--
-- PostgreSQL database dump
--

\restrict HtQEF16DByZAoWFWcHLot9IfgGJRf8Yeg2hmS6mxFjKIsNCrA0A9ofkLHF5910B

-- Dumped from database version 16.11
-- Dumped by pg_dump version 16.11

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET xmloption = content;
SET client_min_messages = warning;
SET row_security = off;

--
-- Name: auth; Type: SCHEMA; Schema: -; Owner: postgres
--

CREATE SCHEMA auth;


ALTER SCHEMA auth OWNER TO postgres;

--
-- Name: pgcrypto; Type: EXTENSION; Schema: -; Owner: -
--

CREATE EXTENSION IF NOT EXISTS pgcrypto WITH SCHEMA public;


--
-- Name: EXTENSION pgcrypto; Type: COMMENT; Schema: -; Owner: 
--

COMMENT ON EXTENSION pgcrypto IS 'cryptographic functions';


--
-- Name: role(); Type: FUNCTION; Schema: auth; Owner: postgres
--

CREATE FUNCTION auth.role() RETURNS text
    LANGUAGE sql STABLE
    AS $$
  SELECT COALESCE(NULLIF(current_setting('request.jwt.claims', true)::json->>'role', ''), 'anonymous');
$$;


ALTER FUNCTION auth.role() OWNER TO postgres;

--
-- Name: user_id(); Type: FUNCTION; Schema: auth; Owner: postgres
--

CREATE FUNCTION auth.user_id() RETURNS uuid
    LANGUAGE sql STABLE
    AS $$
  SELECT NULLIF(current_setting('request.jwt.claims', true)::json->>'id', '')::UUID;
$$;


ALTER FUNCTION auth.user_id() OWNER TO postgres;

--
-- Name: cleanup_old_data(); Type: FUNCTION; Schema: public; Owner: postgres
--

CREATE FUNCTION public.cleanup_old_data() RETURNS void
    LANGUAGE plpgsql
    AS $$
BEGIN
    DELETE FROM system_metrics WHERE timestamp < NOW() - INTERVAL '7 days';
    DELETE FROM network_traffic WHERE recorded_at < NOW() - INTERVAL '7 days';
    DELETE FROM disk_snapshots WHERE recorded_at < NOW() - INTERVAL '7 days';
    DELETE FROM service_uptime WHERE checked_at < NOW() - INTERVAL '30 days';
EXCEPTION WHEN undefined_column OR undefined_table THEN
    NULL;
END;
$$;


ALTER FUNCTION public.cleanup_old_data() OWNER TO postgres;

--
-- Name: update_updated_at_column(); Type: FUNCTION; Schema: public; Owner: postgres
--

CREATE FUNCTION public.update_updated_at_column() RETURNS trigger
    LANGUAGE plpgsql
    AS $$
BEGIN
    NEW.updated_at = now();
    RETURN NEW;
END;
$$;


ALTER FUNCTION public.update_updated_at_column() OWNER TO postgres;

SET default_tablespace = '';

SET default_table_access_method = heap;

--
-- Name: activity_logs; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.activity_logs (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    activity_type text NOT NULL,
    description text,
    metadata jsonb,
    created_at timestamp with time zone DEFAULT now()
);


ALTER TABLE public.activity_logs OWNER TO postgres;

--
-- Name: ad_clicks; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.ad_clicks (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    ad_id uuid,
    clicked_at timestamp with time zone DEFAULT now() NOT NULL,
    ip_hash text,
    user_agent text,
    referrer text
);


ALTER TABLE public.ad_clicks OWNER TO postgres;

--
-- Name: ad_purchases; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.ad_purchases (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    name text NOT NULL,
    target_channel text NOT NULL,
    target_subscribers integer DEFAULT 0,
    our_channel_id uuid,
    ad_link text,
    tracking_code text,
    cost numeric DEFAULT 0 NOT NULL,
    currency text DEFAULT 'RUB'::text,
    start_date timestamp with time zone,
    end_date timestamp with time zone,
    subscribers_before integer DEFAULT 0,
    subscribers_after integer DEFAULT 0,
    new_subscribers integer DEFAULT 0,
    clicks integer DEFAULT 0,
    status text DEFAULT 'planned'::text,
    notes text,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    updated_at timestamp with time zone DEFAULT now() NOT NULL
);


ALTER TABLE public.ad_purchases OWNER TO postgres;

--
-- Name: ad_sales; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.ad_sales (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    channel_id uuid NOT NULL,
    rate_id uuid,
    client_name text NOT NULL,
    client_contact text,
    ad_link text,
    tracking_code text,
    price numeric DEFAULT 0 NOT NULL,
    currency text DEFAULT 'RUB'::text,
    publish_date timestamp with time zone,
    end_date timestamp with time zone,
    clicks integer DEFAULT 0,
    impressions integer DEFAULT 0,
    status text DEFAULT 'pending'::text,
    is_paid boolean DEFAULT false,
    payment_date timestamp with time zone,
    notes text,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    updated_at timestamp with time zone DEFAULT now() NOT NULL
);


ALTER TABLE public.ad_sales OWNER TO postgres;

--
-- Name: admins; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.admins (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    name text NOT NULL,
    email text,
    phone text,
    telegram_chat_id text,
    telegram_username text,
    is_active boolean DEFAULT true NOT NULL,
    receive_notifications boolean DEFAULT true NOT NULL,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    updated_at timestamp with time zone DEFAULT now() NOT NULL
);


ALTER TABLE public.admins OWNER TO postgres;

--
-- Name: ai_requests; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.ai_requests (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    model text DEFAULT 'gpt-4'::text,
    prompt text,
    response text,
    tokens_used integer DEFAULT 0,
    cost numeric(10,4) DEFAULT 0,
    created_at timestamp with time zone DEFAULT now()
);


ALTER TABLE public.ai_requests OWNER TO postgres;

--
-- Name: app_settings; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.app_settings (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    key text NOT NULL,
    value jsonb,
    created_at timestamp with time zone DEFAULT now(),
    updated_at timestamp with time zone DEFAULT now()
);


ALTER TABLE public.app_settings OWNER TO postgres;

--
-- Name: backups; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.backups (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    name text NOT NULL,
    type text,
    size_bytes bigint,
    path text,
    status text DEFAULT 'completed'::text,
    created_at timestamp with time zone DEFAULT now()
);


ALTER TABLE public.backups OWNER TO postgres;

--
-- Name: channel_ad_rates; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.channel_ad_rates (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    channel_id uuid NOT NULL,
    format text DEFAULT 'post'::text NOT NULL,
    price numeric DEFAULT 0 NOT NULL,
    currency text DEFAULT 'RUB'::text NOT NULL,
    duration_hours integer DEFAULT 24,
    description text,
    is_active boolean DEFAULT true,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    updated_at timestamp with time zone DEFAULT now() NOT NULL
);


ALTER TABLE public.channel_ad_rates OWNER TO postgres;

--
-- Name: disk_snapshots; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.disk_snapshots (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    mount_point text,
    total_bytes bigint,
    used_bytes bigint,
    percent_used real,
    recorded_at timestamp with time zone DEFAULT now(),
    name text,
    percent real,
    fs_type text
);


ALTER TABLE public.disk_snapshots OWNER TO postgres;

--
-- Name: dns_configs; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.dns_configs (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    name text NOT NULL,
    primary_dns text,
    secondary_dns text,
    is_active boolean DEFAULT true,
    created_at timestamp with time zone DEFAULT now(),
    updated_at timestamp with time zone DEFAULT now()
);


ALTER TABLE public.dns_configs OWNER TO postgres;

--
-- Name: firewall_rules; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.firewall_rules (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    port text NOT NULL,
    from_ip text DEFAULT 'LAN'::text,
    protocol text DEFAULT 'tcp'::text,
    comment text,
    is_active boolean DEFAULT true,
    created_at timestamp with time zone DEFAULT now(),
    updated_at timestamp with time zone DEFAULT now()
);


ALTER TABLE public.firewall_rules OWNER TO postgres;

--
-- Name: media_channels; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.media_channels (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    name text NOT NULL,
    platform text NOT NULL,
    channel_url text,
    subscribers integer DEFAULT 0,
    views integer DEFAULT 0,
    engagement numeric(5,2) DEFAULT 0,
    growth numeric(5,2) DEFAULT 0,
    videos_count integer DEFAULT 0,
    is_active boolean DEFAULT true NOT NULL,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    updated_at timestamp with time zone DEFAULT now() NOT NULL,
    channel_id text,
    username text,
    last_synced_at timestamp with time zone,
    is_monetized boolean DEFAULT false,
    watch_hours integer DEFAULT 0,
    avg_view_duration integer DEFAULT 0,
    ctr numeric DEFAULT 0,
    revenue numeric DEFAULT 0,
    likes integer DEFAULT 0,
    comments integer DEFAULT 0,
    shares integer DEFAULT 0,
    CONSTRAINT media_channels_platform_check CHECK ((platform = ANY (ARRAY['youtube'::text, 'tiktok'::text, 'rutube'::text, 'telegram'::text, 'max'::text, 'vk'::text])))
);


ALTER TABLE public.media_channels OWNER TO postgres;

--
-- Name: monitored_hosts; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.monitored_hosts (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    name text NOT NULL,
    ip text NOT NULL,
    port integer DEFAULT 80,
    description text,
    status text DEFAULT 'unknown'::text,
    last_check_at timestamp with time zone,
    response_time_ms integer,
    created_at timestamp with time zone DEFAULT now()
);


ALTER TABLE public.monitored_hosts OWNER TO postgres;

--
-- Name: network_traffic; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.network_traffic (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    interface text,
    rx_bytes bigint,
    tx_bytes bigint,
    recorded_at timestamp with time zone DEFAULT now()
);


ALTER TABLE public.network_traffic OWNER TO postgres;

--
-- Name: security_settings; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.security_settings (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    ufw_status text DEFAULT 'unknown'::text,
    fail2ban_status text DEFAULT 'unknown'::text,
    ssh_port integer DEFAULT 22,
    last_check_at timestamp with time zone,
    created_at timestamp with time zone DEFAULT now(),
    updated_at timestamp with time zone DEFAULT now()
);


ALTER TABLE public.security_settings OWNER TO postgres;

--
-- Name: service_uptime; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.service_uptime (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    service_id uuid,
    status text NOT NULL,
    response_time_ms integer,
    checked_at timestamp with time zone DEFAULT now()
);


ALTER TABLE public.service_uptime OWNER TO postgres;

--
-- Name: services; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.services (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    name text NOT NULL,
    description text,
    category text DEFAULT 'admin'::text,
    port text NOT NULL,
    url text,
    icon text DEFAULT 'server'::text,
    is_active boolean DEFAULT true,
    status text DEFAULT 'unknown'::text,
    last_check_at timestamp with time zone,
    response_time_ms integer,
    created_at timestamp with time zone DEFAULT now(),
    updated_at timestamp with time zone DEFAULT now()
);


ALTER TABLE public.services OWNER TO postgres;

--
-- Name: system_metrics; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.system_metrics (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    "timestamp" timestamp with time zone DEFAULT now(),
    cpu_percent double precision,
    ram_percent double precision,
    net_rx_total bigint,
    net_tx_total bigint
);


ALTER TABLE public.system_metrics OWNER TO postgres;

--
-- Name: telegram_ads; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.telegram_ads (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    channel_id uuid,
    name text NOT NULL,
    ad_text text,
    ad_link text,
    tracking_code text,
    clicks integer DEFAULT 0,
    impressions integer DEFAULT 0,
    start_date timestamp with time zone,
    end_date timestamp with time zone,
    budget numeric DEFAULT 0,
    spent numeric DEFAULT 0,
    status text DEFAULT 'draft'::text,
    is_active boolean DEFAULT true,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    updated_at timestamp with time zone DEFAULT now() NOT NULL
);


ALTER TABLE public.telegram_ads OWNER TO postgres;

--
-- Name: telegram_bots; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.telegram_bots (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    name text NOT NULL,
    token text NOT NULL,
    description text,
    is_active boolean DEFAULT true NOT NULL,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    updated_at timestamp with time zone DEFAULT now() NOT NULL
);


ALTER TABLE public.telegram_bots OWNER TO postgres;

--
-- Name: vpn_profiles; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.vpn_profiles (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    name text NOT NULL,
    config text,
    is_active boolean DEFAULT true,
    created_at timestamp with time zone DEFAULT now(),
    updated_at timestamp with time zone DEFAULT now()
);


ALTER TABLE public.vpn_profiles OWNER TO postgres;

--
-- Data for Name: activity_logs; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.activity_logs (id, activity_type, description, metadata, created_at) FROM stdin;
aebf2179-cb99-4d2c-b861-55d5f39828ce	login	Admin logged in	\N	2026-01-01 10:34:39.746379+00
20be5fb5-36fd-43df-9a98-a3cbbc9c28bc	system	Dashboard started	\N	2026-01-01 10:34:39.746379+00
c6c5fe46-795e-4af4-84e7-0f811641ee77	audit	Project audit completed	\N	2026-01-01 10:34:39.746379+00
414a01c4-7c8c-42f3-8dc4-91c4044fc5c0	SYSTEM_RESTORE	System functionality restored	{}	2026-01-07 10:03:26.321036+00
f321cc64-f89d-4961-805b-40e464b6fb98	LOGIN_FAILED	Failed login attempt for admin@example.com	{"user_id": null, "ip_address": "::ffff:172.18.0.8"}	2026-01-07 10:10:55.754648+00
fc814ecc-40ab-4177-8c8d-475879791276	LOGIN_FAILED	Failed login attempt for admin@example.com	{"user_id": null, "ip_address": "::ffff:172.18.0.8"}	2026-01-07 10:15:36.678357+00
4073a117-c642-4c5d-b72c-5925049a307a	LOGIN_FAILED	Failed login attempt for admin@example.com	{"user_id": null, "ip_address": "::ffff:172.18.0.8"}	2026-01-07 10:15:47.24692+00
d112b44a-e74a-4296-b27f-6ccf084234e7	LOGIN_FAILED	Failed login attempt for admin@example.comadmin@example.com	{"user_id": null, "ip_address": "::ffff:172.18.0.8"}	2026-01-07 10:16:24.869101+00
95835177-4940-4f16-9987-eee79e44bd64	LOGIN_FAILED	Failed login attempt for admin@example.comadmin@example.com	{"user_id": null, "ip_address": "::ffff:172.18.0.8"}	2026-01-07 10:16:24.874827+00
e6ffaf6c-2fa9-401c-a711-0d0dcfdb7f83	LOGIN_FAILED	Failed login attempt for admin@example.comadmin@example.com	{"user_id": null, "ip_address": "::ffff:172.18.0.8"}	2026-01-07 10:16:33.805607+00
036d5345-3240-45de-a5e5-4e4891db7903	LOGIN_FAILED	Failed login attempt for admin@example.comadmin@example.com	{"user_id": null, "ip_address": "::ffff:172.18.0.8"}	2026-01-07 10:16:33.806088+00
b091818c-0a26-4f42-9880-2025d09ce1f7	LOGIN_FAILED	Failed login attempt for 	{"user_id": null, "ip_address": "::ffff:172.18.0.8"}	2026-01-07 10:17:00.341744+00
d2204e54-4d7e-4707-9171-1818d97577ea	LOGIN_FAILED	Failed login attempt for 	{"user_id": null, "ip_address": "::ffff:172.18.0.8"}	2026-01-07 10:20:07.962341+00
a6f43d3e-ce09-435d-a6ca-d6f3b4eba6b6	LOGIN_FAILED	Failed login attempt for admin@example.com	{"user_id": null, "ip_address": "::ffff:172.18.0.8"}	2026-01-07 10:21:32.466291+00
80c265df-fb84-4a3c-8374-d4de6113f306	LOGIN_FAILED	Failed login attempt for admin@example.com	{"user_id": null, "ip_address": "::ffff:172.18.0.8"}	2026-01-07 10:22:40.967317+00
c01367ce-b348-446a-b128-608031ee4125	LOGIN_FAILED	Failed login attempt for admin@example.com	{"user_id": null, "ip_address": "::ffff:172.18.0.8"}	2026-01-07 10:44:42.633809+00
6130f2f0-9ccd-4c84-91c0-17890ef3545a	LOGIN_FAILED	Failed login attempt for admin@example.com	{"user_id": null, "ip_address": "::ffff:172.18.0.8"}	2026-01-07 10:49:43.30002+00
9c42328b-dd33-423f-adf0-eb92d114a630	LOGIN_FAILED	Failed login attempt for 	{"user_id": null, "ip_address": "::ffff:172.18.0.8"}	2026-01-07 10:57:15.579904+00
8cb85b5c-9858-4587-9d8e-9e8486a80b55	LOGIN_FAILED	Failed login attempt for admin@example.com	{"user_id": null, "ip_address": "::ffff:172.18.0.8"}	2026-01-07 10:57:38.222892+00
e74e1f4d-ee15-4bc3-b6bf-534f2905b24d	LOGIN_FAILED	Failed login attempt for admin@example.com	{"user_id": null, "ip_address": "::ffff:172.18.0.8"}	2026-01-07 10:57:38.226938+00
489ada41-81ba-44e0-9608-5407c96bb3f4	LOGIN_FAILED	Failed login attempt for admin@example.com	{"user_id": null, "ip_address": "::ffff:172.18.0.8"}	2026-01-07 10:57:38.22722+00
5c17dab0-a3ff-4b29-9f4d-68103ca85063	LOGIN_FAILED	Failed login attempt for admin@example.com	{"user_id": null, "ip_address": "::ffff:172.18.0.8"}	2026-01-07 11:03:56.32079+00
e986915f-687e-4be4-9967-170d1ccc7ab9	LOGIN_FAILED	Failed login attempt for admin@example.com	{"user_id": null, "ip_address": "::ffff:172.18.0.8"}	2026-01-07 11:04:05.915812+00
65175126-446e-4088-a15c-8b812e658cd8	LOGIN_SUCCESS	User test@test.com logged in (Recovery)	{"user_id": null, "ip_address": "::ffff:172.18.0.1"}	2026-01-07 11:08:47.150369+00
eb4bf4a5-5b26-480c-b1b6-21b77822ac20	LOGIN_SUCCESS	User admin@example.com logged in (Recovery)	{"user_id": null, "ip_address": "::ffff:172.18.0.7"}	2026-01-07 11:13:16.402406+00
8846355a-a6e4-4080-a678-524c9354f81c	LOGIN_FAILED	Failed login attempt for admin@example.com	{"user_id": null, "ip_address": "::ffff:172.18.0.7"}	2026-01-07 11:35:53.392703+00
b52eb49b-f27c-4588-a26b-c9bf37e3b8b6	LOGIN_SUCCESS	User admin@example.com logged in (Recovery)	{"user_id": null, "ip_address": "::ffff:172.18.0.7"}	2026-01-07 11:36:44.674716+00
b6e170d4-5823-409d-bdb2-734539c261ec	LOGIN_SUCCESS	User admin@example.com logged in (Recovery)	{"user_id": null, "ip_address": "::ffff:172.18.0.7"}	2026-01-07 11:40:59.166163+00
bd489465-25ff-4d56-abe4-d7715e68aaee	LOGIN_SUCCESS	User test@test.com logged in (Recovery)	{"user_id": null, "ip_address": "::ffff:172.18.0.3"}	2026-01-07 12:07:27.2784+00
9ddb4540-af6a-4f4b-9c48-f4b7104cb10b	LOGIN_SUCCESS	User admin@example.com logged in (Recovery)	{"user_id": null, "ip_address": "::ffff:172.18.0.3"}	2026-01-07 12:33:25.087473+00
e29b3002-ccb1-4f08-adf6-721415b9dc55	LOGIN_SUCCESS	User test@test.com logged in (Recovery)	{"user_id": null, "ip_address": "::ffff:172.18.0.3"}	2026-01-07 12:51:56.070954+00
c141e1fd-2a50-4365-99d3-a452216a89a4	LOGIN_SUCCESS	User test@test.com logged in (Recovery)	{"user_id": null, "ip_address": "::ffff:172.18.0.3"}	2026-01-07 12:59:44.313731+00
d5e7a15a-541f-456f-b600-3e18f2483587	LOGIN_SUCCESS	User admin@example.com logged in (Recovery)	{"user_id": null, "ip_address": "::ffff:172.18.0.3"}	2026-01-07 13:03:31.391491+00
f72dac24-3b02-4472-915c-62e99473b66e	LOGIN_SUCCESS	User test@test.com logged in (Recovery)	{"user_id": null, "ip_address": "::ffff:172.18.0.3"}	2026-01-07 13:07:36.75228+00
9face80f-0e55-4013-862d-47f463bd46e6	LOGIN_SUCCESS	User admin@example.com logged in (Recovery)	{"user_id": null, "ip_address": "::ffff:172.18.0.3"}	2026-01-07 13:10:14.897249+00
49fc3acf-1264-4278-9a2d-345da876d385	LOGIN_SUCCESS	User admin@example.com logged in (Recovery)	{"user_id": null, "ip_address": "::ffff:172.18.0.3"}	2026-01-07 13:57:22.702117+00
631b8d0e-f873-498b-8736-2b63bf47fcd9	LOGIN_SUCCESS	User admin@example.com logged in (Recovery)	{"user_id": null, "ip_address": "::ffff:172.18.0.3"}	2026-01-07 14:05:54.616771+00
e3c6e1b6-1f49-433b-b28c-e53265b177f7	LOGIN_FAILED	Failed login attempt for 	{"user_id": null, "ip_address": "::ffff:172.18.0.3"}	2026-01-07 14:22:42.357728+00
428a377a-b066-42e5-ab07-52d1830e4e31	LOGIN_SUCCESS	User admin@example.com logged in (Recovery)	{"user_id": null, "ip_address": "::ffff:172.18.0.3"}	2026-01-07 14:24:15.320584+00
5cf8b91f-f516-41db-a33a-f631ef0f872c	LOGIN_FAILED	Failed login attempt for 	{"user_id": null, "ip_address": "::ffff:172.18.0.3"}	2026-01-07 14:27:51.63372+00
fad1464a-dd94-47d1-986e-c53967b934a2	LOGIN_FAILED	Failed login attempt for 	{"user_id": null, "ip_address": "::ffff:172.18.0.3"}	2026-01-07 14:28:03.190972+00
f6f6a6ea-3e54-4c89-a595-20b938270dde	LOGIN_FAILED	Failed login attempt for 	{"user_id": null, "ip_address": "::ffff:172.18.0.3"}	2026-01-07 14:29:10.72892+00
58cadeb7-1ad9-44e1-a94c-83a3586ff2f9	LOGIN_FAILED	Failed login attempt for 	{"user_id": null, "ip_address": "::ffff:172.18.0.3"}	2026-01-07 14:33:45.113569+00
e443f02c-c17f-460d-a0ae-056eae1b4dce	LOGIN_FAILED	Failed login attempt for 	{"user_id": null, "ip_address": "::ffff:172.18.0.3"}	2026-01-07 14:34:14.783459+00
bccfa782-b55f-410c-a19f-283e09f416fe	LOGIN_FAILED	Failed login attempt for 	{"user_id": null, "ip_address": "::ffff:172.18.0.3"}	2026-01-07 14:35:29.922494+00
4917135d-8a91-44c2-8539-cbd937ad5ac4	LOGIN_FAILED	Failed login attempt for 	{"user_id": null, "ip_address": "::ffff:172.18.0.3"}	2026-01-07 14:36:03.114665+00
19bf1ae6-7dcc-46e5-87c6-f80afcbfee3e	LOGIN_SUCCESS	User admin@example.com logged in (Recovery)	{"user_id": null, "ip_address": "::ffff:172.18.0.3"}	2026-01-07 14:36:48.618796+00
22b8beb9-3d2d-4fc3-8937-7ba9efc82148	LOGIN_SUCCESS	User admin@example.com logged in (Recovery)	{"user_id": null, "ip_address": "::ffff:172.18.0.3"}	2026-01-07 14:41:38.161336+00
b74a903a-f0a5-4263-a1fa-df5056b5e7b3	LOGIN_SUCCESS	User admin@example.com logged in (Recovery)	{"user_id": null, "ip_address": "::ffff:172.18.0.3"}	2026-01-07 15:03:56.565596+00
f31a6a9d-da37-46dc-8aaa-a3fe34edd2d4	LOGIN_SUCCESS	User admin@example.com logged in (Recovery)	{"user_id": null, "ip_address": "::ffff:172.18.0.3"}	2026-01-07 15:11:17.508353+00
\.


--
-- Data for Name: ad_clicks; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.ad_clicks (id, ad_id, clicked_at, ip_hash, user_agent, referrer) FROM stdin;
\.


--
-- Data for Name: ad_purchases; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.ad_purchases (id, name, target_channel, target_subscribers, our_channel_id, ad_link, tracking_code, cost, currency, start_date, end_date, subscribers_before, subscribers_after, new_subscribers, clicks, status, notes, created_at, updated_at) FROM stdin;
\.


--
-- Data for Name: ad_sales; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.ad_sales (id, channel_id, rate_id, client_name, client_contact, ad_link, tracking_code, price, currency, publish_date, end_date, clicks, impressions, status, is_paid, payment_date, notes, created_at, updated_at) FROM stdin;
\.


--
-- Data for Name: admins; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.admins (id, name, email, phone, telegram_chat_id, telegram_username, is_active, receive_notifications, created_at, updated_at) FROM stdin;
\.


--
-- Data for Name: ai_requests; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.ai_requests (id, model, prompt, response, tokens_used, cost, created_at) FROM stdin;
\.


--
-- Data for Name: app_settings; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.app_settings (id, key, value, created_at, updated_at) FROM stdin;
9c89e188-f310-4359-9bc8-2c175409c74e	security	{"autoLock": 5, "twoFactor": false, "ipWhitelist": []}	2025-12-25 09:42:27.478465+00	2025-12-25 09:42:27.478465+00
60fbf0a8-f943-4c74-8ac8-e936348b5421	notifications	{"email": true, "slack": false, "telegram": false}	2025-12-25 09:42:27.478465+00	2025-12-25 09:42:27.478465+00
074a992f-d19a-4dd6-9943-ed61ebc5fabe	appearance	{"theme": "dark", "language": "ru"}	2025-12-25 09:42:27.478465+00	2025-12-25 09:42:27.478465+00
fefba4a3-213d-4765-bb39-cf2698adb9e1	dashboardVersion	2.3	2026-01-01 10:24:36.300358+00	2026-01-01 10:24:36.300358+00
16948e9c-7991-4cef-95f1-69a4bb061edd	themeDark	true	2026-01-01 10:24:36.300358+00	2026-01-01 10:24:36.300358+00
7ae24afc-1175-46d6-b1e3-88fb698dd24e	serverIp	"192.168.1.220"	2026-01-01 10:24:50.65158+00	2026-01-01 10:24:50.65158+00
\.


--
-- Data for Name: backups; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.backups (id, name, type, size_bytes, path, status, created_at) FROM stdin;
\.


--
-- Data for Name: channel_ad_rates; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.channel_ad_rates (id, channel_id, format, price, currency, duration_hours, description, is_active, created_at, updated_at) FROM stdin;
\.


--
-- Data for Name: disk_snapshots; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.disk_snapshots (id, mount_point, total_bytes, used_bytes, percent_used, recorded_at, name, percent, fs_type) FROM stdin;
5126f829-ada8-4ff6-8be0-d39c2c36d85e	/	248215199744	153312780288	\N	2026-01-06 16:10:41.069043+00	System	64.7	ext4
ce9eaed6-cff2-452f-a3c3-4bdf366920be	/home/inno/compose_ARCHIVED_DO_NOT_USE/backups	195762728960	24133632	\N	2026-01-06 16:10:41.072014+00	Backups	0	ext4
d8c6172f-fb23-4f5b-b202-6319cffbc37e	/home/inno/compose_ARCHIVED_DO_NOT_USE/volumes/media	3936818806784	12288	\N	2026-01-06 16:10:41.073+00	Media	0	ext4
63f79b4c-0d21-43c2-a2a2-eebb88ec3774	/	248215199744	165663199232	\N	2026-01-06 19:05:41.622529+00	System	69.9	ext4
bb83eca9-a550-4b24-bef4-061df1c11b70	/home/inno/compose_ARCHIVED_DO_NOT_USE/backups	195762728960	24133632	\N	2026-01-06 19:05:41.625165+00	Backups	0	ext4
c7a6cfae-ca9e-42d9-b37c-3b61e3b9a0ae	/home/inno/compose_ARCHIVED_DO_NOT_USE/volumes/media	3936818806784	12288	\N	2026-01-06 19:05:41.627105+00	Media	0	ext4
2697f426-37ba-4b0c-94e8-3a8aa81c0b55	/	248215199744	173793533952	\N	2026-01-06 22:00:42.183264+00	System	73.3	ext4
cfc7b9df-6ba7-4620-9329-090a02edd831	/home/inno/compose_ARCHIVED_DO_NOT_USE/backups	195762728960	24133632	\N	2026-01-06 22:00:42.185684+00	Backups	0	ext4
1c62592a-5551-42db-bb32-433f1c2b6d35	/home/inno/compose_ARCHIVED_DO_NOT_USE/volumes/media	3936818806784	12288	\N	2026-01-06 22:00:42.186711+00	Media	0	ext4
d0ddc0a1-832d-41d8-ba36-e9ac5d3b9f69	/	248215199744	173794013184	\N	2026-01-07 00:55:42.485966+00	System	73.3	ext4
e2461446-7725-4503-98b0-4d974b34b938	/home/inno/compose_ARCHIVED_DO_NOT_USE/backups	195762728960	24133632	\N	2026-01-07 00:55:42.488335+00	Backups	0	ext4
3feb98a3-a274-4ad8-a7c1-b1eb8906ae40	/home/inno/compose_ARCHIVED_DO_NOT_USE/volumes/media	3936818806784	12288	\N	2026-01-07 00:55:42.489328+00	Media	0	ext4
68834e7e-c0dd-4e80-b3be-23915174e5f2	/	248215199744	173787131904	\N	2026-01-07 03:50:42.675649+00	System	73.3	ext4
3e24f614-ebfa-4bfd-b011-52b40a176772	/home/inno/compose_ARCHIVED_DO_NOT_USE/backups	195762728960	24133632	\N	2026-01-07 03:50:42.678093+00	Backups	0	ext4
e3a81cb1-0c2c-4673-9357-7621cb325df1	/home/inno/compose_ARCHIVED_DO_NOT_USE/volumes/media	3936818806784	12288	\N	2026-01-07 03:50:42.679948+00	Media	0	ext4
993a1c47-e505-42c4-9190-7dab6f42c5db	/	248215199744	173909090304	\N	2026-01-07 06:45:42.862123+00	System	73.4	ext4
9c34d998-4bfa-4058-abef-bfd09f3fb90c	/home/inno/compose_ARCHIVED_DO_NOT_USE/backups	195762728960	24133632	\N	2026-01-07 06:45:42.868262+00	Backups	0	ext4
c716cbe5-44f9-4050-8d05-7bfc22954af1	/home/inno/compose_ARCHIVED_DO_NOT_USE/volumes/media	3936818806784	12288	\N	2026-01-07 06:45:42.870087+00	Media	0	ext4
aa76725e-5d02-4823-8b73-7ebb49bd56fd	/	248215199744	209894236160	\N	2026-01-07 09:37:12.142438+00	System	88.6	ext4
f63e5983-bc1e-49cc-b629-63f923472513	/home/inno/compose_ARCHIVED_DO_NOT_USE/backups	195762728960	24133632	\N	2026-01-07 09:37:12.154651+00	Backups	0	ext4
d21dc897-a415-4329-a399-b10f41006a31	/home/inno/compose_ARCHIVED_DO_NOT_USE/volumes/media	3936818806784	12288	\N	2026-01-07 09:37:12.176767+00	Media	0	ext4
d9568a8c-68bc-4e8d-8cfd-ebebd7b35759	/	248215199744	153655767040	\N	2026-01-06 16:15:41.109585+00	System	64.8	ext4
f4f3e136-92f7-478b-a4f7-c2cd7d8a8c2d	/home/inno/compose_ARCHIVED_DO_NOT_USE/backups	195762728960	24133632	\N	2026-01-06 16:15:41.113525+00	Backups	0	ext4
031c52ca-5db7-4682-8ada-d47b5a3c9ba5	/home/inno/compose_ARCHIVED_DO_NOT_USE/volumes/media	3936818806784	12288	\N	2026-01-06 16:15:41.115046+00	Media	0	ext4
a95bd248-4bd9-405e-98bb-cd2fb3bc8659	/	248215199744	166047653888	\N	2026-01-06 19:10:41.670151+00	System	70.1	ext4
d08419e5-7e49-4bb0-9e38-7bffa233601b	/home/inno/compose_ARCHIVED_DO_NOT_USE/backups	195762728960	24133632	\N	2026-01-06 19:10:41.676502+00	Backups	0	ext4
f196b919-494e-4c85-88ca-27361ccfa8bb	/home/inno/compose_ARCHIVED_DO_NOT_USE/volumes/media	3936818806784	12288	\N	2026-01-06 19:10:41.678711+00	Media	0	ext4
d8c3acaf-bdc4-4864-91f5-93217095957e	/	248215199744	173793546240	\N	2026-01-06 22:05:42.219779+00	System	73.3	ext4
0703963c-ba35-4ad0-b1a4-570904d3d874	/home/inno/compose_ARCHIVED_DO_NOT_USE/backups	195762728960	24133632	\N	2026-01-06 22:05:42.221178+00	Backups	0	ext4
9d91dcfe-2718-4fd5-ac03-bad47d96e50c	/home/inno/compose_ARCHIVED_DO_NOT_USE/volumes/media	3936818806784	12288	\N	2026-01-06 22:05:42.222149+00	Media	0	ext4
dc9fd2f5-9d8c-42b9-a255-39851734ac52	/	248215199744	173794025472	\N	2026-01-07 01:00:42.487957+00	System	73.3	ext4
9b97b607-1116-4784-acb9-abdb5fe65941	/home/inno/compose_ARCHIVED_DO_NOT_USE/backups	195762728960	24133632	\N	2026-01-07 01:00:42.490182+00	Backups	0	ext4
7a50692d-9e91-400f-a910-5afb297d4c84	/home/inno/compose_ARCHIVED_DO_NOT_USE/volumes/media	3936818806784	12288	\N	2026-01-07 01:00:42.491109+00	Media	0	ext4
2459045a-f3ab-448f-a5a5-a591868a76d1	/	248215199744	173780381696	\N	2026-01-07 03:55:42.684249+00	System	73.3	ext4
862435ad-af87-45d0-9fff-40fc18624b82	/home/inno/compose_ARCHIVED_DO_NOT_USE/backups	195762728960	24133632	\N	2026-01-07 03:55:42.686214+00	Backups	0	ext4
e50e2f5f-6220-4930-a8a8-ecbf6df43a31	/home/inno/compose_ARCHIVED_DO_NOT_USE/volumes/media	3936818806784	12288	\N	2026-01-07 03:55:42.687158+00	Media	0	ext4
0fc5641c-5cd8-4b22-abfb-090122655498	/	248215199744	173904998400	\N	2026-01-07 06:50:42.954588+00	System	73.4	ext4
9f4815f2-ec20-497d-a615-4a0e55aa2852	/home/inno/compose_ARCHIVED_DO_NOT_USE/backups	195762728960	24133632	\N	2026-01-07 06:50:42.956594+00	Backups	0	ext4
16955eba-9887-4e7c-8c8f-14b9b2642de8	/home/inno/compose_ARCHIVED_DO_NOT_USE/volumes/media	3936818806784	12288	\N	2026-01-07 06:50:42.957552+00	Media	0	ext4
caa99c79-2401-4f3c-b624-20200c5f3f64	/	248215199744	189383475200	\N	2026-01-07 09:42:12.258519+00	System	79.9	ext4
3b4406bc-8a89-44d9-9d5c-5adfa5eb7b5c	/home/inno/compose_ARCHIVED_DO_NOT_USE/backups	195762728960	24133632	\N	2026-01-07 09:42:12.265134+00	Backups	0	ext4
f551f716-dd35-49f4-96ae-ce12f5286a34	/home/inno/compose_ARCHIVED_DO_NOT_USE/volumes/media	3936818806784	12288	\N	2026-01-07 09:42:12.267923+00	Media	0	ext4
2364f920-1f1a-4dc2-b465-ec22ff773635	/	248215199744	153955618816	\N	2026-01-06 16:20:41.112168+00	System	65	ext4
bbbe42a9-8f27-4540-91e2-e78148225dfc	/home/inno/compose_ARCHIVED_DO_NOT_USE/backups	195762728960	24133632	\N	2026-01-06 16:20:41.114419+00	Backups	0	ext4
0c0abf5f-4845-4ea1-ad96-de578b60f6ce	/home/inno/compose_ARCHIVED_DO_NOT_USE/volumes/media	3936818806784	12288	\N	2026-01-06 16:20:41.115302+00	Media	0	ext4
f6f47cea-6270-4645-9856-84f2b78fa150	/	248215199744	166415130624	\N	2026-01-06 19:15:41.714335+00	System	70.2	ext4
a5f50257-0457-4174-bc8b-0b0929e3458c	/home/inno/compose_ARCHIVED_DO_NOT_USE/backups	195762728960	24133632	\N	2026-01-06 19:15:41.7189+00	Backups	0	ext4
f141777f-c0a0-4bb2-aa4e-040fd466e0dd	/home/inno/compose_ARCHIVED_DO_NOT_USE/volumes/media	3936818806784	12288	\N	2026-01-06 19:15:41.720215+00	Media	0	ext4
b60cd67b-1811-4ce5-bbf5-0c82dc473bba	/	248215199744	173793562624	\N	2026-01-06 22:10:42.181336+00	System	73.3	ext4
58360def-4f05-4577-8a4d-990d20fda2a2	/home/inno/compose_ARCHIVED_DO_NOT_USE/backups	195762728960	24133632	\N	2026-01-06 22:10:42.183302+00	Backups	0	ext4
815b6048-25c4-4bbd-a6be-54a2f5a86a86	/home/inno/compose_ARCHIVED_DO_NOT_USE/volumes/media	3936818806784	12288	\N	2026-01-06 22:10:42.184217+00	Media	0	ext4
397831ce-5dce-4221-819a-75261d55bd7f	/	248215199744	173794037760	\N	2026-01-07 01:05:42.487877+00	System	73.3	ext4
ae61dffe-9c9d-4624-be9f-946014579f0d	/home/inno/compose_ARCHIVED_DO_NOT_USE/backups	195762728960	24133632	\N	2026-01-07 01:05:42.48934+00	Backups	0	ext4
f9f9a270-66c0-4fd8-b576-05e0bb711229	/home/inno/compose_ARCHIVED_DO_NOT_USE/volumes/media	3936818806784	12288	\N	2026-01-07 01:05:42.490321+00	Media	0	ext4
6361ea50-7a06-4a07-895d-1c38958ca357	/	248215199744	173783662592	\N	2026-01-07 04:00:42.679388+00	System	73.3	ext4
ba90d349-383e-41cd-a491-f7b8770c7c9c	/home/inno/compose_ARCHIVED_DO_NOT_USE/backups	195762728960	24133632	\N	2026-01-07 04:00:42.681425+00	Backups	0	ext4
639e86b0-fc94-44c3-ac9e-50d22b616110	/home/inno/compose_ARCHIVED_DO_NOT_USE/volumes/media	3936818806784	12288	\N	2026-01-07 04:00:42.682278+00	Media	0	ext4
967feb3d-1fad-47e6-aebd-744de76a1810	/	248215199744	173901586432	\N	2026-01-07 06:55:43.085129+00	System	73.4	ext4
379d1306-e788-46db-94df-17967b378f23	/home/inno/compose_ARCHIVED_DO_NOT_USE/backups	195762728960	24133632	\N	2026-01-07 06:55:43.089255+00	Backups	0	ext4
2c44d921-da3e-46cc-b5ba-18a836160b8a	/home/inno/compose_ARCHIVED_DO_NOT_USE/volumes/media	3936818806784	12288	\N	2026-01-07 06:55:43.090372+00	Media	0	ext4
c73e555c-8c5e-4bcc-a2f9-ff7fbfcab249	/	248215199744	189383675904	\N	2026-01-07 09:47:12.358681+00	System	79.9	ext4
3d4bfefe-d09b-4e5a-a01f-460520b52fe2	/home/inno/compose_ARCHIVED_DO_NOT_USE/backups	195762728960	24133632	\N	2026-01-07 09:47:12.360392+00	Backups	0	ext4
eac33c37-1d29-41c4-a1ec-f70996808d1d	/home/inno/compose_ARCHIVED_DO_NOT_USE/volumes/media	3936818806784	12288	\N	2026-01-07 09:47:12.361354+00	Media	0	ext4
9ffa7e46-20e6-4bf3-9073-ab6ca39521ce	/	248215199744	153817735168	\N	2026-01-06 16:25:41.116308+00	System	64.9	ext4
c44fdd20-a6f0-466c-8937-95d5f0f83569	/home/inno/compose_ARCHIVED_DO_NOT_USE/backups	195762728960	24133632	\N	2026-01-06 16:25:41.118241+00	Backups	0	ext4
5d1097b3-d4f8-43bd-888c-608a70b7edb9	/home/inno/compose_ARCHIVED_DO_NOT_USE/volumes/media	3936818806784	12288	\N	2026-01-06 16:25:41.119171+00	Media	0	ext4
1a94329f-76e0-47ad-b957-834775a82bcd	/	248215199744	166796800000	\N	2026-01-06 19:20:41.712369+00	System	70.4	ext4
1870312a-7c2c-46a7-a1ac-275e8b54c072	/home/inno/compose_ARCHIVED_DO_NOT_USE/backups	195762728960	24133632	\N	2026-01-06 19:20:41.721667+00	Backups	0	ext4
be9c905d-10f4-4a84-a5dd-de43636054bd	/home/inno/compose_ARCHIVED_DO_NOT_USE/volumes/media	3936818806784	12288	\N	2026-01-06 19:20:41.724934+00	Media	0	ext4
98f3f63a-3c05-43d9-a593-7e1e4e0489aa	/	248215199744	173793570816	\N	2026-01-06 22:15:42.181747+00	System	73.3	ext4
3231bc0a-8f1e-4735-8720-a34e7e834d89	/home/inno/compose_ARCHIVED_DO_NOT_USE/backups	195762728960	24133632	\N	2026-01-06 22:15:42.183749+00	Backups	0	ext4
f6411482-49b5-43e9-9a8a-a2328f63b094	/home/inno/compose_ARCHIVED_DO_NOT_USE/volumes/media	3936818806784	12288	\N	2026-01-06 22:15:42.186208+00	Media	0	ext4
2d89bfca-d47b-4536-8360-cd1ee78e4abf	/	248215199744	173794066432	\N	2026-01-07 01:10:42.480769+00	System	73.3	ext4
a0e464c2-dd36-4e97-b286-0403f63129e3	/home/inno/compose_ARCHIVED_DO_NOT_USE/backups	195762728960	24133632	\N	2026-01-07 01:10:42.482705+00	Backups	0	ext4
aa84c02a-3e85-4509-a4b8-fd34791c8ae5	/home/inno/compose_ARCHIVED_DO_NOT_USE/volumes/media	3936818806784	12288	\N	2026-01-07 01:10:42.483652+00	Media	0	ext4
7e4f35eb-78ef-494e-b12e-97072dbd0a37	/	248215199744	173782376448	\N	2026-01-07 04:05:42.665304+00	System	73.3	ext4
a020e8f4-f531-491b-8458-3cfd3736f94c	/home/inno/compose_ARCHIVED_DO_NOT_USE/backups	195762728960	24133632	\N	2026-01-07 04:05:42.667946+00	Backups	0	ext4
d085169d-59d5-4521-b93e-adb0a2c37e78	/home/inno/compose_ARCHIVED_DO_NOT_USE/volumes/media	3936818806784	12288	\N	2026-01-07 04:05:42.669831+00	Media	0	ext4
968ab115-1532-4f20-ae2d-de913e17b605	/	248215199744	173906345984	\N	2026-01-07 07:00:42.864535+00	System	73.4	ext4
397537f7-d3e7-4624-b500-0e0b1460e9f1	/home/inno/compose_ARCHIVED_DO_NOT_USE/backups	195762728960	24133632	\N	2026-01-07 07:00:42.867885+00	Backups	0	ext4
b4ffd244-999e-48f8-8ac3-9695ba7b62fd	/home/inno/compose_ARCHIVED_DO_NOT_USE/volumes/media	3936818806784	12288	\N	2026-01-07 07:00:42.869099+00	Media	0	ext4
0382b443-4018-4616-a0e0-58d62fba8c9a	/	248215199744	189383770112	\N	2026-01-07 09:52:12.382111+00	System	79.9	ext4
ad98970b-6739-47b2-b870-6f0a87bcc234	/home/inno/compose_ARCHIVED_DO_NOT_USE/backups	195762728960	24133632	\N	2026-01-07 09:52:12.384455+00	Backups	0	ext4
a770f590-10c1-4a98-8bed-896a5e2c62f4	/home/inno/compose_ARCHIVED_DO_NOT_USE/volumes/media	3936818806784	12288	\N	2026-01-07 09:52:12.38577+00	Media	0	ext4
6cd3fcbb-ab0c-4af2-b675-391017d4f025	/	248215199744	153821499392	\N	2026-01-06 16:30:41.167653+00	System	64.9	ext4
8c5de073-9aea-407b-91fd-daaa1ca8a1d5	/home/inno/compose_ARCHIVED_DO_NOT_USE/backups	195762728960	24133632	\N	2026-01-06 16:30:41.173689+00	Backups	0	ext4
c32f166e-e3a0-495b-8a7e-0b38ffed9f41	/home/inno/compose_ARCHIVED_DO_NOT_USE/volumes/media	3936818806784	12288	\N	2026-01-06 16:30:41.175711+00	Media	0	ext4
c99551c6-b56d-40f5-a2c4-5fb5e8d05d6d	/	248215199744	167170342912	\N	2026-01-06 19:25:41.718192+00	System	70.5	ext4
6a994a27-eb76-40b0-a8e8-2b92aa237823	/home/inno/compose_ARCHIVED_DO_NOT_USE/backups	195762728960	24133632	\N	2026-01-06 19:25:41.7248+00	Backups	0	ext4
5798a4c1-e78d-4407-824e-d5e1e5e6a6d2	/home/inno/compose_ARCHIVED_DO_NOT_USE/volumes/media	3936818806784	12288	\N	2026-01-06 19:25:41.727266+00	Media	0	ext4
acaea826-269b-4479-9887-124f3c41355c	/	248215199744	173793607680	\N	2026-01-06 22:20:42.184274+00	System	73.3	ext4
89feac16-9689-4b78-a1ec-abab39080016	/home/inno/compose_ARCHIVED_DO_NOT_USE/backups	195762728960	24133632	\N	2026-01-06 22:20:42.186189+00	Backups	0	ext4
2363a984-1888-4307-a4b5-c4cc747e96bf	/home/inno/compose_ARCHIVED_DO_NOT_USE/volumes/media	3936818806784	12288	\N	2026-01-06 22:20:42.187153+00	Media	0	ext4
63059b60-f824-44c4-82d7-df541240672d	/	248215199744	173794070528	\N	2026-01-07 01:15:42.520914+00	System	73.3	ext4
3c2ec230-2eec-459e-825f-5394c0fa6f1a	/home/inno/compose_ARCHIVED_DO_NOT_USE/backups	195762728960	24133632	\N	2026-01-07 01:15:42.523313+00	Backups	0	ext4
b57ebca0-5f1f-4f24-afa0-09cd252de56a	/home/inno/compose_ARCHIVED_DO_NOT_USE/volumes/media	3936818806784	12288	\N	2026-01-07 01:15:42.524319+00	Media	0	ext4
db848e13-9bd6-4252-989b-708cd8d50004	/	248215199744	173785010176	\N	2026-01-07 04:10:42.700419+00	System	73.3	ext4
90936357-52e4-482a-9b3f-1b035db42859	/home/inno/compose_ARCHIVED_DO_NOT_USE/backups	195762728960	24133632	\N	2026-01-07 04:10:42.70641+00	Backups	0	ext4
1d978a53-edca-4cfa-990e-67aeff21f83a	/home/inno/compose_ARCHIVED_DO_NOT_USE/volumes/media	3936818806784	12288	\N	2026-01-07 04:10:42.708265+00	Media	0	ext4
31ca9f40-a40c-47dc-8d22-32d32d075e3b	/	248215199744	173902643200	\N	2026-01-07 07:05:42.844063+00	System	73.4	ext4
84e06a66-115b-49a1-8d29-15fd502e7129	/home/inno/compose_ARCHIVED_DO_NOT_USE/backups	195762728960	24133632	\N	2026-01-07 07:05:42.846633+00	Backups	0	ext4
fe108b10-13c6-4b8c-900f-bbf5e4629dbc	/home/inno/compose_ARCHIVED_DO_NOT_USE/volumes/media	3936818806784	12288	\N	2026-01-07 07:05:42.84857+00	Media	0	ext4
5636e42e-0314-4e7f-9293-4b168768a002	/	248215199744	189383872512	\N	2026-01-07 09:57:12.37696+00	System	79.9	ext4
e5a287f1-c1f5-4571-96cf-55884ce60262	/home/inno/compose_ARCHIVED_DO_NOT_USE/backups	195762728960	24133632	\N	2026-01-07 09:57:12.379099+00	Backups	0	ext4
e673a250-9380-4c2b-9f14-e0ac2b1a366a	/home/inno/compose_ARCHIVED_DO_NOT_USE/volumes/media	3936818806784	12288	\N	2026-01-07 09:57:12.380081+00	Media	0	ext4
6ecc641e-e257-4fbc-be86-3e2c5d30cb11	/	248215199744	154258886656	\N	2026-01-06 16:35:41.168446+00	System	65.1	ext4
c624cfe2-5b67-4402-9a31-b436763e2a09	/home/inno/compose_ARCHIVED_DO_NOT_USE/backups	195762728960	24133632	\N	2026-01-06 16:35:41.172382+00	Backups	0	ext4
d734a61b-a124-49c1-adfe-0c1f623ae3cf	/home/inno/compose_ARCHIVED_DO_NOT_USE/volumes/media	3936818806784	12288	\N	2026-01-06 16:35:41.173514+00	Media	0	ext4
4fa17fcc-36e0-45c5-9cc2-523476c6aa58	/	248215199744	167550390272	\N	2026-01-06 19:30:41.73017+00	System	70.7	ext4
f57c031a-ab91-488a-adff-72214faaab38	/home/inno/compose_ARCHIVED_DO_NOT_USE/backups	195762728960	24133632	\N	2026-01-06 19:30:41.733663+00	Backups	0	ext4
97b92471-6505-410d-9975-cd460449fc91	/home/inno/compose_ARCHIVED_DO_NOT_USE/volumes/media	3936818806784	12288	\N	2026-01-06 19:30:41.734941+00	Media	0	ext4
8d1b62cf-ccb0-4a19-bbff-4bd4e946db9d	/	248215199744	173793615872	\N	2026-01-06 22:25:42.189859+00	System	73.3	ext4
3c1ef9c9-f10f-4a50-8c8e-7c334889fb0a	/home/inno/compose_ARCHIVED_DO_NOT_USE/backups	195762728960	24133632	\N	2026-01-06 22:25:42.191838+00	Backups	0	ext4
dcefb803-d10e-4f7f-ad68-5c78326c8e54	/home/inno/compose_ARCHIVED_DO_NOT_USE/volumes/media	3936818806784	12288	\N	2026-01-06 22:25:42.192803+00	Media	0	ext4
c5bde8a6-e3e8-4305-896a-433519946e53	/	248215199744	173794086912	\N	2026-01-07 01:20:42.519703+00	System	73.3	ext4
094ae744-c4a0-4a27-9d8c-3a4a21c2e00f	/home/inno/compose_ARCHIVED_DO_NOT_USE/backups	195762728960	24133632	\N	2026-01-07 01:20:42.52195+00	Backups	0	ext4
bece6f31-de51-44f8-afdb-e86468adbfdc	/home/inno/compose_ARCHIVED_DO_NOT_USE/volumes/media	3936818806784	12288	\N	2026-01-07 01:20:42.524933+00	Media	0	ext4
5381ae0e-f05a-46e3-9411-34ee65d26dd2	/	248215199744	173778337792	\N	2026-01-07 04:15:42.694943+00	System	73.3	ext4
8c15fd01-81e8-47c9-93b6-f5ed113f08c2	/home/inno/compose_ARCHIVED_DO_NOT_USE/backups	195762728960	24133632	\N	2026-01-07 04:15:42.696918+00	Backups	0	ext4
e1d89a32-d3a4-4cb0-a637-88100c7a759c	/home/inno/compose_ARCHIVED_DO_NOT_USE/volumes/media	3936818806784	12288	\N	2026-01-07 04:15:42.697815+00	Media	0	ext4
3d2f80dc-189d-4233-977b-6bfe337bfcb0	/	248215199744	173908201472	\N	2026-01-07 07:10:43.062605+00	System	73.4	ext4
b9a6313b-b198-47a3-a339-0ec3d5c02c8d	/home/inno/compose_ARCHIVED_DO_NOT_USE/backups	195762728960	24133632	\N	2026-01-07 07:10:43.065135+00	Backups	0	ext4
f322e662-d286-4b79-af69-b7201ed5e017	/home/inno/compose_ARCHIVED_DO_NOT_USE/volumes/media	3936818806784	12288	\N	2026-01-07 07:10:43.066225+00	Media	0	ext4
ac9061d9-4b72-4270-9805-cbe7c2a363c3	/	248215199744	189385711616	\N	2026-01-07 10:02:12.408298+00	System	79.9	ext4
abad0a49-63a0-4258-8d31-ae9e5eceb17c	/home/inno/compose_ARCHIVED_DO_NOT_USE/backups	195762728960	24133632	\N	2026-01-07 10:02:12.410714+00	Backups	0	ext4
ba647f68-64b1-4c8a-b822-83bce2f99837	/home/inno/compose_ARCHIVED_DO_NOT_USE/volumes/media	3936818806784	12288	\N	2026-01-07 10:02:12.412684+00	Media	0	ext4
be235d2c-3111-4ea1-8199-3a3c52fb094a	/	248215199744	154614312960	\N	2026-01-06 16:40:41.182089+00	System	65.2	ext4
81db4a8f-f50f-4a86-b250-ed95522518ce	/home/inno/compose_ARCHIVED_DO_NOT_USE/backups	195762728960	24133632	\N	2026-01-06 16:40:41.18696+00	Backups	0	ext4
c22bb122-653f-47e4-8b04-6fa91bd1f4fa	/home/inno/compose_ARCHIVED_DO_NOT_USE/volumes/media	3936818806784	12288	\N	2026-01-06 16:40:41.188168+00	Media	0	ext4
76a006da-7dec-403b-b9cc-c76eaee9fcb5	/	248215199744	167924158464	\N	2026-01-06 19:35:41.74682+00	System	70.9	ext4
2b1cfc95-f795-406b-a8c7-5116bb10f73b	/home/inno/compose_ARCHIVED_DO_NOT_USE/backups	195762728960	24133632	\N	2026-01-06 19:35:41.75338+00	Backups	0	ext4
f91716fc-c4f2-44b3-9c82-ebf703942f58	/home/inno/compose_ARCHIVED_DO_NOT_USE/volumes/media	3936818806784	12288	\N	2026-01-06 19:35:41.755368+00	Media	0	ext4
048112cb-902f-40e5-b591-c8acab97361d	/	248215199744	173793636352	\N	2026-01-06 22:30:42.207423+00	System	73.3	ext4
ca17877a-dbba-486d-a632-89b8428d6f9d	/home/inno/compose_ARCHIVED_DO_NOT_USE/backups	195762728960	24133632	\N	2026-01-06 22:30:42.209354+00	Backups	0	ext4
0101931e-81bf-4dc5-ad9c-31b4f6b19973	/home/inno/compose_ARCHIVED_DO_NOT_USE/volumes/media	3936818806784	12288	\N	2026-01-06 22:30:42.21026+00	Media	0	ext4
822fab89-14d5-40f1-b5be-8c7393ee67a4	/	248215199744	173794099200	\N	2026-01-07 01:25:42.537564+00	System	73.3	ext4
3537d61f-4ba9-449d-90f9-42f2c023c822	/home/inno/compose_ARCHIVED_DO_NOT_USE/backups	195762728960	24133632	\N	2026-01-07 01:25:42.542018+00	Backups	0	ext4
19286185-26f5-464d-940d-dd7904de6db5	/home/inno/compose_ARCHIVED_DO_NOT_USE/volumes/media	3936818806784	12288	\N	2026-01-07 01:25:42.544215+00	Media	0	ext4
fe9c7731-2e22-4d58-ae2d-30c63fa8c32c	/	248215199744	173779394560	\N	2026-01-07 04:20:42.702654+00	System	73.3	ext4
1dc833f7-fc25-4f78-8717-238258843314	/home/inno/compose_ARCHIVED_DO_NOT_USE/backups	195762728960	24133632	\N	2026-01-07 04:20:42.704686+00	Backups	0	ext4
2d9ff6fb-7352-4c83-b1d5-cbc3cd85f12a	/home/inno/compose_ARCHIVED_DO_NOT_USE/volumes/media	3936818806784	12288	\N	2026-01-07 04:20:42.705637+00	Media	0	ext4
1b4c152d-d103-49b7-814e-893a102c40f7	/	248215199744	173905387520	\N	2026-01-07 07:15:42.879622+00	System	73.4	ext4
68f0d96c-439f-4b27-9c34-e97eb2b533ec	/home/inno/compose_ARCHIVED_DO_NOT_USE/backups	195762728960	24133632	\N	2026-01-07 07:15:42.882943+00	Backups	0	ext4
8a956a8e-cb6e-4b4f-881d-fbfbfccbb8e6	/home/inno/compose_ARCHIVED_DO_NOT_USE/volumes/media	3936818806784	12288	\N	2026-01-07 07:15:42.884158+00	Media	0	ext4
996889bf-9f22-451b-b869-f3a234d70f53	/	248215199744	189408579584	\N	2026-01-07 10:07:12.412826+00	System	79.9	ext4
5b9c8f93-5a39-4da5-8421-e3c41c8b93f6	/home/inno/compose_ARCHIVED_DO_NOT_USE/backups	195762728960	24133632	\N	2026-01-07 10:07:12.414875+00	Backups	0	ext4
f2cab641-d499-4948-bdf6-aea2a900a962	/home/inno/compose_ARCHIVED_DO_NOT_USE/volumes/media	3936818806784	12288	\N	2026-01-07 10:07:12.41652+00	Media	0	ext4
71bc5ab4-95ec-4555-902e-89ea84eba7f9	/	248215199744	155460718592	\N	2026-01-06 16:45:41.209859+00	System	65.6	ext4
ba1f9e9c-58d2-4ebb-bcb8-ada77fa92bdb	/home/inno/compose_ARCHIVED_DO_NOT_USE/backups	195762728960	24133632	\N	2026-01-06 16:45:41.212136+00	Backups	0	ext4
c2188ebd-bc23-4cd1-a3a8-d969bf5442ff	/home/inno/compose_ARCHIVED_DO_NOT_USE/volumes/media	3936818806784	12288	\N	2026-01-06 16:45:41.213215+00	Media	0	ext4
86cb8c29-275d-4693-80f7-c216b7f5a1e7	/	248215199744	168309055488	\N	2026-01-06 19:40:41.764116+00	System	71	ext4
1dbeb0ec-069d-419a-b5d8-2995370f5929	/home/inno/compose_ARCHIVED_DO_NOT_USE/backups	195762728960	24133632	\N	2026-01-06 19:40:41.770975+00	Backups	0	ext4
fc61193b-45bb-46c5-bfc9-48439c0b35f9	/home/inno/compose_ARCHIVED_DO_NOT_USE/volumes/media	3936818806784	12288	\N	2026-01-06 19:40:41.773047+00	Media	0	ext4
91da379e-5559-4543-9132-a293678f1a15	/	248215199744	173793640448	\N	2026-01-06 22:35:42.220226+00	System	73.3	ext4
5208a27a-0134-4d39-8fcf-73c660172f36	/home/inno/compose_ARCHIVED_DO_NOT_USE/backups	195762728960	24133632	\N	2026-01-06 22:35:42.222176+00	Backups	0	ext4
8a063bd9-b2f1-4082-a5ed-9cdc4780e48e	/home/inno/compose_ARCHIVED_DO_NOT_USE/volumes/media	3936818806784	12288	\N	2026-01-06 22:35:42.22313+00	Media	0	ext4
fccd159e-6fb8-427d-96d9-1bd65c9ed7db	/	248215199744	173795840000	\N	2026-01-07 01:30:42.556026+00	System	73.3	ext4
c8a610c0-3f8a-48cf-a03e-90aa8b0f0e53	/home/inno/compose_ARCHIVED_DO_NOT_USE/backups	195762728960	24133632	\N	2026-01-07 01:30:42.558112+00	Backups	0	ext4
547be59b-355c-4fdc-9193-3b999d702d25	/home/inno/compose_ARCHIVED_DO_NOT_USE/volumes/media	3936818806784	12288	\N	2026-01-07 01:30:42.560622+00	Media	0	ext4
16407aec-d259-4322-9d81-a699810c5dac	/	248215199744	173781045248	\N	2026-01-07 04:25:42.721712+00	System	73.3	ext4
852f124e-a6be-414b-81e3-012f2970ad8a	/home/inno/compose_ARCHIVED_DO_NOT_USE/backups	195762728960	24133632	\N	2026-01-07 04:25:42.723785+00	Backups	0	ext4
3eac5fdf-f20d-4481-a50a-0a2f2439289a	/home/inno/compose_ARCHIVED_DO_NOT_USE/volumes/media	3936818806784	12288	\N	2026-01-07 04:25:42.72478+00	Media	0	ext4
b24f045e-d30f-43d6-bc70-1f59b2b6c205	/	248215199744	173911056384	\N	2026-01-07 07:20:42.882059+00	System	73.4	ext4
b65583d5-99e5-4d75-8c3b-20a773e10758	/home/inno/compose_ARCHIVED_DO_NOT_USE/backups	195762728960	24133632	\N	2026-01-07 07:20:42.88807+00	Backups	0	ext4
4daeb2bc-8a1e-4860-9da2-570d481701ff	/home/inno/compose_ARCHIVED_DO_NOT_USE/volumes/media	3936818806784	12288	\N	2026-01-07 07:20:42.889782+00	Media	0	ext4
29cce616-91eb-4cb0-b1a7-1e1c439cdfd3	/	248215199744	189451739136	\N	2026-01-07 10:12:12.42769+00	System	79.9	ext4
9030d820-14a0-482e-b489-555dc8adc69d	/home/inno/compose_ARCHIVED_DO_NOT_USE/backups	195762728960	24133632	\N	2026-01-07 10:12:12.429661+00	Backups	0	ext4
b2279e9f-1a44-464a-9e8e-fd141086627e	/home/inno/compose_ARCHIVED_DO_NOT_USE/volumes/media	3936818806784	12288	\N	2026-01-07 10:12:12.430577+00	Media	0	ext4
3f2a49c8-0d86-4614-aa32-93f6dbdba7f1	/	248215199744	155525128192	\N	2026-01-06 16:50:41.217657+00	System	65.6	ext4
b4dd11ac-1c9e-47bd-839c-4e8229427d41	/home/inno/compose_ARCHIVED_DO_NOT_USE/backups	195762728960	24133632	\N	2026-01-06 16:50:41.220053+00	Backups	0	ext4
300f7b57-d78f-44fb-bce5-4d78a0e35ce7	/home/inno/compose_ARCHIVED_DO_NOT_USE/volumes/media	3936818806784	12288	\N	2026-01-06 16:50:41.221672+00	Media	0	ext4
215a2db5-b30d-4e04-899e-0fec889a251d	/	248215199744	168677711872	\N	2026-01-06 19:45:41.764995+00	System	71.2	ext4
c2dc96ee-3d7a-4fdd-86ca-ab40d4e3ad01	/home/inno/compose_ARCHIVED_DO_NOT_USE/backups	195762728960	24133632	\N	2026-01-06 19:45:41.771154+00	Backups	0	ext4
e19a5434-36f6-4fd5-b145-47bf06adc9f5	/home/inno/compose_ARCHIVED_DO_NOT_USE/volumes/media	3936818806784	12288	\N	2026-01-06 19:45:41.772639+00	Media	0	ext4
36e18502-bb21-49c4-a4f2-d1ed28384f08	/	248215199744	173793665024	\N	2026-01-06 22:40:42.231836+00	System	73.3	ext4
88e77731-9469-4dcb-aff0-5e2414c1bb9e	/home/inno/compose_ARCHIVED_DO_NOT_USE/backups	195762728960	24133632	\N	2026-01-06 22:40:42.234126+00	Backups	0	ext4
2d38b92f-eee8-41bd-a21c-85214379702d	/home/inno/compose_ARCHIVED_DO_NOT_USE/volumes/media	3936818806784	12288	\N	2026-01-06 22:40:42.235098+00	Media	0	ext4
60cc004f-ed8d-4fb2-a167-01fca9a524a5	/	248215199744	173795868672	\N	2026-01-07 01:35:42.557499+00	System	73.3	ext4
b6eda01e-4188-42ff-80e9-eae74f141ae0	/home/inno/compose_ARCHIVED_DO_NOT_USE/backups	195762728960	24133632	\N	2026-01-07 01:35:42.559905+00	Backups	0	ext4
06cd1156-1ee3-416d-9d5d-e4e691947913	/home/inno/compose_ARCHIVED_DO_NOT_USE/volumes/media	3936818806784	12288	\N	2026-01-07 01:35:42.560947+00	Media	0	ext4
9a6b9b7f-1858-49df-be35-9fbdd79c875a	/	248215199744	173784092672	\N	2026-01-07 04:30:42.727992+00	System	73.3	ext4
4d66fc08-293b-4b4d-bdf0-cca73c1337ec	/home/inno/compose_ARCHIVED_DO_NOT_USE/backups	195762728960	24133632	\N	2026-01-07 04:30:42.730054+00	Backups	0	ext4
87eae783-8c53-4db3-aeee-6e4064df1662	/home/inno/compose_ARCHIVED_DO_NOT_USE/volumes/media	3936818806784	12288	\N	2026-01-07 04:30:42.732522+00	Media	0	ext4
343457b5-9e1f-4c3d-9511-5cd637eb16c4	/	248215199744	173906702336	\N	2026-01-07 07:25:42.886239+00	System	73.4	ext4
bebf6b82-8d70-4a05-a48a-92963d0259ef	/home/inno/compose_ARCHIVED_DO_NOT_USE/backups	195762728960	24133632	\N	2026-01-07 07:25:42.892137+00	Backups	0	ext4
2f8bc117-5747-4b94-b91f-55eb0f99da8f	/home/inno/compose_ARCHIVED_DO_NOT_USE/volumes/media	3936818806784	12288	\N	2026-01-07 07:25:42.894047+00	Media	0	ext4
818e20f6-76ef-405a-9ae1-b8e909d6d879	/	248215199744	189475287040	\N	2026-01-07 10:17:12.457624+00	System	80	ext4
023a4934-cb88-42c5-a27a-385564d3d51c	/home/inno/compose_ARCHIVED_DO_NOT_USE/backups	195762728960	24133632	\N	2026-01-07 10:17:12.461599+00	Backups	0	ext4
c5923fc2-05c3-4d6f-a4f2-054ca54b5ef8	/home/inno/compose_ARCHIVED_DO_NOT_USE/volumes/media	3936818806784	12288	\N	2026-01-07 10:17:12.462588+00	Media	0	ext4
a4ba8d50-2583-4b31-8d07-612054f96592	/	248215199744	155837149184	\N	2026-01-06 16:55:41.234864+00	System	65.8	ext4
79bd5a8f-be3c-400b-b578-95fe2f246a5d	/home/inno/compose_ARCHIVED_DO_NOT_USE/backups	195762728960	24133632	\N	2026-01-06 16:55:41.236788+00	Backups	0	ext4
638660e1-d22d-4b70-a8e5-5af56a3bb9d4	/home/inno/compose_ARCHIVED_DO_NOT_USE/volumes/media	3936818806784	12288	\N	2026-01-06 16:55:41.237752+00	Media	0	ext4
67c8108d-db0d-4987-8119-d0b4781560df	/	248215199744	169061818368	\N	2026-01-06 19:50:41.789355+00	System	71.3	ext4
12ca2520-1317-4b66-8f8b-36717ab9f5dd	/home/inno/compose_ARCHIVED_DO_NOT_USE/backups	195762728960	24133632	\N	2026-01-06 19:50:41.795236+00	Backups	0	ext4
84537562-52a8-4118-add3-8833482798d2	/home/inno/compose_ARCHIVED_DO_NOT_USE/volumes/media	3936818806784	12288	\N	2026-01-06 19:50:41.797055+00	Media	0	ext4
14c50376-8c46-4193-94c6-c16b3c2d590e	/	248215199744	173793689600	\N	2026-01-06 22:45:42.227388+00	System	73.3	ext4
f4dda65a-639e-41d4-b579-12fdcf355ad5	/home/inno/compose_ARCHIVED_DO_NOT_USE/backups	195762728960	24133632	\N	2026-01-06 22:45:42.229715+00	Backups	0	ext4
809cdb57-cb88-49ef-a738-c0bfe8eed9c7	/home/inno/compose_ARCHIVED_DO_NOT_USE/volumes/media	3936818806784	12288	\N	2026-01-06 22:45:42.230675+00	Media	0	ext4
07c0fed3-44e8-428b-9194-45dc53b96da7	/	248215199744	173795872768	\N	2026-01-07 01:40:42.566504+00	System	73.3	ext4
17f2b8d6-bcc5-418c-b6fd-c45141a7ae6d	/home/inno/compose_ARCHIVED_DO_NOT_USE/backups	195762728960	24133632	\N	2026-01-07 01:40:42.569049+00	Backups	0	ext4
94a8600e-540c-4c9f-b36f-2df2455737aa	/home/inno/compose_ARCHIVED_DO_NOT_USE/volumes/media	3936818806784	12288	\N	2026-01-07 01:40:42.570065+00	Media	0	ext4
32c9178a-5613-42c0-a689-2c117b4a304f	/	248215199744	173785722880	\N	2026-01-07 04:35:42.733703+00	System	73.3	ext4
60e3bfcf-c2bc-46b3-8de4-8810d6cb1483	/home/inno/compose_ARCHIVED_DO_NOT_USE/backups	195762728960	24133632	\N	2026-01-07 04:35:42.735699+00	Backups	0	ext4
ed35d281-27c6-4b88-87a0-3fcd1537b378	/home/inno/compose_ARCHIVED_DO_NOT_USE/volumes/media	3936818806784	12288	\N	2026-01-07 04:35:42.73665+00	Media	0	ext4
aeb6d083-90b5-43ff-ae9c-4a3c5aa07324	/	248215199744	173904240640	\N	2026-01-07 07:30:43.095191+00	System	73.4	ext4
e4682013-ac11-429d-add3-1bebf80a5ab5	/home/inno/compose_ARCHIVED_DO_NOT_USE/backups	195762728960	24133632	\N	2026-01-07 07:30:43.097161+00	Backups	0	ext4
e44c5b19-18cd-45b4-a3cf-bd29df3939cb	/home/inno/compose_ARCHIVED_DO_NOT_USE/volumes/media	3936818806784	12288	\N	2026-01-07 07:30:43.098072+00	Media	0	ext4
417562f2-b385-47fb-8ce5-45562b4ae295	/	248215199744	189512560640	\N	2026-01-07 10:22:12.458945+00	System	80	ext4
1d26ef5a-0048-4df8-9880-d8e3b38bd07a	/home/inno/compose_ARCHIVED_DO_NOT_USE/backups	195762728960	24133632	\N	2026-01-07 10:22:12.46086+00	Backups	0	ext4
27d46030-b40f-456b-875d-d232532eea80	/home/inno/compose_ARCHIVED_DO_NOT_USE/volumes/media	3936818806784	12288	\N	2026-01-07 10:22:12.461786+00	Media	0	ext4
46a3b84f-e147-4dc4-971a-bf307066eda7	/	248215199744	156218077184	\N	2026-01-06 17:00:41.255773+00	System	65.9	ext4
f0cfdf51-a222-4851-b1af-67bd50e1aef3	/home/inno/compose_ARCHIVED_DO_NOT_USE/backups	195762728960	24133632	\N	2026-01-06 17:00:41.258529+00	Backups	0	ext4
b89b0820-6765-4ed2-8ec0-495735495848	/home/inno/compose_ARCHIVED_DO_NOT_USE/volumes/media	3936818806784	12288	\N	2026-01-06 17:00:41.260321+00	Media	0	ext4
92092f22-f739-475a-a9eb-d7b91450158d	/	248215199744	169435172864	\N	2026-01-06 19:55:41.774308+00	System	71.5	ext4
3ce0df74-85f2-49de-9fd9-cf4c8f61789c	/home/inno/compose_ARCHIVED_DO_NOT_USE/backups	195762728960	24133632	\N	2026-01-06 19:55:41.776215+00	Backups	0	ext4
e7d3690d-c9f9-4f30-b62d-6614bd81b539	/home/inno/compose_ARCHIVED_DO_NOT_USE/volumes/media	3936818806784	12288	\N	2026-01-06 19:55:41.777098+00	Media	0	ext4
33712366-d56b-414f-a40b-8d7c1f62f989	/	248215199744	173793705984	\N	2026-01-06 22:50:42.25721+00	System	73.3	ext4
770d4fd9-442f-42ba-9676-96b285175303	/home/inno/compose_ARCHIVED_DO_NOT_USE/backups	195762728960	24133632	\N	2026-01-06 22:50:42.259526+00	Backups	0	ext4
babe13cd-515d-45bf-849d-772deee57a0a	/home/inno/compose_ARCHIVED_DO_NOT_USE/volumes/media	3936818806784	12288	\N	2026-01-06 22:50:42.260545+00	Media	0	ext4
c52b6f78-64de-4ce9-adfb-336d9f73ddd1	/	248215199744	173795885056	\N	2026-01-07 01:45:42.551211+00	System	73.3	ext4
dabc9d6c-51c7-4dc8-b408-4dc7049762f8	/home/inno/compose_ARCHIVED_DO_NOT_USE/backups	195762728960	24133632	\N	2026-01-07 01:45:42.553159+00	Backups	0	ext4
680f68c1-51f0-4a23-bf9a-9222256fa7cb	/home/inno/compose_ARCHIVED_DO_NOT_USE/volumes/media	3936818806784	12288	\N	2026-01-07 01:45:42.554132+00	Media	0	ext4
86920bef-3d3c-4d80-8a1e-3cc4861165b6	/	248215199744	173777473536	\N	2026-01-07 04:40:42.728695+00	System	73.3	ext4
5e28e0d1-81e0-45bb-9d29-7ef062faf71c	/home/inno/compose_ARCHIVED_DO_NOT_USE/backups	195762728960	24133632	\N	2026-01-07 04:40:42.730569+00	Backups	0	ext4
51fca7cc-c3cd-4d88-a213-efb37e6e316c	/home/inno/compose_ARCHIVED_DO_NOT_USE/volumes/media	3936818806784	12288	\N	2026-01-07 04:40:42.733023+00	Media	0	ext4
07664eb8-2563-4f87-9d4e-512691b5607d	/	248215199744	173911769088	\N	2026-01-07 07:35:42.892218+00	System	73.4	ext4
ab7220ca-c373-49dc-8059-3dec5fe8d569	/home/inno/compose_ARCHIVED_DO_NOT_USE/backups	195762728960	24133632	\N	2026-01-07 07:35:42.899992+00	Backups	0	ext4
90bfdb28-6655-4e13-bd39-1b28740a6b1c	/home/inno/compose_ARCHIVED_DO_NOT_USE/volumes/media	3936818806784	12288	\N	2026-01-07 07:35:42.901886+00	Media	0	ext4
327f2e55-0cad-42d1-979e-84df3dab5db8	/	248215199744	189532889088	\N	2026-01-07 10:27:12.488614+00	System	80	ext4
fee08db1-1173-461f-9856-a9e8c51046d7	/home/inno/compose_ARCHIVED_DO_NOT_USE/backups	195762728960	24133632	\N	2026-01-07 10:27:12.491428+00	Backups	0	ext4
9f2a4069-bd0c-46bc-9714-00ad41a9f706	/home/inno/compose_ARCHIVED_DO_NOT_USE/volumes/media	3936818806784	12288	\N	2026-01-07 10:27:12.493429+00	Media	0	ext4
e04f0f13-2b5f-4e37-9bc0-50fb93f24c41	/	248215199744	156597899264	\N	2026-01-06 17:05:41.241439+00	System	66.1	ext4
b0322866-5904-498d-a482-dfbcde38b702	/home/inno/compose_ARCHIVED_DO_NOT_USE/backups	195762728960	24133632	\N	2026-01-06 17:05:41.243121+00	Backups	0	ext4
015abccc-3ed9-48c3-9de3-4704b7823c4c	/home/inno/compose_ARCHIVED_DO_NOT_USE/volumes/media	3936818806784	12288	\N	2026-01-06 17:05:41.245254+00	Media	0	ext4
0f87a174-0331-4d85-8696-668043cc2bc1	/	248215199744	169816932352	\N	2026-01-06 20:00:41.826897+00	System	71.7	ext4
4de5ae9e-7a9f-4217-8487-3a99dcb59b3e	/home/inno/compose_ARCHIVED_DO_NOT_USE/backups	195762728960	24133632	\N	2026-01-06 20:00:41.833166+00	Backups	0	ext4
a9720b68-dd1f-4623-8fe6-f5a577e27f29	/home/inno/compose_ARCHIVED_DO_NOT_USE/volumes/media	3936818806784	12288	\N	2026-01-06 20:00:41.83689+00	Media	0	ext4
5bb9eae6-5b0c-4121-8f2a-75535d7356e9	/	248215199744	173793714176	\N	2026-01-06 22:55:42.344042+00	System	73.3	ext4
83e42d3c-a261-47f6-9a13-cf58d11b3aa9	/home/inno/compose_ARCHIVED_DO_NOT_USE/backups	195762728960	24133632	\N	2026-01-06 22:55:42.346263+00	Backups	0	ext4
4eea745a-d288-42e9-94d1-8e05e5e020a2	/home/inno/compose_ARCHIVED_DO_NOT_USE/volumes/media	3936818806784	12288	\N	2026-01-06 22:55:42.347204+00	Media	0	ext4
0d7c0956-9961-4df0-9ad7-80f0e5d36839	/	248215199744	173795901440	\N	2026-01-07 01:50:42.588366+00	System	73.3	ext4
24eecdd7-23fa-44a3-9d2f-5229663ccc16	/home/inno/compose_ARCHIVED_DO_NOT_USE/backups	195762728960	24133632	\N	2026-01-07 01:50:42.590706+00	Backups	0	ext4
81ee401f-65aa-4b8c-aa47-fad58a7fff6f	/home/inno/compose_ARCHIVED_DO_NOT_USE/volumes/media	3936818806784	12288	\N	2026-01-07 01:50:42.591743+00	Media	0	ext4
ee7c60d7-f4b6-4d72-90ff-cac1305dc39c	/	248215199744	173780533248	\N	2026-01-07 04:45:42.734449+00	System	73.3	ext4
9d51b240-5de9-437a-83fc-05d1a1e80ea0	/home/inno/compose_ARCHIVED_DO_NOT_USE/backups	195762728960	24133632	\N	2026-01-07 04:45:42.736499+00	Backups	0	ext4
69824283-4911-4d80-8add-fe0beee95e00	/home/inno/compose_ARCHIVED_DO_NOT_USE/volumes/media	3936818806784	12288	\N	2026-01-07 04:45:42.737455+00	Media	0	ext4
cfa84faf-dde1-4944-8e9d-a06118696800	/	248215199744	173904007168	\N	2026-01-07 07:40:42.897259+00	System	73.4	ext4
58d262d7-a5cc-45e6-8f4d-5697bfdfee8d	/home/inno/compose_ARCHIVED_DO_NOT_USE/backups	195762728960	24133632	\N	2026-01-07 07:40:42.901589+00	Backups	0	ext4
cade866c-92df-4331-af5a-99018525fd44	/home/inno/compose_ARCHIVED_DO_NOT_USE/volumes/media	3936818806784	12288	\N	2026-01-07 07:40:42.902958+00	Media	0	ext4
c3ae8861-ea19-4f3e-84d0-6850d2d99cb8	/	248215199744	189536497664	\N	2026-01-07 10:32:12.63239+00	System	80	ext4
ffd87400-69b1-4ee1-a126-87ba040a1604	/home/inno/compose_ARCHIVED_DO_NOT_USE/backups	195762728960	24133632	\N	2026-01-07 10:32:12.63497+00	Backups	0	ext4
ee37a795-e4bb-4605-a5d5-e295b47daef9	/home/inno/compose_ARCHIVED_DO_NOT_USE/volumes/media	3936818806784	12288	\N	2026-01-07 10:32:12.636075+00	Media	0	ext4
78a89a3e-829e-4d0c-a6eb-c65176d557bc	/	248215199744	156980547584	\N	2026-01-06 17:10:41.270188+00	System	66.2	ext4
41e752cc-45bf-4536-baac-758cfbb01d95	/home/inno/compose_ARCHIVED_DO_NOT_USE/backups	195762728960	24133632	\N	2026-01-06 17:10:41.273627+00	Backups	0	ext4
b6c0913c-751e-4159-aba3-1a940c12dac5	/home/inno/compose_ARCHIVED_DO_NOT_USE/volumes/media	3936818806784	12288	\N	2026-01-06 17:10:41.274948+00	Media	0	ext4
e33c7ef1-d590-47cf-82c9-e08284ac7daa	/	248215199744	170191192064	\N	2026-01-06 20:05:41.790541+00	System	71.8	ext4
86ed9b49-f9ce-4e56-b4c5-9f8408fdd5d2	/home/inno/compose_ARCHIVED_DO_NOT_USE/backups	195762728960	24133632	\N	2026-01-06 20:05:41.793058+00	Backups	0	ext4
ac01a9ce-812e-4417-a630-4e9f0e07918a	/home/inno/compose_ARCHIVED_DO_NOT_USE/volumes/media	3936818806784	12288	\N	2026-01-06 20:05:41.795049+00	Media	0	ext4
59407013-7e06-4c69-b97c-a6daa20c7ade	/	248215199744	173793734656	\N	2026-01-06 23:00:42.38515+00	System	73.3	ext4
8649a747-e2dd-4fe4-bea9-8b0a58399e14	/home/inno/compose_ARCHIVED_DO_NOT_USE/backups	195762728960	24133632	\N	2026-01-06 23:00:42.388045+00	Backups	0	ext4
3f0d770d-f351-4971-b7c3-8eacd6aa8632	/home/inno/compose_ARCHIVED_DO_NOT_USE/volumes/media	3936818806784	12288	\N	2026-01-06 23:00:42.389189+00	Media	0	ext4
a89dde7a-d237-4ca3-96f5-4b3877a409ba	/	248215199744	173795913728	\N	2026-01-07 01:55:42.595755+00	System	73.3	ext4
cfafc2fd-b2fd-4d7b-b42a-80f966d47716	/home/inno/compose_ARCHIVED_DO_NOT_USE/backups	195762728960	24133632	\N	2026-01-07 01:55:42.598093+00	Backups	0	ext4
2707c1c4-22ef-437a-a243-9ff08361b8bb	/home/inno/compose_ARCHIVED_DO_NOT_USE/volumes/media	3936818806784	12288	\N	2026-01-07 01:55:42.599106+00	Media	0	ext4
2c375ca0-4f8c-4ff5-9889-022d8da59ead	/	248215199744	173781934080	\N	2026-01-07 04:50:42.741954+00	System	73.3	ext4
f5d9d0fd-c77c-4a46-913d-56c6ca40ab58	/home/inno/compose_ARCHIVED_DO_NOT_USE/backups	195762728960	24133632	\N	2026-01-07 04:50:42.745957+00	Backups	0	ext4
2adda40e-cf53-4263-b774-4e6bafee782d	/home/inno/compose_ARCHIVED_DO_NOT_USE/volumes/media	3936818806784	12288	\N	2026-01-07 04:50:42.747748+00	Media	0	ext4
b0306071-2d7c-48c9-b48c-9f9f085495aa	/	248215199744	173911486464	\N	2026-01-07 07:45:43.025168+00	System	73.4	ext4
358cd9be-f378-4ede-be47-aa2c202cd3b1	/home/inno/compose_ARCHIVED_DO_NOT_USE/backups	195762728960	24133632	\N	2026-01-07 07:45:43.027086+00	Backups	0	ext4
58bcfb54-de02-4fc9-bfcf-8b161a1bde0f	/home/inno/compose_ARCHIVED_DO_NOT_USE/volumes/media	3936818806784	12288	\N	2026-01-07 07:45:43.027957+00	Media	0	ext4
95b141a3-2de5-44ca-a010-d4f4ca8c12a1	/	248215199744	189536604160	\N	2026-01-07 10:37:12.48311+00	System	80	ext4
9e4d6f64-8822-4667-bb7a-550e43724bb9	/home/inno/compose_ARCHIVED_DO_NOT_USE/backups	195762728960	24133632	\N	2026-01-07 10:37:12.484305+00	Backups	0	ext4
34e2587a-d77f-4827-8f9b-9d0ee6f45e56	/home/inno/compose_ARCHIVED_DO_NOT_USE/volumes/media	3936818806784	12288	\N	2026-01-07 10:37:12.485226+00	Media	0	ext4
dcca0189-3afb-49e2-b1d0-9bce1bc3d04c	/	248215199744	157353156608	\N	2026-01-06 17:15:41.287658+00	System	66.4	ext4
d067041b-46a3-4bf0-b176-bf284ac22479	/home/inno/compose_ARCHIVED_DO_NOT_USE/backups	195762728960	24133632	\N	2026-01-06 17:15:41.291308+00	Backups	0	ext4
12979cf0-7c86-4c13-b9e9-e9abeda31d29	/home/inno/compose_ARCHIVED_DO_NOT_USE/volumes/media	3936818806784	12288	\N	2026-01-06 17:15:41.292396+00	Media	0	ext4
4ebb2627-e115-4265-ad5d-497251c1af6d	/	248215199744	170575237120	\N	2026-01-06 20:10:41.838919+00	System	72	ext4
59f58d66-a9f7-4206-87f8-5a3ce015dd35	/home/inno/compose_ARCHIVED_DO_NOT_USE/backups	195762728960	24133632	\N	2026-01-06 20:10:41.849119+00	Backups	0	ext4
3f5e05a3-60a7-4049-b77f-48376d90683b	/home/inno/compose_ARCHIVED_DO_NOT_USE/volumes/media	3936818806784	12288	\N	2026-01-06 20:10:41.851454+00	Media	0	ext4
2804c8ae-6cec-44c8-9229-b1bd424769de	/	248215199744	173793742848	\N	2026-01-06 23:05:42.25994+00	System	73.3	ext4
d5b13fa5-9412-4484-88eb-a9a47e77951f	/home/inno/compose_ARCHIVED_DO_NOT_USE/backups	195762728960	24133632	\N	2026-01-06 23:05:42.261212+00	Backups	0	ext4
18f5f5f7-888b-40fd-b2b2-d16bd9b3775a	/home/inno/compose_ARCHIVED_DO_NOT_USE/volumes/media	3936818806784	12288	\N	2026-01-06 23:05:42.262199+00	Media	0	ext4
609d24ec-d4fa-4948-a354-2cd03b003ecd	/	248215199744	173769089024	\N	2026-01-07 02:00:42.498473+00	System	73.3	ext4
a05da1ed-8530-4728-80fc-b9ac08796e59	/home/inno/compose_ARCHIVED_DO_NOT_USE/backups	195762728960	24133632	\N	2026-01-07 02:00:42.500351+00	Backups	0	ext4
6fa482ff-2041-4fe7-9bc7-872a8cde53eb	/home/inno/compose_ARCHIVED_DO_NOT_USE/volumes/media	3936818806784	12288	\N	2026-01-07 02:00:42.501276+00	Media	0	ext4
1b663624-a781-43e2-bb4b-5424278fa626	/	248215199744	173784887296	\N	2026-01-07 04:55:42.748783+00	System	73.3	ext4
642449d0-08af-4cc5-bcd9-87f4eaea1040	/home/inno/compose_ARCHIVED_DO_NOT_USE/backups	195762728960	24133632	\N	2026-01-07 04:55:42.750806+00	Backups	0	ext4
cd8c2166-f276-46a7-8baa-5ffb549354e9	/home/inno/compose_ARCHIVED_DO_NOT_USE/volumes/media	3936818806784	12288	\N	2026-01-07 04:55:42.75175+00	Media	0	ext4
89c42206-ae20-4fe5-9ca5-4047f48a3e27	/	248215199744	173906513920	\N	2026-01-07 07:50:43.027482+00	System	73.4	ext4
5f28dae6-8f1c-4a9b-a43c-a3d653907a89	/home/inno/compose_ARCHIVED_DO_NOT_USE/backups	195762728960	24133632	\N	2026-01-07 07:50:43.029724+00	Backups	0	ext4
344a8074-9f24-4fa9-9560-15602693f016	/home/inno/compose_ARCHIVED_DO_NOT_USE/volumes/media	3936818806784	12288	\N	2026-01-07 07:50:43.030682+00	Media	0	ext4
9125c2b6-dffa-46e7-a1c4-0115e5fa88bc	/	248215199744	189536747520	\N	2026-01-07 10:42:12.513577+00	System	80	ext4
b75518a3-1255-4ffa-a649-2a31e9dac21b	/home/inno/compose_ARCHIVED_DO_NOT_USE/backups	195762728960	24133632	\N	2026-01-07 10:42:12.515761+00	Backups	0	ext4
58e32842-4276-4cc0-a048-73959ea13f80	/home/inno/compose_ARCHIVED_DO_NOT_USE/volumes/media	3936818806784	12288	\N	2026-01-07 10:42:12.51676+00	Media	0	ext4
2c03210e-ea65-4569-8fb7-0b341326e0dc	/	248215199744	157734608896	\N	2026-01-06 17:20:41.307721+00	System	66.6	ext4
e37ef9be-7e82-4a15-93a9-f49a6926624b	/home/inno/compose_ARCHIVED_DO_NOT_USE/backups	195762728960	24133632	\N	2026-01-06 17:20:41.310199+00	Backups	0	ext4
52f9ecf3-f059-4cae-b88d-d9f73ff9d7b4	/home/inno/compose_ARCHIVED_DO_NOT_USE/volumes/media	3936818806784	12288	\N	2026-01-06 17:20:41.312979+00	Media	0	ext4
7414be4a-21a9-4402-9679-3cb4cefb6945	/	248215199744	170946252800	\N	2026-01-06 20:15:41.882339+00	System	72.1	ext4
5838e056-8332-4df5-8a78-1dcee0aeb8a8	/home/inno/compose_ARCHIVED_DO_NOT_USE/backups	195762728960	24133632	\N	2026-01-06 20:15:41.886234+00	Backups	0	ext4
bfa64fb8-3bf3-4600-ade3-4692bbeb90fc	/home/inno/compose_ARCHIVED_DO_NOT_USE/volumes/media	3936818806784	12288	\N	2026-01-06 20:15:41.890191+00	Media	0	ext4
58bba805-9650-48b1-955c-a9eb95ff65b0	/	248215199744	173793763328	\N	2026-01-06 23:10:42.277457+00	System	73.3	ext4
237dbabb-7ed1-4365-ab25-d07dc7f77126	/home/inno/compose_ARCHIVED_DO_NOT_USE/backups	195762728960	24133632	\N	2026-01-06 23:10:42.27957+00	Backups	0	ext4
dd78ef95-456d-41fb-b85f-140e46224389	/home/inno/compose_ARCHIVED_DO_NOT_USE/volumes/media	3936818806784	12288	\N	2026-01-06 23:10:42.280539+00	Media	0	ext4
243e3f4e-d7c6-4f50-b1ad-134f900ec1f3	/	248215199744	173772369920	\N	2026-01-07 02:05:42.486079+00	System	73.3	ext4
91e561b1-807c-4459-95ad-1766b5160928	/home/inno/compose_ARCHIVED_DO_NOT_USE/backups	195762728960	24133632	\N	2026-01-07 02:05:42.488621+00	Backups	0	ext4
a3daf9e3-ced0-4635-8f66-5eda2008859a	/home/inno/compose_ARCHIVED_DO_NOT_USE/volumes/media	3936818806784	12288	\N	2026-01-07 02:05:42.490545+00	Media	0	ext4
ae48a5d6-da6e-45ad-ace1-f6b209e553f8	/	248215199744	173768884224	\N	2026-01-07 05:00:42.767813+00	System	73.3	ext4
5d7b2857-de55-4a36-9c95-ac5673ff9f94	/home/inno/compose_ARCHIVED_DO_NOT_USE/backups	195762728960	24133632	\N	2026-01-07 05:00:42.773918+00	Backups	0	ext4
c7dc2b9c-1a6e-4088-8817-f3fd63a82c08	/home/inno/compose_ARCHIVED_DO_NOT_USE/volumes/media	3936818806784	12288	\N	2026-01-07 05:00:42.775554+00	Media	0	ext4
54cbbb81-a401-47d0-93b6-ae19d628cc31	/	248215199744	173913989120	\N	2026-01-07 07:55:43.022398+00	System	73.4	ext4
aeea804f-afb9-4d34-9d6f-546558489553	/home/inno/compose_ARCHIVED_DO_NOT_USE/backups	195762728960	24133632	\N	2026-01-07 07:55:43.024322+00	Backups	0	ext4
110bb6c0-d845-46ea-a2e1-1229e14ad65a	/home/inno/compose_ARCHIVED_DO_NOT_USE/volumes/media	3936818806784	12288	\N	2026-01-07 07:55:43.025218+00	Media	0	ext4
dd47ff8c-32d8-4e1b-aaa6-aa477a72474e	/	248215199744	189596225536	\N	2026-01-07 10:47:12.647056+00	System	80	ext4
0177eb35-1fa4-4bd7-a84a-6652f6d564c7	/home/inno/compose_ARCHIVED_DO_NOT_USE/backups	195762728960	24133632	\N	2026-01-07 10:47:12.64911+00	Backups	0	ext4
c8c74974-87ac-4229-8c0d-d29952ff9b5d	/home/inno/compose_ARCHIVED_DO_NOT_USE/volumes/media	3936818806784	12288	\N	2026-01-07 10:47:12.650082+00	Media	0	ext4
70673326-701c-499b-96c5-f399e83d245e	/	248215199744	158108794880	\N	2026-01-06 17:25:41.341395+00	System	66.7	ext4
18e791a6-7a46-486b-9cca-d1c929125e3a	/home/inno/compose_ARCHIVED_DO_NOT_USE/backups	195762728960	24133632	\N	2026-01-06 17:25:41.343388+00	Backups	0	ext4
b4cb46fe-6a84-41da-9c9b-ecaa74b90205	/home/inno/compose_ARCHIVED_DO_NOT_USE/volumes/media	3936818806784	12288	\N	2026-01-06 17:25:41.344453+00	Media	0	ext4
1d1cee10-487b-4955-9ebf-62ea1903d4b3	/	248215199744	171327594496	\N	2026-01-06 20:20:41.83802+00	System	72.3	ext4
64f1bb88-f531-4f68-89d4-0307d90db8c3	/home/inno/compose_ARCHIVED_DO_NOT_USE/backups	195762728960	24133632	\N	2026-01-06 20:20:41.840622+00	Backups	0	ext4
7549759c-b6fe-4251-9e55-e17f537b1263	/home/inno/compose_ARCHIVED_DO_NOT_USE/volumes/media	3936818806784	12288	\N	2026-01-06 20:20:41.841681+00	Media	0	ext4
bb943edd-7b2f-4992-be11-a4e7af2b7d17	/	248215199744	173793775616	\N	2026-01-06 23:15:42.30675+00	System	73.3	ext4
aa118daf-41f1-4283-8f74-c3f9025bd037	/home/inno/compose_ARCHIVED_DO_NOT_USE/backups	195762728960	24133632	\N	2026-01-06 23:15:42.30946+00	Backups	0	ext4
9d8a91e4-8897-4ce8-b4e6-2c4dbf35754a	/home/inno/compose_ARCHIVED_DO_NOT_USE/volumes/media	3936818806784	12288	\N	2026-01-06 23:15:42.310526+00	Media	0	ext4
0cb31883-4935-4279-ae75-90fd2b016a83	/	248215199744	173775638528	\N	2026-01-07 02:10:42.522195+00	System	73.3	ext4
d4670fc9-5ec1-452e-9131-7288a9387222	/home/inno/compose_ARCHIVED_DO_NOT_USE/backups	195762728960	24133632	\N	2026-01-07 02:10:42.524183+00	Backups	0	ext4
b3e9e7a7-f700-47a0-85a8-857f45387e7b	/home/inno/compose_ARCHIVED_DO_NOT_USE/volumes/media	3936818806784	12288	\N	2026-01-07 02:10:42.525156+00	Media	0	ext4
8ef815a0-4a31-40d8-b04a-db0236c23a9c	/	248215199744	173900513280	\N	2026-01-07 05:05:42.848744+00	System	73.4	ext4
53233a08-05a7-4210-8e1c-e348284393fd	/home/inno/compose_ARCHIVED_DO_NOT_USE/backups	195762728960	24133632	\N	2026-01-07 05:05:42.850033+00	Backups	0	ext4
49a2746a-1fe5-466b-a32b-96890daf337a	/home/inno/compose_ARCHIVED_DO_NOT_USE/volumes/media	3936818806784	12288	\N	2026-01-07 05:05:42.851013+00	Media	0	ext4
bc95b75e-f362-4244-b4f4-07b4e7549b39	/	248215199744	173902675968	\N	2026-01-07 08:00:43.049653+00	System	73.4	ext4
e56edf59-115b-432e-9965-f117d792f7ad	/home/inno/compose_ARCHIVED_DO_NOT_USE/backups	195762728960	24133632	\N	2026-01-07 08:00:43.053263+00	Backups	0	ext4
c9b05ab3-6de8-4f95-9873-4927c54cabd0	/home/inno/compose_ARCHIVED_DO_NOT_USE/volumes/media	3936818806784	12288	\N	2026-01-07 08:00:43.054188+00	Media	0	ext4
2d0cc627-76ac-4735-9e41-273520343899	/	248215199744	189645524992	\N	2026-01-07 10:52:12.692194+00	System	80	ext4
eaf873b7-4741-41e5-97f5-f4993f02215d	/home/inno/compose_ARCHIVED_DO_NOT_USE/backups	195762728960	24133632	\N	2026-01-07 10:52:12.694856+00	Backups	0	ext4
5e823290-3ee5-4b9a-a530-8b2d81d19f3e	/home/inno/compose_ARCHIVED_DO_NOT_USE/volumes/media	3936818806784	12288	\N	2026-01-07 10:52:12.696024+00	Media	0	ext4
8570b72b-1777-44a4-969c-e88be2c29923	/	248215199744	158489243648	\N	2026-01-06 17:30:41.352162+00	System	66.9	ext4
78b378e1-af5a-49e6-9d3e-b9ca83191840	/home/inno/compose_ARCHIVED_DO_NOT_USE/backups	195762728960	24133632	\N	2026-01-06 17:30:41.354308+00	Backups	0	ext4
cc8f0696-3e53-4561-83eb-98c1ca65f160	/home/inno/compose_ARCHIVED_DO_NOT_USE/volumes/media	3936818806784	12288	\N	2026-01-06 17:30:41.355443+00	Media	0	ext4
974d80da-822a-494a-9671-9f7bb5b75494	/	248215199744	171697414144	\N	2026-01-06 20:25:41.881128+00	System	72.4	ext4
6bc0d140-20fe-4624-a60a-7de2151f34ca	/home/inno/compose_ARCHIVED_DO_NOT_USE/backups	195762728960	24133632	\N	2026-01-06 20:25:41.88742+00	Backups	0	ext4
cc538352-60e0-42a1-8806-f2b73d992ec3	/home/inno/compose_ARCHIVED_DO_NOT_USE/volumes/media	3936818806784	12288	\N	2026-01-06 20:25:41.890968+00	Media	0	ext4
69e759ce-beca-4d03-8f7a-adf97c63b211	/	248215199744	173793792000	\N	2026-01-06 23:20:42.298159+00	System	73.3	ext4
1e2cca95-d6ec-40e2-92cd-797b85d1804d	/home/inno/compose_ARCHIVED_DO_NOT_USE/backups	195762728960	24133632	\N	2026-01-06 23:20:42.300189+00	Backups	0	ext4
fb3a9ad6-d2fe-47a9-a301-9509b5016769	/home/inno/compose_ARCHIVED_DO_NOT_USE/volumes/media	3936818806784	12288	\N	2026-01-06 23:20:42.301131+00	Media	0	ext4
132d485f-c92e-4aa1-97e5-c780d1593f51	/	248215199744	173778894848	\N	2026-01-07 02:15:42.518261+00	System	73.3	ext4
de8953ab-a7a3-4089-b50a-87ddd31e9dcf	/home/inno/compose_ARCHIVED_DO_NOT_USE/backups	195762728960	24133632	\N	2026-01-07 02:15:42.52021+00	Backups	0	ext4
33442fa3-4bf8-4121-bbd2-2408eccc58b5	/home/inno/compose_ARCHIVED_DO_NOT_USE/volumes/media	3936818806784	12288	\N	2026-01-07 02:15:42.521111+00	Media	0	ext4
f078785e-e4ed-44c3-b90e-f80660def44f	/	248215199744	173896921088	\N	2026-01-07 05:10:42.785562+00	System	73.4	ext4
e38acb21-c899-465c-a9a9-714878139dea	/home/inno/compose_ARCHIVED_DO_NOT_USE/backups	195762728960	24133632	\N	2026-01-07 05:10:42.79033+00	Backups	0	ext4
02a4ee81-782e-41ec-b812-621407518eb6	/home/inno/compose_ARCHIVED_DO_NOT_USE/volumes/media	3936818806784	12288	\N	2026-01-07 05:10:42.791771+00	Media	0	ext4
08534bb0-ae1b-45f3-b6f0-0064eda55ff1	/	248215199744	173903454208	\N	2026-01-07 08:05:42.875512+00	System	73.4	ext4
f314347f-1feb-4e84-9895-491dfd8a6429	/home/inno/compose_ARCHIVED_DO_NOT_USE/backups	195762728960	24133632	\N	2026-01-07 08:05:42.878118+00	Backups	0	ext4
aec07877-0a58-4692-a3ac-d21c0855958c	/home/inno/compose_ARCHIVED_DO_NOT_USE/volumes/media	3936818806784	12288	\N	2026-01-07 08:05:42.880097+00	Media	0	ext4
71dc458f-1e54-4de6-a2dd-cab8330aa41a	/	248215199744	189647298560	\N	2026-01-07 10:57:12.55377+00	System	80	ext4
0292e37c-d23d-4b92-82ff-82a0f9b442a3	/home/inno/compose_ARCHIVED_DO_NOT_USE/backups	195762728960	24133632	\N	2026-01-07 10:57:12.555676+00	Backups	0	ext4
120e1bdc-1fc3-4ecd-ae98-d4e026445e2d	/home/inno/compose_ARCHIVED_DO_NOT_USE/volumes/media	3936818806784	12288	\N	2026-01-07 10:57:12.556592+00	Media	0	ext4
593d3fd9-5c56-413b-a27e-88667e52ba78	/	248215199744	158878928896	\N	2026-01-06 17:35:41.35391+00	System	67	ext4
620beafb-3efb-46a3-8b68-33467b586926	/home/inno/compose_ARCHIVED_DO_NOT_USE/backups	195762728960	24133632	\N	2026-01-06 17:35:41.355888+00	Backups	0	ext4
f8bbae01-9449-4ff7-9d45-7b3ba113c7db	/home/inno/compose_ARCHIVED_DO_NOT_USE/volumes/media	3936818806784	12288	\N	2026-01-06 17:35:41.356779+00	Media	0	ext4
45423eba-18b6-4063-a64e-b0dd04e40919	/	248215199744	172077957120	\N	2026-01-06 20:30:41.889934+00	System	72.6	ext4
285004e0-315e-42f2-82a6-3d0de5ed9892	/home/inno/compose_ARCHIVED_DO_NOT_USE/backups	195762728960	24133632	\N	2026-01-06 20:30:41.89247+00	Backups	0	ext4
0fd5aadf-7e1c-40e8-bcd7-8ee841ff8a2e	/home/inno/compose_ARCHIVED_DO_NOT_USE/volumes/media	3936818806784	12288	\N	2026-01-06 20:30:41.893635+00	Media	0	ext4
ba3f2ade-a186-430f-856a-6d388b7f6515	/	248215199744	173793808384	\N	2026-01-06 23:25:42.319365+00	System	73.3	ext4
bde49ba3-7c75-46d4-86e1-113c692b12ae	/home/inno/compose_ARCHIVED_DO_NOT_USE/backups	195762728960	24133632	\N	2026-01-06 23:25:42.321307+00	Backups	0	ext4
7c8f48c9-afe1-4e7d-a81b-20aae9bc663a	/home/inno/compose_ARCHIVED_DO_NOT_USE/volumes/media	3936818806784	12288	\N	2026-01-06 23:25:42.32215+00	Media	0	ext4
dba8c739-99a9-4791-9383-e40b7324de29	/	248215199744	173772185600	\N	2026-01-07 02:20:42.527805+00	System	73.3	ext4
08320175-bdbb-483e-9bdc-f83deb87b0fe	/home/inno/compose_ARCHIVED_DO_NOT_USE/backups	195762728960	24133632	\N	2026-01-07 02:20:42.529976+00	Backups	0	ext4
0e0c1b63-39c0-4f67-a958-8fa9b996c170	/home/inno/compose_ARCHIVED_DO_NOT_USE/volumes/media	3936818806784	12288	\N	2026-01-07 02:20:42.534648+00	Media	0	ext4
b80e7b6b-ebf1-4692-9710-ce307c59b876	/	248215199744	173903560704	\N	2026-01-07 05:15:42.785315+00	System	73.4	ext4
abc42be0-eb51-42c6-9a46-40a3326ee449	/home/inno/compose_ARCHIVED_DO_NOT_USE/backups	195762728960	24133632	\N	2026-01-07 05:15:42.791493+00	Backups	0	ext4
41e05cb4-4e3b-4912-a2ac-8438dd8c1d56	/home/inno/compose_ARCHIVED_DO_NOT_USE/volumes/media	3936818806784	12288	\N	2026-01-07 05:15:42.793442+00	Media	0	ext4
b2970f40-e538-449e-a599-f292ff6c9ecd	/	248215199744	173904236544	\N	2026-01-07 08:10:42.876832+00	System	73.4	ext4
d76aef54-50d0-4d96-8bbb-106f801d4105	/home/inno/compose_ARCHIVED_DO_NOT_USE/backups	195762728960	24133632	\N	2026-01-07 08:10:42.879005+00	Backups	0	ext4
5878db36-9124-4eec-8b6d-d51d771c36c3	/home/inno/compose_ARCHIVED_DO_NOT_USE/volumes/media	3936818806784	12288	\N	2026-01-07 08:10:42.881527+00	Media	0	ext4
4fbe3aa4-8eaa-4c74-9c61-ca24b5a203f2	/	248215199744	189657120768	\N	2026-01-07 11:02:12.644671+00	System	80	ext4
866f226e-d026-4ca3-b306-72161747596c	/home/inno/compose_ARCHIVED_DO_NOT_USE/backups	195762728960	24133632	\N	2026-01-07 11:02:12.646815+00	Backups	0	ext4
336e374a-7bec-4b39-8859-c262ed727b86	/home/inno/compose_ARCHIVED_DO_NOT_USE/volumes/media	3936818806784	12288	\N	2026-01-07 11:02:12.647806+00	Media	0	ext4
6b72d57f-e660-4b5c-90b6-fae56bc4a11e	/	248215199744	159260151808	\N	2026-01-06 17:40:41.377659+00	System	67.2	ext4
70240315-7db0-4e58-9902-7eaa05a2f859	/home/inno/compose_ARCHIVED_DO_NOT_USE/backups	195762728960	24133632	\N	2026-01-06 17:40:41.384264+00	Backups	0	ext4
624dfe5e-df21-4438-abc5-745f50561c23	/home/inno/compose_ARCHIVED_DO_NOT_USE/volumes/media	3936818806784	12288	\N	2026-01-06 17:40:41.38532+00	Media	0	ext4
d751f652-0e94-47d8-aa3b-d7487ae208e2	/	248215199744	172452724736	\N	2026-01-06 20:35:41.891014+00	System	72.8	ext4
55f5edad-1254-4523-a91c-b1230723649c	/home/inno/compose_ARCHIVED_DO_NOT_USE/backups	195762728960	24133632	\N	2026-01-06 20:35:41.896696+00	Backups	0	ext4
391a977b-1a28-48d7-9f9e-df367e949719	/home/inno/compose_ARCHIVED_DO_NOT_USE/volumes/media	3936818806784	12288	\N	2026-01-06 20:35:41.898003+00	Media	0	ext4
9c611c14-1d01-4578-b776-7c8ceaf585c0	/	248215199744	173793845248	\N	2026-01-06 23:30:42.329165+00	System	73.3	ext4
c8e02ba0-c5fd-4b20-b5e9-70c05478c477	/home/inno/compose_ARCHIVED_DO_NOT_USE/backups	195762728960	24133632	\N	2026-01-06 23:30:42.331648+00	Backups	0	ext4
97cf1149-bf03-4a95-b84d-a8461e967d7d	/home/inno/compose_ARCHIVED_DO_NOT_USE/volumes/media	3936818806784	12288	\N	2026-01-06 23:30:42.332699+00	Media	0	ext4
03ae4f81-b5d9-4aeb-af96-9644e6dbc0b1	/	248215199744	173775032320	\N	2026-01-07 02:25:42.5378+00	System	73.3	ext4
e0800752-b77e-4f3a-871b-65ea6a6a2ccd	/home/inno/compose_ARCHIVED_DO_NOT_USE/backups	195762728960	24133632	\N	2026-01-07 02:25:42.539713+00	Backups	0	ext4
7f39052a-8ed9-465b-a837-031a044efef4	/home/inno/compose_ARCHIVED_DO_NOT_USE/volumes/media	3936818806784	12288	\N	2026-01-07 02:25:42.540591+00	Media	0	ext4
4e986fd5-f308-4601-9046-89a7d53d0e84	/	248215199744	173901070336	\N	2026-01-07 05:20:42.790477+00	System	73.4	ext4
84598f87-0a37-435e-bf83-ad4233500bfa	/home/inno/compose_ARCHIVED_DO_NOT_USE/backups	195762728960	24133632	\N	2026-01-07 05:20:42.797447+00	Backups	0	ext4
ebe4885a-1890-4a2f-a0ad-bbd5179f78c3	/home/inno/compose_ARCHIVED_DO_NOT_USE/volumes/media	3936818806784	12288	\N	2026-01-07 05:20:42.798923+00	Media	0	ext4
4f261b1c-1cbb-47ff-afbc-b42fae71cf19	/	248215199744	173905010688	\N	2026-01-07 08:15:42.910005+00	System	73.4	ext4
15ea4d89-8d05-4dbc-a0c1-c459e8bf702a	/home/inno/compose_ARCHIVED_DO_NOT_USE/backups	195762728960	24133632	\N	2026-01-07 08:15:42.915937+00	Backups	0	ext4
f46e7427-851b-41f8-9741-2cd6b4e2a161	/home/inno/compose_ARCHIVED_DO_NOT_USE/volumes/media	3936818806784	12288	\N	2026-01-07 08:15:42.917807+00	Media	0	ext4
99f038ec-874a-4ded-83e0-489a138c6dab	/	248215199744	202538373120	\N	2026-01-07 11:07:12.643761+00	System	85.5	ext4
f747b6b2-e90c-4850-88e8-cc77ec992a74	/home/inno/compose_ARCHIVED_DO_NOT_USE/backups	195762728960	24133632	\N	2026-01-07 11:07:12.722909+00	Backups	0	ext4
ac1cf834-2904-4686-99b4-9c2587170f0d	/home/inno/compose_ARCHIVED_DO_NOT_USE/volumes/media	3936818806784	12288	\N	2026-01-07 11:07:12.766334+00	Media	0	ext4
45c394a8-4483-47e7-84f3-6f9448fb92dd	/	248215199744	159626788864	\N	2026-01-06 17:45:41.388571+00	System	67.4	ext4
49e8badd-26b8-497f-8887-fbab9ef67365	/home/inno/compose_ARCHIVED_DO_NOT_USE/backups	195762728960	24133632	\N	2026-01-06 17:45:41.39063+00	Backups	0	ext4
037e65df-4dbc-4df3-91ba-410e449b699a	/home/inno/compose_ARCHIVED_DO_NOT_USE/volumes/media	3936818806784	12288	\N	2026-01-06 17:45:41.391569+00	Media	0	ext4
71ca1369-a2f9-43ee-86ed-1127eeee22a3	/	248215199744	172834402304	\N	2026-01-06 20:40:41.923756+00	System	72.9	ext4
4fae5292-200b-4299-970c-a76b239b7879	/home/inno/compose_ARCHIVED_DO_NOT_USE/backups	195762728960	24133632	\N	2026-01-06 20:40:41.92918+00	Backups	0	ext4
8aa5c5d4-2a51-40d4-a27d-40afd55158c3	/home/inno/compose_ARCHIVED_DO_NOT_USE/volumes/media	3936818806784	12288	\N	2026-01-06 20:40:41.930787+00	Media	0	ext4
8d214fce-382b-4ca8-a864-0e05cdfb5c69	/	248215199744	173793837056	\N	2026-01-06 23:35:42.327279+00	System	73.3	ext4
3962254d-4b23-46fd-ae55-7c187b2fbbba	/home/inno/compose_ARCHIVED_DO_NOT_USE/backups	195762728960	24133632	\N	2026-01-06 23:35:42.330747+00	Backups	0	ext4
67bfe44d-5c4c-4646-bdc8-2bc04b0fe894	/home/inno/compose_ARCHIVED_DO_NOT_USE/volumes/media	3936818806784	12288	\N	2026-01-06 23:35:42.331731+00	Media	0	ext4
038ae655-dac1-4fe4-a1ab-66dac7dff24a	/	248215199744	173777268736	\N	2026-01-07 02:30:42.547635+00	System	73.3	ext4
2601b049-75b6-46bf-9b2a-5f68b016b271	/home/inno/compose_ARCHIVED_DO_NOT_USE/backups	195762728960	24133632	\N	2026-01-07 02:30:42.549655+00	Backups	0	ext4
6706f0e8-1c99-4047-9f0a-e14eb6c1e9b0	/home/inno/compose_ARCHIVED_DO_NOT_USE/volumes/media	3936818806784	12288	\N	2026-01-07 02:30:42.550559+00	Media	0	ext4
c0f0bc4f-a734-47c9-976d-6868ef7a6a90	/	248215199744	173908971520	\N	2026-01-07 05:25:42.796129+00	System	73.4	ext4
90e8f01c-3c4c-404b-b93b-9eaec799179f	/home/inno/compose_ARCHIVED_DO_NOT_USE/backups	195762728960	24133632	\N	2026-01-07 05:25:42.802169+00	Backups	0	ext4
ea70891d-985b-4dfa-9f88-714be8b46693	/home/inno/compose_ARCHIVED_DO_NOT_USE/volumes/media	3936818806784	12288	\N	2026-01-07 05:25:42.803979+00	Media	0	ext4
0cd24f6c-3d21-4dae-b6c1-e7d62cb2b79d	/	248215199744	173898268672	\N	2026-01-07 08:20:42.881362+00	System	73.4	ext4
c2554ccd-aadb-42dc-8381-6410828abfb7	/home/inno/compose_ARCHIVED_DO_NOT_USE/backups	195762728960	24133632	\N	2026-01-07 08:20:42.883683+00	Backups	0	ext4
022fd640-b1e4-4ce7-bec9-2a06f30f66f7	/home/inno/compose_ARCHIVED_DO_NOT_USE/volumes/media	3936818806784	12288	\N	2026-01-07 08:20:42.884729+00	Media	0	ext4
191d906a-2a02-45db-801e-7cea3bf9c2d2	/	248215199744	189941211136	\N	2026-01-07 11:12:12.59562+00	System	80.1	ext4
e4fce3ab-fd7e-4b63-a171-8e43bd929870	/home/inno/compose_ARCHIVED_DO_NOT_USE/backups	195762728960	24133632	\N	2026-01-07 11:12:12.597631+00	Backups	0	ext4
96a3c688-a467-4015-972e-b6fc0c053f0b	/home/inno/compose_ARCHIVED_DO_NOT_USE/volumes/media	3936818806784	12288	\N	2026-01-07 11:12:12.598533+00	Media	0	ext4
012d1af7-e467-44ca-aba6-9db5b38759c6	/	248215199744	160006348800	\N	2026-01-06 17:50:41.406742+00	System	67.5	ext4
ddc99733-b10a-43db-b197-d089b44fe199	/home/inno/compose_ARCHIVED_DO_NOT_USE/backups	195762728960	24133632	\N	2026-01-06 17:50:41.408825+00	Backups	0	ext4
dba59125-3c3d-4900-964f-761c475de5ee	/home/inno/compose_ARCHIVED_DO_NOT_USE/volumes/media	3936818806784	12288	\N	2026-01-06 17:50:41.409776+00	Media	0	ext4
cedb7b35-fd33-460b-87ce-23f395f56920	/	248215199744	173204066304	\N	2026-01-06 20:45:41.944223+00	System	73.1	ext4
344b4a5f-d209-4ae8-ad5f-30f36337ed96	/home/inno/compose_ARCHIVED_DO_NOT_USE/backups	195762728960	24133632	\N	2026-01-06 20:45:41.950664+00	Backups	0	ext4
894615e4-7e57-4178-a1ac-fa70c5301ef4	/home/inno/compose_ARCHIVED_DO_NOT_USE/volumes/media	3936818806784	12288	\N	2026-01-06 20:45:41.952713+00	Media	0	ext4
d15bdcc1-ef12-481e-8587-fae50cb53dce	/	248215199744	173793857536	\N	2026-01-06 23:40:42.337477+00	System	73.3	ext4
179552d6-fb62-478e-8623-6fcd455d6b32	/home/inno/compose_ARCHIVED_DO_NOT_USE/backups	195762728960	24133632	\N	2026-01-06 23:40:42.339485+00	Backups	0	ext4
e4374897-6747-4879-aa64-e7338b1a1f35	/home/inno/compose_ARCHIVED_DO_NOT_USE/volumes/media	3936818806784	12288	\N	2026-01-06 23:40:42.34043+00	Media	0	ext4
f8ad554b-91c5-4196-915f-ec1da2cb4e32	/	248215199744	173779156992	\N	2026-01-07 02:35:42.565178+00	System	73.3	ext4
7cfda9f7-fc1d-476b-9a41-2e798632383d	/home/inno/compose_ARCHIVED_DO_NOT_USE/backups	195762728960	24133632	\N	2026-01-07 02:35:42.57109+00	Backups	0	ext4
4ec86c22-aa56-4c4b-af2f-ea1eae590262	/home/inno/compose_ARCHIVED_DO_NOT_USE/volumes/media	3936818806784	12288	\N	2026-01-07 02:35:42.572963+00	Media	0	ext4
563415b7-d65c-4501-996c-a4c7566bcd89	/	248215199744	173903462400	\N	2026-01-07 05:30:42.80853+00	System	73.4	ext4
08227928-bdd6-4608-91b4-c51c0da59e70	/home/inno/compose_ARCHIVED_DO_NOT_USE/backups	195762728960	24133632	\N	2026-01-07 05:30:42.811408+00	Backups	0	ext4
db12329b-3ffd-4af2-bd76-ae6d5fc1ff53	/home/inno/compose_ARCHIVED_DO_NOT_USE/volumes/media	3936818806784	12288	\N	2026-01-07 05:30:42.812585+00	Media	0	ext4
10c576aa-8058-4af9-af2e-7dbe312a628e	/	248215199744	173898825728	\N	2026-01-07 08:25:43.003038+00	System	73.4	ext4
3137bbfd-79f9-4070-8d5c-84f974e013af	/home/inno/compose_ARCHIVED_DO_NOT_USE/backups	195762728960	24133632	\N	2026-01-07 08:25:43.007192+00	Backups	0	ext4
f50a3ab8-8dc5-467b-b05b-ec6c79ea0b88	/home/inno/compose_ARCHIVED_DO_NOT_USE/volumes/media	3936818806784	12288	\N	2026-01-07 08:25:43.009138+00	Media	0	ext4
afa237e6-d6a2-4a0c-a669-5db6b8797523	/	248215199744	189885313024	\N	2026-01-07 11:17:12.611851+00	System	80.1	ext4
b0ab843f-a637-46c2-b424-76be4f1fb69e	/home/inno/compose_ARCHIVED_DO_NOT_USE/backups	195762728960	24133632	\N	2026-01-07 11:17:12.614341+00	Backups	0	ext4
fc877299-d406-4cb7-89d1-997eb93035e8	/home/inno/compose_ARCHIVED_DO_NOT_USE/volumes/media	3936818806784	12288	\N	2026-01-07 11:17:12.61619+00	Media	0	ext4
80514b14-9765-4e95-bc26-8b73d1cc2983	/	248215199744	160374284288	\N	2026-01-06 17:55:41.439674+00	System	67.7	ext4
c9db8ca8-f32f-4a18-9836-85fe24190f90	/home/inno/compose_ARCHIVED_DO_NOT_USE/backups	195762728960	24133632	\N	2026-01-06 17:55:41.446057+00	Backups	0	ext4
cd59ba3c-93f5-4585-a959-7f4fe8a92e72	/home/inno/compose_ARCHIVED_DO_NOT_USE/volumes/media	3936818806784	12288	\N	2026-01-06 17:55:41.447532+00	Media	0	ext4
3faf1ab8-1fb9-441e-866c-ac7cfef39c99	/	248215199744	173593346048	\N	2026-01-06 20:50:41.953879+00	System	73.2	ext4
764235bb-7818-4f85-ac9d-19ef14005de9	/home/inno/compose_ARCHIVED_DO_NOT_USE/backups	195762728960	24133632	\N	2026-01-06 20:50:41.961802+00	Backups	0	ext4
0baa6683-2e12-4d30-9518-777a4d76fb31	/home/inno/compose_ARCHIVED_DO_NOT_USE/volumes/media	3936818806784	12288	\N	2026-01-06 20:50:41.96368+00	Media	0	ext4
af4fce8d-0930-452b-8a25-e2db9717baac	/	248215199744	173793873920	\N	2026-01-06 23:45:42.34931+00	System	73.3	ext4
9b997feb-1024-4cff-a931-b53054091ba9	/home/inno/compose_ARCHIVED_DO_NOT_USE/backups	195762728960	24133632	\N	2026-01-06 23:45:42.351189+00	Backups	0	ext4
0288baa0-0f32-4cfd-a743-d5b33a2ff3b8	/home/inno/compose_ARCHIVED_DO_NOT_USE/volumes/media	3936818806784	12288	\N	2026-01-06 23:45:42.352082+00	Media	0	ext4
518886b9-aca9-4c52-84f7-292f8d125656	/	248215199744	173781643264	\N	2026-01-07 02:40:42.56585+00	System	73.3	ext4
84b6c0a2-8faf-4ac8-90c4-2a78bd6d5f02	/home/inno/compose_ARCHIVED_DO_NOT_USE/backups	195762728960	24133632	\N	2026-01-07 02:40:42.568103+00	Backups	0	ext4
707894f7-cc4b-4453-8da6-ae7246964ebc	/home/inno/compose_ARCHIVED_DO_NOT_USE/volumes/media	3936818806784	12288	\N	2026-01-07 02:40:42.569017+00	Media	0	ext4
19228149-424c-4c43-89dd-ca42dacb1a02	/	248215199744	173909360640	\N	2026-01-07 05:35:43.01476+00	System	73.4	ext4
e513977a-bf95-41ea-b2b5-66dd48b860e6	/home/inno/compose_ARCHIVED_DO_NOT_USE/backups	195762728960	24133632	\N	2026-01-07 05:35:43.018522+00	Backups	0	ext4
d809b26c-a3bd-47bb-a13a-3886d6daf6b2	/home/inno/compose_ARCHIVED_DO_NOT_USE/volumes/media	3936818806784	12288	\N	2026-01-07 05:35:43.019822+00	Media	0	ext4
a528e693-f9b6-4e7b-9e2c-e4eb27dd2f37	/	248215199744	173899161600	\N	2026-01-07 08:30:42.914221+00	System	73.4	ext4
b46ad606-be6f-460b-8db2-1fee104d1279	/home/inno/compose_ARCHIVED_DO_NOT_USE/backups	195762728960	24133632	\N	2026-01-07 08:30:42.920195+00	Backups	0	ext4
7bcce5b1-a362-4c95-985f-a775621dcddf	/home/inno/compose_ARCHIVED_DO_NOT_USE/volumes/media	3936818806784	12288	\N	2026-01-07 08:30:42.923492+00	Media	0	ext4
fb2e30f3-2239-417f-a43a-cd53890d77e4	/	248215199744	200016150528	\N	2026-01-07 11:22:12.672672+00	System	84.4	ext4
906b447a-1175-48db-99ed-98350d21aa8f	/home/inno/compose_ARCHIVED_DO_NOT_USE/backups	195762728960	24133632	\N	2026-01-07 11:22:12.745447+00	Backups	0	ext4
a317b123-9457-4f9a-94ad-49ade5898b0f	/home/inno/compose_ARCHIVED_DO_NOT_USE/volumes/media	3936818806784	12288	\N	2026-01-07 11:22:12.789037+00	Media	0	ext4
695369ec-14d2-4ea6-bc36-e3308f1f154a	/	248215199744	160757370880	\N	2026-01-06 18:00:41.47575+00	System	67.8	ext4
90f658a0-c9e5-4d24-9294-42b44e10b445	/home/inno/compose_ARCHIVED_DO_NOT_USE/backups	195762728960	24133632	\N	2026-01-06 18:00:41.48312+00	Backups	0	ext4
cafc212c-7b9c-4549-9ec4-420c16468ac6	/home/inno/compose_ARCHIVED_DO_NOT_USE/volumes/media	3936818806784	12288	\N	2026-01-06 18:00:41.485839+00	Media	0	ext4
4c02d017-b293-485e-a0ac-1cf3b04656c4	/	248215199744	173793951744	\N	2026-01-06 20:55:42.034256+00	System	73.3	ext4
86e25396-b8dd-4393-8c60-6c627aba7745	/home/inno/compose_ARCHIVED_DO_NOT_USE/backups	195762728960	24133632	\N	2026-01-06 20:55:42.036163+00	Backups	0	ext4
87df90fc-4e14-4d5f-b417-9e09beb049a7	/home/inno/compose_ARCHIVED_DO_NOT_USE/volumes/media	3936818806784	12288	\N	2026-01-06 20:55:42.037132+00	Media	0	ext4
14038b07-c73a-48bc-8ccc-cac1643f8af1	/	248215199744	173793886208	\N	2026-01-06 23:50:42.392494+00	System	73.3	ext4
d9c20835-3ce2-4413-ab89-9f2aa8aa6819	/home/inno/compose_ARCHIVED_DO_NOT_USE/backups	195762728960	24133632	\N	2026-01-06 23:50:42.395258+00	Backups	0	ext4
e1aed5ac-bfbd-4891-8f79-e0fe70b491e8	/home/inno/compose_ARCHIVED_DO_NOT_USE/volumes/media	3936818806784	12288	\N	2026-01-06 23:50:42.396486+00	Media	0	ext4
822c0d7e-e3ca-478f-8be1-074832ebf198	/	248215199744	173774299136	\N	2026-01-07 02:45:42.568444+00	System	73.3	ext4
50f881c8-567c-43bb-bb58-988935ff474c	/home/inno/compose_ARCHIVED_DO_NOT_USE/backups	195762728960	24133632	\N	2026-01-07 02:45:42.570315+00	Backups	0	ext4
b509a74a-33ca-469e-9979-3696a7c7b7c4	/home/inno/compose_ARCHIVED_DO_NOT_USE/volumes/media	3936818806784	12288	\N	2026-01-07 02:45:42.571205+00	Media	0	ext4
8cabca53-0369-4a37-baa9-43cdb3ddf743	/	248215199744	173905694720	\N	2026-01-07 05:40:42.812362+00	System	73.4	ext4
7e135722-0014-4d88-9354-58f3b804da9e	/home/inno/compose_ARCHIVED_DO_NOT_USE/backups	195762728960	24133632	\N	2026-01-07 05:40:42.81841+00	Backups	0	ext4
b907f399-c007-4a49-992d-7bc49fd248a5	/home/inno/compose_ARCHIVED_DO_NOT_USE/volumes/media	3936818806784	12288	\N	2026-01-07 05:40:42.820357+00	Media	0	ext4
9c3da9d0-6fcf-4b77-81a7-0b124b27622e	/	248215199744	173899898880	\N	2026-01-07 08:35:42.891031+00	System	73.4	ext4
a75e2920-6677-41b7-b5f1-d865f94898c8	/home/inno/compose_ARCHIVED_DO_NOT_USE/backups	195762728960	24133632	\N	2026-01-07 08:35:42.893159+00	Backups	0	ext4
70c3d94f-249a-42dd-ba31-74aa796f241a	/home/inno/compose_ARCHIVED_DO_NOT_USE/volumes/media	3936818806784	12288	\N	2026-01-07 08:35:42.894123+00	Media	0	ext4
6a255a8c-f523-4702-a33a-955942083845	/	248215199744	189716762624	\N	2026-01-07 11:27:12.758887+00	System	80.1	ext4
bf62a2d2-06ee-4ed5-8588-44f4f4ec1e1d	/home/inno/compose_ARCHIVED_DO_NOT_USE/backups	195762728960	24133632	\N	2026-01-07 11:27:12.761204+00	Backups	0	ext4
f380338e-1503-4d95-9290-2fb0fe824f96	/home/inno/compose_ARCHIVED_DO_NOT_USE/volumes/media	3936818806784	12288	\N	2026-01-07 11:27:12.762192+00	Media	0	ext4
53aebb20-f44c-449e-af61-40996aaac193	/	248215199744	161129054208	\N	2026-01-06 18:05:41.436005+00	System	68	ext4
5430e536-5cfa-4f51-a7fe-36a4614f3cab	/home/inno/compose_ARCHIVED_DO_NOT_USE/backups	195762728960	24133632	\N	2026-01-06 18:05:41.437347+00	Backups	0	ext4
ad8e92c9-0be2-463b-bf72-c553c1daf1db	/home/inno/compose_ARCHIVED_DO_NOT_USE/volumes/media	3936818806784	12288	\N	2026-01-06 18:05:41.438232+00	Media	0	ext4
1de26c0c-27bb-4c30-8342-c7923d846c41	/	248215199744	173793972224	\N	2026-01-06 21:00:42.047521+00	System	73.3	ext4
43a75d65-2437-484c-97c8-e78218baded0	/home/inno/compose_ARCHIVED_DO_NOT_USE/backups	195762728960	24133632	\N	2026-01-06 21:00:42.049624+00	Backups	0	ext4
edcd7bfd-8335-46ea-ab63-828effbbc442	/home/inno/compose_ARCHIVED_DO_NOT_USE/volumes/media	3936818806784	12288	\N	2026-01-06 21:00:42.050514+00	Media	0	ext4
f7493a5e-82c4-4a9b-8d9d-240075814052	/	248215199744	173793890304	\N	2026-01-06 23:55:42.376828+00	System	73.3	ext4
354890cd-bdca-43fa-9ab3-f95b23b9f345	/home/inno/compose_ARCHIVED_DO_NOT_USE/backups	195762728960	24133632	\N	2026-01-06 23:55:42.379227+00	Backups	0	ext4
038754bc-822b-4f60-9d2d-4095be7198c0	/home/inno/compose_ARCHIVED_DO_NOT_USE/volumes/media	3936818806784	12288	\N	2026-01-06 23:55:42.380236+00	Media	0	ext4
bfca12e7-0842-4798-b59f-5e879c27dff9	/	248215199744	173776044032	\N	2026-01-07 02:50:42.578387+00	System	73.3	ext4
1f717165-d4a4-4e95-b3ce-953217391d20	/home/inno/compose_ARCHIVED_DO_NOT_USE/backups	195762728960	24133632	\N	2026-01-07 02:50:42.580371+00	Backups	0	ext4
7cc15fa8-4dbb-4086-a3b5-7052c02f959a	/home/inno/compose_ARCHIVED_DO_NOT_USE/volumes/media	3936818806784	12288	\N	2026-01-07 02:50:42.581306+00	Media	0	ext4
5799ebfc-6ca4-44dd-adbc-e2184488d10d	/	248215199744	173900136448	\N	2026-01-07 05:45:42.81669+00	System	73.4	ext4
24815007-a88b-4928-9a47-afa0d19a5c56	/home/inno/compose_ARCHIVED_DO_NOT_USE/backups	195762728960	24133632	\N	2026-01-07 05:45:42.822707+00	Backups	0	ext4
c900452c-965f-4288-8f15-173c2a258d25	/home/inno/compose_ARCHIVED_DO_NOT_USE/volumes/media	3936818806784	12288	\N	2026-01-07 05:45:42.824514+00	Media	0	ext4
23c77e31-88b2-4f11-b1aa-5b0c92b7eaec	/	248215199744	173901467648	\N	2026-01-07 08:40:43.094674+00	System	73.4	ext4
bee6de9f-d209-4fe9-9ff3-7c3f5fbfd3fb	/home/inno/compose_ARCHIVED_DO_NOT_USE/backups	195762728960	24133632	\N	2026-01-07 08:40:43.097237+00	Backups	0	ext4
e9c678d1-8131-42b3-9f76-7e05f847b94d	/home/inno/compose_ARCHIVED_DO_NOT_USE/volumes/media	3936818806784	12288	\N	2026-01-07 08:40:43.098378+00	Media	0	ext4
6a817684-32ae-4f06-ad7c-81da78d31a21	/	248215199744	189716938752	\N	2026-01-07 11:32:12.755245+00	System	80.1	ext4
3d37ad3b-47d6-47b4-877c-664daec53d36	/home/inno/compose_ARCHIVED_DO_NOT_USE/backups	195762728960	24133632	\N	2026-01-07 11:32:12.757708+00	Backups	0	ext4
9e234855-2d76-49e8-adb6-5b9b3db91e17	/home/inno/compose_ARCHIVED_DO_NOT_USE/volumes/media	3936818806784	12288	\N	2026-01-07 11:32:12.758715+00	Media	0	ext4
9ac1af1a-c598-4f8b-9ac7-eb7694f27d46	/	248215199744	161521983488	\N	2026-01-06 18:10:41.49429+00	System	68.2	ext4
178966ae-84c0-467c-8009-70e95cd7c015	/home/inno/compose_ARCHIVED_DO_NOT_USE/backups	195762728960	24133632	\N	2026-01-06 18:10:41.500472+00	Backups	0	ext4
23ecc65d-c49e-497a-bd1b-99908deef9c7	/home/inno/compose_ARCHIVED_DO_NOT_USE/volumes/media	3936818806784	12288	\N	2026-01-06 18:10:41.502466+00	Media	0	ext4
c01ffd15-6d57-4e54-b282-a1e100388804	/	248215199744	173793996800	\N	2026-01-06 21:05:42.039379+00	System	73.3	ext4
d1f444a5-020b-451f-a352-9cad82fd5c56	/home/inno/compose_ARCHIVED_DO_NOT_USE/backups	195762728960	24133632	\N	2026-01-06 21:05:42.040613+00	Backups	0	ext4
7111348c-6adc-41c0-bd18-6ce99ed2b1de	/home/inno/compose_ARCHIVED_DO_NOT_USE/volumes/media	3936818806784	12288	\N	2026-01-06 21:05:42.041504+00	Media	0	ext4
870f70a3-32a1-4ddb-8658-6ae4a5c94361	/	248215199744	173793849344	\N	2026-01-07 00:00:42.392913+00	System	73.3	ext4
7abb29c1-dc56-4419-9aa6-8200a7f53fde	/home/inno/compose_ARCHIVED_DO_NOT_USE/backups	195762728960	24133632	\N	2026-01-07 00:00:42.395603+00	Backups	0	ext4
c4400bd8-4d1c-4f77-8463-7d21c0618d6b	/home/inno/compose_ARCHIVED_DO_NOT_USE/volumes/media	3936818806784	12288	\N	2026-01-07 00:00:42.396652+00	Media	0	ext4
cefe93bd-4068-4f0d-8e75-1a0a62994601	/	248215199744	173779308544	\N	2026-01-07 02:55:42.585522+00	System	73.3	ext4
be19fcf9-b856-403a-858d-ee94e177872e	/home/inno/compose_ARCHIVED_DO_NOT_USE/backups	195762728960	24133632	\N	2026-01-07 02:55:42.588177+00	Backups	0	ext4
2a285b0a-dbd7-46e1-b7a8-ec3e6a81b418	/home/inno/compose_ARCHIVED_DO_NOT_USE/volumes/media	3936818806784	12288	\N	2026-01-07 02:55:42.589951+00	Media	0	ext4
e70a357d-ce51-45db-a8f7-34b999c4f1d7	/	248215199744	173906112512	\N	2026-01-07 05:50:42.972202+00	System	73.4	ext4
c57324d8-aeb0-4d5a-b764-d17cd808c825	/home/inno/compose_ARCHIVED_DO_NOT_USE/backups	195762728960	24133632	\N	2026-01-07 05:50:42.974149+00	Backups	0	ext4
8c738786-d0e2-4e20-8370-3646d33f164a	/home/inno/compose_ARCHIVED_DO_NOT_USE/volumes/media	3936818806784	12288	\N	2026-01-07 05:50:42.975107+00	Media	0	ext4
04df26cc-843a-4b70-a69b-62b232fa24ae	/	248215199744	173902598144	\N	2026-01-07 08:45:43.012968+00	System	73.4	ext4
5ffa49e3-2f63-4886-9920-833c0b74f3a9	/home/inno/compose_ARCHIVED_DO_NOT_USE/backups	195762728960	24133632	\N	2026-01-07 08:45:43.014941+00	Backups	0	ext4
511a8e2a-98c1-473f-9e53-d5d139242163	/home/inno/compose_ARCHIVED_DO_NOT_USE/volumes/media	3936818806784	12288	\N	2026-01-07 08:45:43.015754+00	Media	0	ext4
1ed65e07-e98a-47db-8e45-e5ba1e9cb80f	/	248215199744	189790588928	\N	2026-01-07 11:37:12.554316+00	System	80.1	ext4
640e1c53-a153-4633-abf8-e9f73b9370b3	/home/inno/compose_ARCHIVED_DO_NOT_USE/backups	195762728960	24133632	\N	2026-01-07 11:37:12.55699+00	Backups	0	ext4
e655e810-ec18-4f48-9de7-875638f459b8	/home/inno/compose_ARCHIVED_DO_NOT_USE/volumes/media	3936818806784	12288	\N	2026-01-07 11:37:12.55893+00	Media	0	ext4
5201f685-2339-4c11-bd43-121140861977	/	248215199744	161889783808	\N	2026-01-06 18:15:41.507404+00	System	68.3	ext4
0e3abae1-90fc-40d7-976c-7a7b01cc2902	/home/inno/compose_ARCHIVED_DO_NOT_USE/backups	195762728960	24133632	\N	2026-01-06 18:15:41.515076+00	Backups	0	ext4
81829d92-80c2-451c-b3f1-dff6039d616e	/home/inno/compose_ARCHIVED_DO_NOT_USE/volumes/media	3936818806784	12288	\N	2026-01-06 18:15:41.516973+00	Media	0	ext4
e8fe9f39-04c2-4598-afc0-51aea4034655	/	248215199744	173793370112	\N	2026-01-06 21:10:42.056494+00	System	73.3	ext4
d1a71f41-ae8c-4f4c-bff2-09c177ab24b7	/home/inno/compose_ARCHIVED_DO_NOT_USE/backups	195762728960	24133632	\N	2026-01-06 21:10:42.058504+00	Backups	0	ext4
d406d02b-476b-44e5-aaf0-11624a76a2b7	/home/inno/compose_ARCHIVED_DO_NOT_USE/volumes/media	3936818806784	12288	\N	2026-01-06 21:10:42.059399+00	Media	0	ext4
56341063-41be-4a35-8448-ab8083b0ebbf	/	248215199744	173793857536	\N	2026-01-07 00:05:42.390118+00	System	73.3	ext4
3ada41cb-909b-452f-86e3-b9fee5bd02d2	/home/inno/compose_ARCHIVED_DO_NOT_USE/backups	195762728960	24133632	\N	2026-01-07 00:05:42.391496+00	Backups	0	ext4
b0915626-dad4-4f51-9625-28fac58ca8c1	/home/inno/compose_ARCHIVED_DO_NOT_USE/volumes/media	3936818806784	12288	\N	2026-01-07 00:05:42.392618+00	Media	0	ext4
e728505c-e50f-4c11-9e41-3bf4e2c6863d	/	248215199744	173781368832	\N	2026-01-07 03:00:42.5943+00	System	73.3	ext4
4a2ea9f5-8f6f-438b-b159-d8fa2df37fa5	/home/inno/compose_ARCHIVED_DO_NOT_USE/backups	195762728960	24133632	\N	2026-01-07 03:00:42.596189+00	Backups	0	ext4
457d9aac-d13c-4f02-a7d7-a2cdb35f30e3	/home/inno/compose_ARCHIVED_DO_NOT_USE/volumes/media	3936818806784	12288	\N	2026-01-07 03:00:42.597102+00	Media	0	ext4
e365fe56-1fe9-434a-aff7-cc4fdd328a77	/	248215199744	173902647296	\N	2026-01-07 05:55:42.826957+00	System	73.4	ext4
a5da3b5d-fe7b-4dc5-95e7-2af35331798a	/home/inno/compose_ARCHIVED_DO_NOT_USE/backups	195762728960	24133632	\N	2026-01-07 05:55:42.833087+00	Backups	0	ext4
89efcae5-12f5-4066-bee7-f131b1509703	/home/inno/compose_ARCHIVED_DO_NOT_USE/volumes/media	3936818806784	12288	\N	2026-01-07 05:55:42.834985+00	Media	0	ext4
17b44277-b75a-4422-82e7-ef89130b3797	/	248215199744	173903839232	\N	2026-01-07 08:50:43.025716+00	System	73.4	ext4
486d3be4-2f14-4538-9cee-9096194f9df5	/home/inno/compose_ARCHIVED_DO_NOT_USE/backups	195762728960	24133632	\N	2026-01-07 08:50:43.027812+00	Backups	0	ext4
4be89379-0570-47c9-9f2d-18fac4773336	/home/inno/compose_ARCHIVED_DO_NOT_USE/volumes/media	3936818806784	12288	\N	2026-01-07 08:50:43.030106+00	Media	0	ext4
ee8f8459-6027-4f7a-aa8f-60da7c9f5503	/	248215199744	190105546752	\N	2026-01-07 11:42:12.595945+00	System	80.2	ext4
dacfc660-0950-4b57-90de-3328c6c30f50	/home/inno/compose_ARCHIVED_DO_NOT_USE/backups	195762728960	24133632	\N	2026-01-07 11:42:12.603183+00	Backups	0	ext4
72ff8303-27a0-4e32-b8e1-542607f3983e	/home/inno/compose_ARCHIVED_DO_NOT_USE/volumes/media	3936818806784	12288	\N	2026-01-07 11:42:12.605375+00	Media	0	ext4
e23d3f6d-9cb1-43fa-9ac3-67c483c2b226	/	248215199744	162272092160	\N	2026-01-06 18:20:41.524188+00	System	68.5	ext4
14947823-e304-4902-a635-f2e92efe567a	/home/inno/compose_ARCHIVED_DO_NOT_USE/backups	195762728960	24133632	\N	2026-01-06 18:20:41.530193+00	Backups	0	ext4
ca720aa1-c340-4264-9f01-18c05769c185	/home/inno/compose_ARCHIVED_DO_NOT_USE/volumes/media	3936818806784	12288	\N	2026-01-06 18:20:41.532037+00	Media	0	ext4
ea60df15-29eb-431d-ad41-c3db18b1b9db	/	248215199744	173793382400	\N	2026-01-06 21:15:42.117984+00	System	73.3	ext4
d2931e09-1685-4ee0-9c3f-617342283247	/home/inno/compose_ARCHIVED_DO_NOT_USE/backups	195762728960	24133632	\N	2026-01-06 21:15:42.120896+00	Backups	0	ext4
ee912741-15b9-4d33-93a2-cf44dce121ad	/home/inno/compose_ARCHIVED_DO_NOT_USE/volumes/media	3936818806784	12288	\N	2026-01-06 21:15:42.122027+00	Media	0	ext4
bd37d0c3-6404-436c-b425-929a491c33a3	/	248215199744	173793878016	\N	2026-01-07 00:10:42.404817+00	System	73.3	ext4
b067f7b5-2988-4c85-b3eb-af7f70f85931	/home/inno/compose_ARCHIVED_DO_NOT_USE/backups	195762728960	24133632	\N	2026-01-07 00:10:42.407252+00	Backups	0	ext4
1bcb63f0-fb51-4123-af53-0d99acd2616e	/home/inno/compose_ARCHIVED_DO_NOT_USE/volumes/media	3936818806784	12288	\N	2026-01-07 00:10:42.408279+00	Media	0	ext4
d096d2ff-02d2-4026-a35a-1253e8dbc477	/	248215199744	173773053952	\N	2026-01-07 03:05:42.574016+00	System	73.3	ext4
06fd20ff-67cf-40bb-9fc7-1756badc38f5	/home/inno/compose_ARCHIVED_DO_NOT_USE/backups	195762728960	24133632	\N	2026-01-07 03:05:42.575297+00	Backups	0	ext4
60845bff-b042-452c-8e5a-86ae0a9abce7	/home/inno/compose_ARCHIVED_DO_NOT_USE/volumes/media	3936818806784	12288	\N	2026-01-07 03:05:42.57638+00	Media	0	ext4
7407fa05-43e2-47a3-a437-a1fc1a0e0631	/	248215199744	173908762624	\N	2026-01-07 06:00:42.832393+00	System	73.4	ext4
45f1b9ad-cf28-4096-94ab-1ff5cc6faa05	/home/inno/compose_ARCHIVED_DO_NOT_USE/backups	195762728960	24133632	\N	2026-01-07 06:00:42.838402+00	Backups	0	ext4
c60afed2-d8de-4e6d-ad23-cdbd714c2fb1	/home/inno/compose_ARCHIVED_DO_NOT_USE/volumes/media	3936818806784	12288	\N	2026-01-07 06:00:42.840388+00	Media	0	ext4
4a3c5dfe-4fd0-4b45-a20e-b185e46de853	/	248215199744	208608157696	\N	2026-01-07 08:55:42.926706+00	System	88	ext4
a7f441cf-172e-4452-948e-f8adcdf2d491	/home/inno/compose_ARCHIVED_DO_NOT_USE/backups	195762728960	24133632	\N	2026-01-07 08:55:42.996212+00	Backups	0	ext4
1f04cfba-157b-44e1-a96b-636da1a96aa7	/home/inno/compose_ARCHIVED_DO_NOT_USE/volumes/media	3936818806784	12288	\N	2026-01-07 08:55:43.024327+00	Media	0	ext4
5cc7d2a8-259b-4722-819f-281870b052c2	/	248215199744	162642071552	\N	2026-01-06 18:25:41.542505+00	System	68.6	ext4
c925ed72-7d36-4c02-ad8f-cec815c95102	/home/inno/compose_ARCHIVED_DO_NOT_USE/backups	195762728960	24133632	\N	2026-01-06 18:25:41.548952+00	Backups	0	ext4
2a31b19b-6f1a-4e97-a1fd-bb820237f808	/home/inno/compose_ARCHIVED_DO_NOT_USE/volumes/media	3936818806784	12288	\N	2026-01-06 18:25:41.551686+00	Media	0	ext4
d91a5890-daa6-4d73-a95e-2eae947f9758	/	248215199744	173793423360	\N	2026-01-06 21:20:42.072239+00	System	73.3	ext4
ce1990fd-0112-4c8e-b7c9-1745041f5d1a	/home/inno/compose_ARCHIVED_DO_NOT_USE/backups	195762728960	24133632	\N	2026-01-06 21:20:42.074198+00	Backups	0	ext4
1e50a7e2-203f-4fdd-83ac-503c92c75461	/home/inno/compose_ARCHIVED_DO_NOT_USE/volumes/media	3936818806784	12288	\N	2026-01-06 21:20:42.075068+00	Media	0	ext4
01f24403-bbc4-4ddf-9050-3229d911df1a	/	248215199744	173793882112	\N	2026-01-07 00:15:42.389944+00	System	73.3	ext4
1f5758c8-8a70-413f-943c-e1d574a70b22	/home/inno/compose_ARCHIVED_DO_NOT_USE/backups	195762728960	24133632	\N	2026-01-07 00:15:42.392637+00	Backups	0	ext4
ad6269cb-f42a-417a-8e02-02cca2a536a4	/home/inno/compose_ARCHIVED_DO_NOT_USE/volumes/media	3936818806784	12288	\N	2026-01-07 00:15:42.394423+00	Media	0	ext4
ba45b188-72e3-4f22-991a-49ba3e051480	/	248215199744	173775532032	\N	2026-01-07 03:10:42.604269+00	System	73.3	ext4
abe02870-40c8-4b54-bdbe-fd8d0a8f9203	/home/inno/compose_ARCHIVED_DO_NOT_USE/backups	195762728960	24133632	\N	2026-01-07 03:10:42.606212+00	Backups	0	ext4
7c989450-0e12-49ed-bfd1-6bbcf04bb478	/home/inno/compose_ARCHIVED_DO_NOT_USE/volumes/media	3936818806784	12288	\N	2026-01-07 03:10:42.607151+00	Media	0	ext4
5b9d95c2-0896-45af-b18a-05c1b655a822	/	248215199744	173903732736	\N	2026-01-07 06:05:42.917674+00	System	73.4	ext4
3db0395b-cf56-46ea-a9c7-c84b582407e8	/home/inno/compose_ARCHIVED_DO_NOT_USE/backups	195762728960	24133632	\N	2026-01-07 06:05:42.918933+00	Backups	0	ext4
b060e5fd-a893-4aa1-8c68-e7ff67c9b15d	/home/inno/compose_ARCHIVED_DO_NOT_USE/volumes/media	3936818806784	12288	\N	2026-01-07 06:05:42.919995+00	Media	0	ext4
2bf5bd54-0a7c-4e32-9aef-a840634d2da8	/	248215199744	189400428544	\N	2026-01-07 09:00:42.925156+00	System	79.9	ext4
350c90ab-edba-433e-bd57-eb931d29dd12	/home/inno/compose_ARCHIVED_DO_NOT_USE/backups	195762728960	24133632	\N	2026-01-07 09:00:42.931324+00	Backups	0	ext4
d8728bc8-5006-4619-9cca-62f3e08a1d4e	/home/inno/compose_ARCHIVED_DO_NOT_USE/volumes/media	3936818806784	12288	\N	2026-01-07 09:00:42.933178+00	Media	0	ext4
b6dda0ef-b7d9-489b-8956-8cbb77340c36	/	248215199744	163025997824	\N	2026-01-06 18:30:41.558442+00	System	68.8	ext4
cad1595c-3904-4f09-a1e8-9c142ff1e929	/home/inno/compose_ARCHIVED_DO_NOT_USE/backups	195762728960	24133632	\N	2026-01-06 18:30:41.566661+00	Backups	0	ext4
82437c4b-cd7e-4eca-bf7b-5a2d1457d5e6	/home/inno/compose_ARCHIVED_DO_NOT_USE/volumes/media	3936818806784	12288	\N	2026-01-06 18:30:41.568623+00	Media	0	ext4
03f9a51f-57b0-4787-806a-e93497f03352	/	248215199744	173793415168	\N	2026-01-06 21:25:42.158681+00	System	73.3	ext4
60d69325-cea0-4ede-8760-0092b6b13ca3	/home/inno/compose_ARCHIVED_DO_NOT_USE/backups	195762728960	24133632	\N	2026-01-06 21:25:42.161039+00	Backups	0	ext4
07b93825-713c-4953-8de3-8cd059411ac9	/home/inno/compose_ARCHIVED_DO_NOT_USE/volumes/media	3936818806784	12288	\N	2026-01-06 21:25:42.162058+00	Media	0	ext4
374ede8b-9192-4bc2-ad70-7dbf7a6b276f	/	248215199744	173793906688	\N	2026-01-07 00:20:42.412983+00	System	73.3	ext4
3711244b-88e6-4626-ba1a-9c4bbad793db	/home/inno/compose_ARCHIVED_DO_NOT_USE/backups	195762728960	24133632	\N	2026-01-07 00:20:42.415379+00	Backups	0	ext4
6333298c-f94d-4f34-827c-d65fd20754ce	/home/inno/compose_ARCHIVED_DO_NOT_USE/volumes/media	3936818806784	12288	\N	2026-01-07 00:20:42.416368+00	Media	0	ext4
d416835b-e85e-417a-80b0-ecfb3f6bf0ba	/	248215199744	173778800640	\N	2026-01-07 03:15:42.627377+00	System	73.3	ext4
af08ecbb-d82a-439b-a114-cb7f7e3dc8ee	/home/inno/compose_ARCHIVED_DO_NOT_USE/backups	195762728960	24133632	\N	2026-01-07 03:15:42.633226+00	Backups	0	ext4
e87e455f-dbc2-43ab-90b9-1f065cb0464f	/home/inno/compose_ARCHIVED_DO_NOT_USE/volumes/media	3936818806784	12288	\N	2026-01-07 03:15:42.635078+00	Media	0	ext4
430fc61b-e662-4505-a251-014898ab0b2d	/	248215199744	173909286912	\N	2026-01-07 06:10:42.837913+00	System	73.4	ext4
12486476-476e-434a-93c1-12b9366cc57b	/home/inno/compose_ARCHIVED_DO_NOT_USE/backups	195762728960	24133632	\N	2026-01-07 06:10:42.844389+00	Backups	0	ext4
473e536a-62bc-4d60-9872-6539be01f101	/home/inno/compose_ARCHIVED_DO_NOT_USE/volumes/media	3936818806784	12288	\N	2026-01-07 06:10:42.846498+00	Media	0	ext4
00feb5a0-dacc-489f-8ad1-f84ccf8c13d0	/	248215199744	189401341952	\N	2026-01-07 09:05:42.889385+00	System	79.9	ext4
e9e54e65-c15e-4962-84af-a34177d4962b	/home/inno/compose_ARCHIVED_DO_NOT_USE/backups	195762728960	24133632	\N	2026-01-07 09:05:42.890945+00	Backups	0	ext4
00fde082-2ac3-4893-a6f1-0b2d45d94061	/home/inno/compose_ARCHIVED_DO_NOT_USE/volumes/media	3936818806784	12288	\N	2026-01-07 09:05:42.892421+00	Media	0	ext4
0086febd-e90a-4a49-b325-1b1b4809d370	/	248215199744	163398103040	\N	2026-01-06 18:35:41.575594+00	System	68.9	ext4
1ba04421-66d8-4f19-9c5e-3827da38ea6c	/home/inno/compose_ARCHIVED_DO_NOT_USE/backups	195762728960	24133632	\N	2026-01-06 18:35:41.581815+00	Backups	0	ext4
f57678c8-0f51-467d-8e75-87b952c74d37	/home/inno/compose_ARCHIVED_DO_NOT_USE/volumes/media	3936818806784	12288	\N	2026-01-06 18:35:41.586197+00	Media	0	ext4
0ce31a36-a981-431a-92ed-96d985cf07a7	/	248215199744	173793439744	\N	2026-01-06 21:30:42.108301+00	System	73.3	ext4
e9bd0350-a16f-4db2-9c66-2ffe0f9c7061	/home/inno/compose_ARCHIVED_DO_NOT_USE/backups	195762728960	24133632	\N	2026-01-06 21:30:42.110214+00	Backups	0	ext4
e2828921-2fe4-47f5-9e1c-fd35ce801e90	/home/inno/compose_ARCHIVED_DO_NOT_USE/volumes/media	3936818806784	12288	\N	2026-01-06 21:30:42.111138+00	Media	0	ext4
030971a4-7f7b-4861-9f4e-753888bc1174	/	248215199744	173793923072	\N	2026-01-07 00:25:42.429263+00	System	73.3	ext4
cbab2b32-9eac-426b-9ea7-1a2b8e8747c6	/home/inno/compose_ARCHIVED_DO_NOT_USE/backups	195762728960	24133632	\N	2026-01-07 00:25:42.431762+00	Backups	0	ext4
0c0d2791-7206-4712-9cf5-433d551aaf5e	/home/inno/compose_ARCHIVED_DO_NOT_USE/volumes/media	3936818806784	12288	\N	2026-01-07 00:25:42.43272+00	Media	0	ext4
c5da3bdf-99a6-4b8d-b37c-232d51b49cb4	/	248215199744	173782077440	\N	2026-01-07 03:20:42.622409+00	System	73.3	ext4
ddbc2360-770d-4244-9850-f0ce7f48d8b4	/home/inno/compose_ARCHIVED_DO_NOT_USE/backups	195762728960	24133632	\N	2026-01-07 03:20:42.624316+00	Backups	0	ext4
27f444da-7003-41e4-b469-738d57d16009	/home/inno/compose_ARCHIVED_DO_NOT_USE/volumes/media	3936818806784	12288	\N	2026-01-07 03:20:42.625251+00	Media	0	ext4
d15a1524-4d75-4622-ac7b-517ad57b9d62	/	248215199744	173905289216	\N	2026-01-07 06:15:42.841068+00	System	73.4	ext4
32a92aec-cf7a-4573-893e-875d1612db0f	/home/inno/compose_ARCHIVED_DO_NOT_USE/backups	195762728960	24133632	\N	2026-01-07 06:15:42.849351+00	Backups	0	ext4
5da956a0-ac09-4535-9a78-1307ba8a7103	/home/inno/compose_ARCHIVED_DO_NOT_USE/volumes/media	3936818806784	12288	\N	2026-01-07 06:15:42.851374+00	Media	0	ext4
ff5b9aa9-f4cd-4fd8-bb85-cf58a2c792cd	/	248215199744	189401755648	\N	2026-01-07 09:10:43.014587+00	System	79.9	ext4
890b3502-5592-424c-badf-aeccc530757e	/home/inno/compose_ARCHIVED_DO_NOT_USE/backups	195762728960	24133632	\N	2026-01-07 09:10:43.016566+00	Backups	0	ext4
821889f4-1fb4-4d8d-9db3-72c4954d0962	/home/inno/compose_ARCHIVED_DO_NOT_USE/volumes/media	3936818806784	12288	\N	2026-01-07 09:10:43.017449+00	Media	0	ext4
edec9e8a-b518-4644-a573-2055485d174f	/	248215199744	163781918720	\N	2026-01-06 18:40:41.609468+00	System	69.1	ext4
dc945785-069a-4dbc-8ee7-23f051a6d27b	/home/inno/compose_ARCHIVED_DO_NOT_USE/backups	195762728960	24133632	\N	2026-01-06 18:40:41.615428+00	Backups	0	ext4
c6fccea5-4937-49c2-93e4-f9f5a9b026bb	/home/inno/compose_ARCHIVED_DO_NOT_USE/volumes/media	3936818806784	12288	\N	2026-01-06 18:40:41.617297+00	Media	0	ext4
e43dcf2c-c030-4b97-8250-cb6c99aacb73	/	248215199744	173793447936	\N	2026-01-06 21:35:42.117551+00	System	73.3	ext4
8b360eab-b5cc-4e6b-9c14-73f821991d66	/home/inno/compose_ARCHIVED_DO_NOT_USE/backups	195762728960	24133632	\N	2026-01-06 21:35:42.119573+00	Backups	0	ext4
9173d37d-19af-41ed-a417-73b2f053d309	/home/inno/compose_ARCHIVED_DO_NOT_USE/volumes/media	3936818806784	12288	\N	2026-01-06 21:35:42.120535+00	Media	0	ext4
7d1715e6-db37-4f16-9a01-1a0fd2ba8fed	/	248215199744	173793935360	\N	2026-01-07 00:30:42.431664+00	System	73.3	ext4
646aa9f0-cad3-42ca-8781-40547f1dbda4	/home/inno/compose_ARCHIVED_DO_NOT_USE/backups	195762728960	24133632	\N	2026-01-07 00:30:42.43412+00	Backups	0	ext4
fdb3073b-1d2f-4901-a48d-3f3f5a5a81ea	/home/inno/compose_ARCHIVED_DO_NOT_USE/volumes/media	3936818806784	12288	\N	2026-01-07 00:30:42.435099+00	Media	0	ext4
b9e48b38-737a-4f1e-99a5-73517a006c58	/	248215199744	173785329664	\N	2026-01-07 03:25:42.629882+00	System	73.3	ext4
a02e348e-c1ce-422a-af08-8b02ce8dfafc	/home/inno/compose_ARCHIVED_DO_NOT_USE/backups	195762728960	24133632	\N	2026-01-07 03:25:42.631901+00	Backups	0	ext4
f6f48e2a-6927-460d-867f-f759a869fe80	/home/inno/compose_ARCHIVED_DO_NOT_USE/volumes/media	3936818806784	12288	\N	2026-01-07 03:25:42.634372+00	Media	0	ext4
1f4fbc10-88da-4ec4-815d-5188848cdf66	/	248215199744	173902602240	\N	2026-01-07 06:20:43.058917+00	System	73.4	ext4
d2b6eae3-3dfa-4eb5-827c-8d7a63d56f0f	/home/inno/compose_ARCHIVED_DO_NOT_USE/backups	195762728960	24133632	\N	2026-01-07 06:20:43.062369+00	Backups	0	ext4
ac6e19ea-942c-43fe-b5f3-72152a7e5d71	/home/inno/compose_ARCHIVED_DO_NOT_USE/volumes/media	3936818806784	12288	\N	2026-01-07 06:20:43.063709+00	Media	0	ext4
9769689f-34cd-4650-b6b0-d29793521e2c	/	248215199744	189383847936	\N	2026-01-07 09:15:43.014848+00	System	79.9	ext4
65066404-afa1-4f6d-ae45-e09d02b45c27	/home/inno/compose_ARCHIVED_DO_NOT_USE/backups	195762728960	24133632	\N	2026-01-07 09:15:43.016779+00	Backups	0	ext4
2079c44e-56fc-447d-8b4f-40a35bd141fd	/home/inno/compose_ARCHIVED_DO_NOT_USE/volumes/media	3936818806784	12288	\N	2026-01-07 09:15:43.017737+00	Media	0	ext4
7241da58-6dad-4443-839c-634923b58da8	/	248215199744	164155686912	\N	2026-01-06 18:45:41.611946+00	System	69.3	ext4
280a3b92-eb27-46b2-9b14-43747ae858e8	/home/inno/compose_ARCHIVED_DO_NOT_USE/backups	195762728960	24133632	\N	2026-01-06 18:45:41.618121+00	Backups	0	ext4
f6d122b8-d04b-4d16-b7f3-9a35f57f98c2	/home/inno/compose_ARCHIVED_DO_NOT_USE/volumes/media	3936818806784	12288	\N	2026-01-06 18:45:41.620173+00	Media	0	ext4
6a87dea2-cdba-493a-9483-632b27f98c09	/	248215199744	173793468416	\N	2026-01-06 21:40:42.133605+00	System	73.3	ext4
39c7eeac-18a6-4cdf-af79-c863e620311b	/home/inno/compose_ARCHIVED_DO_NOT_USE/backups	195762728960	24133632	\N	2026-01-06 21:40:42.135592+00	Backups	0	ext4
73e6d308-5de0-4c47-809a-6b06d6c6a18c	/home/inno/compose_ARCHIVED_DO_NOT_USE/volumes/media	3936818806784	12288	\N	2026-01-06 21:40:42.136486+00	Media	0	ext4
67100e42-b1c3-4ec9-aab7-c96e8962aa33	/	248215199744	173793951744	\N	2026-01-07 00:35:42.45213+00	System	73.3	ext4
b8493319-e700-425c-836d-4b83514a10eb	/home/inno/compose_ARCHIVED_DO_NOT_USE/backups	195762728960	24133632	\N	2026-01-07 00:35:42.45474+00	Backups	0	ext4
d4bc35b7-5e6d-4d32-9dd4-badf861ded8c	/home/inno/compose_ARCHIVED_DO_NOT_USE/volumes/media	3936818806784	12288	\N	2026-01-07 00:35:42.457689+00	Media	0	ext4
e95cd875-b5be-4320-903f-be8d627f643a	/	248215199744	173778632704	\N	2026-01-07 03:30:42.638292+00	System	73.3	ext4
9dfae709-fe4e-4599-ba75-08efa88c1ab1	/home/inno/compose_ARCHIVED_DO_NOT_USE/backups	195762728960	24133632	\N	2026-01-07 03:30:42.64191+00	Backups	0	ext4
c4a494d3-d331-4d0c-8ae1-362bf0223cb0	/home/inno/compose_ARCHIVED_DO_NOT_USE/volumes/media	3936818806784	12288	\N	2026-01-07 03:30:42.642895+00	Media	0	ext4
ce208402-84e3-4fa9-a19f-80308124809c	/	248215199744	173910077440	\N	2026-01-07 06:25:42.924546+00	System	73.4	ext4
fa5f173d-5598-4f91-b673-7c47e695a7f7	/home/inno/compose_ARCHIVED_DO_NOT_USE/backups	195762728960	24133632	\N	2026-01-07 06:25:42.926532+00	Backups	0	ext4
c74b3893-fbf7-4d4e-92f5-f681fabba7d4	/home/inno/compose_ARCHIVED_DO_NOT_USE/volumes/media	3936818806784	12288	\N	2026-01-07 06:25:42.927425+00	Media	0	ext4
14e0b469-617b-4d67-9639-9fd8983c1a85	/	248215199744	189384384512	\N	2026-01-07 09:20:33.413308+00	System	79.9	ext4
48350ca4-87a1-4f7a-9e4b-e812de471aab	/home/inno/compose_ARCHIVED_DO_NOT_USE/backups	195762728960	24133632	\N	2026-01-07 09:20:33.417206+00	Backups	0	ext4
630ffb6f-7a59-47c6-b5c0-58d609e1e3de	/home/inno/compose_ARCHIVED_DO_NOT_USE/volumes/media	3936818806784	12288	\N	2026-01-07 09:20:33.420107+00	Media	0	ext4
a141a9f9-96ea-4c76-b912-9ebab2c491d5	/	248215199744	164535115776	\N	2026-01-06 18:50:41.624561+00	System	69.4	ext4
5cbdf6f2-c8e7-447d-bf84-05ac07af5418	/home/inno/compose_ARCHIVED_DO_NOT_USE/backups	195762728960	24133632	\N	2026-01-06 18:50:41.630802+00	Backups	0	ext4
6499b5c1-008c-40ea-bfbf-43a4b4d4b19a	/home/inno/compose_ARCHIVED_DO_NOT_USE/volumes/media	3936818806784	12288	\N	2026-01-06 18:50:41.632742+00	Media	0	ext4
7b0b9fa4-32ea-4470-a50e-f0b7cd62e89c	/	248215199744	173793480704	\N	2026-01-06 21:45:42.151589+00	System	73.3	ext4
fb073604-dd93-41f0-adae-8c35223a6e81	/home/inno/compose_ARCHIVED_DO_NOT_USE/backups	195762728960	24133632	\N	2026-01-06 21:45:42.153809+00	Backups	0	ext4
b4382276-3638-430a-9df1-fe791170f163	/home/inno/compose_ARCHIVED_DO_NOT_USE/volumes/media	3936818806784	12288	\N	2026-01-06 21:45:42.154809+00	Media	0	ext4
e35d3e8f-7ba8-43b8-8e17-b8e1a170660f	/	248215199744	173793964032	\N	2026-01-07 00:40:42.444879+00	System	73.3	ext4
bb1eba83-3cdd-449e-b33a-bcc5c72c5ce2	/home/inno/compose_ARCHIVED_DO_NOT_USE/backups	195762728960	24133632	\N	2026-01-07 00:40:42.448644+00	Backups	0	ext4
6ffddd7b-1e6a-49bb-a2fa-1a1b308e1277	/home/inno/compose_ARCHIVED_DO_NOT_USE/volumes/media	3936818806784	12288	\N	2026-01-07 00:40:42.449618+00	Media	0	ext4
90984133-8422-45e8-afcb-1d162557ad55	/	248215199744	173783941120	\N	2026-01-07 03:35:42.646403+00	System	73.3	ext4
22720b2d-c390-4075-ae3d-b141b662d78f	/home/inno/compose_ARCHIVED_DO_NOT_USE/backups	195762728960	24133632	\N	2026-01-07 03:35:42.648352+00	Backups	0	ext4
2db92be4-5a59-4d06-99d9-19c517e283ef	/home/inno/compose_ARCHIVED_DO_NOT_USE/volumes/media	3936818806784	12288	\N	2026-01-07 03:35:42.649239+00	Media	0	ext4
b247aad6-10e9-42f8-b5de-a279d1e09e39	/	248215199744	173907009536	\N	2026-01-07 06:30:42.850391+00	System	73.4	ext4
2b3a3ed2-cafe-4ed4-b27a-a9c1491623f3	/home/inno/compose_ARCHIVED_DO_NOT_USE/backups	195762728960	24133632	\N	2026-01-07 06:30:42.856673+00	Backups	0	ext4
bb2df73d-60f5-4585-b493-29aa89639e6f	/home/inno/compose_ARCHIVED_DO_NOT_USE/volumes/media	3936818806784	12288	\N	2026-01-07 06:30:42.858519+00	Media	0	ext4
f1d9b1b4-8273-486e-94db-a124ce33ba77	/	248215199744	189385797632	\N	2026-01-07 09:24:28.143741+00	System	79.9	ext4
f2d5e2dc-a5e1-468e-80e3-256644de2bca	/home/inno/compose_ARCHIVED_DO_NOT_USE/backups	195762728960	24133632	\N	2026-01-07 09:24:28.145717+00	Backups	0	ext4
1e3b6428-10b4-4960-a793-8f29a80a0d7a	/home/inno/compose_ARCHIVED_DO_NOT_USE/volumes/media	3936818806784	12288	\N	2026-01-07 09:24:28.147323+00	Media	0	ext4
bf2b6a4b-d32b-48db-ae82-86536bbbb940	/	248215199744	139609436160	\N	2026-01-01 02:51:48.525819+00	System	58.9	ext4
f29439de-304d-4c97-9324-b69c5eb32198	/home/inno/compose/backups	195762728960	12288	\N	2026-01-01 02:51:48.530303+00	Backups	0	ext4
6ebaf097-a713-4b01-96f4-7420df020463	/home/inno/compose/volumes/media	3936818806784	12288	\N	2026-01-01 02:51:48.53465+00	Media	0	ext4
cbe1b559-d70a-4cc5-bd7f-4bf893185c34	/	248215199744	139441147904	\N	2026-01-01 03:42:53.146585+00	System	58.8	ext4
88be915c-beac-4edd-9b9a-50eda9123bf4	/home/inno/compose/backups	195762728960	12288	\N	2026-01-01 03:42:53.153842+00	Backups	0	ext4
577fef1e-1f98-4ac4-9a45-4319d91b912a	/home/inno/compose/volumes/media	3936818806784	12288	\N	2026-01-01 03:42:53.158823+00	Media	0	ext4
b342da1f-0eed-4831-a60f-24662510ebbd	/	248215199744	139990036480	\N	2026-01-01 03:47:53.317733+00	System	59.1	ext4
02dee316-1e7e-47f1-9bb3-d66e78468880	/home/inno/compose/backups	195762728960	12288	\N	2026-01-01 03:47:53.32149+00	Backups	0	ext4
c1126d19-3002-4285-bbe5-5064a044ed75	/home/inno/compose/volumes/media	3936818806784	12288	\N	2026-01-01 03:47:53.323401+00	Media	0	ext4
0c3f2646-32cc-4485-ac31-3b9e0f242b0e	/	248215199744	140036456448	\N	2026-01-01 03:52:53.337196+00	System	59.1	ext4
f1ce062a-4444-455d-a2ef-4927072df7bf	/home/inno/compose/backups	195762728960	12288	\N	2026-01-01 03:52:53.345103+00	Backups	0	ext4
df8eac22-8689-490f-bf74-91b44b07bbc0	/home/inno/compose/volumes/media	3936818806784	12288	\N	2026-01-01 03:52:53.347647+00	Media	0	ext4
1b63f1c1-e066-460e-a742-4f8faba18c3d	/	248215199744	141190787072	\N	2026-01-01 12:46:15.964165+00	System	59.6	ext4
0f11392c-3551-4140-89d5-0f8c7c1e36ea	/home/inno/compose/backups	195762728960	12288	\N	2026-01-01 12:46:15.983493+00	Backups	0	ext4
351fb44d-4615-4de9-9c39-a2815dfda025	/home/inno/compose/volumes/media	3936818806784	12288	\N	2026-01-01 12:46:15.997059+00	Media	0	ext4
2377b008-f943-4a25-a873-f334f02d5977	/	248215199744	100379148288	\N	2026-01-01 12:51:16.162968+00	System	42.4	ext4
f7dfe174-e0fb-4179-8821-d2ab273f940e	/home/inno/compose/backups	195762728960	12288	\N	2026-01-01 12:51:16.16661+00	Backups	0	ext4
82f50a10-9325-4f81-af20-ce3f426f7cd0	/home/inno/compose/volumes/media	3936818806784	12288	\N	2026-01-01 12:51:16.167987+00	Media	0	ext4
159c77a2-5873-45a3-92b5-a7597f18c23c	/	248215199744	100376694784	\N	2026-01-01 12:56:16.170402+00	System	42.4	ext4
7315809b-aa13-4084-b1ee-ba164b7f63bf	/home/inno/compose/backups	195762728960	12288	\N	2026-01-01 12:56:16.172666+00	Backups	0	ext4
89cc26b7-003e-42b4-835e-09949823424d	/home/inno/compose/volumes/media	3936818806784	12288	\N	2026-01-01 12:56:16.173636+00	Media	0	ext4
1a75091a-e40f-44ce-ae9a-0e7d03bf0883	/	248215199744	100413566976	\N	2026-01-01 13:01:16.254289+00	System	42.4	ext4
ba4090b6-6533-41e2-a444-334e1398d080	/home/inno/compose/backups	195762728960	12062720	\N	2026-01-01 13:01:16.256468+00	Backups	0	ext4
8d81096a-bf10-4f11-9574-326e0c9c268e	/home/inno/compose/volumes/media	3936818806784	12288	\N	2026-01-01 13:01:16.257482+00	Media	0	ext4
c9159e68-621d-4acb-8c91-61caa8949528	/	248215199744	100840611840	\N	2026-01-01 13:06:16.391089+00	System	42.6	ext4
1eb5faba-17b6-4d7b-b506-1a06e00c2705	/home/inno/compose/backups	195762728960	12062720	\N	2026-01-01 13:06:16.393031+00	Backups	0	ext4
62894b9e-a72b-444a-8c29-fddbbf3b87a3	/home/inno/compose/volumes/media	3936818806784	12288	\N	2026-01-01 13:06:16.393974+00	Media	0	ext4
d6c90673-960c-4d80-9e4d-e2ba8c0994b9	/	248215199744	100841603072	\N	2026-01-01 13:11:16.406807+00	System	42.6	ext4
c5c78249-7258-4d48-b6f0-8b1b007560c6	/home/inno/compose/backups	195762728960	12062720	\N	2026-01-01 13:11:16.410195+00	Backups	0	ext4
69fb395b-c707-4a5b-a8ff-b965f314e2cc	/home/inno/compose/volumes/media	3936818806784	12288	\N	2026-01-01 13:11:16.413803+00	Media	0	ext4
c048644b-8df3-4249-9a80-0f6966057a45	/	248215199744	100958748672	\N	2026-01-01 13:16:16.359817+00	System	42.6	ext4
1f3b6dbe-2353-4eac-9f69-c1cfc79ad93f	/home/inno/compose/backups	195762728960	12062720	\N	2026-01-01 13:16:16.361879+00	Backups	0	ext4
81c222eb-7463-4015-9c23-22d85efcdf2b	/home/inno/compose/volumes/media	3936818806784	12288	\N	2026-01-01 13:16:16.362923+00	Media	0	ext4
efd8a1e0-2f52-4364-8464-26df1a1e88cd	/	248215199744	100959793152	\N	2026-01-01 13:21:16.302381+00	System	42.6	ext4
c7a06ba6-64f9-42fa-b267-f622db48d9b0	/home/inno/compose/backups	195762728960	12062720	\N	2026-01-01 13:21:16.304413+00	Backups	0	ext4
c96f2e4d-9f62-465b-a8be-80d5d27bf29d	/home/inno/compose/volumes/media	3936818806784	12288	\N	2026-01-01 13:21:16.305411+00	Media	0	ext4
97256024-cd4b-4b33-a366-ee5ea27c16f2	/	248215199744	100969447424	\N	2026-01-01 13:26:16.332516+00	System	42.6	ext4
60641077-ace5-425e-8e1a-0cbf5c003581	/home/inno/compose/backups	195762728960	12062720	\N	2026-01-01 13:26:16.334603+00	Backups	0	ext4
7676b665-9c70-4c34-bdb1-e0255d1c0aa7	/home/inno/compose/volumes/media	3936818806784	12288	\N	2026-01-01 13:26:16.335686+00	Media	0	ext4
d22bab38-5563-4926-a23f-163e0d6c05dd	/	248215199744	100970475520	\N	2026-01-01 13:31:16.404736+00	System	42.6	ext4
541898a3-a1e8-4f0a-ad9e-7cde6c4543fb	/home/inno/compose/backups	195762728960	12062720	\N	2026-01-01 13:31:16.407331+00	Backups	0	ext4
a2386594-c916-4b47-b6b9-6ab1aa9daf23	/home/inno/compose/volumes/media	3936818806784	12288	\N	2026-01-01 13:31:16.409346+00	Media	0	ext4
f88d2cfa-9f20-458e-8c8f-9c77cafa37ba	/	248215199744	100971438080	\N	2026-01-01 13:36:16.468985+00	System	42.6	ext4
ff5c38b9-e726-4c1e-89de-f19b34b469fd	/home/inno/compose/backups	195762728960	12062720	\N	2026-01-01 13:36:16.471521+00	Backups	0	ext4
3ac3276c-81f5-40c2-a1b0-7fee6efb249e	/home/inno/compose/volumes/media	3936818806784	12288	\N	2026-01-01 13:36:16.472648+00	Media	0	ext4
c7655b92-bcc1-4cb5-a65c-25a3fbcb6118	/	248215199744	100993384448	\N	2026-01-01 13:41:16.483769+00	System	42.6	ext4
dfda0884-cafc-42f3-a00b-1726f166293c	/home/inno/compose/backups	195762728960	12062720	\N	2026-01-01 13:41:16.486598+00	Backups	0	ext4
3a210e64-2772-44c2-88c9-cb0bef5eb5c3	/home/inno/compose/volumes/media	3936818806784	12288	\N	2026-01-01 13:41:16.488626+00	Media	0	ext4
6f8a26dd-f230-4406-8cc0-ee0467b9382f	/	248215199744	100994650112	\N	2026-01-01 13:46:16.397888+00	System	42.6	ext4
396e1000-294d-4006-b373-d274b9887823	/home/inno/compose/backups	195762728960	12062720	\N	2026-01-01 13:46:16.399413+00	Backups	0	ext4
9745fcdc-a612-43d9-a8f3-63c1d160c814	/home/inno/compose/volumes/media	3936818806784	12288	\N	2026-01-01 13:46:16.400596+00	Media	0	ext4
84e8f49c-9b02-4f4a-9512-9ee9d8030f33	/	248215199744	100996038656	\N	2026-01-01 13:51:16.532467+00	System	42.6	ext4
47f45a98-02c1-4f8e-b8ad-facd70999485	/home/inno/compose/backups	195762728960	12062720	\N	2026-01-01 13:51:16.535678+00	Backups	0	ext4
2653a02c-61ac-4ea7-bc1e-ec9202d9799f	/home/inno/compose/volumes/media	3936818806784	12288	\N	2026-01-01 13:51:16.536795+00	Media	0	ext4
b53ab26e-4a9d-40de-ac28-3174b5fbf383	/	248215199744	100996993024	\N	2026-01-01 13:56:16.390821+00	System	42.6	ext4
185d7d21-641f-43dd-996f-eaab63b281df	/home/inno/compose/backups	195762728960	12062720	\N	2026-01-01 13:56:16.39278+00	Backups	0	ext4
49332a95-74cf-45d7-938d-9fc227630c10	/home/inno/compose/volumes/media	3936818806784	12288	\N	2026-01-01 13:56:16.393773+00	Media	0	ext4
10d6389e-7ba1-4a2c-acc2-0761ada9f6ee	/	248215199744	100997324800	\N	2026-01-01 14:01:16.423657+00	System	42.6	ext4
c4fe2c79-124c-4f65-bcf9-0801afe73791	/home/inno/compose/backups	195762728960	12062720	\N	2026-01-01 14:01:16.425827+00	Backups	0	ext4
7bd18257-ed09-41da-bfe8-8a38d94ef94c	/home/inno/compose/volumes/media	3936818806784	12288	\N	2026-01-01 14:01:16.426846+00	Media	0	ext4
61b122d2-47ed-41ac-b9ea-80d9b4f6b9e0	/	248215199744	100997922816	\N	2026-01-01 14:06:16.433172+00	System	42.6	ext4
cf54195b-ef3c-4aa7-9f62-89c5c0af3a27	/home/inno/compose/backups	195762728960	12062720	\N	2026-01-01 14:06:16.435107+00	Backups	0	ext4
b7ec7bc5-f1e9-4945-8e1a-47861f605276	/home/inno/compose/volumes/media	3936818806784	12288	\N	2026-01-01 14:06:16.436496+00	Media	0	ext4
695e657c-fb65-4278-a816-bbc63110f7a2	/	248215199744	100998537216	\N	2026-01-01 14:11:16.463223+00	System	42.6	ext4
c9e14425-b4fe-4fd5-b814-ca95113b89a3	/home/inno/compose/backups	195762728960	12062720	\N	2026-01-01 14:11:16.466021+00	Backups	0	ext4
97563577-a20d-48ac-84a3-d7ffa0f0f4fc	/home/inno/compose/volumes/media	3936818806784	12288	\N	2026-01-01 14:11:16.46718+00	Media	0	ext4
8506ed6a-2bef-4d27-80dc-39e3c7f1014e	/	248215199744	101370449920	\N	2026-01-01 14:16:16.677954+00	System	42.8	ext4
3e5a0e06-404f-4b6c-86ee-a7ff004afc72	/home/inno/compose/backups	195762728960	12062720	\N	2026-01-01 14:16:16.684569+00	Backups	0	ext4
70cef7cc-f37c-4f11-bd9d-adb6f8790ee9	/home/inno/compose/volumes/media	3936818806784	12288	\N	2026-01-01 14:16:16.686899+00	Media	0	ext4
5cf311cd-2d3a-42f3-bbd6-03a5f2710c98	/	248215199744	101393702912	\N	2026-01-01 14:21:16.460763+00	System	42.8	ext4
4048b5f2-8ca8-41c3-ae3c-2f527edb1f65	/home/inno/compose/backups	195762728960	12062720	\N	2026-01-01 14:21:16.46273+00	Backups	0	ext4
5a7f956c-9980-4a1b-9ea3-210affe1d329	/home/inno/compose/volumes/media	3936818806784	12288	\N	2026-01-01 14:21:16.46365+00	Media	0	ext4
e2fa3861-4e0b-4073-b535-69dbd2614c23	/	248215199744	101420724224	\N	2026-01-01 14:26:16.533967+00	System	42.8	ext4
7f87ceb0-990d-4878-9d52-0428b3f4a6cd	/home/inno/compose/backups	195762728960	12062720	\N	2026-01-01 14:26:16.536654+00	Backups	0	ext4
99d6895c-991c-4de7-9df9-7bb7011b4d34	/home/inno/compose/volumes/media	3936818806784	12288	\N	2026-01-01 14:26:16.538213+00	Media	0	ext4
c0629a17-0c63-4e48-8de8-908923478078	/	248215199744	101450289152	\N	2026-01-01 14:31:16.524997+00	System	42.8	ext4
a2ccb840-dfc0-4ac6-ade6-d4d496d99b36	/home/inno/compose/backups	195762728960	12062720	\N	2026-01-01 14:31:16.527164+00	Backups	0	ext4
b06dcd59-00d2-4034-b218-7bda5eadd6e3	/home/inno/compose/volumes/media	3936818806784	12288	\N	2026-01-01 14:31:16.528611+00	Media	0	ext4
90082e01-ecfd-4ad2-b771-60ebb707d23a	/	248215199744	101448101888	\N	2026-01-01 14:36:16.54355+00	System	42.8	ext4
e5e2181e-888c-44e9-a5ff-0c26ed3407c6	/home/inno/compose/backups	195762728960	12062720	\N	2026-01-01 14:36:16.545992+00	Backups	0	ext4
ba250844-eac4-4770-a49f-7c7fd3bf6b27	/home/inno/compose/volumes/media	3936818806784	12288	\N	2026-01-01 14:36:16.547118+00	Media	0	ext4
03ad9050-84b0-4d6c-bbee-08a983029007	/	248215199744	101448794112	\N	2026-01-01 14:41:16.561211+00	System	42.8	ext4
18c98ae7-85af-4b11-aa2e-2737ae761a45	/home/inno/compose/backups	195762728960	12062720	\N	2026-01-01 14:41:16.564187+00	Backups	0	ext4
1c166847-007a-49ea-b0e9-902d37ffb71c	/home/inno/compose/volumes/media	3936818806784	12288	\N	2026-01-01 14:41:16.565351+00	Media	0	ext4
a799e485-cb7b-4455-8104-ea9ae21bf011	/	248215199744	101466013696	\N	2026-01-01 14:46:16.598235+00	System	42.8	ext4
e2e8cf26-8c0d-44e2-b9bf-3aedf1bdf357	/home/inno/compose/backups	195762728960	12062720	\N	2026-01-01 14:46:16.600096+00	Backups	0	ext4
89d38c34-b3d2-44ab-bc11-62cf3d3a4ae4	/home/inno/compose/volumes/media	3936818806784	12288	\N	2026-01-01 14:46:16.602192+00	Media	0	ext4
f9dedf83-da3c-4540-894f-9f96a1d9f548	/	248215199744	101466595328	\N	2026-01-01 14:51:16.618196+00	System	42.8	ext4
3afabd97-0a6d-4540-a072-3de005423df3	/home/inno/compose/backups	195762728960	12062720	\N	2026-01-01 14:51:16.620133+00	Backups	0	ext4
81ef5b59-f635-47b2-a562-2874563b429f	/home/inno/compose/volumes/media	3936818806784	12288	\N	2026-01-01 14:51:16.621098+00	Media	0	ext4
8eeeb567-36a9-4c37-a60c-c4382eff21ef	/	248215199744	101471473664	\N	2026-01-01 14:56:16.560866+00	System	42.8	ext4
fd673cd9-eb6d-42c6-b1a3-f8dda27c0dd7	/home/inno/compose/backups	195762728960	12062720	\N	2026-01-01 14:56:16.564468+00	Backups	0	ext4
154ee624-c651-4258-9eaa-afaa56e8880a	/home/inno/compose/volumes/media	3936818806784	12288	\N	2026-01-01 14:56:16.565518+00	Media	0	ext4
c57efc6b-45fb-45c1-893c-542ad2ec697b	/	248215199744	101471879168	\N	2026-01-01 15:01:16.589992+00	System	42.8	ext4
5cacb5f9-55a3-4191-839e-c475ba927ab0	/home/inno/compose/backups	195762728960	12062720	\N	2026-01-01 15:01:16.592191+00	Backups	0	ext4
74b05a23-634a-4be6-a1cd-199db6204546	/home/inno/compose/volumes/media	3936818806784	12288	\N	2026-01-01 15:01:16.595131+00	Media	0	ext4
9ed5b9fa-a0c8-4f22-96ac-9cbc1323b7fd	/	248215199744	101472157696	\N	2026-01-01 15:06:16.765778+00	System	42.8	ext4
303ec6ee-3123-4d43-90d3-ec434d3e3fc3	/home/inno/compose/backups	195762728960	12062720	\N	2026-01-01 15:06:16.768677+00	Backups	0	ext4
d9a9d5eb-a5b3-4d16-8bf4-c5db9df5ced2	/home/inno/compose/volumes/media	3936818806784	12288	\N	2026-01-01 15:06:16.769836+00	Media	0	ext4
be89d259-79e6-41b4-81e1-4e2d478fcb45	/	248215199744	101472485376	\N	2026-01-01 15:11:16.604768+00	System	42.8	ext4
d799c5ad-26ab-4928-a8b6-3e7ef1eaf567	/home/inno/compose/backups	195762728960	12062720	\N	2026-01-01 15:11:16.606722+00	Backups	0	ext4
120c4ea3-aeec-40cb-a6d5-38dc613c2664	/home/inno/compose/volumes/media	3936818806784	12288	\N	2026-01-01 15:11:16.607658+00	Media	0	ext4
75d6408c-39e3-4b0c-ba20-02eb4c37d038	/	248215199744	152271306752	\N	2026-01-06 15:25:41.109413+00	System	64.3	ext4
e288917c-e8b4-49e7-8e79-a6e26f111a2d	/home/inno/compose/backups	195762728960	24133632	\N	2026-01-06 15:25:41.114438+00	Backups	0	ext4
91e03ee8-72a8-41f8-bc32-952744b38cb9	/home/inno/compose/volumes/media	3936818806784	12288	\N	2026-01-06 15:25:41.115531+00	Media	0	ext4
07400cc2-7e40-4a2b-87d5-7cdc0688e358	/	248215199744	152274268160	\N	2026-01-06 15:35:41.008909+00	System	64.3	ext4
8380f4fa-f93d-4b8b-87a9-3f2e185ed919	/home/inno/compose/backups	195762728960	24133632	\N	2026-01-06 15:35:41.015118+00	Backups	0	ext4
005743c7-a40a-4d09-8bc9-14d1667fcd47	/home/inno/compose/volumes/media	3936818806784	12288	\N	2026-01-06 15:35:41.017169+00	Media	0	ext4
03eec1d4-d7f0-467e-b8e1-f40df794de22	/	248215199744	152275746816	\N	2026-01-06 15:45:41.025316+00	System	64.3	ext4
1765c859-9580-4909-8788-d76885218579	/home/inno/compose_ARCHIVED_DO_NOT_USE/backups	195762728960	24133632	\N	2026-01-06 15:45:41.027432+00	Backups	0	ext4
5d00784c-f8b6-4fd7-b5cd-bfd8ef8756a0	/home/inno/compose_ARCHIVED_DO_NOT_USE/volumes/media	3936818806784	12288	\N	2026-01-06 15:45:41.028396+00	Media	0	ext4
3764ed04-e26c-4955-b4ea-60aa9d7d9481	/	248215199744	152277274624	\N	2026-01-06 15:55:41.061768+00	System	64.3	ext4
947a01df-6f8c-4a5b-9187-e05479c2090b	/home/inno/compose_ARCHIVED_DO_NOT_USE/backups	195762728960	24133632	\N	2026-01-06 15:55:41.067951+00	Backups	0	ext4
842ceca2-bbfb-4a36-836c-8744dfee885e	/home/inno/compose_ARCHIVED_DO_NOT_USE/volumes/media	3936818806784	12288	\N	2026-01-06 15:55:41.070214+00	Media	0	ext4
85abdf9e-c197-4d6e-9a6e-beffefa0fed9	/	248215199744	152824573952	\N	2026-01-06 16:05:41.053355+00	System	64.5	ext4
750cdceb-5dc9-4db8-8c5e-2fd67175191d	/home/inno/compose_ARCHIVED_DO_NOT_USE/backups	195762728960	24133632	\N	2026-01-06 16:05:41.056012+00	Backups	0	ext4
00912d3a-575f-4f59-8c63-c4623cabecf7	/home/inno/compose_ARCHIVED_DO_NOT_USE/volumes/media	3936818806784	12288	\N	2026-01-06 16:05:41.058045+00	Media	0	ext4
09b738ea-10ac-4cc3-9d2b-5e2377dea632	/	248215199744	164905607168	\N	2026-01-06 18:55:41.64357+00	System	69.6	ext4
dfa56ca2-ffe4-4123-af04-8b82ab8bf758	/home/inno/compose_ARCHIVED_DO_NOT_USE/backups	195762728960	24133632	\N	2026-01-06 18:55:41.65192+00	Backups	0	ext4
4d37f212-6d96-4606-bad4-18778c01ffb0	/home/inno/compose_ARCHIVED_DO_NOT_USE/volumes/media	3936818806784	12288	\N	2026-01-06 18:55:41.653878+00	Media	0	ext4
4885f89f-0d9e-481b-86e9-b0b08fe69180	/	248215199744	173793501184	\N	2026-01-06 21:50:42.159831+00	System	73.3	ext4
61d50253-697d-496d-8c10-8f8b0f785997	/home/inno/compose_ARCHIVED_DO_NOT_USE/backups	195762728960	24133632	\N	2026-01-06 21:50:42.16194+00	Backups	0	ext4
59dbec59-00af-4856-b518-440a2b43304f	/home/inno/compose_ARCHIVED_DO_NOT_USE/volumes/media	3936818806784	12288	\N	2026-01-06 21:50:42.163507+00	Media	0	ext4
24dd3b04-5c8c-42fc-9cf7-c6dc31d2294a	/	248215199744	173794000896	\N	2026-01-07 00:45:42.464539+00	System	73.3	ext4
61ebfd3c-8675-4181-82f2-2f1a94e2c317	/home/inno/compose_ARCHIVED_DO_NOT_USE/backups	195762728960	24133632	\N	2026-01-07 00:45:42.467006+00	Backups	0	ext4
3975bc33-1de4-4f73-9d54-bafb75778037	/home/inno/compose_ARCHIVED_DO_NOT_USE/volumes/media	3936818806784	12288	\N	2026-01-07 00:45:42.468038+00	Media	0	ext4
be92fe86-36f7-44af-9821-2e68fdc9a4d5	/	248215199744	173787193344	\N	2026-01-07 03:40:42.66739+00	System	73.3	ext4
45933043-64d0-4fb1-86bf-f14f1b5cf88f	/home/inno/compose_ARCHIVED_DO_NOT_USE/backups	195762728960	24133632	\N	2026-01-07 03:40:42.669391+00	Backups	0	ext4
daaad512-2887-4a6f-9c61-5fbea3633e47	/home/inno/compose_ARCHIVED_DO_NOT_USE/volumes/media	3936818806784	12288	\N	2026-01-07 03:40:42.670412+00	Media	0	ext4
5794311d-e28a-4f0e-80bf-6925707fa9ca	/	248215199744	173907869696	\N	2026-01-07 06:35:42.856183+00	System	73.4	ext4
eaf2d7d0-12a7-439c-a0cd-2ddbbc3fe3d4	/home/inno/compose_ARCHIVED_DO_NOT_USE/backups	195762728960	24133632	\N	2026-01-07 06:35:42.862708+00	Backups	0	ext4
1c95a1fa-6472-47d4-98f8-3affbd28e5df	/home/inno/compose_ARCHIVED_DO_NOT_USE/volumes/media	3936818806784	12288	\N	2026-01-07 06:35:42.864645+00	Media	0	ext4
c92fc490-7c53-45ec-aa6f-0e9550fec998	/	248215199744	209892302848	\N	2026-01-07 09:27:56.858647+00	System	88.6	ext4
f249c035-3b7b-454f-bab7-b3bf1ce8b23e	/home/inno/compose_ARCHIVED_DO_NOT_USE/backups	195762728960	24133632	\N	2026-01-07 09:27:56.860789+00	Backups	0	ext4
d61f468f-543b-464b-82e8-885f74c793d3	/home/inno/compose_ARCHIVED_DO_NOT_USE/volumes/media	3936818806784	12288	\N	2026-01-07 09:27:56.862112+00	Media	0	ext4
77971b2a-3b0d-4b74-a59d-a974e601d176	/	248215199744	152273469440	\N	2026-01-06 15:30:40.992157+00	System	64.3	ext4
8512976f-44b1-4825-837d-2f75004b9735	/home/inno/compose/backups	195762728960	24133632	\N	2026-01-06 15:30:40.998953+00	Backups	0	ext4
1520d8d4-c5af-47be-8b33-63a71b42a1e9	/home/inno/compose/volumes/media	3936818806784	12288	\N	2026-01-06 15:30:41.001057+00	Media	0	ext4
c6bbb220-59a8-4ed5-874b-0bc17b41758d	/	248215199744	152274915328	\N	2026-01-06 15:40:41.007003+00	System	64.3	ext4
9cbd0b80-7771-415d-ac64-96b67918a5a3	/home/inno/compose/backups	195762728960	24133632	\N	2026-01-06 15:40:41.011555+00	Backups	0	ext4
ea04784e-94b0-4b97-8d63-2464857c5b2a	/home/inno/compose/volumes/media	3936818806784	12288	\N	2026-01-06 15:40:41.012824+00	Media	0	ext4
0c8db617-8a8e-440b-a81f-b5f6c2fdc463	/	248215199744	152276156416	\N	2026-01-06 15:50:41.042287+00	System	64.3	ext4
661c7293-cec6-4d57-b48b-aca6537947cd	/home/inno/compose_ARCHIVED_DO_NOT_USE/backups	195762728960	24133632	\N	2026-01-06 15:50:41.048462+00	Backups	0	ext4
74c65685-2445-43b7-afd5-cdcf5874adc5	/home/inno/compose_ARCHIVED_DO_NOT_USE/volumes/media	3936818806784	12288	\N	2026-01-06 15:50:41.050717+00	Media	0	ext4
92d1c563-abed-4d55-976b-1440e48aae13	/	248215199744	152775270400	\N	2026-01-06 16:00:41.056175+00	System	64.5	ext4
4be46bce-b2f9-4bb8-a909-c1b212ebb3f8	/home/inno/compose_ARCHIVED_DO_NOT_USE/backups	195762728960	24133632	\N	2026-01-06 16:00:41.060547+00	Backups	0	ext4
e3a7ded7-ddb0-4644-b432-aae52d4b4225	/home/inno/compose_ARCHIVED_DO_NOT_USE/volumes/media	3936818806784	12288	\N	2026-01-06 16:00:41.061689+00	Media	0	ext4
92a361a9-d465-489f-8174-012fa2e0568f	/	248215199744	165287653376	\N	2026-01-06 19:00:41.654928+00	System	69.7	ext4
64b4bfd8-7980-4c1d-9f79-dd01f059052c	/home/inno/compose_ARCHIVED_DO_NOT_USE/backups	195762728960	24133632	\N	2026-01-06 19:00:41.661133+00	Backups	0	ext4
f4ab9807-9f62-4324-9c72-c03b4e1a4dcb	/home/inno/compose_ARCHIVED_DO_NOT_USE/volumes/media	3936818806784	12288	\N	2026-01-06 19:00:41.663371+00	Media	0	ext4
a6a301ae-2730-4f84-9343-a57efc083aae	/	248215199744	173793509376	\N	2026-01-06 21:55:42.254172+00	System	73.3	ext4
9aaf8a8b-be4e-41c9-afe2-f65dbb26839d	/home/inno/compose_ARCHIVED_DO_NOT_USE/backups	195762728960	24133632	\N	2026-01-06 21:55:42.256481+00	Backups	0	ext4
569c5bfc-ce02-4e4f-9490-311cc853cc68	/home/inno/compose_ARCHIVED_DO_NOT_USE/volumes/media	3936818806784	12288	\N	2026-01-06 21:55:42.257452+00	Media	0	ext4
f0ee0bd2-3a95-4464-a52d-c546c7700754	/	248215199744	173793992704	\N	2026-01-07 00:50:42.485108+00	System	73.3	ext4
f2219af9-52ab-4db1-96c3-d4f97e98c34d	/home/inno/compose_ARCHIVED_DO_NOT_USE/backups	195762728960	24133632	\N	2026-01-07 00:50:42.487805+00	Backups	0	ext4
a13b55a9-373f-4e3d-a0cf-0de450854639	/home/inno/compose_ARCHIVED_DO_NOT_USE/volumes/media	3936818806784	12288	\N	2026-01-07 00:50:42.488924+00	Media	0	ext4
a3ad75c0-1ac5-462b-a593-a3786189147c	/	248215199744	173783863296	\N	2026-01-07 03:45:42.658596+00	System	73.3	ext4
d5a6d94c-a5c3-4331-87a1-c48395fe371f	/home/inno/compose_ARCHIVED_DO_NOT_USE/backups	195762728960	24133632	\N	2026-01-07 03:45:42.660584+00	Backups	0	ext4
50cd4c10-0b72-49c6-ba6a-947f5673dab9	/home/inno/compose_ARCHIVED_DO_NOT_USE/volumes/media	3936818806784	12288	\N	2026-01-07 03:45:42.661539+00	Media	0	ext4
899d6e76-e632-426a-ab04-71440e97b330	/	248215199744	173905362944	\N	2026-01-07 06:40:42.859406+00	System	73.4	ext4
76ce1c18-911a-4929-9988-591ee374b634	/home/inno/compose_ARCHIVED_DO_NOT_USE/backups	195762728960	24133632	\N	2026-01-07 06:40:42.865738+00	Backups	0	ext4
c670e090-fb44-4f72-ab43-eaca3c17e781	/home/inno/compose_ARCHIVED_DO_NOT_USE/volumes/media	3936818806784	12288	\N	2026-01-07 06:40:42.867795+00	Media	0	ext4
1dba4520-c287-459c-a1bb-a7f3ebfe1a04	/	248215199744	189402431488	\N	2026-01-07 09:32:56.955106+00	System	79.9	ext4
a476e41c-bb18-4fb6-92fe-0cd15f7bfada	/home/inno/compose_ARCHIVED_DO_NOT_USE/backups	195762728960	24133632	\N	2026-01-07 09:32:56.967235+00	Backups	0	ext4
8287674b-33b9-4701-8529-778e669f781f	/home/inno/compose_ARCHIVED_DO_NOT_USE/volumes/media	3936818806784	12288	\N	2026-01-07 09:32:56.972665+00	Media	0	ext4
\.


--
-- Data for Name: dns_configs; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.dns_configs (id, name, primary_dns, secondary_dns, is_active, created_at, updated_at) FROM stdin;
\.


--
-- Data for Name: firewall_rules; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.firewall_rules (id, port, from_ip, protocol, comment, is_active, created_at, updated_at) FROM stdin;
\.


--
-- Data for Name: media_channels; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.media_channels (id, name, platform, channel_url, subscribers, views, engagement, growth, videos_count, is_active, created_at, updated_at, channel_id, username, last_synced_at, is_monetized, watch_hours, avg_view_duration, ctr, revenue, likes, comments, shares) FROM stdin;
\.


--
-- Data for Name: monitored_hosts; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.monitored_hosts (id, name, ip, port, description, status, last_check_at, response_time_ms, created_at) FROM stdin;
\.


--
-- Data for Name: network_traffic; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.network_traffic (id, interface, rx_bytes, tx_bytes, recorded_at) FROM stdin;
\.


--
-- Data for Name: security_settings; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.security_settings (id, ufw_status, fail2ban_status, ssh_port, last_check_at, created_at, updated_at) FROM stdin;
\.


--
-- Data for Name: service_uptime; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.service_uptime (id, service_id, status, response_time_ms, checked_at) FROM stdin;
\.


--
-- Data for Name: services; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.services (id, name, description, category, port, url, icon, is_active, status, last_check_at, response_time_ms, created_at, updated_at) FROM stdin;
e236e8d4-35bd-4db2-9796-a540e9f4bef8	PostgreSQL	Auto-seeded service	core	5432	http://192.168.1.220:5432	server	t	unknown	\N	\N	2026-01-01 14:55:46.191279+00	2026-01-06 16:32:38.160967+00
f3e8ec2a-4e5f-4a14-8f54-428c167b32be	Redis	Auto-seeded service	core	6379	http://192.168.1.220:6379	server	t	unknown	\N	\N	2026-01-01 14:55:46.197631+00	2026-01-06 16:32:38.160967+00
ed6aa021-52e4-4726-9328-e9360620b3dc	n8n	Workflow automation	work	5678	http://192.168.1.220:5678	workflow	t	online	2025-12-27 13:07:02.413+00	\N	2025-12-25 09:24:40.422904+00	2026-01-06 16:32:38.160967+00
1b2f869e-8f01-44c3-8190-2af546a945b6	File Browser	File manager	data	8082	http://192.168.1.220:8082	folder-open	t	offline	2026-01-01 12:18:10.004+00	\N	2025-12-25 09:24:40.422904+00	2026-01-06 16:32:38.160967+00
480ccbf3-f29d-44ed-9b54-ed94a95b5fbf	Grafana	Analytics	data	3001	http://192.168.1.220:3001	bar-chart-3	t	online	2026-01-01 13:52:22.131+00	\N	2025-12-25 09:24:40.422904+00	2026-01-06 16:32:38.160967+00
70a8cfbc-706c-4afe-ad03-0db149cf002b	Portainer	Docker management	admin	9000	http://192.168.1.220:9000	container	t	online	2026-01-07 08:55:54.658+00	\N	2025-12-25 09:24:40.422904+00	2026-01-07 08:55:55.300679+00
90cea327-f747-473a-bdbd-fe76ab78469f	WireGuard	VPN management	admin	5003	http://192.168.1.220:5003	key	t	offline	2026-01-07 08:55:54.658+00	\N	2025-12-25 09:24:40.422904+00	2026-01-07 08:55:55.314149+00
9f81017c-4bab-4c2a-a748-516c2f49f3f6	Nginx Proxy Manager	Reverse proxy	admin	81	http://192.168.1.220:81	shield	t	online	2026-01-07 08:55:54.658+00	\N	2025-12-25 09:24:40.422904+00	2026-01-07 08:55:55.302101+00
214d0640-eefa-49d5-b1e3-3877928771d2	AI Chat (Ollama)	Auto-seeded service	ai	11434	http://192.168.1.220:11434	server	t	online	2026-01-07 08:50:06.777+00	\N	2026-01-01 14:55:46.160287+00	2026-01-07 08:50:07.443288+00
0e0c3c71-2792-40d4-b490-f1f9bc453959	Nextcloud	Cloud storage	data	8081	http://192.168.1.220:8081	cloud	t	online	2026-01-01 12:56:49.83+00	\N	2025-12-25 09:24:40.422904+00	2026-01-06 16:32:38.160967+00
4e7dfe70-9aeb-4da3-a3c1-169ab0cb1a7a	Browserless	Auto-seeded service	automation	3002	http://192.168.1.220:3000	server	t	unknown	\N	\N	2026-01-01 14:55:46.221089+00	2026-01-06 16:32:38.160967+00
1bbd0940-0447-4e3e-beb0-067c080cae5c	YouTube DL	Auto-seeded service	media	8084	http://192.168.1.220:8080	server	t	unknown	\N	\N	2026-01-01 14:55:46.231543+00	2026-01-06 16:32:38.160967+00
bdda51e8-d47f-4ffa-8fe5-52fcaeabd4a3	VPN Manager	Auto-seeded service	network	5001	http://192.168.1.220:5000	server	t	unknown	\N	\N	2026-01-01 14:55:46.241115+00	2026-01-06 16:32:38.160967+00
c0eba0da-2c13-47f6-9593-8f62c3d6f5c6	Channel Manager	Auto-seeded service	network	5002	http://192.168.1.220:5002	server	t	unknown	\N	\N	2026-01-01 14:55:46.246107+00	2026-01-06 16:32:38.160967+00
f4465856-2804-4cb6-99dc-a3806d401615	Healthchecks	Auto-seeded service	system	8001	http://192.168.1.220:8000	server	t	unknown	\N	\N	2026-01-01 14:55:46.25073+00	2026-01-06 16:32:38.160967+00
5e68a0bf-f28b-4352-a36b-a2cd3307b165	Homepage	Auto-seeded service	system	3000	http://192.168.1.220:3000	server	t	unknown	\N	\N	2026-01-01 14:55:46.255556+00	2026-01-06 16:32:38.160967+00
20337517-323c-4aa7-84e2-88ca6a459e4d	RSSHub	Auto-seeded service	automation	1200	http://192.168.1.220:1200	server	t	unknown	\N	\N	2026-01-01 14:55:46.267985+00	2026-01-06 16:32:38.160967+00
f349ea73-6a2d-4a63-b9f5-55418a01af2d	AI Transcribe (Whisper)	Auto-seeded service	ai	8000	http://192.168.1.220:8000	server	t	offline	2026-01-07 08:50:41.41+00	\N	2026-01-01 14:55:46.17188+00	2026-01-07 08:50:42.067333+00
7b487875-e402-4148-8266-16f2087dcc41	SAM 2	Сегментация и отслеживание объектов	AI Studio	8787	http://192.168.1.220:8787	Scan	t	offline	2026-01-07 08:55:54.658+00	\N	2025-12-28 10:49:04.587883+00	2026-01-07 08:55:55.295476+00
7bb2387c-9fec-48d9-b87a-1b6448cfb1ef	IOPaint	AI-инпейнтинг для удаления водяных знаков	AI Studio	8585	http://192.168.1.220:8585	Eraser	t	offline	2026-01-07 08:55:54.658+00	\N	2025-12-28 10:49:04.587883+00	2026-01-07 08:55:55.297698+00
2446a289-6066-4a55-a1a6-a114718b1b84	Glances	System monitor	admin	61208	http://192.168.1.220:61208	activity	t	online	2026-01-07 08:55:54.658+00	\N	2025-12-25 09:24:40.422904+00	2026-01-07 08:55:55.306156+00
06702436-22e6-4c67-b057-103e41532e49	Dozzle	Log viewer	admin	8888	http://192.168.1.220:8888	terminal	t	online	2026-01-07 08:55:54.658+00	\N	2025-12-25 09:24:40.422904+00	2026-01-07 08:55:55.305411+00
28c0ad09-0b38-47e3-9d09-6fc0b840ec3e	Video Processor	API обработки видео с FFmpeg	AI Studio	8686	http://192.168.1.220:8686	Video	t	offline	2026-01-07 08:55:54.658+00	\N	2025-12-28 10:49:04.587883+00	2026-01-07 08:55:55.357756+00
6e78e13e-5b23-44f5-99f2-fe15d4057776	Adminer	Database management	admin	8083	http://192.168.1.220:8083	database	t	online	2026-01-07 08:55:54.658+00	\N	2025-12-25 09:24:40.422904+00	2026-01-07 08:55:55.357471+00
3ef43b2b-16f3-4597-8237-715510b967d3	AI TTS (Piper)	Auto-seeded service	ai	10200	http://192.168.1.220:10200	server	t	offline	2026-01-07 08:55:54.659+00	\N	2026-01-01 14:55:46.184769+00	2026-01-07 08:55:55.357663+00
e407d61e-7424-4058-9d99-75cd0ee53708	AI Translate	Auto-seeded service	ai	5000	http://192.168.1.220:5000	server	t	offline	2026-01-07 08:41:58.102+00	\N	2026-01-01 14:55:46.178528+00	2026-01-07 08:41:58.784497+00
\.


--
-- Data for Name: system_metrics; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.system_metrics (id, "timestamp", cpu_percent, ram_percent, net_rx_total, net_tx_total) FROM stdin;
74102aab-9271-4e16-94fe-e0eb0c5aab09	2026-01-06 15:05:40.763257+00	35.8	24.7	28713	12835
6f896dc5-1879-4959-8ad7-a46259fa33c1	2026-01-06 15:06:15.454954+00	34.2	24.3	989149	989149
8171943d-d038-40c8-adeb-dd0025cc5edb	2026-01-06 15:06:29.669924+00	33.1	24.9	330212	330212
5b9b39a3-7f65-4a54-8ed2-0d5f728c363e	2026-01-06 15:06:40.911755+00	29.7	23.9	0	0
2f4731e4-c87a-4961-a7f5-6127cb65bb45	2026-01-06 15:06:51.428447+00	32.3	23.8	1206317	1206317
9546130b-ade3-483c-8737-dddcf9117f76	2026-01-06 15:06:58.24618+00	33.1	23.9	874909	874909
9a54e23c-dddf-4915-a3b1-090a3bb76527	2026-01-06 15:07:15.457057+00	40.4	23.8	1815509	1815509
a982fca0-11eb-4d80-9794-77fb1a0979ed	2026-01-06 15:07:19.121153+00	40	24.4	1498542	1498542
e77f7b5d-976d-445d-b621-c733cb7cdf1a	2026-01-06 15:07:27.611679+00	40.1	24.6	964887	964887
a1d596ab-db18-428f-b179-a0650c84b4c9	2026-01-06 15:07:29.658058+00	37.9	24.6	355574	355574
865901cb-2059-43f6-b569-8bf9004e4c27	2026-01-06 15:07:35.195402+00	39.7	24.6	1860737	1860737
587398ed-e84a-48f1-8d8d-e702e0e9ab06	2026-01-06 15:07:40.939857+00	40.9	24.7	0	0
bff5c785-3b2c-4338-8a9e-4fc38888aaee	2026-01-06 15:07:51.475307+00	38.1	24.7	660154	660154
74c48bf5-67a2-47f2-80b9-99a614414c32	2026-01-06 15:08:09.866935+00	39.8	24.8	1314913	1314913
5cebe23c-3de2-442c-bccd-4d43032d2714	2026-01-06 15:08:15.480152+00	44.6	24.8	790456	790456
87025f8b-29a1-4374-8b5b-45bc989300fe	2026-01-06 15:08:19.091221+00	50.1	24.8	2073556	2073556
7812e926-d6ab-4f09-b754-81a25e1fc333	2026-01-06 15:08:27.49744+00	40.8	25.3	1587236	1587236
603d4402-d167-4a34-a1d9-654008d8afc4	2026-01-06 15:08:29.654089+00	37.3	25.2	1041154	1041154
faf7fafa-fc46-491c-8bdc-d7d64dce11fe	2026-01-06 15:08:40.954888+00	41.5	25.1	0	0
15c44fbb-25e8-4ec0-a759-8c386e06abbc	2026-01-06 15:08:51.443019+00	40.1	25.1	1288479	1288479
468ae5da-dfa1-4563-9998-5ad71c9ab983	2026-01-06 15:09:08.70521+00	38.3	25.1	502059	502059
0e6fcfee-8877-43c1-8f74-6417fbda0270	2026-01-06 15:09:15.484857+00	37.3	25.1	4335952	4335952
8d44c347-4565-4518-87b1-578dca5aa5df	2026-01-06 15:09:19.083366+00	39.5	24.7	4967457	4967457
3034fde8-d9af-433d-bafb-215ab82953d2	2026-01-06 15:09:27.564603+00	42.6	24.8	5385654	5385654
fe67a34f-2f1b-479f-ac02-ccb5dfcbe95f	2026-01-06 15:09:29.707901+00	33.3	24.8	363331	363331
65a6a719-5a22-46be-8ffa-452f405499d6	2026-01-06 15:09:41.036816+00	30.3	25.3	45082	48821
26ea5ca4-8ce7-461a-9545-c27a69bb08cc	2026-01-06 15:09:51.453501+00	37.3	25.3	978445	978445
34a5c607-8536-4c5a-ad5f-6d3bad6f4848	2026-01-06 15:10:08.64183+00	29.6	25.3	633252	633252
32f609ce-c6c9-460d-8f26-663c753b2b10	2026-01-06 15:10:15.507499+00	28.4	25	1025837	1025837
0c508b3c-062c-4bfa-bd46-485267a6a8fd	2026-01-06 15:10:19.14282+00	30.3	25	733308	733308
da8de630-b25a-405b-8fc5-52bb5df65b63	2026-01-06 15:10:27.506794+00	31.8	25	1288245	1288245
c31900ce-a9dc-4bfd-a6cb-e7c042b36674	2026-01-06 15:10:28.671888+00	31.8	24.9	1200965	1200965
e76fae74-0dc7-464a-acad-35201dc5ec4a	2026-01-06 15:10:29.72091+00	30.8	24.9	598283	598283
3723132c-7367-40ae-87d4-f88c46877ae8	2026-01-06 15:10:41.071989+00	41.4	25.1	3376585	1239556
115a6a39-72c6-4eaf-b5b1-395bfe2adf26	2026-01-06 15:10:51.45993+00	43.7	25	1318124	1318124
a7bdda3d-ca83-4a5f-adae-5effe03939a4	2026-01-06 15:11:08.57444+00	31	24.9	812261	812261
006f7b5b-1192-4696-be6d-bc5cce4bd2b2	2026-01-06 15:11:15.506593+00	40.1	25.1	1177834	1177834
43df7e6a-41d4-4f00-9828-ae28c52fc5f7	2026-01-06 15:11:19.056786+00	36.7	25.7	989241	989241
ae7591f2-4ac5-4986-914b-9fdace5b2dc0	2026-01-06 15:11:27.461336+00	36	25.2	1387354	1387354
1f59b90c-2c3b-444f-9b59-b7d0f5178f17	2026-01-06 15:11:28.451071+00	35.9	25.2	797019	797019
0b185781-ce04-40fe-83fa-b2055b1f8b5e	2026-01-06 15:11:29.641906+00	35.6	24.9	806665	806665
1a8bc0a4-e463-45bb-ac46-0338238d5f6d	2026-01-06 15:11:40.9833+00	33	24.1	41633	41681
8fca67d0-18fd-43da-afdc-946326648804	2026-01-06 15:11:51.435812+00	35.3	25.6	723788	723788
45f6142b-af2d-4eb6-a9a1-97a65db862df	2026-01-06 15:12:08.537267+00	35.6	26.1	403049	403049
01814cb4-8d93-47d7-9483-086510c7cd61	2026-01-06 15:12:15.471524+00	33.7	25.1	782405	782405
dfb8c102-4ad6-4a9d-a3c0-f36f4acedc72	2026-01-06 15:12:19.058109+00	33.4	25.4	1210920	1210920
d67417d5-1e58-4819-945f-a55d0b2d787d	2026-01-06 15:12:27.47039+00	35.6	28	686431	686431
a8c674f8-29dd-41c1-81b6-e9aa7c4f79df	2026-01-06 15:12:28.484829+00	35.6	28	728895	728895
4674a720-4dd3-4981-8b18-26632793f0f9	2026-01-06 15:12:29.649774+00	35.5	28.3	933429	933429
994696af-67f5-4a32-815e-9608de2cafe7	2026-01-06 15:12:36.134175+00	32.7	26.5	1000430	1000430
d111ae93-ceba-4407-b2ab-1f58ee4907e6	2026-01-06 15:12:41.015192+00	35.4	24.3	70068	41438
ffe1737c-fec9-4d1d-827b-9d6cb38f1486	2026-01-06 15:12:51.428552+00	35.5	24.2	1381451	1381451
ff5350e0-9f76-47bb-8998-7e5e27c36e2e	2026-01-06 15:13:08.535401+00	37.7	25.6	558974	558974
ec900881-efd3-49f6-9d86-229cfa918a83	2026-01-06 15:13:15.509953+00	35.5	25.6	383546	383546
08a760bf-af2b-4e69-996d-e337933b6e3e	2026-01-06 15:13:19.060565+00	37.5	24.3	763830	763830
25103275-0e47-46b9-892f-d93af4cdac7c	2026-01-06 15:13:27.472727+00	34.9	24.1	801058	801058
02641024-6b23-49ae-b426-19af97d75952	2026-01-06 15:13:28.463624+00	34.9	24.1	468083	468083
9c6103e1-d0af-4591-9a93-18d7618120aa	2026-01-06 15:13:29.657865+00	34.6	24.2	485021	485021
02aa53a2-e5e4-46b2-b13b-b923c8ae8004	2026-01-06 15:13:36.058166+00	37.4	24.2	563555	563555
a3718ced-a0c3-4cba-93e4-87dc5f0ca145	2026-01-06 15:13:41.018016+00	26.9	24.2	76588	49025
9df3349e-4b63-4fd6-a880-035b705887e1	2026-01-06 15:13:51.450618+00	18.3	24.9	642354	642354
0ca6dc78-201e-4fe2-ace2-6755c66fe7c2	2026-01-06 15:14:08.545822+00	20.5	24.9	449259	449259
a53627f4-0b1d-4998-b6a1-720e842c4243	2026-01-06 15:14:15.502441+00	21.9	24.9	485413	485413
21e19083-d2bf-4438-ad35-fea3caa820a8	2026-01-06 15:14:19.059189+00	24.2	24.9	1058065	1058065
1e6629e3-57c4-4532-9680-723720228e80	2026-01-06 15:14:27.498739+00	23	25.5	799675	799675
b3b91f82-30cb-42cd-8387-1fcfb1d6c875	2026-01-06 15:14:28.507417+00	21.1	25.5	697513	697513
9631953c-5d90-4e69-8201-16ea8da142c5	2026-01-06 15:14:29.672064+00	17.1	25.5	419981	419981
f7ca4e7d-5d80-4214-9cc9-af706bcfb9a2	2026-01-06 15:14:36.038465+00	16.8	25.5	996129	996129
e00faf2e-0196-4c38-a480-9a5827a3337b	2026-01-06 15:14:41.029848+00	20.5	25.5	138178	1332528
0e9d38d2-4bde-4061-9142-17bb1def6eb7	2026-01-06 15:14:51.458952+00	23.8	25.7	901087	901087
6870faae-bbc1-409a-b509-e948dea67e3c	2026-01-06 15:15:08.535273+00	19	25.7	893210	893210
a7e88348-d656-4a31-8dda-03d2e18c26a4	2026-01-06 15:15:15.562837+00	19.6	25.4	675486	675486
dac3c75b-7f47-4a60-b1dd-4d1f548a15b1	2026-01-06 15:15:19.097528+00	28	25.2	816353	816353
4b5c48f3-f3ce-4fe1-b9c2-afcf5e4a9a35	2026-01-06 15:15:27.559012+00	25.9	25.4	934670	934670
9a38409e-3c3d-4710-967a-79668039deae	2026-01-06 15:15:28.462969+00	25.9	25.3	1075789	1075789
219b748f-4bf6-4dee-8dcc-d6fe2664534c	2026-01-06 15:15:29.671703+00	21	25.3	540173	540173
ed5aa094-6155-46fb-8ad4-852ffc870890	2026-01-06 15:15:36.032432+00	21.1	25.3	1048080	1048080
7a40a6f9-e34b-40be-b3b0-ab4c7d4e33a9	2026-01-06 15:15:41.07568+00	17.9	25.3	92898	51089
e759ef78-7d15-47c7-a558-1d7a4399ba13	2026-01-06 15:15:51.425178+00	30.2	26.5	1095279	1095279
cda24ecc-a6b3-4bfb-8ef6-8ff7597df5cd	2026-01-06 15:16:08.517925+00	49.3	31.5	557402	557402
9a6a477d-71d8-4290-9afa-1e2373bac7aa	2026-01-06 15:16:15.485919+00	36.5	26.2	844994	844994
61f83ea1-f3ee-43b5-8f06-bd4333f02c57	2026-01-06 15:16:19.072646+00	30.8	26	945270	945270
48ff929b-cdee-4e7a-bc51-21426423e3c6	2026-01-06 15:16:26.293832+00	37.3	25.9	301281	301281
8a43aa07-3c5b-456d-8f7e-03dc36d73629	2026-01-06 15:16:27.53912+00	26.6	26	1256382	1256382
570c3d8b-df70-47c8-8164-1a5b8b51bf0d	2026-01-06 15:16:28.539135+00	26.6	26	3045568	3045568
2785694b-82fd-4f14-82df-2d8f5c8e207f	2026-01-06 15:16:29.72258+00	36.2	26.1	2470106	2470106
26ef91fa-c456-4058-9159-d1a07a7644a7	2026-01-06 15:16:38.148744+00	43.8	25.7	1983409	1983409
b6264d6c-1f4d-42f3-a9c5-1d66b237a302	2026-01-06 15:16:41.088837+00	51.2	25.4	6754788	186653
97e4e25e-8873-493a-878f-6302560ba2a2	2026-01-06 15:16:44.370871+00	45.9	25.4	2469937	2469937
913fec52-d4d3-4c78-8567-56a8d3c06790	2026-01-06 15:16:51.53415+00	48.4	23.9	1004134	1004134
e42a83b2-496c-4a51-8314-3b34e5c99abe	2026-01-06 15:17:08.525144+00	47.9	28.2	408897	408897
e62a1f58-e6cf-4c52-8348-b43cee061216	2026-01-06 15:17:15.484516+00	35.6	27.1	741199	741199
709d1f7b-5c77-485c-9951-6af79841a872	2026-01-06 15:17:19.066696+00	37.3	24.9	1021764	1021764
67d5cf33-06f0-42e5-979f-052ee3d7002c	2026-01-06 15:17:27.505689+00	34.7	24.3	946623	946623
f273074a-5bee-4c65-a5ee-b123843ffed9	2026-01-06 15:17:28.500626+00	22.3	24.3	498893	498893
5349ea42-bd3c-4406-8819-7b11a1ac4ba8	2026-01-06 15:17:29.700454+00	22.3	24.7	356569	356569
f2517401-2de6-4de7-8a86-4d92e6b23684	2026-01-06 15:17:36.05678+00	27.2	25.1	846314	846314
c372f6bf-98f4-4a08-adc9-9fd3307d41d7	2026-01-06 15:17:41.12023+00	26.3	25.6	74664	104562
274018b1-45ef-4ed9-b026-59ae6733015c	2026-01-06 17:58:21.572993+00	38.1	29.7	1414702	1414702
1a20b0b3-dd2c-400a-b9fb-2039f43b2a71	2026-01-06 17:58:50.582156+00	42.3	29.7	4030652	4030652
85e9eb45-cf1b-46e0-bb49-486b64925e0f	2026-01-06 17:59:21.585624+00	29.6	29.7	4190654	4190654
39296428-6f4b-4899-b3f9-19c1e7bb5533	2026-01-06 17:59:25.948024+00	42.2	29.7	1458329	1458329
b617f3a9-8a3d-421b-a8ed-bf935e1373eb	2026-01-06 18:00:21.528564+00	29.9	29.7	3920648	3920648
b3a05bce-b02e-49db-b575-23d724e4618c	2026-01-06 18:00:22.662952+00	40.2	29.9	2089429	2089429
c26df994-4b82-4513-9a3c-ff20fb35e681	2026-01-06 18:00:50.484179+00	33.7	29.7	4601006	4601006
da923f3d-a453-4842-9cf0-8dc442466638	2026-01-06 18:01:52.090496+00	44.1	29.7	477284	477284
92133baf-06c7-45b9-ad4d-670f9fe9aff9	2026-01-06 18:03:22.799088+00	36.5	29.7	3714044	3714044
2e956e90-223a-43be-af5d-1c34233f8cbc	2026-01-06 18:18:43.737889+00	48.3	29.7	3936779	108632
55827ca9-c0b1-4276-b5ce-04d9e4425022	2026-01-06 18:44:44.104266+00	46.1	29.7	4069709	103205
7f064775-950c-4295-a55e-3dae39539a34	2026-01-06 19:11:22.304416+00	40.5	29.9	3584989	3584989
2204c7a1-8be7-46c2-8077-622a9975771c	2026-01-06 19:14:22.338153+00	48.5	29.9	1881624	1881624
84e86312-170b-4846-9a9f-8977cc34761e	2026-01-06 19:14:25.950719+00	43.1	29.9	556363	556363
d74842ba-3ca1-4805-8530-c465a745226e	2026-01-06 19:14:50.423364+00	36.3	29.9	798949	798949
087aa068-daad-40f0-8142-2ab28cb5ba38	2026-01-06 19:15:50.309467+00	40.8	29.9	5481873	5481873
c3237b73-8294-4c07-a3af-f92083289cb9	2026-01-06 19:16:02.130427+00	44.6	29.9	4570208	4570208
b535f59f-2626-4bad-a7aa-8eb0a248fa93	2026-01-06 19:16:50.602051+00	39.5	29.9	5211149	5211149
a32fde00-3846-4915-b85d-b19cf60d5626	2026-01-06 19:17:22.805636+00	47	30	209919	209919
795269bd-a345-4687-b48a-5a6ebe2d5f20	2026-01-06 19:17:25.919415+00	43.9	30	1133652	1133652
29989cc3-c2e0-4256-a05b-17563a834f45	2026-01-06 19:18:22.610411+00	53.8	30.1	3916417	3916417
bff04bbb-638e-4b76-a72b-e92f1e2e1832	2026-01-06 19:18:50.461007+00	31.5	30	3587144	3587144
51a0bd4b-94b8-44fc-b4e5-b9b5b3a97401	2026-01-06 19:19:02.110492+00	43.9	30	4358553	4358553
21a5c7fc-6087-416d-8920-9a7e35a7e247	2026-01-06 19:20:21.569686+00	30.9	29.9	3687030	3687030
3b89a7ac-7a73-424c-abce-98c4ef54ef4b	2026-01-06 19:20:22.325654+00	40.2	29.9	3587754	3587754
796b42c2-2d6a-4cfd-90e2-c1df3b51cec4	2026-01-06 19:20:51.877098+00	43.9	29.9	442713	442713
d33db6b6-07bd-445c-aab7-b5fef82f9310	2026-01-06 19:21:25.925513+00	62.4	30	4104205	4104205
b2f67f13-a12c-48e0-b24a-6fa6c8c30db8	2026-01-06 19:21:50.397183+00	30.7	30	1192428	1192428
a338abfd-88b9-4eee-8aa3-1f4ed25e941c	2026-01-06 19:22:22.708264+00	42.6	30.1	1492446	1492446
f4a97951-a2cd-441a-923c-69232092b131	2026-01-06 19:22:50.647075+00	32.6	30	4820158	4820158
3bdb014b-9bfa-4aa4-9500-8b6b8005f4fa	2026-01-06 19:23:52.092141+00	50.1	30	2882852	2882852
8a832e3b-0b47-4d02-a231-fcc5a8881c56	2026-01-06 19:24:21.521528+00	30.6	29.9	4882892	4882892
a899f6d2-d0d3-4cea-968b-a403a3aacd9d	2026-01-06 19:24:22.289591+00	51.7	30	1012142	1012142
37751197-3c6c-497d-9a6f-7bd3758c6a08	2026-01-06 19:24:50.514036+00	40.2	30.1	2718017	2718017
d9231536-7234-4a9b-a3d9-0a94c6b687be	2026-01-06 19:24:51.877257+00	74	30	619093	619093
2bbf87a0-656c-4116-914e-35960f43f8f9	2026-01-06 19:25:02.094902+00	44.6	29.9	2712796	2712796
9e9c9890-0e4a-4b2c-849f-9b354c1dcaf9	2026-01-06 19:25:22.792242+00	44.2	30.2	4616165	4616165
a1a08b0e-428c-41de-8b74-4b1c1fb4b915	2026-01-06 19:25:50.613715+00	42.1	30	4351688	4351688
f849fde1-4fc9-41df-ab90-af7482968066	2026-01-06 19:26:50.362069+00	39	30	4258276	4258276
f71cfb75-1707-4209-ab09-16284be579d1	2026-01-06 19:26:51.732302+00	43.6	30	3227945	3227945
3db0abb9-84eb-4132-9353-0e812f35827e	2026-01-06 19:27:50.597988+00	41.6	30	4114942	4114942
02015eb3-16b0-4cbb-9647-f1cb76350e7b	2026-01-06 19:28:22.82476+00	51.4	30	3966456	3966456
8ebbcba2-0d5f-4d4d-b9a2-826e0691e2c8	2026-01-06 19:29:22.675981+00	41.9	29.9	5351859	5351859
62c457f6-d9ff-45f2-a9f7-e07c20de36ef	2026-01-06 19:29:25.926747+00	42.3	29.9	3220863	3220863
75bbb6c4-fec5-415a-93b7-0e56967d06e9	2026-01-06 19:29:50.310319+00	38.5	29.9	3871320	3871320
73610fab-9d9a-4928-a51d-76dfb555ebb1	2026-01-06 19:30:52.07382+00	70.3	29.9	5203640	5203640
c11b3c95-6ced-44f3-ab5a-f9b8f2a925f2	2026-01-06 19:31:50.569137+00	36.1	30	3521643	3521643
e5edaf0b-341c-4d90-875f-293f1f94bc94	2026-01-06 19:32:22.785055+00	45.5	30	2960309	2960309
370faecb-c105-485e-85db-ba311b925e42	2026-01-06 19:32:50.410689+00	38.8	30	3843269	3843269
5186382f-3993-4975-b3c0-36dde9bdfca5	2026-01-06 19:36:22.816596+00	46.7	30	4574397	4574397
6c8a6384-01c8-48f3-88fa-261b9f085ee9	2026-01-06 19:37:22.747632+00	44.7	30.1	411272	411272
d89a1b15-b831-4bba-ac93-85aa4b734b71	2026-01-06 19:37:51.945625+00	42.3	30	403826	403826
1fd67e9b-5d13-4197-88cc-5fc515f486ae	2026-01-06 19:39:22.575808+00	43.9	30.1	4813388	4813388
501465ff-bec4-4fec-af3e-9be2f7845bc8	2026-01-06 19:39:25.929787+00	43.6	30.1	3409376	3409376
7aa6d396-b96c-4dd8-adc4-e7814a23d43c	2026-01-06 19:39:50.462014+00	32.2	30	4518830	4518830
7aec3ba8-6547-4a6f-aadb-2521c1eb59d2	2026-01-06 19:40:02.103605+00	52.2	30	2776825	2776825
ca6df97f-23a5-4994-8d64-8762002353d6	2026-01-06 19:40:22.273046+00	45.3	30	5544378	5544378
3821cd4b-a35f-4655-aab8-0ad96724cbc7	2026-01-06 19:40:25.924871+00	46.3	30.1	3628142	3628142
395f90ea-3882-4f49-a7e1-a57c5812b1cb	2026-01-06 19:40:51.874134+00	43.7	30.1	4207317	4207317
034f8e66-9be9-4731-8967-15c75175ba07	2026-01-06 19:42:02.137614+00	47.3	30	4443671	4443671
3b98ec70-d026-4861-b9d2-5108d38df51b	2026-01-06 19:42:21.567518+00	32.3	29.9	4590065	4590065
24b7b7fd-f0a1-4e4c-9966-ca4f9297aa98	2026-01-06 19:42:51.827821+00	45	30.1	486305	486305
308c5a5d-db6d-498c-9361-17e94f7142fa	2026-01-06 19:43:22.760575+00	47.8	30.2	206338	206338
3a15fb8a-ee16-4c51-9576-cc01bbd338ac	2026-01-06 19:44:02.079132+00	52.1	29.9	2867899	2867899
c4b910df-b93b-4cda-8b17-82fcc7ccad1c	2026-01-06 19:44:50.53664+00	35.3	30	4199440	4199440
19a5423e-e532-42a5-a76e-d4a616f67ca2	2026-01-06 19:44:51.931867+00	44.2	30	5098182	5098182
dbdc4fd1-3a9d-47a1-a679-7a5bf946d03d	2026-01-06 19:45:25.916867+00	42.7	29.9	3729585	3729585
426bd453-6662-43e8-ae52-15f865a2c451	2026-01-06 19:46:02.099012+00	45.9	30.1	2990923	2990923
85a65ae3-f85d-45fd-a08e-ac49109ad890	2026-01-06 19:46:50.650483+00	39	29.9	4971505	4971505
584c725c-aeb7-4fa9-8164-018276a592ee	2026-01-06 19:47:22.752078+00	35.5	30.1	3092893	3092893
23e72417-3c7a-40a5-9855-459895c40143	2026-01-06 19:47:51.85994+00	74.2	30	408996	408996
5733b32f-c589-48ac-8ff7-c826b43c17a8	2026-01-06 19:48:02.098112+00	49	30	6192302	6192302
fabfcde9-af33-45b9-9bcb-876a1f6e74c8	2026-01-06 19:48:21.594324+00	33.8	29.9	3102492	3102492
5c8e171a-45a1-420a-9c45-dd29ee603f35	2026-01-06 19:48:50.484518+00	36.8	30	4270928	4270928
2bf03873-6b6b-4b38-ba25-d94d51ebd6bb	2026-01-06 19:49:21.619961+00	33.4	30	921771	921771
453317aa-7b76-4b83-8917-5b84cafb1c24	2026-01-06 19:49:22.824646+00	39.7	30	4445310	4445310
300a6746-b5bd-49e9-8377-b6cd9ae0785f	2026-01-06 19:50:02.133206+00	47.3	30.1	5457778	5457778
575a6140-7e9c-4262-9ffa-25739b39037a	2026-01-06 19:50:22.599775+00	44.4	30	4484377	4484377
808f9bab-20d7-42bb-b74f-dcb22212cbc2	2026-01-06 19:51:22.772019+00	47.9	29.9	283843	283843
b9dfb3a8-2179-4b22-9d14-d36a60146676	2026-01-06 19:51:25.906602+00	43.6	30	3156274	3156274
479167bf-cdc2-4c74-b195-0920b9725f5d	2026-01-06 19:51:50.348655+00	36.7	30	4590003	4590003
c4f94804-cef8-4784-8b2e-b305f0a92a28	2026-01-06 19:52:22.588642+00	41.3	30.2	5022069	5022069
f725f8d6-3ebb-4ea9-b6cd-1a03edde652b	2026-01-06 19:53:22.270356+00	38.3	30	5487613	5487613
18ca8306-ce52-4171-b266-b876aa656ebc	2026-01-06 19:53:50.519618+00	38.8	30	3431559	3431559
ebf9c0ac-6733-4639-a49a-745482d822b9	2026-01-06 19:54:22.736582+00	43.8	30	237366	237366
d1b480a1-3803-4880-98bf-4e7c446fca43	2026-01-06 19:54:50.481503+00	35.6	30	3137512	3137512
bb6399fe-b497-4abd-9852-0f3ce4689368	2026-01-06 19:55:22.751486+00	39.5	30	5238195	5238195
e21c2a71-61b2-45f0-83df-0665d84504a8	2026-01-06 19:56:21.540388+00	31.5	30	1034724	1034724
b921db49-8284-4f72-b1c0-c3981b2cc29d	2026-01-06 19:57:52.053441+00	47.4	30.2	1205004	1205004
9e48be57-5c08-42d0-8391-2e25c25fa2c7	2026-01-06 19:58:22.775643+00	39.9	30.1	5724966	5724966
70e3beea-e785-44bf-b7fb-1df0f94a1b5d	2026-01-06 19:59:50.327882+00	36.8	30	3913599	3913599
e05439a3-7e5b-481a-b8e6-caef77990e90	2026-01-06 20:00:22.8809+00	49.6	30	306309	306309
232aa3ed-7c40-4b2b-8e99-e724a93085b6	2026-01-06 20:00:50.581495+00	33.6	30	4484890	4484890
7c04d9fe-6e2c-4261-b2d1-224ffe50417e	2026-01-06 20:00:51.755323+00	50.7	30	5543988	5543988
58c85390-07f7-40e8-a8b1-4de6eb3d79e9	2026-01-06 20:01:22.788961+00	38.8	30.1	417866	417866
01606cfd-dce7-4ca4-b4ee-8bfd88fadc0a	2026-01-06 20:02:02.079119+00	43.2	30	6861648	6861648
172be470-5d8a-4233-965f-924705498feb	2026-01-06 15:17:44.306038+00	25.6	25.7	332734	332734
cb5ab9d5-0a7b-4014-99d4-eb5618ffe73f	2026-01-06 15:18:15.455778+00	18.7	25.7	1130700	1130700
c420880c-922e-49e3-ac03-8c6226a6ae1d	2026-01-06 15:19:01.296592+00	22.6	25.8	419250	419250
98c7bfed-c536-4c2c-a388-0186327bbe7c	2026-01-06 17:58:22.258999+00	55.7	29.7	4500353	4500353
a0976865-eb04-4119-a768-0f41348ac1a6	2026-01-06 17:58:50.475522+00	42.3	29.7	4334939	4334939
214a82e3-983a-4220-a6bb-5b0e90ffe561	2026-01-06 17:59:22.392033+00	48	29.7	5140371	5140371
a5bc2bcd-d37d-4680-8f17-c45a3e8910ea	2026-01-06 18:00:51.661246+00	40.6	29.7	4971212	4971212
ad7a60d2-c8ce-488a-8ba3-c7b4c6158ad8	2026-01-06 18:01:02.046061+00	46	29.5	610728	610728
3b82e82d-6682-462b-9f7e-65d7e777e6a7	2026-01-06 18:01:22.371728+00	34.8	29.7	4874900	4874900
e02a6d93-4daa-4fb5-bd22-137e57d986b4	2026-01-06 18:01:50.647188+00	35.2	29.7	3186284	3186284
723e8c4e-2ac4-406d-834f-6635eea73956	2026-01-06 18:02:21.547234+00	31	29.6	5853525	5853525
71459a25-8b78-4805-96ab-d535d9b112d2	2026-01-06 18:03:02.116118+00	49.4	29.7	5157637	5157637
0e350199-14af-4114-a471-673e85504832	2026-01-06 18:03:22.41151+00	36.5	29.7	6068594	6068594
81b06042-2e0e-4132-96f7-c67186282fad	2026-01-06 18:04:22.78625+00	35.9	29.6	1621541	1621541
40c386fe-6032-4378-8abc-ddfa77fa5f9a	2026-01-06 18:04:50.510316+00	35.5	29.6	4991642	4991642
bce0dc6a-a32c-4e73-a785-6904c815a0bc	2026-01-06 18:04:51.7513+00	43.6	29.6	4408666	4408666
aab4f0e5-60db-42dc-9c5a-465d355b86a5	2026-01-06 18:05:02.037919+00	47.7	29.8	3880734	3880734
0dc25140-bfda-4628-bf1a-04831042ee4d	2026-01-06 18:05:22.434764+00	47.7	29.7	410543	410543
4da164c4-985b-478d-b00a-6c7f4dc5ca9a	2026-01-06 18:06:50.487004+00	38.2	29.7	5653654	5653654
3642e6d9-64ae-4f32-9f79-1387e1556daf	2026-01-06 18:07:22.770962+00	36	29.7	9507938	9507938
1be2ec16-735d-41de-9be4-951865884b40	2026-01-06 18:19:43.728436+00	37.3	29.5	4406605	116251
66edaf25-efe9-4c4b-b752-371cc773cfef	2026-01-06 18:45:44.093775+00	43.2	29.7	4217956	110847
b6e44e3a-d747-41d3-8501-12d25b6951a1	2026-01-06 19:11:22.639913+00	40.5	29.9	2267100	2267100
41555121-ef55-4c5c-a59c-24b2ca640b64	2026-01-06 19:11:50.46066+00	36.8	29.9	4518660	4518660
a91adad6-6c2a-43e7-ad8c-2d5c00dd9844	2026-01-06 19:12:02.051259+00	50.2	29.8	2963351	2963351
fb7051f2-dc40-40eb-b6a2-91ada3aff32c	2026-01-06 19:12:25.931659+00	44.8	29.8	3430304	3430304
db87746d-b26b-48e5-b546-dcf43e238950	2026-01-06 19:12:50.598837+00	34.7	29.9	3954131	3954131
85778f26-c437-4eec-bec3-a18a2ac2095b	2026-01-06 19:13:22.315393+00	42.9	29.8	537228	537228
2d1aaeda-38f9-4907-9436-d0686cff3f02	2026-01-06 19:13:25.940993+00	60.1	29.9	833152	833152
c2a2b6ed-8d35-4a86-bdcc-f0ca2b91e914	2026-01-06 19:13:50.602615+00	38.1	29.9	4275527	4275527
a18fb7ae-c4d8-40f6-8d8b-fbe437368026	2026-01-06 19:13:51.994802+00	46.7	29.9	4266646	4266646
f079395d-e421-4b80-96be-7524ac2d0df2	2026-01-06 19:14:22.808495+00	48.5	29.9	4732764	4732764
283d807d-678d-4a01-ac5a-027395d8eed9	2026-01-06 19:15:22.753083+00	39.1	29.9	3931087	3931087
9d004c7c-3657-46c3-91ec-75f3ab82a4a7	2026-01-06 19:15:51.651121+00	38.2	29.9	5168797	5168797
a627eec9-ec7d-4235-8a50-c145e7851c53	2026-01-06 19:16:22.667288+00	36.7	30	1618986	1618986
9a1978c6-f525-427f-affa-44ea05398fd6	2026-01-06 19:16:50.481455+00	39.5	29.9	1354456	1354456
b7d0e7e9-bf7c-428f-8708-3de80a438770	2026-01-06 19:17:22.721503+00	47	30	3701004	3701004
d3112512-6ef1-44d8-901f-05ae65d92726	2026-01-06 19:18:02.155286+00	44.2	30	496095	496095
d4282ebc-0e53-4960-8b9d-b8a56c9fc709	2026-01-06 19:18:21.493828+00	40.1	29.9	4516933	4516933
4c7aa931-e987-4be2-8cc2-badcb42a7348	2026-01-06 19:19:50.580862+00	27.4	29.9	4824358	4824358
a8b3aaee-8615-4b57-a9f6-555c046a12d3	2026-01-06 19:20:22.70933+00	40.2	29.9	4788396	4788396
f770363c-8114-4982-a2b0-2f172bfbc915	2026-01-06 19:20:50.593816+00	33.1	29.9	556270	556270
11b7eae4-28b7-472e-aece-212e0784ebdf	2026-01-06 19:21:22.950629+00	42.5	30.1	568443	568443
ef61464d-a82f-41fb-9ca2-80989601b095	2026-01-06 19:21:50.513155+00	30.7	30	861963	861963
ee182ab7-8fa3-4547-b0b1-afaa1d084ff8	2026-01-06 19:23:02.091333+00	54.3	29.9	3158420	3158420
8a979a09-adee-4b00-943e-91939960a52b	2026-01-06 19:23:22.638404+00	44.7	30	288813	288813
2de537bd-9ad9-481f-ac5f-797f86efd9e6	2026-01-06 19:23:50.61693+00	36.6	30	3347019	3347019
e2ee4d75-fa0c-47d9-bae3-1660200ed904	2026-01-06 19:24:22.783289+00	51.7	30	5720824	5720824
dd33b463-41c3-45f6-a171-a3c5eb94e91e	2026-01-06 19:25:21.619912+00	33.9	30	1064720	1064720
656d2eeb-8271-4040-97b5-e70d65bc39d5	2026-01-06 19:25:51.912603+00	53.2	30	4595630	4595630
22532914-ecc9-469d-be42-8b290699f116	2026-01-06 19:26:21.610205+00	33.1	30	950866	950866
aa5200d1-03c3-4aa4-a7b8-9c81c5ff5ec8	2026-01-06 19:27:02.078348+00	44.7	30	814570	814570
1fc9991f-077c-466c-853d-9e3053c7e161	2026-01-06 19:27:22.340552+00	39.6	30.1	4218096	4218096
7b39e70b-290e-4f38-b950-a84cf6d32cde	2026-01-06 19:27:50.50427+00	41.6	30	3392521	3392521
98c2e939-e9c2-453c-8738-cbaa50204d51	2026-01-06 19:27:51.878572+00	69.7	30	2802988	2802988
d4cb2227-8c93-4a49-96ce-8f132b708dfb	2026-01-06 19:30:50.459287+00	38	29.9	681994	681994
d2b5d5ef-d73e-4f3e-8127-31a248c476f2	2026-01-06 19:31:22.364902+00	50.6	29.9	679478	679478
d312dddd-6b30-45bd-b5e7-f2eb574e70a2	2026-01-06 19:32:22.354555+00	45.5	30	5691044	5691044
667840af-3c6f-4b71-9097-2e6a8b36c940	2026-01-06 19:32:51.850401+00	44.3	30	3773658	3773658
79a2d29f-81ff-4c67-80da-555530ef2314	2026-01-06 19:36:25.963465+00	47.2	30	2032448	2032448
71692e9a-359c-414b-8c6f-03563c42443f	2026-01-06 19:37:50.404606+00	41.2	30	3742209	3742209
7e0f7a11-a5f6-4fc7-a530-0f3478f826de	2026-01-06 19:38:02.035072+00	49.5	30	5099986	5099986
98e0b2de-af6a-41b6-bf16-741ce1c2121f	2026-01-06 19:38:50.478357+00	41.2	30	2915798	2915798
a3345e7c-0161-481b-b74b-6713ea6baf5b	2026-01-06 19:38:52.110236+00	74.3	30	5399305	5399305
e6de63c8-fd0a-4639-b3bc-9a80c1a35d22	2026-01-06 19:39:50.57686+00	32.2	30	3950651	3950651
6bc964cd-feb3-4695-85cb-04302e7f4e71	2026-01-06 19:40:22.699576+00	45.3	30	4935755	4935755
02c27aec-5b6f-44d5-9daf-95f851b669fd	2026-01-06 19:40:50.546324+00	41.4	30	3805198	3805198
a7934504-c62e-4ab1-ac19-06c2c53fe87f	2026-01-06 19:41:02.099076+00	52.1	30	836207	836207
9d245a27-1842-46a4-9d6b-1af36dade140	2026-01-06 19:41:22.7891+00	53.7	30.1	4902650	4902650
c075b4be-d130-46c2-8654-b4b70ba5e843	2026-01-06 19:41:25.900421+00	54.5	30	4095339	4095339
09b3e969-a41b-4d19-9bb2-2975fb3e01c1	2026-01-06 19:42:22.311616+00	43.3	30.1	6131383	6131383
9dc61935-f735-4d3e-9d4a-70aa8ff75104	2026-01-06 19:43:50.552099+00	43.4	30	2502285	2502285
aa95d5ca-c184-4195-a1cc-b7f0592740c1	2026-01-06 19:43:52.062668+00	75.4	30	2030055	2030055
880544a9-1c93-469a-9003-16c80e03508c	2026-01-06 19:45:02.108228+00	45.4	30	5010393	5010393
302d2a0f-c38d-4698-bfe6-a193c009667f	2026-01-06 19:45:21.561514+00	30.6	30	3913722	3913722
7e03e0e8-cd21-4240-89ae-b91f00602d98	2026-01-06 19:46:22.775996+00	41	30	261833	261833
12c92073-4df1-4089-9743-57b0cbe0b108	2026-01-06 19:46:25.912084+00	46.7	30	2286583	2286583
657452c1-6d60-4b06-bc68-eec5dc9448f4	2026-01-06 19:47:25.918828+00	54.7	30.1	1957199	1957199
ddbbff44-06fa-42de-b716-d224e083345b	2026-01-06 19:49:22.363235+00	39.7	30	3223605	3223605
af8b0166-0e64-4714-bad2-585925b1a773	2026-01-06 19:49:52.019339+00	48.5	30.1	2949716	2949716
ec878be9-ad22-45ec-b8c1-d30ba9cfa744	2026-01-06 19:51:22.334744+00	47.9	29.9	732369	732369
21a4a8d0-544e-4eea-84ef-e8e96c1f55dd	2026-01-06 19:51:51.793458+00	74.6	30.1	1458193	1458193
71e30583-5415-44aa-816f-dccbb2d50de0	2026-01-06 19:52:50.313275+00	42.8	30.1	4205310	4205310
20bf08eb-8ed2-4b43-b095-b0c30c6cef53	2026-01-06 19:53:25.859311+00	60.4	30	5141468	5141468
a5db696d-7080-4261-bd0d-e7e960f54b05	2026-01-06 19:55:21.564347+00	31.8	30	929980	929980
9cda9c96-5154-4527-9ca1-1c607b4637ce	2026-01-06 19:55:25.937114+00	45.2	30	3097809	3097809
4c802ccc-d634-4637-81b1-b9b099833d37	2026-01-06 19:55:51.939926+00	46.9	30	4083836	4083836
002acf18-3576-4162-b588-417c0a86a722	2026-01-06 19:56:02.097999+00	50.9	30	1209711	1209711
6abf951f-90f8-42df-8aec-94f754e27bbb	2026-01-06 19:56:50.628724+00	34.6	30	4035550	4035550
a42635ba-b745-406b-b004-475d94e88eca	2026-01-06 19:56:52.068749+00	41.4	30	4023337	4023337
19c70cd2-24ac-427f-b545-9b50b58f430f	2026-01-06 19:57:22.706897+00	39.7	30	5259660	5259660
81204107-dd88-4649-8095-c3a5754b8b64	2026-01-06 19:57:50.546762+00	36.6	30.1	3642786	3642786
3714fa86-f36c-4aa7-b52c-cd2ae49259d0	2026-01-06 19:58:02.085131+00	43.9	30.1	719188	719188
3302cc9a-2115-4fd0-9b6e-d9b7d4f875b3	2026-01-06 19:58:22.691666+00	39.9	30.1	292024	292024
709df150-fac9-41ac-ae7e-3279c5291f6c	2026-01-06 19:58:25.895153+00	40.8	30	3361740	3361740
84ec5219-99ba-4764-8b69-3620d2ad5ddf	2026-01-06 19:58:51.721411+00	45.8	30.1	237288	237288
c6317652-d514-4e30-af8a-a80039ff9281	2026-01-06 19:59:21.573729+00	35.3	30	3349532	3349532
38ee7813-845f-4a81-a6b0-ca3efbbb1c87	2026-01-06 15:17:51.461998+00	25.7	25.6	914050	914050
11377cea-4915-4d72-83d7-8b1303383f4b	2026-01-06 15:18:19.088086+00	23.8	25.7	500671	500671
fa64dde1-30cc-448b-9574-938d58a9a498	2026-01-06 15:18:29.751557+00	21.2	25.7	126590	126590
26a7b762-0aad-4204-9c3e-5fd249619286	2026-01-06 15:19:08.510834+00	25.7	25.9	925919	925919
8195ba2e-a6b7-4fe8-afcd-1bac69632bec	2026-01-06 17:58:22.703107+00	55.7	29.7	2138286	2138286
98ac9116-4adf-4219-8b4d-0ccbc2aa5e99	2026-01-06 17:58:25.94544+00	45.3	29.8	3176979	3176979
a98f2961-9b80-481b-b705-6715ea8effea	2026-01-06 17:59:50.459665+00	42.2	29.7	1169087	1169087
66939695-04b1-4c85-98dd-2cc0d88ee7c4	2026-01-06 18:00:22.272118+00	40.2	29.9	4327220	4327220
8f034716-5851-401d-b648-64af1eb204b2	2026-01-06 18:00:25.928245+00	53.7	29.8	4066698	4066698
7298a1db-e77a-4f99-b2b3-2d20f3099370	2026-01-06 18:01:50.554655+00	35.2	29.7	814189	814189
5fcba5a3-f026-450c-ba8e-c4402649f6dc	2026-01-06 18:02:22.759947+00	37.9	29.8	3931800	3931800
4c184a7c-ae63-45fb-b595-1bd4dd475692	2026-01-06 18:02:50.704211+00	40.9	29.6	425324	425324
ad6890f4-06e6-497f-871a-a1f528626577	2026-01-06 18:20:43.715088+00	43.6	29.6	4345306	117371
1053a158-22e4-4036-aace-0c6162c160b4	2026-01-06 18:46:44.104705+00	47.6	29.7	3533613	89996
d253bc4c-8a25-4411-af7f-65c3135dd08c	2026-01-06 19:11:22.728104+00	40.5	29.9	3760046	3760046
77af8beb-bf15-473e-86db-653273b7dae3	2026-01-06 19:11:25.898802+00	45.7	29.8	2980169	2980169
6bfbe224-db5b-4c80-a7ec-596996e30fc8	2026-01-06 19:11:51.961208+00	39.5	29.8	1547825	1547825
65240555-292d-4ac8-8bf7-9232fa8383a9	2026-01-06 19:13:22.617338+00	42.9	29.8	5378938	5378938
1930859a-74b5-4f6c-a227-38f6f56d31f7	2026-01-06 19:13:50.681596+00	38.1	29.9	5601203	5601203
bca9752e-9198-4c4a-9469-070062b32213	2026-01-06 19:15:02.125239+00	52.6	29.9	4091769	4091769
4fa7a77d-b2a3-494e-babb-c261ea4cb737	2026-01-06 19:15:22.661491+00	39.1	29.9	3194379	3194379
272b707a-9568-4e66-a5fb-94b44b5a849d	2026-01-06 19:15:50.467121+00	40.8	29.9	1077420	1077420
21f005cd-ffdd-4f4c-8634-ae53e7738e74	2026-01-06 19:17:22.362118+00	47	30	3756987	3756987
c7085c9a-af34-45b5-b885-b311e6404653	2026-01-06 19:19:22.795995+00	43.7	30	6218465	6218465
b4de5422-387e-4c8d-86a8-fe504997d305	2026-01-06 19:21:02.097491+00	49.9	29.9	704345	704345
7919280e-7985-43ed-97e0-4cdeff227289	2026-01-06 19:21:22.447531+00	42.5	30.1	4754326	4754326
ef39588b-2082-43d3-94ae-8398fd50854e	2026-01-06 19:21:51.826898+00	38.8	30	667151	667151
a0e5457e-0d98-4092-9161-464282d57134	2026-01-06 19:22:22.365072+00	42.6	30.1	4431124	4431124
22dd6d87-a912-4631-9d69-1179cc282316	2026-01-06 19:22:52.012643+00	51.2	30.1	324148	324148
fef52007-6c66-4a54-bf55-a365705d53e8	2026-01-06 19:25:50.511685+00	42.1	30	957373	957373
0cb6b2f4-ca6f-4ef6-a94e-680eae2f669d	2026-01-06 19:26:22.705182+00	51.5	29.9	5012919	5012919
bf546715-91ae-4556-bc8b-a0c9367a8540	2026-01-06 19:26:25.902877+00	44.8	30	2929933	2929933
6e750a01-2383-49c5-90a4-95560b0cbc3b	2026-01-06 19:27:22.703038+00	39.6	30.1	6605594	6605594
09f9595e-8e92-4769-ba8a-578cfc321dae	2026-01-06 19:28:02.096431+00	47.2	30	1097900	1097900
6405f4bb-8b31-4351-83b8-5e8794e5f388	2026-01-06 19:28:51.769231+00	43	30	4705682	4705682
fd01b78e-6f90-4da7-9693-64bf83b4df59	2026-01-06 19:29:02.028977+00	46.8	30	4625635	4625635
cba50a68-4105-4cfe-a1e9-6ad8624e7366	2026-01-06 19:30:21.517173+00	32.7	29.9	4612147	4612147
6294764a-8fbc-4c23-94f3-673b21382536	2026-01-06 19:30:22.169657+00	53.2	29.9	527969	527969
77c44597-66f4-4d66-ab5a-c1747702fa49	2026-01-06 19:30:50.577045+00	38	29.9	441976	441976
38f0a12c-f1c4-4658-921c-ee99c6f21e74	2026-01-06 19:32:21.561111+00	33.1	29.9	3906825	3906825
5f04cd73-31c6-4ade-893a-1fdc7d7977b7	2026-01-06 19:33:25.944996+00	56.5	30	739202	739202
664e0a46-c675-4668-bc53-501d5a114873	2026-01-06 19:34:50.463091+00	45.2	30	3253294	3253294
4a0b2eb3-7ff5-416d-a6ec-80357f181806	2026-01-06 19:36:44.850182+00	44.2	30	4464135	113644
d98fb279-03b2-419d-905b-d5367e099bff	2026-01-06 20:03:50.453408+00	35.5	30	6023474	6023474
da2458fc-38c5-437c-bf2f-bd1443e4d484	2026-01-06 20:04:21.607498+00	36.1	30	932554	932554
b384790d-fd58-4b11-ba41-d37e7d423ed4	2026-01-06 20:04:22.742215+00	44.1	30	2658084	2658084
02638aae-e6e5-4c3f-990f-892d0af658c9	2026-01-06 20:27:50.575416+00	40.1	30.3	641853	641853
132d1faa-f1e4-42af-84af-5d49b7d80c4a	2026-01-06 20:28:25.88203+00	43.6	30.1	1404869	1404869
28c9cf52-fb86-42c0-826e-679f23fc28cb	2026-01-06 20:31:22.774958+00	47	30.1	4769233	4769233
87d4748b-8454-4ac5-bd8a-6b394b49c088	2026-01-06 20:32:22.840829+00	40	30.1	1170461	1170461
cb5ac4f5-66df-4bc6-8be4-76970ba72eeb	2026-01-06 20:34:22.754598+00	43.2	30.2	235008	235008
132b9f8b-c9e9-4e2d-ae75-01dee8534f8c	2026-01-06 20:34:50.40578+00	41	30	726496	726496
4c28b344-10d0-4de7-912d-3004e2b65f1e	2026-01-06 20:35:25.875361+00	42.8	30.1	3414922	3414922
40f39617-c82e-4a9d-b38f-2bd58435113f	2026-01-06 20:36:02.107149+00	48.6	30	1244207	1244207
e1631a25-ac26-4228-a0f2-09dfe8387711	2026-01-06 20:42:45.81758+00	39.4	30.1	3872982	102098
fec8057e-319b-4865-8426-5ad1be1396fd	2026-01-06 21:09:46.207234+00	4	21.5	1406	313
2eac8885-0455-4bd6-b4ab-39b1367c4767	2026-01-06 21:38:46.591665+00	3.8	21.6	1198	200
be0861b8-4bf3-4420-961e-b8ffa98bedc2	2026-01-06 22:07:46.896827+00	3.9	21.5	1430	293
5e129d8d-9e15-4638-8c6b-32ce53448583	2026-01-06 22:36:47.253541+00	4	21.4	1217	173
0c699997-5064-4f81-b2ef-d4f24e2beee6	2026-01-06 23:05:47.595279+00	3.5	21.6	1714	309
6fdf54f7-23b5-482a-b03e-58166f3386ee	2026-01-06 23:34:47.958879+00	2.6	21.5	1579	188
103cd88b-cef5-4957-b495-2678d4256dde	2026-01-07 00:03:48.319471+00	1	10.1	1431	24
c2683806-3e07-4394-a2f0-2e4141dd43b9	2026-01-07 00:32:48.690492+00	0.9	10.1	2103	27
8252cb70-7036-4bec-9ffc-2babc46a33c9	2026-01-07 01:01:49.092671+00	0.9	10.1	1541	17
5f200e13-02b4-4acc-b586-4cc0b18b40fc	2026-01-07 01:30:49.474772+00	1	10.2	2258	19
c7175c7c-d74d-41f9-a16b-4a67b04ea998	2026-01-07 01:57:49.891681+00	3.2	10.9	63223	47648
a04f7ac2-b8b8-4299-953b-4d6d6e5c33ff	2026-01-07 02:18:50.126356+00	3.2	11	35420	48161
b8966e12-f4e9-482f-b1d7-418da393e5c1	2026-01-07 02:32:50.332514+00	3.3	11.1	23457	17973
c21ef060-931b-4ce8-b41c-615d1ac5caa3	2026-01-07 02:53:50.584824+00	5.4	11	26945	14561
431d7af0-fdf7-4e03-9bc8-b361044fe0cb	2026-01-07 03:01:00.751943+00	2.8	11.1	382597	382597
0f124697-10f8-4f9c-9b40-7489db295081	2026-01-07 03:01:00.878336+00	2.8	11.1	504515	504515
28f3b8e2-e68c-43bd-877e-19ba906ce14e	2026-01-07 03:02:00.905487+00	2.8	11	762314	762314
2359472e-e668-42b4-a432-877c8ae67f64	2026-01-07 03:03:00.726239+00	2.1	11	216348	216348
31790475-3742-4f32-8fa4-9606422b1772	2026-01-07 03:04:00.679862+00	2.5	11.1	735946	735946
e7d891de-7b7a-4bea-9d89-e2f1d9566522	2026-01-07 03:04:01.230579+00	2.5	11.1	632457	632457
793f6714-f205-4cdf-9a3a-b2514c5d70c7	2026-01-07 03:05:00.115687+00	2.8	11	9913	9913
6f797ced-67e1-4aa2-acd2-ec5cd403636d	2026-01-07 03:05:00.251902+00	2.8	11	721811	721811
a753791d-27d4-41d0-affb-dd67f7d9c442	2026-01-07 03:05:01.251018+00	2.8	11	436356	436356
037398f4-9107-45ce-9746-5e6222cd51ba	2026-01-07 03:06:00.962304+00	3	11.1	663095	663095
b5862afe-7cff-46c9-ab56-1988836c90da	2026-01-07 03:07:00.86507+00	2.9	11	318433	318433
81a47c5c-c699-4699-9c17-d5f4434e240e	2026-01-07 03:08:01.005948+00	3.7	11.1	603238	603238
d5a4afba-f483-4dd7-afa3-e4f8391a4e2c	2026-01-07 03:09:00.910148+00	4.8	11.1	736825	736825
f3a774a1-e8d2-4925-95d9-aac9ccc8bbce	2026-01-07 03:10:00.819508+00	2.6	11	674948	674948
7a23866c-0043-4c9f-948f-e28cd2937a32	2026-01-07 03:11:00.107206+00	2.8	11	8495	8495
405060fc-c2d7-4f3c-a7c2-b6a374820504	2026-01-07 03:11:00.811297+00	2.8	11	818517	818517
87dc37ff-46b0-4a95-92b9-f5db64e2b2c7	2026-01-07 03:12:01.165384+00	3	11	577583	577583
5aa29508-1386-4c88-868b-f69f2d0a2c95	2026-01-07 03:12:01.178646+00	3	11	650359	650359
82404058-d70f-4f32-ba07-e918caddb5ca	2026-01-07 03:13:00.258598+00	6	11	709800	709800
b7bb78e4-7463-4c5a-aaa6-5f78a0c4fac6	2026-01-07 03:13:00.90714+00	6	11	630808	630808
13c6ec41-9ff3-4514-848f-28f031c9f712	2026-01-07 03:13:00.922096+00	6	11	547671	547671
7620ea55-8a40-414f-9a10-ca4ddfcc2e3c	2026-01-07 03:14:00.37476+00	5.5	11.1	613822	613822
01db9791-91bf-4a4e-b5ca-dd9189d8eda7	2026-01-07 03:14:00.848186+00	5.5	11.1	673930	673930
6bad3df2-d1c3-412e-9c2f-5834e0da8a6e	2026-01-07 03:14:00.97909+00	5.5	11.1	789186	789186
e1c63bad-ee28-4dfd-a8cf-9d9eec7b1a7a	2026-01-07 03:14:01.148625+00	5.5	11.1	377137	377137
b4af8b0c-3b4b-4246-a62e-7684185549ae	2026-01-07 03:15:01.030173+00	3.2	11.1	605642	605642
2a19d779-8eaf-4566-aafe-3b8b71543840	2026-01-07 03:15:01.067964+00	3.2	11.1	598588	598588
eb610aef-4dfa-4ba9-8ceb-0067e62b08cc	2026-01-07 03:16:00.68528+00	2.7	11.1	700388	700388
824ed2f8-6edb-4836-acda-51990b848954	2026-01-06 15:18:08.552115+00	16.2	25.6	737522	737522
ee2c9d97-143b-4d44-a975-a90a088dbd6e	2026-01-06 15:18:28.498021+00	20.1	25.7	775516	775516
1ddfa356-108f-4604-8ce6-27beb7595612	2026-01-06 15:18:36.027796+00	28.6	25.8	1146820	1146820
2ebffdff-38b0-456b-8028-57bae2dd39be	2026-01-06 15:19:15.484962+00	19.7	25.9	731426	731426
346359b0-7584-42c2-8a40-ab674367126f	2026-01-06 17:58:22.77824+00	55.7	29.7	5928922	5928922
d1fc5f6c-ec03-4b46-856b-159d76f37537	2026-01-06 17:59:22.893396+00	48	29.7	259114	259114
8e53b041-1f55-43d0-b152-9ac375ce642c	2026-01-06 18:00:02.094204+00	44.7	29.7	6732868	6732868
03d75609-5320-4006-855c-262706b48978	2026-01-06 18:01:22.884487+00	34.8	29.7	784978	784978
3c81ffc4-d0d3-47a2-89e4-dcbbc1ee8cb5	2026-01-06 18:02:02.10368+00	48.3	29.8	6120884	6120884
d1d5032f-6836-43e5-995c-ebced4059bda	2026-01-06 18:02:22.350407+00	37.9	29.8	448819	448819
1bd64591-c00c-4079-88e2-a137624e9629	2026-01-06 18:02:50.614128+00	40.9	29.6	1000042	1000042
e30b214d-2daf-4dd4-bc2e-0e676bd00d16	2026-01-06 18:03:21.590118+00	30.6	29.8	5385333	5385333
ea8d0ac0-1d6e-459d-968f-007bb85848f7	2026-01-06 18:03:22.721693+00	36.5	29.7	3574840	3574840
9af80515-6763-41cc-b849-864fc8a494b3	2026-01-06 18:21:43.748264+00	41.1	29.8	3958991	106260
6de986b3-7bd1-4fad-af3f-a7369ab32eae	2026-01-06 18:47:44.162749+00	46.3	29.8	3505471	85194
1e44b4d1-3511-4928-8beb-9d2f883dfb12	2026-01-06 19:11:44.505805+00	42	29.9	3786516	99953
161aa7e6-aa05-403f-8240-0a2daaf74950	2026-01-06 19:36:50.437208+00	38.2	30.1	4933186	4933186
b26233a2-a0e0-4fb5-bc56-03e0b706433a	2026-01-06 19:37:02.07482+00	49.3	29.9	4686116	4686116
69b26721-8926-4463-892e-181f70f3bbd0	2026-01-06 19:37:22.876579+00	44.7	30.1	353698	353698
f983d654-e2c1-4b48-af84-dc5d6d1e6e81	2026-01-06 19:37:25.943377+00	55.8	30	2957103	2957103
057bd414-c14e-4431-92b6-96c9e4ee6c3f	2026-01-06 19:37:50.542198+00	41.2	30	2557085	2557085
18f812a1-8f76-47d8-9a04-16dcd69eb602	2026-01-06 19:38:22.852754+00	43.5	30	2319496	2319496
de5a6543-ab23-42c1-9e33-cd34239f4744	2026-01-06 19:38:50.603535+00	41.2	30	5022789	5022789
09722f47-418f-48ae-8562-d8d401775412	2026-01-06 19:39:22.264155+00	43.9	30.1	6437648	6437648
bc65f85c-eabf-41ef-b1e0-20b7861fe87d	2026-01-06 19:40:50.411795+00	41.4	30	3410907	3410907
70c0b646-edfa-4c96-9baa-3b0b8285bcce	2026-01-06 19:41:50.523302+00	41.6	30	5685310	5685310
56803dda-f2a1-408f-aa63-fdf66d25bec0	2026-01-06 19:41:52.099307+00	42.3	30.1	4671183	4671183
d61f232f-f57a-48d6-bf09-311882ba8244	2026-01-06 19:42:22.630011+00	43.3	30.1	283088	283088
7204c596-87ba-4cdd-bb09-3bc359aea571	2026-01-06 19:42:50.634448+00	30.1	30	3181525	3181525
607596e0-47c4-4cb7-a904-7e45d9f7f2e7	2026-01-06 19:43:02.086611+00	42.9	30	835240	835240
93171f4e-29b6-44c1-96ba-64d22928dc06	2026-01-06 20:04:02.107715+00	51.4	30	571754	571754
8870df2e-9748-4ca5-af84-f569761db38b	2026-01-06 20:04:25.913333+00	43.9	30.1	2108365	2108365
425f24c4-cfae-4ff8-8a5b-df447b5526cb	2026-01-06 20:04:50.581888+00	37.7	30	4275760	4275760
f1cf55e3-1eed-4c24-ba2e-d8fb27fed6bd	2026-01-06 20:04:52.148912+00	46.2	30	576751	576751
caaef597-d6d9-47ab-a531-853f222f7e6b	2026-01-06 20:05:22.319477+00	46.4	30.1	4042190	4042190
75271094-7581-4e31-ae25-3ba5f7ff1b4b	2026-01-06 20:06:21.551739+00	33.9	29.9	912688	912688
58f13ce0-2427-48fe-9c10-f5a6aaeeab02	2026-01-06 20:07:22.344497+00	44	30	1608178	1608178
083b5559-46ac-4537-8d72-4510863c8667	2026-01-06 20:08:22.410145+00	42.2	30.1	5911364	5911364
7aa380a0-49ea-4054-83e0-2451aa79de01	2026-01-06 20:08:50.650371+00	37.3	30.1	3429843	3429843
e916ca31-52a8-4433-a921-85ba3544ace6	2026-01-06 20:09:23.028469+00	38.8	30	107111	107111
ec4ec77a-fe63-4f70-ae34-24fbbae95fce	2026-01-06 20:09:25.899265+00	43.8	30	2135097	2135097
03efb973-acd2-4f50-bea9-a81537dd501b	2026-01-06 20:09:52.04647+00	71.3	30	6070324	6070324
45f4445e-42df-4fc9-acc0-52b76b6cea81	2026-01-06 20:11:21.646904+00	32.1	30	671442	671442
91edd8b0-35d4-40bc-83ff-8e600f7ea230	2026-01-06 20:11:22.795028+00	42.9	30.1	4572932	4572932
35b79164-fe7e-418f-81d9-1d0ca6c5a50b	2026-01-06 20:11:51.643239+00	55.8	30.1	476867	476867
714fa59f-228f-4976-9b6e-51b53b4a20c1	2026-01-06 20:12:21.587488+00	32.3	30.1	3058609	3058609
a505b613-449b-4747-9c66-fbc49f6e0a56	2026-01-06 20:12:50.445952+00	43	30.1	757126	757126
9d9c967e-3cfd-484b-a2fb-1cb3a82c7eb1	2026-01-06 20:28:45.632795+00	39.8	30.1	4397602	114889
ea2a71fe-c94e-4e94-8f67-395482fe529b	2026-01-06 20:43:45.828526+00	33.9	30.1	1842835	39881
8cde7a44-a6a8-41d8-b76d-4ec2ead0c25a	2026-01-06 21:10:46.229589+00	3.9	21.6	1732	296
28be2b6e-1e47-42cb-b7e3-704eb23d5c76	2026-01-06 21:39:46.59267+00	4	21.5	1274	198
6ceb70ba-4a14-4f2d-8728-7dd3f1bf3a79	2026-01-06 22:08:46.949397+00	3.8	21.6	1407	291
d55f6710-fd10-4ade-8ba3-571fb1ef84aa	2026-01-06 22:37:47.269777+00	4.1	21.5	1254	189
a8f2a27c-6ee0-4b73-beae-ecb6a904f300	2026-01-06 23:06:47.654394+00	2.7	21.5	1457	307
e6344ba2-9b33-4e07-877f-6702261cb3c7	2026-01-06 23:35:47.921788+00	3.1	21.5	1312	198
bb01fbc2-c05d-4027-b4fc-a7d8d38d1ddd	2026-01-07 00:04:48.336713+00	0.9	10.1	1249	22
a83890c0-a9a7-4a93-9bdc-925c863bd7dd	2026-01-07 00:33:48.69941+00	1	10.2	1518	24
7b68119e-9d70-4207-803e-e1f0f401da96	2026-01-07 01:02:49.111937+00	0.9	10.1	1542	17
5c810e1b-f436-48ce-9cdb-5ee7323117a6	2026-01-07 01:31:49.506985+00	1	10.2	1687	23
59bde9fe-1cdc-4ba5-aa6f-62051aedb2f8	2026-01-07 01:58:01.010562+00	2.5	11	544060	544060
fe807233-635f-41ca-b5ae-b77900c234be	2026-01-07 01:58:01.258229+00	2.5	11	412125	412125
0c4c409f-31e7-49e3-9a53-00c32bd72d42	2026-01-07 01:59:00.06692+00	3.8	11	9367	9367
f91de47a-0a41-41f9-8c54-8256ef6dca91	2026-01-07 01:59:00.171158+00	3.8	11	674914	674914
24c5f995-4341-48fc-a39b-7873374ced32	2026-01-07 01:59:00.718996+00	3.8	11	511973	511973
4c0f76c8-ba8b-4af3-858e-d6834e029c8e	2026-01-07 02:00:00.052613+00	1.9	11	9138	9138
d4888596-2f12-4652-ad43-ba9e81f75285	2026-01-07 02:00:00.721955+00	1.9	11	513038	513038
37a21898-00f5-47ab-94e3-be79c29aae5a	2026-01-07 02:01:00.78812+00	2.9	11	542559	542559
9646cb34-e9bd-4703-9d86-e7486adfa62b	2026-01-07 02:02:01.045418+00	2.7	11	465645	465645
86f13c89-988f-47e5-af4d-8dbff677d3b1	2026-01-07 02:03:00.676342+00	2.6	11.1	497713	497713
60fb6d16-d99b-48c2-b2d9-62a0937daa21	2026-01-07 02:04:01.258927+00	2.6	10.9	583282	583282
dce05819-0e9d-4a9a-ad58-22cf93dbb92a	2026-01-07 02:05:00.781922+00	3.3	11	665878	665878
e9385ad0-c09c-4514-85e3-03f8f10cb7f3	2026-01-07 02:06:00.09366+00	2.8	11	8018	8018
027d26c8-decc-46c0-b7ce-90ebc4c784bb	2026-01-07 02:06:00.664651+00	2.8	11	745403	745403
43b902f4-58ac-45c5-a0c8-f572c33dca23	2026-01-07 02:07:00.772595+00	3.5	11	686334	686334
e85a4e90-9c85-4c3d-acd2-61f4e1bc0b58	2026-01-07 02:08:00.164975+00	2.1	11	628474	628474
51adc101-69b5-45f3-a620-63e7631d8c16	2026-01-07 02:08:00.573107+00	2.1	11	701183	701183
03781763-4b13-4926-85e7-8fde3e5ba2b2	2026-01-07 02:08:00.796228+00	2.1	11	589873	589873
32fdd0e9-c2d1-4685-a377-1dbd85714c99	2026-01-07 02:09:00.059664+00	4.8	11	9486	9486
f4193221-fe1e-47c2-bd42-5b5b066391af	2026-01-07 02:09:00.880794+00	4.8	11	557975	557975
0d9f24b3-8a5f-4b92-ad74-22fe50b4ad37	2026-01-07 02:10:01.073827+00	3.9	11	435911	435911
dedb1067-bdec-49bd-ae0a-b2350bfcf8a4	2026-01-07 02:11:00.066961+00	2	10.9	8221	8221
bb834130-b3f8-4b6d-b01d-4261d6aa51a3	2026-01-07 02:11:00.735461+00	2	10.9	328667	328667
66e106c4-3525-4602-bf55-03cf96939fc8	2026-01-07 02:12:00.69922+00	2.3	11	738471	738471
4a049da1-a189-4d52-93fb-f9244874d5a4	2026-01-07 02:13:00.155467+00	3.4	11	12055	12055
0ebca7bd-7a2f-45fa-b6d1-e9648145b71a	2026-01-07 02:13:00.910176+00	3.4	11	562158	562158
77e49e22-5988-45d2-8506-f9e46e5b3a82	2026-01-07 02:14:00.726923+00	2.7	10.9	658418	658418
bbd43389-1f95-48e6-b743-96a2aad02669	2026-01-07 02:15:00.846895+00	2.4	11.1	880039	880039
0ee142d9-51d9-494c-84c2-ea75ea87e67e	2026-01-07 02:16:00.80906+00	2.3	11	589161	589161
47945f79-746d-4be9-a71e-df8d97616be0	2026-01-07 02:17:00.756129+00	2.2	11	512896	512896
c7101089-9500-43c1-96aa-1f045c93d8b3	2026-01-07 02:17:00.958954+00	2.2	11	521567	521567
573de571-d90c-4af3-9351-95c7135bfb19	2026-01-07 02:18:00.075061+00	2.4	11	9351	9351
a39e497d-2059-47dd-9c0c-01ccb305b58c	2026-01-07 02:18:00.913816+00	2.4	11	628625	628625
79b19976-3a6e-4223-9777-9fe0e7b8e7a7	2026-01-07 02:19:00.749022+00	3.5	11	620532	620532
d2150f88-ebd5-484f-b730-cba48dfebd89	2026-01-07 02:19:50.131562+00	2.9	11.1	32663	25881
159f0103-34a6-4e56-93fb-c5b0cf8f6c9e	2026-01-07 02:33:50.308805+00	2.5	11	29064	21728
d6fec751-9bf9-4384-b7b3-61b8dd34bc87	2026-01-07 02:54:50.58477+00	3.7	10.9	32981	57656
8e43dbf8-5ed3-49fd-bf2a-8cdaa2c76abc	2026-01-07 03:01:00.837405+00	2.8	11.1	497735	497735
7a54cd14-41e4-4ffa-96cc-9917e847e302	2026-01-06 15:18:27.548725+00	20.1	25.7	296184	296184
8c79d3a2-c2bb-4bfc-9524-976510e49a21	2026-01-06 15:18:41.090658+00	28.3	25.9	76056	55931
402f0619-b113-419c-865a-16131e13be10	2026-01-06 15:18:44.286226+00	23.7	25.9	740539	740539
022108a5-f77b-471f-991f-261a7dd7a47b	2026-01-06 15:18:51.490081+00	32.8	25.9	385559	385559
d7df8d6f-ec47-4119-a9c7-973928b2cc1d	2026-01-06 15:19:19.084677+00	21.3	25.9	527437	527437
ac8c82d4-093e-40c4-8500-53c1cb2b5fb3	2026-01-06 15:19:27.49883+00	19.8	25.8	877293	877293
9ab427f8-ab07-4e00-8f26-31373d45edc8	2026-01-06 15:19:28.491239+00	25	25.9	904847	904847
405f0d87-9da9-4521-abce-c889e6df1053	2026-01-06 15:19:29.684433+00	25	25.9	743231	743231
cfee425b-b084-4a66-a657-cfa1466885f8	2026-01-06 15:19:36.065135+00	22.6	26.9	649040	649040
4c34e662-a50b-4645-98a4-752e444c3af1	2026-01-06 15:19:41.142757+00	28	27	38173	38785
4c8d2557-79ec-4b81-8883-0add2ee4642d	2026-01-06 15:19:52.697299+00	26.7	27.1	213827	213827
5cc8485a-d203-4af5-84f8-c748965668f0	2026-01-06 15:20:08.553775+00	24	27.2	413423	413423
2d6a2ed3-a500-42c6-b8aa-6cb4dee1be9f	2026-01-06 15:20:15.480535+00	20.6	27.2	696027	696027
8254b565-7c4d-4286-8064-3cb8022c2da4	2026-01-06 15:20:19.076553+00	19	27.2	831977	831977
8690c962-add0-46d3-a0f2-9101877e5e34	2026-01-06 15:20:27.50276+00	23.9	27.2	1076083	1076083
3c4a4c1d-e17b-4569-9be6-b8ede08f3856	2026-01-06 15:20:28.472229+00	19.1	27.2	1431541	1431541
e43e7903-e81c-47b6-88b1-0504dc251db3	2026-01-06 15:20:29.695136+00	19.1	27.2	499562	499562
3c75ea6e-05d6-4fac-8a65-48020e03ff88	2026-01-06 15:20:36.068152+00	20.2	27.3	608937	608937
9cd5e786-3ebc-4763-8b31-0e1282c4f984	2026-01-06 15:20:41.116643+00	23.2	27.3	173363	106445
39266bb6-980e-4e84-bd20-31146d6de721	2026-01-06 15:20:52.676603+00	15.7	27.2	286009	286009
8f6d8c20-74a5-48fa-aa76-3a24b30531a4	2026-01-06 15:21:08.556705+00	21.3	27.5	492477	492477
54368903-016f-44b0-a5cf-2b12fc62ae42	2026-01-06 15:21:15.479407+00	25.5	27.7	675454	675454
de3d31b4-ea25-436f-9756-aa4339eef88d	2026-01-06 15:21:19.061418+00	28.7	27.6	1553000	1553000
bbc3228d-d601-44c1-8724-9a9b29c598a2	2026-01-06 15:21:27.477017+00	15.8	27.5	642034	642034
20078ceb-45bd-4c4d-bc11-e75305a10d23	2026-01-06 15:21:28.46497+00	15.8	27.5	851441	851441
086a1c1c-7efd-4cb4-b2e0-e35ab31af182	2026-01-06 15:21:29.708492+00	22.9	27.5	479385	479385
bc389871-6e9f-43f8-801c-00dde60dff45	2026-01-06 15:21:36.056149+00	21.3	24.6	831176	831176
992dec99-d854-4c6b-a7d8-f3df1cbddcc5	2026-01-06 15:21:41.157936+00	25.9	25	46059	37652
1736fdd3-6e22-4a7b-bd6e-e45654c0611f	2026-01-06 15:21:52.627942+00	13.6	24.9	155125	155125
c60ed03c-c0d4-4195-a1c0-1734abfe705f	2026-01-06 15:22:08.543394+00	18.1	25.8	324875	324875
c27363c3-8a6b-486e-b19f-15a9be1bbdd7	2026-01-06 15:22:15.469815+00	15.7	26.4	1099110	1099110
3c3c6904-6ad7-4592-8f3f-01ef898c75b4	2026-01-06 15:22:19.061422+00	16	26.2	1317499	1317499
f8a2c545-713b-4aff-9942-d0d4e1aa26da	2026-01-06 15:22:27.568161+00	59.8	28.2	957457	957457
d12ea88a-3185-4152-a9e3-f239e2af93d1	2026-01-06 15:22:28.520921+00	25.4	28.6	438799	438799
d963c007-8699-48e2-9010-85038d968a7f	2026-01-06 15:22:29.708263+00	25.4	28.6	359629	359629
18fe36e8-a3e6-40b0-854e-fd0cb84a808e	2026-01-06 15:22:36.03427+00	37.3	28.7	880732	880732
1be2bc52-dda1-4e07-b909-28abe8053bf8	2026-01-06 15:22:41.185549+00	24.1	28.7	33198	313630
852c227b-74a1-4d7d-b66c-3ed4b13600b8	2026-01-06 15:22:52.801508+00	15.3	28.5	185160	185160
5f38e1e6-cf68-4eb7-bb24-264f113e67e3	2026-01-06 15:23:08.537734+00	15.9	28.2	315423	315423
95ca8e35-fd9b-4efe-8d97-17a334490cc1	2026-01-06 15:23:15.481+00	0	28.2	754958	754958
64568f8d-aeb1-4a1c-89e3-80afd13515a9	2026-01-06 15:23:19.06948+00	14.1	28.2	1014898	1014898
86d3c57e-e1e6-47d4-933a-edcf32c4fcac	2026-01-06 15:23:27.475549+00	33.6	28.1	1028358	1028358
1c073dcd-02e6-4ff0-a1a6-6f7a8ee222de	2026-01-06 15:23:28.489799+00	33.6	28	757601	757601
473f407a-78d0-4454-b73f-2cd6ac70c126	2026-01-06 15:23:29.670429+00	26.6	27.9	507278	507278
69eb63d6-1f6f-4f5a-a6b7-1554cba5ecf4	2026-01-06 15:23:36.032108+00	20	28	965369	965369
9c89f679-4968-4b50-ac26-8db9814a995a	2026-01-06 15:23:41.164724+00	26.5	28.6	73964	301261
f51a6765-0c26-43b2-ae91-f23830a9a55e	2026-01-06 15:23:52.551127+00	58.4	29.6	291451	291451
7f0a46ea-5ca8-4e96-8bdc-f4defc02cc7d	2026-01-06 15:24:08.518742+00	35	26.6	1119244	1119244
8779ea73-ec49-4271-9df2-a27e8a0d02f3	2026-01-06 15:24:15.482597+00	25.3	26.6	1459024	1459024
68e0eb4e-19d5-4dbb-b8c5-330705d9f53a	2026-01-06 15:24:16.362354+00	24.7	26.6	996823	996823
8a898c4f-111b-492f-bee9-4979c926c4c2	2026-01-06 15:24:19.138084+00	30.1	26.7	1935178	1935178
1cccf7d3-d841-485f-aa83-d66fa1a54170	2026-01-06 15:24:33.703362+00	35.1	26.3	2847224	2847224
e7ccce25-109f-4a9d-accb-d9e43dcd1723	2026-01-06 15:24:33.887151+00	35.1	26.3	1995521	1995521
84a0a2ac-6b6d-42ee-acdb-ae0f47bdd1db	2026-01-06 15:24:34.010977+00	35.1	26.3	812879	812879
0018a4e6-04ef-4522-8f05-c809871c255d	2026-01-06 15:24:34.483234+00	35.1	26.3	239379	239379
bf3bd39a-fa31-4d2d-abdf-7c440b232ead	2026-01-06 15:24:36.097756+00	41.9	26.6	3022919	3022919
b2bb6540-4efd-41b5-98bd-6475037748f3	2026-01-06 15:24:41.236901+00	50	26.8	4535280	125151
4b78c2e4-86c5-428d-997a-6d0c27f47a38	2026-01-06 15:24:42.884576+00	51.9	26.9	437583	437583
9535b24c-e535-454b-8342-e2157dbd0d8a	2026-01-06 15:24:52.990121+00	37	25.1	338309	338309
6567e1b2-527f-4d2d-82aa-6fac20e3f048	2026-01-06 15:25:08.496488+00	40	27	656451	656451
87f6ceb8-803d-4477-84cf-3360ee4d8158	2026-01-06 15:25:15.484565+00	42.6	25.9	898444	898444
1e278a8e-4ca7-4bae-8fb5-22451f203d2f	2026-01-06 15:25:19.114509+00	32.8	25.9	1187799	1187799
50b2ffc3-dfee-48aa-9e94-d4ad3c63df76	2026-01-06 15:25:27.507182+00	34.1	26.4	769660	769660
a41d4dd9-82ab-4a93-bab1-486bdc530177	2026-01-06 15:25:28.519886+00	34.1	26.4	880607	880607
3ab6e1b8-b920-4ba5-ac57-367ca5c15e07	2026-01-06 15:25:29.727771+00	30.4	26.3	239871	239871
500a7b77-9f53-42f8-ba8d-0a587d46eadc	2026-01-06 15:25:33.929368+00	26.6	26.3	385982	385982
982d50c8-83fa-48da-913c-b5b4a858696f	2026-01-06 15:25:36.063761+00	25.2	26.3	828437	828437
01c6f6f6-5067-46a6-888b-3805331b1633	2026-01-06 15:25:41.192587+00	26.4	26.3	38410	23194
a329963f-5d50-420c-b452-f7ee18d5b147	2026-01-06 15:25:42.536964+00	21.9	26.3	640990	640990
34e95f3a-e31f-4412-8c4d-5fef93d864aa	2026-01-06 15:25:53.049946+00	27.3	26.3	193312	193312
d5f32057-10ef-47d6-a38c-2eb560874737	2026-01-06 15:26:08.536996+00	21.5	26.2	395314	395314
da44af19-1640-49db-8392-cc0dcff517bd	2026-01-06 15:26:15.449968+00	23	26.4	466409	466409
7723206b-0336-4d8c-be01-90db9018e9f9	2026-01-06 15:26:15.507198+00	23	26.4	666808	666808
e0d141ef-d056-43a3-b559-f0f0b2be9fa6	2026-01-06 15:26:19.113493+00	31.5	26.4	277940	277940
980ec8f1-d47c-4e30-8694-f93b6aba5e50	2026-01-06 15:26:27.489476+00	28.5	26.5	946977	946977
3c6352c4-26e9-4f67-9cdc-eb2443aaa449	2026-01-06 15:26:28.477971+00	28.5	26.5	920309	920309
7aad7920-f161-4d70-9841-1e8b82bf8fa1	2026-01-06 15:26:29.751176+00	25.3	26.5	266179	266179
833aad8b-b047-460f-8a9a-875e16f820f5	2026-01-06 15:26:33.908823+00	25.2	26.4	303036	303036
5a8ca5a6-cf19-4629-9622-a18565c9d53f	2026-01-06 15:26:36.098257+00	25.6	26.4	315754	315754
44cbf9a1-0d77-4c51-b3db-9e9721a18cf3	2026-01-06 15:26:41.243106+00	34.4	26.5	15821	10623
de4046a3-92f6-4b57-b501-f2ebe96bf778	2026-01-06 15:26:52.711744+00	21.9	26.5	195329	195329
0d968b11-2334-41e1-9975-4ee00563b5a0	2026-01-06 15:27:15.440244+00	7.5	26.4	573973	573973
b67afc19-541d-45fd-b6aa-73e711e3ade2	2026-01-06 15:27:41.211468+00	6	24.3	28257	18397
28224b34-3ef6-4a75-9291-f5b2486ed545	2026-01-06 15:28:15.495376+00	7.7	24.6	224554	224554
0327101d-a579-4758-90c6-a59aa38eab2e	2026-01-06 15:28:41.232997+00	8.8	25	31904	19827
23805a88-7056-4bf6-bfc1-4eed20fe681c	2026-01-06 15:29:15.486068+00	9	28.5	462763	462763
78bf13c0-f4cb-42bc-9079-f71a7d2613fc	2026-01-06 15:29:41.232211+00	11.7	26	34655	290014
90804f38-2178-424e-9ff2-43c89e93a56f	2026-01-06 15:30:15.454368+00	4.8	26.7	767512	767512
9695c4b2-b688-4ae1-b07f-a947e63e47b8	2026-01-06 15:30:41.225352+00	7	26	26399	18048
9ace6857-e75e-4dfa-baab-6223fc633f81	2026-01-06 15:31:15.45912+00	5.4	26	762875	762875
097088b8-ef7b-4a5b-8e8f-36f1657d3fac	2026-01-06 15:31:41.253788+00	7.5	26.5	37222	336709
77a11ea9-127d-475f-8cb4-62f583600ab0	2026-01-06 15:32:15.490753+00	9.1	26.1	301720	301720
9e06c6b8-a97f-46b1-816a-ab8d38f5c9f6	2026-01-06 15:32:41.274154+00	5.5	28	25820	17686
46cd656e-b1eb-4d27-b2c0-aad8180acb0b	2026-01-06 15:33:15.46061+00	4.3	27.9	551201	551201
c5703d69-8de3-4292-bb7f-8a9f40f162fc	2026-01-06 15:33:41.294421+00	6.5	27.9	25744	18701
ce80c623-6793-4e0a-8d53-9b2e223e7d4d	2026-01-06 15:34:15.47149+00	4.8	27.9	577414	577414
93f7b41f-1949-4138-b012-7b1365d90605	2026-01-06 15:34:41.304588+00	7.4	22.6	26943	19411
caacc041-7d3e-4cd9-9a87-a865dc59a6b4	2026-01-06 15:35:15.446356+00	6.8	20.3	684364	684364
f67b5134-e4b8-4113-91ff-a80e47c8eb41	2026-01-06 15:35:41.313243+00	6.5	20.4	26153	18686
912755ad-7548-41ae-9897-77dd5283a51a	2026-01-06 15:37:15.490252+00	7	19.1	274737	274737
d4a31c11-91b9-4662-bf9b-3ef68dcc26d4	2026-01-06 15:38:15.462567+00	6.1	19	438649	438649
2803aa08-7f19-4f47-947f-104122ea0a84	2026-01-06 15:39:15.518635+00	5.7	19	870325	870325
2deac8db-3121-4451-815f-50721fe510c1	2026-01-06 15:40:15.499731+00	5.5	19	337797	337797
81c64d42-833f-4c81-a495-651c2279d524	2026-01-06 17:58:43.409044+00	38.4	29.7	4506230	120509
a547270a-c651-473f-a9fb-9e1bc87ceb6c	2026-01-06 18:22:43.783001+00	39.3	29.7	4366081	117566
e63b3468-e4c9-4a6e-bdf7-308e333923be	2026-01-06 18:48:21.556255+00	38.8	29.7	2395245	2395245
d36eb672-eb26-49b4-99b6-ac980b3e16a6	2026-01-06 18:48:52.029061+00	72.8	29.8	2200942	2200942
f420cd61-e712-42fb-88c7-d59dd29bd517	2026-01-06 18:49:02.107321+00	49.3	29.8	5682673	5682673
f7775f9c-4bec-4e65-a66f-95ff44690f5b	2026-01-06 18:49:22.673131+00	35.2	29.8	405011	405011
d2d50fdc-6099-46bc-a360-5442f477d620	2026-01-06 18:49:51.827803+00	53.2	29.8	2572147	2572147
d68a4b9a-9f56-4422-927d-dc0ceee85a92	2026-01-06 18:50:21.614017+00	44.1	29.7	5762415	5762415
4dda50bc-7488-4b12-8d94-038a90dcb7e4	2026-01-06 18:51:02.047973+00	47.2	29.8	4848862	4848862
7fe40b4e-96e8-42fa-9466-802245774937	2026-01-06 18:51:22.353796+00	37.7	29.8	5928477	5928477
5635ef72-8113-41eb-aea9-b10cddcc24dd	2026-01-06 18:52:52.010047+00	48.7	29.9	4569433	4569433
5ebf51c0-9529-40b0-805d-bca3906d49f7	2026-01-06 18:53:21.507865+00	37.1	29.7	607049	607049
e1a3f592-12ee-4613-97ee-0de454dacd08	2026-01-06 18:54:02.102555+00	44	29.9	4428451	4428451
ba53264a-59a4-4a3d-8517-f3b9e28b98fc	2026-01-06 18:54:22.592155+00	40.5	29.8	3175866	3175866
e4e88eb4-8266-4043-b372-55c10dc0257a	2026-01-06 18:54:25.923601+00	46.1	29.7	1405270	1405270
9649231a-0b68-4e1e-b408-6a9d2eb5d8f1	2026-01-06 18:54:50.601021+00	42	29.9	672513	672513
2afcadaf-7d5b-415e-bd4d-d2f3c305eba6	2026-01-06 18:55:21.550963+00	44.8	29.8	3698622	3698622
283f8123-93ae-493f-8227-9686bdeb0206	2026-01-06 18:55:51.942101+00	41.2	29.8	3019431	3019431
389fc884-1762-4294-a458-ad21e2fea3a4	2026-01-06 18:58:22.302694+00	49.5	29.9	687167	687167
335fc387-bb67-4fe0-b30c-e360a4d5235c	2026-01-06 18:58:50.395703+00	36.3	29.8	1903014	1903014
e37ede0b-0346-43ca-8425-e0e10d93adff	2026-01-06 18:59:21.60196+00	46.6	29.7	3850641	3850641
1f28265f-e30c-4e5f-8ba4-c49fa22ac960	2026-01-06 18:59:22.785226+00	38.5	29.8	3684138	3684138
b2a0cadc-18c4-4d8b-9ced-8b3667491a93	2026-01-06 19:02:25.941632+00	44.2	29.8	3349375	3349375
efb3dba6-e25a-4304-9eb3-4639a1c3a36f	2026-01-06 19:02:50.382608+00	41.5	29.8	1739495	1739495
dda5e804-1ff0-4cfa-929e-36e22ed9b16d	2026-01-06 19:03:21.527813+00	43.2	29.8	2009946	2009946
895d9efe-69fc-4585-9ead-a30b83f75953	2026-01-06 19:03:22.277496+00	46.9	30	5361077	5361077
a4793ad0-9980-4ba6-9acd-2260488d833a	2026-01-06 19:03:50.543546+00	39.3	29.8	3843309	3843309
619d6e02-7799-47c6-82b3-fcc7b9e8df6c	2026-01-06 19:11:50.576018+00	36.8	29.9	2565061	2565061
1d4f3bab-8876-45c2-94d3-478d51859ef5	2026-01-06 19:12:22.352093+00	47.7	30	3424028	3424028
81eadfe4-eb90-49d9-b0a1-e2586022a8ed	2026-01-06 19:12:50.504046+00	34.7	29.9	3745916	3745916
046dd462-9cc8-4420-acd1-404aa95d82d4	2026-01-06 19:12:51.844217+00	54	29.8	4146029	4146029
96ef3f72-277e-4cb7-8faf-5701e813a551	2026-01-06 19:13:02.068101+00	50.4	29.9	868928	868928
932aca4a-244a-4c58-b2c5-ad9bd30fa527	2026-01-06 19:13:21.540526+00	36	29.8	3707082	3707082
abcd00c0-d3e0-40e8-82cd-22e60899703f	2026-01-06 19:14:21.583926+00	38.3	29.9	3609955	3609955
3fa4f1fa-cdfe-45b9-9227-e43627f1a5ee	2026-01-06 19:14:50.540904+00	36.3	29.9	5381314	5381314
82759ac3-b39b-4c8f-a643-9133c6d073d9	2026-01-06 19:15:21.55211+00	33.7	29.8	5344732	5344732
b56289f4-22f8-49e6-a152-e213f282ae05	2026-01-06 19:15:22.297893+00	39.1	29.9	4849700	4849700
5b905a14-983a-447f-ae24-9cb2e3c11f0c	2026-01-06 19:15:25.929481+00	53.9	29.8	2123970	2123970
25dc10cd-9b37-443d-b7c5-8ab530e62b47	2026-01-06 19:16:21.572382+00	38	29.9	4411954	4411954
256725e6-080d-45ac-b11c-f2f5c19f1322	2026-01-06 19:16:22.291807+00	36.7	30	2708021	2708021
6b94ec06-c871-4493-9f47-f45d511d2c3d	2026-01-06 19:16:25.955566+00	50	29.9	2827954	2827954
286c7c86-2238-44b3-86bf-4bbec82699a1	2026-01-06 19:17:02.075825+00	51.9	30	4887867	4887867
214f7d07-3db8-4c6a-ba1d-39d38750767c	2026-01-06 19:17:21.577849+00	44.2	29.8	3153167	3153167
a41426dd-573b-4b1b-8093-afb66e8a7522	2026-01-06 19:17:50.317642+00	32.1	29.9	3659399	3659399
552a3727-f3ec-47e3-aee9-8974ef5f8232	2026-01-06 19:17:51.65108+00	50.4	29.9	334320	334320
15ff3eaa-9087-438b-8893-53238712b8b8	2026-01-06 19:18:22.282691+00	53.8	30.1	6753853	6753853
077579ee-5daa-468e-88f9-870e12b93a90	2026-01-06 19:18:25.949143+00	45.8	30	2164818	2164818
e6973072-9e87-4cd5-aa35-9f5b0f236848	2026-01-06 19:19:22.406802+00	43.7	30	710565	710565
2b4db488-999c-4502-b69c-591cbe8f2555	2026-01-06 19:20:25.909185+00	42.9	29.9	3740102	3740102
950124d4-ec22-4ec4-978e-d81f3b63827c	2026-01-06 19:20:50.499796+00	33.1	29.9	867502	867502
161c4248-ab3b-4f71-bd24-3fee2f6791e1	2026-01-06 19:22:22.777727+00	42.6	30.1	3297110	3297110
c93bd6b2-3934-44fc-9ee7-9914446d2544	2026-01-06 19:22:50.543928+00	32.6	30	4008088	4008088
d2300f0a-8e3b-45d6-bd87-ee0ecd25c464	2026-01-06 19:23:50.520705+00	36.6	30	5013700	5013700
92ec2408-a58b-4dbd-a124-11912f16648c	2026-01-06 19:24:22.712376+00	51.7	30	2878834	2878834
4c49d4e2-89a8-4a7f-a667-87bf5a972618	2026-01-06 19:24:25.930236+00	53.3	30	1651032	1651032
a88e3838-6a8d-4241-bf6b-087e83496682	2026-01-06 19:25:22.712926+00	44.2	30.2	5559652	5559652
f20dd243-dcb9-4dd3-9f48-ba80b9f59cdf	2026-01-06 19:26:02.09985+00	46.6	30	5583685	5583685
a56363ec-979c-47b8-9137-f8d4f2da0683	2026-01-06 19:26:22.394805+00	51.5	29.9	5812893	5812893
3e39a220-ec44-4d54-9e33-b3431ec4a258	2026-01-06 19:27:25.90999+00	52.2	29.9	618323	618323
044f16d5-d624-4528-9703-0f1e23321951	2026-01-06 19:28:21.583167+00	32.5	29.8	968078	968078
97101c6b-cbd5-426e-bb60-678111be1fea	2026-01-06 19:29:21.564424+00	31.2	30	942681	942681
007566ab-eb20-4fce-99aa-8e8b407dc90b	2026-01-06 19:29:22.3554+00	41.9	29.9	3795556	3795556
27850ee8-0e1f-4065-b0db-7e64f9bdc599	2026-01-06 19:30:22.712997+00	53.2	30	4547720	4547720
8ded9b23-7460-4b7f-8a84-e5e436f0f68d	2026-01-06 19:30:25.938591+00	56.8	30	498649	498649
2f99c6c2-704d-4507-acb5-fd166f8861f9	2026-01-06 19:31:22.685234+00	50.6	29.9	2657419	2657419
34a653d4-b7f2-452b-8ea3-5dd74806a471	2026-01-06 19:31:25.903736+00	53.7	29.9	561470	561470
ff9fbb85-bf53-411f-b817-029d0e149677	2026-01-06 19:31:51.804145+00	39.2	30	426135	426135
7e7c3893-73fc-4c5b-83cb-e0760131608a	2026-01-06 19:32:50.549064+00	38.8	30	3982954	3982954
44328fc0-14cd-418f-aab5-0c62d4659f86	2026-01-06 19:33:22.824088+00	49.6	30	246969	246969
318e774e-f4b4-4c30-ba75-80f77b359aa5	2026-01-06 19:34:02.077444+00	52.7	30	887110	887110
257078dc-1eb5-4c0f-806a-5b87d16614d5	2026-01-06 19:34:51.948566+00	44.2	30	2960717	2960717
7c5b929a-11a6-47df-8c14-36001e76cc0e	2026-01-06 19:36:52.101967+00	71.5	30	1194466	1194466
94d37e18-10b3-4293-89c3-13069d7dc358	2026-01-06 19:38:22.422113+00	43.5	30	518168	518168
a3c3ea60-0a32-407b-b5f2-bc3b0d9e48b7	2026-01-06 19:39:21.546197+00	30.2	30	1155364	1155364
b8390886-ef93-4ec1-a0ba-ca84db4c5262	2026-01-06 19:39:51.96824+00	70.7	30.1	2877099	2877099
7a17f961-9d7a-42b4-902f-acb9b6410df5	2026-01-06 19:41:21.571067+00	34	30	5692580	5692580
252d3967-b1ce-4ca0-8c39-268f730a2471	2026-01-06 19:42:25.942903+00	45.6	30	2754494	2754494
58aca0c7-36f7-4cd9-871e-89a68e9d05af	2026-01-06 19:42:50.513555+00	30.1	30	3878846	3878846
30aa0c49-54ac-45ee-a513-630a6bb988ff	2026-01-06 19:43:22.337456+00	47.8	30.2	5000684	5000684
136430a2-4fc4-4986-b432-45699d22a754	2026-01-06 19:43:25.946793+00	43.2	30	2225707	2225707
7caab62c-ee39-476a-b515-60ea30ff03e4	2026-01-06 19:43:50.646348+00	43.4	30	3507347	3507347
45607f28-f973-4305-8fd0-8841f652f846	2026-01-06 19:44:22.329208+00	42.9	30	3538609	3538609
a2ff0ff9-4df7-4a1a-b7a7-52905f194a57	2026-01-06 19:45:22.815775+00	45.1	30	6124429	6124429
39a23cd5-309a-4dd7-aeb1-6b0a195b1ca6	2026-01-06 19:45:50.555946+00	39	30.1	4192972	4192972
70ab3f6b-f859-4928-8ed5-67e143408cfe	2026-01-06 19:49:25.952035+00	43.3	29.9	1921459	1921459
fa8dc8a3-ec35-4746-8fec-59ea9c47a831	2026-01-06 19:49:50.444148+00	42	30	5583733	5583733
153250b4-ddec-41fd-9de4-893ba96bee92	2026-01-06 19:54:22.332637+00	43.8	30	5830588	5830588
993c5a3d-35b3-4c9f-b665-734694928ebc	2026-01-06 19:54:25.943712+00	55.2	30	291820	291820
5593b85a-b5d5-411d-8ef8-8dcc1dbd3982	2026-01-06 19:54:52.135893+00	39.8	30	5359756	5359756
60748ea3-0ff9-4690-a8d1-4fe3b4e3e4a4	2026-01-06 19:55:22.863482+00	39.5	30	5025108	5025108
13cae6bb-2d34-4d0f-9197-492dc6b7321e	2026-01-06 19:55:50.46759+00	39.7	29.9	3529252	3529252
4990810e-ad22-4142-98da-efeddcf54231	2026-01-06 15:36:15.495098+00	4.6	20.3	225285	225285
10dfaade-6761-4c64-b435-dd3ca5aeb494	2026-01-06 15:36:41.331661+00	6.1	19	23407	15504
239f2986-a524-4a39-b900-3d2a5a6c1c55	2026-01-06 15:37:41.342575+00	6.3	19	24598	17782
638710c0-e739-4388-9cc1-1f6e06368d3b	2026-01-06 15:38:41.362498+00	5.4	18.9	24243	16456
7bd89a39-17b5-4136-a963-2f6dd13c6ffc	2026-01-06 15:39:41.371098+00	5.9	19	23765	17078
4b3d1948-3f36-42c0-a06a-07f47490bf34	2026-01-06 15:40:41.357626+00	6.8	19.7	25567	17164
0facd63a-bf11-4fe6-8954-05f7259bead7	2026-01-06 15:41:15.449707+00	6.2	19.6	750954	750954
852255ca-d539-49f9-83d6-cf4e899362a9	2026-01-06 15:41:41.383985+00	6	19.5	25393	17405
0efca244-a1c8-4cc2-9b43-901e7d1a8637	2026-01-06 15:42:15.517526+00	7.4	26.2	284307	284307
d33500ad-727d-4653-b70e-2baeb44db4e2	2026-01-06 15:42:41.436662+00	7.9	25.1	42032	375658
251a3b2f-c58b-4c8e-a290-9c060e2df4fd	2026-01-06 15:43:15.457725+00	9.2	25	337140	337140
79472a15-b248-4cf4-bd49-0fd11d8c95de	2026-01-06 15:43:41.444071+00	9.6	25.1	0	0
cd75955a-1424-47a4-ad6b-152010c1869a	2026-01-06 15:44:15.460707+00	4.2	25.2	531989	531989
2488145c-dd9b-492a-ad63-3520a7a38e05	2026-01-06 15:44:41.490411+00	7.4	26	110760	62276
55a31f9b-4d3a-4d9c-9c19-81f8a91357c0	2026-01-06 15:45:15.475366+00	4.6	26	663618	663618
6ef97dad-fd8b-4e4f-8512-ab222f32f2ef	2026-01-06 15:45:41.441743+00	6.7	26	0	212508
99a27419-35e4-42f8-9deb-7684efb84388	2026-01-06 15:46:15.459763+00	6.5	26.1	661031	661031
5ec48d82-cbe5-469d-a01b-6d2ba525c5f8	2026-01-06 15:46:41.490917+00	6.9	24.1	48755	31927
615ebede-4c5f-4478-bbea-a3cab9b84fce	2026-01-06 15:47:15.458889+00	6	24.1	535726	535726
fdae92eb-561c-4800-9c9c-970ac86a60e7	2026-01-06 15:47:41.49039+00	6.2	24.1	32277	21370
a05c836b-c481-4240-96c1-7ebd48834a34	2026-01-06 15:48:15.449427+00	6.3	24.1	578656	578656
6aefe9c3-b4ed-4f99-bdf7-6828969d1e7b	2026-01-06 15:48:41.539414+00	8.7	19	22259	20799
3e64ec94-75bb-4857-96c5-32e69bcf750c	2026-01-06 15:49:15.457939+00	7	19	493621	493621
c6ceb890-0e22-49ca-8e05-801e05ceae57	2026-01-06 15:49:41.545416+00	9.7	19.1	20705	30512
32666ddf-54a3-4e14-b44f-eb8e4a33f069	2026-01-06 15:50:15.49744+00	6.1	19.9	312099	312099
dfe6596d-bb1a-45a7-a441-c58ef6e955e5	2026-01-06 15:50:40.56643+00	6.2	19.4	815113	815113
3050b0a6-28a0-4f41-a00a-f59eaf62fae1	2026-01-06 15:50:41.517276+00	8	19.5	96882	109880
8a818ba5-e9e1-4ab7-bb6b-59d6f2b36625	2026-01-06 15:51:15.461217+00	8.7	19.4	604491	604491
1405b774-93fe-41fe-845a-c4d4239c6581	2026-01-06 15:51:40.558484+00	7.4	19.4	693314	693314
a41b4e74-16e9-401a-89e0-7d87e8c94ddc	2026-01-06 15:51:41.551482+00	8.3	19.4	18200	17340
502248bc-a24b-493b-8a87-1e344057de80	2026-01-06 15:52:15.485314+00	9.6	19.6	282512	282512
51a36235-0028-4963-8396-282d3bdcd0c9	2026-01-06 15:52:40.550514+00	7.6	19.2	591589	591589
ec09a53f-bb62-4dc5-b02b-6aaca9a57829	2026-01-06 15:52:41.539474+00	7.6	19.2	20940	14896
adcc9fd8-e30e-4d2d-9a08-2514d1eb130d	2026-01-06 15:53:15.544938+00	8.6	19.2	634433	634433
ddd6972f-db02-4d81-8158-a05b2d54e425	2026-01-06 15:53:16.465307+00	8.6	19.2	983791	983791
f78c4008-1674-45c2-8f77-215cc0d87b74	2026-01-06 15:53:41.604166+00	6.8	19.3	17692	11252
c339e12e-634f-4122-bd4f-d6203b2b1d83	2026-01-06 15:54:15.452607+00	4.7	19.2	424108	424108
54ec87b9-fab2-46d4-9714-748fd5eac3e4	2026-01-06 15:54:41.620623+00	6.4	21.5	8886	10355
637e7aae-cd58-4b38-9283-62cd0eccf89d	2026-01-06 15:55:15.462931+00	8.4	24.6	440611	440611
d2737e12-fd42-485e-830f-b09ab0e091ea	2026-01-06 15:55:41.589095+00	7.9	26	17805	12012
ec3f2577-a00d-4941-a6c8-59f8ba4b429b	2026-01-06 15:56:15.518032+00	8	26.8	137439	137439
e546f8a1-fde7-4efb-acb0-2799f88152ab	2026-01-06 15:56:41.643899+00	8.9	26.5	10905	141537
08d2dab0-9878-4939-b8da-804b43392032	2026-01-06 15:57:15.476512+00	5.7	26.4	317395	317395
0b9bde33-023f-4aca-aa18-f37a3af0233d	2026-01-06 15:57:41.628973+00	16.3	25.7	18543	387683
59f0ec62-24e5-4c21-9767-74d86efc8263	2026-01-06 15:58:15.479065+00	13	26.1	608204	608204
2340019b-f14e-4d82-8e86-2bae41f6b0cf	2026-01-06 15:58:19.038686+00	8.1	26.1	428800	428800
1fdad92b-658a-4aa5-87a6-8b8da2ce4524	2026-01-06 15:58:41.677277+00	25.4	25.8	2550436	75782
25a27c43-153a-47dd-ab57-6c4270ed333b	2026-01-06 15:59:15.498643+00	31.7	24.4	3583310	3583310
e3dfd6a0-3d1e-4a4f-9179-e44d9577dc08	2026-01-06 15:59:18.766925+00	32	24.5	1540209	1540209
b019640a-77a6-4946-bd82-8fd38fd4f486	2026-01-06 15:59:41.696243+00	31.3	25.3	3653419	89391
697a83c1-b171-43c7-b62c-8c051f137f9d	2026-01-06 16:00:00.465572+00	35.6	24.9	2491895	2491895
8bad3aef-dc18-4746-a6e9-1abc426b0459	2026-01-06 16:00:15.463086+00	35.4	24.8	3427639	3427639
b54b9539-c281-4350-8f13-370b89d1ae31	2026-01-06 16:00:41.670702+00	34.2	25	5075605	130755
c6b47004-f691-471a-87e7-eac943a8f02d	2026-01-06 16:01:15.481129+00	33.7	24.9	4104283	4104283
ca8693c3-1688-411f-ad4a-776f56d0be07	2026-01-06 16:01:41.676122+00	31.1	26.3	18800	391490
094daad6-1389-4da1-bde4-41695773da5a	2026-01-06 16:02:15.474531+00	32.3	26.9	345024	345024
648208c8-5e76-4964-88f9-989a841a0c65	2026-01-06 16:02:41.679196+00	29.4	25	18513	321662
17e48aa9-3a6b-4cb4-abeb-b610a35d05d8	2026-01-06 16:03:15.476405+00	29.6	25.4	309833	309833
e799dac6-0a2b-4160-9528-2b44f92cc2d2	2026-01-06 16:03:41.700992+00	29.4	25.5	10823	7889
0bcdccf8-25b0-4714-9fa0-33c6b7260bca	2026-01-06 16:04:15.464272+00	29.1	25.5	431860	431860
7cb77272-689c-4a30-a277-dda653ca8dac	2026-01-06 16:04:41.723371+00	7.2	25.4	68534	40094
e2766b86-d653-4aad-bf8b-08335e7dd4b4	2026-01-06 16:05:15.460151+00	5.3	25.5	399805	399805
119c9a15-cb6a-47d8-8b6c-ea41679392e0	2026-01-06 16:05:25.910393+00	9.4	25.6	1099904	1099904
923be646-3f3d-4f73-b9cf-496522b73ed4	2026-01-06 16:05:41.72958+00	7.8	26.2	5504	8282
781665ab-d688-4744-97e5-35ce84646e2c	2026-01-06 16:06:15.455226+00	7.9	26.1	1078805	1078805
1de179ea-a4cc-4c99-8f9c-c516d10ee123	2026-01-06 16:06:25.900563+00	8.7	26.2	225263	225263
06edd1b8-624d-4e39-970a-da733356a881	2026-01-06 16:06:41.741091+00	8.9	26.7	15925	56665
cf8172e8-461d-4a9a-ae88-8c3183d4b5c7	2026-01-06 16:07:15.452978+00	7.3	26	1077986	1077986
805769da-0444-40d5-bccf-e1db07c43a49	2026-01-06 16:07:25.868946+00	7	25.9	690503	690503
a3c03013-99d5-4958-ba89-45b5ad20abcd	2026-01-06 16:07:41.772248+00	7.1	26	7630	8708
fe21d488-dc22-44df-891f-b3410fc7fc76	2026-01-06 16:08:15.457104+00	25.3	30.1	845867	845867
7891d6a0-de2e-48fd-bc86-5242f8e703ac	2026-01-06 16:08:25.908812+00	40.8	29.2	423981	423981
596085a3-a49f-4097-8e6b-0c525a39b5dc	2026-01-06 16:08:41.781497+00	9	28.8	9830	9482
f2fa2087-0ee9-42e4-af85-dd24dd85ec50	2026-01-06 16:08:42.084485+00	9	28.8	920726	920726
5d65735a-dbe6-4273-9425-5e53cc7012b8	2026-01-06 16:08:50.89561+00	27.6	28.6	2427384	2427384
51deb442-45d6-42e0-b621-112b785752e7	2026-01-06 16:09:15.46095+00	39.9	26.2	3302169	3302169
afad2a7c-d562-4c7c-878d-997b58fab1fd	2026-01-06 16:09:25.9917+00	38.3	26.1	2238955	2238955
203ac770-fd14-49b9-b4d0-54c10d4d952d	2026-01-06 16:09:41.790203+00	30.6	26.3	1288680	62440
702c12c5-08af-46f1-a133-5d1bb393522c	2026-01-06 16:09:49.607576+00	34.5	25.5	3294974	3294974
040b477c-2e71-4ea1-83ec-e779f6e84283	2026-01-06 16:09:50.529687+00	34.5	25.5	2964620	2964620
798ad882-8586-489b-8774-efb67cde1163	2026-01-06 16:10:15.476083+00	38.5	25.4	2633219	2633219
125045a5-a471-457a-a83a-64ee7a8751b1	2026-01-06 16:10:25.999165+00	37.5	25.3	323749	323749
eb2e89dd-45d8-4ae7-9203-4a6333157dce	2026-01-06 16:10:41.769925+00	32.2	25.4	4131204	470491
59a3bbcc-628c-4cca-971a-f5f2393cbfd2	2026-01-06 16:10:49.659508+00	38.6	25.4	4739097	4739097
5e5b8065-0175-4c94-a91b-d78ab72c3865	2026-01-06 16:10:50.535876+00	38.6	25.4	3108102	3108102
2cca79cd-99cf-4206-92b2-ac8e3a64c1b3	2026-01-06 16:10:56.854462+00	37	25.4	744547	744547
2e5d1392-1cb3-4557-8eff-4a0790607881	2026-01-06 16:11:15.479754+00	37.1	25.4	4562261	4562261
83f53f99-85ef-4110-b666-3b9c03bcbe05	2026-01-06 16:11:25.975642+00	34.8	25.5	198731	198731
2133fd31-b252-4b1f-8f05-2491b841804c	2026-01-06 16:11:41.819104+00	34.8	26	3899941	107219
7c3cd790-0ffa-403a-8110-065f794254cb	2026-01-06 16:11:49.731858+00	35.4	26.1	4626102	4626102
2097e2c1-6b49-48da-9cec-fd8f2aba291a	2026-01-06 16:11:50.515441+00	35.4	26.1	2603792	2603792
27b0fe1c-6f2a-4f62-bd21-306d5fc7b401	2026-01-06 16:11:56.537474+00	38.6	26.1	4111352	4111352
c68d906d-806b-4251-803f-7c721fbd1a99	2026-01-06 16:12:15.500867+00	35.5	26.6	3353928	3353928
ecf6e69b-0b1d-4a70-a51d-c44b2f67ab10	2026-01-06 16:12:25.973353+00	34.5	26.8	2891980	2891980
ec8916e9-dbbe-4752-aabd-9fd1a076f057	2026-01-06 16:12:41.834447+00	37.1	25.9	4936150	156476
a4f80ee4-e277-4a78-a583-be7aa2dd39a7	2026-01-06 16:12:49.802406+00	35.4	25.9	4165199	4165199
ec460863-8f00-4d6a-a657-aa506a0958ee	2026-01-06 16:12:50.540734+00	35.4	25.9	3887268	3887268
12295ce6-d7f7-4f06-81d8-690afa67fe68	2026-01-06 16:12:56.595306+00	38.4	25.9	1150881	1150881
f0498add-3972-4f0f-a51f-00d70b663808	2026-01-06 16:13:49.735253+00	29.5	26.9	704341	704341
13ed71d6-ea7c-46d9-a3a0-8775da6d6829	2026-01-06 16:13:56.517406+00	32.7	26.9	1205269	1205269
ea908347-dbe1-45c5-a92c-52da646690e0	2026-01-06 16:14:49.812943+00	36.1	26	4994416	4994416
9cb15549-da00-4d6c-96cc-5e70e3cb5770	2026-01-06 17:58:51.972265+00	44.2	29.7	6127477	6127477
72eb8057-4cbd-44b3-a19a-d1c4b1790a17	2026-01-06 17:59:22.761512+00	48	29.7	6142503	6142503
78785fab-9e56-430c-b357-064d75f821f4	2026-01-06 17:59:50.298389+00	42.2	29.7	3982869	3982869
3eb14abb-2e04-48c4-9ca0-c62d480bcdf7	2026-01-06 17:59:51.69985+00	42.6	29.7	6181638	6181638
96703161-17e0-4235-a7be-967d8cd62d11	2026-01-06 18:00:22.775216+00	40.2	29.9	3137692	3137692
d73798bc-68a3-40d2-a4ec-427a45e4f0e5	2026-01-06 18:00:50.331628+00	33.7	29.7	4758076	4758076
96450540-89b6-43fa-9e28-dca8a2cb0769	2026-01-06 18:02:22.863061+00	37.9	29.8	480931	480931
f8ec28d9-89ed-4d27-8599-647af316c96c	2026-01-06 18:03:25.950064+00	48.7	29.7	3306644	3306644
94620286-7027-4360-892a-e218b2842a3a	2026-01-06 18:03:50.613762+00	39.8	29.6	804246	804246
5d8edb33-95ea-473b-8aa9-14cfe944271f	2026-01-06 18:04:02.113691+00	42.7	29.7	5740674	5740674
db73c171-f7da-44d3-a0ae-94e32bc3fac0	2026-01-06 18:04:21.577361+00	32.4	29.6	3853132	3853132
90dd3df8-3f82-4afb-8f68-2c5f8f6622af	2026-01-06 18:04:22.323148+00	35.9	29.6	756346	756346
73ac1f86-5cd9-449d-b6c8-a60061e81dcf	2026-01-06 18:23:43.799895+00	40.6	29.6	3427416	86863
5a075247-5b0c-4e9d-adf2-caed2e74bd08	2026-01-06 18:48:22.35824+00	38.9	29.8	4354805	4354805
e47c2814-b334-447e-ae67-d62d6e0e665a	2026-01-06 18:48:25.926603+00	63.6	29.8	4061153	4061153
51679e46-8f6e-4873-9177-86eac6daa6cb	2026-01-06 18:48:50.409892+00	41.8	29.7	3605560	3605560
aabd9563-c90c-4ea9-86c8-b3acf8ca6c61	2026-01-06 18:49:22.303556+00	35.2	29.8	6264591	6264591
fded8ce4-de04-4bd3-aa8a-947f59d2db87	2026-01-06 18:49:25.920026+00	50	29.7	3641241	3641241
9bcc744d-7c53-41e1-b302-2e8766f2b272	2026-01-06 18:50:02.099719+00	51.5	29.8	665437	665437
45b10a68-58db-4ba0-9465-222bdcaca857	2026-01-06 18:53:25.919035+00	51.4	29.8	3770888	3770888
a1b12c9b-f540-42f8-a79d-2717157c833c	2026-01-06 18:53:50.558995+00	34.8	29.9	4417947	4417947
46925a33-1ac6-4b15-9575-c273376065d9	2026-01-06 18:55:02.117541+00	43.5	29.7	2629309	2629309
6c959f7d-8127-4469-8691-54c511483467	2026-01-06 18:55:22.602088+00	40.7	29.8	6174639	6174639
b79ce2cb-61b3-43ab-9c9c-9a06b875c8bd	2026-01-06 18:56:21.556075+00	37.7	29.8	5297522	5297522
e55c9887-009f-4860-8248-21b0c9a94fcc	2026-01-06 18:56:22.68623+00	48.2	29.9	5742041	5742041
b99b1838-e055-499c-b692-46e679a662ff	2026-01-06 18:58:02.111221+00	46.6	29.8	639265	639265
fec25f09-2cb7-48fe-8cb1-d2b887c45b6d	2026-01-06 19:00:22.838473+00	51	29.9	423640	423640
99dcd03a-7440-45b3-a5cb-5954c91a293e	2026-01-06 19:01:22.662496+00	38.4	29.9	246856	246856
fed41a26-9916-4d81-bf0c-00c761c919fe	2026-01-06 19:01:25.916236+00	43	29.8	2678779	2678779
c6c234e9-26c7-4d6e-ad96-892cfaef519d	2026-01-06 19:02:22.863591+00	41.2	29.8	5296695	5296695
a8a0710b-bf76-489d-8732-9886e01d70a2	2026-01-06 19:02:50.550137+00	41.5	29.8	3872994	3872994
d281935c-46ab-4dce-a105-843b17ca5106	2026-01-06 19:03:02.122956+00	42.6	29.8	5945932	5945932
016159df-5d8b-46e3-8179-7a355f5d2bc6	2026-01-06 19:03:25.929815+00	48.1	29.9	2187088	2187088
6a033876-800d-470d-9d49-1ba706a1632a	2026-01-06 19:04:21.600659+00	38	29.8	4434164	4434164
bffcbb0d-2ca3-431d-b658-c9263b3c03d4	2026-01-06 19:12:21.589414+00	42.2	29.9	5810185	5810185
2f5b17b7-ee84-492f-87bb-c396331d7937	2026-01-06 19:12:22.796118+00	47.7	30	4629784	4629784
d0d9f997-5efa-4258-8189-28facbc9218c	2026-01-06 19:37:44.894327+00	47.6	30	4314756	111389
da3dd607-ff3c-4dc2-ba07-d2b057344091	2026-01-06 20:04:22.368041+00	44.1	30	5677162	5677162
1ff6ab10-cf3a-48d1-a34a-63b82c4b22ce	2026-01-06 20:05:22.724991+00	46.4	30.1	1481554	1481554
113de1b0-7633-4d22-97cb-797c61719da6	2026-01-06 20:05:50.719908+00	39.7	30	3342751	3342751
d71771bf-fc61-4d58-b6c5-0ab52f490d81	2026-01-06 20:06:02.113632+00	53.8	30	697181	697181
b4caeca0-ca6f-413e-a025-8e3b77e909f9	2026-01-06 20:06:22.629317+00	39.3	30	406302	406302
ff11870d-8cfd-4a2c-a72b-5eef73ee07ac	2026-01-06 20:06:52.017141+00	71	30	2838791	2838791
8b5a19b0-0c35-4ddd-9a29-86b50e140288	2026-01-06 20:07:22.679714+00	44	30	283153	283153
5e991307-9f0b-4b0f-b8cd-d203a315f85f	2026-01-06 20:07:25.901886+00	44	30	3042267	3042267
1d32bccd-c25d-48ad-9117-b96d949fc2e1	2026-01-06 20:08:52.091722+00	40.9	30	3261077	3261077
3e3013c5-5ea2-40d6-b9be-7cbc7e38ae72	2026-01-06 20:10:52.028301+00	72.8	30	536831	536831
35e9751a-e755-4a48-aa7d-d3e72b61d9b2	2026-01-06 20:11:22.746775+00	42.9	30.1	291302	291302
5224cd93-d482-400d-b35c-2b4a2d6aa21f	2026-01-06 20:13:21.676798+00	33.6	30	2720510	2720510
b0d6c272-f8cc-4c98-bf9b-849baba339df	2026-01-06 20:13:22.76999+00	42.6	30.2	1461706	1461706
4af2186c-64c1-431a-a457-626194671a13	2026-01-06 20:13:50.410047+00	34.2	30.1	5475862	5475862
37edabaa-bc6e-4b47-9753-17f73c9fcede	2026-01-06 20:14:21.567115+00	34.2	30	4394138	4394138
3653ead4-947a-49d7-af54-f0159f343b33	2026-01-06 20:14:22.652102+00	42.6	30	5576249	5576249
540ba7cc-4529-4252-a917-a8410162b1dd	2026-01-06 20:15:21.607416+00	33.6	30	981663	981663
088b651a-d1f7-4c21-9cc0-0c982af84fe6	2026-01-06 20:15:51.816492+00	69.6	30	1275251	1275251
60082282-0505-4f48-8830-b701644594eb	2026-01-06 20:16:22.814947+00	39.5	30.1	2200360	2200360
3be95652-9c4a-417c-8518-758d9c25e3a4	2026-01-06 20:16:50.587882+00	37.5	30	4758316	4758316
ac6076a5-743f-4e77-ac95-e3bb0eb1ccd3	2026-01-06 20:17:22.760656+00	42.8	30	5296518	5296518
eb30d8d3-5988-46bb-ab61-b5bb822f2552	2026-01-06 20:19:22.317955+00	43.4	30.1	3906547	3906547
d311fc1c-2409-4002-911a-8a4022a8c4e3	2026-01-06 20:19:25.919278+00	45.9	30	2755270	2755270
39a310f1-1543-4c56-b2b1-6118196b2ee2	2026-01-06 20:20:02.013588+00	52.3	29.9	3190224	3190224
760477ad-aad6-4abb-95ce-c4132d2b4795	2026-01-06 20:21:22.345373+00	49.6	30	5012335	5012335
18cfad06-5dfd-4aa2-8b46-004ce06485b2	2026-01-06 20:21:50.693472+00	39.1	30	1402714	1402714
ff6ec27e-5dc2-42f7-9437-93738795f948	2026-01-06 20:22:22.648354+00	44.3	30	4734672	4734672
ec3b55e9-ec5a-47f3-a622-f369887768aa	2026-01-06 20:23:22.283332+00	44.7	30.1	7961499	7961499
1e81bc31-f2f8-455a-acf9-33402a8db81f	2026-01-06 20:23:51.985276+00	44.5	30.1	1935945	1935945
af0c6d48-2dac-4e12-8481-0141920c9c1b	2026-01-06 20:24:02.129883+00	45.1	30.1	3859449	3859449
4cbdcb73-e4ec-4dfa-879f-e0322da2aaec	2026-01-06 20:25:22.723815+00	41.8	30.2	3132392	3132392
fbc64601-40fb-4813-9b0e-7473d36cd20c	2026-01-06 20:25:50.3485+00	39	30.1	4964249	4964249
feac87a8-5356-4ca2-9c4e-5f6210c308fe	2026-01-06 20:26:22.733484+00	42.7	30.2	4851569	4851569
e1ea865d-598b-460b-959f-bd3dd8d5e68f	2026-01-06 20:26:50.39686+00	43.8	30.1	5511679	5511679
4ef4c340-1925-4bd4-a954-942bd40c524a	2026-01-06 20:27:02.100501+00	46.8	30.1	3659653	3659653
487e88f1-f4df-406e-a52f-783494a2f380	2026-01-06 20:27:22.797393+00	46.3	30.1	3616896	3616896
2cab2e6c-383a-4dad-9126-7cb03260d82e	2026-01-06 20:27:50.468762+00	40.1	30.3	4166258	4166258
224ff615-e0eb-43aa-b852-ed244fb965d6	2026-01-06 20:28:22.649257+00	38	30.1	354251	354251
8db01a57-89cb-49ad-82ef-d961b61e1b31	2026-01-06 20:28:50.438487+00	38.1	30.1	724167	724167
0619d4f6-aebf-4969-8528-e08dd351dd6c	2026-01-06 20:28:51.753262+00	44.2	30.1	1344773	1344773
744208f4-3502-4f8c-8b5f-9c25119d0291	2026-01-06 20:29:22.793799+00	49.3	30.2	1008764	1008764
a9090479-2963-4279-ba4f-41e609c49a97	2026-01-06 20:31:02.090296+00	52.4	30.1	6240211	6240211
2cb9d130-8cd5-4ffd-a2db-461d51229775	2026-01-06 20:31:22.373355+00	47	30.1	6687142	6687142
a420b8ae-dab4-4d3a-a7de-dd669cdd5792	2026-01-06 20:31:51.944227+00	70.5	30.1	967668	967668
23ed0125-68a8-44ee-b1a0-e0440b1bc194	2026-01-06 20:32:02.044714+00	52.1	30	3624866	3624866
69c97b70-4e93-45f2-991d-fdf1cae55a9e	2026-01-06 20:32:50.590906+00	38.1	30.1	5703356	5703356
a798c9c9-fbfa-4910-bc3f-9f462b979923	2026-01-06 20:32:52.055578+00	42.3	30.1	4456865	4456865
9b90220f-f223-4759-909d-553a4dc9fec0	2026-01-06 20:33:02.109792+00	49.5	30	644007	644007
0f187967-4610-4582-98f2-6d70e941090c	2026-01-06 20:33:22.832917+00	45.1	30.2	301385	301385
7fdffe53-a7fe-4762-bf76-a3ff4885aa65	2026-01-06 20:33:25.963048+00	49.7	30.1	561692	561692
d564a63c-bdbf-456f-93d0-eced094e6db1	2026-01-06 20:44:22.852644+00	53.2	30.1	2653637	2653637
c554423d-2e5f-4dbe-bd90-df182269d3ef	2026-01-06 20:44:52.071877+00	43.7	30.2	743058	743058
d4416d91-7d38-4dfd-b317-be2513b37d6a	2026-01-06 20:45:22.781936+00	42.5	30.1	379444	379444
2235cdaa-d273-49e3-9d2b-844bcd3b4e8d	2026-01-06 20:45:25.934674+00	49	30.1	3088151	3088151
389c5c16-01cf-4bf5-ba90-4e62fa586c32	2026-01-06 20:45:51.756829+00	68.8	30.2	5460452	5460452
b5966ede-5321-4556-9d91-f5019273594d	2026-01-06 20:46:22.916375+00	42	30.2	165586	165586
2ea6dde2-429e-4969-baeb-ac3ea8e1beee	2026-01-06 16:13:15.470857+00	38.1	26	842148	842148
7880e476-e77f-4fd8-93b0-771defc43032	2026-01-06 16:15:25.96439+00	38.2	26.1	2985229	2985229
a266ad21-e55e-46c3-ba1b-0b2772f0c191	2026-01-06 16:15:56.568071+00	41.3	26.4	2844882	2844882
23ab1dd2-405c-4a21-884c-eae8199b2411	2026-01-06 17:59:02.153719+00	48.3	29.8	298080	298080
04a7d762-2aff-4067-bcc2-3035d7d77410	2026-01-06 18:01:21.59357+00	31	29.6	3351808	3351808
44ca37f5-b58b-46a6-96d9-3aaf89ecd748	2026-01-06 18:01:22.763998+00	34.8	29.7	3432196	3432196
c4779f5d-1574-45de-986b-6e92e0397877	2026-01-06 18:01:25.927408+00	49.5	29.6	397511	397511
9c65a090-bca3-4e87-bc33-379a575d283b	2026-01-06 18:02:25.907605+00	53.2	29.6	5472786	5472786
4c2ded88-a879-47c8-aade-5d39507ec701	2026-01-06 18:02:52.100862+00	73.1	29.7	167348	167348
3fd19a99-beee-4864-9888-906046046dba	2026-01-06 18:24:43.782887+00	36.8	29.8	4585268	124554
a8afe4d0-81f1-4d57-b8bf-aeb1660ab920	2026-01-06 18:48:22.788418+00	38.9	29.8	407315	407315
ff4cde03-4935-4294-b4e7-6d00d60830cf	2026-01-06 18:50:23.07648+00	50.8	29.7	3691397	3691397
a169183b-1be7-46ff-b89b-67c6013e375f	2026-01-06 18:50:50.567926+00	36	29.8	3678941	3678941
9093a074-c9b4-4f9a-88e2-36f3f1f03311	2026-01-06 18:51:22.743378+00	37.7	29.8	388578	388578
d645d229-f1fd-4add-8c13-00e8e39cab14	2026-01-06 18:51:51.795765+00	41.1	29.8	307981	307981
c9e01765-eebc-4534-b6fa-9ceec079ffa2	2026-01-06 18:52:22.764328+00	45.2	29.8	174022	174022
5444ebfa-a70b-4c47-b2bc-6fcd1e03a9c9	2026-01-06 18:53:22.680239+00	41.3	29.8	4296597	4296597
6f61489c-62cb-4e89-b483-c695ef5d41ba	2026-01-06 18:54:22.655352+00	40.5	29.8	5767331	5767331
6c41bafb-27b8-484b-92ba-e2c616b6a9f3	2026-01-06 18:55:50.503965+00	33.6	29.8	1645854	1645854
7e343b34-0350-4277-b775-80cf4ce9d3ec	2026-01-06 18:56:02.060616+00	47.6	29.8	4690955	4690955
81073015-1572-431e-b9af-40c3fda72486	2026-01-06 18:56:22.367504+00	48.2	29.9	1233567	1233567
ea53167f-0fc5-40b4-8c2b-94f1cedc7b36	2026-01-06 18:56:50.561042+00	36.4	29.8	4502889	4502889
b2547a0f-8e74-4fd3-8219-691d42951675	2026-01-06 18:57:22.724223+00	37.2	29.9	3077857	3077857
4a57309c-c425-4137-b394-cfcf5643a9e2	2026-01-06 18:57:52.140228+00	73.6	29.9	5211346	5211346
05264deb-59c4-42c5-b88b-96098b3877d0	2026-01-06 18:58:22.650833+00	49.5	29.9	5877439	5877439
4b6a88ff-b619-4d00-89e4-59d1e537c432	2026-01-06 18:58:51.745953+00	44.2	29.8	3927494	3927494
4545f7fb-64eb-4bda-b587-46137ac3c28b	2026-01-06 18:59:22.693929+00	38.5	29.8	3800907	3800907
b7ae7ae2-c28a-4110-a32c-5ae5d0f72a24	2026-01-06 18:59:50.371442+00	37.3	29.8	950912	950912
07112299-0c32-40e2-9e08-b5b839a0ec51	2026-01-06 19:00:22.393488+00	51	29.9	693002	693002
387dac2d-bd4e-4146-951c-0a92fcc3d506	2026-01-06 19:00:25.905822+00	50.3	29.8	4758826	4758826
b103c77b-f383-4624-83a8-feb1d3f839f3	2026-01-06 19:00:52.128423+00	44.3	29.9	4561260	4561260
d56c7173-ffae-49c7-9269-4277e7808da8	2026-01-06 19:01:22.562719+00	38.4	29.9	2593329	2593329
6920cf66-4828-454c-a23f-39800e19a22e	2026-01-06 19:02:51.701325+00	42.8	29.8	4122500	4122500
c738c92f-5977-4579-8360-39e044125db4	2026-01-06 19:03:22.687752+00	46.9	30	4409643	4409643
07d884dc-4d8e-405f-a077-66aff41e5d5e	2026-01-06 19:04:02.133497+00	45	29.8	6300241	6300241
640a0eaa-f263-4259-af53-83c7f043864e	2026-01-06 19:04:22.262618+00	43.3	29.8	3886364	3886364
0cf5b9da-adff-4a62-82b5-6787d1d1320e	2026-01-06 19:04:51.756524+00	70.6	29.8	208841	208841
68bbbbf5-2396-4ab0-ac20-9156ce196be1	2026-01-06 19:12:22.727113+00	47.7	30	4123598	4123598
84d53f8e-99b0-478c-b347-9b54bbb0b011	2026-01-06 19:13:22.724236+00	42.9	29.8	2576649	2576649
73f433b0-d491-4662-a0aa-6f99bc847331	2026-01-06 19:14:02.088434+00	46.9	30	6112427	6112427
28bd784d-620a-427e-b2ca-6d881e1b7690	2026-01-06 19:16:22.768836+00	36.7	30	263222	263222
bffbedbd-18df-45fd-badd-36b45435bb70	2026-01-06 19:18:22.695557+00	53.8	30.1	5217917	5217917
5a1ff2e0-d5a3-4c94-9240-8eef342ab0bd	2026-01-06 19:18:51.789917+00	42.5	30	3060487	3060487
43856c6e-0a67-46fc-af64-bdd3d4f10d65	2026-01-06 19:19:21.648573+00	30.9	29.9	3167284	3167284
f83bebb7-bb9b-44af-b025-a1f68a69ac55	2026-01-06 19:19:25.919868+00	43.2	30	785107	785107
60d85fb4-b23e-419d-ad7b-f4c8f70177b9	2026-01-06 19:20:02.111701+00	53.2	30.1	5665618	5665618
f8a1b492-1651-4e83-af8a-9b4339f6677e	2026-01-06 19:21:21.678129+00	34.8	29.9	5199263	5199263
6ed5344b-647d-484c-ab3d-7458103d02cf	2026-01-06 19:21:22.917768+00	42.5	30.1	315523	315523
5a832b6c-a56f-4d19-8a92-3a840d14b96b	2026-01-06 19:22:02.096127+00	45.7	30	5373895	5373895
15567273-5cef-4296-a393-3006fa5503e5	2026-01-06 19:22:21.577425+00	31.5	29.9	5290225	5290225
b25b33ba-ddb3-49a0-85af-624b61c44319	2026-01-06 19:22:25.953121+00	52.5	30	2107355	2107355
a34ac8a3-d20f-48e4-950b-3ade1361f927	2026-01-06 19:23:22.743236+00	44.7	30	3779180	3779180
a2b6b32d-dd27-4cc7-8f62-9183729ec46f	2026-01-06 19:23:25.95281+00	50.3	29.9	2459406	2459406
6491c629-979b-4bdd-a6ca-2e4c29463a43	2026-01-06 19:24:02.058286+00	46.8	30	4004637	4004637
e7dd1ffc-f014-4677-bace-c9389c091945	2026-01-06 19:24:50.600049+00	40.2	30.1	4924506	4924506
d789b87a-7026-4e23-8cf3-0e37f61225f9	2026-01-06 19:25:22.390862+00	44.2	30.2	4931582	4931582
5cd84081-6440-4c35-b104-d5c9fa3ea709	2026-01-06 19:25:25.950769+00	51.1	30	2133076	2133076
cc0e77eb-df12-4fd8-897b-b026068a6680	2026-01-06 19:27:21.611306+00	34.5	30.1	842450	842450
2ae438a5-781e-428a-9818-89a7e4bbd12b	2026-01-06 19:27:22.64972+00	39.6	30.1	434351	434351
01648345-ded8-40ac-95de-2b935b3b555e	2026-01-06 19:28:22.321773+00	51.4	30	2839837	2839837
68154e73-a0f8-4bf2-a01e-31b5366d291d	2026-01-06 19:28:50.506931+00	39.9	30	584242	584242
bb389621-e09a-4e91-b141-4ae0a7caa84e	2026-01-06 19:29:22.75788+00	41.9	29.9	4287825	4287825
148de391-eba1-45cd-82bc-b7158bdda02b	2026-01-06 19:29:50.486593+00	38.5	29.9	4010433	4010433
93259623-311d-4a05-8970-3d32955d2a0b	2026-01-06 19:29:51.759625+00	54.6	29.9	4014238	4014238
7b9a5cb4-f2e8-42d0-98ab-27dddaa2b1c1	2026-01-06 19:30:02.090035+00	53.4	29.9	3089895	3089895
9d6f8c2a-9907-47f3-b206-6b17f40980d7	2026-01-06 19:30:22.603715+00	53.2	30	5318834	5318834
a6a2f73d-5817-4740-afff-325af8129356	2026-01-06 19:31:02.134679+00	49.9	30	3958456	3958456
9dd61bd2-e252-42f4-899c-a76d5e31a9c0	2026-01-06 19:31:21.597555+00	31.1	29.8	3729914	3729914
01c7317f-e292-43ab-bf44-089e87e16f32	2026-01-06 19:31:50.437544+00	36.1	30	4628555	4628555
3f8cc338-9d14-4e7e-abf7-6ffd71dcb3a8	2026-01-06 19:32:25.949553+00	47.1	29.9	2525447	2525447
ec94a5b2-6b29-427f-b137-4224f7d51c62	2026-01-06 19:33:22.436861+00	49.6	30	6191259	6191259
3458ee8e-ca74-4752-8aa5-3f3eda7b5d6b	2026-01-06 19:33:51.933733+00	45.8	29.9	241942	241942
ac72cfea-0856-47d4-a069-846fdb3eef33	2026-01-06 19:34:21.564603+00	32.2	29.9	852166	852166
d2b412e0-1360-4143-b056-9b5883c1f643	2026-01-06 19:35:02.117159+00	45.7	30	3483004	3483004
a2fd314d-bda6-41c1-a79c-4a62175fee43	2026-01-06 19:35:25.902244+00	45.8	30	716822	716822
e2c80443-ae96-4f6d-9ebf-a9ff41fb6fc4	2026-01-06 19:38:25.92928+00	54.6	29.9	2602701	2602701
cc52165f-2e6f-4789-9ac4-c9ffcc99d128	2026-01-06 19:39:02.104027+00	45.5	30	3969851	3969851
460d3586-d36e-4370-b4b8-3c6ec544bab1	2026-01-06 19:40:22.642785+00	45.3	30	4255755	4255755
73b163cc-6585-4cdd-8122-c5f1c172f35b	2026-01-06 19:41:22.695832+00	53.7	30.1	5797294	5797294
6bad9f4d-c9cb-4937-8a1b-7e8d50d2acbb	2026-01-06 19:43:22.710397+00	47.8	30.2	442104	442104
1dd51dca-58db-4de5-a294-af1224a4855f	2026-01-06 19:44:22.721517+00	42.9	30	244022	244022
80a63b82-a0db-40a5-8f04-d7a434809dcb	2026-01-06 19:45:50.461767+00	39	30.1	5995366	5995366
6c947431-226b-4738-b839-f78aa31207db	2026-01-06 19:46:22.725596+00	41	30	481143	481143
6cfae696-9083-4265-b4d0-6c1726acad8b	2026-01-06 19:46:50.564235+00	39	29.9	4833977	4833977
d1bdae68-3d62-47e5-9bef-9b95f0d6955a	2026-01-06 19:46:52.129589+00	49.9	30	2184140	2184140
20aedf67-071d-40f5-84b2-8395472de1c6	2026-01-06 19:47:02.103491+00	50	30	788705	788705
7ed95723-6421-4829-82b9-ffb0446ce3f5	2026-01-06 19:47:50.576398+00	41	29.9	1053682	1053682
4473252e-6be6-4449-a227-cad8dd8a1768	2026-01-06 19:48:22.906388+00	43.9	30.1	330150	330150
e3bae1a3-feb9-43e4-b784-c18b4c226944	2026-01-06 19:49:50.561595+00	42	30	4783668	4783668
c2723ead-b006-42a5-ba09-7b71cd5578f6	2026-01-06 19:50:21.50335+00	30.8	29.9	2102120	2102120
95633454-36d3-49f2-9f99-56f7cf73ca98	2026-01-06 19:50:50.621269+00	37	30	5172440	5172440
cd7fd979-2deb-4df4-a73d-d31fd5acf39f	2026-01-06 19:50:51.984432+00	72.5	30	4482472	4482472
220a1b48-cd36-4aa5-93e5-19b37a5e1655	2026-01-06 19:51:21.527004+00	32.1	30	5984521	5984521
db2b3050-9c99-4693-b6ef-10d928467135	2026-01-06 19:51:22.652584+00	47.9	29.9	2555139	2555139
4ccacab8-8132-4ea1-ab43-38ee9bc35dfa	2026-01-06 19:52:02.090719+00	48.8	30.1	5317699	5317699
6d04c96b-e056-42cd-865d-0d78ca2bb3b6	2026-01-06 19:52:22.705896+00	41.3	30.2	2092636	2092636
d60b5ca6-f5be-4a60-8482-3c4213166c21	2026-01-06 19:52:51.799932+00	72.5	30.1	3350920	3350920
a40ff579-2d73-4008-88a6-c382995dc63d	2026-01-06 16:13:25.893908+00	40.9	26.4	3472507	3472507
c323b942-530c-4eee-b9f2-9a05fd9bb691	2026-01-06 16:13:41.824524+00	35.5	26.4	4927526	132935
b3e1242b-7456-44c2-96e0-d0b6d8d6eccf	2026-01-06 16:14:56.569084+00	34.3	25.8	819943	819943
6fc5b2f4-9341-4114-8bb2-a449c1fbe1ff	2026-01-06 16:15:50.550278+00	35.8	26.4	1785876	1785876
866422af-03a0-4a16-a941-804b047f2075	2026-01-06 16:16:15.519176+00	38	26.3	1658504	1658504
808e5e9a-3897-4026-99b3-0bcf8b121165	2026-01-06 17:59:43.427599+00	43	29.8	4189421	111079
085d0902-7c99-41a4-96f2-262e4ce536cf	2026-01-06 18:25:43.79681+00	45.9	29.7	4163088	108993
ca4b78f0-9fe8-44f2-9055-9ecfe2f65991	2026-01-06 18:48:22.852546+00	38.9	29.8	5151341	5151341
e0e54fee-1e10-45b7-a3c8-d5733e59ed1f	2026-01-06 18:49:21.524637+00	36	29.7	2949574	2949574
26053d2a-9579-4127-a699-6b3cdadae3b9	2026-01-06 18:49:50.481326+00	41.3	29.8	3562893	3562893
d64a969f-6899-4270-883a-fdb22c5cef08	2026-01-06 18:50:50.672643+00	36	29.8	1464459	1464459
99972502-c84b-4b34-be51-9c88d8d820c5	2026-01-06 18:50:52.074608+00	41.1	29.9	751116	751116
869fdf56-db25-4d91-932c-e32264d2dee6	2026-01-06 18:51:21.605206+00	39.3	29.8	5862620	5862620
f69c62bb-4bfc-4e46-b0b8-2a574fa80af9	2026-01-06 18:51:50.598613+00	35.5	29.7	1103279	1103279
82e9ad4f-a154-429f-9796-34532124656e	2026-01-06 18:52:21.614643+00	38.6	29.7	1052213	1052213
394477d0-09b7-4c41-8f1c-1591c2b9fa78	2026-01-06 18:52:50.550623+00	39.6	29.9	4134358	4134358
4ee2b9b4-6f4c-4eac-bcdc-130316736cf5	2026-01-06 18:53:22.577021+00	41.3	29.8	392529	392529
e282fb15-cb29-418e-93be-e9e471347402	2026-01-06 18:53:50.447994+00	34.8	29.9	3864791	3864791
349a1cc9-6d35-4d36-a81b-c7fbee194203	2026-01-06 18:54:50.50874+00	42	29.9	5620808	5620808
24520c0d-1165-4faf-803f-f1cb0c656792	2026-01-06 18:55:22.329317+00	40.7	29.8	3502630	3502630
02c07c5e-5370-42cf-8dae-96c7965fa963	2026-01-06 18:56:22.750599+00	48.2	29.9	3735648	3735648
865e5ae9-4c27-4e16-9583-f95762fe81ae	2026-01-06 18:57:21.655074+00	39.3	29.8	989812	989812
f26d32c9-4536-439e-89cf-86bf25f7fa8b	2026-01-06 18:57:25.918862+00	50.7	29.8	868734	868734
aa58bf3f-0c8e-479a-811d-a2882eb7ff81	2026-01-06 18:58:22.759558+00	49.5	29.9	563956	563956
78d61c5e-9fb5-453e-94d2-b631044bf08f	2026-01-06 19:00:02.068224+00	48.2	29.8	3367866	3367866
09e2be10-91e5-4c17-997a-c13311effd8a	2026-01-06 19:01:21.506423+00	41.1	29.8	983980	983980
9f34dd8d-fa52-4505-bef6-adcab62cdf38	2026-01-06 19:01:22.235319+00	38.4	29.9	498154	498154
f2a7c04f-7445-4dac-a046-96d3c102b637	2026-01-06 19:01:51.593552+00	71.1	29.8	386370	386370
8118a073-b231-4d83-816b-c24b1942a801	2026-01-06 19:02:02.078646+00	52.9	29.8	3301392	3301392
5411e83f-9f20-43ed-9f12-1c3d2fa4501e	2026-01-06 19:03:22.607086+00	46.9	30	230546	230546
836c63df-7da7-4f10-9d14-af6640a898eb	2026-01-06 19:04:22.923153+00	43.3	29.8	3011184	3011184
55e57d41-8ddb-4499-83cc-7da666383e34	2026-01-06 19:04:25.959413+00	44.5	29.8	5086434	5086434
feab3f2a-38bd-4581-a1be-12b3d4f862ec	2026-01-06 19:05:22.692596+00	36.9	29.8	4880565	4880565
bd7490a3-a380-47a2-9132-ff0a7491a91b	2026-01-06 19:05:50.347074+00	37.5	29.8	4227527	4227527
dcdfdaf8-1a38-4bb6-8c12-a80803218920	2026-01-06 19:06:22.770115+00	43.1	29.9	3619339	3619339
9ba4e169-272b-4963-a101-baac8948ebcb	2026-01-06 19:07:50.490863+00	36.9	29.9	4684553	4684553
0a8061fc-c631-4578-9eb4-965840c4dc9c	2026-01-06 19:08:22.348161+00	43.5	29.8	641595	641595
5b01f7e7-0c24-44e8-a343-779cebeaa6d1	2026-01-06 19:08:50.588601+00	39	29.9	3077710	3077710
f0d5851f-fc1c-4c9e-95a0-8fde5f0ab71f	2026-01-06 19:09:21.515201+00	35.3	29.9	915785	915785
010cacc7-9edb-49b4-8c26-ce39c745ff43	2026-01-06 19:10:22.275399+00	45.7	29.9	3231204	3231204
316cbdc5-fd7b-422e-979f-2b1030be931e	2026-01-06 19:10:50.498921+00	33	29.9	876928	876928
ddb4ea02-a9cf-4cd9-9de7-06dcc5907933	2026-01-06 19:12:44.526786+00	32.8	29.9	4192250	112096
295df04b-e5da-4fa3-8a71-2143bd030e19	2026-01-06 19:38:44.893731+00	40.2	30	4604874	119545
0ed1352c-3d0f-4efe-aa7c-334e3e121132	2026-01-06 20:04:22.832189+00	44.1	30	359191	359191
4f3088ee-c1ea-4141-9651-044fcb800e77	2026-01-06 20:04:50.675374+00	37.7	30	3412840	3412840
3cca2b18-3e14-4b04-8d7f-3daa98e2bfd2	2026-01-06 20:28:50.569407+00	38.1	30.1	4891639	4891639
95e22a98-845d-4709-9fad-e058eb3e04de	2026-01-06 20:29:25.923251+00	43.5	30	985562	985562
4b92f5c5-e426-420a-8d8a-ab68f6e82bde	2026-01-06 20:30:02.123852+00	51.1	30.1	1563097	1563097
9aad3ddc-65a8-499c-8501-fd8f0fe694cd	2026-01-06 20:30:21.530621+00	32.9	30	3623574	3623574
8d010e6e-7470-4899-8c1a-7fa9cdc9d34a	2026-01-06 20:30:22.291943+00	44.3	30.1	3308744	3308744
8908e682-1aaa-4549-a57f-b4a23e3829de	2026-01-06 20:30:51.718701+00	43.8	30.1	4354926	4354926
642bdc7f-adbe-4db9-9542-323ad9b52be9	2026-01-06 20:31:50.563635+00	41.1	30.2	3496352	3496352
4b32ab67-9648-4fc2-9977-2fd4fd949b6c	2026-01-06 20:32:25.949319+00	44.9	30.1	1715110	1715110
5b03f949-20df-4a2d-a000-f2d8a78100bc	2026-01-06 20:44:45.898541+00	38	30	3683427	108542
8474d2a4-2e3c-4cfe-b05b-20fc46327f4e	2026-01-06 21:11:46.223565+00	3.9	21.6	2325	305
da731d61-69da-4006-8921-f1284c1dd344	2026-01-06 21:40:46.563382+00	3.8	21.5	1620	193
f3d14ab8-b58c-4fba-a8e1-4487a8a96150	2026-01-06 22:09:46.965818+00	4.2	21.5	2096	292
d8d9d023-1853-4835-b228-b793480a16d6	2026-01-06 22:38:47.283325+00	3.8	21.5	1332	174
aaa68e04-0225-4033-834f-364358c8aa39	2026-01-06 23:07:47.673256+00	2.9	21.5	1464	322
89752d39-f381-4191-a074-3068ad425938	2026-01-06 23:36:47.953249+00	3.1	21.4	1246	206
78c9da8b-35eb-48a6-b558-d2e8f6ac8400	2026-01-07 00:05:48.331925+00	1.1	10.2	1172	13
11a59f29-9925-49a8-bd55-e93ff6ae3963	2026-01-07 00:34:48.720633+00	0.9	10.1	1219	30
f2dd0b71-76cc-41ec-9acd-4a87772443f2	2026-01-07 01:03:49.129689+00	1	10.1	1223	24
aa9e9029-375c-45e9-838e-ca2c76efefc6	2026-01-07 01:32:49.552055+00	1	10.2	1562	18
2d2807d6-f03d-4f7f-a663-4b33f9b5eb7e	2026-01-07 01:58:01.041605+00	2.5	11	434056	434056
b81cb697-05ef-4717-a13e-ac095c23bc47	2026-01-07 01:59:00.72932+00	3.8	11	513205	513205
575a52bf-884d-4c88-8439-c63a0af39ce6	2026-01-07 02:00:00.708986+00	1.9	11	617098	617098
edc11375-341c-4308-8b77-9a02762cbb93	2026-01-07 02:00:00.861103+00	1.9	11	640244	640244
b2d8aff9-b9ea-428b-8cd0-e0071ca7cf90	2026-01-07 02:01:00.609167+00	2.9	11	723236	723236
ca799a47-84aa-4739-ba5d-7f0c0c66d80c	2026-01-07 02:01:00.927007+00	2.9	11	389262	389262
6298a150-6fb6-4335-970a-7a8b035576de	2026-01-07 02:02:00.208377+00	2.7	11	656271	656271
bf89aa1c-d500-4142-bb51-70aa56037195	2026-01-07 02:02:00.93311+00	2.7	11	393077	393077
de9fb863-87ff-4bab-9120-d598a227ea65	2026-01-07 02:03:00.620728+00	2.6	11.1	698373	698373
633d67c5-bb65-4d4f-9b6f-08a180f1765a	2026-01-07 02:03:00.803039+00	2.6	11.1	552236	552236
d1fb24bf-8545-49ad-8b56-8849856954f7	2026-01-07 02:04:00.091017+00	2.6	10.9	10590	10590
573c5991-60fd-408f-9526-2f2a6fa76029	2026-01-07 02:04:01.229369+00	2.6	10.9	255056	255056
9f7b446c-ba30-47c1-a8a4-60c3bbd5ff12	2026-01-07 02:05:00.03165+00	3.3	11	8267	8267
f0a26bfb-fc58-4278-995b-a05df65be6d9	2026-01-07 02:05:00.161724+00	3.3	11	845782	845782
4f0b850c-1c33-41e0-a7ad-5e7101586fb9	2026-01-07 02:05:00.726424+00	3.3	11	566849	566849
81f444c2-2378-4575-833c-69610e15d298	2026-01-07 02:06:00.640048+00	2.8	11	706565	706565
d14a8fcd-e4f0-4ad7-bea9-ddb003d11abb	2026-01-07 02:07:00.142049+00	3.5	11	10683	10683
942e31f3-1054-419e-bc6d-bb6cd9f8fb9f	2026-01-07 02:07:00.731593+00	3.5	11	436838	436838
92eceb3b-1f7a-47f8-9208-9f96c39fd810	2026-01-07 02:08:00.679183+00	2.1	11	519162	519162
0ce57a06-4e47-42ef-bd00-92ca9e0e25ac	2026-01-07 02:09:00.844988+00	4.8	11	677540	677540
70be5037-e199-4541-bedb-9d1c85dec342	2026-01-07 02:09:01.012134+00	4.8	11	623943	623943
b491b5ac-e2be-48cc-a292-b99c002abbeb	2026-01-07 02:10:01.162788+00	3.9	11	445770	445770
61f4727c-9691-4265-8c2d-64a2640e55a2	2026-01-07 02:11:00.722192+00	2	10.9	613709	613709
311c5f60-a5eb-410f-abe6-69a1ac51a2eb	2026-01-07 02:11:00.900431+00	2	10.9	493680	493680
4a6dcdf8-a1c4-46ac-9a08-acc4d1f083c2	2026-01-07 02:12:00.048889+00	2.3	11	10140	10140
a16731b0-ab91-486d-bd5e-3be3a4db79cc	2026-01-07 02:12:00.67381+00	2.3	11	515517	515517
9df3ef35-e627-45d3-8163-116a26e758f8	2026-01-07 02:13:00.861916+00	3.4	11	273046	273046
f431adf3-13d3-45da-9dd2-c5a69e713e7c	2026-01-07 02:13:01.08703+00	3.4	11	562353	562353
a675c438-b8b7-440e-8d35-ff43f4b8ed42	2026-01-07 02:14:00.69944+00	2.7	10.9	552148	552148
97d6f847-0264-4e7c-bb0d-9dcb8c0fbe08	2026-01-07 02:15:00.79367+00	2.4	11.1	533792	533792
0052f478-e4bd-4fbc-a297-478f7a501685	2026-01-07 02:15:00.99224+00	2.4	11.1	332521	332521
482c2b9e-a155-4022-8e80-284a7dd6f144	2026-01-07 02:16:00.775747+00	2.3	11	761638	761638
d23cbe98-ebda-4d51-ade4-56c3afdc8c78	2026-01-07 02:17:00.051073+00	2.2	11	9128	9128
13828c77-1772-4d77-9e3c-207183879b22	2026-01-06 16:13:50.510685+00	29.5	26.9	2399808	2399808
97becd4c-83c5-43aa-941b-85cfdf1febe8	2026-01-06 16:14:15.489149+00	34.6	27.1	3523545	3523545
0c6b89bd-b772-42ba-91be-20f61d174a8c	2026-01-06 16:14:25.966654+00	37.2	27	3312473	3312473
50393454-efa4-45fe-a195-20301401a59e	2026-01-06 16:14:41.882647+00	35	27	4339815	106560
defcf816-23bb-4970-9076-aadabba1786d	2026-01-06 18:00:43.402438+00	40	29.8	2493575	102863
c7f097f2-c0bd-4bef-aa1b-b37b90fcc484	2026-01-06 18:26:43.82624+00	37.2	29.9	4701420	126689
92930dd4-e2bd-4832-89fa-b6cf3a4d2d29	2026-01-06 18:48:44.191869+00	43.9	29.7	3828500	103431
5d42564d-038b-4266-8376-b0cc0f4b8f06	2026-01-06 19:13:44.53158+00	40.5	30	4259382	112512
0cd15298-5684-4abc-9687-8d8b486a25e5	2026-01-06 19:39:44.917616+00	34.6	29.9	4080139	101107
b4e1bde3-b39b-41a5-9bda-6cc28110387d	2026-01-06 20:04:45.282162+00	41.4	30	4146174	104402
cfb8be15-f25c-4c64-823f-46ed2c67eab0	2026-01-06 20:29:02.109427+00	45.8	30.1	5624141	5624141
c968d13a-cab0-43b8-a6cd-612d06d655ad	2026-01-06 20:29:22.383184+00	49.3	30.2	5508160	5508160
f594b589-197b-4493-ba63-14f9149d73ee	2026-01-06 20:29:51.758635+00	42.1	30.1	3857133	3857133
dca66b6c-940b-4de4-8405-252cc82ee73c	2026-01-06 20:30:22.700247+00	44.3	30.1	5597087	5597087
5c9efbc0-615e-4d52-82fb-bb594e237d2a	2026-01-06 20:30:50.498852+00	43.8	30	3853406	3853406
849f4a5a-ac1a-4d7d-b212-ba0f256ebcd2	2026-01-06 20:32:21.600936+00	35	30	5195014	5195014
bd586230-5fc8-4096-b209-0d9341baabfe	2026-01-06 20:32:22.346307+00	40	30.1	5607622	5607622
4c09b69a-275f-44eb-8af0-26ae1dcaa23a	2026-01-06 20:34:21.550983+00	39.2	30.1	3952557	3952557
37bfee38-9997-4355-a353-cb7bb556ced1	2026-01-06 20:34:25.955571+00	55.7	30.2	636505	636505
2194a99c-1cb1-457c-a256-f674c03ff118	2026-01-06 20:45:45.859046+00	42.3	30.1	4445536	116404
717b1194-7819-4044-be4c-ee16c6816851	2026-01-06 21:12:46.26726+00	3.7	21.6	1739	299
65a49987-e0f7-460c-8618-585ea0d4acb0	2026-01-06 21:41:46.627484+00	4	21.5	1563	197
f0096347-55bd-49bb-8b2e-12db1c6410b2	2026-01-06 22:10:46.925382+00	3.8	21.5	1743	294
57fec706-59b9-4924-b731-9799fda597ec	2026-01-06 22:39:47.322661+00	4.2	21.5	1579	175
0cf3a33c-eb1e-4eed-92e6-1f746f5c331e	2026-01-06 23:08:47.68281+00	2.7	21.6	1522	312
0814dc7e-d8a9-4abf-8bf0-9115aa8e3a3d	2026-01-06 23:37:47.995383+00	3	21.5	1266	208
0e725a0f-3c6d-4d05-a931-3229875990ec	2026-01-07 00:06:48.362977+00	0.9	10.2	1171	9
580e2b05-6c61-42bd-a965-d820b93575e8	2026-01-07 00:35:48.712419+00	1	10.2	1383	14
66430127-4c55-4bd9-a91c-5563c7f4e54f	2026-01-07 01:04:49.132252+00	0.9	10.1	1209	31
66b8b68e-1742-421a-93ee-cfec6cdc1675	2026-01-07 01:33:49.54058+00	1	10.1	1250	24
b4969642-6e87-482b-8084-9eea5dc16584	2026-01-07 01:58:01.103231+00	2.5	11	456946	456946
ff0af207-8eb4-4d49-9e68-65981d0c56f6	2026-01-07 01:59:00.814018+00	3.8	11	469732	469732
464cd4bf-8cb3-440d-8ce4-04df3ae39df6	2026-01-07 02:00:00.188341+00	1.9	11	676947	676947
a2b96c55-0468-4a24-a4d3-970949ba0059	2026-01-07 02:00:00.718317+00	1.9	11	206806	206806
13620b70-7c5d-45c9-9864-8d4e9276bae5	2026-01-07 02:01:00.81115+00	2.9	11	711841	711841
0db86250-9aa2-40e8-bba7-b0b365ef15b1	2026-01-07 02:02:00.979477+00	2.7	11	366558	366558
56417214-616c-4ac1-a940-2be2485f8c87	2026-01-07 02:03:00.056976+00	2.6	11.1	8169	8169
0c169526-dd99-457a-883a-a45f918e420e	2026-01-07 02:03:00.206701+00	2.6	11.1	577551	577551
7fe9a82f-c458-4d9e-b7f8-3301fa8659c9	2026-01-07 02:03:00.669888+00	2.6	11.1	626082	626082
dc996216-c00b-4e4c-a398-ed62ca9ebbb9	2026-01-07 02:04:01.195648+00	2.6	10.9	392711	392711
b73c2996-91c2-494f-98b4-479e02adc13d	2026-01-07 02:05:00.679299+00	3.3	11	641446	641446
8234f34e-a58e-4972-a6b6-bebddf0f3a50	2026-01-07 02:06:00.712623+00	2.8	11	496737	496737
88751900-b2c0-4da5-85a6-c79836e20d2e	2026-01-07 02:07:00.749747+00	3.5	11	612583	612583
2eefc429-1dde-4bce-be64-16080c540ef7	2026-01-07 02:08:00.673224+00	2.1	11	892140	892140
fd4d7c34-1968-4535-a9f0-e3f9cc3190bb	2026-01-07 02:09:00.203717+00	4.8	11	752280	752280
c133b367-307e-4175-b40b-b9d4709844ea	2026-01-07 02:09:00.868519+00	4.8	11	300936	300936
25e66069-42f4-41fb-ab8a-c2cfd39aa26f	2026-01-07 02:10:00.461923+00	3.9	11	240155	240155
090547df-c73b-4f7d-b84e-afb9776fd03a	2026-01-07 02:10:01.092258+00	3.9	11	574940	574940
ea9ac3dc-935c-4fee-ba2d-f8a4953b1772	2026-01-07 02:11:00.74987+00	2	10.9	423708	423708
5818f81a-0940-414a-86ae-d35cafda86e6	2026-01-07 02:12:00.668872+00	2.3	11	516617	516617
79688fc8-74ab-4efd-ac00-dd9dc14460ca	2026-01-07 02:13:00.88459+00	3.4	11	576879	576879
56f8b8ee-0f37-471d-beda-35efb1e9ac79	2026-01-07 02:14:00.094472+00	2.7	10.9	9385	9385
b80a48c3-0d00-4d62-b99a-566eed238fa8	2026-01-07 02:14:00.709158+00	2.7	10.9	740395	740395
369bf249-cc62-47e9-a84b-d7ec903e4e6f	2026-01-07 02:15:00.887587+00	2.4	11.1	658496	658496
5571d8b2-ffe1-453d-baec-4b3fae978ca4	2026-01-07 02:16:00.136529+00	2.3	11	11613	11613
9aa69fa5-4215-4a74-9901-78ac77a16483	2026-01-07 02:16:00.754937+00	2.3	11	656513	656513
2ef24fe5-8aa4-42e1-b429-0ab6cf738543	2026-01-07 02:17:00.795545+00	2.2	11	624727	624727
50638e73-91c6-4baa-8590-7e9f1895eb57	2026-01-07 02:18:00.90387+00	2.4	11	573238	573238
ef530491-5252-4faa-8fc1-d527deb98e1e	2026-01-07 02:19:00.757862+00	3.5	11	638095	638095
cdca0459-a2c7-4b4f-a7a7-61e7a0ad31cd	2026-01-07 02:20:00.108907+00	2.7	10.9	10669	10669
c9179b01-4af3-4c45-9485-aadb4048905c	2026-01-07 02:20:00.813916+00	2.7	10.9	501716	501716
ec25b45b-c6c3-4b7d-9ec8-c88441b7a41d	2026-01-07 02:21:00.091401+00	2.3	11	8722	8722
eeaa08d7-ebc0-43b3-96a0-b740dbb2b3a7	2026-01-07 02:21:00.214854+00	2.3	11	614632	614632
d98f1a52-15d9-46aa-9e61-e3f092ae46f4	2026-01-07 02:21:00.751764+00	2.3	11	675628	675628
c58d5f02-05b7-4982-a2d8-9a2b70a33df5	2026-01-07 02:22:00.979457+00	2.7	10.9	324487	324487
2aa2ef91-ba88-4429-a11d-3d80e5cebd45	2026-01-07 02:23:00.122914+00	5.5	11	7806	7806
978ad777-5223-42f8-95bf-22f007d76fae	2026-01-07 02:23:01.106993+00	5.5	11	416685	416685
dc03c78f-90d4-4897-8179-e56350b6d414	2026-01-07 02:24:00.039871+00	2.8	11	7189	7189
e4815baf-ba81-49f8-83df-780c8eed6162	2026-01-07 02:24:00.204406+00	2.8	11	577968	577968
f56dc0fa-8d37-4e4a-aebc-d216266b28c9	2026-01-07 02:24:00.712789+00	2.8	11	578981	578981
ca8c0bc3-6e35-4f84-8825-76ec56eb8c2e	2026-01-07 02:25:00.957619+00	3.7	11.1	236686	236686
a926fdc7-929c-47fc-9ab7-659bc95e72d3	2026-01-07 02:25:01.273063+00	3.7	11.1	395097	395097
a15d9fe7-01b2-448a-9e2d-a2f79fc89a70	2026-01-07 02:26:01.026054+00	2.5	11.1	654976	654976
d8445262-7619-43b0-9bfd-df6f1cd4b188	2026-01-07 02:26:01.222946+00	2.5	11.1	421211	421211
e36e9b6c-c672-45b7-87aa-5c01f4794d8c	2026-01-07 02:34:50.324806+00	2.5	11	27028	15311
e4b24e42-f7d9-43f7-a0fd-158a05c58a92	2026-01-07 02:55:00.718564+00	2.8	11	714783	714783
5f0b30d0-131c-4f11-83d5-fe99d94e07ba	2026-01-07 02:56:00.68338+00	2.8	11.1	622062	622062
70b58dc1-0e08-40d8-a7a2-e1f8c697d8c6	2026-01-07 02:57:00.825875+00	3.1	10.9	415070	415070
c7fa569e-4775-4234-b4b1-7b8625d71d0e	2026-01-07 02:57:01.08424+00	3.1	10.9	415478	415478
55347e4a-378b-4820-a3c2-722a6f19c861	2026-01-07 03:01:00.851412+00	2.8	11.1	833335	833335
04bfed1c-aa4b-4f9a-8b19-0b7b270cff03	2026-01-07 03:02:00.883663+00	2.8	11	687011	687011
185482db-2379-4ee8-bad5-23e2b92932f4	2026-01-07 03:02:01.035376+00	2.8	11	607721	607721
d3640679-1f32-40db-aa1f-5778794c15d2	2026-01-07 03:03:00.667988+00	2.1	11	904998	904998
b3117386-e92e-420d-8d58-60b0975f2009	2026-01-07 03:03:00.909052+00	2.1	11	630924	630924
4332e2ab-62bc-4d68-8c54-74bc884c1f05	2026-01-07 03:04:01.239968+00	2.5	11.1	460514	460514
50b0d01c-0a81-4677-b14e-8d5aa4eb0cb8	2026-01-07 03:05:01.16681+00	2.8	11	580751	580751
36523413-61de-4a27-ae5a-c365cfdcedaa	2026-01-07 03:06:00.923317+00	3	11.1	461743	461743
b6b45059-4328-48e9-a386-78ca9706dea5	2026-01-07 03:07:00.082107+00	2.9	11	7036	7036
3fbeb72b-e904-4971-b3a8-f5e60a3dda7d	2026-01-07 03:07:00.795873+00	2.9	11	685623	685623
f7bd9c93-d875-44a9-8335-a5c6399980c3	2026-01-07 03:08:00.920901+00	3.7	11.1	320792	320792
47595634-a618-4274-beca-63f85939ff54	2026-01-07 03:08:01.142635+00	3.7	11.1	673405	673405
8594c6b6-1bc9-4ec6-b21f-c61e5faf7d77	2026-01-07 03:09:00.221268+00	4.8	11.1	711652	711652
2c9b7187-f6f2-496a-8977-ec921c90bbca	2026-01-07 03:09:00.862326+00	4.8	11.1	541497	541497
9346e8c6-a3f5-45da-ab25-939de2bdd56a	2026-01-07 03:10:00.86661+00	2.6	11	678652	678652
b463db61-13c5-4477-81a7-4c5fc8b87a5b	2026-01-07 03:11:00.811269+00	2.8	11	390867	390867
81ff572b-96e9-4455-8381-19757846c428	2026-01-07 03:11:01.136349+00	2.8	11	483001	483001
d83e1940-74e4-4fd3-b4ad-2c0751e4ef11	2026-01-07 03:12:00.122116+00	3	11	8752	8752
f1747489-63ed-4933-a855-ffb0ba6e581e	2026-01-06 16:14:50.550616+00	36.1	26	5089578	5089578
49dec580-9693-4aee-802d-9234207bf2a4	2026-01-06 16:15:15.479274+00	38.7	25.9	5132050	5132050
c946104e-74be-4cc6-976a-7caf76eddf5d	2026-01-06 16:15:41.844519+00	31.6	26.4	4183312	257753
bd8298cf-faff-4abb-8e00-f289e61f591d	2026-01-06 16:15:49.65136+00	35.8	26.4	3287973	3287973
45dfe95e-7314-4fb8-927f-f0c3d4b119f5	2026-01-06 16:16:25.991883+00	38.7	26.3	1352430	1352430
6e846c02-bbc2-44a4-a22f-ca97c78215ff	2026-01-06 16:16:41.892062+00	35.5	26.1	3900294	132493
d6380e50-18e3-4bee-80ec-3516f8f50cb2	2026-01-06 16:16:49.909249+00	32.9	26.4	590844	590844
32688afd-1d3c-44b1-a883-01a6b2bdc760	2026-01-06 16:16:50.563495+00	32.9	26.4	441541	441541
01f0e1c0-fbfd-474d-9e56-593232fcdf4b	2026-01-06 16:16:56.590495+00	35.8	26.3	4016937	4016937
b4279a85-7313-4140-8b02-bf8a57e43267	2026-01-06 16:17:15.483888+00	30.5	26.2	1093060	1093060
17c50df4-c946-44df-b86c-e6b45e804eae	2026-01-06 16:17:25.969629+00	33.4	26.2	1702628	1702628
eb652afd-6948-4a8e-ae9d-2c4e4b969288	2026-01-06 16:17:41.91261+00	33.1	26.1	3585653	160713
c4d0c6db-3fcd-4f1c-abf7-6bf07e5c8920	2026-01-06 16:17:49.657427+00	34.6	26.3	2327517	2327517
f77cea7d-ac5a-4417-a33c-b81c9840d54e	2026-01-06 16:17:50.540178+00	34.6	26.3	1183867	1183867
9a92ed3f-b43d-4f88-b2f4-c971f19b7a1e	2026-01-06 16:17:56.570429+00	32.8	26.2	3759585	3759585
6e8f6e80-8862-4481-8217-476f5059cf8c	2026-01-06 16:18:15.452425+00	37.6	28.8	1060144	1060144
92f96c6a-ec63-4da3-8982-d9feb64b9660	2026-01-06 16:18:25.904714+00	30.9	26.4	359370	359370
0c03c1ac-29ce-43c6-ad55-93afb1109516	2026-01-06 16:18:41.889596+00	33.9	29.5	63531	204250
f70c66fc-55f1-43a7-a170-6e3729f488bb	2026-01-06 16:18:49.607689+00	34.6	27.2	990403	990403
54199c65-3f94-47b7-bb8f-c8db1aabba08	2026-01-06 16:18:50.464318+00	34.6	27.2	672042	672042
4df57631-a683-46b1-bbf8-85f2333995e2	2026-01-06 16:18:56.5133+00	43.1	29.5	892713	892713
e39d5f9d-695a-4175-82e7-684d015b0fa5	2026-01-06 16:19:15.451703+00	38.7	28.6	920627	920627
30d33d29-cf5e-4941-a25c-56e05ce501ed	2026-01-06 16:19:25.884271+00	29.3	26.4	419166	419166
193f7a04-8b45-41f8-8b10-e159bc2deb88	2026-01-06 16:19:41.333315+00	28.3	26.1	1030440	1030440
52e16d31-c577-4e21-9561-a262a07cdbdb	2026-01-06 16:19:41.90759+00	28.3	26.1	88180	135592
0677abbf-ada4-4008-b5c4-38da80b5a5ac	2026-01-06 16:19:49.569301+00	33.8	28.2	982921	982921
34a9c989-58e7-4282-982e-d53eebd87fa8	2026-01-06 16:19:50.461464+00	33.8	28.2	951031	951031
698f7e97-445b-4b95-9cb1-b11cbe0fb401	2026-01-06 16:20:03.063823+00	34.1	28.4	1210404	1210404
f55b9891-ab0f-4ac6-915f-5ab646a5dea2	2026-01-06 16:20:15.433972+00	31.8	28.2	827590	827590
288de0b0-a389-4d1f-81a3-7a498e0d7d6a	2026-01-06 16:20:25.879954+00	34.2	28.3	572425	572425
ee665499-f610-4e34-baf2-73900ca24c1c	2026-01-06 16:20:41.901583+00	29.5	27.6	55273	275694
3fec859e-45da-4af1-8bc3-d9c99380494f	2026-01-06 16:20:49.551821+00	29.3	28.3	790777	790777
da34d8a1-cb6c-4b4b-953c-fc0b667fc1e9	2026-01-06 16:20:50.460791+00	29.3	28.3	834399	834399
7b187a0b-0228-4f70-9c76-45ef2d209b69	2026-01-06 16:21:03.037882+00	36.5	28.5	443206	443206
67dfa9d4-6352-4706-ab82-aa4f41d7ea0c	2026-01-06 16:21:15.448414+00	34.1	26.9	1184666	1184666
7fc49bd4-a613-4040-a1a9-087867009074	2026-01-06 16:21:25.882134+00	29.4	27.6	666592	666592
d88735fd-9904-4a3a-a747-61f1c22300ee	2026-01-06 16:21:41.929139+00	36.2	28.2	51855	318890
3e7566ad-8cba-4a00-ae9c-7720ea311bc1	2026-01-06 16:21:49.590585+00	34.7	26.5	758753	758753
36ed163d-bb72-4429-9b29-1316fb61e15e	2026-01-06 16:21:50.47901+00	34.7	26.5	786853	786853
d69efd6e-c328-47d4-b08c-81c527417e11	2026-01-06 16:22:03.044977+00	32.9	28.6	1404602	1404602
6a43941b-cb69-4749-b294-4c995ff2b7c7	2026-01-06 16:22:15.463348+00	36.4	28.9	948927	948927
6eab5b69-0609-4795-8979-ffe448ee2ae9	2026-01-06 16:22:25.881324+00	33.3	28.3	470488	470488
777343d3-64bb-4fec-9690-96ae6155d26e	2026-01-06 16:22:41.984661+00	17.9	26.2	30629	8606
24dc1355-8e99-49ef-9cc4-22b8a3aa50ac	2026-01-06 16:22:49.55464+00	22.5	26.8	690879	690879
bdc4a3ac-3152-4f25-8597-57264c8e1787	2026-01-06 16:22:50.541777+00	22.5	26.8	309386	309386
63aa539c-8ec9-47c5-8508-6ce9135def73	2026-01-06 16:23:03.05554+00	16.6	27.2	724046	724046
a683e545-ce78-4221-9456-c11dc84bdb4b	2026-01-06 16:23:15.44876+00	29.7	30.2	820868	820868
da166adf-dc4a-42db-9795-1c3320a12733	2026-01-06 16:23:26.024078+00	29.5	30.2	403495	403495
f28c7508-8ca0-4c61-9e18-97fb4f14a10c	2026-01-06 16:23:41.962925+00	9.6	28.2	68139	713950
2a765181-0a8a-42d6-8bdf-c2dcdc26819a	2026-01-06 16:23:49.557098+00	8.4	30.5	776293	776293
7ddd3546-edd3-42eb-9eae-cb43402b2f67	2026-01-06 16:23:50.462619+00	8.4	30.5	717329	717329
ce9245ee-4338-4282-8cf7-02b5ea1609cc	2026-01-06 16:24:03.063649+00	19.8	30.5	629081	629081
0737553a-377c-4a75-a82f-71f68185cac6	2026-01-06 16:24:15.465418+00	16.4	30.7	809307	809307
c649d5d9-8753-426d-b39a-8fd31ec633d6	2026-01-06 16:24:25.892085+00	15.8	30.5	447786	447786
3687cb46-0843-4eea-a594-0b0c8789a06d	2026-01-06 16:24:41.974757+00	6.9	30.5	33774	9365
fc6c1f01-566f-477f-a579-db7fbb4d3039	2026-01-06 16:24:49.555411+00	11.4	30.6	823929	823929
d3c5ffe5-d834-437b-bd5a-c406bf8036b6	2026-01-06 16:24:50.539784+00	11.4	30.6	328923	328923
fd80f58c-e111-4291-8c49-69f8be000513	2026-01-06 16:25:03.041194+00	14	30.4	1030080	1030080
4a8e2821-4659-491e-81ae-eeb6f834415c	2026-01-06 16:25:15.485099+00	14.3	30.5	761245	761245
fb678121-621f-48be-9927-6858dfa92852	2026-01-06 16:25:25.945753+00	10.7	30.5	194286	194286
dbd7dc97-0c6b-475a-950d-21f278698816	2026-01-06 16:25:41.974364+00	9.8	30.5	32352	8494
d2584f0d-6000-4aab-b5a5-6d6b01fa4f63	2026-01-06 16:25:49.579022+00	10.9	30.5	804639	804639
99f7cd6c-f816-4026-9de6-4376072f000a	2026-01-06 16:25:50.488361+00	10.9	30.5	581143	581143
5a574283-5e2b-471a-8a2c-7f56d89bda77	2026-01-06 16:26:03.058615+00	13.7	30.5	670527	670527
12f1cf71-2c1e-447f-9c70-6094c55671a0	2026-01-06 16:26:15.486037+00	16.6	25.3	955856	955856
ce057978-05f4-46ee-855b-9e9d0d7a72af	2026-01-06 16:26:25.916271+00	16.5	22.2	313014	313014
cac9d7a2-ab21-4f7d-bc17-d07cddb569df	2026-01-06 16:26:42.029976+00	7	22.2	37335	11184
d7427701-be8a-4fa1-96a4-0bb4791300ff	2026-01-06 16:26:49.554077+00	11.8	22.1	679341	679341
42e0f1a8-ae56-47ee-9071-0d7690651426	2026-01-06 16:26:50.485517+00	11.8	22.1	553471	553471
a486de3d-6260-4f8e-b4b6-98f4dffb09d8	2026-01-06 16:27:03.042828+00	18.3	22	830874	830874
59014962-2ee5-47c0-8e10-dba938585b43	2026-01-06 16:27:15.478761+00	14.7	22.1	720614	720614
22e2f936-b79e-4644-ab74-5942cdece7fc	2026-01-06 16:27:25.943314+00	13	22.1	167356	167356
59968301-913e-456c-ac6f-038aab0f225f	2026-01-06 16:27:42.011628+00	12	22.1	35434	9678
feaaf3f7-de51-4553-99e3-6a937d07d3ba	2026-01-06 16:27:49.550444+00	11.3	22.1	789092	789092
f0e5de6e-3d96-4660-8088-4fe4c4b4da00	2026-01-06 16:27:50.513855+00	11.3	22.1	365330	365330
793febc7-33ee-4162-8d99-6baf3cec2d53	2026-01-06 16:28:03.059303+00	17.4	22.1	592680	592680
9ea63687-3311-4c56-a1e9-8da1d679132a	2026-01-06 16:28:15.472633+00	14.7	21.6	716833	716833
29ac1b9d-8f1f-490d-b1a4-6d01852219eb	2026-01-06 16:28:25.913423+00	15.8	21.5	423861	423861
e47a5cbc-d930-4e8a-aadc-29e018684f63	2026-01-06 16:28:42.030514+00	11.4	21.6	34281	8302
025cec1e-e798-4d7d-891d-54792e1f4b16	2026-01-06 16:28:49.60422+00	12.7	21.6	597682	597682
13d22749-1a1c-4ec2-ae9f-9899e1ff7781	2026-01-06 16:28:50.475273+00	12.7	21.6	714585	714585
973e4893-88aa-43de-b7fb-7869989239f7	2026-01-06 16:29:03.062113+00	14.5	21.5	1042920	1042920
fb80b0bb-5b01-454f-a436-e34b7cc9dcd8	2026-01-06 16:29:15.461748+00	16.4	21.7	868202	868202
fbe81a7b-4734-4dd1-a5b6-b08cbf9b54f7	2026-01-06 16:29:25.906775+00	13.6	21.6	349285	349285
0d76f5c0-5e62-4502-b54a-4b6a1069e7da	2026-01-06 16:29:42.051554+00	11.1	21.6	36615	9738
7c5998d1-1cc3-45e6-9dd9-7aecea3c469a	2026-01-06 16:29:49.558118+00	6.8	21.6	781695	781695
3e4ad155-d754-4884-83bb-fe580ce59508	2026-01-06 16:29:50.519712+00	6.8	21.6	317215	317215
eae5c0b7-683b-4915-9f7a-31a6f4bd8111	2026-01-06 16:30:03.034015+00	15.4	21.6	1501708	1501708
ec44cc28-d681-4ca9-b460-d498b6f3a3d0	2026-01-06 16:30:15.487221+00	12.8	21.4	701845	701845
a9e89443-6e36-46ff-9ee7-2c7e73197e43	2026-01-06 16:30:25.997399+00	12.8	21.4	422905	422905
e7880a05-268d-4fb0-8343-0ab7a861fc2a	2026-01-06 16:30:42.038507+00	6.2	21.5	40441	10723
bb9653f5-4db5-4b58-969f-79ff90ca278c	2026-01-06 16:30:49.551857+00	13.4	21.4	825082	825082
88d39f19-0ff8-4da7-9f77-ccc9bcf14675	2026-01-06 16:30:50.151719+00	13.4	21.4	339028	339028
6286bb61-7248-497c-91dd-f973d69e3775	2026-01-06 16:30:50.557181+00	13.4	21.4	197567	197567
ac420caf-85cc-475f-ac2d-faa7c0eb6b37	2026-01-06 16:31:15.44289+00	12.6	21.4	840740	840740
690b82de-2b93-41f0-9d2e-a3f7d9170af2	2026-01-06 16:31:25.900312+00	13.9	21.4	306289	306289
6b1555b8-12e0-4dc6-bc83-c4ccc3fcac45	2026-01-06 16:31:42.104588+00	11.3	21.5	36235	10013
77b86b09-fed0-4185-9823-5cbb397804ce	2026-01-06 16:31:49.643653+00	8.7	21.5	500414	500414
0f3ddbe8-9a2a-4c94-86ef-e19211e2931d	2026-01-06 16:31:50.474453+00	8.7	21.5	710899	710899
5c524525-37df-431d-a848-a7699b64a463	2026-01-06 16:32:15.467516+00	20.9	27.9	1080020	1080020
66452140-03f4-425c-9203-da3a91dc97ac	2026-01-06 16:32:49.639922+00	9.5	28.4	732149	732149
b03a4398-4bdf-478e-b053-225f76427b2d	2026-01-06 16:33:15.463706+00	14.8	30.4	872779	872779
fcb1536f-5d1c-460f-8acb-81bffaf1a41c	2026-01-06 16:33:25.880245+00	25	31.1	856690	856690
f443ca66-a450-4dd0-8dd5-69ddb491a1f1	2026-01-06 18:01:43.452577+00	46.8	29.7	3692808	97396
759c180a-8eb2-49bd-8197-7745ba3d92a8	2026-01-06 18:27:21.594459+00	37.1	29.9	5232729	5232729
e071bf98-f8b0-42d7-8da8-8acd4f92953e	2026-01-06 18:27:25.935572+00	51	30	1867950	1867950
9d824788-88ca-4f98-8111-d88951f58b34	2026-01-06 18:27:50.523208+00	29.9	29.9	2994542	2994542
8a90ba43-a105-4449-8150-0359bb1c01dc	2026-01-06 18:28:50.558682+00	39.2	29.8	782860	782860
e2a6b1ab-4578-432e-b466-da50461362ab	2026-01-06 18:29:22.900566+00	36.3	29.9	225221	225221
fd076713-0198-464e-a1f5-211c3af963c8	2026-01-06 18:30:02.108315+00	48.4	29.7	4639935	4639935
38ffd9b0-d740-4e4b-9e75-427d63dfc82c	2026-01-06 18:30:22.377331+00	43.2	29.6	4567229	4567229
90e2c008-58b9-4d3a-a0f9-e1626a7d9cfe	2026-01-06 18:30:50.620388+00	41	29.9	4014777	4014777
fd9924b2-d67f-479a-9afa-3a50cfca52f5	2026-01-06 18:31:21.556407+00	42.4	29.8	972971	972971
4cfadfda-6f6d-4582-b370-be345c32a321	2026-01-06 18:31:50.556242+00	42.7	29.7	1243020	1243020
6966f9c3-ba86-41a6-a09c-772618ba796b	2026-01-06 18:32:22.197489+00	41.2	29.8	4208955	4208955
97f7fc59-e330-4449-9990-d9322bf0db78	2026-01-06 18:32:50.696722+00	37.7	29.8	645750	645750
0f510a4e-c147-4966-8ea0-7b84ba23d892	2026-01-06 18:33:25.955111+00	45.7	30	3338905	3338905
826ee8ed-17d5-47f9-a4f5-43c45385d3d5	2026-01-06 18:33:50.559571+00	38.3	29.7	3607857	3607857
534bbc87-6e79-44b0-8300-2bc35746e271	2026-01-06 18:48:50.565865+00	41.8	29.7	3742208	3742208
1983bf2d-7cf0-4a09-936f-cb68e883ef2d	2026-01-06 18:49:22.60011+00	35.2	29.8	407789	407789
1b71a8bf-17b5-43d9-ae5d-2440f45624a6	2026-01-06 18:50:25.93269+00	49.8	29.8	1955368	1955368
86b4a211-294b-4d19-acb9-b98c980acfe5	2026-01-06 18:51:22.801242+00	37.7	29.8	228067	228067
bb8fc322-3205-47a8-bd1e-7c5d4f0dccc2	2026-01-06 18:51:25.883085+00	44.4	29.7	2136460	2136460
92334014-a66c-469c-89c2-4d97507f0cb2	2026-01-06 18:52:22.351976+00	45.2	29.8	7327370	7327370
ca87018e-53c3-4c50-a017-d4b9bba7ed39	2026-01-06 18:52:25.901412+00	44.5	29.8	3401736	3401736
a921036a-eedd-40e4-b1e9-91e1c474d38d	2026-01-06 18:53:02.102471+00	48.1	29.8	6876766	6876766
a751fee7-69bc-4f82-a589-2ce52890b2c1	2026-01-06 18:54:21.549427+00	37	29.7	5657483	5657483
07505a2f-7c7e-49a8-8fd1-4e30d94cd729	2026-01-06 18:55:25.915003+00	45.9	29.7	739266	739266
840d0b44-bb25-4447-9644-fd554e34664a	2026-01-06 18:55:50.366968+00	33.6	29.8	6020950	6020950
813afd8a-d40b-49a7-b209-a3f5b8b7d71d	2026-01-06 18:56:50.450814+00	36.4	29.8	747970	747970
181a9d8a-232d-4ee3-8a98-27af815c2ce5	2026-01-06 18:57:22.335588+00	37.2	29.9	5073928	5073928
88b3cfbf-78ca-4eee-8c53-f5cb38bad3c8	2026-01-06 18:57:50.748298+00	41.9	29.7	629816	629816
f9087c59-a67a-486b-a4f5-85db908cec2b	2026-01-06 18:58:21.593115+00	37.2	29.7	691595	691595
c5c64670-1e3f-440d-a74a-d01850ef2907	2026-01-06 18:59:02.083207+00	48.9	29.8	392767	392767
7270a627-9147-4e5d-9f61-2029d0605e6a	2026-01-06 18:59:22.374697+00	38.5	29.8	2306314	2306314
a0e0019f-de00-4d38-9b34-5bce7a45c47c	2026-01-06 18:59:50.521082+00	37.3	29.8	4581618	4581618
6720ba58-0b8f-480f-859b-a6c864f68f20	2026-01-06 19:00:50.715574+00	42.2	29.9	673641	673641
80ae8e71-c4c7-4554-ade4-c4e3daf6846a	2026-01-06 19:01:02.074411+00	44.9	29.8	519604	519604
d65f01f4-9275-4be5-b952-7e49c0d8a67a	2026-01-06 19:01:50.397277+00	38.9	29.8	2968838	2968838
989a8c46-49a1-47b7-8c3c-b564700b0e1d	2026-01-06 19:02:21.552349+00	42.4	29.7	2421538	2421538
d437b47d-8c6e-4eb7-ba62-b3ec9f30f1aa	2026-01-06 19:02:22.315669+00	41.2	29.8	5265476	5265476
2db61a14-ef2d-4d07-9f69-2c43eb5e2676	2026-01-06 19:03:50.384173+00	39.3	29.8	2459141	2459141
7afabf1e-f509-45c8-8b5e-5796f2e85288	2026-01-06 19:03:51.772649+00	50.9	29.8	3996272	3996272
fefd069b-a879-4384-bf4f-7d5385a6915e	2026-01-06 19:14:22.722312+00	48.5	29.9	2580620	2580620
3af9c142-e7f2-448e-9356-8ff0f6aa73e5	2026-01-06 19:14:51.572561+00	40.6	29.9	4735180	4735180
4c0e5d74-13e2-4261-909b-a2951512cd4c	2026-01-06 19:16:52.04705+00	54.8	30	6472509	6472509
b27531a8-7ddb-4ea1-832e-4f90cd793edb	2026-01-06 19:17:50.468409+00	32.1	29.9	610663	610663
38b2d0f9-3279-4418-b000-4181b2e28e25	2026-01-06 19:18:50.573061+00	31.5	30	3020013	3020013
34389805-3bb0-4363-a28e-2a2c45836f60	2026-01-06 19:19:22.727049+00	43.7	30	4170583	4170583
276dc274-33de-45bc-80fa-8bead851ac5c	2026-01-06 19:19:50.459478+00	27.4	29.9	719895	719895
ebdb8fbc-22f5-491d-b7e3-d5d305d26202	2026-01-06 19:19:51.82443+00	41.6	29.9	3549438	3549438
e15dff31-aba0-4888-b521-d534d8842504	2026-01-06 19:20:22.6451+00	40.2	29.9	570241	570241
1aee2080-ac4f-4be4-a55c-32eb3d604673	2026-01-06 19:23:21.51339+00	29.5	29.8	1009206	1009206
c4886465-4726-4d99-bd98-ed3001a410d3	2026-01-06 19:23:22.260134+00	44.7	30	3219871	3219871
258a41de-0fdc-4cd9-9094-6b3cee9d203a	2026-01-06 19:26:22.7883+00	51.5	29.9	5889130	5889130
de5ca001-d4b0-4a23-8519-f2b5756ccfd8	2026-01-06 19:26:50.507795+00	39	30	5902494	5902494
2f84ab5b-eeb8-44b4-80fd-98313ba08cca	2026-01-06 19:28:22.707939+00	51.4	30	3873327	3873327
62563019-5544-418b-a9cd-3e0b2666e7a2	2026-01-06 19:28:25.932458+00	43.9	29.9	1476607	1476607
72b9262f-b8c6-426c-a125-48fee5a939cd	2026-01-06 19:28:50.382825+00	39.9	30	5739315	5739315
bcfa947e-873b-4b87-b30b-edf94ee08e7c	2026-01-06 19:31:22.779924+00	50.6	29.9	422463	422463
b979df38-4e93-4b12-a705-26aa9c4fdd01	2026-01-06 19:32:02.105245+00	53.2	29.9	466215	466215
2a9bd8a8-f8f4-46b6-a1cd-f5be8ed81c6d	2026-01-06 19:32:22.674024+00	45.5	30	332252	332252
df864def-907b-4976-8c6c-841e933aacf1	2026-01-06 19:33:02.102205+00	50.2	30	4899993	4899993
bf15eb53-357a-4143-93fe-73b661512f73	2026-01-06 19:33:50.525091+00	37.9	29.9	5519176	5519176
76df108f-c1ff-4b14-88a8-a10784ad64ca	2026-01-06 19:34:22.346442+00	36.6	29.9	4746941	4746941
4a705c55-3fd1-4fba-8141-248383d4e08e	2026-01-06 19:34:25.943357+00	54.8	30	2554246	2554246
9333ae23-09a3-4871-b814-670ccc602050	2026-01-06 19:34:50.605052+00	45.2	30	3556736	3556736
383eea51-784b-4d66-8845-c5e939a60db6	2026-01-06 19:35:22.318684+00	37.4	30	438781	438781
7e9acbe6-0412-4614-81b8-c0291febdb2a	2026-01-06 19:40:44.903772+00	43.6	30	3978504	104024
b0712611-5a7d-4020-bce8-9b95d92d2325	2026-01-06 20:05:02.092358+00	47.9	30	5032135	5032135
c5f1b2fe-c75f-476d-b438-969c7cd3601b	2026-01-06 20:06:22.289799+00	39.3	30	5162420	5162420
b5b84fbf-e02d-4e7a-9f10-78551292e9a9	2026-01-06 20:06:25.906386+00	44.6	30.1	871885	871885
9b074e17-13fd-49c2-9f06-1c709386810b	2026-01-06 20:07:02.087703+00	46.5	30.1	476498	476498
10654cd2-d484-423a-b66d-477ef7f179e8	2026-01-06 20:07:22.785323+00	44	30	232653	232653
c6ee0900-4584-40f6-ae21-0eb66f79f643	2026-01-06 20:07:50.447481+00	37	30	3616378	3616378
20dfd68a-2762-437e-a413-b88f37bdbc6e	2026-01-06 20:08:22.794272+00	42.2	30.1	4575707	4575707
65056e29-88ee-414f-9bfa-bccce1a31298	2026-01-06 20:08:25.924191+00	44.5	30	2323544	2323544
2abc7cc8-3ba4-424b-a275-5fb487a2f44a	2026-01-06 20:09:22.337303+00	38.8	30	5679756	5679756
cfd91d18-0f17-4fc1-bb02-42c8edc178fe	2026-01-06 20:09:50.574389+00	36.5	30.1	1057822	1057822
b48decae-5a7a-47ec-957a-dd41eede7f94	2026-01-06 20:10:23.146856+00	44.1	30	394436	394436
d193e7ec-9442-4860-93fa-5e4583c027ef	2026-01-06 20:10:25.96081+00	56.3	30.1	3366346	3366346
edb1a47a-345f-4cee-bf1b-f3ceedc8f026	2026-01-06 20:11:02.073714+00	50.4	30.1	5656000	5656000
7de305b6-1dff-4677-8ead-46c89ca004b7	2026-01-06 20:11:22.431664+00	42.9	30.1	5322871	5322871
0ff74a2e-dbbe-44c4-8cd6-8b21a46ceb60	2026-01-06 20:12:02.058618+00	45.5	30	2774520	2774520
37115e3a-9228-4ccb-aa5a-08bd1f77927e	2026-01-06 20:12:22.357933+00	42	30.1	3816732	3816732
05cebeda-b56a-4b8c-a11d-b5627621ada0	2026-01-06 20:12:50.557346+00	43	30.1	5803102	5803102
b0c2f808-4955-4076-a090-4ac8b125e359	2026-01-06 20:13:50.545563+00	34.2	30.1	3835853	3835853
e04783ef-fe42-46f1-9556-24d5af02e56e	2026-01-06 20:14:02.111128+00	50.8	30.1	552510	552510
23ca6bfd-c3dd-4886-bc26-6217a9ff5fa4	2026-01-06 20:14:22.299236+00	42.6	30	5285678	5285678
e871a3ae-ef74-4108-965d-7137ae29a310	2026-01-06 20:14:50.613017+00	35.6	30	4156030	4156030
72c47499-119b-4c30-9beb-855d95431167	2026-01-06 20:15:22.873492+00	45.1	30.1	503211	503211
edf173cc-9447-49cc-a1bd-46de1edf6b48	2026-01-06 20:17:22.32249+00	42.8	30	783055	783055
2cd276eb-849f-4d46-9c86-3e2fb016cc3a	2026-01-06 20:18:52.127868+00	39.2	30.1	3760358	3760358
d7f835ee-dfc0-430b-9687-1aa819dc2f3f	2026-01-06 20:19:21.579371+00	31.6	29.9	624367	624367
3bfe0c86-8a7e-437d-85ab-1b91e89772d6	2026-01-06 16:32:19.572191+00	13.9	27.6	579739	579739
4d9230b1-e05a-4d84-8a81-b6e696405c50	2026-01-06 16:32:25.932264+00	19.3	27.1	324836	324836
16dad649-7860-4a02-8500-6a2776a156d1	2026-01-06 16:32:42.092329+00	11	28.6	35907	66940
7e9f39f4-aecb-4b70-9bef-f703da2ddfa7	2026-01-06 16:32:50.465195+00	9.5	28.4	663624	663624
bbabe87c-b5f0-4774-8f32-f3840bd931c6	2026-01-06 18:02:43.450936+00	39.1	29.7	4568302	122146
fcd81b3f-2cc2-4229-8dfe-0ee84a3d1b94	2026-01-06 18:27:22.390078+00	43.4	29.9	831220	831220
e27ce9d2-f69b-4f3c-af58-65c61944abdc	2026-01-06 18:28:51.831917+00	43.9	30	3877129	3877129
7f55f7a6-102b-41e0-84cc-75d1af448515	2026-01-06 18:29:22.36258+00	36.3	29.9	3309992	3309992
c37f8461-53eb-438d-9261-d85b84980a9a	2026-01-06 18:30:22.695032+00	43.2	29.6	5469142	5469142
258f9ba0-3084-4116-bee3-9464b39e90f2	2026-01-06 18:30:25.955577+00	53.3	29.7	3427506	3427506
3f61cc2c-de8a-4aa8-93cc-b64b5fa83db3	2026-01-06 18:31:02.1317+00	55.8	29.8	5222829	5222829
859a6d3d-6806-47a5-8d2e-0f7be95d1367	2026-01-06 18:31:22.281307+00	41.3	29.8	5559559	5559559
cf6e5861-1103-46fb-bf84-eef5e13ecab3	2026-01-06 18:33:22.717284+00	40.5	29.9	4614541	4614541
ade019ed-0d71-469b-8d85-08ace5e4cf74	2026-01-06 18:33:51.754732+00	42.4	29.7	3416540	3416540
25c8ba68-29cd-4f84-b346-ef80d1d03541	2026-01-06 18:34:50.644503+00	40.8	29.8	5207914	5207914
0acccc11-5bc4-49fc-a434-a0fbcc94517c	2026-01-06 18:35:22.637181+00	45.5	29.8	384194	384194
ab60e40b-cc28-4bea-a850-8bca618777d0	2026-01-06 18:36:22.733088+00	43.7	29.9	276298	276298
2de48256-f285-4776-b542-b9cf974289de	2026-01-06 18:36:51.829011+00	42.5	29.7	2218400	2218400
084f60bb-a045-4cbf-a438-d37ac10e5f71	2026-01-06 18:37:50.495164+00	37.6	29.7	1408850	1408850
4c0229c9-cd82-4d09-8ff0-3fd4a5e2f05b	2026-01-06 18:37:52.044293+00	70	29.7	2464639	2464639
103ecaea-1d88-4b8a-82f9-dc4206742aac	2026-01-06 18:38:51.747533+00	53.6	29.8	3993651	3993651
007b2f34-b20b-432e-a810-4088bffb65f4	2026-01-06 18:39:50.54895+00	33.5	30	822503	822503
96109642-e55e-4550-a91a-dd2376320dbb	2026-01-06 18:40:21.537183+00	42.6	29.7	3858248	3858248
57ce7b4c-551a-4702-8d3d-3ac141e26863	2026-01-06 18:40:22.297288+00	40.8	29.8	3041682	3041682
221b2de2-afb8-4523-82f7-2600a58a2d69	2026-01-06 18:42:22.647452+00	40.1	29.8	4752600	4752600
c20f8e92-211f-4e14-86bb-21015e374362	2026-01-06 18:42:25.945294+00	45.5	29.9	714646	714646
fff0d4b5-98ab-4401-8895-f7047dd31171	2026-01-06 18:49:44.187288+00	40.8	29.8	4041905	105639
33ca85a6-caa5-48db-9c0e-ff68514566e6	2026-01-06 19:14:44.580475+00	42.8	29.9	4603165	123483
8a7b6a84-b4bc-4391-a56d-a5ac37cf94f6	2026-01-06 19:41:44.911817+00	40.5	30	4615532	119946
2ed3e22d-8edf-4dab-8467-36a79081b6a2	2026-01-06 20:05:21.610945+00	29.9	29.9	975842	975842
5d06a7ac-2292-4d98-b85b-21ad633d012a	2026-01-06 20:05:25.945753+00	43.1	30	4536090	4536090
c2f3ab60-80ba-448d-9771-d4931a872a08	2026-01-06 20:05:52.153668+00	40.2	30	4528809	4528809
cf124e28-3dfc-4fc9-90c1-3cf962eadef5	2026-01-06 20:07:50.559687+00	37	30	4270209	4270209
b9a67208-1467-4fa0-acf1-e2f340d377a5	2026-01-06 20:07:51.710159+00	40	30	4992412	4992412
8ce01996-5a31-48fb-9db5-62dcdf0e5a27	2026-01-06 20:08:02.002044+00	48.9	30	612308	612308
b44ea38c-8723-4670-a7ec-00f25bf5b303	2026-01-06 20:08:22.882434+00	42.2	30.1	6166900	6166900
8840cbf3-d3b1-4e30-a916-9796dbb57d0b	2026-01-06 20:08:50.509312+00	37.3	30.1	3257932	3257932
e6f6fa08-d6cd-4a56-8e96-ecdf73e48a15	2026-01-06 20:09:02.117871+00	45.3	30	4828618	4828618
9579d55c-c30f-4574-ae11-8b5a287c2bbd	2026-01-06 20:10:23.093812+00	44.1	30	408743	408743
3b335780-a3e5-4bcd-8574-dc9152fc67bf	2026-01-06 20:10:50.658464+00	41.9	30	3393277	3393277
7c5e6edd-6962-4b8f-a2b0-3ff887f2d41e	2026-01-06 20:11:25.919333+00	45.8	30	5731061	5731061
6b8ea6a8-4412-46ac-9bc6-dd356189d087	2026-01-06 20:12:22.902022+00	42	30.1	2210838	2210838
ca91c794-7327-46ec-92ee-38e2b64dc9a0	2026-01-06 20:13:22.446994+00	42.6	30.2	4953853	4953853
995b4c4d-b3fb-4181-bf20-ee1da1404197	2026-01-06 20:14:51.980216+00	68	30.1	2803446	2803446
7cff4b3f-5013-4f2c-939a-82553fb0bea3	2026-01-06 20:16:22.69389+00	39.5	30.1	748879	748879
cda73447-ba86-413c-9d8f-fc6ab7a20deb	2026-01-06 20:16:25.927263+00	54.7	30.1	470815	470815
00dc5b60-58dc-4421-af76-4578c0148f91	2026-01-06 20:16:51.787302+00	70.7	30	3550990	3550990
3836972d-c6fa-4acd-8064-c5097cb195c7	2026-01-06 20:17:21.561285+00	30.6	30.1	3778207	3778207
dfece93f-30e9-4264-9692-48e3d2e3171f	2026-01-06 20:17:25.953151+00	46.5	30.1	421537	421537
1a23e381-b94e-4607-8692-28493d54c096	2026-01-06 20:17:50.598172+00	38.1	30.1	6307022	6307022
05df00e3-b4e4-4fd7-bdf1-df77da22bd4e	2026-01-06 20:18:22.359109+00	43.9	30.2	4805275	4805275
43a1ce8b-3066-4c45-b523-c3e9562f6d29	2026-01-06 20:18:25.91191+00	49.7	30	2807681	2807681
dfd187ef-7e8d-4bac-858a-feb480f434d6	2026-01-06 20:19:50.579656+00	42.1	30.1	3844596	3844596
718a742e-7796-46f8-9a78-a2b145ea573a	2026-01-06 20:19:52.048246+00	42.4	30.1	3659942	3659942
8ea32d5a-7114-4b33-851f-76b00809fd00	2026-01-06 20:21:25.929964+00	50.6	30.1	2583118	2583118
4e634d09-6a82-494f-945f-af5708f7c4bd	2026-01-06 20:22:02.138262+00	48.6	30	4470419	4470419
2e49ed47-a708-40b6-a162-484d853aa258	2026-01-06 20:22:25.936203+00	45.7	30	3298140	3298140
9ce60d51-7789-4af0-8633-8bd76618357e	2026-01-06 20:23:22.609972+00	44.7	30.1	2993271	2993271
521b935f-eea8-4c3d-84ad-e4ea178b2225	2026-01-06 20:24:22.388948+00	42.5	30.3	5896471	5896471
873f19ac-9715-4246-bc04-85dd96ce39d0	2026-01-06 20:25:21.50394+00	31.6	30	3955346	3955346
c64ec09f-999d-4e66-bbf7-2efe847d84ac	2026-01-06 20:25:50.515189+00	39	30.1	4906824	4906824
88038d36-dde5-451f-81f6-c8918c5466d2	2026-01-06 20:26:25.938083+00	42.2	30.1	2113344	2113344
61dd6d3a-90db-469d-94ff-0a30328f632b	2026-01-06 20:29:21.599286+00	31	30.3	5572534	5572534
12c1644b-203c-4cbc-9623-4119f1b80dc3	2026-01-06 20:29:50.379109+00	40.4	30.2	6533478	6533478
761041eb-7506-42bd-b822-22919391ac45	2026-01-06 20:30:22.622456+00	44.3	30.1	4482596	4482596
9bb84d28-962e-4a3b-baba-8d5d31b76eb6	2026-01-06 20:31:22.843697+00	47	30.1	6385733	6385733
6c2145fd-b9d3-4ae5-b557-4968474d9a65	2026-01-06 20:31:50.649735+00	41.1	30.2	494048	494048
ed612c74-9434-4208-a678-72fdd4263471	2026-01-06 20:33:22.701583+00	45.1	30.2	280785	280785
32a8c1b1-6ba8-454e-8da8-7fcb2ab91bf9	2026-01-06 20:33:50.438736+00	38	30	3671398	3671398
d06681d0-103f-48cc-8f36-d75100a2cfa0	2026-01-06 20:33:52.04254+00	42.2	30.2	2618744	2618744
e87e2911-0e00-446f-a8be-b20ef016d60c	2026-01-06 20:34:50.530481+00	41	30	3255748	3255748
cbb8bcc9-392f-4c6b-b6c9-410e2a38e94c	2026-01-06 20:34:52.152098+00	44.3	30.1	3695659	3695659
1f1cd48f-2deb-48da-9450-c46a1571a9fe	2026-01-06 20:35:22.390479+00	43.4	30.1	4116686	4116686
c13f5eeb-0876-4452-a30b-39a710be7e00	2026-01-06 20:35:50.609158+00	42.9	30	3458397	3458397
c6a0cb22-16a6-4f81-a050-6e86729d445e	2026-01-06 20:46:45.864879+00	38.5	30.1	8287311	243892
96bb45a6-af9c-441e-a2e7-14935a5b4bce	2026-01-06 21:13:46.267193+00	3.9	21.5	1763	308
02a804d2-ba8a-40b6-a841-23aaf7bd7bfb	2026-01-06 21:42:46.609689+00	3.8	21.5	1558	198
ada9a6d6-495c-4ba6-8aef-ce0741d76efe	2026-01-06 22:11:46.943435+00	4.7	21.6	1760	282
35fd07e7-ab67-4caf-874b-7733151a64fd	2026-01-06 22:40:47.305177+00	4	21.4	1566	176
fc8d64bd-67de-486d-9eb2-ba6c4ff807e6	2026-01-06 23:09:47.662176+00	3.1	21.6	1869	309
16543303-753c-4737-a1f4-98b84021f8de	2026-01-06 23:38:48.010179+00	2.7	21.4	1654	199
ce544175-f19d-4dc5-8aab-b4881261a24e	2026-01-07 00:07:48.363373+00	0.9	10.2	1301	14
f882534f-82dd-4b86-b237-72b1cdf81f0a	2026-01-07 00:36:48.742262+00	0.9	10.1	1138	13
dea24bac-cc49-43bf-97e0-0f8c9879e886	2026-01-07 01:05:49.124014+00	1.1	10.3	1247	14
791a865e-53cb-464d-9c60-17c3fb6b8dc6	2026-01-07 01:34:49.573812+00	0.9	10.2	1305	18
70b71fc6-9560-46a3-9898-3e32fa6a475d	2026-01-07 01:58:01.15423+00	2.5	11	455550	455550
eeae34a9-a9e7-4b1e-9a06-1481e2cef880	2026-01-07 01:59:00.765389+00	3.8	11	551859	551859
48d3bfc0-5dc6-4772-ad9d-9c24594d51dc	2026-01-07 02:00:00.739223+00	1.9	11	504766	504766
48c57136-30b5-4886-a1e6-c7d4d547578a	2026-01-07 02:01:00.067347+00	2.9	11	9457	9457
a3c6888c-e347-442a-8033-fcd86efe8156	2026-01-07 02:01:00.765244+00	2.9	11	792590	792590
9af86881-f681-4dd8-ace7-71439f8e3301	2026-01-07 02:02:00.94711+00	2.7	11	315041	315041
b03221d3-2090-427b-be8d-5bc40d5c58ad	2026-01-07 02:03:00.719454+00	2.6	11.1	772928	772928
47577c5d-b1fe-43a0-93a7-64dd3742ea07	2026-01-07 02:04:00.321951+00	2.6	10.9	617710	617710
0bce500c-bbe6-40cf-a506-b44e52b88d8e	2026-01-07 02:04:01.161255+00	2.6	10.9	197468	197468
1a48a07f-58da-4b78-8b98-93070933f904	2026-01-07 02:05:00.740589+00	3.3	11	695707	695707
f0eca18a-2ef7-4649-8e9e-169170a87274	2026-01-07 02:06:00.640048+00	2.8	11	751018	751018
1a28b1f5-f088-4d44-925e-dd5a43279b5d	2026-01-07 02:06:00.890414+00	2.8	11	507614	507614
371b8082-ee01-43bb-a8b4-bb1a7bc613ae	2026-01-06 16:33:19.577751+00	15.5	30.3	307943	307943
0f752c56-570d-47b6-bee2-8eda82d6b6b6	2026-01-06 16:33:42.097279+00	21	29.7	41550	17193
400c1de7-8455-4bd7-b9ef-42d646e23d09	2026-01-06 16:33:49.709973+00	51.1	31.1	414024	414024
854a1078-0738-49c1-a33e-aa84e87c02a0	2026-01-06 16:34:21.689907+00	33	30.4	2637959	2637959
94989407-7a38-417b-8666-fee968fc8b4e	2026-01-06 16:35:25.932448+00	39.1	26.9	1279625	1279625
e47d5c3e-e0c0-4819-8e7b-50fc99537cc4	2026-01-06 16:36:49.980637+00	33.7	27	3009941	3009941
5ddce0d6-4aeb-4dad-924d-219a621df2de	2026-01-06 16:36:50.990666+00	33.7	27	4103035	4103035
e9b73533-c491-4c8a-ae8d-765270d07055	2026-01-06 16:37:21.999173+00	40.9	28.2	2872580	2872580
534a1980-5d3a-4abe-8cca-fa013c81b476	2026-01-06 16:37:25.885183+00	41.1	28.3	831039	831039
6567e0c7-1d94-4bdb-8180-89f74c71d13c	2026-01-06 16:37:50.786234+00	37.8	28.1	3400987	3400987
a8856552-bdf4-4893-90ee-70874c962e9a	2026-01-06 16:38:21.832855+00	34.7	28.1	5730196	5730196
af8fe4fb-d0c0-4f71-9487-354f314bd010	2026-01-06 16:39:21.872869+00	40.2	28.3	4284024	4284024
dcb075bb-3dbd-4402-95c0-a18f4d451650	2026-01-06 16:39:25.973487+00	46.7	28.3	2310878	2310878
5084a04a-cd16-440c-bda3-99162d95ce6f	2026-01-06 16:39:50.992518+00	35.7	28.4	3408339	3408339
5f7db91b-136f-4b63-953e-a41dbf01ee2e	2026-01-06 16:40:25.933366+00	42.4	28.1	1677254	1677254
eb3de426-8026-4e7a-a2b9-a9e8756a3c13	2026-01-06 16:40:50.462965+00	37.1	27.7	796657	796657
072af79f-b623-4e1e-9631-598f7b35026f	2026-01-06 16:41:49.677999+00	31.9	30	487512	487512
0761503d-d4fd-4383-b18c-0b3924c53d08	2026-01-06 16:43:50.953587+00	29.5	28.4	3044224	3044224
07d178b4-1702-45fc-b6fe-9ff0e0d936bd	2026-01-06 18:03:43.492199+00	50.4	29.7	4401440	113604
ab23e01b-a872-46a8-88d1-9e83200561b4	2026-01-06 18:27:22.759282+00	43.4	29.9	3366202	3366202
3886e6a4-dcfd-4d14-9030-612c4c9d1826	2026-01-06 18:27:50.641982+00	29.9	29.9	5929732	5929732
313d753b-2a7a-491c-a6d4-852965bda324	2026-01-06 18:28:02.113055+00	51.6	30	5172849	5172849
d7614f74-a17c-4b8f-be67-75ae0a253806	2026-01-06 18:28:21.661421+00	36.6	29.9	3048460	3048460
c84b133d-4088-49ee-b81d-99152d28c598	2026-01-06 18:28:22.954489+00	48.1	29.9	3731370	3731370
84b01287-c606-4886-92ab-e53e1cf86eeb	2026-01-06 18:28:50.40341+00	39.2	29.8	3568101	3568101
91947e6f-dcc5-4d1f-b361-7d9e14e0e554	2026-01-06 18:29:25.909867+00	53.4	29.9	2149674	2149674
53315b01-e176-47ec-aef3-ca17194559e0	2026-01-06 18:30:21.664428+00	45.8	29.7	4772450	4772450
70988b9d-2b1e-4bff-b279-ab3607d0a45f	2026-01-06 18:30:51.8082+00	43.9	29.9	4975862	4975862
960b9bf1-27e6-426a-a089-f4c3ad1e7200	2026-01-06 18:31:22.746163+00	41.3	29.8	6112515	6112515
485131a4-1646-414f-abe5-9699931d8b68	2026-01-06 18:32:22.650174+00	41.2	29.8	2469862	2469862
9b7d6bd4-0482-4f5e-9239-62b14f6853b1	2026-01-06 18:32:25.913077+00	43.3	29.7	3534601	3534601
49db2d4a-47e0-4072-ae86-fb007b0a8565	2026-01-06 18:33:22.342954+00	40.5	29.9	4267150	4267150
f7025d78-467a-4090-8658-a362968dcd5d	2026-01-06 18:33:50.452806+00	38.3	29.7	5870939	5870939
0e6e0daf-b6c2-43bb-931c-e1b1a272a872	2026-01-06 18:49:50.547294+00	41.3	29.8	4581804	4581804
c55dce45-a820-406b-81dc-be1fd077902f	2026-01-06 18:50:22.384698+00	50.8	29.7	3824466	3824466
1ef465e5-efce-43e6-a2f9-7f52cccf48c2	2026-01-06 18:50:23.0028+00	50.8	29.7	4147792	4147792
ddeffded-c3df-477f-821d-37bf54586aaa	2026-01-06 18:51:50.50891+00	35.5	29.7	4592282	4592282
c10ad6cd-2019-40a3-9f61-a97a1522e78f	2026-01-06 18:52:02.077577+00	53.3	29.9	2262896	2262896
cea4df29-de3b-42b6-ad5c-a2de2cfd30af	2026-01-06 18:52:22.691215+00	45.2	29.8	6056490	6056490
1c1a21d6-539e-447f-8a23-cbe84271cb37	2026-01-06 18:52:50.630063+00	39.6	29.9	4650069	4650069
f520be3e-a5e9-4954-9a73-a44dd6c32631	2026-01-06 18:53:22.25885+00	41.3	29.8	4429947	4429947
c2f28e01-123a-4ead-8d7c-f01377c0dd4f	2026-01-06 18:53:51.809045+00	71.1	29.9	3456287	3456287
86f5272c-8998-4d15-8a12-a9d02d8b0d9c	2026-01-06 18:54:22.253702+00	40.5	29.8	736629	736629
9f4fad37-86ea-4894-b28d-a07df7f40147	2026-01-06 18:54:51.800006+00	51.1	29.8	514300	514300
e94bba73-7141-4d57-b6a7-5a4aff83705f	2026-01-06 18:55:22.645419+00	40.7	29.8	527382	527382
3ef7dea7-a554-4852-bef9-9b0bc721a727	2026-01-06 18:56:25.887218+00	56	29.8	3645119	3645119
42c7224e-47d7-430a-aad6-f568d8b82880	2026-01-06 18:56:51.823749+00	44.7	29.9	4439176	4439176
c90d6ea5-e375-485e-8013-0e205fd823cb	2026-01-06 18:57:02.073615+00	48.3	29.8	4540094	4540094
a8205179-8d37-4150-8363-c4414efad547	2026-01-06 18:57:22.822371+00	37.2	29.9	3570613	3570613
15a87349-c1c1-42c1-babe-30d685dc83f8	2026-01-06 18:57:50.647128+00	41.9	29.7	566899	566899
874d36bf-1084-4cc6-acc0-ad9e1519e2d7	2026-01-06 18:58:25.949131+00	43.9	29.7	457589	457589
073972dc-be7c-41e7-9e5e-ec6e8090f974	2026-01-06 18:58:50.547102+00	36.3	29.8	1368042	1368042
db180d66-287c-4657-8e41-5c2b480ade6f	2026-01-06 18:59:25.964307+00	43.1	29.8	2748546	2748546
38acb565-51a9-42df-8cff-06591d308046	2026-01-06 18:59:51.834042+00	40.5	29.9	5504421	5504421
338936c7-2b37-4875-8da9-2aab60e0be6f	2026-01-06 19:00:21.541232+00	42.2	29.7	3539654	3539654
c18887d6-b5df-498c-ab67-bc1cfbb2e50e	2026-01-06 19:00:22.766742+00	51	29.9	4831708	4831708
cf1d1be0-699e-4e4f-955a-fcf822cd075e	2026-01-06 19:00:50.600012+00	42.2	29.9	4594368	4594368
d01853d4-25ee-4ee8-b3b7-14e0e421ec9a	2026-01-06 19:01:50.272301+00	38.9	29.8	5886422	5886422
6cb087b4-69d4-417f-be45-e6c7f1ff2161	2026-01-06 19:02:22.79038+00	41.2	29.8	2572247	2572247
1e5b9403-16ad-435c-b564-6a462ff63b59	2026-01-06 19:15:44.550853+00	47.5	29.9	4037029	106569
fa41dda4-f984-4b1a-8984-40de7f350051	2026-01-06 19:42:44.963592+00	40	30	4215565	111826
8da96e83-4c3b-4701-b8bf-8c63779c5778	2026-01-06 20:05:22.660093+00	46.4	30.1	3950554	3950554
0b489479-3edc-4540-bc5e-b2fe8c191956	2026-01-06 20:05:50.615552+00	39.7	30	2693251	2693251
89ab2491-f0ac-49b2-a18b-34f8159334f5	2026-01-06 20:06:22.698535+00	39.3	30	4803424	4803424
382ef96b-89c4-4894-b04e-bf0abc17f4b3	2026-01-06 20:06:50.633779+00	37	30	562086	562086
7b0d3778-420c-487b-a6f3-8b0ed9942f6f	2026-01-06 20:07:21.547781+00	38.5	29.9	972402	972402
a0168b2f-ed03-4d68-8908-3ac716e8fca6	2026-01-06 20:09:22.903987+00	38.8	30	5676410	5676410
9b860b24-20a0-449f-b242-513b4a6c5170	2026-01-06 20:10:21.710314+00	31	30	5448415	5448415
7c452ae4-f717-475e-8cbd-01c29021f5b5	2026-01-06 20:11:50.448351+00	42.8	30	5508870	5508870
502a159a-15f0-46ae-ae2d-9b229d1f9ec5	2026-01-06 20:12:22.770312+00	42	30.1	3503282	3503282
1ee7c1cd-624f-4122-a62c-79ddb7472dcf	2026-01-06 20:12:25.92291+00	52.7	29.9	3231015	3231015
bd0289ba-5579-4370-a4f8-4bf05de0c0ed	2026-01-06 20:13:22.830003+00	42.6	30.2	314184	314184
fab77a76-4654-4566-96ea-c4606863db2b	2026-01-06 20:13:25.909869+00	46.4	30	1819478	1819478
0367889a-c509-44eb-a737-be3e3bee095b	2026-01-06 20:13:51.783246+00	43.4	30.1	344896	344896
81b64c64-2d9e-4a1b-86c6-29c1144927f3	2026-01-06 20:14:25.954439+00	43.6	30.1	791836	791836
54390ff5-1dac-465d-89ad-c61e7d6d48b6	2026-01-06 20:14:50.539904+00	35.6	30	4364753	4364753
7c69f84d-a901-4009-84ca-58bc72cd945d	2026-01-06 20:15:25.951611+00	44.6	30.1	5764988	5764988
f5f87444-69f4-455a-aba7-6221e296c762	2026-01-06 20:16:22.296751+00	39.5	30.1	438178	438178
281d6d07-3b60-4861-a3d6-5b32634f4df4	2026-01-06 20:17:02.102231+00	46.9	30.1	3125022	3125022
2878518f-6324-4b5e-b55e-7fb09bb31baa	2026-01-06 20:17:22.674718+00	42.8	30	3865940	3865940
8538367e-bd7a-4770-95b4-cd45cb059543	2026-01-06 20:17:50.705307+00	38.1	30.1	4294815	4294815
e974e303-216c-421d-8c0a-d9d5ffb5eb89	2026-01-06 20:17:52.07844+00	41.6	30.2	3961105	3961105
283cf27c-a8ae-44b6-901d-7d19b5f50db2	2026-01-06 20:18:22.773574+00	43.9	30.2	3253554	3253554
0cec83d4-39a4-4e2a-a19c-5a7d646b3053	2026-01-06 20:18:50.489725+00	36.2	30	3912476	3912476
14fff1ba-f117-49de-8058-2fe36455813c	2026-01-06 20:20:22.700312+00	48.4	30.1	4186818	4186818
34696924-310b-40f7-bb8e-5ed6561e1323	2026-01-06 20:21:22.775914+00	49.6	30	3522553	3522553
1daf6b98-88dc-49ac-8c63-0f60e79edf06	2026-01-06 20:23:25.919221+00	45.9	30.1	3773088	3773088
e67e17a7-5cbe-403a-a88d-03f468893edb	2026-01-06 20:24:25.926839+00	43	30	4127354	4127354
5cf35617-9f3e-422c-a4d9-690f11ed0706	2026-01-06 20:24:50.512285+00	44.5	30	5630719	5630719
22df762f-8ad5-4022-a796-adeb360d7475	2026-01-06 20:25:02.092264+00	48.2	30.1	3896028	3896028
d391fb23-9d82-482a-a86b-51ee7cd52cc9	2026-01-06 20:25:22.274182+00	41.8	30.2	5219888	5219888
143d12fd-42ec-4231-9985-c68b26833f78	2026-01-06 20:26:02.043539+00	48.9	30.1	4184811	4184811
a858a400-96d5-461a-a150-ac2e7107da55	2026-01-06 20:26:22.397789+00	42.7	30.2	836668	836668
3efd3a01-7565-45d4-841e-e70ff055ba51	2026-01-06 20:27:22.90018+00	46.3	30.1	3862726	3862726
2be26893-f4c8-46c9-affb-c8edaa6c5289	2026-01-06 20:27:25.909367+00	48	30.1	4726547	4726547
0db47acc-dde1-40fc-9d90-a37ead8e01b9	2026-01-06 20:28:02.116151+00	50.8	30.1	522524	522524
de20d4a8-317e-4e49-abad-50629ee14acb	2026-01-06 20:29:22.718252+00	49.3	30.2	5068241	5068241
46f8e198-92b6-4f50-8e3c-fc0f637a53f9	2026-01-06 16:33:50.487296+00	51.1	31.1	573532	573532
bbdf22a9-46e5-4b9b-ae83-cbe1dc2b5ea7	2026-01-06 16:34:21.363493+00	33	30.4	3052045	3052045
e3537f7c-6dfe-4b39-848d-eb2d38866df5	2026-01-06 16:34:25.941775+00	43.2	29.7	2893733	2893733
4985fe4d-7100-402c-9089-260d43afa159	2026-01-06 16:34:42.159906+00	40.3	28.3	4099898	109545
9ceaef03-6cd1-4f10-9c13-caa4859421d3	2026-01-06 16:34:57.868023+00	33.7	26.8	3740982	3740982
7890d948-0296-401e-bd3b-70d2661395fb	2026-01-06 16:34:59.133647+00	38.4	26.7	220210	220210
c65b2b79-6d3d-4253-8bd4-d23b7ab90c22	2026-01-06 16:35:21.333446+00	23.3	26.8	1001963	1001963
bf8789d4-2c2a-48cc-b699-ada48b652396	2026-01-06 16:35:21.566818+00	23.3	26.8	572836	572836
491ab412-272d-4ac3-b919-b95cfab51fa3	2026-01-06 16:35:22.269043+00	39.9	26.7	2187239	2187239
7be543b0-36f3-4fa7-993a-ffaad7f64d11	2026-01-06 16:35:42.129809+00	32.3	26.7	4169502	163250
4dd993ad-901b-4308-b9d8-eac46b1365f6	2026-01-06 16:35:49.83099+00	38.8	26.8	4582398	4582398
2c2a7abc-5a45-43cd-aa5f-ea580ec41380	2026-01-06 16:35:50.735015+00	38.8	26.8	462267	462267
73677b96-0b9b-474a-9b8e-769dd48f18c4	2026-01-06 16:36:21.39477+00	31.1	26.9	769879	769879
7dafe366-b08e-43cf-8ffb-faa660db026e	2026-01-06 16:36:21.865184+00	38.1	26.9	754378	754378
182d9fef-a3c5-4dcb-8874-6b49ca83df9a	2026-01-06 16:36:22.216132+00	38.1	26.9	257414	257414
3ccef8ff-ef31-4ad0-be77-40bc566c1a9c	2026-01-06 16:36:25.970097+00	46.2	27	2414237	2414237
e2a19683-f409-4207-a731-a4959bad1418	2026-01-06 16:36:42.165684+00	37.9	26.9	4592672	236142
828d65e6-762f-4d9c-907d-01e5d3468322	2026-01-06 16:37:21.461585+00	35.2	28.2	2627999	2627999
52f4aa15-db3d-4844-8a9d-527035f45335	2026-01-06 16:37:22.398199+00	40.9	28.3	1351932	1351932
a891b924-3819-4118-bc19-cc947e9d1509	2026-01-06 16:37:42.191261+00	36.2	28.1	3628138	140764
78aa1b96-0681-4f9b-830e-62f3a2aed545	2026-01-06 16:37:49.884506+00	37.8	28.1	3520880	3520880
6965ff3d-92b0-4ef6-8a8f-d2d0227dd4d2	2026-01-06 16:38:21.419912+00	29.8	28.1	1135931	1135931
aa64a097-f595-4a16-8091-c91cb690f0b7	2026-01-06 16:38:22.230983+00	34.7	28.2	3814951	3814951
5749922b-3740-47f1-9164-d2ca2062831b	2026-01-06 16:38:25.932839+00	41.3	28	4723963	4723963
0962dd74-66a5-4eb5-992d-f609c9469418	2026-01-06 16:38:42.220626+00	38.9	28.4	5005889	252509
ebe81bea-22c4-4133-8ebd-8dc35e6c21ab	2026-01-06 16:38:49.923421+00	33.5	28.3	2270567	2270567
fa0c858a-bf03-4ad4-ac39-532615b3680c	2026-01-06 16:38:50.790587+00	33.5	28.3	3803846	3803846
f1af8425-8e73-4dc2-b748-a8e2f9b8fa68	2026-01-06 16:39:21.458132+00	31.8	28.3	5137213	5137213
2f376bd9-4f56-4c9b-9f0f-625bfeeb3f14	2026-01-06 16:39:22.212513+00	40.2	28.4	454535	454535
c0576ac5-7bb1-47dd-97b2-da86f176d1fb	2026-01-06 16:39:42.256621+00	41.2	28.3	4172664	447994
1838da88-76b4-4bdf-8a6c-42f4321b9d7e	2026-01-06 16:39:50.032602+00	35.7	28.4	3288644	3288644
9cd21c23-e7c4-484c-909d-becc49140103	2026-01-06 16:40:21.387678+00	31.1	28.1	917696	917696
925fe235-7c4f-4950-ba9a-f1e8ad41294c	2026-01-06 16:40:21.80866+00	31.1	28.1	525212	525212
5e4f6a07-c10d-447b-8fd1-17e945ad2be8	2026-01-06 16:40:22.226561+00	46.2	28.1	225422	225422
3388c0ff-de07-46e9-8806-4bdad12c74fa	2026-01-06 16:40:42.181665+00	33.5	29.7	39887	87587
e326eb1a-77ba-4fd3-8b6d-1855a6993933	2026-01-06 16:40:49.617808+00	37.1	27.7	694308	694308
d66eccb7-058c-44c6-a83f-7427320a1ba7	2026-01-06 16:41:21.294233+00	29.1	27.5	734429	734429
441cf9eb-c2ef-46b1-b3bd-21d0f71ed15f	2026-01-06 16:41:21.609169+00	29.1	27.5	496037	496037
7b549d79-2d46-41dc-9c6a-e897107c2bd3	2026-01-06 16:41:21.979008+00	36.7	27.6	355512	355512
9a89ef6c-973d-4d39-8034-328e88935b68	2026-01-06 16:41:25.868039+00	36.3	27.5	794346	794346
d983f3bc-7024-4302-a09b-791f99193a39	2026-01-06 16:41:42.207238+00	34.5	29.5	60695	53190
60aa6211-ffce-4632-bc2b-6e02583e3912	2026-01-06 16:41:50.470445+00	31.9	30	573885	573885
380bf417-43b7-498b-9512-59a4d97869a3	2026-01-06 16:42:21.398486+00	9	30.1	764530	764530
a9c3f8e2-e32d-491b-a398-aee85e355683	2026-01-06 16:42:21.705463+00	9	30.1	778307	778307
8c388767-f1a0-4ee7-99ad-1ece3f642acb	2026-01-06 16:42:22.061039+00	14.7	30.1	169885	169885
d1715397-4b74-434d-8e4d-884e7a5e5883	2026-01-06 16:42:25.891648+00	17.4	30.1	940753	940753
4ac1158e-a3dc-4077-9aa5-1dbe968a41f4	2026-01-06 16:42:42.270752+00	37	30.6	52355	203896
7462bff5-bf0d-4d15-853c-1dc48197c64e	2026-01-06 16:42:49.666084+00	19.2	30.5	879762	879762
0013a595-929b-457f-b685-ac41658404cb	2026-01-06 16:42:50.519744+00	19.2	30.5	386037	386037
230488d2-fb2a-47c4-8794-579c748c4c2b	2026-01-06 16:43:21.328083+00	7.6	32.1	772782	772782
154fa216-96fb-4d23-85de-df50e353a41d	2026-01-06 16:43:21.600773+00	7.6	32.1	641485	641485
ab83b9c6-35cd-40dd-a54d-2b24d45a8880	2026-01-06 16:43:22.065453+00	29.5	31.8	152462	152462
994eab69-f66b-426b-ba1c-c3b8f36679d6	2026-01-06 16:43:25.927777+00	27.6	31.5	298089	298089
a8467ec9-1c97-427c-b5f7-395ff19460f1	2026-01-06 16:43:42.24507+00	18.5	31.2	2647135	87407
78a5d34b-3ace-45bb-8ae4-7a2e8bea149c	2026-01-06 16:43:49.598457+00	29.5	28.4	2826198	2826198
6c4f5f09-99da-472a-8c8e-c47b12aee635	2026-01-06 16:43:49.793134+00	29.5	28.4	3243323	3243323
d717ab50-0749-4432-a4b3-2e70940878c3	2026-01-06 16:44:02.339866+00	43.3	29.7	2790702	2790702
40be64c0-da2f-4b76-bacd-b927ded3fe64	2026-01-06 16:44:21.570792+00	34.6	27.2	4850486	4850486
0b133413-89cb-4e8e-bb7a-179022336989	2026-01-06 16:44:22.282299+00	42.2	27.3	419430	419430
af01fb69-d2bb-4bbf-b203-dd4f8412b418	2026-01-06 16:44:22.636301+00	42.2	27.3	279248	279248
5f796460-337f-42ef-9c71-32c999749058	2026-01-06 16:44:25.955698+00	43	27.2	1034099	1034099
c5d299aa-0d29-4157-9dbb-41dcca9ef28b	2026-01-06 16:44:42.306504+00	42.8	27.3	4809225	144251
73530638-05a6-410d-971a-873867aec250	2026-01-06 16:44:50.354222+00	39	27.3	3691968	3691968
00ba19d3-12c0-49b2-83a8-1365b0c22abf	2026-01-06 16:44:50.494385+00	39	27.3	490282	490282
7ff7cbf2-7310-4cda-9e91-097b7c93cb86	2026-01-06 16:44:51.842026+00	40.8	27.3	151568	151568
2fb72249-8d51-4352-a8fb-277ed2705a68	2026-01-06 16:45:02.068136+00	45	27.3	2073856	2073856
c97f5e4d-b089-42f1-910c-b5681318410c	2026-01-06 16:45:21.553196+00	30.7	27.4	877572	877572
567a1dc5-d499-455f-be54-0afad6835978	2026-01-06 16:45:22.270265+00	42.4	27.4	324545	324545
e9c105f5-183e-4027-b667-0a013e01b834	2026-01-06 16:45:22.702271+00	42.4	27.4	5547997	5547997
d1cd1615-ba92-45d7-8ec0-b5f31cd659e1	2026-01-06 16:45:25.969605+00	53.6	27.3	443675	443675
b5324f80-ef2a-4253-aba6-499597d35570	2026-01-06 16:45:42.263274+00	36.6	27.3	4444417	221725
4f36c055-1af0-4b55-a66e-9cbde025fd9b	2026-01-06 16:45:50.271203+00	40.7	27.4	3183212	3183212
596ac9e5-89a9-492b-b627-b4dc0d1ffd48	2026-01-06 16:45:50.37804+00	40.7	27.4	684949	684949
6fe7aa8e-c0a4-409d-970d-7e22348a7280	2026-01-06 16:45:51.768639+00	37.9	27.4	2358292	2358292
a9c1cf3e-30f7-4354-9c87-8c0a614d677f	2026-01-06 16:46:02.059504+00	48.6	27.3	1686386	1686386
14ed256e-7d26-4f27-a2ff-d468b46f9f64	2026-01-06 16:46:21.828906+00	36.1	27.3	1905835	1905835
2035fe58-2cd1-4914-b988-4fd7d25c97f0	2026-01-06 16:46:22.445607+00	49.4	29.9	635655	635655
b71f2439-b892-456f-bd19-d91354ff229c	2026-01-06 16:46:22.703572+00	49.4	29.9	528433	528433
e4540206-07ae-4292-b845-cadf46032795	2026-01-06 16:46:25.866702+00	42.9	29.1	903315	903315
6432dad6-1d9b-4e8a-86d0-dc2596a7ccfc	2026-01-06 16:46:42.28735+00	34.7	32.8	50809	33883
6f0eaca6-7263-425d-a8af-07776f4cc270	2026-01-06 16:46:49.829796+00	38.2	31.7	730494	730494
cf0f6b58-45af-45b9-aaa6-11a346543151	2026-01-06 16:46:49.961655+00	38.2	31.7	676269	676269
207746d9-934e-47c0-bed6-7b57d3f8f2a1	2026-01-06 16:46:50.906958+00	42.6	31.3	761985	761985
17e054ca-3600-4984-aafe-2645eb5cb922	2026-01-06 16:47:02.141559+00	37.3	33.3	180154	180154
2ccede4b-547c-49e8-9515-d627d76e210a	2026-01-06 16:47:21.416742+00	9	33	948960	948960
9a88bc1e-bc98-4759-beeb-e0740c41469a	2026-01-06 16:47:21.81177+00	15.8	33	504188	504188
862a24b4-d2ba-4017-883b-f65f315836c5	2026-01-06 16:47:22.139479+00	15.8	33	434821	434821
2396ca04-7fa8-4ee2-b4f3-b1350a0e6ffa	2026-01-06 16:47:25.89351+00	23.1	32.8	1400462	1400462
3267121e-e2f8-4581-818c-bcadaafba177	2026-01-06 16:47:42.34909+00	15.5	33	52341	360374
fec695da-40ef-4c42-b7e2-22e818c7a5e2	2026-01-06 16:47:49.598324+00	10.1	32.9	903368	903368
7e6b2f86-20af-42d2-bfaf-fe4b789549d7	2026-01-06 16:47:49.795505+00	10.1	32.9	721482	721482
16336e8c-4832-429a-a82f-9c03322eb37e	2026-01-06 16:47:50.895738+00	10.1	32.9	1271651	1271651
ed810e8a-a935-4601-b0c6-dd8a1526c9c7	2026-01-06 16:48:01.973495+00	26.7	33	470976	470976
a6ff1df2-10b1-411b-87bf-2fc8ba897ae0	2026-01-06 16:48:21.359698+00	8.5	33	852577	852577
cc407b1e-4ae8-4a25-a9fc-44ea7e798834	2026-01-06 16:48:21.820074+00	8.5	33	435765	435765
aed76c53-3046-405d-83c3-4b2e69a54ae7	2026-01-06 16:48:22.190594+00	37.2	33.1	439893	439893
372f9f98-0242-4302-83a0-66d051432aaa	2026-01-06 16:48:25.917051+00	21.1	32.9	564651	564651
508c64f7-3f32-4dcf-a02a-438fc60676af	2026-01-06 16:48:42.367203+00	7.2	33	39010	22281
d101720f-51c3-474d-ac2e-8b985ba5c4f7	2026-01-06 18:03:50.504365+00	39.8	29.6	2382205	2382205
bd57acf3-e8a3-43a3-a378-7968a2db4fc9	2026-01-06 18:03:52.121294+00	39.7	29.7	3820343	3820343
741072f4-5a18-4070-9341-67090de9645c	2026-01-06 18:04:22.67498+00	35.9	29.6	4121586	4121586
68515885-581d-4ee9-94fe-092654885134	2026-01-06 18:04:25.941958+00	45.3	29.6	4292583	4292583
27f50979-6f62-4020-a104-b04993bb7a14	2026-01-06 18:04:50.371368+00	35.5	29.6	4499287	4499287
70299295-e049-4268-9c1f-ca6eae8b855d	2026-01-06 18:07:02.032341+00	41.6	29.6	3740511	3740511
91925d0b-9e71-4beb-a25a-9730a52d19f0	2026-01-06 18:07:22.240907+00	36	29.7	3937719	3937719
c36ac583-a9bd-4242-bed5-e4d61f650e70	2026-01-06 18:07:25.935716+00	43	29.6	1653632	1653632
5f11856b-4a81-4a4d-b7ed-8c87b229c518	2026-01-06 18:08:02.079355+00	50.3	29.7	5649876	5649876
e2516a51-6bbd-46c0-8fac-ba93d54cb950	2026-01-06 18:27:22.822072+00	43.4	29.9	4333076	4333076
c2bed47c-a664-4442-a763-a27d3d00d5bf	2026-01-06 18:28:22.431681+00	48.1	29.9	6337941	6337941
811e0446-6d1e-45d1-ad81-7e30f4ec8058	2026-01-06 18:28:25.932948+00	54.4	29.9	2070473	2070473
0cb12267-3132-4860-9741-12899f794e4e	2026-01-06 18:29:50.503728+00	37.7	29.6	3061209	3061209
4fb99db9-b14f-4db4-ad7d-3009a6e1b0f4	2026-01-06 18:32:02.088341+00	49.2	29.9	632721	632721
3cce6a49-9890-426a-a67c-0c976d6263c6	2026-01-06 18:32:22.490058+00	41.2	29.8	513320	513320
9293f15c-f9be-4d22-925c-d0a67b83867f	2026-01-06 18:50:44.17936+00	47.1	29.8	3648527	91150
d27ad396-1257-4115-aea4-9dfdebe9034c	2026-01-06 19:16:44.598491+00	50.6	29.9	4628117	108656
7973c5eb-b00e-4ec1-97fe-478b12938e57	2026-01-06 19:43:45.028098+00	47.9	30	4686340	122951
95811197-374a-4242-af77-d6675615f093	2026-01-06 20:05:45.248822+00	43.2	30	4211732	106912
5f11c424-53b6-434d-a13e-e242a15fa55e	2026-01-06 20:29:45.658549+00	38.8	30.1	4066242	101973
6268ead7-4410-4618-8e59-522a2fae98ff	2026-01-06 20:46:50.635546+00	39.9	30.1	4755827	4755827
627f95f9-0902-4084-b5d1-367141fc58f6	2026-01-06 20:48:50.572034+00	34.9	30.1	4855983	4855983
b5698a0c-68cd-44e0-a00c-ddab4c7c1b37	2026-01-06 20:49:22.345944+00	43.7	29.9	5229713	5229713
f070e46e-b4ea-48c8-abad-31693ad5b433	2026-01-06 20:49:25.913329+00	46.6	30	2851928	2851928
9e3b75c7-ba16-4760-bfe8-e516aa231142	2026-01-06 20:51:22.338365+00	45.7	30.1	5269510	5269510
dcc03172-e1c7-4e70-8d16-2fa84c9d1de4	2026-01-06 20:52:22.191679+00	45	30.1	4507630	4507630
2f507d23-e130-412f-936d-858e22c4a80a	2026-01-06 20:52:52.122209+00	75.1	30.1	3185278	3185278
cfa8654c-e98b-4076-aa3e-ce67639e05ac	2026-01-06 21:14:46.308949+00	3.8	21.5	1556	307
ef6f969f-5261-4920-a57d-55ec9dea4fef	2026-01-06 21:43:46.622311+00	4.1	21.5	1584	197
eca6df49-3412-4770-b6a9-2eff1b3d256c	2026-01-06 22:12:47.004163+00	3.9	21.5	1789	295
fd5f15e6-a4c9-4036-b803-d73cf478ba77	2026-01-06 22:41:47.333781+00	3.9	21.5	2070	171
6f5c8c84-de0a-4081-9b0b-2c1ca66caa9f	2026-01-06 23:10:47.652695+00	2.8	21.5	1809	316
a747ab74-5946-4750-ab27-2db3d98d243e	2026-01-06 23:39:47.999697+00	3.1	21.4	2134	199
16efd49b-db38-4078-8229-467d57431149	2026-01-07 00:08:48.383131+00	0.9	10.1	1505	13
665c216b-c5df-402e-8d4b-b48e506c032d	2026-01-07 00:37:48.759621+00	0.9	10.1	1587	13
231ab767-6679-4b07-863b-00af3b234232	2026-01-07 01:06:49.157813+00	0.9	10.2	1242	9
9037cf94-075d-411c-8b21-8c5e65ff0e8e	2026-01-07 01:35:49.548075+00	1.2	10.2	1538	14
d351f360-47c4-4f66-b7d9-7b2027b1d574	2026-01-07 01:58:49.880026+00	3.8	11.1	59648	44444
dd1f72e2-1cd7-407e-91c9-536788af2db4	2026-01-07 02:20:00.258114+00	2.7	10.9	758171	758171
93b06835-c4d6-4039-98ef-6e48420efb70	2026-01-07 02:20:00.781424+00	2.7	10.9	444241	444241
318c785b-27d2-498f-b09c-b38d5b242ac6	2026-01-07 02:21:00.727917+00	2.3	11	361335	361335
4005566d-32da-4bfc-a07f-cf2291791c0d	2026-01-07 02:21:00.915585+00	2.3	11	730568	730568
1a41e2b1-6eb1-4dbe-b1ea-d1a783267f83	2026-01-07 02:22:00.331773+00	2.7	10.9	612304	612304
4ae49409-c33c-4b4e-9c59-7f993f820e38	2026-01-07 02:22:00.935013+00	2.7	10.9	740992	740992
4cfdc2ef-7c03-4d5c-ac4c-57d9cce3b310	2026-01-07 02:23:01.045534+00	5.5	11	375781	375781
fa2274bd-a583-42d2-a2e0-e73e4b0dee64	2026-01-07 02:23:01.275943+00	5.5	11	537285	537285
3cf99b8f-5900-4b57-ac13-7ed1e7df9153	2026-01-07 02:24:00.738368+00	2.8	11	789626	789626
c690a3bd-2b16-4f11-8481-67cbfa86880d	2026-01-07 02:25:01.121213+00	3.7	11.1	559300	559300
2e51a16f-4d7d-44b6-9b43-7868e70072d1	2026-01-07 02:26:01.055782+00	2.5	11.1	753008	753008
e1bd94b3-dfa5-4197-be31-b06db9bfbc62	2026-01-07 02:35:50.324398+00	4.4	11	25772	17381
2b647391-3c6b-4063-8a64-8303845a2f22	2026-01-07 02:55:00.780422+00	2.8	11	288671	288671
dc397a0e-2cf4-4ca9-8b8e-cd4dc5542024	2026-01-07 02:56:00.602942+00	2.8	11.1	697453	697453
7323dca9-4ce6-4204-a1d3-a9c7bda3ec82	2026-01-07 02:57:00.960938+00	3.1	10.9	506663	506663
6c46aa79-d365-4caa-8907-6014c3d9b2ef	2026-01-07 03:01:50.676086+00	3.2	11	15989	10661
e75419c3-00db-4cf9-9e65-dd846f09259f	2026-01-07 03:12:50.811492+00	5.1	11	18154	12892
0ba35843-47ba-4e76-8ea4-8f1007b96a2b	2026-01-07 03:22:50.964514+00	1.7	11	22002	47629
40dee86a-86b9-4dba-ad10-61b31304310f	2026-01-07 03:29:51.075956+00	5.2	11.1	17125	10288
b6598b4f-510c-4fe7-b7e1-162c947f853f	2026-01-07 03:36:51.151912+00	4.5	11.1	17932	33027
ba7c4d17-66af-4564-a31c-9ddc129b4d57	2026-01-07 03:43:51.23885+00	3.8	11.1	17303	7250
1c2613fd-1e90-4fc4-9cf3-afcfcbe709d1	2026-01-07 03:46:51.28187+00	4	11	12485	8166
59ac0149-5688-4800-99a2-4930a915f37d	2026-01-07 03:55:00.750895+00	2.4	11	562804	562804
5eea3055-6aa6-4a1e-9f21-62104ed590ba	2026-01-07 03:56:00.238659+00	2.9	11.1	557118	557118
17d58e4b-3c66-495e-897d-7f4135fab9bf	2026-01-07 03:56:00.79894+00	2.9	11.1	515505	515505
da4eb454-43ea-4d73-959e-0c58759ae474	2026-01-07 03:58:51.429673+00	2.7	11	13814	7741
7e84ab3b-70fc-4405-a1a3-c662286d0248	2026-01-07 04:01:01.122675+00	3.2	11	393291	393291
2b08fd1a-795d-4e83-bcfa-e63d3b223525	2026-01-07 04:01:01.396325+00	3.2	11	439574	439574
4f822899-f902-45af-b328-e2358fcc114a	2026-01-07 04:01:51.470558+00	4.8	11.1	13478	9247
2be0402d-4d44-4b4a-a2b1-8397a077f1fc	2026-01-07 04:02:00.900286+00	2.9	10.9	640986	640986
23f55bfe-9351-4da6-a656-31c7efa3e279	2026-01-07 04:03:00.152784+00	4.9	11.1	8822	8822
1eed3f0c-a6d7-4dcb-b646-9e9c6b57dae2	2026-01-07 04:03:00.290665+00	4.9	11.1	572840	572840
d434205e-b30b-498f-a3ae-4838a47e43fb	2026-01-07 04:03:00.756347+00	4.9	11.1	583079	583079
a9dc3776-c749-4869-90f9-4e176e6cb502	2026-01-07 04:03:00.854151+00	4.9	11.1	698240	698240
8e6444b2-f898-4e63-8e4f-4c9e2d5584b4	2026-01-07 04:04:00.743495+00	2.7	11.1	635313	635313
29fd67e2-83ed-4c12-9326-b3c343810f84	2026-01-07 04:05:00.285435+00	3	11.1	372838	372838
c90c90a4-7800-4435-9489-6d34cf66ba85	2026-01-07 04:05:00.862847+00	3	11.1	533325	533325
e2558654-10c1-4467-8346-55b30387eef1	2026-01-07 04:05:00.946614+00	3	11.1	700287	700287
d5ce06d0-4632-49d7-a1bb-4708b20dbdad	2026-01-07 04:06:00.080511+00	2.2	11	8922	8922
701c3eba-a1d7-4729-876b-33d895a813db	2026-01-07 04:06:00.809885+00	2.2	11	562862	562862
baf8521a-5d6c-4398-bb9c-05c15c5169bb	2026-01-07 04:06:00.816161+00	2.2	11	731669	731669
6f850a05-efa8-4bcf-99a2-6f22a2940db8	2026-01-07 04:06:51.52542+00	3.6	11.1	12637	15800
460954cb-8071-4f17-b557-f012d96663e0	2026-01-07 04:07:00.073988+00	2.7	11	8822	8822
15148cbc-a80c-467c-8479-f7dd785e9e86	2026-01-07 04:07:00.181911+00	2.7	11	763159	763159
7bd80174-3b7f-40c2-972d-336677f6eb90	2026-01-07 04:07:00.709302+00	2.7	11	540706	540706
486dcdd5-c5f9-455b-9ecc-8c4a07ffc8da	2026-01-07 04:07:00.77213+00	2.7	11	579504	579504
a1fd4aa5-9fe7-44bd-9f3b-f0fece7a572b	2026-01-07 04:08:00.096339+00	0	11.1	10433	10433
53bafa6a-fb52-44bf-b0b2-53a4588f496a	2026-01-07 04:08:00.381446+00	0	11.1	161356	161356
0f152ea1-e2ba-4ef6-8989-37e76c91f4cd	2026-01-07 04:08:01.010108+00	0	11.1	261922	261922
0eb1d6e1-c7aa-46f1-92d1-7ac5f25d03df	2026-01-07 04:08:01.050738+00	0	11.1	299047	299047
2f2c6d91-1949-4763-845e-b7bbffed630e	2026-01-07 04:08:01.11409+00	0	11.1	645426	645426
a4c3e0d6-f4dc-4f57-baac-3ab86d4efb7f	2026-01-07 04:08:01.225077+00	0	11.1	411661	411661
558be17e-a52f-4003-83e8-bfea78bd42a5	2026-01-07 04:09:00.080494+00	2.6	11.2	9156	9156
c408a1cd-510b-477f-a38e-0e00d9989c89	2026-01-07 04:09:00.183875+00	2.6	11.2	748895	748895
19d4692e-964d-4163-a005-0e862fcc6118	2026-01-07 04:09:00.949278+00	2.6	11.2	635999	635999
455a0b24-6ff6-4844-a850-db3c47895c79	2026-01-07 04:09:01.01807+00	2.6	11.2	665126	665126
dd9afebf-bad1-4f58-b410-d4039981e833	2026-01-07 04:09:01.04201+00	2.6	11.2	579879	579879
b32653e2-aff6-4458-913d-699079adb25d	2026-01-07 04:09:01.07114+00	2.6	11.2	610943	610943
2f831940-cfe2-4c94-a1b1-5ddb4b69ad4a	2026-01-06 16:48:49.58855+00	16.1	33	602654	602654
a4dd6b72-ca89-428a-9c48-9f4e7a53121d	2026-01-06 16:49:25.935889+00	19.7	25.2	376714	376714
0d7f9f79-bcad-485f-a08d-6b026ed6442b	2026-01-06 16:50:25.94427+00	26.5	25.3	607555	607555
85a825d5-fed5-4a03-b7d6-987c5af82cd1	2026-01-06 16:51:22.211151+00	22.6	32.9	454285	454285
59042e17-57c9-4b5f-89b7-a0a94e224f2a	2026-01-06 16:52:50.440604+00	39.2	27.6	503253	503253
754d2c5e-66a5-42cc-b2b1-c364c7080764	2026-01-06 16:53:22.258145+00	45	27.7	1914746	1914746
4cae536d-69d6-4ab0-ac5e-9e2480c196c2	2026-01-06 16:53:25.94244+00	55.6	27.6	1180647	1180647
5b6d4c38-c0ee-4015-99c6-321c2125fc57	2026-01-06 16:54:21.58545+00	32.5	27.8	757320	757320
0c5763ae-2c22-4e2e-a78d-5451681adcb7	2026-01-06 18:04:43.531952+00	39.1	29.6	3585667	98832
5f7f272d-f65b-42ed-a751-494959f0e74a	2026-01-06 18:27:43.857479+00	38.3	30	4044485	110926
ad37f436-bf6f-4708-82bd-3e0631a16e8b	2026-01-06 18:51:44.22375+00	41.1	29.7	4277044	115190
ccc2d303-660d-42e2-8206-b23d75e942d2	2026-01-06 19:17:44.620323+00	48.7	29.9	4397124	116305
619afc72-cb52-4ff8-b753-775c5abdad61	2026-01-06 19:44:21.572718+00	30.7	30	1148483	1148483
4a66f2d1-4cb4-408d-83bf-c55a2d83ef82	2026-01-06 19:44:25.924756+00	42.7	30	2804713	2804713
356d9ca5-c7db-4b4f-a8d7-6f202cb641f4	2026-01-06 19:44:50.640654+00	35.3	30	3833716	3833716
8d38940c-43bf-484a-89f8-34c01976fd84	2026-01-06 19:45:22.322243+00	45.1	30	4120452	4120452
9fb77b7d-220c-4ca4-9518-75ed4348eeb7	2026-01-06 19:46:21.577158+00	33.5	30	4245276	4245276
667059fb-3a6b-4c00-a8d1-670483270b9d	2026-01-06 19:47:22.32416+00	35.5	30.1	4577905	4577905
b8b93b1f-be7c-43fb-ae58-8569ab85f6db	2026-01-06 19:47:50.663622+00	41	29.9	5929587	5929587
a08bc235-6d06-4446-a865-c8b42259c737	2026-01-06 19:48:22.354306+00	43.9	30.1	4316844	4316844
8618e865-72eb-41e1-aa30-cb51ee24ffe3	2026-01-06 19:48:50.324346+00	36.8	30	3902000	3902000
293a2133-e1cb-4c1c-944d-e58542f698d1	2026-01-06 19:48:51.728289+00	69.7	30	3118788	3118788
4a737673-d2e4-4d5f-8e57-74d18bdb23fa	2026-01-06 19:49:22.693784+00	39.7	30	315624	315624
66d99714-d5ac-43fd-8dfc-59b5a714908f	2026-01-06 19:50:22.684968+00	44.4	30	4504793	4504793
5d81ba09-d42c-4d75-9118-d2cb2e5c794f	2026-01-06 19:50:50.497296+00	37	30	2712998	2712998
4bf26021-9914-4528-bdff-9ad2d5379193	2026-01-06 19:52:21.5391+00	33.2	30	3112528	3112528
545e8836-9568-4e15-a9f9-a719ed732d31	2026-01-06 19:52:25.917863+00	63.4	30.1	1507189	1507189
118cb51a-bb9d-4516-abc0-c6717e0742fa	2026-01-06 19:53:02.040489+00	47.7	30.1	4231634	4231634
ac6c5790-c449-4661-b115-a2529ed03a6a	2026-01-06 19:55:22.29603+00	39.5	30	4500876	4500876
4682ca03-4ee1-4ff0-a3e3-2efb8602b2a3	2026-01-06 19:57:22.310997+00	39.7	30	487000	487000
7ebf2be5-9681-49b5-a218-12b4bfeae64e	2026-01-06 19:59:22.739874+00	40	30	5196530	5196530
d7b56333-a232-45aa-afe2-e1eabaf126ac	2026-01-06 20:00:02.120168+00	42.5	30	6323292	6323292
ac58703a-fdfb-4b72-89b9-de1db095c931	2026-01-06 20:00:25.903223+00	42.5	30.1	3682637	3682637
24e84454-3026-43ca-a966-b096ce32360c	2026-01-06 20:02:22.768556+00	36.8	30	2842208	2842208
819f3bc6-c40f-49de-972c-bc4b71b100ed	2026-01-06 20:02:51.823924+00	71.2	30	403507	403507
6007b8f7-59f7-49bf-8f2f-56c334a92bd0	2026-01-06 20:03:22.769888+00	43.3	30	3192149	3192149
c1e00ae7-d1c0-46b5-a3f0-518ecd206400	2026-01-06 20:06:45.304871+00	41.7	30	4607237	116247
6ef273d9-436e-4397-89d7-4c271a210af5	2026-01-06 20:29:50.528737+00	40.4	30.2	4594882	4594882
d07dc371-12bf-4c1d-9e7d-428d7e5713a9	2026-01-06 20:30:25.906247+00	53.1	30.1	864153	864153
e37cbe4a-0635-4bbc-bdec-b787ca2e2052	2026-01-06 20:30:50.354421+00	35.1	30	700439	700439
bfb7bd07-a4b7-4991-9fd0-957fdf025f03	2026-01-06 20:31:21.596888+00	35.4	30.1	3607328	3607328
ae34dc5d-aaaf-40c5-a7d4-f681200144c0	2026-01-06 20:31:25.943635+00	47.3	30	507705	507705
5e5c49ab-ad35-4d9e-8013-2be48a6a66b4	2026-01-06 20:32:22.735954+00	40	30.1	3279615	3279615
9d8bcfec-7a8b-45d3-9dfe-f0cd26c211a9	2026-01-06 20:32:50.500551+00	38.1	30.1	4008947	4008947
d35f6d21-1bd1-4e71-a5ae-48b854b41940	2026-01-06 20:34:02.066644+00	54.3	30	5126730	5126730
70a71562-15a0-471c-802a-6caebf507131	2026-01-06 20:47:45.88237+00	36.3	30.1	5598902	135403
5b48f2a6-763d-4752-8c88-8c47235d0b2b	2026-01-06 21:15:46.270968+00	4.2	21.6	1412	308
35f9772f-ab3c-4915-b835-b1365c34466c	2026-01-06 21:44:46.631854+00	3.7	21.5	1231	192
e14340cc-a725-48da-87d7-631c980fd309	2026-01-06 22:13:47.006874+00	4	21.5	1488	295
36a37f47-2b63-4328-a431-66d393b6a598	2026-01-06 22:42:47.349262+00	3.7	21.5	1587	184
e7e5e0a7-4990-47b3-a1ab-0dad3a2c8289	2026-01-06 23:11:47.709047+00	2.9	21.5	1785	306
0852cd07-b4a2-4e92-b951-5c50a70eb422	2026-01-06 23:40:48.013132+00	2.8	21.4	1573	203
b49cfcaa-ed2e-4820-8cd3-baff9aa5de8a	2026-01-07 00:09:48.399621+00	1	10.1	1503	22
b1223c02-330e-4a8a-82db-c278ea53db82	2026-01-07 00:38:48.767617+00	0.9	10.1	1373	35
38d0a027-cd76-4e94-bfdc-aec463ff981a	2026-01-07 01:07:49.17696+00	1	10.2	1528	9
b19e91f0-e1d7-4c14-b2ef-28793d8617fa	2026-01-07 01:36:49.581973+00	0.9	10.2	1337	19
d00cdac7-71e6-4d19-8504-325dcf9ea713	2026-01-07 01:59:49.883677+00	4.3	11	66518	109200
c02acf79-9da6-4ad5-99d4-fe6dd6496a42	2026-01-07 02:20:00.769769+00	2.7	10.9	338655	338655
01ad3a08-0b27-466f-9b61-b5d8b486d04a	2026-01-07 02:20:00.951319+00	2.7	10.9	633360	633360
c7429344-047e-454a-9218-4842991ec6a4	2026-01-07 02:21:00.823936+00	2.3	11	762715	762715
e1b6c09f-cae3-48a6-8c2d-7a92c33448db	2026-01-07 02:22:01.000141+00	2.7	10.9	889679	889679
7f88ab41-eca2-4164-be3b-0b635adf319f	2026-01-07 02:23:01.116664+00	5.5	11	413312	413312
111991f0-f369-443a-889d-95abe4d7a151	2026-01-07 02:24:00.695451+00	2.8	11	700095	700095
7fdd6e75-f773-4391-8393-5cad84a3fbe7	2026-01-07 02:25:00.984137+00	3.7	11.1	246056	246056
88f142c5-f4df-4b49-b1a2-5929a099a82f	2026-01-07 02:26:01.124226+00	2.5	11.1	818845	818845
ba882e88-9eb2-470a-a127-eedf4423f7c8	2026-01-07 02:27:00.079205+00	5	11.1	7357	7357
a0557138-fe67-4a4b-9c91-8d9a401a0233	2026-01-07 02:27:00.950427+00	5	11.1	686557	686557
0cfc4fc0-b9c9-4ec5-b1ac-b89917804789	2026-01-07 02:36:50.349702+00	3.7	11	24563	17793
0677b7d5-61d9-4ab5-83fe-2abdcc93e940	2026-01-07 02:55:50.584258+00	3.5	11.1	40850	69142
6e48e222-50e3-4aec-8c16-ce64dad34238	2026-01-07 03:02:00.07805+00	2.8	11	11089	11089
06fbaafb-39df-4f9d-aa5f-0fc458d5908e	2026-01-07 03:02:00.915598+00	2.8	11	588215	588215
88db42f5-a354-4f0a-90a6-2a665588a1bc	2026-01-07 03:03:00.776975+00	2.1	11	293839	293839
74ec4779-0d41-4cde-b6e3-0078a6273240	2026-01-07 03:04:01.294511+00	2.5	11.1	605946	605946
e3015591-f8c4-4b96-92f3-56182885acac	2026-01-07 03:05:01.277027+00	2.8	11	477290	477290
9f0ae08d-17ad-40a3-88c6-9156bc4939e8	2026-01-07 03:06:00.082734+00	3	11.1	8778	8778
4209c59b-370e-4dd6-9418-25895b93f51a	2026-01-07 03:06:00.940431+00	3	11.1	450569	450569
c86df6b2-8a0e-48b1-b59c-67ace16d595f	2026-01-07 03:07:00.243838+00	2.9	11	727785	727785
d3ff71ce-f7f6-4396-b409-5db579996e23	2026-01-07 03:07:00.746173+00	2.9	11	476291	476291
3b5a709b-41c5-4251-8739-81e0de1df355	2026-01-07 03:08:00.344599+00	3.7	11.1	418884	418884
f5f7e918-f1f0-4066-951d-0310331d0b9a	2026-01-07 03:08:00.937142+00	3.7	11.1	536533	536533
163a28af-36aa-4b4c-bcd8-bf8cbf0e1d44	2026-01-07 03:09:00.888184+00	4.8	11.1	658765	658765
1d27c656-cfeb-4ee0-bcb5-84dda97bb7b8	2026-01-07 03:10:00.745001+00	2.6	11	454563	454563
064462fb-abdb-4eaa-9495-2967db09d55e	2026-01-07 03:10:00.964571+00	2.6	11	643642	643642
2d3cb105-e6dc-4454-9253-f3dea57bb304	2026-01-07 03:11:00.262818+00	2.8	11	513543	513543
95d903a1-c639-4d73-acc3-5654a6e7626c	2026-01-07 03:11:00.827529+00	2.8	11	582376	582376
5efffd20-5fab-407e-8e2b-8c6bf173a6a7	2026-01-07 03:12:01.137906+00	3	11	590082	590082
fd69cb13-7640-4ec8-bfbf-badcfa3ee36c	2026-01-07 03:13:00.106975+00	6	11	8501	8501
5c2f41c7-7807-4322-8c18-97579d3fda5c	2026-01-07 03:13:00.943303+00	6	11	645898	645898
95fc0cfa-25e6-4800-93fd-811dc2cf32cb	2026-01-07 03:13:50.822776+00	3.9	11.1	19049	11025
48a9a463-3c9e-41db-a10b-8bdbfcc1f2fc	2026-01-07 03:14:01.03124+00	5.5	11.1	583764	583764
57d4020b-9235-4fee-b3bf-444adf4bf043	2026-01-07 03:15:00.40691+00	3.2	11.1	279782	279782
51c38228-f2ed-4ca5-b166-c502d2d6f9f8	2026-01-07 03:15:00.989696+00	3.2	11.1	544980	544980
42ddf577-7112-48fa-9cbb-1219fd271386	2026-01-07 03:16:00.202149+00	2.7	11.1	587538	587538
3cf2e68d-8a37-48f7-a7a5-1dd05288f277	2026-01-07 03:16:00.69533+00	2.7	11.1	881752	881752
b6754114-d85d-466e-b1c5-68fcb4d93373	2026-01-07 03:17:01.13117+00	4	11	476548	476548
30950eee-ddff-4b1b-930d-24313945a701	2026-01-07 03:17:01.384289+00	4	11	405261	405261
5c5c2154-8b91-4ab9-b80a-1ff6407e8ee7	2026-01-07 03:18:00.268191+00	3	11	377828	377828
88ee1726-8abc-4caf-bb80-2910e23a0d31	2026-01-06 16:48:49.748448+00	16.1	33	1082261	1082261
9ac918ec-17d5-4d2f-bc35-68202a3fcce0	2026-01-06 16:50:50.648602+00	14.6	29.3	334949	334949
8618944f-2eee-4887-98a0-f36f72e8ee85	2026-01-06 16:51:21.758855+00	17.9	32.9	910477	910477
88125769-1384-4c53-a0fd-e3700c7e12f1	2026-01-06 16:51:50.515805+00	33.8	29.1	662008	662008
080cbc4a-5a62-4115-85f7-6a872a9b97fb	2026-01-06 16:52:22.116605+00	50	28.1	3354082	3354082
45ea3e06-8e71-4b87-9a80-cc63f286163c	2026-01-06 16:52:25.945165+00	40.9	28.1	1298049	1298049
e77756a7-97d4-42f8-84ad-8d67e227c03d	2026-01-06 16:52:52.079982+00	40.7	27.8	684936	684936
2335bfc2-c72d-4d3e-8f53-a973310390dd	2026-01-06 16:53:50.523171+00	43.8	27.6	2810448	2810448
19577f0d-c188-4ebf-a2a8-6db26001e7b6	2026-01-06 16:54:22.314887+00	40.9	27.8	3745972	3745972
73c5e13f-272d-4f58-be3e-df4bf8a99120	2026-01-06 16:54:50.572169+00	32.5	27.8	2061731	2061731
0a7868fa-7530-4273-8057-66f3e323ecdc	2026-01-06 18:05:21.618923+00	30.9	29.7	770871	770871
6b37ca9d-8ece-4f4a-9577-059326b71450	2026-01-06 18:05:50.409446+00	36.6	29.6	5315544	5315544
c7e9dfce-ca11-47cd-8ee8-a44d3fb3d420	2026-01-06 18:06:02.125313+00	54.9	29.9	913644	913644
669f6ad4-be77-4c23-a421-493af98fede0	2026-01-06 18:06:22.331887+00	44.9	29.7	5267793	5267793
fd9aa392-855d-40c6-be6a-03f083460c7f	2026-01-06 18:06:51.967499+00	68.5	29.7	1281561	1281561
6aa457c1-8ca8-4279-9e35-e73ca4240871	2026-01-06 18:07:22.658005+00	36	29.7	3733085	3733085
ae2a9040-fa11-4e34-adfc-5922dbc70e0c	2026-01-06 18:27:52.155861+00	71.5	30	1791229	1791229
acb8c46b-d0a8-46e7-968d-2f8914f0b2cc	2026-01-06 18:31:22.666026+00	41.3	29.8	5940365	5940365
c77aafd7-6651-4a1b-bbcb-a4afe9a75524	2026-01-06 18:31:25.951017+00	53.3	29.7	3952754	3952754
a4544c25-a00c-4e3a-8d4b-1e30c1bfdb7e	2026-01-06 18:34:22.636138+00	47.5	29.8	756330	756330
0d7b14a4-1ac7-4616-b936-601290fd79e3	2026-01-06 18:34:50.56583+00	40.8	29.8	4051682	4051682
a618a6dc-0c3f-4119-af2d-5e780a013258	2026-01-06 18:52:44.25475+00	39.9	29.8	4055581	104737
93a40ffb-27ea-40b8-a6d1-ccff90d6eaaa	2026-01-06 19:18:44.638285+00	37.7	30	3723044	91512
25b2fb50-a8d9-43df-bc8b-287dbb7322a4	2026-01-06 19:44:44.969696+00	40.7	29.9	4226102	117210
7aaee64d-340c-4459-ba43-3c2c254f8ec0	2026-01-06 20:06:50.55953+00	37	30	3928473	3928473
874530e0-0f84-4ace-a165-aceefcb0c6d4	2026-01-06 20:08:21.598049+00	30.9	30	5801259	5801259
7fb4db1d-8af9-4cdd-b075-9975da11e57d	2026-01-06 20:09:21.536886+00	31.6	29.9	1843595	1843595
cb9e542f-39b7-4acb-9b56-b1622a973b2a	2026-01-06 20:09:50.672777+00	36.5	30.1	3774344	3774344
4111d284-b94c-4286-a1e3-63ba251218af	2026-01-06 20:10:02.110831+00	44.1	30	2545429	2545429
5d41c88e-2f2e-40c5-bf1a-711851a93963	2026-01-06 20:10:22.517631+00	44.1	30	4318216	4318216
42981ec7-19ae-479d-b4b4-2d7abf4eb4d4	2026-01-06 20:10:50.537449+00	41.9	30	3395515	3395515
94fa6f3c-7a46-4320-8522-d31d29266f01	2026-01-06 20:11:50.550125+00	42.8	30	5596496	5596496
f08ce723-a50e-409f-b3de-ed748a118d0b	2026-01-06 20:12:52.056336+00	40.1	30.1	2883318	2883318
4225ff00-c634-49ce-a6f4-0d57a2c1e002	2026-01-06 20:13:02.127534+00	44.8	30.1	4213796	4213796
9f9226eb-2666-46ca-b460-2e69157713ba	2026-01-06 20:14:22.695503+00	42.6	30	5306977	5306977
2e832b76-e33b-46a2-9e90-2edd187e91a4	2026-01-06 20:15:02.142885+00	44.9	30	2429940	2429940
5f0437a2-04aa-428e-b0e5-e52d86ed9aae	2026-01-06 20:15:22.361578+00	45.1	30.1	904428	904428
4f855632-4ca6-41b6-8d80-7e3582f7e1a6	2026-01-06 20:15:50.562731+00	44	30	4949156	4949156
ce0082de-5157-4edf-929f-54519dfbd798	2026-01-06 20:16:21.568356+00	29.2	30.2	3299490	3299490
cb0006b9-5bfd-4af5-9769-a8d0f14daa47	2026-01-06 20:16:50.483682+00	37.5	30	1295079	1295079
1f0dba0c-6cd0-411d-8193-0d7dd94b680e	2026-01-06 20:18:02.09778+00	52.2	30.1	334298	334298
7bc5a81a-8025-4618-912e-39abe6568ef7	2026-01-06 20:18:50.592756+00	36.2	30	1093665	1093665
061139d7-e508-46a4-883d-515632ee9489	2026-01-06 20:19:02.121264+00	49.4	30.1	1237442	1237442
f6a2f3d8-dfdf-48da-a7b5-259503441f3f	2026-01-06 20:20:21.566027+00	34.2	30	3257375	3257375
8fea6b4b-ac56-4386-bed3-44a8c0c6b8e6	2026-01-06 20:20:25.916706+00	52.3	29.9	3777910	3777910
1fae5385-6bf0-4061-bf47-331c6555e348	2026-01-06 20:20:50.412125+00	35.8	30	4918959	4918959
e655881f-4753-42d4-9b70-c540e6a52443	2026-01-06 20:21:02.103794+00	42.6	30.1	5170803	5170803
9187f655-320a-4ecf-a2e6-e5d6075b506a	2026-01-06 20:21:21.531305+00	35.5	30	1056154	1056154
b01a1880-f214-4107-b97e-ed1b1426c53c	2026-01-06 20:21:22.685737+00	49.6	30	3972773	3972773
3345ac6a-95dc-44ea-921f-8f8fb70853d5	2026-01-06 20:21:50.58288+00	39.1	30	697544	697544
19aec9a3-cb46-4b44-b52e-20d624319d23	2026-01-06 20:21:52.11642+00	74.7	30	3427229	3427229
a8387804-5b80-497b-9424-39d35dae40c8	2026-01-06 20:22:22.593161+00	44.3	30	5119833	5119833
0c193557-91e5-4df7-8674-89cfe0f482dd	2026-01-06 20:22:50.39966+00	39.3	30.1	2556600	2556600
dce5e000-9e5a-4f4d-8026-c59e7474024b	2026-01-06 20:22:51.603549+00	41.6	30.1	3366596	3366596
e87fb602-68fa-41cb-a7dd-cedc1acdffed	2026-01-06 20:23:50.656599+00	42.4	30.1	3568225	3568225
1fec8a49-fff9-4b9f-93b7-f2798b4f8b11	2026-01-06 20:24:22.761618+00	42.5	30.3	6020336	6020336
4aa4736c-4a33-45f7-aabb-790049c76053	2026-01-06 20:25:25.906066+00	49.5	30.2	2545897	2545897
9d8973bf-ec97-4bd6-8ed3-990b446503ca	2026-01-06 20:26:51.808432+00	44.4	30.1	4561270	4561270
b5566a0a-6b80-4c61-964c-c3e3ccfabe10	2026-01-06 20:28:22.712179+00	38	30.1	4964273	4964273
de63f91d-ef15-4e43-8422-4363702c4f28	2026-01-06 20:30:45.627785+00	39.8	30.1	4279058	106960
98c7ee28-6286-429c-ba3f-cee62b67ee39	2026-01-06 20:48:45.903008+00	39.1	30.2	7688630	225738
52667470-8b32-4edc-b415-46fa0e976957	2026-01-06 21:16:46.283583+00	3.9	21.5	1412	301
9de1d065-f4ea-47ca-844e-fdf09aa08557	2026-01-06 21:45:46.62854+00	4.1	21.5	1227	189
5cf013cf-48f9-4221-a201-39ed880db2af	2026-01-06 22:14:46.996084+00	3.8	21.4	1422	299
c65728bf-799a-4990-86e2-10a8cf0a6d00	2026-01-06 22:43:47.359897+00	3.9	21.3	1326	180
e0cc3a0a-4e7a-449f-9d35-45365f8ecb4b	2026-01-06 23:12:47.668708+00	2.8	21.5	1805	312
e7bc7847-adcb-4f40-9ec0-60a230595bcd	2026-01-06 23:41:48.020108+00	3	21.4	1855	323
d4906168-f25c-4a20-a695-9766ad51b3e4	2026-01-07 00:10:48.387721+00	1	10.2	1579	13
84ff7daf-7d21-4639-9f2e-939c69c8fbd0	2026-01-07 00:39:48.794476+00	0.9	10.2	1432	22
089b8071-e200-476a-bf51-c8165ace9998	2026-01-07 01:08:49.19302+00	0.9	10.2	1642	18
e84dc1bf-4429-4d0c-b899-32a33f42d6b7	2026-01-07 01:37:49.597358+00	1	10.1	1679	19
7c603e84-52cc-4f7e-96fa-a3b5fc48ada2	2026-01-07 02:00:49.90016+00	3.9	11	65775	52671
c4e71119-b6e2-4cf3-a877-9a0eeec9db46	2026-01-07 02:20:00.805066+00	2.7	10.9	425457	425457
e6f4bf06-9d4b-4074-8929-3e3e2f82269c	2026-01-07 02:21:00.757569+00	2.3	11	516769	516769
130140c5-bbbd-4940-b2f5-c45d6bda5113	2026-01-07 02:22:00.220232+00	2.7	10.9	12026	12026
b6b0b0f9-1b44-4d42-9c81-3b68ccafd457	2026-01-07 02:22:00.971865+00	2.7	10.9	550966	550966
429b2631-bfd3-42e2-8efa-de0a9a8a4876	2026-01-07 02:23:00.232716+00	5.5	11	644979	644979
db61cb5e-fa43-4559-b3bf-168a66e3b45b	2026-01-07 02:23:01.095719+00	5.5	11	426654	426654
17e80cf6-1b6e-4418-b5e1-8846f0c983b6	2026-01-07 02:24:00.763242+00	2.8	11	491490	491490
903cdccf-ef4c-483e-b265-e43bd1df4d30	2026-01-07 02:25:01.03152+00	3.7	11.1	191669	191669
6d686746-8638-428b-93a2-da5f7553fe8d	2026-01-07 02:26:01.13304+00	2.5	11.1	719130	719130
ef8564fb-fbcc-46dc-930a-aca2cf45803f	2026-01-07 02:27:00.914333+00	5	11.1	595374	595374
657fb961-e12c-4813-9850-159c011dcabb	2026-01-07 02:27:01.116804+00	5	11.1	502817	502817
8de59948-ba4a-4d32-8c75-1ade45720a22	2026-01-07 02:37:50.366525+00	1.5	11	25903	14265
97dcd5d8-9f26-4453-ba74-a5e0e9af82da	2026-01-07 02:56:00.593651+00	2.8	11.1	377041	377041
efbc0803-6721-4ff2-a52d-3f17c6ece528	2026-01-07 02:56:00.836009+00	2.8	11.1	234735	234735
7aa95b0d-feab-41d3-a18e-b6c440bfb41f	2026-01-07 02:57:00.973242+00	3.1	10.9	508995	508995
8a088316-6079-41ba-b3f9-6cfcc5bed24f	2026-01-07 03:02:00.350545+00	2.8	11	217545	217545
c0fa9267-d237-460f-82d2-e3fca033b4e5	2026-01-07 03:02:00.888691+00	2.8	11	679295	679295
9c9e714f-6719-4a7c-9c4f-fa80fc53478a	2026-01-07 03:03:00.040374+00	2.1	11	8200	8200
959b68cc-5301-4f9e-850e-13c89afd6682	2026-01-07 03:03:00.698192+00	2.1	11	661720	661720
9f9bb0a8-b33f-45d1-83c4-0a0089fa3c60	2026-01-07 03:04:01.267829+00	2.5	11.1	585201	585201
17a24902-b4fc-4fe5-83b1-cee1f1ac5bc2	2026-01-07 03:05:01.260149+00	2.8	11	685067	685067
76703c39-da19-4022-be58-3e97ef8b6a47	2026-01-07 03:06:00.902699+00	3	11.1	533671	533671
57cf99ee-274f-4829-af48-fe9b1c050f5a	2026-01-07 03:06:01.067833+00	3	11.1	626252	626252
d2a58f90-078c-472b-a93f-3416c3715c2f	2026-01-07 03:07:00.829637+00	2.9	11	550264	550264
48c741eb-c947-4cc4-b6f3-263c87a42b05	2026-01-07 03:08:00.954228+00	3.7	11.1	588556	588556
f5fa5439-fdf0-4c38-8a0b-4c2c8f2248de	2026-01-06 16:48:50.733341+00	16.1	33	423895	423895
65896ee2-db15-4a04-938d-175ac65ba2e1	2026-01-06 16:49:02.033117+00	18.8	33	292207	292207
6767b4d1-59e2-42c5-9145-d25b0a909d09	2026-01-06 16:49:21.832466+00	19.1	25.3	530246	530246
ed9e233f-fcce-41c5-9b53-5ca47b5e2c74	2026-01-06 16:49:49.73086+00	8.5	25.3	693831	693831
ace7070b-8921-41c9-a62a-9a4cc929269e	2026-01-06 16:50:22.318891+00	17.7	25.3	222166	222166
6ff0b36c-9a24-4592-935d-7be166338ad8	2026-01-06 16:51:01.975097+00	35.2	32.9	716657	716657
9c6a516a-aa02-4d3b-b43b-a84729eff58b	2026-01-06 16:52:21.505078+00	31.8	28.2	3352148	3352148
fab84633-50b8-44af-8dc0-f2d1a9feb361	2026-01-06 16:53:51.999034+00	67.2	27.6	1791521	1791521
5a0de198-542f-4d8b-bc54-96fc3b041c71	2026-01-06 16:54:22.695412+00	40.9	27.8	2339960	2339960
8973845e-d1bb-4f6c-abba-6525ff2962b6	2026-01-06 16:54:25.931555+00	37.4	27.7	2353559	2353559
b7c206b5-91fe-44d0-982a-9a336578fad9	2026-01-06 16:55:02.10898+00	54	27.9	6126272	6126272
24d4bdb0-5fa4-48d6-a867-107e2f1469a8	2026-01-06 18:05:22.815978+00	47.7	29.7	5082200	5082200
38774cf4-fea7-4243-98f6-479bc8939f0c	2026-01-06 18:05:50.547193+00	36.6	29.6	3113236	3113236
fbc5b5d9-c88f-4aea-bc9d-d61216378fc0	2026-01-06 18:06:25.938413+00	42.4	29.7	5495020	5495020
e3095faa-f1ed-4a7c-9fca-718ea183f146	2026-01-06 18:07:50.466923+00	29.1	29.6	3004787	3004787
e48cce3e-5ca4-404f-9e6b-e56d68bc72cf	2026-01-06 18:28:22.856674+00	48.1	29.9	3657582	3657582
84dcb921-23dd-4c3d-8c55-561d4b5d48f7	2026-01-06 18:29:02.140342+00	49.2	29.8	4235384	4235384
a156db84-daa1-41fc-9ad6-c704020d5b5c	2026-01-06 18:29:21.54017+00	40.9	30	858964	858964
d66ecf36-e069-4c7e-a44e-0f90cc0f6f6f	2026-01-06 18:29:22.77961+00	36.3	29.9	252877	252877
e668bee5-fba5-4c0c-a6e5-a3358e58e6ef	2026-01-06 18:29:50.371277+00	37.7	29.6	4894510	4894510
f112a0e9-2c5b-4ae2-9e0f-cb9b856054f4	2026-01-06 18:29:51.763179+00	71	29.6	3412349	3412349
fa518272-2b28-406e-9859-d88d08f87232	2026-01-06 18:30:22.801084+00	43.2	29.6	2768641	2768641
016ee8b6-f588-4434-9abb-06515372dfd9	2026-01-06 18:30:50.497968+00	41	29.9	5271063	5271063
ba131423-e25d-4b7a-84b3-a7972938c29d	2026-01-06 18:31:50.650393+00	42.7	29.7	5661224	5661224
bb59648d-f452-4727-aada-285a7e6318e7	2026-01-06 18:31:51.95916+00	40.5	29.7	5789202	5789202
edec194b-cc23-4c16-9fd9-cacbb0998dbf	2026-01-06 18:32:21.583661+00	34.1	29.7	713803	713803
c42f2cae-b657-4674-a0e5-3a19bde62607	2026-01-06 18:32:50.597052+00	37.7	29.8	6201508	6201508
1f08cc50-e4a2-402d-bb37-9eed519e30fe	2026-01-06 18:32:52.093253+00	70.3	29.7	338905	338905
54e8031f-2793-4820-8649-5737b6439017	2026-01-06 18:33:02.116636+00	50.3	29.9	4390824	4390824
f6c2c204-1d99-4a7d-989b-f9182f027202	2026-01-06 18:33:22.648888+00	40.5	29.9	332154	332154
b0708451-67d1-45ae-b121-392136f446bc	2026-01-06 18:34:22.231714+00	47.5	29.8	591306	591306
91b5cec7-f67b-49ab-81ff-0ff32402be39	2026-01-06 18:34:25.935245+00	43.5	29.8	2478946	2478946
9c344921-3d9c-4bb6-979e-d12cb5f73cfa	2026-01-06 18:53:44.26269+00	37.5	29.8	3601535	94181
fe5ba330-da55-4b08-a407-ccb731f6452e	2026-01-06 19:19:44.640698+00	39	29.9	4416279	111972
bc675405-aa44-4849-9da1-4bacfafabfa0	2026-01-06 19:45:44.972487+00	40.3	29.9	4594045	121069
59a041de-c9a9-4b28-994b-94efdd4966cf	2026-01-06 20:07:45.324713+00	43.5	30	3971167	98742
7a0642dd-e38d-4d67-bf5d-f1c949cd2b98	2026-01-06 20:31:45.672377+00	36.3	30	4075491	106607
d26d7201-f98d-456c-86a3-ffccc56a7d81	2026-01-06 20:49:45.924367+00	46.3	29.8	3799448	93549
7d3a4475-4795-4d4c-a009-932caab058d5	2026-01-06 21:17:46.342434+00	4.1	21.5	1537	311
cc9a2a6d-1190-4b04-bbf6-8d695da92085	2026-01-06 21:46:46.666388+00	3.8	21.6	1353	193
8f0feb67-1971-47a9-87d0-93b51d61dbab	2026-01-06 22:15:46.986037+00	4.1	21.6	1418	282
9763b97a-0d90-41ab-a3d6-ed2d016787fa	2026-01-06 22:44:47.334875+00	3.9	21.4	1230	177
42bb84a9-454f-413a-bc8a-d7e90c31618d	2026-01-06 23:13:47.688907+00	3	21.5	1476	302
59eb2ced-e060-4196-a7a5-71989d3a57b8	2026-01-06 23:42:48.064046+00	2.7	21.5	1507	347
ba30ae78-a98f-407e-b81a-2a3959841e42	2026-01-07 00:11:48.421584+00	2.9	10.1	1534	22
55608aba-12a7-45b3-94d5-24d4dafdbd1f	2026-01-07 00:40:48.7903+00	1	10.2	1297	14
b49675c9-a3e0-4fff-acc4-3b340743c713	2026-01-07 01:09:49.211942+00	1	10.1	1925	18
bedc149c-5103-4741-8fe6-73ee4a2ee893	2026-01-07 01:38:49.615779+00	0.9	10.3	1580	22
8a17a08e-7a6a-4e35-a645-79c9481560c6	2026-01-07 02:01:49.935206+00	5.5	11	49882	83557
893862c7-dd72-433f-a63c-4f5a2e80aba0	2026-01-07 02:20:00.819547+00	2.7	10.9	645198	645198
626bb73f-0b6a-4eab-8680-495af75d4de5	2026-01-07 02:21:00.792266+00	2.3	11	633495	633495
906a02f2-731b-4f9f-b415-464e0ad7f342	2026-01-07 02:22:00.900853+00	2.7	10.9	419575	419575
4a363cda-241a-43de-90b5-37e9ba1ac1e5	2026-01-07 02:22:01.085991+00	2.7	10.9	547835	547835
1b6f2cc9-7d74-4950-afbc-7f1ed827f35a	2026-01-07 02:23:01.084993+00	5.5	11	500249	500249
f8231665-4174-48dd-b065-5053043ceb9b	2026-01-07 02:24:00.653987+00	2.8	11	646024	646024
1c7037ff-da2f-4abd-9a43-46e31247630d	2026-01-07 02:24:00.860029+00	2.8	11	809698	809698
ad308443-caf2-4d64-80fd-11638474fb51	2026-01-07 02:25:01.073631+00	3.7	11.1	453329	453329
69ccf4a0-0a2f-4210-9620-5533183eb8ad	2026-01-07 02:26:00.133532+00	2.5	11.1	7773	7773
f0bde6ea-b9bd-482e-8117-ba6dc5810896	2026-01-07 02:26:01.1061+00	2.5	11.1	742392	742392
84beea91-592d-4fce-a3a2-d959d12cddaa	2026-01-07 02:27:00.198078+00	5	11.1	845378	845378
54b08425-2234-4d26-991a-75ded3364dc2	2026-01-07 02:27:00.934599+00	5	11.1	412969	412969
8163e5b5-a7a9-450d-b965-d07b43428ce0	2026-01-07 02:38:50.381212+00	1.5	10.9	25869	15392
9e88e030-2368-4a37-93e4-3f7856d1c36b	2026-01-07 02:56:00.635882+00	2.8	11.1	700170	700170
216639d4-ccf9-46bc-aa74-be751596bb13	2026-01-07 02:57:00.026599+00	3.1	10.9	7781	7781
cac44eaf-b187-4b2f-a8e4-fab849cdde73	2026-01-07 02:57:00.887866+00	3.1	10.9	471015	471015
e1a4fbdb-c44d-41cf-b10b-048028fe43dd	2026-01-07 02:58:01.096628+00	2.4	11	318971	318971
139047a1-2d04-486f-9fad-7ae3dd37b547	2026-01-07 03:02:50.69381+00	2.6	11.1	18700	10908
a1c430cb-c45e-461d-88f1-94c20f777deb	2026-01-07 03:14:50.846182+00	4.5	10.9	18662	12522
23b0eb2a-0fbd-4cdd-a564-c60f80e81d0e	2026-01-07 03:23:50.982726+00	2.5	11.1	17725	35508
87980246-9527-4e59-874c-fd6ce0991566	2026-01-07 03:30:00.776951+00	2.8	11	645652	645652
464fa215-bb1e-4ec2-9a17-0874fb51b579	2026-01-07 03:31:00.913086+00	2.5	11.1	532559	532559
cd5567d0-8605-4869-a525-0aad125c7751	2026-01-07 03:32:00.820247+00	3.3	11.1	721473	721473
b3048535-8c67-467f-a65b-a36cbea210d8	2026-01-07 03:33:01.01133+00	11	11.3	434851	434851
7ae055df-3222-40a3-902b-10193456dff0	2026-01-07 03:33:01.262773+00	11	11.3	507062	507062
ed40f985-431e-4788-a0e7-b15dea2c2f8f	2026-01-07 03:34:00.090966+00	3	11.1	7962	7962
a7cd1305-65e5-4bee-8913-843047f76af7	2026-01-07 03:34:00.695641+00	3	11.1	734749	734749
e08c9022-c860-425e-8f99-c295f8488823	2026-01-07 03:35:01.023533+00	3.3	11.1	526962	526962
4c1b1728-d146-4f27-b662-3e1bc6ea6bfc	2026-01-07 03:35:01.297588+00	3.3	11.1	447252	447252
ddb8dc75-10fb-40ed-bf8a-63b81b696b46	2026-01-07 03:36:00.822837+00	2.5	11.1	579662	579662
5765b2f9-ef08-4452-95fb-1542793f649e	2026-01-07 03:37:00.840205+00	2.6	11	500882	500882
02b2e7ad-44f0-4e6c-a3ee-01b2dbe1d8b5	2026-01-07 03:37:51.152979+00	3.6	11.1	21081	39500
f6351526-0bc3-489b-b596-868a51b8f2e5	2026-01-07 03:38:00.759934+00	3	11	563111	563111
f4de0f06-3c7d-4d78-9623-12a2355c7d60	2026-01-07 03:39:01.067002+00	2.5	11.1	269322	269322
87a38cb6-0716-4837-b544-0f765e60f51d	2026-01-07 03:40:00.63934+00	2.7	11	831865	831865
3c8124cf-7ae9-4050-a0a2-6a3b4a63e5c1	2026-01-07 03:40:00.813103+00	2.7	11	654388	654388
f68b4f88-f001-4b4d-9fcc-f370ddb3c149	2026-01-07 03:41:00.718784+00	0	11.1	893218	893218
3adc92ee-3f71-4a8c-9a09-78431e14d364	2026-01-07 03:41:00.872396+00	0	11.1	649943	649943
3f4a33b8-cd8e-487e-a804-8b8310417ebb	2026-01-07 03:42:00.690525+00	2.3	11.1	613161	613161
2b8ab753-a894-4f80-beb1-82cfaa02de4a	2026-01-07 03:42:00.94067+00	2.3	11.1	553372	553372
a96e0e70-0834-4dc5-8c27-e95eb584c588	2026-01-07 03:43:01.089953+00	3.2	11	334529	334529
7215bc13-cf6c-44cf-ab37-d3bd8904c7aa	2026-01-07 03:44:00.960138+00	3.1	11	528434	528434
1a685be2-55a3-475e-a6c4-a958d1149dd8	2026-01-07 03:44:51.256458+00	5.4	11	13497	9297
57e30de3-cf30-4a7c-b677-22949bc96b81	2026-01-07 03:45:00.802514+00	2.8	11	742896	742896
1384fcb0-c7d3-415b-9d1e-d419ab3dace5	2026-01-07 03:45:01.056836+00	2.8	11	562996	562996
3b95923e-d614-4e15-b462-c330cea443c7	2026-01-07 03:47:51.295809+00	3	11	12982	9568
4237d063-87f6-49a9-98d1-cf6689e78da2	2026-01-07 03:55:51.394013+00	1.6	11.1	16897	13144
4258166b-8260-4b7e-bb56-265794d080e9	2026-01-07 03:59:00.78173+00	2.7	11	757911	757911
c6d6a7a5-5a42-4eb3-9cdf-e69244746169	2026-01-06 16:49:21.355285+00	9.5	25.3	957042	957042
66713e31-0bee-4649-99ee-339b5f1ce53e	2026-01-06 16:49:22.164073+00	19.1	25.3	588716	588716
c3d71729-158d-4659-9a9c-93730edeff17	2026-01-06 16:49:42.390956+00	14.6	25.3	44688	23516
dec23343-cb34-4d2b-859b-cd6a362c69c6	2026-01-06 16:49:49.865279+00	8.5	25.3	941362	941362
1722164e-d50e-4323-ab76-30951771fab0	2026-01-06 16:50:21.364495+00	8.8	25.3	696965	696965
04186fac-7e5f-4cf6-80d7-fb77f03639db	2026-01-06 16:50:49.747005+00	14.6	29.3	413235	413235
b686897a-582c-4477-81df-b44879a26f81	2026-01-06 16:51:51.750168+00	70.2	29.1	347140	347140
0c93003b-4713-4f57-89d2-4f627d9c7033	2026-01-06 16:52:22.44966+00	50	28.1	1399794	1399794
b2d3e59c-202e-4c90-90e0-415851043fde	2026-01-06 16:53:22.704764+00	45	27.7	5320354	5320354
07319cee-333a-4db0-8335-8066c2982c56	2026-01-06 16:54:50.396054+00	32.5	27.8	3049109	3049109
58f5772c-7d96-483a-8ff7-e016c0651e6e	2026-01-06 18:05:22.914559+00	47.7	29.7	231419	231419
2d19854b-3578-43fd-8b2b-4b3157d0449a	2026-01-06 18:05:51.792283+00	38.9	29.6	517281	517281
2f7eabd3-fb9c-44e1-bbfd-24ed151822bd	2026-01-06 18:06:21.576733+00	30.9	29.7	4920448	4920448
fed34733-eb37-4d39-bf7b-f444e4a45630	2026-01-06 18:06:22.734049+00	44.9	29.7	5754901	5754901
f868ca91-2854-4ff8-bf90-61f434174836	2026-01-06 18:06:50.60323+00	38.2	29.7	3712392	3712392
256926be-4fb5-4fe6-984e-cb43a2263e9d	2026-01-06 18:28:43.89689+00	41.2	29.8	3786742	102197
e97ed66e-9e66-498c-b252-2ed59d97e198	2026-01-06 18:54:44.263551+00	57.3	29.6	4278227	110530
af0728b6-cea9-4ad6-a24e-69c24cd58910	2026-01-06 19:20:44.631338+00	42.7	29.9	4180585	109137
cb0a02f6-fb75-4dd9-8496-720b924e62b6	2026-01-06 19:46:45.021193+00	34.2	30	3898271	102007
76b1f645-834d-478a-94bb-1dae065f26ab	2026-01-06 20:08:45.3302+00	39.8	30	4187876	107757
06b11774-b1a5-45b6-84d7-0d0bccf07268	2026-01-06 20:32:45.692399+00	39.8	30	3975802	103268
99a013e4-6e70-44d4-ba23-b077637c2b7f	2026-01-06 20:50:45.918251+00	42.1	29.9	6085183	185261
a7333edd-ee87-45c8-b536-d1e5595f2c53	2026-01-06 21:18:46.365448+00	4	21.5	1770	310
c5e15d11-37b7-4b19-b1a7-9c78c1368d00	2026-01-06 21:47:46.672802+00	3.9	21.5	1577	188
ce5b5852-0672-42c2-b8d1-19e8a94ebea9	2026-01-06 22:16:47.040692+00	3.8	21.5	1459	275
c57ad82a-fd25-4722-8b77-0e496ccfed6f	2026-01-06 22:45:47.327113+00	4.2	21.5	1230	179
494060c4-f64c-4448-96ee-1406e5fecae3	2026-01-06 23:14:47.737838+00	3	21.4	1455	311
5657cd2f-e017-4ed6-ba53-3a457a5a7eff	2026-01-06 23:43:48.084431+00	2.9	21.5	1667	341
51e6ae36-18a0-4c37-9fde-e6c986eb5563	2026-01-07 00:12:48.464744+00	0.9	10.1	1162	28
a09faa5c-a907-47b8-8517-b99fda6f4b88	2026-01-07 00:41:48.820693+00	0.9	10.1	982	18
47267558-8764-4667-b89b-a515f64216a7	2026-01-07 01:10:49.206988+00	1	10.2	1122	20
1bac5050-73ed-40eb-8c70-b6f4f81d52a4	2026-01-07 01:39:49.633942+00	0.9	10.2	1538	22
6d96e017-fc34-45ea-a6a4-35341be3ac5d	2026-01-07 02:02:49.91+00	6.2	11	46288	44295
10618b7c-c1f7-4d6b-b73d-7fb1e10f64d2	2026-01-07 02:20:00.859734+00	2.7	10.9	775143	775143
804a6a36-6d84-4ab9-8be9-13751a61ae18	2026-01-07 02:21:00.765238+00	2.3	11	620871	620871
fd996c0b-7c61-49ec-943f-9499c61baae9	2026-01-07 02:22:00.941495+00	2.7	10.9	520693	520693
1a512cc2-8979-42a8-b7fa-6bbcc743afe8	2026-01-07 02:23:01.147358+00	5.5	11	617398	617398
cd39a08e-e1c0-4c8c-a446-1f71c4f34a54	2026-01-07 02:24:00.777778+00	2.8	11	593003	593003
bc7cb98d-c8d3-4406-ab5d-514abb08eab0	2026-01-07 02:25:00.119766+00	3.7	11.1	8028	8028
520c4301-6d70-4367-8f27-db6e119bb908	2026-01-07 02:25:00.272568+00	3.7	11.1	679560	679560
71ad3a21-b077-4e74-a7b0-41d1397d2dba	2026-01-07 02:25:01.04394+00	3.7	11.1	284558	284558
c373616b-2cff-433d-b74b-748257c4096c	2026-01-07 02:26:00.514684+00	2.5	11.1	117852	117852
42426ec3-f91f-411e-a23f-1fa3fd5caeac	2026-01-07 02:26:01.097605+00	2.5	11.1	606836	606836
00392a90-68c4-484c-9c50-2adf6764e15e	2026-01-07 02:27:01.013303+00	5	11.1	479006	479006
12f588bb-0398-4053-89b0-fa2c24b64ae1	2026-01-07 02:39:50.400801+00	1.6	11	22175	16389
9d9917ed-93ce-4a89-9003-c2a093035e2d	2026-01-07 02:56:50.601695+00	2	11	20294	26285
364d02fc-1fc3-47ae-9497-daf9feeceba5	2026-01-07 03:03:50.707222+00	4.9	11.1	17116	12778
bb8b3428-0601-432d-9999-62f90169be08	2026-01-07 03:15:50.847856+00	3.1	11	16662	10228
afefc5f8-0016-4349-95ee-13820e6bc15d	2026-01-07 03:24:50.99827+00	1.4	10.9	15785	19657
6fb42986-7514-4ba1-91da-0190a80de6c4	2026-01-07 03:30:51.074934+00	2.8	11	19967	9271
600bcc23-27eb-474e-9dbf-30ca0d7f9771	2026-01-07 03:38:51.17144+00	2.7	11	12966	7351
61b83927-80fa-42a7-9465-9817c6a8b828	2026-01-07 03:45:51.257918+00	3.2	11.1	14567	10227
68257d5d-fb68-40ab-8d37-4fc9e6cbdb1a	2026-01-07 03:48:51.315149+00	3.6	11.1	12519	7759
86297030-730a-40ab-849d-a6244dd6ab05	2026-01-07 03:56:51.401546+00	4.7	11	15253	9335
d5b8c206-e5bd-43b0-9466-0a167a1ccc38	2026-01-07 03:59:51.446873+00	2.4	11.1	12582	7783
308974de-711b-4626-a1b6-84d4a9592d69	2026-01-07 04:01:01.205978+00	3.2	11	393085	393085
53eef51b-8b77-471b-92e4-4d3772a3b32a	2026-01-07 04:02:51.471722+00	3.2	11.1	11489	6491
5f6ea2d0-760b-47c1-a1d1-c6fea43b9421	2026-01-07 04:05:51.500249+00	3.5	11	16868	25895
d78a59fc-8e97-4716-9f19-bf3598d80d3f	2026-01-07 04:07:51.541375+00	3	11.1	10207	7544
77a0a965-c1a4-4f72-a092-f68e2bfa2e9b	2026-01-07 04:08:01.124187+00	0	11.1	506356	506356
85f83087-d8f7-4f73-9fdb-e63297145094	2026-01-07 04:08:51.555349+00	6	11.2	11291	8135
50b10bd8-c32a-4ea3-aebd-1d269fa07913	2026-01-07 04:09:01.057948+00	2.6	11.2	719786	719786
1322d988-8f8e-439b-916e-5743d05848be	2026-01-07 04:09:01.076143+00	2.6	11.2	457899	457899
15ba4ef5-7f97-463f-859a-b21ebdb8a688	2026-01-07 04:09:01.171908+00	2.6	11.2	816607	816607
7bd6b075-69f6-46f4-9a29-e34e76ebed76	2026-01-07 04:09:51.568759+00	5.9	11.1	11953	6256
a8b29736-e7db-4409-9ccc-5c762eda4e89	2026-01-07 04:10:00.121314+00	5.6	11.1	10208	10208
8d078eeb-86a8-40a0-b815-fdd50ff7de43	2026-01-07 04:10:00.249636+00	5.6	11.1	662580	662580
fa4aa306-ab6f-4a03-8d96-25e59c9d3934	2026-01-07 04:10:00.753635+00	5.6	11.1	423975	423975
25cd21f7-ada2-4c33-8764-e6bc039d80e3	2026-01-07 04:10:00.792752+00	5.6	11.1	616606	616606
c4d9b4fd-21a2-4a22-a5c7-e3376d684883	2026-01-07 04:10:00.867722+00	5.6	11.1	603993	603993
ee793f3a-45ad-4747-91ba-0b2d84985582	2026-01-07 04:10:00.884551+00	5.6	11.1	344122	344122
36eba495-e263-45d3-9225-c0b31b097f8c	2026-01-07 04:10:00.893864+00	5.6	11.1	488848	488848
42ee63b6-8753-412d-82ab-d2814f3a311f	2026-01-07 04:10:00.905896+00	5.6	11.1	619998	619998
e82d9960-1b1b-4aab-ba26-1fc8a2c67bf3	2026-01-07 04:10:01.014561+00	5.6	11.1	388279	388279
75849ffd-4bb4-4929-b67f-543f8b9acb63	2026-01-07 04:10:51.564718+00	5.9	11.1	13054	7198
238bdc85-f738-4bbe-bb92-0480eb379a71	2026-01-07 04:11:00.154037+00	2.7	11.1	9431	9431
f1b1f08f-b792-40dc-b2f6-c79ae4af8f70	2026-01-07 04:11:00.297474+00	2.7	11.1	653515	653515
a72e59e6-0b6f-4312-851c-a1e8c4ac48f5	2026-01-07 04:11:00.754956+00	2.7	11.1	496394	496394
4bb8ea8d-40ee-4f67-b023-6620909b9715	2026-01-07 04:11:00.780725+00	2.7	11.1	616690	616690
051ca01b-73d0-49ba-acb4-533bc2f0e407	2026-01-07 04:11:00.803729+00	2.7	11.1	633894	633894
790a60f4-e6b2-4101-936b-fc5759401cfb	2026-01-07 04:11:00.819985+00	2.7	11.1	600328	600328
64360b4a-b64d-4384-ab96-52a64cd5e995	2026-01-07 04:11:00.827336+00	2.7	11.1	747790	747790
3427144d-a668-4a97-a859-46ffa26266aa	2026-01-07 04:11:00.838336+00	2.7	11.1	1018536	1018536
403957c4-d2dc-4d5a-8d8f-4bc44d5d1763	2026-01-07 04:11:00.936055+00	2.7	11.1	380250	380250
92248f31-91c9-40e3-adfd-0955f8ceb1a0	2026-01-07 04:11:51.588289+00	5.6	11.3	13271	8371
8592a139-20c6-4881-80f9-f36ed2304da7	2026-01-07 04:12:00.09386+00	3	11.2	11107	11107
d091fabb-1b99-40a1-996d-5e56ba567de3	2026-01-07 04:12:00.195829+00	3	11.2	775533	775533
e95f00fe-f0db-429c-9e5e-70f832f976b3	2026-01-07 04:12:00.935491+00	3	11.2	467916	467916
d5bf9e18-e0dc-43b1-a3b9-27a7950de0f5	2026-01-07 04:12:00.964059+00	3	11.2	439467	439467
e6278256-fe77-46cd-928f-bf0a94c4b056	2026-01-07 04:12:00.998059+00	3	11.2	551640	551640
db04dc9c-a5ea-4027-bfa0-f46486f82f7a	2026-01-07 04:12:01.002556+00	3	11.2	494678	494678
a84de0c6-7d30-42ec-b3bf-4c51b6e81373	2026-01-07 04:12:01.048472+00	3	11.2	438111	438111
0f3b1b88-99ef-4f3f-a875-75cd820ece7c	2026-01-07 04:12:01.063802+00	3	11.2	469123	469123
571afd42-12eb-4582-8a43-5b6b1cddfaca	2026-01-07 04:12:01.226382+00	3	11.2	409767	409767
92d0117d-8e85-494a-a56b-4561582a4f31	2026-01-07 04:12:51.601782+00	4.2	11.2	20147	8366
993b59af-e9c7-421b-b7b8-233a9ee7ab69	2026-01-07 04:13:00.063294+00	3	11.1	9982	9982
fb728f38-920b-4c1b-970d-775a1ff59dc5	2026-01-07 04:13:00.184175+00	3	11.1	774230	774230
55d38372-0424-4d8d-b5a8-8cded08f4fa6	2026-01-06 16:49:50.657042+00	8.5	25.3	336685	336685
e1c7032f-b95c-4ab8-a503-703b4b49c945	2026-01-06 16:50:01.990661+00	24.2	25.2	562058	562058
84d70db3-66b9-48f9-837f-da3e4192c89c	2026-01-06 16:52:02.032804+00	49.9	27.7	3751982	3751982
4bf6ec56-88cf-4fc2-9e38-7d77b87ad1bc	2026-01-06 16:52:22.393132+00	50	28.1	2705778	2705778
70a60923-dfdd-4177-8633-40c9c5bd4367	2026-01-06 16:53:50.633539+00	43.8	27.6	6459298	6459298
8c0dcf6c-4965-41b7-8563-5e8d234dead4	2026-01-06 16:54:02.091298+00	43.9	27.8	4224757	4224757
5448f72e-c248-4ee1-8886-a9c5d3035c0f	2026-01-06 18:05:25.947691+00	46.6	29.6	644395	644395
49505060-1e1e-4926-91bc-c9a25bacfa79	2026-01-06 18:06:22.662379+00	44.9	29.7	5556566	5556566
ed4a7f71-9e8b-46ef-892f-8aa06ff51d7b	2026-01-06 18:07:21.486262+00	31.5	29.6	2562573	2562573
4f065cb8-0cb4-4b4d-bbe1-1515d6512a07	2026-01-06 18:07:50.581626+00	29.1	29.6	466754	466754
066640aa-1a61-45e9-afe7-08f06e7d2756	2026-01-06 18:07:51.749756+00	39.9	29.6	145254	145254
b6e3c815-b9ad-430c-a5fb-7a5fa4da160d	2026-01-06 18:29:43.872622+00	40.5	29.8	4674383	125759
adfb9b80-bb1c-4d95-bdbe-eba8b59d031b	2026-01-06 18:55:44.253197+00	43.5	29.8	4094702	109720
67330be7-dbe8-4021-826f-156f8b7b86b2	2026-01-06 19:21:44.650051+00	38.6	29.9	4221909	111948
8d8702c6-d017-4540-a70a-5a72bfda8fcd	2026-01-06 19:47:45.015102+00	39.9	30	3714128	95551
3bcb2154-6cb5-444e-a203-3d22cd4ae8cb	2026-01-06 20:09:45.37315+00	40.3	30.1	3815665	96102
b3e949a2-1962-43ab-8eeb-9954a2848f43	2026-01-06 20:33:21.573943+00	32.9	30	4477100	4477100
14a1576e-4031-404d-bbe8-39e524eb2a3e	2026-01-06 20:33:22.362815+00	45.1	30.2	749923	749923
7af3ed3a-b61c-452d-9fa8-0f60af27aaf9	2026-01-06 20:33:50.541509+00	38	30	3677801	3677801
72dd1905-d5cb-4cd6-a9e9-fa8cfe744930	2026-01-06 20:34:22.301237+00	43.2	30.2	4534011	4534011
7d1b8be4-9e24-4f9a-9f94-c2cd66317353	2026-01-06 20:35:02.109753+00	45.9	30.2	3905041	3905041
5a2bc080-8a1d-44c4-ac97-a64e2dd3024b	2026-01-06 20:35:22.698911+00	43.4	30.1	5153242	5153242
cdec8f3b-2164-4d0c-bcbd-765feac40b0c	2026-01-06 20:36:22.477876+00	43.6	30.1	302885	302885
681b15f8-8be3-4293-979d-7d75d4aa1391	2026-01-06 20:51:22.692719+00	45.7	30.1	3289187	3289187
63aaa43d-1e22-44b8-985d-ae136d5a5d66	2026-01-06 20:52:22.73914+00	45	30.2	3459322	3459322
87fd033b-39ef-4d4c-98f9-3f2641c669d6	2026-01-06 20:53:02.146505+00	46.8	30.2	4160995	4160995
cab9f6ee-ff07-4a7c-8a33-4be5271a3942	2026-01-06 21:19:46.351618+00	3.9	21.5	1769	308
f86a87a7-affe-414a-a11e-b57ca8fce9ff	2026-01-06 21:48:46.687489+00	3.8	21.5	2063	193
526eb752-dfae-47d5-ada7-440bcb4587ac	2026-01-06 22:17:47.041155+00	4	21.5	1835	300
41cfa867-bcf0-4074-a134-c877b89a7896	2026-01-06 22:46:47.348565+00	3.8	21.5	1847	166
9cb1feca-c7e4-4900-b479-07f9e41d91ca	2026-01-06 23:15:47.719197+00	3.2	21.4	1596	307
916061eb-3466-481b-b13e-171c47cf9c9b	2026-01-06 23:44:48.09838+00	2.8	21.4	1532	321
5daf3d78-4f98-4b58-9f17-7cc8e2dccb91	2026-01-07 00:13:48.454926+00	0.9	10.1	1236	37
13ddbba0-ba58-4ed5-ac98-e6d486528396	2026-01-07 00:42:48.838097+00	0.9	10.2	1080	16
671792cd-3eb9-43fe-85b0-9531e4435e41	2026-01-07 01:11:49.238551+00	1	10.2	1274	31
c8167b2b-6168-4d6d-8e9f-5d030b94a62a	2026-01-07 01:40:49.624299+00	1	10.3	1232	19
eacd568d-5f93-49f3-b77a-92a617647ff7	2026-01-07 02:03:49.927276+00	5.1	10.9	62567	99049
cac440e7-3851-4e5c-9909-6fb0207fdd5d	2026-01-07 02:20:50.131714+00	4.4	10.9	32853	20305
7e79906d-b98b-4136-8c0a-2a1f164e2acd	2026-01-07 02:40:50.399782+00	3.5	10.9	25153	38160
cf3c076b-b38b-4a12-a33f-1bf657926adf	2026-01-07 02:57:00.232665+00	3.1	10.9	408525	408525
a82da531-c48b-4617-b609-121a7a04a085	2026-01-07 02:57:00.876852+00	3.1	10.9	445274	445274
194f5346-88c2-4157-b198-841d14f9a901	2026-01-07 02:58:01.119741+00	2.4	11	437503	437503
0f8fca28-a272-4380-854d-d6fc5aab2cb2	2026-01-07 02:59:01.121435+00	2.8	10.9	188240	188240
c3db6371-4801-44e4-ae44-3e1ef0c51dfd	2026-01-07 02:59:01.441971+00	2.8	10.9	420346	420346
e796cf9f-2f24-4a69-81e1-45bc6419e257	2026-01-07 03:00:00.808424+00	3	11	521338	521338
7adc1374-2dda-41f2-99a9-c4315858df9b	2026-01-07 03:04:50.713182+00	3	11.1	26374	59650
51e3d401-2601-4003-8928-8f6baf61e3bf	2026-01-07 03:16:00.796258+00	2.7	11.1	687234	687234
92a5a9aa-66a8-4401-9360-7db387b6dc91	2026-01-07 03:17:01.159636+00	4	11	655465	655465
08ba81f7-a616-4aff-aaeb-9c4489519f7b	2026-01-07 03:18:01.162103+00	3	11	418705	418705
5dafd184-ca83-455a-832b-496dc86c9892	2026-01-07 03:19:00.228786+00	3.8	11	609580	609580
815bec5f-c7b6-4f09-a8cc-54b94142a0bc	2026-01-07 03:19:00.652261+00	3.8	11	491447	491447
0a93ca36-ec2f-410b-b44a-5f8e120885fb	2026-01-07 03:20:00.825413+00	2.5	11.1	539074	539074
2d263e2d-194e-49dd-840c-dcc0731b2f8e	2026-01-07 03:21:00.979449+00	2.6	11	510335	510335
ff90abb3-82c7-4da2-9bf2-9baf81f6987f	2026-01-07 03:22:00.220678+00	2.8	11.1	782690	782690
af102226-1435-4f55-ba52-49f6bb4d53be	2026-01-07 03:22:00.706494+00	2.8	11.1	818989	818989
c5379bfa-bcda-474e-bd94-32a500255230	2026-01-07 03:23:00.291314+00	3.2	11	800037	800037
6800b223-fe3e-4d43-bc75-9a5dfc4a9cdd	2026-01-07 03:23:01.104998+00	3.2	11	496285	496285
ebc98eb1-821d-465c-b85e-97e7a783747e	2026-01-07 03:24:01.019153+00	2.5	11	490330	490330
6345bdd6-0e01-46b5-89fd-82582fdc7044	2026-01-07 03:25:00.240459+00	3.4	11.1	489344	489344
4ee9142b-5c99-4e11-a3cb-68dcde79dcc5	2026-01-07 03:25:00.945627+00	3.4	11.1	451572	451572
8d80f3db-ce8c-47a2-8899-7195b28bd7c2	2026-01-07 03:25:50.998494+00	5.3	11	16631	21104
55a80b24-42af-4540-882e-1065f2b79621	2026-01-07 03:26:00.728263+00	2.8	11	446180	446180
e61300ec-6b7e-410f-a945-ef4658dc4205	2026-01-07 03:26:00.900462+00	2.8	11	414138	414138
cbf0e15b-2140-439a-9724-fbc36351670e	2026-01-07 03:27:00.902225+00	2.6	11	610881	610881
2343f622-6375-45f9-87a7-6256a8cf2b2c	2026-01-07 03:27:01.050598+00	2.6	11	479170	479170
2eee7cff-01f1-4aa1-a5dc-b16121184865	2026-01-07 03:31:51.100667+00	3.2	11.1	18360	8486
1ac287c0-d34c-482d-96d4-3dd3e9807cf7	2026-01-07 03:39:51.184477+00	2.7	11	13719	16999
db43b8ed-3385-4f3a-8065-a914e21184ff	2026-01-07 03:46:00.068485+00	2.7	11	9291	9291
b51bd981-df02-418b-82f7-d5faf92a70c1	2026-01-07 03:46:00.363384+00	2.7	11	500701	500701
d239b0c4-c730-4c41-8653-d4d7113585a7	2026-01-07 03:46:01.079156+00	2.7	11	530349	530349
ab708718-2bb8-4c20-aea1-dc4fc57a7a44	2026-01-07 03:47:00.893657+00	3	11.1	419416	419416
f2c6f8fa-88e3-4536-8395-82f42063af7e	2026-01-07 03:47:01.084576+00	3	11.1	498090	498090
e636476d-7157-4535-bbe2-7e2e8e6602d3	2026-01-07 03:48:00.774253+00	4.3	11	597070	597070
ac4287a0-7814-428e-a4fc-643a978e2ddc	2026-01-07 03:49:00.915048+00	5.9	11.1	703692	703692
c39e0035-949d-4bec-abb1-f78f5f3b8c4b	2026-01-07 03:49:51.330811+00	3.1	11.1	12154	7856
8e616e1d-a5ff-4066-8ac4-b9a61e3a1914	2026-01-07 03:50:00.111329+00	2.8	11.1	10788	10788
03290a26-4a7b-4af7-8a73-826b4f6bedd0	2026-01-07 03:50:01.027944+00	2.8	11.1	592254	592254
88ed8ce7-3b3e-4f95-807a-9a716d954034	2026-01-07 03:51:00.987519+00	2.4	11.1	575444	575444
183a0e85-e04f-4078-809a-d26ad42d79ae	2026-01-07 03:52:00.875136+00	2.6	11.1	468789	468789
d87702a6-e17f-4db3-8427-d0a15184c31e	2026-01-07 03:53:01.005006+00	2.4	11.1	567332	567332
84803366-bf46-4008-a246-e2b95a485890	2026-01-07 03:54:01.043643+00	3.1	11	661967	661967
15142e1d-7d5b-4b2f-8a64-bb5a9a7c5985	2026-01-07 03:55:00.653581+00	2.4	11	632649	632649
ad21fe6b-c755-4112-8e12-03c3bc8adf41	2026-01-07 03:55:00.844531+00	2.4	11	495222	495222
25e13632-bfca-48c0-92df-a0ac7e05d74c	2026-01-07 03:56:00.947239+00	2.9	11.1	663136	663136
a3835a4c-bc39-42c8-91f3-0f1b7e439a53	2026-01-07 03:57:00.803684+00	3.6	11.1	672776	672776
deef4c57-fefe-474c-9dd6-4e067b468e31	2026-01-07 03:57:00.847916+00	3.6	11.1	671393	671393
34052825-1f36-498b-8d93-01b28e4df7bc	2026-01-07 03:58:00.663106+00	3.5	11.1	699707	699707
fc2842cb-5c93-422f-ab8d-5a0b92ed622d	2026-01-07 03:58:00.689145+00	3.5	11.1	699300	699300
d424afe8-027f-4e63-a82d-0b3574ceb29e	2026-01-07 03:58:00.753277+00	3.5	11.1	500089	500089
7c03f93e-2856-4b18-84ee-662ea13d804d	2026-01-07 03:59:00.767581+00	2.7	11	599072	599072
25aed49c-4d53-4aa2-ae7e-a3a9f8d06b0b	2026-01-07 03:59:00.830768+00	2.7	11	665303	665303
9eae6332-a53f-4f36-9b90-423dc5e4004b	2026-01-07 03:59:00.948534+00	2.7	11	556316	556316
a4a737ea-420a-4770-9c6d-ec4912498ea0	2026-01-07 04:00:00.097344+00	3.1	11	9082	9082
a108ef51-4d07-4901-be1d-063bad1c24b7	2026-01-07 04:00:00.689624+00	3.1	11	1086843	1086843
917bfc4f-ed79-4b2f-8c64-2bdb57c07244	2026-01-07 04:00:00.708524+00	3.1	11	521371	521371
3796bd04-28a1-4333-8091-5791c9747a8b	2026-01-07 04:00:00.725208+00	3.1	11	753887	753887
8ca1e24d-7953-44c8-9c19-485015cf6b08	2026-01-07 04:00:00.844768+00	3.1	11	331214	331214
707402dc-216e-4f4f-b0c5-abefcdea78a2	2026-01-06 16:50:21.829819+00	17.7	25.3	355155	355155
a48b763f-a0c4-4d29-ad7d-577e279518f3	2026-01-06 16:50:42.35887+00	7.3	25.3	54075	24250
b94ede5a-3411-4ee3-bf83-0efaf50b2de3	2026-01-06 16:50:49.533961+00	14.6	29.3	606511	606511
fbf15a64-da38-4594-913b-c23a868972a0	2026-01-06 16:51:21.363818+00	17.9	32.9	950587	950587
c84c7e54-34a2-4cec-8686-3f627fcad9ec	2026-01-06 16:51:22.238004+00	22.6	32.9	2345245	2345245
2170c14b-2338-462f-b1f9-987dc1636c10	2026-01-06 16:51:25.933744+00	27.6	29.4	2897212	2897212
ce3c4b78-15bf-4801-96bd-df56abdb8eed	2026-01-06 16:51:42.409526+00	36.9	28.4	4576100	139554
26c36a06-27c6-4d15-b272-29edf014033e	2026-01-06 16:51:50.362972+00	33.8	29.1	4268452	4268452
7a8027ff-325f-4683-bdfe-b4b024e4c35f	2026-01-06 16:52:42.412024+00	35.3	27.6	5374831	149328
65695c51-ca26-401b-ba56-4b5d25819eac	2026-01-06 16:52:50.567034+00	39.2	27.6	4701028	4701028
a1e589f6-0c00-4976-b71f-eaac84923bea	2026-01-06 16:53:02.138141+00	48.5	27.7	6462521	6462521
4a528b8e-2c02-4ca3-8827-67690ff2c3c4	2026-01-06 16:53:21.575705+00	32.1	27.7	2823831	2823831
ad864186-99ed-44d9-a094-9e83c456f74c	2026-01-06 16:53:22.590759+00	45	27.7	119388	119388
e25c4b06-b686-425d-86b7-4473163ca338	2026-01-06 16:53:42.437095+00	37.4	27.7	4482365	129475
1aa78da9-b88a-4459-a3ee-53060f848953	2026-01-06 16:54:22.76566+00	40.9	27.8	5844339	5844339
b85fff3f-dc6b-4028-a0c1-48da3e547b57	2026-01-06 16:54:42.438078+00	35.3	27.8	4208000	118817
377d749f-55bc-4df9-a6f3-f038c3b4ff51	2026-01-06 16:54:51.94738+00	44.3	27.8	4198145	4198145
14d35f29-3967-4c0b-a80f-b0c0213be366	2026-01-06 16:55:21.618707+00	35.7	29.2	4066843	4066843
6655ff84-a7ab-43f5-a2dc-d5897a0aa124	2026-01-06 16:55:22.358077+00	43.4	29.2	4477302	4477302
9bac35dd-2440-434d-99cf-37a72954df8e	2026-01-06 16:55:22.7093+00	43.4	29.2	4941798	4941798
fc66dfb9-361f-4939-8f25-0fbafaa1faab	2026-01-06 16:55:22.821186+00	43.4	29.2	269452	269452
115120d7-8c41-43f1-a579-040238d53e03	2026-01-06 16:55:25.899463+00	53.3	29.2	2310062	2310062
9ac8a414-5989-44d0-b557-efdb724f589f	2026-01-06 16:55:42.435116+00	29.3	29.2	4575311	136057
b4f6abbd-a012-40fd-9625-5922b88500d8	2026-01-06 16:55:50.650007+00	34	29.2	4226392	4226392
db7ade93-fbc3-481d-9f32-ab68525b6bd3	2026-01-06 16:55:50.737997+00	34	29.2	4835371	4835371
e483d00a-826b-4be3-b225-fcd0060a8311	2026-01-06 16:55:52.193791+00	40.4	29.2	302350	302350
57078ab4-fba3-4d3c-aa32-07c994324d4a	2026-01-06 16:56:02.103691+00	49.7	29.2	6009959	6009959
2076f5c2-1032-46d0-aa72-58426e192564	2026-01-06 16:56:21.583125+00	32.7	29.2	4487328	4487328
38d41bc9-1577-4c86-81c1-43c485217322	2026-01-06 16:56:22.314707+00	43.1	29.3	6153362	6153362
19268e2f-3528-4faa-88c6-c5a71d22c05f	2026-01-06 16:56:22.631303+00	43.1	29.3	5541330	5541330
ba414869-9fbb-43c0-9990-8f0e71d3a726	2026-01-06 16:56:22.749876+00	43.1	29.3	4350837	4350837
1e28945c-60f6-42db-b095-855ff05785d4	2026-01-06 16:56:25.928149+00	51.3	29.2	4055382	4055382
d17d6931-62a9-4f1a-a767-724040de969b	2026-01-06 16:56:42.461785+00	31.1	29.3	4312019	116297
1201ca58-cd8e-48de-9509-63bc1611ca98	2026-01-06 16:56:50.461441+00	34.2	29.2	648279	648279
fa209dc8-2ddf-4f47-9dbf-b5958d627603	2026-01-06 16:56:50.620046+00	34.2	29.2	5119871	5119871
0bb7b1d2-1867-44d7-bdd3-aac4fbcd8b23	2026-01-06 16:56:51.810062+00	41.7	29.2	1627131	1627131
dd9bdade-693e-4965-bb97-ed3c509199e6	2026-01-06 16:57:02.143801+00	43.1	29.3	333473	333473
ebbc141f-19fc-45f2-869e-2ed81fb1edb5	2026-01-06 16:57:21.512314+00	30.4	29.2	5345072	5345072
5cdfced3-768b-44e3-94ad-ebcdf161ba4c	2026-01-06 16:57:22.300494+00	42.6	29.3	4956005	4956005
03b35cbe-6a96-46fd-81b1-6f7f513b9fd3	2026-01-06 16:57:22.633739+00	42.6	29.3	1411850	1411850
78cf4e36-5064-494f-90a7-2e5fd1520f7a	2026-01-06 16:57:22.706734+00	42.6	29.3	5284436	5284436
1254a378-efc1-435e-b08b-e8acc006c741	2026-01-06 16:57:25.914783+00	43.2	29.3	1522847	1522847
1d5cde1e-d7b3-4d4b-a825-930427c0919e	2026-01-06 16:57:42.4806+00	33.7	29.4	4808024	134326
308b281f-9f2e-4fab-9e2c-31825a3899e6	2026-01-06 16:57:50.433763+00	33.6	29.3	806686	806686
4021d426-1e54-4cca-90e2-67b04ece8ef2	2026-01-06 16:57:50.557663+00	33.6	29.3	977081	977081
7c7d7fb4-bf04-4151-9119-67fa7f0a7476	2026-01-06 16:57:51.836398+00	44.8	29.3	256334	256334
19420be3-8b6c-443f-988f-8bdc4645a418	2026-01-06 16:58:02.091759+00	43.2	29.2	3794412	3794412
5b185108-1cf7-41cf-a547-a3efd588c5d7	2026-01-06 16:58:21.548554+00	33.6	29.3	3464771	3464771
13370321-bdce-4d7f-b210-0940afcf0c52	2026-01-06 16:58:22.255217+00	51.7	29.4	5594227	5594227
694bb9cc-d2ce-475f-95cc-ab448364f342	2026-01-06 16:58:22.665196+00	51.7	29.4	4115015	4115015
f4ae1b25-c411-4ec5-9631-18bf5e9b6251	2026-01-06 16:58:22.779182+00	51.7	29.4	4455829	4455829
d1d17066-ec6f-4b04-a7a7-dbeaadf2fa2d	2026-01-06 16:58:25.970275+00	45.1	29.3	2644065	2644065
a22240c1-8009-40fc-8e17-58921992e0c6	2026-01-06 16:58:42.533699+00	42.4	29.4	3944060	114169
bc974b94-682d-4d21-b2e1-89a03a44c2ad	2026-01-06 16:58:50.403887+00	37.3	29.3	5513701	5513701
dad1e360-4397-4ac5-8e55-a95758356d12	2026-01-06 16:58:50.562362+00	37.3	29.3	4642228	4642228
37ae8944-07e6-4127-b997-8767f1763e89	2026-01-06 16:58:51.779308+00	67.2	29.3	3914029	3914029
8a1d1630-e758-4074-95cf-72dbec192eb7	2026-01-06 16:59:02.135337+00	42.7	29.3	5902714	5902714
1653dba8-1bd5-423d-9805-273db4863957	2026-01-06 16:59:21.535203+00	32.4	29.2	3557929	3557929
2a925cce-1def-4923-8805-41c193c3e90a	2026-01-06 16:59:22.326159+00	42.5	29.3	4740758	4740758
ac018368-12cc-4f69-8a0e-c47727ecc2c8	2026-01-06 16:59:22.690295+00	42.5	29.3	3470599	3470599
bd651b11-1d45-46fc-983b-7b66a0b7b0ef	2026-01-06 16:59:22.782645+00	42.5	29.3	3302501	3302501
38d4dfa3-a31a-4dab-9c5f-7b89fbf7378e	2026-01-06 16:59:25.922944+00	42.8	29.3	4253974	4253974
54c62b17-7b0d-47d9-86f9-95b6e874680e	2026-01-06 16:59:42.502585+00	39.6	29.3	4759435	133290
54d7b7e4-8b53-4102-83c6-0ef356a63df6	2026-01-06 16:59:50.323397+00	31.4	29.3	3346034	3346034
abe3f447-5bd7-4d1b-9117-b586cecb0e98	2026-01-06 16:59:50.496193+00	31.4	29.3	4475277	4475277
59fcd36e-6ba5-427c-a60d-447cc41530d8	2026-01-06 16:59:52.030603+00	38.4	29.2	3417036	3417036
84d40f8b-eba6-491d-b3e0-397b08ea60d8	2026-01-06 17:00:02.102199+00	46.8	29.3	3520099	3520099
60e71439-d7a2-4149-bcc9-36941c9d0f98	2026-01-06 17:00:21.557034+00	30.6	29.3	4296102	4296102
4ef94ba7-d3f1-48ec-a1b3-57f89abfc888	2026-01-06 17:00:22.351039+00	43	29.3	5386073	5386073
bb61b430-a587-4419-bcdc-e99e041c80c8	2026-01-06 17:00:22.693221+00	43	29.3	3332719	3332719
614b8f2a-bec9-4084-871c-118638ff7d4a	2026-01-06 17:00:22.782306+00	43	29.3	1165278	1165278
38e08a04-ce9e-40c5-bb81-3ab4fbdf2711	2026-01-06 17:00:25.92808+00	52.1	29.3	535597	535597
c86fc126-2a42-4ce9-b5e6-19ca7e32a5f4	2026-01-06 17:00:42.515468+00	36.3	29.3	4265447	119908
575fc95b-f060-46c6-856c-83e16d8da0a6	2026-01-06 17:00:50.515936+00	34	29.3	4378382	4378382
a6c13f74-b5c4-496e-826b-6f182bfe97a8	2026-01-06 17:00:50.601028+00	34	29.3	4469245	4469245
50152de7-d90f-43a1-805d-a6a1d912ecb4	2026-01-06 17:00:52.013854+00	71.1	29.3	2532423	2532423
3c2c2750-c6cd-4e8c-b9e6-fdcaab0333cf	2026-01-06 17:01:02.105591+00	47	29.3	5540883	5540883
492f3658-d0ac-4e6b-9a64-3d57293735e8	2026-01-06 17:01:21.602783+00	31.4	29.3	2069494	2069494
2fba39b9-1992-4bc7-af10-1ceecefee087	2026-01-06 17:01:22.368363+00	44.8	29.3	3416960	3416960
99bf98db-327e-4a13-9ba0-51b0affbdb2c	2026-01-06 17:01:22.72368+00	44.8	29.3	4590845	4590845
8fd0c93d-c177-4e90-a798-969a43bc87d9	2026-01-06 17:01:22.802266+00	44.8	29.3	221179	221179
580fa27f-ee64-4be3-9cb2-8639399a18b3	2026-01-06 17:01:25.942583+00	51.6	29.3	2531151	2531151
67a6f2f1-7277-4c6c-835c-aa489cd43ff8	2026-01-06 17:01:42.525222+00	41.7	29.2	4197537	117339
7c062823-20e4-4885-8e7c-2fac89824a17	2026-01-06 17:01:50.379575+00	38.6	29.3	804399	804399
dce7f648-3b0d-4042-b204-eb8e24bb23fd	2026-01-06 17:01:50.548548+00	38.6	29.3	3373005	3373005
0bab2822-6756-41f1-8b62-94f24ae20cef	2026-01-06 17:01:51.678327+00	38	29.3	5211841	5211841
7d312bcb-ae8a-4e8b-a3ac-cf64ca8fd50f	2026-01-06 17:02:02.104299+00	47.9	29.3	4848781	4848781
30856b06-a544-4fe6-874b-b7109386b149	2026-01-06 17:02:21.581314+00	31.4	29.2	3214114	3214114
98f57fe0-cf9d-4498-9354-ce6aa55bd1ad	2026-01-06 17:02:22.33553+00	42	29.5	2537278	2537278
10221e40-04e9-43ab-afe3-c7df7ae7e34e	2026-01-06 17:02:22.655301+00	42	29.5	4541187	4541187
3750c418-9afe-46e7-82aa-255fb492741f	2026-01-06 17:02:22.743726+00	42	29.5	3720291	3720291
88d42afb-1c7f-4924-8714-50d4d087028a	2026-01-06 17:02:25.924078+00	42.9	29.3	3611944	3611944
0d8cf8c8-760f-477c-bdf5-a478caf0061a	2026-01-06 17:02:42.59243+00	56.2	29.3	3875524	112832
f6ac4c13-5dd1-4c85-97c4-215c576a8422	2026-01-06 17:02:50.333389+00	29.3	29.3	3262926	3262926
38eebca7-4a00-41ad-9cf2-222f5c40b696	2026-01-06 17:02:50.461387+00	29.3	29.3	881452	881452
5f78ef13-e92f-4640-9f8f-1dcd7a3fba40	2026-01-06 17:02:51.882916+00	38	29.2	4209383	4209383
3616cddf-6bb8-4898-9c69-27aa222da7e8	2026-01-06 17:03:02.039671+00	41.1	29.3	626842	626842
b86aa6ee-588b-41db-91e0-1ac995305bac	2026-01-06 17:03:21.48041+00	32.7	29.2	935668	935668
d0c92c3f-d246-494b-acc6-337637d59432	2026-01-06 17:04:22.277246+00	41.7	29.4	477410	477410
931488d1-cfce-4000-a434-6c787c1b6ace	2026-01-06 17:04:50.589212+00	37	29.3	3970979	3970979
9c5d7689-85fd-4126-bd32-e172e4470fb4	2026-01-06 17:04:51.77515+00	73.5	29.3	205638	205638
a0ad4a0b-644e-4683-a669-f6b1167a714b	2026-01-06 17:05:22.352442+00	35.9	29.2	6032096	6032096
b8e4305e-6a78-4aa3-9573-7ac4455ca4f3	2026-01-06 17:05:50.529167+00	37.5	29.5	3510339	3510339
dfa33e1d-4396-43a7-843c-98f785609d26	2026-01-06 17:06:22.302621+00	41	29.2	624172	624172
79b92c6f-ab86-4535-8091-f9badfa30caa	2026-01-06 17:06:25.942374+00	45.6	29.2	961896	961896
2e5582a2-f3c3-47f3-bcec-07be6c8c80ac	2026-01-06 18:05:43.505799+00	43.9	29.6	4284927	119321
adbedecf-8d23-44ad-9034-ca709093d1f7	2026-01-06 18:30:43.872894+00	40	29.8	3930772	104826
942bfe0d-46ad-4b19-b1da-a936b3dbe740	2026-01-06 18:56:44.301358+00	45	29.7	4051654	104365
9a66335d-1751-4b3f-842a-cebccd5985fc	2026-01-06 19:22:44.713604+00	51.4	30	4252854	107122
f945751b-0b19-4c94-8a50-7ec9318f2c93	2026-01-06 19:48:45.029533+00	41.4	30	3978293	104016
bce456e1-8198-484d-91db-be6a6580f2ac	2026-01-06 20:10:45.350472+00	46.1	30	4392862	113873
da5c280f-f8a9-402e-9117-35e30027f447	2026-01-06 20:33:45.720362+00	35.9	30	4020051	105690
0b6b1825-6ea2-4dec-8bca-adbc196896dc	2026-01-06 20:51:45.94495+00	38.6	29.9	4375751	140489
c9404013-7aa2-4451-956f-761c5fc3d3c4	2026-01-06 21:20:46.34094+00	3.9	21.6	1796	306
d9b3cdd7-af8b-4437-aece-29dc41752752	2026-01-06 21:49:46.746483+00	4	21.5	1582	197
3a3cba91-6c35-4444-ac10-d8f1d83e7b18	2026-01-06 22:18:47.040876+00	4	21.6	1771	296
dbbcfaf7-e0ec-4d35-aecd-3d4fe4585287	2026-01-06 22:47:47.394645+00	4.1	21.5	1601	188
e24bc009-269a-4273-8d35-c67cc21a4a53	2026-01-06 23:16:47.702554+00	2.7	21.4	1791	311
01b22a73-dd2f-4166-8498-5909e661d433	2026-01-06 23:45:48.076142+00	3.1	21.5	1510	295
7b31d257-b80d-462a-b32d-edc9df8ca9a6	2026-01-07 00:14:48.474484+00	0.9	10.2	1229	21
5a3ccdd1-4cf4-4821-8d9e-9de9b7c03b1b	2026-01-07 00:43:48.844789+00	0.9	10.2	1003	15
ce5ace95-1aa7-4c67-b9f0-29318162ebc0	2026-01-07 01:12:49.282309+00	0.9	10.2	1567	17
58096ab3-9253-425b-bff3-5e48b0245a67	2026-01-07 01:41:49.658415+00	0.9	10.2	1250	23
3f9eddbe-0c9a-4785-858a-0cbb12888acb	2026-01-07 02:04:49.972138+00	2.8	11	54086	128860
8976ff47-1553-4b83-ae3f-a2a156ea4e80	2026-01-07 02:21:50.144701+00	2.7	11	34285	24360
75282ba2-2269-4edd-8a79-6bdc0812dc5a	2026-01-07 02:41:50.428673+00	1.6	11.1	28507	69553
37abd176-dfe2-4e23-97e0-c5575be1bee4	2026-01-07 02:57:00.843199+00	3.1	10.9	473174	473174
59d8d27b-27da-4c0c-af7b-beaf4f427f0c	2026-01-07 02:58:01.08103+00	2.4	11	389386	389386
4c2b4a97-90d2-42aa-b012-ce36cdb8d898	2026-01-07 02:59:00.227229+00	2.8	10.9	783550	783550
7ea66d9c-ce88-40b8-b33a-c3cc3c740e4b	2026-01-07 02:59:01.140736+00	2.8	10.9	417702	417702
56c00336-b166-4a17-be53-6e3ecbb82295	2026-01-07 03:00:00.833056+00	3	11	641549	641549
e68bf29a-6119-4201-984c-be5b7713a6d7	2026-01-07 03:05:50.715555+00	2.9	11	22284	11737
7fc8ca1b-a8b3-4949-a578-b55ef31291b5	2026-01-07 03:16:00.892094+00	2.7	11.1	373300	373300
e88f62e6-7516-455e-bd49-3e26b0c203f6	2026-01-07 03:17:01.246029+00	4	11	387145	387145
af1b31d8-7cf2-46fb-a598-896438b72d13	2026-01-07 03:18:00.125836+00	3	11	8040	8040
7330a3f2-c970-4ba5-93ce-b4ff285839fc	2026-01-07 03:18:01.143434+00	3	11	425445	425445
3a25e231-f2f6-40a7-b3b9-6cd36fa2b673	2026-01-07 03:19:00.597221+00	3.8	11	897838	897838
06586a1f-d63d-426f-ba39-edbd2baad14d	2026-01-07 03:19:00.82521+00	3.8	11	911086	911086
689b5b38-bcbc-4b6c-97ba-eb7e6e601c51	2026-01-07 03:20:00.81155+00	2.5	11.1	557203	557203
32706dc8-c545-4c6e-adb5-a4ed70901031	2026-01-07 03:21:01.006919+00	2.6	11	533425	533425
ea3186b2-42f4-43c9-9412-3a8372bf7e22	2026-01-07 03:22:00.730597+00	2.8	11.1	740946	740946
d7adb259-c008-43dd-8f39-e951d056f93f	2026-01-07 03:23:01.22791+00	3.2	11	481897	481897
30ec3c81-29a6-4d59-9546-916b52749a52	2026-01-07 03:24:00.253137+00	2.5	11	692719	692719
dc33f1c9-49ec-420c-8bef-c811f8638cf4	2026-01-07 03:24:00.867764+00	2.5	11	596753	596753
382f830d-f0c3-4824-bf95-fa127f08d486	2026-01-07 03:25:00.920598+00	3.4	11.1	481573	481573
c3a7c701-e6c6-4ba4-9c03-4780dbce0b31	2026-01-07 03:25:01.105376+00	3.4	11.1	478079	478079
0cfb2f8e-c966-4f1d-b53a-b0098992c37d	2026-01-07 03:26:00.815756+00	2.8	11	641581	641581
c212cefe-ecb6-40d8-bc0e-9f0f2b91182e	2026-01-07 03:26:51.02454+00	3.8	11	20589	13953
2fd2b2ec-a028-40dd-936a-a4d4e1b2789b	2026-01-07 03:32:00.785814+00	3.3	11.1	466784	466784
a6d44546-72a4-4ab9-8964-d064afe8460b	2026-01-07 03:33:00.125117+00	11	11.3	8950	8950
80fcc215-3dbe-4509-a4e5-473e9021c572	2026-01-07 03:33:01.06693+00	11	11.3	657507	657507
c0f32aa3-07da-4fab-a9b2-42c4fe75b74a	2026-01-07 03:34:00.720517+00	3	11.1	686496	686496
23c1de0a-1a36-4ce6-9bf1-1748f0ac8d61	2026-01-07 03:35:01.174272+00	3.3	11.1	565488	565488
1aa74898-ae88-49c9-81d4-b2dbd9dc3265	2026-01-07 03:36:00.814687+00	2.5	11.1	658451	658451
021fc69f-4a24-40c8-bf12-049560bd476f	2026-01-07 03:37:00.981142+00	2.6	11	541494	541494
fb011e5d-094b-421d-be47-a2c0ef284c1f	2026-01-07 03:38:00.808456+00	3	11	582349	582349
60a32da2-fc9b-4646-aa85-9c5c901e3315	2026-01-07 03:39:01.093393+00	2.5	11.1	494745	494745
98a695fe-1418-4a17-a79d-95b3f14d7299	2026-01-07 03:40:00.065536+00	2.7	11	8048	8048
ca33f1bb-ef42-47e4-98f0-90602543a24e	2026-01-07 03:40:00.705588+00	2.7	11	654144	654144
057f8e7b-c6b5-4e4a-bb21-43aca81a7677	2026-01-07 03:40:51.186149+00	4.2	11.1	13808	10744
6bf0dc1f-ce44-4b33-8109-334ed29514a4	2026-01-07 03:41:00.773501+00	0	11.1	731231	731231
1893ed17-cd35-4afa-a3dd-576dbd0c1470	2026-01-07 03:42:00.768338+00	2.3	11.1	621706	621706
f5e0ed61-09d7-4c35-aa25-0bf12f5be319	2026-01-07 03:43:01.101415+00	3.2	11	559192	559192
efc3b13b-b461-437e-b981-db209b5c16ea	2026-01-07 03:44:00.969978+00	3.1	11	760495	760495
60717b87-ccc8-4a1a-b9a6-69f7c2ea6983	2026-01-07 03:45:00.945571+00	2.8	11	620424	620424
891512cf-4e24-419e-a839-1fba6ced9bef	2026-01-07 03:46:01.036921+00	2.7	11	262168	262168
e7cb3888-aec4-4c5a-ab24-ca06b3201e64	2026-01-07 03:46:01.239463+00	2.7	11	469055	469055
bff4ed5d-117e-4830-855a-a03d1d2cb8d3	2026-01-07 03:47:00.925151+00	3	11.1	552819	552819
11385c93-efa1-48d2-9c8a-b46e0b1eb44f	2026-01-07 03:48:00.778767+00	4.3	11	585882	585882
57baf76d-b6d6-4ab4-b1fd-91c0ec70e1d0	2026-01-07 03:49:00.924926+00	5.9	11.1	625949	625949
f8b294b8-83ca-43e1-a6c2-2c45643be66e	2026-01-07 03:50:01.031494+00	2.8	11.1	667585	667585
c79ec106-23df-49e3-b4f5-39587177f039	2026-01-07 03:50:51.328181+00	2.6	11	18109	11319
42a79009-d469-4b52-9b39-48e0fe2b23e3	2026-01-07 03:51:00.217429+00	2.4	11.1	734322	734322
47ef86e7-8eef-4060-8a72-947a55104ba7	2026-01-07 03:51:00.699316+00	2.4	11.1	664630	664630
4cd1f7e5-6bb9-44c5-aad0-ace9327b58b6	2026-01-07 03:51:01.163308+00	2.4	11.1	537482	537482
abbe7190-510b-4068-bc34-a68d3070c00f	2026-01-07 03:52:00.86295+00	2.6	11.1	624228	624228
9615a200-f2ad-4319-95ae-f661ed1f5013	2026-01-07 03:53:00.142789+00	2.4	11.1	12328	12328
9dbdd993-da92-4777-8800-ec915b105e40	2026-01-07 03:53:00.26011+00	2.4	11.1	773899	773899
2f3f2fee-2d9b-43e2-a4eb-bee99873bb21	2026-01-07 03:53:00.979741+00	2.4	11.1	605162	605162
f9663482-e730-4361-ac4d-b9e5ba8865f4	2026-01-07 03:54:00.997752+00	3.1	11	459073	459073
126d6ff4-f8d8-4d5f-a21c-8fe6116ae8f9	2026-01-07 03:55:00.760527+00	2.4	11	801352	801352
7b9da812-d214-4f7e-9722-cb809be8dc43	2026-01-07 03:56:00.913546+00	2.9	11.1	571550	571550
b0f4a0ab-8016-4722-8906-57dff3203b2f	2026-01-07 03:57:00.294376+00	3.6	11.1	224790	224790
c74c297a-bced-4d5d-a150-9ec81994d73d	2026-01-07 03:57:00.7939+00	3.6	11.1	715769	715769
68fb74e4-01a3-4e9c-bdfc-5a042b0be096	2026-01-07 03:57:00.882269+00	3.6	11.1	868231	868231
a2cdbeee-af8b-4e5c-b4cd-da95a89b03d6	2026-01-07 03:58:00.670211+00	3.5	11.1	455296	455296
522c6f66-34e5-4286-82ed-62f67c412c74	2026-01-07 03:58:00.841125+00	3.5	11.1	515692	515692
46a6f50a-cacc-4ada-859c-932e91b0a1cc	2026-01-07 03:59:00.141213+00	2.7	11	11941	11941
8c419c37-4d23-400d-8eb8-cb60cf8eaf2b	2026-01-07 03:59:00.279591+00	2.7	11	549798	549798
d86f321e-5d77-4ec4-9b62-1211eea90448	2026-01-07 03:59:00.717546+00	2.7	11	636166	636166
59e83132-9276-4cfd-b01c-03481ba9c7d8	2026-01-07 03:59:00.864783+00	2.7	11	750212	750212
4566d114-fbab-4ccd-bee4-be22dde10694	2026-01-07 04:00:00.735099+00	3.1	11	589825	589825
3956b151-24d1-4605-bc7f-efbe69f1f42f	2026-01-07 04:00:00.754771+00	3.1	11	929457	929457
f46a4827-d9e3-48bd-a3a6-95996eb20bd9	2026-01-07 04:01:00.076835+00	3.2	11	8847	8847
6f1aee64-7dff-42e4-a62e-2aa9a9dc7d22	2026-01-06 17:03:22.250547+00	35.4	29.3	5929153	5929153
ea7f62f0-eaaa-4da7-ab50-5f904bd58a7c	2026-01-06 17:04:22.621046+00	41.7	29.4	295587	295587
164388b2-5fa2-4e23-948f-fb90d9982cfc	2026-01-06 18:06:43.52709+00	40.8	29.6	4601371	127117
afdd3e4c-3020-40c8-9ad9-f83dc3911415	2026-01-06 18:31:43.914353+00	50.5	29.7	4503296	117062
30c52660-3c49-4754-b228-564fcf9c7c88	2026-01-06 18:57:44.313453+00	39	29.8	3947043	106340
f1a43d21-e802-442c-b0b7-501004d334f6	2026-01-06 19:23:44.717486+00	40	29.9	3957808	105549
780c7307-3234-4774-8faa-4351fa823e9e	2026-01-06 19:49:45.038625+00	41.3	30	4137082	107084
d83bedcc-bf13-4b4e-908b-d3e9fe0749c0	2026-01-06 20:11:45.390693+00	37.5	29.9	3975989	102696
48adc440-9b3e-4ad7-a32c-ce893667c76c	2026-01-06 20:34:22.668509+00	43.2	30.2	251544	251544
bb22baac-d94e-48c2-ad03-4fd1750a9173	2026-01-06 20:36:22.416293+00	43.6	30.1	285902	285902
8d79625c-b13d-44f8-9f23-cd50e33e4004	2026-01-06 20:52:45.960479+00	35.3	30.1	6732225	193849
d2807bae-696c-42ad-a812-899ffef7836c	2026-01-06 21:21:46.3858+00	4	21.5	1417	299
ff927ded-d91d-481b-8264-1907d654c24e	2026-01-06 21:50:46.705685+00	4	21.6	1545	189
d82ff264-f2f4-4aa8-992c-db9e8bc6969b	2026-01-06 22:19:47.059783+00	3.9	21.6	1794	296
65d5e010-4717-4b59-b695-1e1125e872ea	2026-01-06 22:48:47.358834+00	3.7	21.5	1562	170
663a4912-af5d-437e-a6eb-8450c2762d4c	2026-01-06 23:17:47.746955+00	2.9	21.4	1811	311
c8fe7e13-735e-4ecc-a2cc-0b83deeb276e	2026-01-06 23:46:48.092775+00	2.8	21.4	1795	299
4c7523b9-3362-42ae-8c17-98a502945685	2026-01-07 00:15:48.458315+00	1	10.1	1524	17
d64a0c74-48df-4762-b19e-24393543f1ee	2026-01-07 00:44:48.865397+00	0.9	10.2	1072	13
2732ad28-09d4-4e47-bbe3-ef89df15edfc	2026-01-07 01:13:49.272336+00	0.9	10.2	1340	15
86fdb5b7-5597-45d5-929a-856f5d15a609	2026-01-07 01:42:49.676529+00	0.9	10.2	1317	23
9659b35a-48ea-4da0-985f-70cfaa01a239	2026-01-07 02:05:00.751947+00	3.3	11	486870	486870
e46ebde8-f84c-4834-ba1a-0145d1b209e6	2026-01-07 02:06:00.208044+00	2.8	11	578554	578554
c2b2de22-94ec-456a-94b2-bab37b957aac	2026-01-07 02:06:00.740975+00	2.8	11	704995	704995
c4154cfc-ec86-40af-a039-c35f23aef17d	2026-01-07 02:07:00.263657+00	3.5	11	664291	664291
b331dcf2-f656-4b86-8f08-428b1287c7c0	2026-01-07 02:07:00.695992+00	3.5	11	826191	826191
88cd4e79-6427-44cb-bac5-02158e5653a8	2026-01-07 02:08:00.59438+00	2.1	11	643440	643440
bde3141b-7e0a-409f-85e6-245e36f08ba6	2026-01-07 02:09:00.912116+00	4.8	11	612229	612229
4bcb969b-a2c1-44b9-aa28-b9fc9dc49269	2026-01-07 02:10:00.157307+00	3.9	11	8724	8724
1c262d70-8cde-44d2-8de4-2c8efd2f3148	2026-01-07 02:10:01.150008+00	3.9	11	374299	374299
69428683-b8a5-433e-bf83-fca91b1e1d2c	2026-01-07 02:11:00.787809+00	2	10.9	520606	520606
9110da4e-9105-42a5-bca1-f892e7d64a2c	2026-01-07 02:12:00.525727+00	2.3	11	755039	755039
03a14654-cf73-4313-a3fc-dd03a88ae811	2026-01-07 02:12:00.786983+00	2.3	11	609400	609400
abc5f6ca-563a-4c2b-b2e9-2af552826557	2026-01-07 02:13:00.962072+00	3.4	11	769758	769758
a49158b5-dfc1-484d-b631-5cce50d11115	2026-01-07 02:14:00.206131+00	2.7	10.9	726803	726803
17111612-21bc-4df6-97b4-38e4e5954b45	2026-01-07 02:14:00.688468+00	2.7	10.9	676947	676947
9661d303-4194-4de8-be92-d9ee55a4dee7	2026-01-07 02:15:00.89504+00	2.4	11.1	862689	862689
5542fa84-94ff-4ce7-bc3c-f15233975d3e	2026-01-07 02:16:00.678288+00	2.3	11	668716	668716
d84e24ec-b0eb-4cc4-bf2b-49b4f2e67ae5	2026-01-07 02:16:00.903457+00	2.3	11	449900	449900
effc2b3c-e045-4bd7-aaed-662f6e7de995	2026-01-07 02:17:00.195917+00	2.2	11	708127	708127
2b40b9e1-87a2-4e4d-b5e1-7c200e78775d	2026-01-07 02:17:00.787507+00	2.2	11	447597	447597
80403261-5d25-4e97-8bbd-04c08e70c3a1	2026-01-07 02:18:00.174158+00	2.4	11	640620	640620
f3e5ef58-fafb-4cdf-8d09-f020c29e9cf2	2026-01-07 02:18:00.832688+00	2.4	11	642269	642269
9f159972-3562-4418-8313-477b08394136	2026-01-07 02:18:01.051342+00	2.4	11	593853	593853
31238042-112e-4690-b857-e782846f3ad2	2026-01-07 02:19:00.24225+00	3.5	11	626591	626591
bd00cae4-c438-4a81-974d-46ef8ce2fcac	2026-01-07 02:19:00.684044+00	3.5	11	735964	735964
ed78e6e1-f5d7-4590-a66a-694142407e09	2026-01-07 02:22:50.163008+00	2.9	11	46558	29225
f893d66b-582e-4502-95d6-b40de8477c85	2026-01-07 02:42:50.429784+00	2.8	11	25364	51821
ca6752a2-0d54-4174-a864-273598a7b517	2026-01-07 02:57:50.617713+00	4	11	20581	29441
98107307-6a42-41ee-88f3-70645ecfbd83	2026-01-07 03:06:50.739672+00	2.8	11	24151	14665
9865a4d9-ba41-4e3e-a8c1-e38002df06f7	2026-01-07 03:16:50.869764+00	3.2	11	17358	12082
cf062152-b353-47ea-a6a4-c6057c11e300	2026-01-07 03:27:00.940322+00	2.6	11	517498	517498
8e1287bf-c72d-490e-b49e-e02b7fdcb5ee	2026-01-07 03:28:00.965549+00	2.6	11	524065	524065
3f3a86e8-a131-4a30-a56a-00e99bc45a71	2026-01-07 03:29:01.112083+00	4.7	11	560608	560608
1c24fb49-eb52-4b27-863e-c0853107b8ff	2026-01-07 03:30:00.767256+00	2.8	11	627782	627782
71de5b05-2544-4647-ac1e-bba1096c2094	2026-01-07 03:30:00.922821+00	2.8	11	382796	382796
b52c5543-78f7-4860-a31b-2b45961cf8ef	2026-01-07 03:31:00.072993+00	2.5	11.1	8029	8029
717ef4ff-dc6c-496d-8a64-a72d5c457c80	2026-01-07 03:31:00.933136+00	2.5	11.1	658852	658852
1fee6e9d-7073-4e64-b225-160793c01ec5	2026-01-07 03:32:00.829143+00	3.3	11.1	505728	505728
942052d6-43de-42ce-af68-e5da62be450f	2026-01-07 03:32:51.11534+00	20.1	12.1	20034	9459
ef7d5956-ceb7-4932-81f1-57ee107e8b3f	2026-01-07 03:33:01.142024+00	11	11.3	522077	522077
54b09460-a673-4a9c-be4d-0acbdcfcb9ba	2026-01-07 03:34:00.72571+00	3	11.1	721680	721680
b5e3b3ae-d837-48c5-a170-4452cf2231d6	2026-01-07 03:35:01.15628+00	3.3	11.1	462350	462350
006e2cf5-018e-460b-ab8d-ac9db9895489	2026-01-07 03:36:00.100916+00	2.5	11.1	7781	7781
c23dc111-a428-4aed-9620-301c2cba133a	2026-01-07 03:36:00.834026+00	2.5	11.1	650997	650997
f8b20d55-0017-488a-92c9-36677d683cad	2026-01-07 03:37:01.020017+00	2.6	11	475533	475533
00323c98-f811-49ed-ab7d-742b0b4d9f3c	2026-01-07 03:38:00.141237+00	3	11	7793	7793
413516a0-fbde-41e5-b4c8-87478b7f8c49	2026-01-07 03:38:00.685896+00	3	11	298355	298355
9e6db091-bd4a-4995-90e8-717e9cbc5baa	2026-01-07 03:39:00.168018+00	2.5	11.1	687763	687763
3318a84f-0ff8-4971-9490-8ccfe08285b2	2026-01-07 03:39:00.960899+00	2.5	11.1	444108	444108
bd661c0c-1a21-4eaf-ac8f-6241319669cc	2026-01-07 03:39:01.186558+00	2.5	11.1	597553	597553
75f57ed3-40a8-4312-afd2-b3e9b4ef8e9a	2026-01-07 03:40:00.177827+00	2.7	11	637620	637620
c27fac94-4e95-4fc1-a29b-37fa15838910	2026-01-07 03:40:00.685492+00	2.7	11	614570	614570
835aef02-fd8c-4127-a00f-65cbde517a9e	2026-01-07 03:41:00.166663+00	0	11.1	9173	9173
741e6497-dd4d-4a64-8b77-eb3660a6a660	2026-01-07 03:41:00.764789+00	0	11.1	758620	758620
b557aeca-a135-4170-9dca-81cc33daf358	2026-01-07 03:41:51.206667+00	4.7	11	12708	8699
4537fd6f-4587-4bb0-aa37-8457915c60fd	2026-01-07 03:42:00.287581+00	2.3	11.1	589271	589271
5538ec19-0ad0-406e-96b5-a3f686b9c317	2026-01-07 03:42:00.734477+00	2.3	11.1	704622	704622
e62b35b1-6fda-4feb-a079-72122b5bf964	2026-01-07 03:43:00.404618+00	3.2	11	166857	166857
9cb803f3-27db-4dfa-9ac4-3c85bba8cf92	2026-01-07 03:43:01.068062+00	3.2	11	450885	450885
b21b27f3-0016-44a2-b2ae-b58602304386	2026-01-07 03:44:00.269366+00	3.1	11	12533	12533
e3eece5e-150e-4dca-9699-ee4c990db808	2026-01-07 03:44:00.930182+00	3.1	11	810119	810119
00bdda8a-9c56-4468-8ace-fd919d8e3bda	2026-01-07 03:45:00.255685+00	2.8	11	8724	8724
57cec347-612f-4343-8fb1-e31e782fa777	2026-01-07 03:45:00.904024+00	2.8	11	606645	606645
1e4e2f41-6fa3-4f59-8a74-2dffc3d810ae	2026-01-07 03:46:01.050589+00	2.7	11	357217	357217
a009d764-ae98-4f42-b741-d44ee16e0e00	2026-01-07 03:47:00.996097+00	3	11.1	643441	643441
3f301f6f-9843-4228-80e0-797a678bd01f	2026-01-07 03:48:00.79245+00	4.3	11	674868	674868
49376b9e-36ed-44b0-b690-b9093f3b4d23	2026-01-07 03:49:00.80054+00	5.9	11.1	637841	637841
3ea1fe98-8dc9-4129-ae11-698246abbfe8	2026-01-07 03:49:01.003592+00	5.9	11.1	670252	670252
f89ca6bc-b607-42f9-af6f-96668af8832c	2026-01-07 03:50:01.043483+00	2.8	11.1	295596	295596
f2e67b10-9aa2-4809-abd5-c4d11f11bcb6	2026-01-07 03:51:01.02302+00	2.4	11.1	598501	598501
1550b24f-f8c3-4a0a-8a2a-0ffcc22189fe	2026-01-07 03:51:51.356953+00	2.4	11.1	12123	15721
d4f85bf1-97e3-4f59-97da-e4de63b3ceb5	2026-01-07 03:52:00.822723+00	2.6	11.1	572510	572510
9cf7a177-70cd-4468-9f05-7329d6ebecfd	2026-01-07 03:53:00.970696+00	2.4	11.1	529448	529448
494e2ab6-9146-4399-b02e-dd2899165c03	2026-01-07 03:53:01.162136+00	2.4	11.1	530193	530193
bed78129-336d-47b9-b593-dc1b5eb8edfb	2026-01-07 03:54:00.964138+00	3.1	11	646076	646076
421641b8-b27f-4e6a-9244-52e845da30df	2026-01-07 03:54:01.15829+00	3.1	11	832568	832568
55aa38a6-5695-40f3-a39b-d85ae426a690	2026-01-06 17:03:22.604093+00	35.4	29.3	280218	280218
68ca1bf1-f08b-4c9d-ab9c-cc4e25db2cfb	2026-01-06 18:07:43.564882+00	36.6	29.6	3826022	101697
53b8bea2-299a-4f88-b1ca-4dee96851d95	2026-01-06 18:32:43.927631+00	41.8	29.7	3949663	103013
8e4e959b-7708-435a-9869-42b78f84ca06	2026-01-06 18:58:44.334951+00	42.2	29.8	4171041	111405
a32629a5-68fd-419b-a31d-c073437ad6ab	2026-01-06 19:24:44.733919+00	43	30	3703046	95394
915ac43d-580d-43c8-ae16-54fb6c83b21c	2026-01-06 19:50:45.051347+00	36.6	30.1	4086517	104186
c6336eee-68fe-4104-bf56-31b21ee89eb0	2026-01-06 20:12:45.394504+00	39.8	30	4333420	113206
d3605302-2626-4375-bbc7-9264df49a9cd	2026-01-06 20:34:45.727647+00	36.8	30.1	4102614	110645
174460ab-3f19-4a9a-a0eb-e866e20a99ec	2026-01-06 20:53:46.023793+00	6	29.6	858	62
c31c3161-8f64-4f83-bc37-cc29452cb1b8	2026-01-06 21:22:46.363048+00	3.8	21.6	1426	310
043d6e37-fc99-43f5-8ce0-9cf0dece47af	2026-01-06 21:51:46.753871+00	3.8	21.5	1576	187
facd6d14-5f58-4a85-a726-2103b0211567	2026-01-06 22:20:47.041039+00	4	21.6	1748	286
3f79aee3-c904-4cc1-ac66-79a2324f8566	2026-01-06 22:49:47.415066+00	3.9	21.5	1656	170
0b50d6bd-0b86-41d2-a398-55a7e536b93c	2026-01-06 23:18:47.749355+00	2.7	21.4	2570	412
b8994eb8-1ee7-4b9e-b2a1-0cb7add3d1c9	2026-01-06 23:47:48.141881+00	3.1	21.5	1860	303
2629e9ac-98ad-4e1a-8f46-ac30d97a153f	2026-01-07 00:16:48.474733+00	0.9	10.1	2123	13
660bd664-15af-4353-b4e9-0ba8e8176c90	2026-01-07 00:45:48.856798+00	1.3	10.2	1357	18
27e72d10-cd3f-4e66-93f1-0a1542f6019c	2026-01-07 01:14:49.290789+00	0.9	10.2	1796	18
90d89095-9d27-4e80-a6d3-69d5aaa9fd71	2026-01-07 01:43:49.682313+00	1	10.1	1346	23
e256f9e4-c02e-4be1-8e0d-e08970950408	2026-01-07 02:05:49.937022+00	2.1	11	46582	49484
74b7b370-72fa-4714-a702-aa8af7e0c214	2026-01-07 02:23:50.182935+00	2.1	11	39595	22596
cbcf309e-7ae2-4857-bbb4-0ce835c055b4	2026-01-07 02:43:50.4482+00	5.4	11	30270	68048
dcf39db0-d5fb-401c-8d36-75a4fdd0dc3c	2026-01-07 02:58:00.040919+00	2.4	11	7927	7927
297ac7c3-3a3a-4302-ade9-6ec80cb0db2b	2026-01-07 02:58:00.29429+00	2.4	11	198881	198881
c1c9c6aa-c221-4bfa-ae32-c7e6206660b8	2026-01-07 02:58:01.010448+00	2.4	11	370475	370475
d4bd2c54-cfa3-4db9-9404-709a14028714	2026-01-07 02:58:01.157862+00	2.4	11	443997	443997
37cb7cdf-f394-4f48-9d16-7ea752b6527b	2026-01-07 02:59:01.285157+00	2.8	10.9	651265	651265
648f8d96-b69a-4f1b-b6f8-815c00243554	2026-01-07 03:00:00.776723+00	3	11	504246	504246
25a58418-93c6-4b07-a2bb-b560cb6e3d4a	2026-01-07 03:00:00.865344+00	3	11	518089	518089
be34e605-6497-4fc4-bc9e-dc5e4844e39c	2026-01-07 03:07:50.742564+00	4.9	11	20788	13521
d8c2f5ba-1bef-4560-be0c-12c04624eaa4	2026-01-07 03:17:50.889946+00	1.9	11	18445	12175
98ad16f6-9507-4203-b538-8f11211cd2dc	2026-01-07 03:27:00.961449+00	2.6	11	698407	698407
b46630b3-a4e1-47a7-965a-03b9cb9b203f	2026-01-07 03:28:00.339223+00	2.6	11	400685	400685
1d45dece-365f-4d02-bae0-ca9aa9c8ef6a	2026-01-07 03:28:00.900145+00	2.6	11	654543	654543
f48e3d9e-51cf-4a40-beb6-7039dd1de8b6	2026-01-07 03:28:01.143289+00	2.6	11	504709	504709
011f2972-8133-425f-a37e-5a9647b38c9c	2026-01-07 03:29:01.029358+00	4.7	11	459416	459416
e3498104-e1d9-4829-bd3c-d3f95ec92c65	2026-01-07 03:30:00.185595+00	2.8	11	9118	9118
ac9efd84-9542-4284-bfb1-297f137b7437	2026-01-07 03:30:00.791228+00	2.8	11	412994	412994
bf126adf-d99c-40fa-83fd-f41893597f9b	2026-01-07 03:31:00.951079+00	2.5	11.1	484944	484944
b3006d03-405f-4843-a848-da416fe6ba81	2026-01-07 03:32:00.169614+00	3.3	11.1	9052	9052
86774d7e-d119-49be-84e3-b0fbc5c77f0b	2026-01-07 03:32:00.808657+00	3.3	11.1	475951	475951
f748eb28-a1b8-402f-bf35-937281e0fe96	2026-01-07 03:33:01.044294+00	11	11.3	613180	613180
1288fa6b-3f61-4412-8adf-672a4f1c013f	2026-01-07 03:33:51.119914+00	1.8	11.2	15770	9328
6f157420-d497-4df1-86c7-6b70b1a79981	2026-01-07 03:34:00.627259+00	3	11.1	668483	668483
15d7e7e3-42e4-47f9-9586-6657653dc421	2026-01-07 03:34:00.812503+00	3	11.1	557173	557173
6f62a929-6da6-4e3d-8c86-203a463580f5	2026-01-07 03:35:01.05724+00	3.3	11.1	426538	426538
797b878b-4a94-4eb6-bd6e-a47982dee4d1	2026-01-07 03:36:00.845799+00	2.5	11.1	790567	790567
99a8ca80-60c4-47a0-b8da-55670823f367	2026-01-07 03:37:00.081035+00	2.6	11	7946	7946
90105a97-2d0d-44c1-91f9-9239da46521e	2026-01-07 03:37:00.938969+00	2.6	11	541447	541447
f332d63b-7d32-4f00-a095-a2ff0da907eb	2026-01-07 03:38:00.790946+00	3	11	474331	474331
593ac7d2-bd82-451e-b24a-018e039b268b	2026-01-07 03:39:00.046813+00	2.5	11.1	7726	7726
47922eca-9268-4d83-abda-a459151fc39e	2026-01-07 03:39:01.047714+00	2.5	11.1	250049	250049
cad22903-8ce6-4f82-9e4e-1f26c3ca9775	2026-01-07 03:40:00.693374+00	2.7	11	559138	559138
7d27c453-fb05-46b5-a49e-2855f6260549	2026-01-07 03:41:00.268488+00	0	11.1	721861	721861
db062e3a-9c2c-4eda-9623-b836c17dada9	2026-01-07 03:41:00.736767+00	0	11.1	680267	680267
4a9bb4f4-fbd8-4bb4-9465-cd2129c945a4	2026-01-07 03:42:00.776249+00	2.3	11.1	718937	718937
8cec2556-bfcd-4b94-8b99-f26da1615064	2026-01-07 03:42:00.817289+00	2.3	11.1	679782	679782
c23dea2e-43c8-4790-abb9-3c96b3ac283a	2026-01-07 03:43:00.086727+00	3.2	11	8801	8801
18434657-16a5-4132-b2b3-ef1cc6b721b3	2026-01-07 03:43:01.04681+00	3.2	11	546447	546447
20b7eebe-380e-4ffc-8387-11a76634afad	2026-01-07 03:43:01.080257+00	3.2	11	403656	403656
8e6d6737-cd9f-4f7c-b442-7bd692d8c56b	2026-01-07 03:44:00.388649+00	3.1	11	675683	675683
dca5c017-25c6-43cb-a85f-9f17471ffba9	2026-01-07 03:44:00.915417+00	3.1	11	574334	574334
92a0c766-f604-4726-a2f9-7072b61c677c	2026-01-07 03:44:00.921611+00	3.1	11	663284	663284
c39085f8-12bc-40ca-a56b-3ee682619655	2026-01-07 03:45:00.41596+00	2.8	11	429356	429356
7eeb8747-c42f-4d0a-a282-ed1eccaecee7	2026-01-07 03:45:00.877676+00	2.8	11	638744	638744
6a164afb-cf9b-4430-9467-ac221a9dcbbf	2026-01-07 03:45:00.885887+00	2.8	11	543561	543561
c4bae2b5-6b1d-4134-ac00-21d3e3c5caf1	2026-01-07 03:46:01.068459+00	2.7	11	484925	484925
eb16eb5b-3814-4b49-be95-0a44f4b34834	2026-01-07 03:47:00.980511+00	3	11.1	578809	578809
25216308-6250-4b01-b93a-69578de9dc7d	2026-01-07 03:48:00.216297+00	4.3	11	652511	652511
596a6ad0-224c-4567-80e4-ee63e249a4fb	2026-01-07 03:48:00.725032+00	4.3	11	734787	734787
80cae3bc-0ac8-4697-a89f-a87fde86b340	2026-01-07 03:49:00.817533+00	5.9	11.1	615108	615108
a3f622aa-60e2-4708-95d1-c3259b5df3dc	2026-01-07 03:50:00.891336+00	2.8	11.1	635034	635034
66116dc9-968d-40a5-82db-07b8cad4a937	2026-01-07 03:51:01.03646+00	2.4	11.1	103178	103178
af6a4e33-fdd6-433d-8234-f2ad57bc7c4f	2026-01-07 03:52:00.093678+00	2.6	11.1	8613	8613
a68dfc4e-1439-48eb-a883-d6043adb6227	2026-01-07 03:52:00.272303+00	2.6	11.1	620924	620924
7625fe34-f1e7-4c6c-95db-537c8b4084ed	2026-01-07 03:52:00.829016+00	2.6	11.1	381251	381251
6e15207d-bfc3-4dc3-8c0f-4480b98a95d1	2026-01-07 03:52:51.373828+00	4.5	11.1	10850	8505
1ab929fb-6328-4ad7-b8c3-840b8cad5034	2026-01-07 03:53:01.055444+00	2.4	11.1	632422	632422
7b2cdc66-c1c4-4d41-90c0-ea016cdd5fe7	2026-01-07 03:54:00.333885+00	3.1	11	9270	9270
ed298a96-c1f8-4daf-ba2d-f6b2aa95209d	2026-01-07 03:54:01.022164+00	3.1	11	509759	509759
e1effde8-6bef-4608-a52b-0916f6f52db7	2026-01-07 03:55:00.25512+00	2.4	11	449704	449704
9c5eac51-ca49-43ec-982d-f557d9740ff8	2026-01-07 03:55:00.691342+00	2.4	11	656132	656132
9343d6bd-ab5b-4ecf-b0e5-7de08c76be7f	2026-01-07 03:56:00.783441+00	2.9	11.1	321863	321863
091092c5-6ab7-49cd-a3f5-7270b0a1e1a2	2026-01-07 03:56:01.04799+00	2.9	11.1	518110	518110
15b4ea1f-1cec-44f2-b3ca-11cfa9856463	2026-01-07 03:57:00.0592+00	3.6	11.1	10820	10820
da52ebb3-e7db-42a2-8886-afa87c37badf	2026-01-07 03:57:00.841644+00	3.6	11.1	693537	693537
436a3706-1d76-4581-96c2-8afc3dceaf74	2026-01-07 03:57:51.414235+00	2.9	11	21979	7447
30f17345-66d8-44b1-9d78-a45ea61f2a22	2026-01-07 03:58:00.206308+00	3.5	11.1	624709	624709
cb899902-8cfd-4183-9f08-7a886f49dfab	2026-01-07 03:58:00.712647+00	3.5	11.1	344696	344696
08269c53-0f6f-4729-931f-017e28d9964d	2026-01-07 04:00:51.447175+00	3.3	11.1	14681	9454
d7275978-9893-4a8e-a5cf-f45b95c14958	2026-01-07 04:01:01.222806+00	3.2	11	297412	297412
68cdaf68-1718-4914-8aab-6623561b8f5e	2026-01-07 04:02:00.177603+00	2.9	10.9	12015	12015
691aeb10-56ab-4ea2-b92b-f0f733ed1cc1	2026-01-07 04:02:00.871003+00	2.9	10.9	603495	603495
fda85647-8375-4076-aff7-1d1f9b1476bc	2026-01-07 04:02:00.980548+00	2.9	10.9	683927	683927
a3ab4a67-a5c6-4c22-a3b0-5bb7558d469b	2026-01-07 04:03:00.773809+00	4.9	11.1	557590	557590
2aa1d4fd-ff23-4be2-9270-8b8ea8acd186	2026-01-07 04:03:51.491606+00	3.7	11	10698	7737
a3a25362-a688-43c3-8e54-c322509ccf3b	2026-01-07 04:04:00.732878+00	2.7	11.1	442500	442500
76df6e15-1b1a-43ae-8617-e4cd71127d2c	2026-01-06 17:03:22.687657+00	35.4	29.3	254864	254864
6810ccac-586b-412a-a61d-8b98382b5704	2026-01-06 17:03:25.967729+00	40.6	29.3	519307	519307
c3a3deec-39af-44a7-b163-406407b3a8e8	2026-01-06 17:03:42.576684+00	40.7	29.6	3788629	105162
74ff8e00-6a5b-491e-95d7-4c721685716b	2026-01-06 17:03:50.363942+00	34.2	29.5	3825786	3825786
e93195d6-d619-4891-adf4-15718cec5cca	2026-01-06 17:03:50.503469+00	34.2	29.5	5297707	5297707
0c09d0af-0c8b-4108-b9bd-4ef2ca351718	2026-01-06 17:03:51.714913+00	41.5	29.5	1397993	1397993
8eff5a33-7f67-43b5-8f20-207c061d0ad0	2026-01-06 17:04:02.092692+00	45.5	29.4	4408829	4408829
97af8540-ef63-47c4-9b6d-91994c1f1716	2026-01-06 17:04:21.549276+00	29.8	29.6	3866719	3866719
f84da8e3-d8fb-424b-8efa-09242a01d166	2026-01-06 17:04:22.72561+00	41.7	29.4	416567	416567
496c714e-8ffa-499e-8161-fe7fe89d59b4	2026-01-06 17:04:50.473031+00	37	29.3	5106957	5106957
e24cd214-7f96-4132-8d1e-479952c0ff92	2026-01-06 17:05:21.621745+00	30.9	29.2	2435700	2435700
01708d58-9c75-424d-94ae-140d1e619d43	2026-01-06 17:05:22.721751+00	35.9	29.2	5061305	5061305
2e93fe75-dc21-4d28-a5c1-1a19333b989e	2026-01-06 17:05:50.396219+00	37.5	29.5	6026431	6026431
4ee10b3b-1293-4052-86ac-550cd35b20d9	2026-01-06 17:06:22.677893+00	41	29.2	3227637	3227637
d95ef84b-6f0f-41e5-90ef-2faf9869c59c	2026-01-06 17:06:50.456018+00	38.6	29.3	4213728	4213728
55760af5-d9c8-4827-a9da-279fd8928a71	2026-01-06 17:06:51.838411+00	40	29.3	5247297	5247297
ff50b712-d5f8-4cec-a5cd-a34f52ea2a7f	2026-01-06 18:08:21.551444+00	34.2	29.6	3767336	3767336
725c8fc8-5d5b-4d60-88f8-570abd8998c6	2026-01-06 18:09:02.10973+00	46.4	29.7	3348189	3348189
441612e7-13be-4327-8d38-00ad17a65342	2026-01-06 18:09:22.206027+00	42.1	29.6	847049	847049
ea536c30-9598-455d-9213-c0544d7fb9e2	2026-01-06 18:09:25.958801+00	42.8	29.7	1899522	1899522
b9c2e478-66ee-471e-96ea-cfb037f59be0	2026-01-06 18:10:22.18939+00	43.5	29.7	4269925	4269925
b552ed7e-8e5d-441e-8bbe-d52dcf4f1f97	2026-01-06 18:12:52.175185+00	41.7	29.9	379670	379670
7c79d79d-ddea-41f9-8299-11465a658d35	2026-01-06 18:13:02.111258+00	48.8	29.6	5538923	5538923
d9c6f9db-b246-4537-9679-d2d435378e39	2026-01-06 18:13:25.936066+00	43.3	29.6	1077141	1077141
bfb870f5-149f-4add-b1e4-8decbceafb76	2026-01-06 18:13:51.814837+00	46.7	29.7	4856668	4856668
31c1593b-f360-4afd-a5a1-d4aa8449528d	2026-01-06 18:14:22.710384+00	36.8	29.8	5221170	5221170
e8afa17b-3a04-4777-9fff-df70a593ee39	2026-01-06 18:15:22.881999+00	36.1	29.9	5263478	5263478
510033bd-ad4b-47c9-b0d4-ba703c5f31df	2026-01-06 18:16:22.706698+00	44.4	29.8	5037178	5037178
371bfbae-c84d-48bc-952f-6f8f4df3dad7	2026-01-06 18:18:22.837744+00	39.1	29.7	3452347	3452347
1cd116f8-f38d-4aff-b086-63c3c271f7f8	2026-01-06 18:18:50.542868+00	31.3	29.8	4590814	4590814
233eff4c-f9e8-43eb-9a57-53cac48067bc	2026-01-06 18:20:02.109244+00	44.9	29.6	638596	638596
965fd011-508e-409c-93b5-dc8a81baff4e	2026-01-06 18:20:22.863429+00	42.9	29.7	3204313	3204313
0b359027-bee1-4507-98fd-629d822dad4a	2026-01-06 18:20:50.590278+00	37.1	29.6	2680778	2680778
8773c999-f515-4d0b-b850-e82df058726e	2026-01-06 18:22:21.634776+00	31	29.7	4715420	4715420
8bd287c6-c51a-4b96-9b89-62f24fa63fd7	2026-01-06 18:22:22.366439+00	46.6	29.8	4156523	4156523
94ab648e-b5f4-4f22-a4f8-85fc1ac1fe18	2026-01-06 18:24:22.666146+00	41.8	30	418658	418658
fb4e976b-961a-43c1-a90c-d20d5c9b6eec	2026-01-06 18:25:22.284249+00	43.8	29.7	4083247	4083247
936e9de5-7aa4-4cbe-90df-013df8fd7792	2026-01-06 18:26:02.124307+00	47.4	29.7	6520588	6520588
bcc62d58-fe3a-4587-a11d-0af067e19257	2026-01-06 18:26:22.389706+00	38.8	30	906265	906265
0ad9e566-d88c-4c2e-867a-aa17751b8cb2	2026-01-06 18:26:25.957742+00	42.8	29.8	4262378	4262378
22e5cbf4-4a9c-4160-8072-8ff3d6a5fe9b	2026-01-06 18:33:21.594387+00	40	29.9	3423096	3423096
cf2c2143-c39f-4c0e-ba67-428ac3355687	2026-01-06 18:34:02.097265+00	46.2	29.7	5539385	5539385
dde3123c-b076-4f01-98b4-93258b89d984	2026-01-06 18:34:22.716614+00	47.5	29.8	3861336	3861336
510f5666-2d1b-407a-9f1f-1c48c5b9e6bc	2026-01-06 18:35:02.146548+00	52.7	29.8	364447	364447
62eb6e6e-eae8-4ffa-9494-93c9d63ddb78	2026-01-06 18:35:21.537649+00	41.8	29.7	4951574	4951574
87065ecb-5e52-4b39-90f2-dad5a316449b	2026-01-06 18:36:21.570282+00	36	29.8	3767138	3767138
3490a99f-5e65-48a0-80e7-ab6ae4cf6e46	2026-01-06 18:36:50.455498+00	36	29.7	3913275	3913275
9cd6e893-0585-4bac-a13a-1ba4f9e75260	2026-01-06 18:38:21.629791+00	31.1	29.8	3827803	3827803
91c3eb7b-d6d4-4d85-b95e-acb886619d37	2026-01-06 18:38:22.302769+00	37.2	29.7	3719208	3719208
7f725cc7-20fc-41ab-8169-a15277f1adf3	2026-01-06 18:40:50.588779+00	40.8	29.8	291262	291262
4e544f5e-7aeb-4cae-8e14-5639523f403b	2026-01-06 18:41:01.977144+00	44.3	30	4495904	4495904
4b2cdfeb-d40d-4a1b-ad1d-8aaa002be35d	2026-01-06 18:41:21.583336+00	31.9	29.8	926695	926695
98995af5-fc1b-488c-b27c-5870a3d15eb5	2026-01-06 18:43:21.617725+00	39.2	29.6	683545	683545
04cf73bf-ddbd-4819-92aa-cd62b8dc6787	2026-01-06 18:43:22.3883+00	42.3	29.8	5415491	5415491
4380d3e6-3b50-411b-90b4-06bf11902e5c	2026-01-06 18:43:50.530124+00	40.3	29.7	2428374	2428374
5fe30704-811e-43e3-a65b-3523971d1c0c	2026-01-06 18:44:22.682764+00	37.5	29.7	6200265	6200265
d9fffdeb-b967-418a-966d-b2a894a2b3a0	2026-01-06 18:44:50.416917+00	37.6	29.8	3082009	3082009
c4230033-8f08-4c01-966f-6fd4f787672c	2026-01-06 18:45:22.612891+00	49.9	29.7	241362	241362
f23b7ef8-5367-4ab3-8d91-6cd3bdfa073a	2026-01-06 18:46:22.63174+00	37.8	29.8	4074065	4074065
aaca0b51-8b72-4cb3-83ef-a0b4b7cf854f	2026-01-06 18:47:21.511788+00	32.6	29.7	903482	903482
09f42827-767e-4f74-826d-1b7f95d470c2	2026-01-06 18:47:22.24371+00	45.2	29.8	676107	676107
c9daa13d-168b-4a17-ac60-7159bfc3b0b0	2026-01-06 18:59:44.347281+00	41	29.8	4066029	104835
d961c905-049e-4041-9a48-ed42b1950883	2026-01-06 19:25:44.709197+00	52.9	30	4043986	101812
9827ab5e-b47f-4928-845c-903b201a2e6b	2026-01-06 19:51:45.085487+00	38.5	30	4480881	114926
8e544635-d5fa-4539-afa7-ff6e4d0c886b	2026-01-06 20:13:45.39666+00	37.4	30	4103475	107346
80d9c8c6-8f79-43c5-8b7c-113925a78beb	2026-01-06 20:35:21.663733+00	33.8	30.1	486039	486039
e48906bb-316a-41a6-8859-6cb1669102b2	2026-01-06 20:35:50.528962+00	42.9	30	4798824	4798824
dd86d23b-d604-4c04-8c9c-b7031c4bb2c5	2026-01-06 20:54:46.027226+00	3.9	29.8	1339	192
321c9967-6722-4c72-b215-11bf5fa0aa17	2026-01-06 21:23:46.42116+00	4	21.5	1430	301
eddd0e71-aecd-457a-bafc-2ab2b3c39ce7	2026-01-06 21:52:46.770919+00	3.9	21.5	1210	191
3df6df91-c539-4716-871e-729ea7aef48e	2026-01-06 22:21:47.105813+00	4	21.5	1443	277
353215f0-94aa-4462-8e56-41778b186c96	2026-01-06 22:50:47.373786+00	4.2	21.5	1527	175
8d79c985-ae90-4511-bfe0-83f9a2b7ff3a	2026-01-06 23:19:47.756187+00	3	21.5	1572	192
883a4608-e765-45ea-bc65-c1f70bef0e29	2026-01-06 23:48:48.15735+00	2.7	21.5	1799	300
23170ffc-9bce-4fea-b2a5-4577edd3b0a4	2026-01-07 00:17:48.483975+00	0.9	10.2	1517	24
ed017252-a845-439a-82dc-826bb99e09a1	2026-01-07 00:46:48.892458+00	0.9	10.2	1388	18
970d6efa-3007-4d07-9098-ffca1472ed35	2026-01-07 01:15:49.281652+00	1	10.1	1526	19
3ea62e50-93d0-49c0-890d-0633b851e0a8	2026-01-07 01:44:49.709512+00	0.9	10.2	1610	18
6730dedd-24da-40a9-9840-678a0f4a477f	2026-01-07 02:06:50.003179+00	3.8	11	45755	34277
eda2c3bd-9c3b-4960-8690-211099df142b	2026-01-07 02:24:50.198473+00	2.9	11.1	28881	21059
99fcbc50-5e48-4b70-8fc6-50ceba584f5b	2026-01-07 02:44:00.967387+00	3.8	11	720040	720040
56eda8df-24f0-45dc-9dea-1557db34ccc0	2026-01-07 02:45:00.716118+00	2.4	11	636190	636190
c0598ff9-26d9-4b72-a9ea-4c53393e84ec	2026-01-07 02:46:00.233708+00	3.4	11	699926	699926
96db503e-c147-4f1c-b369-04a5728e24da	2026-01-07 02:46:00.951953+00	3.4	11	300324	300324
31b91b86-9064-475e-946e-702981f7704b	2026-01-07 02:47:00.828434+00	3.2	11	410959	410959
13ceb56f-d926-418f-9543-0b998e2dbb0e	2026-01-07 02:48:01.028052+00	2.8	11	565611	565611
57381536-52b8-4359-bd93-f66070dec2df	2026-01-07 02:48:01.243053+00	2.8	11	762271	762271
90190743-53a4-41da-be5a-fefc15d0d681	2026-01-07 02:49:00.759685+00	3.1	11	554737	554737
e4f3e8cf-3f70-41c3-a01f-c915b4fb215d	2026-01-07 02:50:00.249477+00	3.3	11	600557	600557
8434fd31-bd74-4008-9a77-d51393c7e715	2026-01-07 02:50:00.71367+00	3.3	11	622196	622196
697e690f-5a95-4843-890d-8c38c5d8c82a	2026-01-07 02:51:00.73352+00	2.4	11	351629	351629
ee4c4bc4-94e7-45fa-a728-d3707125a05d	2026-01-07 02:51:00.916158+00	2.4	11	699510	699510
9d8bb5e7-89c0-4f96-8e1e-0f3ce8738256	2026-01-07 02:52:00.776887+00	2.5	11.1	790174	790174
c65cbccf-9dbc-4685-afab-6520b9e97fb4	2026-01-07 02:53:00.189178+00	3.2	11	9542	9542
4f0edede-840d-4605-a739-9e3a9c3399ef	2026-01-07 02:53:00.803244+00	3.2	11	729181	729181
5584a16a-10ba-4402-b3ed-481af6f44f03	2026-01-07 02:54:01.000571+00	2.6	11	338871	338871
4393a9e2-9e19-4d6a-82ff-8eb5d41fc240	2026-01-07 02:55:00.633343+00	2.8	11	700679	700679
83ab1470-7601-4ad4-a117-e3892b2cf143	2026-01-06 17:04:25.943148+00	51.4	29.3	3455306	3455306
af73967d-3bef-4b89-b853-55b2a4ee9b63	2026-01-06 17:04:42.616784+00	36.5	29.5	4623674	132342
b03380b3-5a09-403c-8b76-8d61f0d7837c	2026-01-06 17:05:02.104247+00	41.3	29.3	4733662	4733662
b5e37a57-9235-4ba2-8056-a72a042b0842	2026-01-06 17:05:22.648803+00	35.9	29.2	401765	401765
755bed4d-2f5a-4d0c-b423-1e00658f69ff	2026-01-06 17:05:25.936874+00	43.6	29.3	2784187	2784187
82ed8b20-aedf-4e17-9749-ded86e64080f	2026-01-06 17:05:42.600354+00	38.8	29.3	4260108	116648
62607b5f-094b-4601-b8d7-2613d8c31ec6	2026-01-06 17:05:51.729937+00	42.1	29.5	3914481	3914481
f31c0973-4021-4842-895f-ad4f322d54ed	2026-01-06 17:06:02.09186+00	50.1	29.2	527294	527294
b3b14045-1f13-4aa9-8dd1-560788cf0aa6	2026-01-06 17:06:21.579032+00	30.1	29.2	8509320	8509320
b7860bbc-c894-4473-bd88-506cfe5be80d	2026-01-06 17:06:22.760528+00	41	29.2	4313300	4313300
37dd68c8-2e42-40eb-894c-ea9f2857b414	2026-01-06 17:06:42.63041+00	43.7	29.3	4853519	131504
be65142e-d461-4a46-b288-aba17c5f532b	2026-01-06 17:06:50.56372+00	38.6	29.3	771232	771232
6f80633a-dd5a-4a56-b40f-4b0557bc176b	2026-01-06 17:07:02.081598+00	45.3	29.4	718481	718481
4594e4b9-575f-44f9-8946-e99101ecb0a8	2026-01-06 17:07:21.617981+00	32.2	29.2	3201931	3201931
44a13817-1cfd-40b2-ad38-cbb0212e4ac9	2026-01-06 17:07:22.299322+00	47.4	29.4	5681189	5681189
b8796397-355e-4ae8-820c-3eac64e9bc6b	2026-01-06 17:07:22.660533+00	47.4	29.4	3428208	3428208
fffd3121-f7e1-4a13-bdc8-6b3534d3ccd7	2026-01-06 17:07:22.779925+00	47.4	29.4	242858	242858
61ca1a80-5992-40e3-bb5b-fade8c5d1e35	2026-01-06 17:07:25.941456+00	56	29.3	2308620	2308620
3684676f-c77b-4a2c-9433-c9b38f869358	2026-01-06 17:07:42.644621+00	38.2	29.2	4514491	126441
85dfebaa-9c12-442f-a3b4-2b34677c4e0c	2026-01-06 17:07:50.535445+00	30.2	29.3	927699	927699
32fff637-6b8b-4429-a9c2-4ef620181f9d	2026-01-06 17:07:50.632551+00	30.2	29.3	3833944	3833944
fcf12adf-e799-48f0-b773-4cd64eae5cff	2026-01-06 17:07:52.10429+00	70.8	29.3	4977712	4977712
a4718771-9ce6-4d4b-8ead-710207d10a03	2026-01-06 17:08:02.030825+00	43	29.2	4530982	4530982
88aba688-5319-4fd7-9005-3bef92d6e910	2026-01-06 17:08:21.606707+00	31.7	29.3	1073031	1073031
1ad994a3-1952-474c-af3e-0ca06086e702	2026-01-06 17:08:22.31647+00	43	29.3	621348	621348
04badc68-4242-415b-880a-693c227c4e98	2026-01-06 17:08:22.646726+00	43	29.3	556813	556813
35858045-7c20-4097-bba7-da33778a6c47	2026-01-06 17:08:22.764291+00	43	29.3	2244414	2244414
6ac6e2c3-7cab-40af-9588-50bfcf363210	2026-01-06 17:08:25.919269+00	43.1	29.2	3427591	3427591
8ff06942-8ca2-4d3e-9c64-fdf93ab021fd	2026-01-06 17:08:42.682486+00	55.1	29.3	4111805	111819
2833b8c2-1f14-4433-b6c0-946d9a6be8c1	2026-01-06 17:08:50.365573+00	29.4	29.2	3732099	3732099
5a318202-e674-48c1-bab2-f3a9be85f93e	2026-01-06 17:08:50.517013+00	29.4	29.2	4527119	4527119
daf951cb-4e91-4109-a9a8-5959da3f7d38	2026-01-06 17:08:51.770222+00	41.6	29.2	252997	252997
0b4c33fe-ffac-4dee-aef3-e0287f9038bc	2026-01-06 17:09:02.118092+00	47.1	29.4	4087340	4087340
c296d97e-4979-463e-879f-a0f61dd9d347	2026-01-06 17:09:21.684862+00	31.7	29.3	5222411	5222411
952fb552-fa42-4474-8795-4c9be03093ee	2026-01-06 17:09:22.366128+00	51.2	29.3	1243191	1243191
a793e5b9-16ef-4377-b907-ba82a8762a5f	2026-01-06 17:09:22.728804+00	51.2	29.3	3568974	3568974
b417c3ce-8282-4909-93a5-dfbe562c36f7	2026-01-06 17:09:22.810496+00	51.2	29.3	5352044	5352044
5b05b3c1-5de3-4253-a636-28573a83d514	2026-01-06 17:09:25.932802+00	54.1	29.3	2544361	2544361
5743395b-d2a4-4edf-9777-db2a66283242	2026-01-06 17:09:42.692271+00	39.2	29.2	4358263	116407
ca7c6d38-c509-4a2f-98a7-0c223362f666	2026-01-06 17:09:50.563429+00	35.7	29.3	4960318	4960318
f561081e-3baa-49c1-99c6-7ff60c312b11	2026-01-06 17:09:50.661655+00	35.7	29.3	4809528	4809528
2d5ac332-17dd-45ef-a1d6-545d75b74784	2026-01-06 17:09:52.174725+00	41.8	29.2	4953528	4953528
c767f5ea-088a-4ecc-bb7d-07e50fb718d9	2026-01-06 17:10:02.097834+00	50.8	29.4	3083475	3083475
9d5c4a56-782e-4601-8cca-0a68b8f31e86	2026-01-06 17:10:21.686889+00	33.9	29.3	1723930	1723930
d82d9c11-b170-437f-a6dd-0014e56faf5e	2026-01-06 17:10:22.412654+00	48	29.3	4925368	4925368
5fbe728f-41ab-464e-b43b-d24369d89720	2026-01-06 17:10:22.831161+00	48	29.3	1938348	1938348
4506981e-4cb0-4299-8c20-4e53816f6f89	2026-01-06 17:10:22.931354+00	48	29.3	315253	315253
3b18f097-3d6c-4e25-ab23-31462783f376	2026-01-06 17:10:25.96746+00	53.4	29.2	2578671	2578671
fb1b6a11-f85c-4895-ae03-4fdc039a3dae	2026-01-06 17:10:42.653908+00	41.1	29.4	4293661	121103
a24b047f-a9e8-4bec-9f1c-aafa6b7f8b0f	2026-01-06 17:10:50.453857+00	38.2	29.3	3520686	3520686
fea93fe4-24c0-49a4-a289-2035e30fb064	2026-01-06 17:10:50.563174+00	38.2	29.3	959353	959353
7afcd4f7-54d4-4222-81bc-05610a132a13	2026-01-06 17:10:51.769209+00	44.9	29.3	372191	372191
a1dfffd0-8b37-47ba-9e1a-c43156595d06	2026-01-06 17:11:02.103092+00	55.2	29.3	2574721	2574721
1e36a8eb-dee0-4696-8a5b-a8d9dce2f40e	2026-01-06 17:11:21.545045+00	30	29.3	4633342	4633342
4a6264bb-f4aa-4591-a33c-1210f0595ce6	2026-01-06 17:11:22.291358+00	48.3	29.4	1188649	1188649
0f9f39ba-5942-4964-9955-a3c49b066aa6	2026-01-06 17:11:22.684982+00	48.3	29.4	157990	157990
01396230-f589-4db9-bf6a-efbaebc7df42	2026-01-06 17:11:22.79965+00	48.3	29.4	2871436	2871436
5f338375-93ca-45a9-a175-ed7758ba252f	2026-01-06 17:11:25.955499+00	39.4	29.3	491031	491031
fc031dd4-1f46-475d-b77c-92a12d95df7a	2026-01-06 17:11:42.702967+00	56.8	29.2	4461673	122087
ce3335d8-490f-4af9-971c-b602793fe90d	2026-01-06 17:11:50.480508+00	40.5	29.4	692958	692958
39820e77-9e6b-4ee9-9960-b89961949da9	2026-01-06 17:11:50.598119+00	40.5	29.4	637507	637507
fa1a1753-c11f-49b2-9668-9767e77a7c57	2026-01-06 17:11:51.989041+00	41	29.4	4156251	4156251
ce0f4aef-7e6b-4c64-9e98-2601895031de	2026-01-06 17:12:02.071081+00	44.1	29.3	4199669	4199669
79d410bd-ef0e-49e9-9bcb-be2dcee4cdaa	2026-01-06 17:12:21.524465+00	32.2	29.3	4078021	4078021
549130bd-1d2d-4193-ad98-55d107540cdb	2026-01-06 17:12:22.228262+00	36	29.3	522901	522901
5d844c49-b86f-46bb-9705-c1eb1433dc77	2026-01-06 17:12:22.617229+00	36	29.4	171941	171941
100eb8c6-c0b7-4f73-abce-5c698c3370f5	2026-01-06 17:12:22.679674+00	36	29.4	5998551	5998551
4fa2d6ea-eed6-463a-8652-9c1a7680bf1c	2026-01-06 17:12:25.94357+00	42.4	29.3	3850114	3850114
c7a3a623-70d9-4873-88ab-ca21b189b4e4	2026-01-06 17:12:42.720342+00	51.4	29.3	4254127	114619
509ce7d1-7cb4-42f5-8dbf-5d3868d91918	2026-01-06 17:12:50.395715+00	40.3	29.3	3176097	3176097
782de628-fc66-4b6a-9805-3366e6257da9	2026-01-06 17:12:50.540067+00	40.3	29.3	4694972	4694972
d0b1be87-c55a-48cb-945c-f4bea49b562f	2026-01-06 17:12:51.864183+00	40.4	29.3	259296	259296
dae719ab-8a17-47f2-af42-5314ed7a0938	2026-01-06 17:13:02.094444+00	51.3	29.4	432787	432787
c106c47b-06e8-44c5-af93-1bf33e50b4fe	2026-01-06 17:13:21.530173+00	32.1	29.4	4248025	4248025
b6a11476-b032-4104-b92c-5c55a4b4051d	2026-01-06 17:13:22.350776+00	40.2	29.3	3804582	3804582
7044af12-edb0-4d6c-b4b1-0b64205cef5f	2026-01-06 17:13:22.639777+00	40.2	29.3	236218	236218
41e040de-f25f-49ad-91fa-30563c7793a3	2026-01-06 17:13:22.72068+00	40.2	29.3	236560	236560
f7b07610-bd33-4ae8-a83b-7f489ade93ea	2026-01-06 17:13:25.931552+00	44.1	29.3	3816415	3816415
a3334dcc-acc0-4247-851f-62b2fcd27f84	2026-01-06 17:13:42.760819+00	57	29.3	3797437	98616
0617400d-b528-41e8-ab73-1aee0c06c86d	2026-01-06 17:13:50.403838+00	33.9	29.4	3675443	3675443
00e05321-00b2-428c-9fc2-a7a67694d740	2026-01-06 17:13:50.532733+00	33.9	29.4	4499701	4499701
0d0845c2-41fb-41c3-b55e-0bbc815e3c2c	2026-01-06 17:13:51.779878+00	43.5	29.4	483838	483838
a9844b43-5a59-4055-a4f8-88e6eccd039f	2026-01-06 17:14:02.044771+00	53.8	29.3	4779111	4779111
02d12063-5734-44e2-ad3b-2a18cd433459	2026-01-06 17:14:21.595769+00	33.2	29.3	958463	958463
caae7e2b-bc7a-4c89-9799-7f1e0f3805ad	2026-01-06 17:14:22.369402+00	40.4	29.4	3921986	3921986
f7bffdeb-8bcf-4aa2-ad1d-a347f00b2e5c	2026-01-06 17:14:22.749239+00	40.4	29.4	4888296	4888296
47ecd64b-48f7-4bfd-9f45-994b4a90d860	2026-01-06 17:14:22.821556+00	40.4	29.4	300368	300368
6c980bbc-c77b-4c5a-8f5c-39c9e91c747b	2026-01-06 17:14:25.95714+00	52.5	29.4	4269254	4269254
cf862daf-b235-4f27-b71b-0832c105cff9	2026-01-06 17:14:42.803531+00	50.2	29.3	4234220	119524
799f26c4-138b-4c3d-9a40-88abdffb5d28	2026-01-06 17:14:50.385642+00	41.6	29.3	3764524	3764524
4d2fd237-a4c9-42cd-8337-29840a654d61	2026-01-06 17:14:50.523522+00	41.6	29.3	3332955	3332955
8daec17f-54c2-4d7f-b0d6-7bfbe17972cd	2026-01-06 17:14:51.720058+00	41.5	29.3	277232	277232
ba9cf73f-2ffc-480c-9a3a-08327315d015	2026-01-06 17:15:02.174298+00	53.1	29.3	5133103	5133103
81c9a200-1c6f-4380-9d3e-195f507af4db	2026-01-06 17:15:21.588539+00	27.9	29.4	4734026	4734026
669c06ab-0bf1-429d-ba31-c6e43aa9e6bd	2026-01-06 17:15:22.385875+00	43.9	29.4	4247373	4247373
08f54d50-4b01-4b8b-8b41-a0e826fd53ce	2026-01-06 17:15:22.673458+00	43.9	29.4	5068975	5068975
a9c5a864-888b-480e-b605-cb77b8bb42da	2026-01-06 17:15:22.73698+00	43.9	29.4	405879	405879
9c01db5d-6a77-4fc3-bf98-77411b0ee3a9	2026-01-06 17:15:25.958405+00	45.2	29.3	4521541	4521541
233779e5-ed28-4c22-b4b8-8a116be438ed	2026-01-06 17:15:42.729997+00	39.1	29.3	4746038	131694
1f33e7ce-910e-4648-8948-76fe1ac7cc70	2026-01-06 17:16:22.628005+00	45.8	29.6	4070596	4070596
a83c9d78-8de8-4196-9750-77ed3ab28adb	2026-01-06 17:16:50.50358+00	39.1	29.5	4745464	4745464
8c34b48c-950e-47af-be43-a094296cd6f7	2026-01-06 17:16:51.96853+00	68.6	29.5	3364430	3364430
13397d09-5ce4-4d9c-afec-399b72366c18	2026-01-06 17:17:22.663896+00	42.9	29.6	3007908	3007908
d783fdd6-69dc-4627-a47f-62367403d5f0	2026-01-06 17:17:50.646019+00	35.2	29.5	3391414	3391414
1f428aec-798c-42b0-bf4f-64e22055241a	2026-01-06 17:18:22.625712+00	39.2	29.6	269341	269341
b528e19f-5493-4c80-978e-e3d73dc68ebc	2026-01-06 17:18:25.987836+00	42.5	29.5	805225	805225
5fed93b6-1f91-4444-9a81-39cbfdec1570	2026-01-06 17:19:22.310159+00	36.5	29.6	4270571	4270571
63ce02c6-b8e2-4917-924f-274d69b0e7f4	2026-01-06 17:20:02.094941+00	49.3	29.5	4869482	4869482
85974358-d9c1-439f-a9c4-d38b14b3f89d	2026-01-06 18:08:22.245727+00	52	29.6	3802197	3802197
3aa46501-a1f1-47cd-a6b4-3210c2c7bc6b	2026-01-06 18:08:51.6819+00	39.6	29.9	4660396	4660396
84d89d5b-78c9-48d1-917f-6f4c8dace83d	2026-01-06 18:09:50.496388+00	38.1	29.7	4374356	4374356
a3471e18-8a9f-47c4-8625-e013ee296b06	2026-01-06 18:10:02.060306+00	45.4	29.5	5555804	5555804
07a7d462-fec7-4c55-8a77-b4421c5709db	2026-01-06 18:10:22.670318+00	43.5	29.8	2643995	2643995
388074b9-9871-4423-91f7-adb11ca74303	2026-01-06 18:10:50.75299+00	36.8	29.6	4625216	4625216
03e0ecdd-d180-4477-82d7-51e5a53a728b	2026-01-06 18:11:25.930198+00	43.8	29.6	2371303	2371303
896fbcdf-9a3f-4c3b-9a3b-a3e27f94f7f8	2026-01-06 18:12:21.557131+00	30.9	29.7	729509	729509
84dc4ad6-efdb-4779-a3d4-c732b1b728fb	2026-01-06 18:13:21.58042+00	32.9	29.7	4108650	4108650
a3735067-0cbe-41f1-9532-22e0aaf1070b	2026-01-06 18:13:22.791566+00	44.3	29.7	176789	176789
e5a68542-88ac-4f5b-abd3-2191a372c536	2026-01-06 18:14:50.572901+00	41.3	29.8	2843877	2843877
0d53e7e6-5b79-4f0e-a426-e8133bfc929b	2026-01-06 18:15:22.397691+00	36.1	29.9	2455289	2455289
d347d17b-628d-4706-8129-851a07663cff	2026-01-06 18:16:21.574902+00	30.8	29.7	4483199	4483199
78c6215d-2d98-45be-b420-2823dace3fb8	2026-01-06 18:16:25.93704+00	52.7	29.7	2253580	2253580
460f3196-962c-4f2c-a6b1-2e25e6666a8c	2026-01-06 18:16:50.671496+00	41.5	29.6	3152213	3152213
644c5ac3-fbbb-4c18-b352-a94ab63624c6	2026-01-06 18:17:21.60688+00	33.4	29.6	4646003	4646003
1e7064e7-72e1-4d2d-a2bf-b710747bfe43	2026-01-06 18:17:50.52425+00	33.3	29.8	1021130	1021130
b774e147-273e-409b-84b1-2b6aa2619e2b	2026-01-06 18:18:50.418663+00	31.3	29.8	784982	784982
aa965f02-4b32-46dd-9f4a-12d86c1c358c	2026-01-06 18:19:02.103069+00	48.2	29.7	420981	420981
82d14d42-3a17-4b7a-9680-13362ff4385b	2026-01-06 18:19:21.579815+00	31.7	29.6	4702925	4702925
65256654-669e-443e-90e5-467cd4fc4128	2026-01-06 18:19:22.345421+00	43.2	29.7	5629187	5629187
a552dd7f-7f71-41d1-8d03-b75720c0e902	2026-01-06 18:20:22.342205+00	42.9	29.7	481845	481845
6cb80a11-4b67-4f13-b876-73aa265e12d7	2026-01-06 18:21:02.083804+00	49.7	29.7	1919120	1919120
24e17f06-00ed-40c7-81b8-f6496e21c138	2026-01-06 18:21:22.760981+00	48.5	29.6	781775	781775
2046178b-9ccd-499d-8f25-7502f46100b6	2026-01-06 18:21:50.633549+00	30.2	29.7	4708445	4708445
00af8ed3-2c06-43b9-8e9e-3b68aca7f12b	2026-01-06 18:22:22.673422+00	46.6	29.8	4300290	4300290
5e5ba187-c3e5-4237-ab0d-e2fb207c87f9	2026-01-06 18:22:50.552147+00	36	29.7	3922837	3922837
cf4bdb37-fcf2-44d9-b7d5-da495cddd51f	2026-01-06 18:23:21.6064+00	33.7	29.6	4687581	4687581
720bfed3-54b4-41d1-b3ee-adbef204628c	2026-01-06 18:23:50.550869+00	30.9	29.7	3966112	3966112
f4b8738e-1fc7-4e88-9358-95d8c2fa0f23	2026-01-06 18:24:50.624098+00	38.3	29.8	507865	507865
0b9f4aa7-e5cb-4a79-ab11-27f235540da1	2026-01-06 18:24:52.169685+00	40.1	29.8	4585539	4585539
5985fedf-1e28-4274-9509-43af989bc3f5	2026-01-06 18:25:02.101028+00	54.3	29.6	747457	747457
345cb944-fddb-4fe8-bd95-da83841bbcb8	2026-01-06 18:25:22.71861+00	43.8	29.7	5884577	5884577
ba52946d-3fd4-4a73-9563-d2badb5c0507	2026-01-06 18:25:50.582637+00	34.2	29.7	4645866	4645866
96bda931-0809-4cca-b4b0-12711684c444	2026-01-06 18:26:22.898875+00	38.8	30	3922504	3922504
a83f4346-1ea2-4d8b-bf17-beab247b19af	2026-01-06 18:26:50.553623+00	43.5	29.9	858772	858772
595ee308-f64a-499c-93dd-6e590e6656ea	2026-01-06 18:33:43.939123+00	39.5	29.7	4623794	123558
da621da8-aa35-4de4-8a86-b25d338d688d	2026-01-06 19:00:44.323061+00	40	29.7	3816976	94742
6eefe3cd-267b-45fd-8fef-cae719dc966a	2026-01-06 19:26:44.746444+00	31.7	30	4004123	102932
3bc98cf1-2376-4aee-8eca-70241a7eb35a	2026-01-06 19:52:45.101772+00	48.1	30.1	4016706	106904
cfe99760-7e45-4a47-a9d7-6aadf260fd48	2026-01-06 20:14:45.42603+00	37.3	30	4081653	109052
19f1a18e-deb6-4fec-b449-349e2fd9bae9	2026-01-06 20:35:22.767187+00	43.4	30.1	3120061	3120061
503441fe-278c-4251-aadd-141a00343359	2026-01-06 20:35:51.813127+00	50.9	30	5309559	5309559
bb7c3b7d-c053-48e2-b9f1-e63ab0fea70b	2026-01-06 20:55:45.986883+00	4.3	22.1	1843	194
39c556a9-2f0b-44a5-ad60-becaff58a275	2026-01-06 21:24:46.439671+00	3.7	21.5	1484	303
5e5eee4d-1266-4f5e-a39e-9c9cfd0234d1	2026-01-06 21:53:46.734857+00	3.9	21.5	1221	194
925ed931-3018-4620-bee6-832f9eb4bc6a	2026-01-06 22:22:47.125365+00	3.7	21.6	1410	291
4edd8e81-5796-493b-b588-c433b98b154e	2026-01-06 22:51:47.436225+00	4	21.4	1219	156
f35723fe-c83e-41eb-aee5-0bf7613066b4	2026-01-06 23:20:47.75378+00	2.9	21.4	1260	192
d81a091f-9c30-4698-b8a1-80a2a25187c5	2026-01-06 23:49:48.176713+00	3	21.4	1731	332
97d1d6fb-c38b-45f4-be18-ae26bde5ea55	2026-01-07 00:18:48.493926+00	0.9	10.1	1445	22
c27abf1e-8b7a-4075-a62e-926630af2345	2026-01-07 00:47:48.923111+00	1	10.1	1351	18
51b8d382-a543-42e5-93a4-01450ee84b46	2026-01-07 01:16:49.29174+00	0.9	10.1	1627	30
99f65199-bfe4-450e-abbf-a978f0f24f00	2026-01-07 01:45:49.700034+00	1.1	10.1	1636	13
8250db57-0690-48b6-a706-9e0b80dfda8e	2026-01-07 02:07:00.612051+00	3.5	11	668688	668688
3ce1a01d-a917-4ea3-8307-dc7daf34f207	2026-01-07 02:07:00.857302+00	3.5	11	638437	638437
82729f1e-7d83-41dc-a51e-bb50fd64511d	2026-01-07 02:08:00.584809+00	2.1	11	689953	689953
5d357b8c-2a32-4894-8c0d-84ae427979ec	2026-01-07 02:09:00.845976+00	4.8	11	528500	528500
b4794029-4772-4878-b426-d6daf4487636	2026-01-07 02:10:01.054761+00	3.9	11	416633	416633
b2c3eaba-bff5-488c-87ac-36d0039a56f1	2026-01-07 02:10:01.327063+00	3.9	11	459566	459566
f634ba8e-ed1d-4c12-8b8e-9d587d652e71	2026-01-07 02:11:00.216487+00	2	10.9	590999	590999
52ff4920-9bda-4b25-ade2-9d9394f3996f	2026-01-07 02:11:00.730365+00	2	10.9	800979	800979
051fb801-9d37-447d-a90f-1867e247e57a	2026-01-07 02:12:00.684998+00	2.3	11	628284	628284
e584221a-86fa-4fb6-837e-c0980ffbd2a8	2026-01-07 02:13:00.296989+00	3.4	11	696179	696179
bd0b42dd-9e64-4761-92b6-0520920d5afc	2026-01-07 02:13:00.873328+00	3.4	11	369538	369538
83f49ebc-143e-4629-ae67-8dee2e368c18	2026-01-07 02:14:00.668969+00	2.7	10.9	748332	748332
957c8252-cc43-424b-ad5c-183074fb81c5	2026-01-07 02:14:00.846309+00	2.7	10.9	636250	636250
f6953f57-2a49-4aa4-b014-c801a3c5f3fb	2026-01-07 02:15:00.114705+00	2.4	11.1	9055	9055
353a4fa9-ff65-4bbc-b9b5-e7e16bebf93c	2026-01-07 02:15:00.857415+00	2.4	11.1	633924	633924
2a1bc8ef-cfba-4890-9d12-207071db5c36	2026-01-07 02:16:00.745178+00	2.3	11	1037535	1037535
efb86ae0-b4f9-4d8b-8c0f-e82c2d1e77db	2026-01-07 02:17:00.819862+00	2.2	11	650019	650019
3e20f994-7a43-46aa-9881-1a1dce115ad5	2026-01-07 02:18:00.852613+00	2.4	11	680009	680009
bb0bd7eb-ce1c-4ce9-95ce-23e41809c6c4	2026-01-07 02:19:00.137948+00	3.5	11	11538	11538
626fe0db-d7f3-41aa-88f2-2108fff26949	2026-01-07 02:19:00.703021+00	3.5	11	594357	594357
197fa8f8-ee83-4b77-955c-284f1a2a1ed5	2026-01-07 02:25:50.197098+00	3.8	11	40487	31507
e96afa5e-3eeb-4811-bf96-64def487d7d9	2026-01-07 02:44:50.457925+00	2.3	10.9	21966	14488
aee817ba-bce8-4e6f-985e-26f3e4c5d2d4	2026-01-07 02:58:01.04561+00	2.4	11	396318	396318
87c7a5d0-06ce-4eb2-bb41-fbd75a72f363	2026-01-07 02:58:01.265966+00	2.4	11	602741	602741
e38c54a3-fc55-4122-954e-b8f39739cd42	2026-01-07 02:59:01.270612+00	2.8	10.9	458469	458469
ac31c261-5cbd-489a-adc1-ef0d5e4351b6	2026-01-07 03:00:00.11731+00	3	11	8328	8328
db40312e-3896-4172-991b-149587495009	2026-01-07 03:00:00.258247+00	3	11	594602	594602
41b1ce92-b86b-42c3-aaae-b97f1ac7cbba	2026-01-07 03:00:00.797728+00	3	11	365102	365102
52e1089b-dfbb-4782-bbab-7dd43cfff114	2026-01-07 03:00:00.959483+00	3	11	537141	537141
2987c3cc-36a0-4d91-86df-d39ec9ed587c	2026-01-07 03:08:50.760846+00	2.6	11	19326	13975
9d910742-ba49-4f32-b295-acbfdb42053d	2026-01-07 03:18:01.041442+00	3	11	367166	367166
333175b0-9bca-4398-9d8b-b413367dbd9f	2026-01-07 03:19:00.72844+00	3.8	11	535218	535218
6c2c0059-4211-4b58-9e15-1636d23ac409	2026-01-06 17:15:50.30908+00	36	29.3	956994	956994
43afd413-cae1-4e35-9f93-3dd8b7934a60	2026-01-06 17:16:50.345094+00	39.1	29.5	3538630	3538630
02e41818-b282-4cc0-8c34-1b6fed230b37	2026-01-06 17:17:51.988639+00	43.3	29.5	2216825	2216825
8c233110-7559-4d9e-a302-47eb9bc4a46b	2026-01-06 17:19:02.070913+00	47.4	29.5	4514959	4514959
1f7840c9-350d-4f27-9ae2-ae200a574713	2026-01-06 17:19:50.585123+00	37.9	29.6	4226996	4226996
ff7a93ed-84d5-47a4-bf1f-460eb35a4735	2026-01-06 18:08:22.704943+00	52	29.7	220473	220473
e80a6e17-cb97-4b66-b173-df72a2ff5fe6	2026-01-06 18:08:25.927259+00	42.7	29.6	4661071	4661071
9195972b-fe04-47df-afd4-067a4d78b4f1	2026-01-06 18:10:22.532009+00	43.5	29.8	4003317	4003317
3fdaa9fc-5bca-45c1-8850-4df206c44242	2026-01-06 18:11:22.632822+00	49.1	29.7	4368698	4368698
62ee4aee-8ed2-4441-a8b0-b6a6a4c6eb0c	2026-01-06 18:11:50.585453+00	39.3	29.7	5636242	5636242
cfc80b98-859d-48fb-ab22-2f807be01fcb	2026-01-06 18:12:22.298893+00	40.8	29.7	4356908	4356908
baa3aa4c-262c-46e3-8953-7ad1f9016007	2026-01-06 18:13:22.682913+00	44.3	29.7	173553	173553
0adbb20c-00a9-4834-8bc3-b72a5b585968	2026-01-06 18:14:22.652032+00	36.8	29.8	468209	468209
b5918e2d-41ee-4185-a42f-c762cdde6521	2026-01-06 18:15:02.111401+00	43.7	29.7	4299589	4299589
869f6dc4-976d-493c-acd8-51f3fe75893c	2026-01-06 18:15:21.561458+00	32.5	29.9	3042328	3042328
88f2d522-5430-4987-853d-fdde0f8257c4	2026-01-06 18:15:25.955334+00	50.2	29.8	4447688	4447688
3013735d-bf7c-481b-b2e1-15c889788eb6	2026-01-06 18:15:50.536009+00	40.7	29.7	4058231	4058231
246cba02-0be2-4939-9f6c-902e0437ff78	2026-01-06 18:15:51.862263+00	71	29.7	286747	286747
23b628c5-0832-4ae5-8975-733a836adeeb	2026-01-06 18:16:02.11557+00	50	29.7	724284	724284
6f4de137-5ec6-4ae5-b56e-259a54575b48	2026-01-06 18:16:50.566716+00	41.5	29.6	3994210	3994210
402e66f1-531f-411a-b0f0-474d4ed53932	2026-01-06 18:17:22.881471+00	40.2	29.7	4402967	4402967
32736faa-13e4-4cb1-9ebd-a15e6c464546	2026-01-06 18:18:21.6037+00	30	29.6	1785523	1785523
9d80749e-626c-4efc-9168-cd7b55c089f2	2026-01-06 18:18:51.801679+00	43.1	29.8	4771372	4771372
24972bb6-28e4-47a6-807c-16427ad11a6e	2026-01-06 18:20:50.684754+00	37.1	29.6	818372	818372
29753546-9cbf-4114-9f23-0124de303076	2026-01-06 18:21:22.640929+00	48.5	29.6	317370	317370
670f8670-fc4d-47c6-9f3f-a7a25e56ec22	2026-01-06 18:21:52.094673+00	40.7	29.9	4643607	4643607
4ceeaa99-e7a3-4798-8cce-29cb6771fc21	2026-01-06 18:23:22.348425+00	41.4	29.7	4487200	4487200
10946c69-1fcc-418e-9d6a-f2160e008d3f	2026-01-06 18:24:21.554173+00	36.6	29.8	533771	533771
4136fb9a-4080-422f-bb78-eda876db7c3b	2026-01-06 18:25:21.580043+00	34.9	29.7	3534721	3534721
4bde1ae9-1e7d-40d0-95bc-227bf38a0c47	2026-01-06 18:25:52.241259+00	44	29.8	5757148	5757148
6573868e-e2c5-4177-bdc8-edd87573b99a	2026-01-06 18:26:50.451279+00	43.5	29.9	617235	617235
bffc065b-10a7-4a9b-95fc-94c4640f7bff	2026-01-06 18:26:51.715345+00	47.5	29.9	393631	393631
c8c61b0b-17a7-4ace-8c7e-6663f450451b	2026-01-06 18:34:21.53899+00	40.7	29.6	607254	607254
03b04dbc-d78b-45f1-ab66-99245cd624e2	2026-01-06 18:35:52.100953+00	40.5	29.7	3649360	3649360
f0c9db55-90f0-482f-ab30-6182a23bdc7a	2026-01-06 18:37:21.581195+00	41.9	29.7	6036652	6036652
057191c5-2d50-4c6b-95e5-1be8b1146b28	2026-01-06 18:37:25.946041+00	43.1	29.8	2180083	2180083
1c6d259d-1c9e-45b1-b528-da9199d93d08	2026-01-06 18:38:22.703029+00	37.2	29.7	210800	210800
b7eb646e-d2ef-41fa-a560-6ada3a44bf49	2026-01-06 18:39:22.355114+00	36.4	29.9	5273159	5273159
43d08797-f73d-4d07-a1bf-ef767f95d414	2026-01-06 18:39:25.948556+00	49.6	29.8	3642004	3642004
375cef90-dd57-4ba7-b22c-395b604df2c5	2026-01-06 18:40:02.088744+00	46.2	29.9	3513700	3513700
df2d9288-a551-426d-b2fa-b552b9339768	2026-01-06 18:40:22.684535+00	40.8	29.8	260458	260458
3f704d4d-9fb4-4499-a982-2157375ff120	2026-01-06 18:41:22.324564+00	46.2	29.8	4072221	4072221
effa65d1-7ee0-4ddb-8612-4df82317dbfb	2026-01-06 18:41:52.089259+00	37.7	29.8	1605172	1605172
fe6dd8d7-cc4b-4312-958d-df07d747b815	2026-01-06 18:42:02.057928+00	50.6	29.7	4331014	4331014
9b730147-da84-40d1-8610-025273f61153	2026-01-06 18:42:22.750007+00	40.1	29.8	3191542	3191542
adcc4c6c-7368-4df5-a0ab-95e844fe5527	2026-01-06 18:42:50.36891+00	38.8	29.7	5556168	5556168
5007b7ba-5d12-4c8b-87fb-24148bf5855f	2026-01-06 18:43:22.741811+00	42.3	29.8	5045694	5045694
d06ff723-d7cf-4d66-b12d-bceb6e2f059f	2026-01-06 18:43:50.381116+00	40.3	29.7	4450186	4450186
fb694e9b-3b5e-4900-a9c4-254a9a3e4c79	2026-01-06 18:43:51.798528+00	40.4	29.7	313721	313721
93bae2a6-da94-499c-9c8e-59d5ceb2725e	2026-01-06 18:44:50.548855+00	37.6	29.8	458030	458030
9135a1d9-89dc-4f83-88db-44eee9cdc4d7	2026-01-06 18:45:22.224758+00	49.9	29.7	4031540	4031540
58e05c51-d144-4274-896a-5636c760651a	2026-01-06 18:45:25.933557+00	47.7	29.8	1283591	1283591
ddc031a3-0d32-4966-8d3f-74f37b8dff70	2026-01-06 18:45:50.436024+00	42.3	29.8	4147819	4147819
011588cc-4cf7-4821-9f46-8767bd07ec2a	2026-01-06 18:46:50.515866+00	36	29.8	3236092	3236092
1a851a0d-7eb1-467b-9a46-83dae27280a0	2026-01-06 18:47:02.123261+00	52.9	29.7	5006817	5006817
1703c1c6-c8ea-41c6-8c75-d645451ad00f	2026-01-06 18:47:22.553909+00	45.2	29.8	322257	322257
a5a618e6-790a-4765-83b7-6411d0b89cf9	2026-01-06 19:01:44.36199+00	32.9	29.8	4307596	114726
e03ad195-386d-487d-b638-be837df3126c	2026-01-06 19:27:44.775+00	43.1	29.9	3926434	103885
ec082ee7-e228-4265-a0a9-46bf54d9fc9a	2026-01-06 19:53:21.523929+00	35.2	30	843707	843707
6bd44853-8ffe-4d09-a916-a45e66405c8a	2026-01-06 19:53:22.630171+00	38.3	30	317756	317756
c6af074e-023f-496b-b2aa-6b93c066dcf6	2026-01-06 19:53:51.924818+00	71.6	30.1	2916933	2916933
7ed5b015-af63-4a95-a7ee-449a0cf54e36	2026-01-06 19:54:02.080196+00	49.5	30	3957385	3957385
e1498079-b3cf-434d-ae10-dfff8dcc088f	2026-01-06 19:54:22.643665+00	43.8	30	4252054	4252054
b8fcb1e1-6499-47fd-9f90-a188811442cf	2026-01-06 19:55:02.096248+00	50	30.1	5304030	5304030
2fec43d7-33d4-4e62-b45a-3c4ebc8d22e9	2026-01-06 19:55:50.575595+00	39.7	29.9	2960194	2960194
3ece6777-24b4-4be4-bc28-99248ef0c213	2026-01-06 19:56:22.661637+00	49.6	30	207977	207977
1344b749-e6ab-40a6-9083-365709bf30bc	2026-01-06 19:57:02.095683+00	48.2	30	4191922	4191922
7b84eccd-b26e-4235-a14a-0951d4235e1c	2026-01-06 19:57:21.60311+00	33.7	30	3351831	3351831
3e168047-d501-4c3a-ac3d-9e3f114ec6dd	2026-01-06 19:57:25.859179+00	42.1	30	950977	950977
a6f250ab-ff45-4f91-b5d7-3e8fb26d7194	2026-01-06 19:58:21.555952+00	33.9	30	479362	479362
ddc6f098-53f3-4d40-b2e2-f6f086035bb2	2026-01-06 19:58:22.358539+00	39.9	30.1	4691376	4691376
58193fe9-25f0-4043-b88f-b0bbe13c69da	2026-01-06 19:58:50.526581+00	39.6	30.1	2847678	2847678
cf427397-dc85-482d-8340-15f1c247de32	2026-01-06 19:59:02.105855+00	46.6	30	4448826	4448826
9a4afa40-238d-47e9-8dd4-331104b5fa7b	2026-01-06 19:59:22.630213+00	40	30	246229	246229
8dc8e804-b004-48a8-bb12-08e1a7218c48	2026-01-06 19:59:25.893883+00	55.8	30.1	3130831	3130831
42e87098-1fb4-41ce-8da5-2ce94c4b3cd5	2026-01-06 20:01:22.740551+00	38.8	30.1	427634	427634
932f9ede-f023-41e4-bfaa-32a97dfa024d	2026-01-06 20:01:50.519295+00	40.2	30.1	4432300	4432300
4e1ce83a-109a-4126-a69a-45183f636023	2026-01-06 20:02:22.654332+00	36.8	30	432264	432264
9cad55aa-dcce-43df-8ce7-01739e7b7152	2026-01-06 20:02:25.937301+00	58.1	30.1	2487992	2487992
8f0adbe0-5c2a-4b38-8610-7dd8ad2e346d	2026-01-06 20:03:22.844123+00	43.3	30	5392213	5392213
80569ad3-bc97-4ab1-906f-95651481802e	2026-01-06 20:15:22.727298+00	45.1	30.1	285380	285380
dbd53017-399c-4712-b105-78c44b77a5ae	2026-01-06 20:15:50.635949+00	44	30	4515651	4515651
c49d0694-d287-4e92-969d-c1cb72dc158b	2026-01-06 20:16:02.069359+00	49.1	30	4912756	4912756
98c429fd-a63b-4f6f-8ec8-1920fbc62aa3	2026-01-06 20:18:21.594256+00	32.8	30	3622931	3622931
7f0e4fc8-f238-4d7d-a309-2632a75810ac	2026-01-06 20:18:22.699391+00	43.9	30.2	4281671	4281671
b05bfbb0-515b-4bdc-8bcc-07aa7aa44376	2026-01-06 20:19:22.717651+00	43.4	30.1	4397044	4397044
cef6b04f-a7f6-4d25-9ae5-28945f66f26f	2026-01-06 20:19:50.459119+00	42.1	30.1	4008670	4008670
0a145350-e5e7-4f5c-bd6b-fd9c410b7099	2026-01-06 20:20:22.347293+00	48.4	30.1	3035362	3035362
5d639439-07b1-4fbc-8e64-90f4fc6df3a2	2026-01-06 20:22:21.51762+00	29.9	29.9	978330	978330
ed1d504d-dac0-4f0e-bdef-32a22e0405f1	2026-01-06 20:22:22.281282+00	44.3	30	4074424	4074424
f1930b0b-b8da-4aaf-ae4e-68d58607b47f	2026-01-06 20:22:50.535398+00	39.3	30.1	6802700	6802700
f051a899-b22e-42aa-876c-19518005750d	2026-01-06 20:23:21.555922+00	34.2	30.1	3680741	3680741
f5da40d3-d374-4137-8c82-02eeb28b9af1	2026-01-06 20:23:50.567555+00	42.4	30.1	2726285	2726285
e6522549-b70b-417b-86a3-56e5d49e92ee	2026-01-06 20:24:21.558965+00	37	30	606316	606316
00665a17-4e93-4b76-9753-beb274cb6b24	2026-01-06 20:25:22.619905+00	41.8	30.2	3418760	3418760
b66a41ad-c2fa-4e52-90c3-1d6be3addfbe	2026-01-06 20:25:51.9518+00	40	30.1	4074780	4074780
0d7a6a82-e41a-412b-82df-3002e390381d	2026-01-06 20:26:21.613492+00	31.9	30	5236299	5236299
82224afe-b1d3-44a9-ac0e-613bb4f53af8	2026-01-06 17:15:50.405608+00	36	29.3	4368402	4368402
ad3d31e3-089b-485d-bd0a-0d35055310dc	2026-01-06 17:16:22.731182+00	45.8	29.6	3432257	3432257
aaed8fe8-7e4e-4798-808f-38d15553a84d	2026-01-06 17:17:22.738497+00	42.9	29.6	468347	468347
de22d32a-fa6c-4dc2-9005-3bd867f3f5ca	2026-01-06 17:17:50.578261+00	35.2	29.5	4626568	4626568
d22f3728-58ba-4a3d-bf3f-69007e36ad3b	2026-01-06 17:18:02.08875+00	51.7	29.5	654391	654391
8390afd3-fb0d-405b-878a-d0458c2a9037	2026-01-06 17:18:21.528254+00	29.4	29.6	821636	821636
b5ffad27-5689-47ed-8c5f-d389b54c67fd	2026-01-06 17:18:50.603398+00	37.5	29.6	4012691	4012691
38cedb8f-31cf-481a-9c16-8bcef35364c7	2026-01-06 17:19:51.989071+00	70	29.5	5143928	5143928
0c541642-3fbf-448f-9250-1a4ab80a6c3b	2026-01-06 18:08:22.783768+00	52	29.7	2790691	2790691
ca1079de-6969-4c02-a4fb-c22095e825ae	2026-01-06 18:08:50.510482+00	36.1	29.9	3401596	3401596
3b3b7ef5-09ee-4c5e-ab5c-3f2c109a3575	2026-01-06 18:09:21.590729+00	31.6	29.6	2636502	2636502
c5d740af-347e-4594-856b-4e679bf9dfd8	2026-01-06 18:09:50.597749+00	38.1	29.7	4326907	4326907
efee325a-c058-40b4-8b9b-a9bcfcb6e7c0	2026-01-06 18:10:21.531666+00	33.3	29.7	3185544	3185544
05c5c167-ee49-4ab8-8366-7ffb7d6d3c36	2026-01-06 18:11:22.740093+00	49.1	29.7	2434231	2434231
608c2118-70b5-4ed4-b22f-3791a5011c8e	2026-01-06 18:11:50.493342+00	39.3	29.7	3754400	3754400
e4001e7e-513a-4060-a170-9c7c6302df1a	2026-01-06 18:12:02.063907+00	52	29.7	653120	653120
17934400-796e-4819-b4f7-62085c04f5fe	2026-01-06 18:12:22.657447+00	40.8	29.7	4365054	4365054
ae4521c5-97da-46c6-a2f0-57b8a49d1cf1	2026-01-06 18:12:50.654997+00	31.5	29.8	4013373	4013373
d4b7b5ba-b103-4541-9f5b-d4707b85ee32	2026-01-06 18:34:43.945202+00	37	29.8	3278432	92179
5b3fcf86-a01c-46d6-a6ed-91ae180d1202	2026-01-06 19:02:44.380595+00	42.7	29.7	3909093	102710
ac791eb5-b817-4193-96e3-59bed80494cc	2026-01-06 19:28:44.786174+00	45.1	29.9	3826187	100323
0f52dc96-f9ab-45b8-81bd-b8466501637f	2026-01-06 19:53:45.101402+00	38.5	30.1	4283366	112351
9087cadd-0ed9-4b9c-bb55-8675ce83d3b2	2026-01-06 20:15:45.397132+00	37.8	30.1	4591115	115005
1f3bbf34-dd06-4931-8793-d8ebd00eb0bc	2026-01-06 20:35:45.774728+00	43.3	30	4180220	105557
942ac3c3-4bc5-4d12-8aac-a6764e8c8e48	2026-01-06 20:56:46.046388+00	3.9	22	1535	181
2a4a9b4c-1e97-4acd-bf29-ba55d0f6c81b	2026-01-06 21:25:46.39857+00	4	21.5	1818	306
fae2cae0-0ab1-4e63-b09d-c6e7d15bcb29	2026-01-06 21:54:46.763379+00	3.8	21.5	1343	194
3bf1345a-fad7-4e9f-92e0-bff5b285752a	2026-01-06 22:23:47.140808+00	4.2	21.5	83768	4441
95b72613-9b09-49f9-a614-a1b33f28ab95	2026-01-06 22:52:47.45714+00	3.9	21.5	1302	164
e2f323b3-4695-479a-ac87-847b1b5fb83f	2026-01-06 23:21:47.814224+00	3.2	21.4	1314	196
b5fca064-8bce-47ce-a9e7-e0bf22b05f37	2026-01-06 23:50:48.142271+00	2.8	21.5	1563	296
68788c24-9b21-4ba5-b273-065b3bfa66c4	2026-01-07 00:19:48.495386+00	0.9	10.1	1207	22
edb47aa4-2512-43d9-afcc-af399f250fd4	2026-01-07 00:48:48.90369+00	0.9	10.2	1314	22
ce2fcadc-882d-4f64-a84d-64dc85f2e582	2026-01-07 01:17:49.311229+00	1	10.2	1526	23
9f1a9cee-d6e6-4d38-a2c2-cce5d973ddf7	2026-01-07 01:46:49.725023+00	0.9	10.2	1904	23
bda9cffc-740f-43dd-9608-6f80cbb44b3c	2026-01-07 02:07:49.97564+00	2.5	11	46248	29387
01177646-b067-4085-baa0-63b58647bf8b	2026-01-07 02:26:50.246429+00	3.7	11	44133	26323
42903538-ff7d-4050-820e-e57209d30f08	2026-01-07 02:45:50.463299+00	1.7	10.9	28065	13651
3b0d676a-aa3d-4bd1-96b8-7b6625559d7c	2026-01-07 02:58:50.633216+00	4.8	11.1	18197	25401
31190e40-d5e3-4461-95e6-6c37aef450c7	2026-01-07 03:09:00.852714+00	4.8	11.1	639529	639529
769fc298-2b08-4c9c-8ba0-fc3678dd7700	2026-01-07 03:09:01.001829+00	4.8	11.1	491388	491388
bc79ffa5-c5f3-4d04-9c99-ba19330c9eed	2026-01-07 03:10:00.181516+00	2.6	11	628777	628777
ee13225b-e0f8-4b43-a253-217987c17193	2026-01-07 03:10:00.755633+00	2.6	11	161415	161415
a7b0db2d-2182-4f07-9d0e-528983c78bc1	2026-01-07 03:11:01.043473+00	2.8	11	300293	300293
fbe9b729-67e3-4b96-881e-fcfd3a104789	2026-01-07 03:12:01.134165+00	3	11	549583	549583
05300b7c-db44-4914-b842-a3e8338eebbb	2026-01-07 03:13:00.950959+00	6	11	416861	416861
ca0c785b-44a5-4193-a521-687427044dc7	2026-01-07 03:14:00.263265+00	5.5	11.1	11427	11427
615086d3-0750-4e5d-9de8-bb0f48e201de	2026-01-07 03:14:01.015325+00	5.5	11.1	516563	516563
a9ffaf3f-22cd-4f06-b7fa-5e9e5fc72cef	2026-01-07 03:15:00.9378+00	3.2	11.1	545555	545555
69d6c2fd-c6e6-4226-afbf-350226ae4942	2026-01-07 03:15:01.166238+00	3.2	11.1	552911	552911
d768728c-07c6-42ed-bc39-fbaad0e13658	2026-01-07 03:16:00.082363+00	2.7	11.1	7661	7661
e8022a69-a8ef-4052-96df-4d01ea468d7f	2026-01-07 03:16:00.74754+00	2.7	11.1	692956	692956
5efd21ef-8a3c-416c-8688-9c9bb6dac3f6	2026-01-07 03:17:01.219386+00	4	11	457381	457381
554a2553-a9d9-4e46-9cfa-103d8aea92e6	2026-01-07 03:18:01.15085+00	3	11	599486	599486
68e7462e-8cb1-4f98-a242-b70816811d60	2026-01-07 03:18:50.906281+00	2.4	11.1	16338	9817
100c1475-ed44-4c82-bac9-cc9d482bfc19	2026-01-07 03:19:00.665869+00	3.8	11	672395	672395
001a396b-37eb-4fab-98a8-6f50704e1882	2026-01-07 03:20:00.833721+00	2.5	11.1	753241	753241
c7258271-26e5-4877-9fc7-72a6fe375ed5	2026-01-07 03:21:00.909903+00	2.6	11	665902	665902
2f2ee513-c718-4991-a8b2-17fe2d0b5e42	2026-01-07 03:21:01.087191+00	2.6	11	594655	594655
7df451ce-2249-45b4-a910-74b2bc23c19b	2026-01-07 03:22:00.098995+00	2.8	11.1	8059	8059
e953799e-1130-420b-af88-b47d98afc8d2	2026-01-07 03:22:00.714946+00	2.8	11.1	648382	648382
2f8a9555-d318-43b9-946d-74c2cbc90290	2026-01-07 03:23:00.956456+00	3.2	11	542087	542087
84f362ba-b857-43f8-8a0a-9ae071131d7b	2026-01-07 03:23:01.35294+00	3.2	11	482989	482989
db6a50e3-ee7f-4105-97ab-4fe5053e550a	2026-01-07 03:24:00.13133+00	2.5	11	8509	8509
03d4ce0a-f630-4e67-9f6e-a3e6f57baf65	2026-01-07 03:24:00.995559+00	2.5	11	413285	413285
f8c1a1cf-3f23-41e0-b997-ea4c2e9cb249	2026-01-07 03:25:00.966999+00	3.4	11.1	541396	541396
47c662d4-6c02-45b9-a174-10d6880b12e1	2026-01-07 03:26:00.807398+00	2.8	11	803861	803861
c4d7267e-4d30-4967-99ac-2d067f99f7bf	2026-01-07 03:27:00.072954+00	2.6	11	8780	8780
dcdccc0c-f4fe-4b83-b669-8922177ef8ed	2026-01-07 03:27:00.924545+00	2.6	11	483231	483231
f09c3d51-8aba-4117-b4e4-10672e8270e2	2026-01-07 03:27:51.033181+00	3.4	11	15615	15653
da1122ec-08d5-442b-833f-8c14d2e9b4d0	2026-01-07 03:28:00.182407+00	2.6	11	9128	9128
497fafc5-920e-4963-8a31-255cd503293b	2026-01-07 03:28:01.008627+00	2.6	11	548377	548377
acd2b105-bd5c-40d2-8d23-b382f4a07b72	2026-01-07 03:29:01.019219+00	4.7	11	252186	252186
2526316d-c786-43ff-885a-9bb8475f6d59	2026-01-07 03:30:00.80437+00	2.8	11	657393	657393
57d7e13e-7c14-4bce-a9af-ae317906f1f9	2026-01-07 03:31:00.943393+00	2.5	11.1	544319	544319
a0fb5147-f9e8-4963-9d67-713d8aece740	2026-01-07 03:34:51.121503+00	5.3	11.1	15550	10330
898872b0-ed04-4f01-adef-cb494aee92e6	2026-01-07 03:42:51.22108+00	4	11	16208	9867
07413412-70ad-4b41-aa27-58d81d776ea2	2026-01-07 03:46:01.098145+00	2.7	11	475581	475581
f622c937-6174-4c41-a637-a60ada759440	2026-01-07 03:47:00.318925+00	3	11.1	732098	732098
5406a817-1a5c-4e84-81e3-146df7935560	2026-01-07 03:47:00.906281+00	3	11.1	650508	650508
e91e5e1d-c5bd-4cf5-b046-f5222e56f240	2026-01-07 03:48:00.630994+00	4.3	11	697746	697746
b7218dee-390c-4231-a00a-2331e12a2b07	2026-01-07 03:48:00.896118+00	4.3	11	774639	774639
ff356fff-2335-43df-991d-468afaebed34	2026-01-07 03:49:00.08091+00	5.9	11.1	9064	9064
3aff9744-abdf-49b8-91d5-e424827d7de9	2026-01-07 03:49:00.878165+00	5.9	11.1	385936	385936
c2443df2-d06a-4bb9-a7ff-840a1600504e	2026-01-07 03:50:00.236887+00	2.8	11.1	790350	790350
928ab92c-8c5f-4192-ab12-3452d9740e4b	2026-01-07 03:50:00.882098+00	2.8	11.1	576785	576785
33020e3e-d303-4137-a9d0-14e4f00d218d	2026-01-07 03:51:00.906235+00	2.4	11.1	685020	685020
92e17601-78a1-4807-a54f-fc9e23492b0c	2026-01-07 03:52:00.85065+00	2.6	11.1	723664	723664
9af9dfb8-b1c5-44f1-9078-fd5f72b5438c	2026-01-07 03:53:00.988037+00	2.4	11.1	516495	516495
afa31c6c-0efe-45af-abea-2b4d8d0afd34	2026-01-07 03:53:51.376613+00	2.3	11.1	14651	16002
73ee98b6-b30f-470a-a6fa-5d2a616d1ae1	2026-01-07 03:54:01.054445+00	3.1	11	603564	603564
2dee536a-4ed2-4f10-b62d-6474b89bea91	2026-01-07 03:55:00.106989+00	2.4	11	9497	9497
d917cbbf-1c3f-4755-8385-b639b73af2d6	2026-01-07 03:55:00.699368+00	2.4	11	849195	849195
8bfaa749-4a4b-4b20-bf97-a612a7f07e51	2026-01-07 03:56:00.800191+00	2.9	11.1	225145	225145
18cf0b71-14ca-4173-822b-b5dd79281ac2	2026-01-07 03:57:00.787471+00	3.6	11.1	700815	700815
d7eb0446-a33d-4985-899a-d2d9ab8f9432	2026-01-07 03:57:00.963761+00	3.6	11.1	626509	626509
2ca18f04-5c1b-403b-8d17-988d3e9dd03e	2026-01-07 03:58:00.09699+00	3.5	11.1	8733	8733
587e48c6-ae91-46d8-bf09-cbcca94a48fb	2026-01-06 17:15:51.654517+00	38.4	29.3	4694555	4694555
019e3817-50f3-4ad8-aab8-0265901f79c7	2026-01-06 17:16:21.542266+00	31.7	29.3	942090	942090
72ca53cd-5647-4fbd-820c-03371f085ed4	2026-01-06 17:16:22.27526+00	45.8	29.6	5546508	5546508
e4409b19-0eaf-4c20-9d70-8923b7c9424a	2026-01-06 17:16:25.934572+00	55.5	29.4	3653363	3653363
fc9dc38b-ed11-4746-889c-583a8f895b46	2026-01-06 17:18:22.302831+00	39.2	29.6	6042658	6042658
1d864b03-36ab-45d5-b24a-6a5b6aaab0e5	2026-01-06 17:18:50.497137+00	37.5	29.6	4111054	4111054
29ebd5e6-1b11-402a-a40d-4856daa05ee0	2026-01-06 17:19:22.698+00	36.5	29.6	354295	354295
6602549f-0ce9-4de8-a26a-cb548e15e33b	2026-01-06 18:08:43.552468+00	56.4	29.8	3843597	100715
e45d3369-5082-49c8-aecc-623af53a4733	2026-01-06 18:34:52.043588+00	42.8	29.8	2030160	2030160
66aacb07-898c-4b73-92b3-d0a2b879e0ea	2026-01-06 18:35:22.313737+00	45.5	29.8	798551	798551
08d37763-ebc4-4c0e-9819-e178380041cb	2026-01-06 18:35:50.604571+00	41.9	29.7	3384839	3384839
6046fa5e-fc31-4c1c-a427-2c5a771ec2eb	2026-01-06 18:36:25.928379+00	45.8	29.7	1626253	1626253
02469a16-be01-40db-a477-68d243807bc7	2026-01-06 18:37:22.326361+00	42.8	29.9	4397249	4397249
dbdd5a31-79fc-4fb5-a668-73b2d16b2cc8	2026-01-06 18:38:02.110131+00	43.3	29.8	562312	562312
13f540e6-fe4d-43d1-ad7d-e9beb179be22	2026-01-06 18:38:25.945153+00	41.3	29.7	4472994	4472994
66057bf7-de97-4c87-b8d4-3654c1f8044f	2026-01-06 18:38:50.33907+00	35.5	29.8	5814473	5814473
7da6c864-45cb-4292-9d31-72c966c2835f	2026-01-06 18:39:21.691865+00	44.2	29.7	3054559	3054559
e1657b69-b6e8-4a11-a917-ad011364e293	2026-01-06 18:39:22.656257+00	36.4	29.9	799542	799542
8e2ec6b2-5f3e-4847-9d0d-ff0d8e43bc54	2026-01-06 18:39:51.943494+00	72.3	29.7	453473	453473
f619b8dd-af56-4c82-8efe-10abde3f2a9b	2026-01-06 18:40:51.755679+00	46.3	29.8	373037	373037
35c32610-f454-4db5-bd0a-a7b078bd173e	2026-01-06 18:41:22.781133+00	46.2	29.8	3216856	3216856
bdead4d7-18f1-46bb-abb4-5b4a47f0d27e	2026-01-06 18:41:50.451958+00	43	29.8	3394963	3394963
418e79b6-0351-4839-a0fa-f8996eaef4e0	2026-01-06 18:44:21.561559+00	37.7	29.6	4944939	4944939
5e6a8a9f-8799-4378-a832-cbfee7be07bc	2026-01-06 18:44:22.351687+00	37.5	29.7	3399832	3399832
9830be64-83b3-4f6b-9de0-2713b024bb8f	2026-01-06 18:46:02.042584+00	47.8	29.8	5103923	5103923
2c173100-f576-4b5b-b1bf-f3b389e17018	2026-01-06 18:46:21.502693+00	41.8	29.7	3934949	3934949
f2d21b04-c5bd-4bd4-aaed-433e679c0ce5	2026-01-06 19:03:44.441126+00	38.7	29.8	3482748	85855
3b8dbd03-24cc-4b26-8ef6-bcbb5a25ac00	2026-01-06 19:29:44.77943+00	43.5	29.9	4282033	113067
b404ee9f-ecf1-4961-872c-3651a0b1c743	2026-01-06 19:54:45.094154+00	39.9	30	4150136	104577
66c96b55-b64e-4e7d-b269-b82d837e05bc	2026-01-06 20:16:45.421484+00	38.8	30	5995899	178982
657d1c46-d963-42bd-bf3a-84d61a9b80b4	2026-01-06 20:36:21.50447+00	33.1	30	2773815	2773815
bdfb3856-d345-497d-8653-b22d526de54e	2026-01-06 20:36:22.124285+00	43.6	30	5166118	5166118
eaa2f542-8e84-4fab-9ee8-1d17bc0a298a	2026-01-06 20:57:46.064911+00	3.9	21.7	1518	187
72890781-7ddf-4e65-84f3-8299dac5b8e6	2026-01-06 21:26:46.414989+00	3.7	21.5	1741	298
bbf163bc-72b6-4110-b2f9-6051764ea023	2026-01-06 21:55:46.752029+00	4.2	21.6	1569	190
c58a798b-1f82-4766-9cad-220c613d4fe5	2026-01-06 22:24:47.157811+00	4	21.5	1757	287
33702f29-951c-4dee-9d29-f72977a03934	2026-01-06 22:53:47.47214+00	4	21.5	1217	164
22b312f6-c17f-405d-bc4e-4fbe62ebcf6d	2026-01-06 23:22:47.793433+00	2.7	21.4	1257	201
a1ec0e28-72f3-40ee-aa01-f272f6e2dfd4	2026-01-06 23:51:48.159452+00	3	21.4	1435	299
0feed09c-6fa4-4bda-8e3a-b0267d98f16f	2026-01-07 00:20:48.500488+00	1	10.2	1168	17
87667422-f3b5-4eab-89f9-d2f063507c1e	2026-01-07 00:49:48.933265+00	1	10.2	979	17
3f0a0264-7bcb-4b44-a0fe-407cd332b8e7	2026-01-07 01:18:49.318373+00	0.9	10.2	1216	9
30005efa-3df0-4986-93ff-3b7050f70dde	2026-01-07 01:47:49.752238+00	1	10.2	1559	23
1f913976-7a61-4ad5-a753-c162adda5d2a	2026-01-07 02:08:50.026904+00	6.2	11	44738	26639
beb60d7c-313a-4aa9-bece-8baab5668adb	2026-01-07 02:27:00.963967+00	5	11.1	502051	502051
a06e824e-9d0f-434d-89b5-468d90a12cd8	2026-01-07 02:28:00.076855+00	3.6	11.1	8413	8413
9ae5ae75-4663-4a45-9d40-45df9505aa83	2026-01-07 02:28:00.681133+00	3.6	11.1	479410	479410
82e5c32a-59d1-4c58-aae4-3e49fbce2797	2026-01-07 02:28:00.941112+00	3.6	11.1	552421	552421
58198ce7-a7ed-46d2-8c9d-c42ae0d00dfb	2026-01-07 02:29:00.875707+00	3.2	10.9	572220	572220
929ce1d3-2631-40db-8579-41dcec09d88e	2026-01-07 02:30:00.823957+00	3.1	11.1	740654	740654
008c398b-1989-485a-bd40-866f9d5aee91	2026-01-07 02:30:01.169075+00	3.1	11.1	330107	330107
cab8ff1e-b234-4a62-a08f-4aa236625eb1	2026-01-07 02:31:01.012325+00	2.8	11.1	644121	644121
ff5e5cec-ec68-4361-9d98-7d7c9c4cc29b	2026-01-07 02:32:01.013073+00	3.1	11	530178	530178
cce919e1-6d86-4f2d-b34b-37777b5dcff8	2026-01-07 02:33:00.06438+00	6	11	8026	8026
dcd3d504-ca8b-41d2-b303-1712b9a9df95	2026-01-07 02:33:00.77448+00	6	11	672833	672833
33064750-9486-4970-8952-0a1db0bffcf1	2026-01-07 02:34:00.973694+00	2.2	11.2	626430	626430
75ca3fc0-ce64-401b-bdb7-09f308f81dcd	2026-01-07 02:35:00.77421+00	2.4	11	706823	706823
a9d5eca4-6ef9-4685-981e-2a58cd789179	2026-01-07 02:35:00.98939+00	2.4	11	577661	577661
b373ad1b-8065-4655-9231-2381c6742056	2026-01-07 02:36:00.349067+00	2.7	11	649396	649396
86457d35-9425-40dc-a0b1-50fb7730953b	2026-01-07 02:36:00.982179+00	2.7	11	551073	551073
090a2c26-f874-409e-a18b-6783f95b56a0	2026-01-07 02:37:00.234268+00	2.9	11	446534	446534
d4e73092-b0e5-4ac6-b2c8-c8555585298b	2026-01-07 02:37:00.699509+00	2.9	11	635113	635113
30d76c5b-bf48-456d-9fa1-0f37a45695d2	2026-01-07 02:38:00.105364+00	2.7	11.1	8837	8837
a56158d2-be92-48e4-b6f6-8226276b7b2e	2026-01-07 02:38:00.691639+00	2.7	11.1	925354	925354
8cee4a4a-b3d0-4358-9300-4adafd1b02f4	2026-01-07 02:39:00.030346+00	2.5	11	8781	8781
6c866776-dd28-4743-a2a9-3c173b7aa62a	2026-01-07 02:39:00.727153+00	2.5	11	653720	653720
7e5b1b07-2558-4263-90b1-0e17719bf4a3	2026-01-07 02:40:00.902067+00	3.8	11	308820	308820
112bb511-c85e-412d-afb2-319787e7b563	2026-01-07 02:41:00.696462+00	3.1	11	811092	811092
768082d1-23d0-4806-87d6-d1055fc9ae43	2026-01-07 02:42:00.618346+00	2.8	11	777236	777236
c5746e04-ca24-4544-ad68-6be07f91d1c9	2026-01-07 02:42:00.804983+00	2.8	11	587985	587985
75904ae6-9965-4c3f-a925-1ac2bccc59da	2026-01-07 02:43:01.055771+00	3.9	11.1	402655	402655
9df43472-0128-4a87-ae96-5717a8963cea	2026-01-07 02:44:00.71105+00	3.8	11	584420	584420
a259ef63-0148-4f06-b404-9857ddbc5f6c	2026-01-07 02:45:00.192812+00	2.4	11	604697	604697
5fc029e4-624b-47e8-b999-3eccd832df01	2026-01-07 02:45:00.647234+00	2.4	11	611271	611271
22f525b8-ec91-44ee-8c6d-a0c2a19b0abd	2026-01-07 02:45:00.857199+00	2.4	11	587519	587519
54fef43b-545c-4dd1-b96e-2d7b9d81a065	2026-01-07 02:46:01.020448+00	3.4	11	329787	329787
ab3de23d-3b59-4456-a07f-339286a2af18	2026-01-07 02:46:50.490309+00	2.7	11	26028	13539
70fb6a67-4f4f-4707-811e-f2fbeed2cc1a	2026-01-07 02:47:00.272541+00	3.2	11	352197	352197
47682c5e-4c61-4178-8776-39979e3863a9	2026-01-07 02:47:00.707993+00	3.2	11	569494	569494
d6dc1bac-7b0e-4e22-95f2-d97080ed1721	2026-01-07 02:48:01.079915+00	2.8	11	562088	562088
8ee4c2eb-88be-4adc-b304-f228659c9ad9	2026-01-07 02:49:00.221803+00	3.1	11	551806	551806
32011cb7-44e3-4036-85e6-492d7889771b	2026-01-07 02:49:00.725264+00	3.1	11	759287	759287
6ba156cd-b1fd-4c15-9669-e404688fd091	2026-01-07 02:50:00.107581+00	3.3	11	7225	7225
97284c37-f004-46f8-b6e8-f0f5d640a0da	2026-01-07 02:50:00.736261+00	3.3	11	725837	725837
a85f9930-83db-4694-b4dd-06029c5209ae	2026-01-07 02:51:00.172225+00	2.4	11	719246	719246
235608d7-0a47-4714-9c56-b8123f6c6d64	2026-01-07 02:51:00.767965+00	2.4	11	533330	533330
0550053c-781c-4372-b801-4324a106d038	2026-01-07 02:52:00.78348+00	2.5	11.1	612929	612929
302555e7-f8dd-4cc3-89f5-aa11ce2a8ac7	2026-01-07 02:53:00.739601+00	3.2	11	690084	690084
11bbb20c-1eeb-443b-846c-fc890df772df	2026-01-07 02:53:00.956625+00	3.2	11	572620	572620
3ee7bb1b-c2ec-44d3-bbe6-f0cc74d82598	2026-01-07 02:54:00.334156+00	2.6	11	619444	619444
00ee68c0-f04e-41df-98ec-caf1be0e8255	2026-01-07 02:54:00.978602+00	2.6	11	430616	430616
7fa3ee7a-eec9-4af0-8da8-9ea5fbdc2d82	2026-01-07 02:55:00.157002+00	2.8	11	387032	387032
ccef31c9-69bd-49c0-aab1-b51a0ac14d0a	2026-01-07 02:55:00.737304+00	2.8	11	941957	941957
10e08cdc-5ffd-474a-a840-87588cf37cfb	2026-01-07 02:56:00.021293+00	2.8	11.1	7904	7904
1e2cec5d-8252-43ea-a074-b3b14d016524	2026-01-07 02:56:00.138245+00	2.8	11.1	899736	899736
ae4f1e4f-8704-4b9e-9653-96e0bba87da9	2026-01-07 02:56:00.613298+00	2.8	11.1	358348	358348
01ce17da-f875-4866-916e-a6bd4b2359c1	2026-01-07 02:59:00.121546+00	2.8	10.9	10465	10465
132d4ae4-723c-4933-895b-0d16e621f89b	2026-01-06 17:16:02.116575+00	52.5	29.4	5579377	5579377
0fe9a46d-d57f-49b4-bec8-6f28ee0ace76	2026-01-06 17:16:42.785073+00	41.6	29.4	5275401	139099
3e82971c-d4ab-492f-9c45-b8465dca1297	2026-01-06 17:17:21.559261+00	34.1	29.5	4379718	4379718
832650d5-f45c-454f-8e43-a0ebfedba307	2026-01-06 17:17:22.260909+00	42.9	29.6	4127689	4127689
56d96ead-bd24-4fcc-b2bd-805380ba39cc	2026-01-06 17:18:22.722083+00	39.2	29.6	2870032	2870032
b1b0a20f-9ec5-41ce-ac1c-dd05378f22a2	2026-01-06 17:19:22.637894+00	36.5	29.6	289001	289001
241243ba-5c2c-416d-8afa-e4c60162ecd2	2026-01-06 17:19:25.951633+00	53.4	29.5	4490354	4490354
d3cc8b3b-e2d0-4355-9255-f5729d6f3f0a	2026-01-06 18:08:50.375052+00	36.1	29.9	4011551	4011551
44d1bf69-405e-41c4-bde5-d4c1d4c33269	2026-01-06 18:09:22.69687+00	42.1	29.8	5917071	5917071
c19c8ef0-9866-472f-81c9-12de56ae4aca	2026-01-06 18:10:25.911685+00	42.6	29.6	933649	933649
ebdee7aa-c2a0-413b-a0e8-088f893c2663	2026-01-06 18:11:02.077684+00	53.9	29.6	4238231	4238231
40774640-613f-4470-83ff-c5226cad28be	2026-01-06 18:11:22.296702+00	49.1	29.7	5047802	5047802
98dacf04-3c09-4adb-b2d3-00c3b8599efd	2026-01-06 18:11:52.007237+00	44.3	29.7	6284107	6284107
d8820afd-bdd4-4174-85af-dfe8f0f5175a	2026-01-06 18:12:25.967319+00	50.9	29.6	2650766	2650766
2375804d-0500-412b-99c8-782bfd4d1c41	2026-01-06 18:12:50.45575+00	31.5	29.8	3791902	3791902
0b7484fe-1b6b-43b0-86e2-a57bbcfa7f99	2026-01-06 18:13:50.322291+00	38.9	29.6	642053	642053
26041538-ca79-4436-a10e-e4651a6b0626	2026-01-06 18:14:21.610897+00	30	29.6	3629308	3629308
b2a7752a-4cce-47b0-823d-883f1e7e2df3	2026-01-06 18:14:51.883061+00	41.2	29.8	913563	913563
8fcf7a91-49f4-47b1-a898-8c13d9e17eed	2026-01-06 18:16:22.802989+00	44.4	29.8	3006919	3006919
81d08072-8a37-4f08-9d7a-06b7e0993b35	2026-01-06 18:17:22.805344+00	40.2	29.7	443261	443261
7ffa898e-a182-45a6-8a55-ed6973f929f3	2026-01-06 18:17:51.728196+00	38.6	29.8	3641669	3641669
4dad1657-6272-4e37-a1f2-bda6698ab13f	2026-01-06 18:18:02.112558+00	46.9	29.8	444832	444832
92a8b29c-67d1-4918-82ce-c0b60cf96d2c	2026-01-06 18:18:22.742103+00	39.1	29.7	3556732	3556732
df4c6615-c560-4519-98c0-af9a85f35ad6	2026-01-06 18:19:50.501046+00	38.2	29.6	892912	892912
4dfbfa75-b9f6-4c51-96cf-7ef36f2ab42a	2026-01-06 18:20:22.703969+00	42.9	29.7	2636679	2636679
d37df766-d8c6-4cef-b661-d265ba5226c7	2026-01-06 18:21:25.927661+00	44.6	29.7	3662766	3662766
a2ba44ef-c967-470d-961e-a2d4b29b7d47	2026-01-06 18:22:50.418868+00	36	29.7	4965745	4965745
13fe0e50-e4a9-4d70-9ebf-9dea18e6f4c1	2026-01-06 18:23:22.697421+00	41.4	29.7	6248409	6248409
9a84f2f1-6298-49b1-becb-78905faeabad	2026-01-06 18:23:50.470984+00	30.9	29.7	3901385	3901385
80a2a8e2-fa6a-4381-9162-d9c3c90664c7	2026-01-06 18:23:51.804129+00	43.2	29.7	1289770	1289770
43ad170f-e5b7-4635-b4f7-bc4191493377	2026-01-06 18:24:22.590873+00	41.8	30	4829732	4829732
af3ea108-1f72-4844-a725-a49a8f7eae71	2026-01-06 18:24:25.954573+00	49.9	29.9	1789941	1789941
9038f3df-b5c9-4631-b3fb-761099677cc6	2026-01-06 18:24:50.548935+00	38.3	29.8	3875385	3875385
461d888b-42f9-4f8d-ac7f-348101814307	2026-01-06 18:25:50.687568+00	34.2	29.7	6011848	6011848
a3ec4f34-7b94-4307-9910-701ed50575b4	2026-01-06 18:26:21.616503+00	29.8	29.9	802503	802503
b9f29f29-22c9-4005-9172-e3d954dde1c4	2026-01-06 18:35:22.762041+00	45.5	29.8	1276667	1276667
ca553358-2b12-4b6d-8c9e-d0f3b6a394d3	2026-01-06 18:35:50.528831+00	41.9	29.7	3717915	3717915
dd1eb906-af4e-4dd2-9ecc-e461961d90e1	2026-01-06 18:36:22.346457+00	43.7	29.9	3845023	3845023
336e97c7-d0a4-4bc9-a27f-afcdf89c204d	2026-01-06 18:36:50.549811+00	36	29.7	4578384	4578384
eb5e992d-47f3-4640-b735-bcbc200ea519	2026-01-06 18:37:02.096121+00	47	29.7	700214	700214
4a918f42-7b33-40de-ba93-847daf258181	2026-01-06 18:37:22.64271+00	42.8	29.9	5257389	5257389
379f7a80-7323-440c-af75-41cfbffdd9e9	2026-01-06 18:38:22.612768+00	37.2	29.7	2554589	2554589
aa54e1ff-3f5d-4323-8040-19d41bb7938a	2026-01-06 18:39:22.733208+00	36.4	29.9	3494374	3494374
8f982ff6-328c-4824-a7e0-f8554e1c7665	2026-01-06 18:40:22.781115+00	40.8	29.8	5345229	5345229
da321306-5a4f-4fa1-83ff-0fdcb9e2abb9	2026-01-06 18:40:25.94543+00	46.9	29.8	2629504	2629504
cac1d962-d5f4-4a23-8589-2a5d28c49835	2026-01-06 18:41:22.674462+00	46.2	29.8	4175968	4175968
a9e6af11-914e-4227-882b-dda216d6ea79	2026-01-06 18:41:50.557812+00	43	29.8	3898751	3898751
34758df3-cb04-4f3c-9c7e-7bc5756e126b	2026-01-06 18:42:22.33727+00	40.1	29.8	4741166	4741166
d24517ca-33fe-4218-9def-2b9aa75cffce	2026-01-06 18:42:50.535375+00	38.8	29.7	4314783	4314783
7263bfff-e169-431e-81f0-1c07c9eda0ca	2026-01-06 18:43:02.140961+00	49	29.8	1844940	1844940
b15dc23a-3b8b-4243-8cf9-36e9255db976	2026-01-06 18:44:02.133021+00	44.1	29.8	4268766	4268766
82fe1632-df15-417b-94a2-6e9e30faecfa	2026-01-06 18:45:02.124279+00	52.2	29.7	709105	709105
b63d8d8e-4b66-45aa-b88b-b8615354b2b3	2026-01-06 18:45:21.544276+00	47.2	29.8	3819511	3819511
0683e325-3db7-426c-b27f-0f0654a301e0	2026-01-06 18:46:22.231023+00	37.8	29.8	787121	787121
954292c1-b0c7-462f-b774-f678fd6c7008	2026-01-06 18:47:22.645821+00	45.2	29.8	3368754	3368754
58a83057-9304-44d1-899c-c595b92741b8	2026-01-06 18:47:25.942391+00	50.2	29.8	1654273	1654273
a1592bd4-eb16-42eb-924a-cdfd8a60577a	2026-01-06 18:48:02.139447+00	49.5	29.8	442465	442465
b793a35f-30ad-4d5d-bf7c-7620eb35c7ed	2026-01-06 19:04:22.763678+00	43.3	29.8	278794	278794
83f381ec-b3b1-466b-a994-2e1a72b44cab	2026-01-06 19:04:50.568355+00	38.8	29.8	532936	532936
64a14f1c-0457-47ec-be4d-204948201a1f	2026-01-06 19:05:22.771695+00	36.9	29.8	390086	390086
7ca075ec-0d33-4a0a-83d7-7866d6f87a03	2026-01-06 19:06:02.064673+00	43.8	29.8	6430702	6430702
41263b89-a964-4712-b539-102bc060aa2e	2026-01-06 19:06:21.595701+00	42.3	29.8	5032622	5032622
fed38747-f46a-4dff-b1c4-11ec8cd24b87	2026-01-06 19:06:51.859195+00	53.3	29.8	4882466	4882466
0be00778-3752-424f-b44e-bb434b11b28f	2026-01-06 19:07:22.277298+00	42.9	30	1969507	1969507
93e04483-23c9-4fd0-b816-0fcc29ab558b	2026-01-06 19:08:22.875116+00	43.5	29.8	2122276	2122276
6697a9f8-b0f4-4a82-b858-8877c0365e8a	2026-01-06 19:09:22.782658+00	44.3	29.9	2782300	2782300
97daa678-4194-4f8b-bbd1-e0257c3890c0	2026-01-06 19:09:50.520383+00	43.5	29.9	3392538	3392538
b4a7e89d-5d27-4082-8009-e857d0a24cf6	2026-01-06 19:09:51.810026+00	44.1	29.9	266086	266086
3dfa2944-1405-4c0b-8a06-14dbf9f056b8	2026-01-06 19:10:22.636237+00	45.7	29.9	5292078	5292078
c8b64f1f-8b08-4631-a612-b098963eb3b9	2026-01-06 19:11:02.098456+00	47.4	29.9	715993	715993
f46ec002-261c-40fd-bb9a-8dc7751c3ff6	2026-01-06 19:30:44.772123+00	37.8	30	4387716	113345
5cb4825a-3084-482d-8350-1999e100b848	2026-01-06 19:55:45.115726+00	42.9	30	4149673	107707
23560408-ffcf-4c2d-869c-e8f82b94bfff	2026-01-06 20:17:45.467633+00	36.7	30	4329708	149445
d05ae23a-b170-49da-aef3-15a59f77b456	2026-01-06 20:36:25.951633+00	45.5	29.9	2738584	2738584
1b8b9dbf-688b-4d06-8e56-547cb94460f5	2026-01-06 20:37:02.124742+00	51.6	30	665913	665913
362321be-9c38-4c9f-9209-3507c2bd9739	2026-01-06 20:37:22.307693+00	47.3	30.3	4297127	4297127
dbac46ea-ec23-4f5a-ad45-926659c226e2	2026-01-06 20:38:51.733093+00	45	30.1	4998012	4998012
d6206d05-aac9-4ddd-ad1c-e1439a8a7a8e	2026-01-06 20:39:02.139001+00	46.4	30	3864457	3864457
7a0275bf-4503-4cd2-91e2-370aeae7d8d7	2026-01-06 20:39:22.51986+00	37.1	30.1	4847103	4847103
81da8886-b5a6-4d71-a149-72a442fa69ff	2026-01-06 20:39:50.659005+00	47.3	30.1	4116304	4116304
8492324f-ffe4-48b8-92d3-5ab19e290630	2026-01-06 20:40:22.611713+00	44.5	30.2	2859005	2859005
c5d078e0-39bc-4e77-9659-adb8070d9438	2026-01-06 20:41:22.654656+00	47.3	30.2	243986	243986
355add93-08fc-4df1-8da9-6c7d6961c423	2026-01-06 20:42:22.935278+00	50.8	30.1	3440041	3440041
3067c2b5-9b15-4d60-8f50-cff09e4028a4	2026-01-06 20:42:50.666863+00	40.3	30.1	4831236	4831236
cdfd37e1-0242-4135-a9ad-b59dfcc0d96f	2026-01-06 20:42:52.153424+00	46.8	30.1	2111595	2111595
8944810a-4c36-4fd5-8fd5-c99b2c40e440	2026-01-06 20:43:21.522166+00	31.9	30	4757032	4757032
df309a8a-801c-4f1b-9620-9ed450a5f3fb	2026-01-06 20:43:50.481598+00	38.3	30.2	4803611	4803611
f42632ee-3c87-498e-a7d1-186b741a0807	2026-01-06 20:45:02.084245+00	44.7	30.1	1526686	1526686
dd746433-a5df-450a-9a11-7abb0c0c13b6	2026-01-06 20:45:21.538432+00	30	30.1	4184480	4184480
105bbbd6-16cd-41fc-a87f-c2f588b348ed	2026-01-06 20:46:22.758592+00	42	30.2	3372208	3372208
9d383ea1-27b3-4f1a-96c0-f7c66552eef5	2026-01-06 20:46:50.537407+00	39.9	30.1	3811832	3811832
ba611963-bbfa-4de0-90fd-f42c4941bb63	2026-01-06 20:48:21.531524+00	31.2	30.1	1843965	1843965
9d5d55dd-721b-4846-aea8-ea5c6a9c3771	2026-01-06 20:48:25.901961+00	58.6	30.1	454331	454331
49cfaece-d1c8-4ffb-99c6-e6735025cfa0	2026-01-06 20:48:52.195903+00	74	30.2	349688	349688
12224d24-3d73-4191-8f45-0baba508c40a	2026-01-06 20:50:02.140778+00	48.5	30.1	4080173	4080173
59aedcc4-e8cb-4160-a450-bb3e4dd0cee0	2026-01-06 20:50:21.540245+00	31.7	30	739572	739572
e97e531c-a0e9-408b-a117-3c6abd1dcec8	2026-01-06 20:50:50.575081+00	30.6	30.1	1562638	1562638
ea722374-9162-4d35-8008-74537411087a	2026-01-06 17:17:02.070586+00	49.6	29.6	806792	806792
6db342d1-89f1-4a75-bfb5-39f11b0d39b4	2026-01-06 17:17:25.915609+00	52.4	29.4	4897509	4897509
ee3a439c-5df3-4257-9aff-b300e525ef2c	2026-01-06 17:17:42.800343+00	42.6	29.6	4853344	134568
d0b55b09-37d5-4449-b873-94e61241006c	2026-01-06 17:18:42.82799+00	37.6	29.5	4336838	117939
6778f2dc-8231-445a-90db-e9b0363a9a9e	2026-01-06 17:18:52.00147+00	46.4	29.6	2356731	2356731
49444178-e5e4-438a-b2b8-cdfffe0ec370	2026-01-06 17:19:21.528779+00	33.1	29.6	3448138	3448138
bb8ca72d-eda4-4fce-88f8-e2f7355e0d2c	2026-01-06 17:19:42.86091+00	42.4	29.5	4203312	115702
7885c951-b859-4e00-860a-6686cfd165b3	2026-01-06 17:19:50.496324+00	37.9	29.6	4278491	4278491
968ff221-c0dd-4ded-a020-0324013e5492	2026-01-06 17:20:21.621001+00	31.2	29.5	953742	953742
3090b053-61ed-4949-be16-e81a88119b6b	2026-01-06 17:20:22.353283+00	44.2	29.6	2904845	2904845
10ad8ac5-221d-4c31-b846-eef1cd3dca59	2026-01-06 17:20:22.683199+00	44.2	29.6	2768497	2768497
bf56f0bc-a874-4357-9132-a0c37f66d633	2026-01-06 17:20:22.757276+00	44.2	29.6	5709804	5709804
743c0b63-60b2-4a18-ab8b-cfcd9b7d9fb8	2026-01-06 17:20:25.959056+00	45.3	29.5	2182683	2182683
412a4c67-b518-483a-8112-ab45df43be49	2026-01-06 17:20:42.832922+00	38.8	29.5	4678281	127025
073aa484-0578-4310-9dc8-fbdcc1ed7350	2026-01-06 17:20:50.295968+00	35.9	29.5	5838504	5838504
aab47601-085b-43d7-b50b-b369496b4fa9	2026-01-06 17:20:50.444027+00	35.9	29.5	5090100	5090100
ab2a0b20-3731-48e7-aade-5c91771dc84d	2026-01-06 17:20:51.711548+00	42.5	29.5	437647	437647
f425f010-2390-4722-8747-2db65f21516f	2026-01-06 17:21:02.10572+00	49.9	29.5	812232	812232
ec1a3b91-56cc-4355-b6c1-3e5e4b492e6b	2026-01-06 17:21:21.623662+00	29	29.4	5352203	5352203
62e4364b-63bc-45fb-9d75-a7834cfd3d8f	2026-01-06 17:21:22.403395+00	43.1	29.5	767932	767932
341f6aeb-dc41-4e94-bcc7-886deb79bd11	2026-01-06 17:21:22.728604+00	43.1	29.5	280283	280283
08bb0683-a9bf-4794-88f6-1fe771f78a19	2026-01-06 17:21:22.784409+00	43.1	29.5	388403	388403
0be2c517-fee9-4447-841a-33460bc17e13	2026-01-06 17:21:25.961721+00	42.6	29.5	3069849	3069849
78998adf-9e94-41d9-ba04-d98994727832	2026-01-06 17:21:42.863749+00	38.7	29.4	4784664	129963
7e9e27fe-ff36-4dd2-8bab-3dc09e771bd1	2026-01-06 17:21:50.558451+00	37.7	29.6	4840809	4840809
6182d405-f7a0-4e04-ac71-12bbf33cd92a	2026-01-06 17:21:50.649171+00	37.7	29.6	2486729	2486729
f5766ae8-0296-487f-bb4c-aa5f4007b02d	2026-01-06 17:21:52.086602+00	71.8	29.5	1370008	1370008
4393ece1-2931-47f7-9759-792e5929436b	2026-01-06 17:22:02.103868+00	49.3	29.5	5505363	5505363
ec4704c5-a26b-454a-a8e6-364e69271eaa	2026-01-06 17:22:21.624647+00	28.9	29.4	1104313	1104313
0da8cfd1-5bbf-465a-8938-18a326d61636	2026-01-06 17:22:22.353234+00	38.8	29.5	452833	452833
6bca36b3-c558-4ba3-bd7a-a081de262b71	2026-01-06 17:22:22.690177+00	38.8	29.5	5664056	5664056
b1be952e-4b27-4c04-9b1b-1f7a0ac6d161	2026-01-06 17:22:22.773713+00	38.8	29.5	4990972	4990972
17273a64-2a59-421b-8918-61410e01dcc8	2026-01-06 17:22:25.90796+00	42	29.5	633709	633709
41c63bfc-22ec-43df-998d-899b3812721d	2026-01-06 17:22:42.902068+00	40.2	29.5	3950678	112292
81d84092-a341-434e-bb77-90b0b8da8189	2026-01-06 17:22:50.354653+00	35.9	29.5	641028	641028
62230cff-9c99-4dd3-9479-3641ca9829b1	2026-01-06 17:22:50.53264+00	35.9	29.5	2621602	2621602
8df90661-1495-45d0-8bae-0414ce7afcab	2026-01-06 17:22:51.826709+00	38	29.5	3418794	3418794
2567c01b-5608-4a05-9ab3-1e11be26412a	2026-01-06 17:23:02.009269+00	42.2	29.5	3694739	3694739
6cf05e45-0220-4b72-9cc1-98f952814e61	2026-01-06 17:23:21.547451+00	29.6	29.5	6270898	6270898
0d509c9d-273b-4a47-bf3c-8195ab313166	2026-01-06 17:23:22.329044+00	45.4	29.6	6201016	6201016
0b46f0be-8df0-4fb7-ae26-8fd8bcddb4db	2026-01-06 17:23:22.708336+00	45.4	29.6	336515	336515
f97014cb-edbd-4c01-8f7f-8505b4f006bc	2026-01-06 17:23:22.797364+00	45.4	29.6	3553481	3553481
5ba58d9a-a359-4628-b7cb-6b9a1e7eca0a	2026-01-06 17:23:25.940748+00	45	29.5	1489770	1489770
8c6fc5f7-bade-427b-928c-0a115cd95a8a	2026-01-06 17:23:42.908487+00	42.6	29.4	4624244	129870
70e3fcc2-dac2-46a9-bf1e-fa570722ebc5	2026-01-06 17:23:50.259463+00	37.1	29.5	743120	743120
32fa5afb-f6a1-42b1-9d90-a429ed1cabdf	2026-01-06 17:23:50.389878+00	37.1	29.5	3067579	3067579
133862f7-89f7-45a1-acd4-294a9e8cccef	2026-01-06 17:23:51.588036+00	45.9	29.5	334016	334016
86cf896e-c563-414c-9737-d4184cd8fb08	2026-01-06 17:24:02.078764+00	46.6	29.4	3276969	3276969
e25d2c21-edbb-4f8a-bbc8-63d73e50d033	2026-01-06 17:24:21.577208+00	30.2	29.4	1065113	1065113
f3341fb9-d0d9-4014-aa0b-dc087fa7be4a	2026-01-06 17:24:22.282044+00	46	29.5	941467	941467
7a0470f3-848c-4920-8f8c-60d49fd7659a	2026-01-06 17:24:22.612805+00	46	29.5	310061	310061
79398c9d-241a-4457-9451-b55e3d35fb01	2026-01-06 17:24:22.692257+00	46	29.5	195040	195040
5a23c9dc-16da-42a0-b3ad-98a1282e6034	2026-01-06 17:24:25.906638+00	43.4	29.5	4087827	4087827
19959bee-a803-478e-a320-557158744eb0	2026-01-06 17:24:42.923319+00	38.4	29.5	4152382	112726
11c1039e-a770-4938-89e5-eff63df1d9c5	2026-01-06 17:24:50.389552+00	29.1	29.5	3250470	3250470
291cbdbd-6e9e-4df9-a85e-1a972b79a0c5	2026-01-06 17:24:50.520632+00	29.1	29.5	4340295	4340295
b7a5a7da-2350-4200-8959-3af234d0f24a	2026-01-06 17:24:52.00356+00	69	29.5	4095777	4095777
e8f875a3-b461-47ff-b76f-839901415376	2026-01-06 17:25:02.1118+00	56.8	29.5	4165419	4165419
c1e64d15-29e3-466e-a9ed-72ff1117e126	2026-01-06 17:25:21.573977+00	34.8	29.5	5685391	5685391
ce392dac-141e-427a-a397-680b72ffebd9	2026-01-06 17:25:22.282997+00	45.9	29.5	4403968	4403968
89c50117-f5be-41e9-aaf5-fc1655726018	2026-01-06 17:25:22.729734+00	45.9	29.5	4716112	4716112
0510c60c-22ec-45cc-83c2-50d2e6fae376	2026-01-06 17:25:22.791187+00	45.9	29.5	1237240	1237240
310f728f-2f17-4ecd-8cd4-ffc5e811a115	2026-01-06 17:25:25.920247+00	48.2	29.4	872452	872452
e4233dcd-24e6-4a0f-8c20-76f6e5d0e228	2026-01-06 17:25:42.90976+00	44	29.5	3780476	100775
b0a44867-e5a3-47b6-9134-3017ab8f2f97	2026-01-06 17:25:50.575824+00	39.3	29.4	4844058	4844058
a925dd39-b0ba-453d-a7a4-b10504443095	2026-01-06 17:25:50.689203+00	39.3	29.4	3138431	3138431
9a52464f-26a8-4787-866c-7e203c48ba74	2026-01-06 17:25:52.103945+00	72.5	29.5	4675206	4675206
6500d356-1e0b-4d6a-b61c-b6d0c5e7c842	2026-01-06 17:26:02.096721+00	45.1	29.6	6208053	6208053
b3121f5a-e0fa-4b5d-a6e2-eb423a1c85c1	2026-01-06 17:26:21.609193+00	32.2	29.5	1251389	1251389
e27622ec-0d90-42d7-8136-5ced7b1c2078	2026-01-06 17:26:22.358768+00	42.9	29.7	3873175	3873175
874908e8-76e8-41cd-8cdf-197b016aaaae	2026-01-06 17:26:22.743228+00	42.9	29.7	4341636	4341636
268d01a7-fc32-453b-ad14-8379ef3f606f	2026-01-06 17:26:22.825621+00	42.9	29.7	317929	317929
fa6304f0-ee12-47bc-8e6d-87e4c447e273	2026-01-06 17:26:25.939049+00	43.8	29.5	4274676	4274676
a9934780-c407-4825-b96c-73d0de5962df	2026-01-06 17:26:42.960768+00	47.6	29.4	4123797	112231
a434182e-f98f-497c-8609-584f1ff9c211	2026-01-06 17:26:50.404909+00	31.7	29.5	3671837	3671837
023de5d6-a5a4-4ae5-ba2c-d82e087aca5d	2026-01-06 17:26:50.569224+00	31.7	29.5	806580	806580
a67a4f68-dbc5-402d-a548-b1ea750e6669	2026-01-06 17:26:51.747543+00	40.2	29.5	6198267	6198267
8df55a87-8622-482b-a456-9f91344ce9be	2026-01-06 17:27:02.102404+00	52.3	29.5	4428300	4428300
fc098175-a90d-4ece-8c74-00f954b9db7e	2026-01-06 17:27:21.587862+00	36.8	29.4	3867085	3867085
276b4f12-5515-4aad-9766-920249efc686	2026-01-06 17:27:22.335883+00	45	29.7	948869	948869
06621ff9-67b4-4d9e-a588-7e6434898f91	2026-01-06 17:27:22.698884+00	45	29.7	162338	162338
adeaebde-6bb5-4644-b022-f2ddbe711169	2026-01-06 17:27:22.791982+00	45	29.7	5415096	5415096
7e11f620-d3c5-41f4-becc-9c263c07ba44	2026-01-06 17:27:25.956539+00	43.7	29.6	3984624	3984624
64c386f1-4f55-4a47-bd69-3bac3c4e18ee	2026-01-06 17:27:42.977337+00	48.7	29.4	4205679	111374
89007490-75dd-4396-85e1-ad27a74b013c	2026-01-06 17:27:50.469532+00	36.2	29.5	3511337	3511337
d9c835cd-b3f3-437b-b215-c32610f60a38	2026-01-06 17:27:50.567298+00	36.2	29.5	2709377	2709377
c8eb4329-ef6c-4286-bec3-412ef6e27939	2026-01-06 17:27:52.000169+00	41.3	29.5	5052403	5052403
9d3624b3-4622-4045-903c-83b7a1d1690e	2026-01-06 17:28:02.140596+00	50.1	29.4	1463906	1463906
3125e8b9-5a8f-400e-8b4c-f6e6006db727	2026-01-06 17:28:21.555655+00	31.2	29.4	5164972	5164972
ce286dc6-9612-4894-a1e2-21151d9b10c7	2026-01-06 17:28:22.366589+00	48.3	29.5	1393356	1393356
f0163fcb-7576-4d1f-a13e-0b008dd03d80	2026-01-06 17:28:22.812822+00	48.3	29.5	3867976	3867976
86a8615a-3c16-46ef-8aa1-0a32eace7493	2026-01-06 17:28:22.928337+00	48.3	29.5	3051423	3051423
296d0517-395f-459e-9020-e3e411160ece	2026-01-06 17:28:25.871816+00	42.4	29.5	1708944	1708944
44b40197-b18c-4422-9669-8e6717c695e8	2026-01-06 17:28:42.972946+00	43.5	29.4	4070143	109924
718ed8fc-ef99-4e77-b76a-f618c25b0c26	2026-01-06 17:28:50.519193+00	38.9	29.5	754126	754126
af3ab8f3-04bd-49f7-b34b-08b61ab04928	2026-01-06 17:28:50.628237+00	38.9	29.5	5011861	5011861
3e48f735-b3a9-4131-bf75-4a0af5d12803	2026-01-06 17:28:51.735535+00	46.5	29.5	1097290	1097290
f4b2ec30-a829-4861-a1bb-92d3e65aa0ba	2026-01-06 17:29:02.091139+00	52.8	29.7	4756125	4756125
e6bb83ff-ce45-4be5-8463-fa04102985af	2026-01-06 17:30:22.824311+00	45.8	29.5	325960	325960
9096fc7b-a4c4-4a83-82c5-780d7d44e49a	2026-01-06 17:31:22.708239+00	40.2	29.7	2895949	2895949
cf9e4109-0cd5-48a1-a515-26b4656fcdc5	2026-01-06 17:31:51.839133+00	39.9	29.5	4447273	4447273
b7dfb6d3-79e4-463b-9df3-9de2830c8f7e	2026-01-06 17:32:22.751754+00	38.9	29.7	2842020	2842020
4765e4c1-c0bd-40b9-bbc3-2fd680068485	2026-01-06 17:32:25.9114+00	42.1	29.4	456925	456925
e3e731c3-9e79-4692-a0a0-97084f1546d1	2026-01-06 17:33:50.537487+00	37.3	29.5	2569019	2569019
7661037d-b48f-4576-9726-d27646007a55	2026-01-06 17:34:02.123397+00	50	29.5	1276782	1276782
0f80eca8-80b6-4a78-a312-9513ccae6dc3	2026-01-06 18:09:22.617011+00	42.1	29.8	1399480	1399480
d1cb3393-051f-4bee-9597-ce8a11deb6bc	2026-01-06 18:09:51.824364+00	68.4	29.7	1507068	1507068
8473eb22-6e66-4210-9fec-b93bcea345c5	2026-01-06 18:10:50.665231+00	36.8	29.6	4191800	4191800
a003f56d-93b2-48cc-b5a1-1f090a19acc2	2026-01-06 18:10:52.100986+00	43.6	29.8	5526194	5526194
cc9a12a6-35ba-4473-a72e-e15d0eb1a59a	2026-01-06 18:11:21.537534+00	31	29.7	3478299	3478299
81109856-0c85-4b0c-89ef-edcbefa95087	2026-01-06 18:12:22.590259+00	40.8	29.7	1190419	1190419
ed7aa3f1-b0d2-4182-9660-17aa2890db8f	2026-01-06 18:14:25.961648+00	56	29.6	2692784	2692784
d5d377da-5f1d-4c81-9f04-ad1f4df9c899	2026-01-06 18:15:22.819588+00	36.1	29.9	3166393	3166393
584af823-e5fe-4005-af88-0ce02e873ef3	2026-01-06 18:17:01.976542+00	43.7	29.7	529977	529977
badd27a0-fb7d-430b-ad1e-a556383832e4	2026-01-06 18:18:22.431614+00	39.1	29.7	4495778	4495778
00ae32fe-dbec-469b-a9eb-ec8a9fb6a5ce	2026-01-06 18:19:22.686946+00	43.2	29.7	4728338	4728338
47fdf9c4-d141-44dd-a888-3b4b36dafc1b	2026-01-06 18:19:25.92805+00	47	29.6	2865395	2865395
d4ade5b4-ba3e-4787-9f51-8479e4d71940	2026-01-06 18:19:51.934129+00	68.5	29.7	220915	220915
36e3c198-d075-4c35-8ea3-94fcb890d340	2026-01-06 18:20:21.597037+00	29.8	29.7	3266222	3266222
54009d0d-b4b6-4d9a-9e26-3e0c2c6cc7dc	2026-01-06 18:20:52.164279+00	73	29.6	489181	489181
a96cdd43-239e-4ca1-9b71-3496b6ea6838	2026-01-06 18:22:22.736117+00	46.6	29.8	4972967	4972967
d427c297-2087-483c-803b-24487e96e8ff	2026-01-06 18:23:25.921428+00	44.6	29.7	725424	725424
b1e20195-dd2e-4331-9977-a3377dcae164	2026-01-06 18:25:22.763722+00	43.8	29.7	4954974	4954974
c8fbd9d6-1d3c-4e69-8931-04b4bc076dbc	2026-01-06 18:25:25.928262+00	42.4	29.7	1589767	1589767
f8230ec0-ff1c-4878-9ab1-d3d93283f664	2026-01-06 18:35:25.941886+00	42.7	29.8	1668621	1668621
5990ceb0-5714-4db7-9600-f4f026fb763c	2026-01-06 18:36:02.103582+00	47.4	29.7	5818122	5818122
eee94854-8300-4aea-80cb-edb1609f6e40	2026-01-06 18:36:22.676884+00	43.7	29.9	5452005	5452005
c70f91c3-a021-48b9-8be3-d18128a4da08	2026-01-06 18:37:22.720295+00	42.8	29.9	251477	251477
d951e000-3d3c-4553-a741-d3782db60e5b	2026-01-06 18:37:50.59952+00	37.6	29.7	3617171	3617171
69ff2f92-75f4-4a5d-a927-0387dded2eaf	2026-01-06 18:38:50.499425+00	35.5	29.8	2689785	2689785
7c91de22-a61e-4d81-8186-860e7ad98c9a	2026-01-06 18:39:02.107075+00	46.9	29.9	5374813	5374813
0aa485f0-ecce-46df-8e62-8fb01c714429	2026-01-06 18:39:50.406735+00	33.5	30	5375624	5375624
55d1e3f0-12e1-4ee8-94d5-1136977b8894	2026-01-06 18:40:50.509781+00	40.8	29.8	3554264	3554264
1412652f-5eb7-4629-8477-e3bee4da7e2a	2026-01-06 18:41:25.946239+00	41.1	29.8	1679400	1679400
70bd486d-0b44-4196-966d-f7e3c3ca5154	2026-01-06 18:42:21.563651+00	33.1	30	3012734	3012734
48151994-958a-442c-91c2-01eb7e200837	2026-01-06 18:42:51.701343+00	43.1	29.7	1395551	1395551
ef76a375-862e-4e73-8708-3178a2bdcd2d	2026-01-06 18:44:51.861877+00	51.3	29.8	2405089	2405089
e059e656-6b94-4353-b9fd-890ff936c4c8	2026-01-06 18:45:22.769353+00	49.9	29.7	3929174	3929174
1694fa31-9aa4-4dbc-a4b3-663d1333c1bc	2026-01-06 18:46:22.575197+00	37.8	29.8	3888882	3888882
c8dc5c58-9159-4263-8a85-f25a634cce63	2026-01-06 18:46:51.726478+00	49.1	29.8	4074349	4074349
e0429bcd-58cc-4269-825e-904e7603e768	2026-01-06 18:47:50.501557+00	41.2	29.7	803062	803062
ae3573c4-cd0f-4bf3-b95c-9abeb83749c9	2026-01-06 19:04:44.423589+00	44.2	29.8	3915257	100008
b2df973f-726f-465e-b655-8043bae67b60	2026-01-06 19:31:44.786297+00	40.9	30	4593244	120858
b2b2a744-1d9a-4bcf-8873-a6d3a5d997bc	2026-01-06 19:56:22.786807+00	49.6	30	3623338	3623338
85f2ceff-ea32-47f0-b0f6-b3d351242953	2026-01-06 19:56:25.908606+00	44.3	30	740836	740836
bb82d2c3-6e78-46cb-973d-258e39961611	2026-01-06 19:57:22.646869+00	39.7	30	4809228	4809228
90871ba1-967d-4c76-b608-579c9b4e64e6	2026-01-06 20:00:21.57625+00	36.5	29.9	3208813	3208813
c6e8ec89-4bc7-424e-bd38-4cb2b1e135d2	2026-01-06 20:00:50.475222+00	33.6	30	4500111	4500111
508b937d-4bd5-434d-b274-a9b44dac01ac	2026-01-06 20:02:21.567365+00	30.9	30	1121334	1121334
51b26785-41d7-4261-b5ae-bcc528f9d207	2026-01-06 20:02:50.636416+00	44.1	30	5718348	5718348
8e847804-e338-4263-b297-e597ff1deb9d	2026-01-06 20:03:22.324859+00	43.3	30	766596	766596
b3c46f10-b11e-4c32-bf45-67590e1489c1	2026-01-06 20:18:45.461223+00	40.8	30	4129123	110772
a2f47d2c-5cb7-4a9e-b12c-e547d0a2726e	2026-01-06 20:36:45.739945+00	40.9	30	3667597	98532
6e33f129-49f6-4a35-ac7b-feaf207d38b4	2026-01-06 20:58:46.079642+00	3.7	21.7	1527	193
db9ab2e0-dcad-4259-9f1a-5ff5a9c98b0c	2026-01-06 21:27:46.475506+00	3.8	21.5	2287	303
07a9eaa3-335e-4c67-adf0-7caa0296f5a1	2026-01-06 21:56:46.813293+00	3.7	21.6	1532	190
d94fb5f2-669c-402a-972b-3de97c3348db	2026-01-06 22:25:47.121679+00	4.1	21.6	2315	282
75ee0838-a064-408f-9190-43d1b857f80b	2026-01-06 22:54:47.490507+00	4	21.5	1531	157
46f521ab-d431-4dcd-adce-c67be9ad9389	2026-01-06 23:23:47.822127+00	2.9	21.4	1831	201
e015e394-97af-4cb3-9cf7-41924ae9eb85	2026-01-06 23:52:48.204322+00	2.7	21.5	1464	301
fa46fa52-5ebb-4cfc-8d82-53c66d830ad0	2026-01-07 00:21:48.536803+00	2.7	10.2	1396	17
1565ad8f-0241-480f-b0f3-96d056ed61db	2026-01-07 00:50:48.92421+00	1	10.2	1243	9
d1930ec3-0473-43bd-b8e9-f4ebf8d3a847	2026-01-07 01:19:49.362664+00	1	10.2	1640	13
8b63794d-e5ba-49a6-b7dd-54adf24b3786	2026-01-07 01:48:49.75425+00	0.9	10.2	1371	40
6ae38058-d101-4bb9-ac37-69c14ef2c946	2026-01-07 02:09:49.997891+00	1.7	10.9	41965	27435
87d9c7be-3038-4da2-b2c5-00fe60cc0a7c	2026-01-07 02:27:00.978107+00	5	11.1	427365	427365
14294b55-4f38-4652-8de2-e7138b6b7810	2026-01-07 02:28:00.848177+00	3.6	11.1	911082	911082
a7d91ba0-5d96-4123-a8c8-7deff6429aef	2026-01-07 02:29:00.185857+00	3.2	10.9	9938	9938
4b353dcb-fdca-4070-abd3-bc836b30dc7e	2026-01-07 02:29:00.821653+00	3.2	10.9	379080	379080
208a8ff0-e1b3-406b-a3c6-e5a582ec0ed7	2026-01-07 02:30:01.063854+00	3.1	11.1	654779	654779
4a98d9d4-221c-4b9d-afd0-2a16bb6f6060	2026-01-07 02:31:00.939861+00	2.8	11.1	340107	340107
89c8ec6a-e446-4d91-9147-fb8fafcf2203	2026-01-07 02:31:01.138755+00	2.8	11.1	473814	473814
7a28b878-5d99-4334-9f7c-368258e92fd6	2026-01-07 02:32:00.945943+00	3.1	11	465983	465983
955fd95c-b750-43b7-bf55-f0158f7b752c	2026-01-07 02:32:01.166004+00	3.1	11	360955	360955
6fcf9952-807e-4e8a-9c1a-3c1d7649fa25	2026-01-07 02:33:00.19585+00	6	11	598578	598578
95118649-8a2e-4eae-9965-ee1126a90e66	2026-01-07 02:33:00.763257+00	6	11	687620	687620
b3b3d4c3-a802-40eb-a640-f04d269fc053	2026-01-07 02:34:01.000442+00	2.2	11.2	580521	580521
06f69358-b960-4711-827e-0d86f9702064	2026-01-07 02:35:00.903232+00	2.4	11	696557	696557
8614af93-c210-417e-acea-110d9681ac2d	2026-01-07 02:36:00.970895+00	2.7	11	384387	384387
207fe56a-357a-43e4-9fb9-27d6680a53c1	2026-01-07 02:36:01.231169+00	2.7	11	487712	487712
b8eca26c-088f-40e9-a2f9-b510f302914e	2026-01-07 02:37:00.608417+00	2.9	11	854435	854435
85ff9d9b-25e7-4e68-bf50-450e0ae0523c	2026-01-07 02:37:00.868858+00	2.9	11	499818	499818
1b7dafe3-84cc-4d4f-ba7f-99f610654e6d	2026-01-07 02:38:00.682554+00	2.7	11.1	719291	719291
2ab05b74-d4d4-4f25-b2f3-f88c5efe2fa7	2026-01-07 02:39:00.75983+00	2.5	11	799759	799759
c8b21517-6ece-4451-9987-ae0e432efac6	2026-01-07 02:40:00.826682+00	3.8	11	538134	538134
6322d10a-8e30-4417-8ed4-ee138cb0cc2c	2026-01-07 02:40:01.007499+00	3.8	11	557557	557557
823737a8-4d2b-48b4-a6f0-3dfe7eb8fb54	2026-01-07 02:41:00.670674+00	3.1	11	666983	666983
358416d7-d3a7-4062-b752-48cff0425793	2026-01-07 02:42:00.672327+00	2.8	11	715863	715863
2afd9edc-7291-48c4-a5be-49a650c4da22	2026-01-07 02:43:00.975202+00	3.9	11.1	438545	438545
bc6377b5-c10c-4d5c-8641-a968caf8557f	2026-01-07 02:43:01.228204+00	3.9	11.1	320450	320450
31a67dc8-47bd-49ee-bda0-1b9b7c7003c5	2026-01-07 02:44:00.837435+00	3.8	11	584864	584864
00d97def-f6e5-46fb-af36-6a361288a08b	2026-01-07 02:45:00.66902+00	2.4	11	647740	647740
55df2255-46d9-44ac-b470-166728ab467a	2026-01-07 02:46:00.883329+00	3.4	11	350253	350253
f9378450-b6ba-4309-9a0a-ca7dee6040e0	2026-01-07 02:46:01.144892+00	3.4	11	546048	546048
4de2dc20-68e6-4dbd-8d0a-4f81447c208e	2026-01-06 17:29:21.524632+00	29.8	29.5	3370920	3370920
ee90c1df-3677-4833-b562-af3122e1772a	2026-01-06 17:30:02.07164+00	49.9	29.4	5505821	5505821
5159024d-ccfb-4200-a172-8acdb41ca088	2026-01-06 17:30:50.431588+00	43.4	29.5	4151670	4151670
fd2c04f1-1941-4be0-b492-9611c9fcc0cc	2026-01-06 17:31:02.109084+00	48.9	29.5	5499708	5499708
0824e71d-447c-4ed6-a6d8-07e080bdcacf	2026-01-06 17:31:22.329957+00	40.2	29.7	584915	584915
f5d7d5e4-ce4f-4bb9-8185-c1b9c9d2a28a	2026-01-06 17:31:25.915521+00	44.5	29.4	3954591	3954591
00295c3d-5989-4744-adb6-8da247c485a6	2026-01-06 17:31:50.456022+00	41.8	29.5	3629822	3629822
7cf17079-a447-49f1-bc00-35012a15300b	2026-01-06 17:32:22.853324+00	38.9	29.7	343730	343730
6340278f-8e13-4358-833a-0ec3acaa5ee7	2026-01-06 18:09:43.583161+00	41.3	29.7	3885080	101422
1f4695aa-abcf-424e-93a7-e001d7659dd3	2026-01-06 18:35:43.936702+00	41	29.7	4925433	131193
0fd9358c-e032-46a3-897b-e07d074680aa	2026-01-06 19:04:50.449738+00	38.8	29.8	4938708	4938708
072dc3d9-f39a-498e-a7c7-07e4d1a6180f	2026-01-06 19:05:21.563207+00	34	29.7	2663602	2663602
0467a6ec-4d13-40b1-8a29-cf7181e683b8	2026-01-06 19:05:22.318664+00	36.9	29.8	4789432	4789432
e9cc9c20-3507-47cd-b6d2-e5dcfd2a289c	2026-01-06 19:05:25.924403+00	41.1	29.8	2182014	2182014
914c30ee-8979-4b42-a0d8-b57024d62f72	2026-01-06 19:05:50.497355+00	37.5	29.8	3896092	3896092
f4cd87c3-d11d-4cbf-9826-28fd86f9e5d3	2026-01-06 19:05:51.871261+00	70.1	29.8	4463369	4463369
80e7f363-947b-45ee-86da-daced545f5c2	2026-01-06 19:06:22.357523+00	43.1	29.9	1383685	1383685
986d2318-fa85-4205-8b5f-e702c5fe1e87	2026-01-06 19:06:50.567889+00	34	29.8	1007806	1007806
9a6afff0-2525-4d80-b81f-dcdf5103f7fa	2026-01-06 19:07:22.590781+00	42.9	30	1013794	1013794
b881a0ac-6a6a-46c3-91fd-bc25e8497b5d	2026-01-06 19:07:25.926454+00	46.8	29.9	6941319	6941319
90807ba8-ee45-45e2-baed-42365cdb7906	2026-01-06 19:07:51.78931+00	69.9	29.9	5856128	5856128
a4be4018-e57a-4baa-96b8-ff91e694bd9e	2026-01-06 19:08:02.111202+00	50.2	29.8	6041089	6041089
f6f5706a-efe3-4a9a-9816-410d26969e10	2026-01-06 19:10:22.733488+00	45.7	29.9	391074	391074
a56d5e03-b49b-4d6f-a799-d1900e236a8d	2026-01-06 19:32:44.819215+00	40.7	29.9	4409543	117667
7556d0a6-4a4e-4bd9-813f-92b0fd368888	2026-01-06 19:56:45.159701+00	41.2	30.2	4005376	103224
6aee650e-2e12-4b00-a78c-5cce92462952	2026-01-06 20:19:22.649567+00	43.4	30.1	5410436	5410436
0f7b629e-0663-4494-a715-293faba57f2a	2026-01-06 20:20:22.77955+00	48.4	30.1	238572	238572
6b264cba-309c-460d-a426-21d7b6114412	2026-01-06 20:20:50.543338+00	35.8	30	5138816	5138816
8fc30a51-d419-40a6-bba0-a21968341ebb	2026-01-06 20:20:51.741606+00	38.6	30	401831	401831
b32024c7-dc06-4e8d-8d1b-95ec66e2f96d	2026-01-06 20:23:02.099993+00	44.6	30	3968437	3968437
f937ecc2-1a97-4c6e-aec3-778de002d39d	2026-01-06 20:23:22.720092+00	44.7	30.1	2217369	2217369
ff685293-9f29-49b0-be3f-8cd2b4b483ba	2026-01-06 20:24:22.839705+00	42.5	30.3	3662108	3662108
6a527025-9994-455d-be58-1104a050ce9a	2026-01-06 20:24:50.645387+00	44.5	30	3806169	3806169
d74a690a-7a87-44f0-83ba-45b581cfdbfa	2026-01-06 20:24:52.082716+00	46.2	30.1	2620672	2620672
e0e2cfc6-dd0a-4ffa-b602-7eca6ff98320	2026-01-06 20:26:22.836098+00	42.7	30.2	3943244	3943244
9321af54-2e47-45a6-91d2-a56e9be0c00c	2026-01-06 20:26:50.533425+00	43.8	30.1	5356678	5356678
1a6591c8-35b5-4c14-83d7-194431ceb4c3	2026-01-06 20:27:21.600028+00	33.6	30.1	4157469	4157469
8bb11df6-c366-4501-8fb8-9c4eed689f33	2026-01-06 20:27:22.474652+00	46.3	30.1	545477	545477
b2e5a5f6-85ea-4bb0-ab32-5b90d901d302	2026-01-06 20:27:52.146911+00	72.7	30.1	4766918	4766918
b0b96166-2e60-4d74-abac-33a90ece9ea6	2026-01-06 20:28:21.517165+00	33.3	30.1	3747668	3747668
7020d035-ce51-49fd-9684-05cd02a6e2a8	2026-01-06 20:28:22.271374+00	38	30.1	4434373	4434373
7940c759-bec1-49b8-a54f-14d109bdcfcf	2026-01-06 20:36:50.501041+00	39.7	30.1	4540642	4540642
59ebc2cc-d391-44b6-9ac2-54f1b9af3631	2026-01-06 20:38:21.508133+00	31.3	30	2927181	2927181
83fc6584-6939-4674-8440-e507915a1f85	2026-01-06 20:38:22.351859+00	41.8	30.1	224922	224922
46fd16aa-97eb-4388-84e8-bc066f8e26ff	2026-01-06 20:38:50.439212+00	36.2	30.1	3317584	3317584
c40da5f2-46a2-4be8-b029-82901bfa97e2	2026-01-06 20:39:25.94749+00	43.4	30.1	377747	377747
065ea404-73db-4be5-bc81-cb077c0bad7e	2026-01-06 20:39:50.565328+00	47.3	30.1	924909	924909
fc4ae749-8496-4dd1-875c-ea9afc274544	2026-01-06 20:40:22.690178+00	44.5	30.2	3972542	3972542
111876b8-311e-4a58-97d3-4f370965f32b	2026-01-06 20:40:50.514522+00	32.6	30.1	3425398	3425398
20e80587-8b4a-4942-95bb-5e839f1d7471	2026-01-06 20:41:21.536691+00	32.7	30	3739303	3739303
12651ff6-bec5-4f6f-8957-7d3885d52639	2026-01-06 20:41:22.306576+00	47.3	30.2	838498	838498
92f1aa0a-4331-4a1c-8425-2088c7f8708a	2026-01-06 20:59:46.099382+00	4	21.6	1329	196
415f46b6-fd82-4be8-a02a-3c44030a18c5	2026-01-06 21:28:46.477467+00	3.9	21.5	1824	302
54556c22-2a8e-41c5-8265-a2016d3e2463	2026-01-06 21:57:46.792735+00	4.1	21.5	1655	184
08c4275f-ba29-4b8a-854e-610d61ad6200	2026-01-06 22:26:47.167789+00	3.8	21.7	2010	396
b64aa4c2-ef1d-4fb8-bc65-401a21f2e5cd	2026-01-06 22:55:47.475645+00	4.2	21.6	1627	152
548f3e5b-0111-4fc1-a692-9deb2371405b	2026-01-06 23:24:47.851439+00	2.7	21.4	1659	192
bc0a2b33-9488-4507-a912-1c5cb358b35c	2026-01-06 23:53:48.192486+00	2.6	11.2	1414	24
f9833e7f-2ea9-43aa-99be-8aacf8257368	2026-01-07 00:22:48.552655+00	0.9	10.2	1266	28
5a00e877-1cc5-457e-80f8-5ce0ed2312c5	2026-01-07 00:51:48.942468+00	0.9	10.2	1215	14
ebe53a6d-d05e-402e-ac67-c99710ae704e	2026-01-07 01:20:49.325408+00	1	10.2	1278	9
6cf9456f-2376-4307-a75c-f9953dd13e13	2026-01-07 01:49:49.758597+00	1	10.2	1248	18
cd3fea84-fc74-4e58-b495-d77ea39ea388	2026-01-07 02:10:49.997255+00	2.2	11	56012	31266
6dd596e2-8dbb-4cc7-a377-b1092aeead6a	2026-01-07 02:27:50.227674+00	1.7	11	29481	24468
f2bb9153-374a-4929-84c7-e5f4e0ae79d5	2026-01-07 02:47:00.103005+00	3.2	11	9630	9630
f43e802e-1c2f-4cd6-a27a-4027717ab81d	2026-01-07 02:47:00.788905+00	3.2	11	555731	555731
14a84d59-56ae-4078-89ae-a4fec860b56c	2026-01-07 02:48:01.090512+00	2.8	11	646752	646752
fb61ac93-336e-482d-bc23-7956c23cfdab	2026-01-07 02:49:00.733819+00	3.1	11	794284	794284
fa73d726-0cbc-4244-9dad-494fd88854d3	2026-01-07 02:50:00.788356+00	3.3	11	689900	689900
a96c3707-d7ad-474a-b3fb-ffb462d7fa5e	2026-01-07 02:51:00.837574+00	2.4	11	451781	451781
40e18da6-cf4a-406a-9a12-38a8a8eae753	2026-01-07 02:52:00.698346+00	2.5	11.1	762043	762043
b1a9916f-bf97-4ec0-93fa-f4eb813cee3e	2026-01-07 02:52:00.874903+00	2.5	11.1	666145	666145
dabb116d-80c1-48ea-bcf9-533c766df4de	2026-01-07 02:53:00.863678+00	3.2	11	610617	610617
c260c029-f402-4156-bdee-f6d558bcd60d	2026-01-07 02:54:00.073898+00	2.6	11	6021	6021
e850f0dc-6dec-46d6-96eb-62868eb0617c	2026-01-07 02:54:00.965936+00	2.6	11	601005	601005
4c543376-2384-4cc4-bf1f-2b8f59a568fe	2026-01-07 02:55:00.534702+00	2.8	11	601826	601826
bd53d581-6e31-449b-be2d-281e00c237f3	2026-01-07 02:55:00.890004+00	2.8	11	432629	432629
7a50794d-5300-412b-9fb3-859147a2bd91	2026-01-07 02:56:00.674635+00	2.8	11.1	760330	760330
ba68b78c-a2ee-4709-9e3a-85fa2857677d	2026-01-07 02:59:01.071566+00	2.8	10.9	92248	92248
77e75520-5989-497c-817b-6920caa2a7f3	2026-01-07 02:59:01.293206+00	2.8	10.9	360336	360336
d89346df-9a96-4afa-b0d5-b5bac7730121	2026-01-07 03:00:00.845943+00	3	11	538334	538334
62e4e82d-bc45-487d-aced-8d0354077c6a	2026-01-07 03:09:50.777272+00	7.4	11	21716	43256
20e5f703-dc08-4ed3-8bbe-7c532b84954c	2026-01-07 03:19:50.922697+00	3.5	11.1	15984	9372
c0529fc9-e36c-4893-ae96-0186832bc049	2026-01-07 03:28:00.994807+00	2.6	11	519708	519708
a4515125-c126-4019-b28f-c78da194bbe5	2026-01-07 03:29:00.162217+00	4.7	11	8136	8136
48787f15-61e0-448b-9701-652eee231839	2026-01-07 03:29:00.321688+00	4.7	11	724876	724876
94b18642-db73-41a3-a6af-39a5cfcb8b5a	2026-01-07 03:29:01.062043+00	4.7	11	441930	441930
e555b412-fa27-4e6d-91d6-dca17911e4e1	2026-01-07 03:30:00.296647+00	2.8	11	692262	692262
031367a9-6bfc-490e-92eb-c76d62be8b02	2026-01-07 03:30:00.768065+00	2.8	11	657043	657043
4b55f927-4ca7-4c30-97e1-bfbc111bf766	2026-01-07 03:31:00.318496+00	2.5	11.1	303534	303534
3b5660ee-ae7d-41fd-a3a7-d32f42a20779	2026-01-07 03:31:00.923402+00	2.5	11.1	605241	605241
b4eac5d8-75e9-4136-9d17-81e39b01389a	2026-01-07 03:32:00.753287+00	3.3	11.1	783657	783657
266c50c7-02ae-43b9-9c55-71e87fcad0c9	2026-01-07 03:32:00.914046+00	3.3	11.1	526363	526363
bdb7865d-9ebe-4129-ae73-a762c884f8fb	2026-01-07 03:33:00.250184+00	11	11.3	589143	589143
ae810cf6-ca20-4570-9713-7558df0050cd	2026-01-07 03:33:01.021999+00	11	11.3	496180	496180
6a4c40db-dbfe-4c3c-b18c-3b21de44f3a8	2026-01-07 03:34:00.671249+00	3	11.1	616736	616736
4d977728-1671-4d25-be19-d41fad15e365	2026-01-07 03:35:00.30586+00	3.3	11.1	12083	12083
0e428d66-1177-4676-a625-77ee3c13796b	2026-01-06 17:29:22.307985+00	46.7	29.6	1372903	1372903
4ac0d3e4-e99d-44a8-a861-f77bb79d8fbb	2026-01-06 17:29:50.431798+00	35.1	29.4	3398479	3398479
62a4a806-0fea-4629-90e6-02658345a98f	2026-01-06 17:29:51.807314+00	41.9	29.4	436041	436041
e4dc95f6-0a58-4b8e-82d6-f75959a8b6b8	2026-01-06 17:30:25.894314+00	42.4	29.4	5396960	5396960
1ce1659b-375d-44cb-8e1d-f7bd3a38d5c8	2026-01-06 17:32:50.570382+00	34.1	29.4	4999155	4999155
3cf7ee6c-851c-41f0-b06f-51333f4dfe7e	2026-01-06 17:33:02.130917+00	49.7	29.4	489036	489036
492a6a86-e755-44c8-92a7-4003442931d1	2026-01-06 17:33:22.330898+00	40.2	29.5	496636	496636
bf4696a4-67a7-4e5b-8961-c7d0382aa3bc	2026-01-06 18:10:43.576786+00	44.2	29.5	3500346	92811
9285f8ac-1108-438a-8b5b-ccaf3e87d4d9	2026-01-06 18:36:43.987708+00	44.6	29.7	4382446	108670
b44496b2-6d51-4a28-aeb7-909b36e5adb0	2026-01-06 19:05:02.064463+00	48.4	29.7	5261720	5261720
075f7d52-9f92-4c81-ad61-16a17e74a816	2026-01-06 19:06:22.884479+00	43.1	29.9	418953	418953
410a6212-7c1c-429f-8307-b89b706b9f22	2026-01-06 19:06:50.479327+00	34	29.8	3667651	3667651
186cdb3e-a561-4f10-8056-b97d035d0e15	2026-01-06 19:07:22.664204+00	42.9	30	498261	498261
9c7abb66-c79d-4e28-b0e3-6dc0a6841c93	2026-01-06 19:07:50.576703+00	36.9	29.9	5273942	5273942
e87a3191-d11e-4efd-bfbc-214141115b69	2026-01-06 19:08:21.605975+00	46.1	29.8	2524410	2524410
e11bf041-3386-4b14-8a7f-f2ae65a62db1	2026-01-06 19:08:50.484709+00	39	29.9	770906	770906
1d7dacc3-dc78-4881-ac73-0d7cddbfda74	2026-01-06 19:09:22.253118+00	44.3	29.9	1814715	1814715
ab3caa5e-2582-4cf3-853b-fc7b14a75ecc	2026-01-06 19:09:25.947598+00	44.1	29.9	2392119	2392119
257a50f7-5013-46b7-96ac-cad20a3bacf6	2026-01-06 19:33:21.690032+00	33.4	29.9	3650280	3650280
81a57fc4-c2cd-47d6-8558-07dbd0501889	2026-01-06 19:33:22.760393+00	49.6	30	5233792	5233792
f270026f-d8a6-47d5-9b7f-5af70783a2bf	2026-01-06 19:33:50.642424+00	37.9	29.9	4885245	4885245
19f61233-75e6-4943-a9a8-1a4fb71a88ea	2026-01-06 19:34:22.726608+00	36.6	29.9	390108	390108
4737a1a8-c2d6-432e-b8ca-e06ea3ab870e	2026-01-06 19:35:21.55759+00	28.3	29.9	3030848	3030848
7aeedcaa-080c-475c-ac83-9ad72c20a531	2026-01-06 19:35:51.811714+00	71.4	30.1	5423764	5423764
9557fafb-a57a-4ed8-b0a9-3ce04c3fcb97	2026-01-06 19:36:21.64791+00	34.4	30	789759	789759
a23266c0-fd0f-4d5b-83f8-ec79bb15fcb4	2026-01-06 19:57:45.157266+00	36	29.9	4181619	105211
b324881e-bcf0-4667-b47a-a8f47eaaae92	2026-01-06 20:19:45.476757+00	36.8	30	4851507	143776
ce3d576d-1e46-4f61-9bd0-05a4c5e04bdb	2026-01-06 20:36:50.590967+00	39.7	30.1	5981642	5981642
ee60d0e1-f4b4-4e8a-b353-a9130a71a451	2026-01-06 20:37:21.513985+00	33.1	30	1148566	1148566
76dac563-9bb2-4693-9f1d-feda0fd21ee7	2026-01-06 20:37:22.744655+00	47.3	30.3	1420690	1420690
2fbd8257-2b29-4f80-bb1b-e66fa7ba28f7	2026-01-06 20:37:50.58797+00	31.8	30	529209	529209
94c92fbb-65a3-4c1b-8c02-367a55fb4d7c	2026-01-06 20:38:02.115152+00	37.7	30.1	4290206	4290206
e1bfe37e-cbe9-406b-a46d-fc487266f38c	2026-01-06 20:40:25.888263+00	50.6	30.1	3960563	3960563
16d71af3-8997-42f3-bf31-18021de414ef	2026-01-06 20:40:52.089061+00	44.6	30.1	4877692	4877692
4dbf83ec-1eca-49ab-bff8-dcb63e4303a9	2026-01-06 20:42:22.431169+00	50.8	30.1	5991925	5991925
b49e879b-0045-4fd0-a2ac-687c95ba0afc	2026-01-06 20:42:22.990954+00	50.8	30.1	6357260	6357260
2a2aed2c-ac68-4935-865f-3c9411faafbd	2026-01-06 20:43:02.080791+00	49.8	30.2	6528752	6528752
0f8b6945-064a-4a72-8246-a23aee3b1dc2	2026-01-06 20:43:22.358233+00	45.4	30.2	3526778	3526778
1f103858-e2c1-455e-9b81-7da44f2780a4	2026-01-06 20:43:50.609908+00	38.3	30.2	3367134	3367134
3e1c2eed-ac18-48bd-bd17-eefa0c274a04	2026-01-06 20:44:02.130802+00	52.3	30.1	6218316	6218316
9e055809-dc81-485f-a99a-768fba641310	2026-01-06 20:45:22.824175+00	42.5	30.1	469938	469938
ce4fcbbd-8770-4dab-8756-b8560001a3e5	2026-01-06 20:45:50.459859+00	36.7	30.2	750702	750702
3532302f-df46-4da0-8a10-55fc177001bf	2026-01-06 20:46:51.960507+00	75.9	30.2	1588455	1588455
48d39236-fc1d-4883-ab36-022dbf0d3816	2026-01-06 20:47:25.908352+00	54.1	30.1	3251454	3251454
d8ff1f6c-1cfd-4910-b159-29ec9e5e75ba	2026-01-06 20:47:50.568477+00	43.5	30.1	5120369	5120369
af96447e-1ae6-411b-b4b6-6480ec94bd7d	2026-01-06 20:47:51.820541+00	42.4	30.1	2827318	2827318
258eb82c-a660-4deb-af13-311a248511e2	2026-01-06 20:48:22.632632+00	39	30.1	2603609	2603609
f7e248de-cbc8-4cc6-8db3-b6df74612028	2026-01-06 20:49:02.128806+00	46.5	29.9	3747937	3747937
949776cc-9878-4b5d-91f0-6f591b853bfd	2026-01-06 20:50:22.708579+00	41	30	4569071	4569071
64aca722-6316-45cd-84f1-bc3c1d179ef9	2026-01-06 20:51:25.949919+00	50.1	30	2656086	2656086
ac456111-cc13-45f3-b3cc-fe36b82e85e4	2026-01-06 20:52:02.0932+00	46.5	30.1	646498	646498
c5e929b7-4f3d-4029-9a18-c6bc72d31f1e	2026-01-06 20:52:50.685474+00	42.2	30.1	4980145	4980145
7d27c617-0ec8-4c7a-90f5-45967f10e4f3	2026-01-06 21:00:46.085131+00	3.8	21.7	1200	185
63bddec1-45b2-48d4-aec7-4585ee2a67fd	2026-01-06 21:29:46.455399+00	4	21.5	1449	302
d8aeadfc-0b7f-4f54-9685-4d6143615888	2026-01-06 21:58:46.838379+00	3.8	21.5	1297	182
dd4f496c-7d7f-4eba-9570-bef15980f2bc	2026-01-06 22:27:47.139821+00	4	21.5	1559	186
9273dbf0-7612-4db5-aee8-36c2c0b23467	2026-01-06 22:56:47.485243+00	3.9	21.5	1572	160
9ca405e6-7a52-46d4-9ac8-e0c0a5e4b5e2	2026-01-06 23:25:47.813778+00	3	21.5	1587	194
231b9c19-bb4c-49c0-84a6-f472e355181d	2026-01-06 23:54:48.223628+00	1.1	11.1	1348	21
561248b2-6964-4a79-94f0-930aee187dc8	2026-01-07 00:23:48.572546+00	1	10.2	1508	28
171b1aa8-66ba-43ca-9ae2-8e9adf6cc842	2026-01-07 00:52:48.998914+00	0.9	10.1	1540	14
633b301f-a532-4321-ab2f-bdf81259f3dd	2026-01-07 01:21:49.361477+00	1	10.1	1640	18
78a7804e-bb2c-4f3d-bae3-e02785743df0	2026-01-07 01:50:49.748666+00	1	10.2	1275	20
0a5f6576-ea37-48b2-b874-bf3e8eaafb0a	2026-01-07 02:11:50.012781+00	5.1	11	65671	160205
14837ddb-358f-41be-b823-a01a809e8092	2026-01-07 02:28:00.214683+00	3.6	11.1	649014	649014
6fbf0f8c-15f6-4c45-a35d-745b3a722aa3	2026-01-07 02:28:00.790544+00	3.6	11.1	712415	712415
f1972634-bb47-4a7f-b7c7-8c1ebf89c526	2026-01-07 02:28:01.048534+00	3.6	11.1	406363	406363
aaf0c87f-4816-4855-9c8f-ab78065063ca	2026-01-07 02:29:00.886403+00	3.2	10.9	517306	517306
5b9774a7-be17-4a5e-95fb-d8e1067add2b	2026-01-07 02:30:00.26195+00	3.1	11.1	694514	694514
625af033-0d54-4b8d-9ad2-129072c0c31a	2026-01-07 02:30:00.983591+00	3.1	11.1	530150	530150
f2571e81-3e65-498a-8919-2ec5b00c58ee	2026-01-07 02:31:00.236444+00	2.8	11.1	543385	543385
e07170ad-162d-4fa6-9be8-388c66acb6b3	2026-01-07 02:31:00.97295+00	2.8	11.1	451699	451699
5c206bc2-3fbb-4265-8569-b4cb23d4b34b	2026-01-07 02:32:00.996806+00	3.1	11	535857	535857
9476e56b-3812-4bcb-a8f4-b85e7c04a7c4	2026-01-07 02:33:00.846388+00	6	11	512780	512780
35143db1-9f9d-4367-95f1-3f22892770d6	2026-01-07 02:34:00.834338+00	2.2	11.2	472008	472008
cfca818e-04aa-46cd-9191-d9fc819dc831	2026-01-07 02:34:01.095668+00	2.2	11.2	724490	724490
9ba2dd9d-5079-4860-8aea-69fb483d6cf4	2026-01-07 02:35:00.894868+00	2.4	11	559846	559846
73bc284a-3c0b-493d-ac47-cbfc09cb316f	2026-01-07 02:36:00.076274+00	2.7	11	9716	9716
bfe25ec4-e32d-46ea-828a-93261ca82b31	2026-01-07 02:36:01.064745+00	2.7	11	531060	531060
3084de6c-cbf1-4b2b-9091-5f47c149c8ce	2026-01-07 02:37:00.77646+00	2.9	11	507388	507388
151a03ce-2117-40cc-95be-0da93d50b7b1	2026-01-07 02:38:00.733199+00	2.7	11.1	618963	618963
d5372a0d-0d34-4fd9-90eb-d4744b0b8464	2026-01-07 02:39:00.464033+00	2.5	11	768485	768485
8d09df4a-93c1-4008-8a67-138c41f73684	2026-01-07 02:39:00.895008+00	2.5	11	474449	474449
4f939503-ec9b-4358-9221-88ca65c2ccdc	2026-01-07 02:40:00.208905+00	3.8	11	411609	411609
2d2674fe-eef3-4d65-95e4-3bc6ad7dfe50	2026-01-07 02:40:00.863362+00	3.8	11	199757	199757
7a34a6cb-9ffd-4385-b808-b584f7d34548	2026-01-07 02:41:00.112678+00	3.1	11	10362	10362
0fd39b1e-5fdf-4791-9fa0-1b96cf576172	2026-01-07 02:41:00.655924+00	3.1	11	622152	622152
1ea45d58-33e7-4bb2-85b9-26f3d0cc794a	2026-01-07 02:42:00.177722+00	2.8	11	542373	542373
3cdcfd54-67d4-4a6c-b2e3-b031999aa748	2026-01-07 02:42:00.661415+00	2.8	11	848462	848462
1d761cbe-9a65-4577-9312-24e1f90b4958	2026-01-07 02:43:01.094407+00	3.9	11.1	572621	572621
76e554fe-8fea-4b65-b9e4-0afbb44a6c2c	2026-01-07 02:44:00.828275+00	3.8	11	751508	751508
baeb64db-b704-4bbc-b38b-2e6c18250c27	2026-01-07 02:45:00.091083+00	2.4	11	7958	7958
d19e2023-a6fe-44fb-9cf7-a5d9deebdb12	2026-01-07 02:45:00.696909+00	2.4	11	605956	605956
7ab1ab57-7aa4-47bb-b3c0-4827a04da030	2026-01-07 02:46:00.041006+00	3.4	11	6750	6750
2c1406b7-c900-4c46-9a89-412c954ce091	2026-01-07 02:46:00.944888+00	3.4	11	430119	430119
627484fe-69c6-4c04-b6d9-7caa95d21f91	2026-01-07 02:47:00.812237+00	3.2	11	684948	684948
b764e00a-597b-454a-ab17-bd642fde7c2d	2026-01-07 02:47:50.506924+00	2.9	11	28779	17810
bc065989-3d8d-4bb1-a753-d09df10eff61	2026-01-06 17:29:22.748798+00	46.7	29.6	154824	154824
f6b24491-eeed-4a56-bf66-eb128b460150	2026-01-06 17:29:50.561626+00	35.1	29.4	4676944	4676944
afef7af8-c867-478e-a243-fe27b4fcf834	2026-01-06 17:30:22.919287+00	45.8	29.5	2541365	2541365
d9652b75-c1b2-4718-8225-47c2aa255901	2026-01-06 17:33:50.389784+00	37.3	29.5	5780447	5780447
d7665d81-6b13-4d45-ae9a-736c314ef401	2026-01-06 18:11:43.602706+00	41.8	29.7	4561647	122973
b6e5d209-83d1-4d26-8e7f-b8d94c0618be	2026-01-06 18:37:44.022543+00	36.1	29.7	3343808	82897
2bb9156e-c90a-42b7-b841-e959fab388eb	2026-01-06 19:05:44.390205+00	40.4	29.8	4088595	108042
255aed14-2d9d-41e7-b2a2-7b38d97863c1	2026-01-06 19:33:44.833494+00	40.9	29.9	4208279	105954
d0176a72-5dc4-485d-a0a6-1308786a9097	2026-01-06 19:58:45.181477+00	40.8	30	4527621	110559
30ab17c1-e3ce-4825-b938-179a98baeaed	2026-01-06 20:20:45.472834+00	38	30.1	4401933	119533
e5c3232c-56fa-42ed-bf8a-c09f4c26a63a	2026-01-06 20:36:51.746835+00	49.7	30.1	4089183	4089183
93a2d597-f3cc-4aae-bfe0-2e164e5330d7	2026-01-06 20:37:22.841496+00	47.3	30.3	435028	435028
feb160ab-cbb5-42ce-ae04-2cd0c76446b4	2026-01-06 20:38:22.793393+00	41.8	30.1	2973149	2973149
2df94389-07a8-4178-a746-71a8462f9860	2026-01-06 20:40:22.237834+00	44.5	30.2	4878486	4878486
d884c810-1b6d-463d-bdc6-28bfb2590b0f	2026-01-06 20:40:50.605603+00	32.6	30.1	6225798	6225798
adf0607c-8bb6-4bd6-8bbe-31f9233a2cf1	2026-01-06 20:41:25.912001+00	42.4	30.2	3519756	3519756
5ffe93ac-3a43-4468-83f4-5250c65b0e0e	2026-01-06 20:41:50.555522+00	60.8	30.2	1373014	1373014
904bf631-2bfc-4b13-b000-2b94c8bdbb01	2026-01-06 20:42:02.114568+00	45.1	30.1	4544722	4544722
c23879cf-da45-4afd-ad11-89dc9b1f76b5	2026-01-06 20:42:50.569631+00	40.3	30.1	720395	720395
b63f032f-10b1-40b8-a65a-d70b350df59b	2026-01-06 20:43:23.038545+00	45.4	30.2	952336	952336
5a819c70-46a5-4b78-a0cc-8dbaf6cab6d7	2026-01-06 20:43:25.897917+00	56.4	30.1	1429352	1429352
6160aafa-9961-437a-b348-4a04036aadae	2026-01-06 20:44:21.582275+00	31.6	30	4072480	4072480
6bc11b20-e756-439f-a571-be37185b895a	2026-01-06 20:44:22.336279+00	53.2	30.1	5203630	5203630
7f6c7628-1dd0-41f9-8634-105593b2e0cd	2026-01-06 20:44:50.718677+00	37.1	30.1	5089828	5089828
84b41381-22db-4cea-bf11-c69f39c31dff	2026-01-06 20:45:22.314645+00	42.5	30.1	3473686	3473686
b76f9816-e68d-45d6-a122-bfbe63634135	2026-01-06 20:46:02.111254+00	51.4	30.1	4936273	4936273
4e3b0810-73c0-4b4c-b34f-4bea7ff7d7c6	2026-01-06 20:46:21.634366+00	36.7	30	4491777	4491777
ad8b7708-8c5f-45b4-97f5-9f4ce5e3873a	2026-01-06 20:46:25.925581+00	62.7	30.1	2466223	2466223
8a28769f-192a-4fc4-9a2a-9c1eb1b98262	2026-01-06 20:47:02.111187+00	47.5	30.1	1632602	1632602
6fee8510-4ac0-48ab-bc57-3f96c75f0677	2026-01-06 20:47:21.584835+00	36.5	30.2	4274295	4274295
0bbeb4fd-022e-4f4f-9455-12504503823f	2026-01-06 20:47:22.696553+00	41.1	30.1	5403115	5403115
138f52a7-9dac-46a5-beaa-a3e12740f896	2026-01-06 20:49:22.75104+00	43.7	29.9	316409	316409
8e858448-f890-4168-8bd3-303b650cc535	2026-01-06 20:50:22.287222+00	41	30	4681554	4681554
19763336-99bc-446a-bac7-9d0234d50d6d	2026-01-06 20:50:51.930847+00	43.2	30.1	3713705	3713705
05489b75-5e0a-4211-9818-67ac46faf40d	2026-01-06 20:51:21.561163+00	32	30	1514113	1514113
487e1d9b-fe17-423b-b0ad-7024cfd9d673	2026-01-06 20:51:50.463756+00	39.1	30	4039294	4039294
ccbcaefb-1426-4f55-bcab-90c9c02f2fec	2026-01-06 20:52:22.575838+00	45	30.2	3930047	3930047
c7c65b26-306c-4268-ac60-12a647c405ec	2026-01-06 20:52:50.589489+00	42.2	30.1	3593359	3593359
fd976fda-5cf8-4042-9cb3-621d1c11ef6e	2026-01-06 21:01:46.083775+00	4	21.7	1215	190
b4a0ddbe-e955-4a2e-a705-5dfabc8e8839	2026-01-06 21:30:46.444914+00	3.8	21.5	1625	414
d55c9f42-5ec1-499a-bd88-7efa897c4bed	2026-01-06 21:59:46.846057+00	4	21.5	1227	154
a9aeb229-c34e-4269-b186-0dc062247080	2026-01-06 22:28:47.157324+00	3.7	21.6	1212	183
aec4a7bc-f5f0-49bc-9c91-bff5dcfd83f4	2026-01-06 22:57:47.501814+00	4.1	21.5	1874	325
381795f2-3f98-450f-be9c-c385a105c867	2026-01-06 23:26:47.829651+00	2.6	21.5	1610	196
0b985681-f2a7-4dfa-a6d3-681fca5f43fb	2026-01-06 23:55:48.199624+00	1.2	11.2	1860	17
567faefb-ef00-44c2-acb9-9e0337c0109f	2026-01-07 00:24:48.589077+00	0.9	10.2	1587	30
a66d020e-3da1-47e0-91eb-f65a39c74798	2026-01-07 00:53:48.986599+00	0.9	10.1	2135	24
53bda393-d07d-4772-88d5-2ac1d2965869	2026-01-07 01:22:49.37768+00	0.9	10.1	1700	23
ff7c4b2f-5f7a-4833-9d02-8f5e33ff0d6a	2026-01-07 01:51:49.778483+00	1	10.2	2138	19
139dff4e-5481-4eac-a479-b355f7f88713	2026-01-07 02:12:50.031952+00	3	11	47219	31826
1fb3bcf9-376a-4e56-af09-168b31ab0e6a	2026-01-07 02:28:00.803971+00	3.6	11.1	718432	718432
75352224-6012-4dd5-90dd-77bb405812f9	2026-01-07 02:29:00.328549+00	3.2	10.9	697267	697267
fc3f1c9c-5084-4d75-b40f-eec5637a5a8f	2026-01-07 02:29:00.802618+00	3.2	10.9	755799	755799
d0ae4faf-513f-4e64-8921-abfb7796acb6	2026-01-07 02:30:00.950785+00	3.1	11.1	662796	662796
b33e637c-6209-4221-87ed-24701203ffce	2026-01-07 02:31:00.070938+00	2.8	11.1	8032	8032
d970cd3b-ca75-40e5-a993-dd4fa23b16bc	2026-01-07 02:31:01.003137+00	2.8	11.1	495897	495897
cff84105-7f12-4c71-8852-0090724d2ba9	2026-01-07 02:32:00.077974+00	3.1	11	6843	6843
a6793f88-7e63-4d59-9258-8b66aa033b9e	2026-01-07 02:32:00.982129+00	3.1	11	596156	596156
8f0b2297-71c3-4198-af76-e65b3d913b33	2026-01-07 02:33:00.74577+00	6	11	444726	444726
907d98e4-180c-411e-9eaf-37feda915b31	2026-01-07 02:33:00.940692+00	6	11	686103	686103
868c2bb2-55c8-4902-aaf2-26c8425c48e9	2026-01-07 02:34:00.04874+00	2.2	11.2	9696	9696
c35b5b3f-6b44-4cb9-bb92-82df7a051422	2026-01-07 02:34:00.958423+00	2.2	11.2	720229	720229
630acdf0-c66e-47c2-88a9-28313d239c2c	2026-01-07 02:35:00.104817+00	2.4	11	10744	10744
20b975c4-0853-42ff-8844-6252ec413928	2026-01-07 02:35:00.820784+00	2.4	11	354168	354168
3d310683-50ab-4038-9367-deabce25bff4	2026-01-07 02:36:01.097001+00	2.7	11	460195	460195
b3f52150-1ef3-4f25-91e7-adc18432e7db	2026-01-07 02:37:00.080547+00	2.9	11	7897	7897
1fe5b0ae-8374-490b-83df-92cc882a0274	2026-01-07 02:37:00.706352+00	2.9	11	760041	760041
3f047c18-e7b3-4b8f-b7bd-ce1486bbfc74	2026-01-07 02:38:00.748818+00	2.7	11.1	658802	658802
40040579-cee3-44d3-bf74-397d194a3394	2026-01-07 02:39:00.768068+00	2.5	11	640036	640036
bd0c0c75-635d-4241-8610-6f42fed53b6a	2026-01-07 02:40:00.871164+00	3.8	11	212100	212100
0e6781f0-d068-4d5a-94ef-708a02a83171	2026-01-07 02:41:00.681288+00	3.1	11	944421	944421
83cf1340-835d-4e57-9fbd-0b1b27ab7d15	2026-01-07 02:42:00.713672+00	2.8	11	881969	881969
2c457081-2eee-4e21-b1c2-8718d311ad93	2026-01-07 02:43:01.079761+00	3.9	11.1	503870	503870
57a77051-0b8f-4d30-9857-f12841e9d215	2026-01-07 02:44:00.105156+00	3.8	11	7641	7641
503aedfc-cdd4-4542-9e70-27c9dc13747c	2026-01-07 02:44:00.286655+00	3.8	11	497726	497726
155d97dc-6bf4-414b-9491-b4da9881d51b	2026-01-07 02:44:00.772229+00	3.8	11	583930	583930
f8e83f00-24e2-42ce-99be-56490230dc7e	2026-01-07 02:45:00.746583+00	2.4	11	679801	679801
202c9b8d-e7cf-4a4c-88bf-e811fb152099	2026-01-07 02:46:01.008134+00	3.4	11	345250	345250
a05e9623-0ba5-4fd1-8d2a-04090868ff72	2026-01-07 02:47:00.695696+00	3.2	11	591023	591023
badce024-4a28-40cf-af45-3c01c9300285	2026-01-07 02:47:00.970986+00	3.2	11	460728	460728
f6c837e9-1061-478d-8687-b6c7161a20e3	2026-01-07 02:48:01.044174+00	2.8	11	589106	589106
f9303229-3d1a-4ec8-b231-297a628acb64	2026-01-07 02:48:01.122361+00	2.8	11	623168	623168
6d7581b5-afc2-406c-ac75-2ffa047a9db4	2026-01-07 02:49:00.049305+00	3.1	11	7755	7755
be61b191-7d6e-4de9-a50d-946c3a0f7f2e	2026-01-07 02:49:00.749143+00	3.1	11	768854	768854
81cb3e5a-7969-4cc4-b70b-2c653c65ceab	2026-01-07 02:49:00.78048+00	3.1	11	627720	627720
5bdbc4e1-92e3-4fcb-b59c-d08a6722df2a	2026-01-07 02:50:00.770252+00	3.3	11	621545	621545
f8aa6677-ff49-4101-9cd3-dc34c58ee5a9	2026-01-07 02:50:00.821793+00	3.3	11	913189	913189
7f12a4b1-a71a-4067-8ce2-29d19f32717e	2026-01-07 02:51:00.783007+00	2.4	11	589423	589423
f174f009-5c9c-4196-ad27-94eedeea2160	2026-01-07 02:51:00.828216+00	2.4	11	549604	549604
510b5fbe-64aa-4e61-9f5e-d2f64bd39e4c	2026-01-07 02:52:00.70673+00	2.5	11.1	708850	708850
6edf2de2-e73a-423a-a389-692d1b21a640	2026-01-07 02:52:00.746469+00	2.5	11.1	454028	454028
260c1bc7-6445-4a0e-bcaf-598a0618b0ec	2026-01-07 02:53:00.316032+00	3.2	11	578925	578925
a09f1c2a-d039-4a21-9b0f-d4b0f8af672d	2026-01-07 02:53:00.793888+00	3.2	11	615138	615138
e1fe9049-351d-40aa-9d91-35019d3a7668	2026-01-07 02:53:00.87294+00	3.2	11	734880	734880
4f5443cc-e35f-4f26-bddd-a0e742394cfe	2026-01-07 02:54:00.935679+00	2.6	11	608678	608678
592371a0-aaab-4958-8c4f-f546bb41f307	2026-01-07 02:54:00.969876+00	2.6	11	564887	564887
5cd6aee2-488d-4bf5-8aa2-1b9b6a35237c	2026-01-07 02:55:00.013961+00	2.8	11	7188	7188
0df1d178-3ad3-411c-a14a-ecc2218ac380	2026-01-06 17:29:22.875245+00	46.7	29.6	2315051	2315051
f34b52a2-8580-4419-99dc-e1df952a5ccc	2026-01-06 17:29:25.931467+00	43.4	29.5	1146294	1146294
adff3f4d-7b67-486d-8c07-9fb39da64d2b	2026-01-06 17:29:43.006067+00	43.7	29.5	4481518	118102
fb4845d9-8c7c-400d-b360-153aedddc7b6	2026-01-06 17:30:21.53864+00	29.4	29.5	4657888	4657888
26a98d7b-2130-4144-bc46-93e2660c7268	2026-01-06 17:30:51.775024+00	38.9	29.5	5851727	5851727
9d29c48a-6ce5-4eb3-a1a6-357f6726fd87	2026-01-06 17:31:21.571465+00	32.7	29.4	718200	718200
05b3d8f5-4d28-46a1-967c-d5a8fee9305b	2026-01-06 17:31:50.566127+00	41.8	29.5	3341452	3341452
57f71247-f500-44e6-8c67-3db1b567c242	2026-01-06 17:32:21.538217+00	29.9	29.4	3619535	3619535
31f5f79a-7671-4bce-a296-83d93e373ac9	2026-01-06 17:32:22.32452+00	38.9	29.7	537973	537973
3a69f39d-4f05-42e4-8e18-ac73f0a0bbb1	2026-01-06 17:32:52.1982+00	40.8	29.5	346007	346007
4fd211d3-74f9-45a7-b01d-be49194bfa59	2026-01-06 17:33:22.745294+00	40.2	29.5	4008869	4008869
2c55be7c-c888-4fbb-911e-297d2f62b943	2026-01-06 17:33:52.074143+00	42.7	29.5	1802437	1802437
6c61dc88-604b-48f1-b955-5e72524e8839	2026-01-06 18:12:43.643666+00	43.6	29.7	4066893	106474
5512c3e2-8563-44b6-b61d-cf0e3376bc3d	2026-01-06 18:38:44.022187+00	44.9	29.8	4346734	112673
6be6f645-0994-4157-8e57-68bdc402bbdd	2026-01-06 19:06:25.923111+00	57.7	29.8	1929248	1929248
5fa3a8a0-a0b3-48cb-964b-9ac5739a377f	2026-01-06 19:07:02.100107+00	44.2	29.8	4755209	4755209
156c55bc-7a1c-4a00-9823-3b36cc90336a	2026-01-06 19:08:22.751802+00	43.5	29.8	217017	217017
74c6c690-9666-4241-afbb-86d89577f2c1	2026-01-06 19:08:25.923274+00	44.1	29.8	581112	581112
16a55e3e-7f90-4a89-bb0a-90b0a1afeb06	2026-01-06 19:08:51.731371+00	45.2	29.9	4650366	4650366
90843bf3-22e1-448e-9642-39e4cc19e8ac	2026-01-06 19:09:22.899359+00	44.3	29.9	844487	844487
b19595d9-e183-4bd5-8556-4761e03ab439	2026-01-06 19:10:21.551773+00	34.4	29.9	5327454	5327454
be1dfc2c-d6ee-4127-b6f4-4ca6e37ce5da	2026-01-06 19:10:25.959408+00	55.2	29.9	2727886	2727886
d4c66cd2-6bde-473a-aa3c-d2f2ddab7c16	2026-01-06 19:10:51.765255+00	40.4	29.9	294919	294919
5dd738c7-37d1-4299-befb-851a70c5f7b7	2026-01-06 19:11:21.564828+00	43.8	29.7	740208	740208
648f1adb-0cb3-447d-84ac-8b23ccca0c91	2026-01-06 19:34:22.65659+00	36.6	29.9	5432269	5432269
bf696f0a-cb8f-485d-8a17-f2159372c417	2026-01-06 19:35:50.463932+00	40.2	30.1	5364775	5364775
5cd80834-f4a3-4763-8697-62503a42cd16	2026-01-06 19:36:22.36314+00	46.7	30	5908252	5908252
e34302ab-edde-4f1a-a42c-402713d8b4c7	2026-01-06 19:59:22.293895+00	40	30	673356	673356
49025413-e00c-4652-8797-26f4089d2603	2026-01-06 19:59:50.480182+00	36.8	30	6050317	6050317
0db57277-d9a5-4b82-9dce-2bc71eba87eb	2026-01-06 20:00:22.829382+00	49.6	30	5728875	5728875
0cb087df-c34f-42b8-a677-75aa924e8ccb	2026-01-06 20:01:21.545188+00	34.4	30.1	872510	872510
90d83f4a-756a-4d21-9fba-cd3ff5ef2600	2026-01-06 20:01:51.822115+00	47.7	30.1	2897367	2897367
6541f68c-6932-49fe-81df-26ba616800eb	2026-01-06 20:03:02.094589+00	46.1	30	4285449	4285449
df277f64-d012-43c9-aab5-1dfbef72c18f	2026-01-06 20:03:21.569502+00	34.1	29.9	1852468	1852468
64e13741-2f04-49cd-a148-fa54627aea87	2026-01-06 20:21:45.534733+00	41.8	30	3983308	100796
a1e6a8c4-191f-4d89-9a47-5689027f233e	2026-01-06 20:37:25.947399+00	43.2	30.1	2787998	2787998
717b3b12-4cfc-4a97-aa85-5f80d8709af1	2026-01-06 20:37:50.691032+00	31.8	30	4728184	4728184
febe6cbc-8865-495b-9293-f3833b8f733e	2026-01-06 20:37:52.08032+00	42.8	30.1	180567	180567
6d556354-8e01-46ef-8394-0ddf040701e8	2026-01-06 20:38:22.902464+00	41.8	30.1	2597452	2597452
9c593bc5-c2ab-4e42-bd5d-ba7f47d1caa7	2026-01-06 20:38:50.551505+00	36.2	30.1	5716000	5716000
7b14f029-fefc-49b6-800b-7644e384832e	2026-01-06 20:39:21.701681+00	30.6	30	1020747	1020747
325247de-f02e-44d0-9893-226ba9325772	2026-01-06 20:39:22.96766+00	37.1	30.1	256679	256679
a8ed9402-f37a-4a8d-b888-4d281aa23729	2026-01-06 20:39:51.935543+00	47.3	30	3014896	3014896
ec1cfb72-d0af-4bf6-94b2-fbb25b9975db	2026-01-06 20:40:02.09502+00	53.4	30.1	6127211	6127211
5a13158b-13df-4859-923d-3de185d6fdfe	2026-01-06 20:41:22.735035+00	47.3	30.2	2990635	2990635
68abf1f7-a328-4811-aaeb-54f6585362f0	2026-01-06 20:43:22.928639+00	45.4	30.2	3023399	3023399
de4b85cd-6f60-4a85-a18e-8bdfdd29e658	2026-01-06 20:43:52.085206+00	72.5	30.2	3218964	3218964
094aadfd-c8e1-4f5a-9392-9472b2032fea	2026-01-06 20:44:25.947499+00	51.3	30.2	2537330	2537330
3fd0df55-bb73-4f8b-9e01-d33fea36dd19	2026-01-06 20:44:50.631871+00	37.1	30.1	3149770	3149770
a5b67763-c87e-4512-929b-51c3f83f48fb	2026-01-06 20:47:22.37297+00	41.1	30.1	3862012	3862012
64934e7b-ef01-4415-a3ad-bda9e7f6a3b3	2026-01-06 20:47:50.658327+00	43.5	30.1	4142068	4142068
e5895acc-e904-49b2-8d1c-c3997917f580	2026-01-06 20:48:22.280581+00	39	30.1	933804	933804
8078c46d-14c4-4163-943a-0465e2402764	2026-01-06 20:48:50.657906+00	34.9	30.1	4049456	4049456
3dc5fd80-e69a-4af9-aa9a-9385762ef1db	2026-01-06 20:49:22.799715+00	43.7	29.9	5822903	5822903
f95dec04-56fc-4f5e-a819-6b3c6da9d4ea	2026-01-06 20:49:50.523659+00	33.1	30	3119598	3119598
1ac7410e-101a-4239-9993-5b8217a93d06	2026-01-06 20:49:51.940983+00	41.2	30	578913	578913
3748b048-1e8c-471d-88a6-306b3ab2d213	2026-01-06 20:50:22.621786+00	41	30	4659167	4659167
b88e7076-a084-4361-82c3-c9df481bfb42	2026-01-06 20:51:02.111715+00	46.7	30	5736731	5736731
3fc03ec3-8e1d-4601-b5fc-b4d62b5ff41a	2026-01-06 20:52:25.884829+00	57.8	30	1189450	1189450
20c1384d-73db-42fa-a479-fda18c880abd	2026-01-06 21:02:46.139329+00	3.9	21.6	1327	186
95d56d90-c206-4660-9cc4-2064fb7f536a	2026-01-06 21:31:46.480096+00	3.9	21.5	1333	189
b39a599d-57af-41f8-a61a-c2d84065292e	2026-01-06 22:00:46.829402+00	3.9	21.5	1241	143
97660d62-2b31-49be-b553-d7f9b36056ca	2026-01-06 22:29:47.185784+00	4	21.6	1281	173
5ad1aefe-0ca4-47e8-a3fa-9ba3d461281b	2026-01-06 22:58:47.549809+00	3.8	21.5	1583	315
f86b1ef1-4a9d-447a-b07d-f0d29600692d	2026-01-06 23:27:47.871033+00	3.1	21.4	1600	201
1fa614b5-539f-4a4c-9a3c-baa68881ec04	2026-01-06 23:56:48.216439+00	1.1	11.2	1350	17
98069459-838f-4b85-887c-c59b4dc38e92	2026-01-07 00:25:48.579485+00	1.1	10.2	1504	9
f82b7450-f712-4206-86e6-07f178974ecb	2026-01-07 00:54:48.995712+00	0.9	10.1	1786	17
eb4b249c-bbaf-44fa-a01b-420bfb68888d	2026-01-07 01:23:49.395464+00	1	10.1	1601	24
eb2f6121-5286-4433-8ffc-d5e1c6b4bc69	2026-01-07 01:52:49.77761+00	0.9	10.2	1608	19
16c9a866-60db-4c5f-b5c3-e3f85761dc95	2026-01-07 02:13:50.08782+00	2.9	11	69266	111647
8fd9a39a-10e6-43e7-b315-835492dfd84d	2026-01-07 02:28:00.822565+00	3.6	11.1	745906	745906
e40aa5df-b365-42ec-96bd-fbb5b9111aa6	2026-01-07 02:29:00.814749+00	3.2	10.9	560471	560471
9f8b9d26-0ac2-4eb0-a26d-3ff0caf6832c	2026-01-07 02:30:00.094597+00	3.1	11.1	7295	7295
9eff3ace-6e3c-47ad-ba75-89acb671fe98	2026-01-07 02:30:01.030971+00	3.1	11.1	702581	702581
75a77be0-bf03-4fd9-af7d-d5dc5eb130b7	2026-01-07 02:31:01.05369+00	2.8	11.1	639610	639610
d58e2e1c-84c2-4893-be66-0b5bb416e0d1	2026-01-07 02:32:01.035109+00	3.1	11	291099	291099
9029222d-3fa8-41c8-a7c6-66873ad02b9d	2026-01-07 02:33:00.799285+00	6	11	691658	691658
f5c1bb1e-ebbf-4371-90a7-c6ecc8a05ab6	2026-01-07 02:34:00.181423+00	2.2	11.2	743407	743407
520e510b-8194-47f3-b9c7-eef9d77641f4	2026-01-07 02:34:00.947336+00	2.2	11.2	297142	297142
259131b7-bde3-4033-b224-ca74b818286c	2026-01-07 02:35:00.290226+00	2.4	11	308400	308400
2c7e92e5-db6d-489f-9a83-e55fae4e2d0c	2026-01-07 02:35:00.810288+00	2.4	11	926402	926402
e1f52c12-aafd-445f-a3a9-ffc262d1093e	2026-01-07 02:36:01.01839+00	2.7	11	470264	470264
8d079553-f5b2-46e3-aa3f-568f11684e2d	2026-01-07 02:37:00.740564+00	2.9	11	342513	342513
7f830c33-5c97-46ae-9a2d-d489add23cbf	2026-01-07 02:38:00.604953+00	2.7	11.1	779183	779183
05b9695c-e1dc-4179-a2bb-e336297f9289	2026-01-07 02:38:00.8487+00	2.7	11.1	397427	397427
2d51afdb-9fba-491b-bfa7-8dfa21e6c7b4	2026-01-07 02:39:00.165465+00	2.5	11	663365	663365
af1478d0-5537-47a2-aa73-c8a0742c52d7	2026-01-07 02:39:00.630567+00	2.5	11	566977	566977
e63450e7-2124-4d50-bbe8-8bc289577d57	2026-01-07 02:40:00.056516+00	3.8	11	8425	8425
5a8376a8-fd32-44ed-bfb7-815ab63350af	2026-01-07 02:40:00.880918+00	3.8	11	300355	300355
03846bde-7d6c-455c-8073-ff4cacd537d6	2026-01-07 02:41:00.209074+00	3.1	11	584748	584748
f6901301-f7fe-4129-a7f1-8942ca39136b	2026-01-07 02:41:00.647381+00	3.1	11	481823	481823
da804975-0f10-4e0d-9ba4-795db0f88645	2026-01-07 02:42:00.058697+00	2.8	11	7251	7251
6dd3884e-0c41-4e45-8547-a315579699a6	2026-01-07 02:42:00.68164+00	2.8	11	572665	572665
b45e276c-fff3-4abb-a7a2-f126f5630ab4	2026-01-07 02:43:00.314248+00	3.9	11.1	586445	586445
e3865624-2d7e-49dc-8702-a248240d1d4d	2026-01-07 02:43:01.004292+00	3.9	11.1	470370	470370
0df27e93-a951-4672-99b4-6de97dcd8c88	2026-01-07 02:44:00.700342+00	3.8	11	398750	398750
2948b108-c7a7-47d8-afae-152e9eb599e4	2026-01-06 17:30:22.435757+00	45.8	29.5	5129342	5129342
a850e9d5-c26b-40b6-ae5f-583cf6e3ac02	2026-01-06 17:30:42.957615+00	51.1	29.5	4608104	126817
1c0606a9-5b17-47cc-a1ca-98cdc8806ba7	2026-01-06 17:30:50.542416+00	43.4	29.5	2490481	2490481
8a64dc62-d644-46e0-81f5-6da14a8533c6	2026-01-06 17:31:22.774372+00	40.2	29.7	520717	520717
4642fecd-c8bb-4303-882e-324044c40d06	2026-01-06 17:31:42.984757+00	36.5	29.5	3780361	86277
bd287ee4-8053-48bf-845f-74d6e11234a8	2026-01-06 17:32:02.087334+00	43.2	29.6	751508	751508
48eadc68-98f5-4908-8210-828ca67083c7	2026-01-06 17:32:43.037571+00	48.3	29.4	4328656	116414
2ad3d16e-aa0c-4073-ad50-766a420a8d9e	2026-01-06 17:32:50.642682+00	34.1	29.4	622899	622899
09e45a63-8484-4533-91e5-d1f3fe64de36	2026-01-06 17:33:21.549664+00	29.1	29.6	4973955	4973955
75794c7b-c8b0-4eca-a0eb-6e43fd2b9942	2026-01-06 17:33:22.635572+00	40.2	29.5	232565	232565
c7dd42a4-ef03-4b36-9be6-f0aa9f6f0888	2026-01-06 17:33:25.934198+00	42.7	29.4	1118623	1118623
645b156d-3616-4172-b7f5-3d260afd8bcf	2026-01-06 17:33:43.047824+00	42.8	29.5	4456309	119574
a5564daf-ecaa-4564-b9fe-cfd5ffa9d23d	2026-01-06 17:34:21.568259+00	29.9	29.5	4493971	4493971
2cda6dc2-0a80-4616-af26-12edeef5cdde	2026-01-06 17:34:22.320328+00	35.9	29.6	4977456	4977456
ecb8f7d4-8386-4942-a10e-54ed002d3eb2	2026-01-06 17:34:22.703745+00	35.9	29.6	244545	244545
e37b0a97-7570-4b37-9e04-5686edce5e65	2026-01-06 17:34:22.767856+00	35.9	29.6	371087	371087
6260fcfd-3c47-4b3b-b4f0-fcfbbef6121e	2026-01-06 17:34:25.940017+00	54.2	29.5	2468267	2468267
57d6c3e2-d46a-46ce-bdbe-73eef2e47a3a	2026-01-06 17:34:43.08075+00	43	29.6	3663771	100262
53255284-ea9f-4363-893d-7829af346e32	2026-01-06 17:34:50.336455+00	32	29.5	5438659	5438659
37ebc01e-9ad2-455b-94be-1dd075671429	2026-01-06 17:34:50.48526+00	32	29.5	626641	626641
952ab477-7215-4935-a32c-3f170bb67803	2026-01-06 17:34:51.728896+00	37.4	29.5	494394	494394
ea66723d-b892-49de-9d48-767ac740bbc9	2026-01-06 17:35:02.10012+00	44.9	29.6	614552	614552
e3e8c519-4fd5-4142-bdd4-954f14decb30	2026-01-06 17:35:21.555783+00	31.6	29.5	4546628	4546628
10e02a12-0d56-4d1a-93d3-afa0230187d1	2026-01-06 17:35:22.333696+00	42.2	29.5	3652744	3652744
fb315e36-5ca2-4dc4-b082-6f6d9967b04e	2026-01-06 17:35:22.746103+00	42.2	29.5	762834	762834
11cebe08-e6d1-458a-b584-a4fbf517be29	2026-01-06 17:35:22.867506+00	42.2	29.5	4518589	4518589
71f13409-7483-4dee-b053-c7f0cc0b5952	2026-01-06 17:35:25.938173+00	48.1	29.4	4399531	4399531
ae82aefb-8779-47ec-8948-628540a0aedf	2026-01-06 17:35:43.040538+00	43.6	29.6	3939843	109028
2f8e5dfe-88eb-4e76-a241-40fbd40edc22	2026-01-06 17:35:50.372828+00	34.1	29.5	5698856	5698856
6a79ccaa-c26b-4ae9-9c0d-96813d63ddc3	2026-01-06 17:35:50.511719+00	34.1	29.5	842534	842534
dc581ed7-bbcf-48a2-8fe9-2634ed7044fc	2026-01-06 17:35:51.711449+00	68	29.5	5018708	5018708
df8421fe-d532-4dfc-8f94-9f8e8f4cc161	2026-01-06 17:36:02.068833+00	46.9	29.6	696743	696743
98355d0c-1ab2-4888-b7c5-0f633a6f4c3b	2026-01-06 17:36:21.518755+00	30.8	29.4	879696	879696
3c4ae0de-ebc8-420d-a8a9-1db6a0935dc7	2026-01-06 17:36:22.225924+00	34.7	29.6	3776192	3776192
07532651-30fc-4e8b-830d-a8547da12def	2026-01-06 17:36:22.559944+00	34.7	29.6	249524	249524
d6646cfc-a224-4756-b6cb-439b259f851f	2026-01-06 17:36:22.636006+00	34.7	29.6	295970	295970
99490e5c-eab8-48f8-8152-c798b2dc0e59	2026-01-06 17:36:25.950265+00	49.9	29.5	2577090	2577090
acba905f-267c-4601-bdc3-b3f5ac9ab793	2026-01-06 17:36:43.097233+00	36.8	29.5	3750228	98435
87484e60-e92a-4fd3-ab95-ef05d94c02a3	2026-01-06 17:36:50.501135+00	37.7	29.5	3132152	3132152
6b5a8a32-6012-41ba-87aa-efea9912cca8	2026-01-06 17:36:50.588407+00	37.7	29.5	3761584	3761584
7ad085b9-4bcf-4b2b-a085-983869a91f96	2026-01-06 17:36:51.951375+00	71.5	29.5	3836671	3836671
ad9fcf78-5bcd-4c4c-847e-47d67af04fcb	2026-01-06 17:37:02.112566+00	48.4	29.5	693621	693621
f7e0a326-9264-4635-84b9-71ffd96ac728	2026-01-06 17:37:21.652408+00	30.8	29.4	832994	832994
1e2aa3bf-f741-4249-9b50-7ce1010cdac8	2026-01-06 17:37:22.395295+00	41.4	29.5	551487	551487
2b058f40-4fdd-479b-a69d-c5197bd52421	2026-01-06 17:37:22.718265+00	41.4	29.5	3333790	3333790
9aaeba6b-9c2e-4fae-9fee-fc368a43f258	2026-01-06 17:37:22.861902+00	41.4	29.5	1566310	1566310
632cd3d2-96c6-4b42-b209-43a30f967519	2026-01-06 17:37:25.937081+00	40.8	29.6	1758562	1758562
c4a571a2-0278-44bf-b7a9-5503033ca9f3	2026-01-06 17:37:43.103207+00	43.7	29.5	4127153	111797
5b65d0bc-94fe-46f4-9248-1970da74d276	2026-01-06 17:37:50.532822+00	37.1	29.5	895541	895541
cfa61f5e-031b-401b-b932-99df47993bf4	2026-01-06 17:37:50.616137+00	37.1	29.5	530912	530912
988684f5-d8f0-4561-8bc9-e13b77e436b0	2026-01-06 17:37:52.076153+00	42	29.6	5587325	5587325
68d0a2de-5cec-4806-bf75-541d3d5fc8b4	2026-01-06 17:38:02.059917+00	50.2	29.7	3643297	3643297
36c42dfb-dc1f-4639-a74b-a628fb8eb0fd	2026-01-06 17:38:21.546933+00	31	29.5	3711137	3711137
6a0a5607-16ee-4158-8af4-168943dc244a	2026-01-06 17:38:22.28403+00	36.3	29.5	1183172	1183172
41d6bc86-e6bc-416e-adca-030384dec8e4	2026-01-06 17:38:22.661227+00	36.3	29.5	3128846	3128846
3400386f-5fcf-4ec4-9ffe-a4e957cee9b6	2026-01-06 17:38:22.733052+00	36.3	29.5	3163389	3163389
e1aede10-09b4-4cfa-9fcb-bd7099e01e83	2026-01-06 17:38:25.930464+00	44	29.5	2297885	2297885
4ab3b09b-b188-4ddc-9c14-fea025acfdaa	2026-01-06 17:38:43.106873+00	37.4	29.5	4244157	115501
df396d7b-e3db-4565-bb03-d08fc0a43970	2026-01-06 17:38:50.33433+00	34.2	29.5	4071934	4071934
41b6b2a6-a117-40fe-aa9e-84d949ab8570	2026-01-06 17:38:50.466649+00	34.2	29.5	3732519	3732519
79528c25-c9db-40cd-987d-bd1a2ab679ce	2026-01-06 17:38:51.819363+00	69.9	29.5	420398	420398
1eb1cb4a-2b10-4282-abeb-0f4b64bf8a26	2026-01-06 17:39:02.150393+00	43.5	29.5	3459039	3459039
307c74dc-c414-4f79-bba3-a285fccd4f42	2026-01-06 17:39:21.576407+00	30.2	29.6	6053437	6053437
fc29ec0f-4f41-48a6-9b44-baedf4cdf0e5	2026-01-06 17:39:22.384988+00	39	29.6	756558	756558
8cdfe0a0-cc25-41b7-a6f7-0f6b2b2b7374	2026-01-06 17:39:22.703873+00	39	29.6	5019623	5019623
18cd571d-d305-42e0-a262-a4d631f51514	2026-01-06 17:39:22.786806+00	39	29.6	3840724	3840724
17bb408a-ced3-45b4-999f-2a7d23621477	2026-01-06 17:39:25.946721+00	52.5	29.5	2827496	2827496
6894e79b-d490-4640-998e-7c2847ffc193	2026-01-06 17:39:43.124719+00	35.7	29.5	4939106	133087
29b0da12-f17e-4091-9b09-be62969ba6ee	2026-01-06 17:39:50.562938+00	35.7	29.6	3107076	3107076
4ad95f8d-db2c-4221-acb3-a21aade4094a	2026-01-06 17:39:50.643044+00	35.7	29.6	684246	684246
c53c8a57-1088-4a1d-a4c4-046bb42eb693	2026-01-06 17:39:52.130398+00	74.4	29.6	3334482	3334482
b7b5646c-7d71-4258-9256-fd7132462791	2026-01-06 17:40:02.096711+00	49.9	29.6	3225308	3225308
94c3708e-5960-4b92-a86b-d3151d5e8dfd	2026-01-06 17:40:21.579535+00	29.6	29.5	5418675	5418675
ba65fd3f-877e-4336-aa0d-938c7304acb5	2026-01-06 17:40:22.376863+00	39.9	29.6	801751	801751
4ede4568-3570-4b28-935b-26aae480c975	2026-01-06 17:40:22.704761+00	39.9	29.6	4436575	4436575
a05e18ca-7ab7-43ca-8899-626aa8a325d4	2026-01-06 17:40:22.770279+00	39.9	29.6	248865	248865
7e1db803-144e-40bc-87f8-eb6578ea2f8c	2026-01-06 17:40:25.94789+00	43.2	29.4	894506	894506
32b0490d-723b-41b8-b6d8-3b5767f45821	2026-01-06 17:40:43.092079+00	37.2	29.5	4008110	107984
183dfbea-b98e-4efa-a88f-5330480dd150	2026-01-06 17:40:50.511986+00	30.6	29.5	4275354	4275354
20eac139-5171-4d48-a0c3-899a9c606951	2026-01-06 17:40:50.614862+00	30.6	29.5	5744918	5744918
a7e2f74d-9f34-442d-a058-704cd10c1760	2026-01-06 17:40:51.876908+00	38.4	29.6	355595	355595
073dca07-090f-4c7a-a9ef-29e9a87455bc	2026-01-06 17:41:02.098012+00	50.7	29.6	4056731	4056731
7557d0cc-4e03-40c3-8d11-06d0c04ae9e7	2026-01-06 17:41:21.675122+00	34.4	29.5	4097355	4097355
f6d7b25f-9b6b-4169-994e-0cf5735e7838	2026-01-06 17:41:22.353122+00	42.6	29.7	3696161	3696161
548f9a09-38a1-4b86-8368-5514c30e39a6	2026-01-06 17:41:22.707913+00	42.6	29.7	3936305	3936305
5f1ef2ed-8837-4f66-9d0b-b250de3a8b7c	2026-01-06 17:41:22.795867+00	42.6	29.7	2047269	2047269
9a5f119c-9a5a-45e7-9c79-a7207d4a6da9	2026-01-06 17:41:25.949367+00	43.9	29.6	3546200	3546200
611ac620-82a5-4f7a-82fc-79be0d1dd350	2026-01-06 17:41:43.160516+00	40.3	29.5	4166416	111834
8af2d487-0e1d-4c22-8220-3b8daeb40bc7	2026-01-06 17:41:50.433376+00	40.6	29.6	5787059	5787059
b2fc8af2-e942-45f2-8c18-80ea6c5bb7af	2026-01-06 17:41:50.558757+00	40.6	29.6	541797	541797
0dd04007-8b26-4874-84f7-3b6bf8abc091	2026-01-06 17:41:51.692903+00	44.9	29.6	3518368	3518368
e20c3d0b-c810-490b-8688-a69b5beb25a1	2026-01-06 17:42:02.098464+00	42.8	29.6	671328	671328
9005fbe8-1a7d-4fae-bf0c-c31fcd488420	2026-01-06 17:42:21.554518+00	34.4	29.5	2654746	2654746
706933d4-7e40-4eb5-9871-99abe4d6c5c2	2026-01-06 17:42:22.325414+00	46.5	29.6	4632756	4632756
a09dc422-a732-4e0a-b484-efc072931d93	2026-01-06 17:42:22.665459+00	46.5	29.6	4207028	4207028
4e7eea04-0ffc-42c2-9932-796e40eff08c	2026-01-06 17:42:22.779763+00	46.5	29.6	2777985	2777985
632c4a82-0c67-4353-b789-3e8a6a26dfee	2026-01-06 17:42:25.913689+00	53.1	29.6	1066178	1066178
8d42b15e-9d41-4b26-a831-fbc62cd5b1bc	2026-01-06 17:42:43.167311+00	37.1	29.5	4568889	122047
ac1419c7-7ff8-4c6a-8c6a-c8e41da341d3	2026-01-06 18:13:22.3375+00	44.3	29.7	720528	720528
3fb83244-b954-4319-86d3-d5cd200e27f8	2026-01-06 18:13:50.44562+00	38.9	29.6	3635306	3635306
75a73396-1d7a-4fa3-b8d7-6576e885f23a	2026-01-06 18:14:02.092714+00	57.7	29.9	766366	766366
b70bd414-73ea-4293-9331-c4b5f9d265e9	2026-01-06 18:14:22.316123+00	36.8	29.8	1031310	1031310
fd4eb3d0-d59c-4e40-9bec-7fd1311a5832	2026-01-06 18:14:50.45426+00	41.3	29.8	5356309	5356309
4610ce2a-4985-413d-95fa-5976621087c5	2026-01-06 18:15:50.372271+00	40.7	29.7	966910	966910
87c64381-0886-41b2-9e79-5c8b089469fa	2026-01-06 18:16:22.382247+00	44.4	29.8	1520232	1520232
dc36fe86-e2dd-43b2-90a0-c504dd3118ba	2026-01-06 18:16:52.104497+00	43.7	29.7	3205983	3205983
c031918c-452b-470c-a8c8-b17f4fc0e42d	2026-01-06 18:17:22.3632+00	40.2	29.7	1066957	1066957
3f76d959-e6d4-4c51-ae96-907e3b8759ed	2026-01-06 18:17:25.974218+00	47.1	29.7	753937	753937
12d6a9f9-bfd8-43ad-b364-708eab9d9906	2026-01-06 18:17:50.355065+00	33.3	29.8	832901	832901
12b8915b-33bc-4da0-9875-0b8a0c848261	2026-01-06 18:18:25.949306+00	48.2	29.6	2372839	2372839
e66fc1b8-320d-4498-a4b1-4830f7f7fc14	2026-01-06 18:19:22.749624+00	43.2	29.7	1390149	1390149
2d831cbb-8abc-4877-b3bc-4accca7566f0	2026-01-06 18:19:50.381354+00	38.2	29.6	4307003	4307003
484ae635-1dd5-417c-b52b-5e3c4782ea94	2026-01-06 18:20:25.962251+00	55.3	29.8	1403356	1403356
15b6f760-6f15-43ff-820a-0632d3268317	2026-01-06 18:21:21.620324+00	33	29.7	898223	898223
4319341c-efbc-4a2d-8c67-dd4535d68b96	2026-01-06 18:21:22.32397+00	48.5	29.6	4590991	4590991
9fcd55dc-b168-4cb6-835a-5f34f50bb7f1	2026-01-06 18:21:50.542614+00	30.2	29.7	5100754	5100754
0fb040d7-0521-4905-a60c-2237e0210482	2026-01-06 18:22:02.100597+00	42	29.8	5027251	5027251
b4ac31af-4250-4ca0-ab0b-1dd78047ae12	2026-01-06 18:22:25.937985+00	41	29.6	498159	498159
f4b7f1b7-f249-4040-9497-ff4194cadc84	2026-01-06 18:22:51.707468+00	38.3	29.7	424744	424744
32e0542f-7c8f-43b8-a3fa-848c45a845f7	2026-01-06 18:23:02.116402+00	52.3	29.7	4821107	4821107
b354ffa1-c7eb-44d4-aee8-4fcd19117626	2026-01-06 18:23:22.760636+00	41.4	29.7	690912	690912
a8ded4d5-c755-4dfc-a1b6-b8c625d9b8e6	2026-01-06 18:24:02.044752+00	43.9	29.8	6721476	6721476
0c4f934d-3158-496d-890f-323378253155	2026-01-06 18:24:22.226996+00	41.8	29.8	5228066	5228066
ab28eb28-4e64-4632-8501-8ed8c6182023	2026-01-06 18:26:22.807739+00	38.8	30	358139	358139
49705c3d-8ba6-457e-a7c1-fea6473a7345	2026-01-06 18:27:02.098957+00	49.6	29.8	3799956	3799956
14bc965a-26f1-49d2-8bfd-ca488ceb70c7	2026-01-06 18:39:44.061094+00	36.5	29.8	4217973	112030
408c45ef-90a8-4bcd-ae9a-335f01b325f9	2026-01-06 19:06:44.448666+00	42.2	29.7	4002715	104429
2789aed2-6bef-471d-b6c2-ddfe761860b4	2026-01-06 19:34:44.862608+00	32.2	30	3885389	96298
718b5a4b-aff0-4c4c-9f65-e133ccc17c1a	2026-01-06 19:59:45.205124+00	36.4	29.9	4110741	101541
ade0e005-10f4-4c27-9dbb-0903faef3e14	2026-01-06 20:22:45.535205+00	29.8	30	4090556	107337
5d00fc0e-a1d4-4bce-91b2-ff2e4af7d6e7	2026-01-06 20:37:45.743653+00	42.9	30.1	4192427	110306
b4bd4082-0b71-4828-810c-9082d90bac32	2026-01-06 21:03:46.118893+00	3.9	21.7	1539	186
9b05f669-4efb-436a-b242-32e1d898a933	2026-01-06 21:32:46.511727+00	3.9	21.5	1808	201
6fdfb0e1-5beb-4c46-9b4b-770fc6a4b1cf	2026-01-06 22:01:46.838143+00	3.9	21.5	1253	142
43450022-5dfb-4762-930b-f831f7b831ba	2026-01-06 22:30:47.199699+00	3.7	21.6	1479	172
d805c879-24f1-4998-8e5e-94b75d3a8a26	2026-01-06 22:59:47.567292+00	3.9	21.4	1446	309
4a5d5caf-48d4-46f1-b351-a0196faa94af	2026-01-06 23:28:47.848382+00	3	21.5	1255	197
c4853f31-857b-47e8-99e2-546914eea14a	2026-01-06 23:57:48.235054+00	1.1	11.1	999	28
09b2597b-c2b4-49e1-b2e7-1c847970c12f	2026-01-07 00:26:48.607453+00	0.8	10.1	1177	17
a7a8d0cc-c59c-4570-9e0d-2c828347ae35	2026-01-07 00:55:48.998225+00	1.1	10.2	1471	18
50e85bd1-b6fe-4467-9d5e-601f8648682b	2026-01-07 01:24:49.439779+00	0.9	10.2	1566	21
d78a1ae3-b546-4615-b199-5dde2822ad19	2026-01-07 01:53:49.83966+00	1	10.1	1616	28
ee9cca48-733c-4139-8e83-98726404ab7b	2026-01-07 02:14:50.064371+00	2.5	11	61326	114331
431d3ac2-a7bb-4ccc-ba77-e6fd27ae533d	2026-01-07 02:28:50.247095+00	2.9	11	37107	86282
035e228f-0ba6-48a7-8302-a464c4e67bc9	2026-01-07 02:48:50.51525+00	6	11	25511	13229
efcf1e23-f8d4-4f7f-bcf0-4b445a930d7c	2026-01-07 02:59:50.663541+00	4.9	10.9	19463	19005
02f39efc-69ac-4d6c-be26-7748ed5df68a	2026-01-07 03:10:50.776581+00	2.8	11.1	22905	46957
e0d94c7d-44a6-4d50-977f-52a3c2fec654	2026-01-07 03:20:00.159171+00	2.5	11.1	8349	8349
0a83043f-617f-474f-b27d-09e1f81a3348	2026-01-07 03:20:00.794412+00	2.5	11.1	679196	679196
745100c7-44d6-43a2-ae37-284f3db7a5e9	2026-01-07 03:21:00.213553+00	2.6	11	627013	627013
5de3d596-e09a-4f0a-9d97-09148be656fe	2026-01-07 03:21:00.94005+00	2.6	11	714120	714120
862856b1-1ba6-4078-8f5f-4a76f7c7d9bd	2026-01-07 03:22:00.66965+00	2.8	11.1	790304	790304
5296be15-6bbf-43c9-8848-998f4953cf14	2026-01-07 03:22:00.841834+00	2.8	11.1	516539	516539
a7ad698c-5b99-4d40-a17f-bbdbeee7ee11	2026-01-07 03:23:00.12805+00	3.2	11	11560	11560
c04b0d80-fce9-42d3-abf9-882ee5489452	2026-01-07 03:23:01.167103+00	3.2	11	390202	390202
7eb725d9-5608-4545-8eae-d86f3dfe76ee	2026-01-07 03:24:00.849628+00	2.5	11	460262	460262
a416030d-a204-4329-af87-09a400416d41	2026-01-07 03:25:01.00227+00	3.4	11.1	530344	530344
4b189962-2cff-4397-bec2-79d25890000e	2026-01-07 03:26:00.120996+00	2.8	11	11829	11829
e340f71c-6289-42a9-b14a-54a6bfed14d2	2026-01-07 03:26:00.791551+00	2.8	11	684865	684865
9b015004-cf8a-4609-a6cc-433eca9e9e63	2026-01-07 03:27:00.176525+00	2.6	11	655405	655405
8932eb2a-1527-4f8f-99eb-2497634b61f0	2026-01-07 03:27:00.906819+00	2.6	11	682233	682233
06378778-a82a-47bd-ab73-b54bdf35cfdd	2026-01-07 03:28:01.037464+00	2.6	11	504082	504082
30860310-f258-488c-85e3-0c275f2641ae	2026-01-07 03:29:01.122699+00	4.7	11	526916	526916
2a6142b4-cab3-41d5-81ca-79b29489bdf8	2026-01-07 03:30:00.812463+00	2.8	11	547866	547866
6193932a-152c-4071-9f54-fe249b3e2a64	2026-01-07 03:31:00.904768+00	2.5	11.1	606339	606339
30d55e22-d27e-4ed0-a510-4a1521ca526e	2026-01-07 03:31:01.032222+00	2.5	11.1	535571	535571
247ae10e-287e-4e19-931a-cb1dc1abe04d	2026-01-07 03:32:00.314961+00	3.3	11.1	600599	600599
b170cad1-5d52-4967-9888-48f8b12e564a	2026-01-07 03:32:00.774619+00	3.3	11.1	940826	940826
3b34a72b-e907-4ebd-9511-3321a5c9aa0b	2026-01-07 03:33:01.107389+00	11	11.3	791490	791490
c32d3495-bd68-4cfe-9346-d85b6483e70e	2026-01-07 03:34:00.207011+00	3	11.1	663683	663683
18ed69ad-7a9d-48d7-a0a3-e2bea1065ee7	2026-01-07 03:34:00.639893+00	3	11.1	746465	746465
cc3c8567-6c4a-4b34-a8e7-72e3cd945725	2026-01-07 03:35:00.512545+00	3.3	11.1	247298	247298
f9b5a9a0-ea3a-475e-be4d-f6366050f1d3	2026-01-07 03:35:01.092082+00	3.3	11.1	604731	604731
34b0582c-c6e9-48d0-9ae0-537b84205eba	2026-01-07 03:35:01.141479+00	3.3	11.1	558639	558639
a07e4c38-8afb-4f72-9b76-0c23bd5c5401	2026-01-07 03:36:00.230698+00	2.5	11.1	659021	659021
0ca64c71-57d2-4a62-b595-c6cfb1b61a69	2026-01-07 03:36:00.789992+00	2.5	11.1	912663	912663
7a4fa39f-58bf-435b-98bd-c70bc0936801	2026-01-07 03:36:00.799285+00	2.5	11.1	646414	646414
bc5c6f1d-ec32-4791-b93a-87af1f1e2ab0	2026-01-07 03:36:00.966145+00	2.5	11.1	366311	366311
425c06ca-1ee8-4188-8f89-ae28b1cd48ce	2026-01-07 03:37:00.30474+00	2.6	11	707394	707394
b56043ec-e0db-4acd-8b7f-c0cd2341a3fa	2026-01-07 03:37:00.825279+00	2.6	11	452091	452091
336f15f9-b8e0-46a3-b7b0-0afd9fcabd7d	2026-01-07 03:37:00.887434+00	2.6	11	572890	572890
bdbb306a-9ae1-4f8c-b751-9c2f942e440b	2026-01-07 03:37:01.140168+00	2.6	11	482404	482404
669f3310-5362-493b-bb02-08762d8638da	2026-01-07 03:38:00.245037+00	3	11	734303	734303
7c897855-668e-4c98-9699-8266fd5af69a	2026-01-07 03:38:00.649218+00	3	11	745368	745368
5ba1315d-bb04-4520-9593-656d9e421ca4	2026-01-07 03:38:00.702149+00	3	11	643072	643072
93dd18c4-7ca4-403c-8249-9752f00fb710	2026-01-07 03:38:00.897539+00	3	11	677425	677425
11351870-e6ae-41b8-a59f-5683e66bb318	2026-01-07 03:39:01.016393+00	2.5	11.1	213191	213191
9519892c-a4a1-4eb2-9720-61df7189a847	2026-01-07 03:39:01.078781+00	2.5	11.1	219726	219726
d1b9edef-678a-495f-8137-20a6c85b890c	2026-01-07 03:40:00.714808+00	2.7	11	618058	618058
b924300a-a9fe-4a54-ba21-cf5bf99f12d3	2026-01-07 03:40:00.731791+00	2.7	11	705228	705228
0a6e52b3-ff1c-448b-8bc3-5ef3ff69448b	2026-01-07 03:41:00.755431+00	0	11.1	654300	654300
d5a742b8-2df9-4aa8-8ba2-e1a316502f4a	2026-01-07 03:41:00.784973+00	0	11.1	766444	766444
6f2452da-4d2b-4833-a80b-3e18860b1107	2026-01-07 03:42:00.132343+00	2.3	11.1	8869	8869
1f1224de-2790-4d28-b189-b9cdda6ab658	2026-01-07 03:42:00.745133+00	2.3	11.1	796143	796143
e3450331-b540-48cf-89a9-9aef34dced5d	2026-01-06 17:42:50.479629+00	34.7	29.5	3888744	3888744
6c643bf5-7881-4270-897e-3624684029fb	2026-01-06 17:43:50.53337+00	34.4	29.6	2486208	2486208
7b6d321e-37a0-4fa8-825d-3b4616e419c9	2026-01-06 17:43:51.876007+00	71	29.6	5074737	5074737
d9066cab-55e2-48e8-8941-b3a88989c724	2026-01-06 17:44:22.4717+00	45.2	29.6	354309	354309
637d68d1-ca34-41f0-98eb-25864e5bd9c8	2026-01-06 17:44:23.065338+00	45.2	29.6	1593872	1593872
5f78ad4a-3f81-49c9-a7a4-27e85ac258d3	2026-01-06 17:45:25.905873+00	55	29.6	2791243	2791243
f4e2369b-c8a6-4c06-b38e-fa7509251b7f	2026-01-06 17:46:02.100822+00	43.6	29.6	848558	848558
8a33bc08-f1e8-4770-941b-1615a2291fd2	2026-01-06 17:46:21.610116+00	31.4	29.5	790802	790802
8bb18b3e-5414-42ca-bea0-868005f59192	2026-01-06 17:48:21.563396+00	30.4	29.6	1034427	1034427
65b72463-ac7a-4346-942a-1363055a04a8	2026-01-06 17:48:22.723936+00	43.6	29.6	3217089	3217089
2f8f02db-e76f-41d7-991f-241894310ff6	2026-01-06 17:49:02.121264+00	51.3	29.5	3600767	3600767
6a4c2b51-0a74-4408-8cd9-9c00d4c039ed	2026-01-06 17:49:21.546133+00	31.2	29.5	4061799	4061799
874f4f49-d370-4bcc-8a1c-bcc7f35fe17b	2026-01-06 18:13:43.65923+00	42.9	29.6	4173780	113976
3106b375-0c06-48f9-a0f8-ca99724ffef3	2026-01-06 18:40:44.036559+00	37.3	29.8	4039476	106192
fe9600fa-fce8-409c-acbc-7b3c82a8cea5	2026-01-06 19:07:21.552882+00	36.4	29.8	2971838	2971838
bec850ae-d60a-4c1a-bd8e-8c1878ce56e0	2026-01-06 19:09:02.112341+00	44.4	29.8	3244635	3244635
32df3ca0-1a42-4c9a-8a47-e0a99dc9dd93	2026-01-06 19:09:50.607044+00	43.5	29.9	4582053	4582053
5f5fb293-cba4-43fc-b14c-f4c77be27b89	2026-01-06 19:10:02.09248+00	50.4	29.9	779388	779388
d8e37aea-0bef-476d-ba9e-552dd762e3e0	2026-01-06 19:10:50.619091+00	33	29.9	5865218	5865218
745ead8c-d22d-4139-ae9a-a824797a2457	2026-01-06 19:35:22.615511+00	37.4	30	5189613	5189613
c23b6d86-5a93-41aa-b643-8dedfce5215f	2026-01-06 20:00:45.190341+00	41.1	30	4118843	107671
7e45140c-05ce-4100-a3bf-3d42482cf48d	2026-01-06 20:23:45.515709+00	43.2	30.1	4195559	107022
1777f781-caf1-49f9-bba3-ac965d1d59c5	2026-01-06 20:38:25.949339+00	43	30	3746519	3746519
6c95798e-b5c8-4808-8e6a-503993dab1dd	2026-01-06 20:39:23.094453+00	37.1	30.1	230608	230608
78141285-3fee-4bb8-b2e3-03476a3b0b09	2026-01-06 20:40:21.55648+00	35	30.1	4064092	4064092
c4439e5e-8673-4830-a3d3-33b369a33a13	2026-01-06 20:41:02.131372+00	47.1	30.2	4509894	4509894
14451544-9fda-457c-8ebd-b70d9d11bf96	2026-01-06 20:41:50.653664+00	60.8	30.2	4548711	4548711
053aeb5b-61ad-40a7-87f6-c2e1b0bb63c7	2026-01-06 20:41:52.105826+00	60.8	30.1	4435480	4435480
06f39a11-ff0a-46c3-a7ca-fdd9b3fbc1a6	2026-01-06 20:42:21.646651+00	31.6	30.1	1192566	1192566
c7880714-7228-4a09-8a31-303a124fab85	2026-01-06 20:42:25.923632+00	45.4	30	2590401	2590401
3e99306c-aa31-49a8-bf53-a36e02565219	2026-01-06 20:44:22.741246+00	53.2	30.1	3832445	3832445
39fc307f-60e3-4219-b041-0a3943cd3774	2026-01-06 20:45:50.565627+00	36.7	30.2	3707530	3707530
f1937719-0e22-4c13-bdff-9b33ee6a226c	2026-01-06 20:46:22.429002+00	42	30.2	4967243	4967243
2c820d39-d6f0-4003-81fc-192e4353bd8e	2026-01-06 20:47:22.79932+00	41.1	30.1	4700240	4700240
406e51a2-5a8f-4278-ac8a-03c7c1eacf59	2026-01-06 20:48:02.096911+00	48	30.1	675850	675850
b4af2ce1-49d4-45df-a6f3-633d016f8449	2026-01-06 20:48:22.748265+00	39	30.1	3857033	3857033
eedaa3e9-673b-4fbc-8c92-1ed1c9305e84	2026-01-06 20:49:21.521244+00	31.9	29.9	2981454	2981454
73941bb3-6a13-4a20-8031-afbb377bfa07	2026-01-06 20:49:50.621532+00	33.1	30	1467129	1467129
10fa10bd-df10-4033-8db5-4029a0bf8f4b	2026-01-06 20:50:25.912312+00	53.3	30	919766	919766
44519f5d-0c1d-44ac-a370-757c64aba760	2026-01-06 20:50:50.483701+00	30.6	30.1	4559255	4559255
e7bf1b60-9733-43ec-b8eb-190d73be3888	2026-01-06 20:51:22.762327+00	45.7	30.1	3900224	3900224
8475efca-5a4a-4fa4-b2c5-d5b653423bdb	2026-01-06 20:51:50.560605+00	39.1	30	510385	510385
baeedb3a-2638-405a-a3c9-cd12dcd89cc0	2026-01-06 20:51:51.813134+00	45.7	30.1	3597348	3597348
1009859c-4ba9-47b7-9625-c75c845ff7e1	2026-01-06 20:52:21.561301+00	34.8	30.1	5081232	5081232
0f9a4bed-bf7a-44fe-8fca-5492866ea279	2026-01-06 21:04:46.136187+00	3.8	21.7	1551	194
2936ceeb-2372-4225-8e03-b4f9726e7533	2026-01-06 21:33:46.531355+00	3.9	21.6	1589	194
41749d8c-75ca-4f68-96a9-0236224069c7	2026-01-06 22:02:46.832169+00	3.8	21.5	1532	153
b2a5fe22-64fa-40fd-b4b2-f727ed903f24	2026-01-06 22:31:47.197279+00	4.1	21.6	1278	165
a254dd42-c900-4a6c-9e12-99aa46fa1e15	2026-01-06 23:00:47.541419+00	4.2	21.4	1446	309
387b3cbf-3a15-49bd-8898-69e82d29071b	2026-01-06 23:29:47.903754+00	3	21.5	1249	192
71b2b104-d125-4f99-9f33-99d481c42e37	2026-01-06 23:58:48.282141+00	1.2	10.2	1076	22
807e21a2-5ca1-44e7-aa9a-52941a1c5027	2026-01-07 00:27:48.624578+00	1	10.2	1263	23
c2757a58-005c-4277-b719-a84ad7072e52	2026-01-07 00:56:49.031356+00	0.9	10.1	1284	13
1ae931ef-377a-42c5-a2db-d6fa79525c89	2026-01-07 01:25:49.406928+00	1.1	10.2	1533	9
d1c46098-3883-4707-a260-2ccc83d5fbda	2026-01-07 01:54:49.830003+00	0.9	10.1	1623	22
17b5fed0-6b9b-42e4-8832-979745df851f	2026-01-07 02:15:50.065229+00	3.9	11	48565	39196
293d446f-40d6-4c00-b3ea-933eca59d87e	2026-01-07 02:29:00.792562+00	3.2	10.9	631471	631471
799c749c-a9bb-4ed0-8c5c-b93cba61e4c2	2026-01-07 02:29:00.984153+00	3.2	10.9	685325	685325
18ac6963-dbab-43ba-b3cc-a0053aa6150c	2026-01-07 02:30:01.055189+00	3.1	11.1	562790	562790
6cc12f27-d8dd-4721-bfff-9257a64ca187	2026-01-07 02:31:00.981544+00	2.8	11.1	502238	502238
baed754e-c1d8-4048-9675-47ba527f31b8	2026-01-07 02:32:00.194289+00	3.1	11	700417	700417
81909799-894b-45b3-817b-18e0428a5f4c	2026-01-07 02:32:00.970943+00	3.1	11	354804	354804
68895103-8ed5-4ebf-9c2c-1827558e13e4	2026-01-07 02:33:00.789185+00	6	11	264823	264823
56143859-e2e1-4781-988d-54520b2065a6	2026-01-07 02:34:00.951421+00	2.2	11.2	564718	564718
37ba2f62-ace9-4eb7-9253-7fd97b58bb4e	2026-01-07 02:35:00.885427+00	2.4	11	495371	495371
00084adc-03ed-41b8-8457-1cff076ef5d5	2026-01-07 02:36:01.083693+00	2.7	11	564447	564447
3fd46104-9aa0-4119-9dd0-d36b6e91032b	2026-01-07 02:37:00.677933+00	2.9	11	783214	783214
6ec74588-1130-4cc7-ab23-9312fa75d1e6	2026-01-07 02:38:00.212735+00	2.7	11.1	678196	678196
7513c9de-3ba7-4ae3-b98b-449f33753bc3	2026-01-07 02:38:00.632467+00	2.7	11.1	675273	675273
23389137-5d0d-4b77-b1d0-780f625794ed	2026-01-07 02:39:00.746156+00	2.5	11	549056	549056
88496b8c-ac1e-49a7-a8a3-e9a35d128581	2026-01-07 02:40:00.906865+00	3.8	11	555947	555947
9648cb2b-82e3-4b9c-9220-7019f5350c58	2026-01-07 02:41:00.633831+00	3.1	11	867857	867857
3e2b8640-5508-49aa-9611-3dda579d3347	2026-01-07 02:41:00.771463+00	3.1	11	676974	676974
738bb3b8-cdaa-4f17-bda2-050370a80e1f	2026-01-07 02:42:00.706516+00	2.8	11	578035	578035
48cc0aef-b790-418f-b47e-5cc6433ef847	2026-01-07 02:43:00.042588+00	3.9	11.1	7713	7713
cea5a8ef-7f01-4160-a41e-7afd8c8da630	2026-01-07 02:43:01.041789+00	3.9	11.1	542350	542350
82609953-444d-4467-b828-c996825f5c39	2026-01-07 02:44:00.761808+00	3.8	11	740288	740288
5cc50c58-92a3-45de-b348-c1896e371841	2026-01-07 02:45:00.65916+00	2.4	11	410064	410064
075b880b-c06f-487d-8231-b0fa40eb8a6f	2026-01-07 02:46:00.996301+00	3.4	11	327338	327338
ede74b2c-3765-4f57-9816-5b953f2fb1b8	2026-01-07 02:47:00.794603+00	3.2	11	883454	883454
959d68ce-a6d6-4087-9c1b-f8d31ba84637	2026-01-07 02:48:00.193697+00	2.8	11	7249	7249
5000022a-b61c-4209-a863-ed707498f2fd	2026-01-07 02:48:00.503786+00	2.8	11	307338	307338
895bbad5-171c-4538-bcb8-7d2475f5043c	2026-01-07 02:48:01.099071+00	2.8	11	442121	442121
4f79df46-8f74-48ab-ba1a-98f4e5a50475	2026-01-07 02:49:00.683365+00	3.1	11	644548	644548
2a117b12-6e4c-4717-a5fb-9770011e3433	2026-01-07 02:49:00.853308+00	3.1	11	598462	598462
362cc0eb-be85-4611-b55f-18e95276a994	2026-01-07 02:49:50.525091+00	5.1	11	25359	13560
5b80ace9-53e5-468a-89cb-0785b26617d3	2026-01-07 02:50:00.703834+00	3.3	11	770570	770570
45a48c7d-b5c3-4397-901f-d59de2d85ff0	2026-01-07 02:50:00.90503+00	3.3	11	655170	655170
ca02f947-ff98-4f65-9f3c-25f0dc99aaf0	2026-01-07 02:51:00.035593+00	2.4	11	7227	7227
6f9a430e-fd9b-447b-9dd5-3c63f35a6311	2026-01-07 02:51:00.793374+00	2.4	11	540416	540416
afcad26b-f915-4293-a0d7-5837653bc0e9	2026-01-07 02:52:00.040629+00	2.5	11.1	7038	7038
6f4e6534-21e7-4511-b86e-a02770b2685d	2026-01-07 02:52:00.212932+00	2.5	11.1	735682	735682
03a80954-6f7a-46d1-9a45-6e2df4dc0a77	2026-01-07 02:52:00.756868+00	2.5	11.1	629145	629145
f5b1127b-5bf8-424d-bf74-29786ee43817	2026-01-07 02:53:00.768108+00	3.2	11	560159	560159
e09736cc-74f4-4c80-b364-e47e3af65ae0	2026-01-07 02:54:00.920309+00	2.6	11	423969	423969
3e7398fd-cd8a-4a54-a9bb-862fa5869127	2026-01-07 02:54:01.147874+00	2.6	11	507359	507359
73d8a76d-8642-429a-9fc2-da0a3bfb787b	2026-01-07 02:55:00.766947+00	2.8	11	128926	128926
a75902a4-8582-4707-b406-819770c5f267	2026-01-06 17:42:50.562436+00	34.7	29.5	671485	671485
7776b114-6b3b-4eb8-b11a-d8cb43fc153b	2026-01-06 18:14:43.681481+00	40.5	29.7	4222409	113478
0a50d48a-3e9a-4efd-8092-46f8625cdc66	2026-01-06 18:41:44.078738+00	41.5	29.8	4615364	124687
6dc32139-2498-4730-825e-37adf75eedf7	2026-01-06 19:07:44.461596+00	45.3	29.9	4165720	107048
0f50b60a-9fe9-481c-a5dc-e91dc1d603ae	2026-01-06 19:35:22.679636+00	37.4	30	430525	430525
3be7a20d-b16c-48d0-aa42-851dc59c24ff	2026-01-06 19:35:50.585984+00	40.2	30.1	3368927	3368927
9b3c99de-7d31-4860-9cbf-3132a599b823	2026-01-06 20:01:45.24228+00	37.1	30	4172140	109146
4118bed1-bf86-41ff-9da2-3fa129780c1a	2026-01-06 20:24:45.579602+00	34.1	30.1	3872643	104417
619b7d3f-183a-406f-a299-0e2882c6304c	2026-01-06 20:38:45.776245+00	41.8	30.1	3965239	107505
37e8fe8d-bcb6-4724-bdfa-27b86dd44f02	2026-01-06 21:05:46.13799+00	4.1	21.6	1807	325
3d1e060f-2f08-4daf-bccf-b555666ecdf4	2026-01-06 21:34:46.54819+00	3.7	21.5	1610	196
b3ef2429-cc6b-4d20-9fd6-930b51f88864	2026-01-06 22:03:46.85262+00	3.9	21.5	1821	277
4494d289-65c1-4815-9d8c-cfceef055797	2026-01-06 22:32:47.253368+00	3.9	21.6	1618	179
20bba5d6-242e-4270-9172-cd027e9bd399	2026-01-06 23:01:47.587133+00	4.1	21.4	1560	314
06512fed-a594-451a-abba-9b81aa557794	2026-01-06 23:30:47.867947+00	2.8	21.5	1323	199
1d9e75e1-629c-4653-b1b3-3a6672d77d89	2026-01-06 23:59:48.287427+00	0.9	10.2	1166	22
2ffa4784-20d8-4fcb-b631-b6b87b06f0f0	2026-01-07 00:28:48.642483+00	0.9	10.2	1221	18
dfc47416-bf00-4377-b003-0bd326bf0674	2026-01-07 00:57:49.037978+00	1	10.2	1199	18
a83ebe0d-b51e-4238-9e8c-3ac72d666156	2026-01-07 01:26:49.428495+00	0.9	10.2	1302	10
6384f80b-ca72-40a3-bd18-0f85a6d8754f	2026-01-07 01:55:49.822121+00	1.1	10.1	1165	9
0c3f7381-138d-46b7-9d5c-fcb244285aac	2026-01-07 02:16:50.089987+00	4.6	11	41670	87070
f14a5787-0996-4ac7-adc3-f65f93155582	2026-01-07 02:29:50.253158+00	5.3	11	33266	51206
399529d8-b725-4178-be7f-615828bba29b	2026-01-07 02:50:50.525023+00	2.2	11	29934	16950
0ea77cf6-0f4a-414d-a3f9-13b8dbd1e014	2026-01-07 03:00:50.644378+00	3.8	11	18174	14850
4257a29e-9719-4b00-b940-af88a0b9ac4c	2026-01-07 03:11:50.801022+00	2.7	11	23160	24121
d3b16e0a-58e5-4e62-80ac-0942c13274c5	2026-01-07 03:20:50.922502+00	5.1	11	16475	14233
2c03b63d-480f-4dfa-bcec-9960cffacba1	2026-01-07 03:28:51.058721+00	2.7	11	16754	11936
f39756e2-6a0a-4419-bbad-80ae3c4a24da	2026-01-07 03:35:51.119861+00	2.4	11.1	22742	52540
f2490e06-2f8d-492a-8b1f-2f2610b6de7c	2026-01-07 03:43:01.016457+00	3.2	11	643426	643426
d76cf7e3-08fb-45d2-8b5b-753e73c607ab	2026-01-07 03:43:01.214027+00	3.2	11	457212	457212
d1c6abd1-4808-4851-9623-d70068a0f1df	2026-01-07 03:44:00.886661+00	3.1	11	598564	598564
8c9540a0-a7b7-4140-bc1e-eae3abb5721b	2026-01-07 03:44:01.051587+00	3.1	11	641100	641100
cd82d270-7582-4f69-8ba5-84716ef409ae	2026-01-07 03:45:00.953347+00	2.8	11	470886	470886
7eee06e6-c612-48a3-891c-49dad2fd3891	2026-01-07 03:46:01.137173+00	2.7	11	476817	476817
b3d70730-87b1-4192-ad48-7a58e230a95d	2026-01-07 03:47:00.114972+00	3	11.1	12399	12399
56e95335-ba03-4a8c-b503-490ea7f60e71	2026-01-07 03:47:00.948661+00	3	11.1	423843	423843
dc57254b-82b2-4ddd-ba5b-5c8f3ccea311	2026-01-07 03:48:00.101253+00	4.3	11	8232	8232
b2148fb4-2d41-407e-9041-e50e5110f18c	2026-01-07 03:48:00.735378+00	4.3	11	747497	747497
e396f475-9486-4d0a-a4b8-a3978f54925d	2026-01-07 03:49:00.279369+00	5.9	11.1	547358	547358
4a3972b7-fabd-4976-aabc-36d7a087980d	2026-01-07 03:49:00.851605+00	5.9	11.1	361884	361884
68d37942-1896-4076-a64f-6662d02d8762	2026-01-07 03:50:00.8431+00	2.8	11.1	743491	743491
d00d4c27-dd7a-485d-a08a-2955e766bff8	2026-01-07 03:50:01.128861+00	2.8	11.1	756264	756264
28fcde55-8cf1-4e11-8bf2-f7e81be64079	2026-01-07 03:51:00.099567+00	2.4	11.1	9446	9446
af1a07c6-85e8-46c6-a103-198b069684ce	2026-01-07 03:51:01.010047+00	2.4	11.1	608489	608489
34b843e0-49bd-4d54-8c50-6e8aa474803c	2026-01-07 03:52:00.810606+00	2.6	11.1	490487	490487
34c14983-2edb-4fde-aefc-98054fa8e54e	2026-01-07 03:52:00.957365+00	2.6	11.1	776263	776263
8b8eee03-6a54-42cb-a00c-d7064c5fcb42	2026-01-07 03:53:01.068601+00	2.4	11.1	582972	582972
cda4d147-5073-44d9-86e8-8dc7884c0544	2026-01-07 03:54:00.465682+00	3.1	11	634379	634379
d5b59db7-7048-4fb3-a4aa-b0863d330024	2026-01-07 03:54:00.970418+00	3.1	11	577775	577775
d6e2758f-eb96-4945-8db5-b140761b30f3	2026-01-07 03:54:51.392972+00	5.1	11.1	15732	7486
896a9b26-5da8-4576-a2b9-06dee4c50065	2026-01-07 03:55:00.669117+00	2.4	11	719462	719462
1ef5cb80-a4c3-4b77-9da5-1095a1e0e924	2026-01-07 03:56:00.117186+00	2.9	11.1	9844	9844
847b2052-8580-41d0-9dc0-4f7da44d6507	2026-01-07 03:56:00.839036+00	2.9	11.1	565132	565132
1703306e-9ee3-40ac-b921-80a62f0cb72c	2026-01-07 03:58:00.696906+00	3.5	11.1	570580	570580
0eea06e6-5f61-4f89-9720-d230f2ee5437	2026-01-07 03:59:00.821914+00	2.7	11	596911	596911
a696ec9c-2f06-4141-a235-2e54f009f348	2026-01-07 04:00:00.214997+00	3.1	11	650096	650096
918065f0-1dad-4f99-9ff1-841f067687fb	2026-01-07 04:00:00.716977+00	3.1	11	670177	670177
7b1b895b-e007-4474-8203-6255d4ee9e9e	2026-01-07 04:01:00.197122+00	3.2	11	816363	816363
90ae49f9-8185-4e34-bd3c-e81f6056f0c4	2026-01-07 04:01:01.192762+00	3.2	11	340862	340862
03768223-3ed4-4311-ad10-57494c3f9a60	2026-01-07 04:01:01.232052+00	3.2	11	495753	495753
d1834c3c-3cdd-41d9-b804-ba8723613f79	2026-01-07 04:01:01.250091+00	3.2	11	530347	530347
ff335eb5-25e8-4f94-9774-59f2cd96e4a2	2026-01-07 04:02:00.434214+00	2.9	10.9	224512	224512
ba97c5d3-2186-49ef-9ec7-3c3ba75fdd7c	2026-01-07 04:02:00.878488+00	2.9	10.9	693090	693090
c6c42d8e-1fe3-47a8-bc15-f0ade8550ad1	2026-01-07 04:02:00.919695+00	2.9	10.9	684660	684660
1760e171-8a15-4428-a728-2081973754dc	2026-01-07 04:02:00.952171+00	2.9	10.9	854772	854772
2e1b0ee6-93a3-4761-870b-e5ffab771073	2026-01-07 04:02:01.16258+00	2.9	10.9	101953	101953
e686109c-097e-4eb6-929d-6736240fd867	2026-01-07 04:03:00.764941+00	4.9	11.1	581059	581059
9e324312-e462-4655-98a9-76a53ed1e115	2026-01-07 04:03:00.821116+00	4.9	11.1	674140	674140
5c76a3f1-965e-45d1-8a2b-be67c993af54	2026-01-07 04:03:00.837022+00	4.9	11.1	609183	609183
622671cc-0819-413d-b1b6-88cdb4501905	2026-01-07 04:03:01.030431+00	4.9	11.1	582786	582786
fbd717ef-5285-4684-85e6-3c5a445ef0f8	2026-01-07 04:04:00.089171+00	2.7	11.1	9201	9201
eaf58b57-27bc-48a1-8170-2c710837b0b5	2026-01-07 04:04:00.235487+00	2.7	11.1	667498	667498
2286d4eb-4196-44a9-9192-a9854e72f6dd	2026-01-07 04:04:00.693014+00	2.7	11.1	707185	707185
6ab69599-6ac7-4601-9ea4-1508ee85c3c2	2026-01-07 04:04:00.722018+00	2.7	11.1	680747	680747
b1542707-05d8-4c60-a0e6-36a449246dbd	2026-01-07 04:04:00.753759+00	2.7	11.1	874973	874973
61b65ff8-58ca-4f02-bd27-22503c0db5d4	2026-01-07 04:04:00.763559+00	2.7	11.1	510560	510560
72b0b7b1-2746-415f-8c05-c1f611acf2e7	2026-01-07 04:04:00.942143+00	2.7	11.1	689167	689167
636b4fa3-fe15-4f2b-9d49-f6381d784fbc	2026-01-07 04:04:51.50777+00	4.3	11	12962	22089
ea02855f-2ef2-40b0-870d-d865c03ebed0	2026-01-07 04:05:00.096568+00	3	11.1	9800	9800
aafb01d0-5715-4337-807f-657d1f807b67	2026-01-07 04:05:00.824281+00	3	11.1	589224	589224
d278175f-48ae-4af2-a639-fb0395cf17f0	2026-01-07 04:05:00.839743+00	3	11.1	687490	687490
acaa530d-4b2f-43d6-a9a8-42b51dc54f18	2026-01-07 04:05:00.937112+00	3	11.1	630285	630285
413f6a82-4b73-43af-81e1-5624f25d5cef	2026-01-07 04:05:00.962142+00	3	11.1	654538	654538
cc53d11f-47a2-4e36-9210-c5cee824cceb	2026-01-07 04:05:01.082503+00	3	11.1	385775	385775
b9feed27-7408-43ea-b6f3-8c84ccd7f006	2026-01-07 04:06:00.260637+00	2.2	11	612134	612134
716a9abb-f3d2-4a86-aae9-09fb79c1cfa1	2026-01-07 04:06:00.76159+00	2.2	11	547445	547445
2b708f77-4e39-49d3-821a-c8ec4a7f7a68	2026-01-07 04:06:00.789798+00	2.2	11	750015	750015
3e8dfa2b-dd03-407a-8ee6-87c10ee99764	2026-01-07 04:06:00.795292+00	2.2	11	525513	525513
0f51af5a-1372-4004-af83-f816df0978b9	2026-01-07 04:06:00.836823+00	2.2	11	628319	628319
e91d425a-b5ae-4c32-b418-fdc1133efa9e	2026-01-07 04:06:00.919821+00	2.2	11	499949	499949
08bcfb9c-2715-4673-8676-719bc4fea832	2026-01-07 04:07:00.619761+00	2.7	11	851181	851181
30680022-efb9-4e7e-8a27-d372166c281f	2026-01-07 04:07:00.699375+00	2.7	11	794544	794544
5d7b636e-3359-4e0d-ab60-7a84bf0baa87	2026-01-07 04:07:00.723806+00	2.7	11	643095	643095
5247e0a8-a5a6-4b7f-a816-96034be57eeb	2026-01-07 04:07:00.738602+00	2.7	11	583992	583992
46482dba-9b5d-4cdf-9aa1-86e021274d38	2026-01-07 04:07:00.858921+00	2.7	11	660867	660867
89900c70-e89b-4d5c-9348-a379d5ef67e3	2026-01-07 04:08:00.964912+00	0	11.1	726006	726006
8afe8e21-f51e-445d-b526-5d2aa0df3365	2026-01-07 04:08:00.996877+00	0	11.1	541057	541057
92bc3447-c0f1-4ae4-a15a-a984cb536d50	2026-01-06 17:42:51.757049+00	44.4	29.5	535486	535486
fb9576da-89f5-4733-9811-3aae16923c5d	2026-01-06 17:44:21.734792+00	35.5	29.6	4318214	4318214
892390e4-8a46-4289-a3e8-8eba622d09df	2026-01-06 17:44:22.926783+00	45.2	29.6	3748157	3748157
7b7c2b0a-0595-42d0-a1e5-795e5e7d8a6a	2026-01-06 17:47:21.563209+00	28.9	29.5	4214785	4214785
f9ac57c1-61b7-4020-bf29-3057e9f56e98	2026-01-06 17:47:50.615584+00	30.6	29.6	4232145	4232145
c2dccc76-ed47-45df-a10c-bd6a95264626	2026-01-06 17:48:02.080698+00	47.3	29.6	3076663	3076663
13857d04-345e-4f48-8570-5e03c9a8ebb4	2026-01-06 17:49:22.797192+00	41.8	29.6	1275189	1275189
f9b8807f-df26-45f7-ae8b-06966db4c756	2026-01-06 18:15:43.62728+00	35.1	29.7	4085046	109974
17f34895-0ed9-49e0-baa4-69f697628323	2026-01-06 18:42:44.100757+00	39.7	29.8	4095391	99283
d66f491c-633a-47e0-a91c-b53f39279503	2026-01-06 19:08:44.446862+00	42	29.8	4661317	122137
d6ac66f8-3bc6-4bdb-b32c-1387f899c99d	2026-01-06 19:35:44.818728+00	40.4	30	4185085	108001
337a0ead-96de-4d79-8eb5-8b91ceb1ae77	2026-01-06 20:02:45.260946+00	40.9	30	4128827	105811
75e6729a-8097-45ba-9987-a16f0be75d81	2026-01-06 20:25:45.548332+00	38.1	30.2	4174412	106772
d12bc27e-6862-4eac-9f1e-863e988188fb	2026-01-06 20:39:45.785585+00	37.7	30.2	4231929	112425
572d3446-e431-45e1-858d-af9402e6d911	2026-01-06 21:06:46.201271+00	3.8	21.5	1816	330
8d0e39a8-eacd-4313-974f-06ad3902e2c7	2026-01-06 21:35:46.507684+00	4.1	21.6	1558	192
3056a258-b3bc-4916-9bf9-a5a6e72f5f66	2026-01-06 22:04:46.870375+00	3.8	21.5	2260	294
8307fbd3-d89f-4e36-be20-3e5391142cf4	2026-01-06 22:33:47.254565+00	4	21.6	1540	174
1e4e5768-f51c-4fbe-8811-2fe2bc79277a	2026-01-06 23:02:47.606057+00	3.9	21.4	2333	317
5a874b78-f1b3-474b-bea9-00c0ba669111	2026-01-06 23:31:47.886192+00	2.8	21.5	1610	198
3aafc53c-44af-45f5-8445-e2a62a4166fb	2026-01-07 00:00:48.274528+00	1	10.2	1771	17
1802661c-d81d-4c81-b2e0-ba3d2e828fc2	2026-01-07 00:29:48.660464+00	0.9	10.1	1227	18
a28a819a-08de-4119-b24b-56db5a10a5b3	2026-01-07 00:58:49.065948+00	0.9	10.1	1697	23
f3be284c-b75f-4b46-bb86-4746966e3acb	2026-01-07 01:27:49.449376+00	5.7	10.2	66865	1949
6eafa1db-f2c9-442e-ab04-918fd300dff8	2026-01-07 01:56:49.877302+00	1.7	10.7	75044	54594
bf4639fb-9f88-449c-a23e-2084c99d5ba5	2026-01-07 02:17:00.810381+00	2.2	11	613962	613962
47467597-56b1-41d2-82c9-23f92c0278be	2026-01-07 02:18:00.923688+00	2.4	11	348589	348589
ba33787c-d985-454b-b0e6-2500427b1b94	2026-01-07 02:19:00.66409+00	3.5	11	580660	580660
d407755e-a664-4823-86a6-bbc267e98a54	2026-01-07 02:19:00.83747+00	3.5	11	527160	527160
7ec36bbd-1f78-4012-b294-c8f57ef9489a	2026-01-07 02:30:50.249958+00	2.9	11.1	25361	25574
af53ded8-5c08-4cd1-a58e-6a4ecffd19df	2026-01-07 02:51:50.551173+00	4.2	11	28008	19562
94e49b82-d8d2-46b6-b031-c8c3d312e28b	2026-01-07 03:01:00.037285+00	2.8	11.1	7435	7435
2f2d988c-0358-40f8-a9d7-42cecda1708e	2026-01-07 03:01:00.837587+00	2.8	11.1	523963	523963
614ff1fd-bb96-49ad-8b4d-05f0ca425f8f	2026-01-07 03:02:00.948724+00	2.8	11	782844	782844
04cc1a3e-6f0e-462b-a835-1aaccb592ba1	2026-01-07 03:03:00.174922+00	2.1	11	704571	704571
09670a9a-20c1-41c3-8c5b-b67ce9c951e3	2026-01-07 03:03:00.673925+00	2.1	11	587973	587973
cfdc5565-de1d-414c-ab39-f2959652190f	2026-01-07 03:04:01.17387+00	2.5	11.1	269936	269936
fc0906f5-125b-4b8e-a6eb-abb0542afd02	2026-01-07 03:04:01.38639+00	2.5	11.1	476844	476844
05ed0856-533e-44d4-a8d3-1da850a52643	2026-01-07 03:05:01.141521+00	2.8	11	419486	419486
5fbdce50-ff77-4c1f-afaa-194127108b7c	2026-01-07 03:05:01.401357+00	2.8	11	526214	526214
e2c23311-673d-40b4-9f9c-ed11e8836979	2026-01-07 03:06:00.302403+00	3	11.1	265094	265094
fe726634-882a-439b-ad4a-bfc2694d43d4	2026-01-07 03:06:00.913875+00	3	11.1	555422	555422
3db5893b-133f-463f-9fb3-c0cd395b7171	2026-01-07 03:07:00.822546+00	2.9	11	521075	521075
e511f32f-ab1f-438d-a10d-8552e7a70037	2026-01-07 03:08:01.018085+00	3.7	11.1	438508	438508
4fa42266-2c17-4bca-8262-5b72b0d4c1c3	2026-01-07 03:09:00.092569+00	4.8	11.1	7981	7981
a4930ff4-2be1-4d54-bafd-d41bb120f05a	2026-01-07 03:09:00.871949+00	4.8	11.1	535709	535709
fcf37d7b-842b-46b0-bc8e-77b11f1aa7c0	2026-01-07 03:10:00.856657+00	2.6	11	749577	749577
1d584d14-7bbb-41e3-8c77-89aa42242dc8	2026-01-07 03:11:00.985857+00	2.8	11	129796	129796
6cf23627-b617-4707-8406-6fe8707f4e74	2026-01-07 03:12:00.252072+00	3	11	525339	525339
29b41344-f70c-41e6-a927-84b6485f1fb6	2026-01-07 03:12:01.10761+00	3	11	573556	573556
74b2a046-6d87-42cf-9aca-ec51f32f7b4f	2026-01-07 03:12:01.144375+00	3	11	613674	613674
8db5c4c9-0546-41ea-8828-ae35b40dc001	2026-01-07 03:12:01.287903+00	3	11	565996	565996
434e409b-1abd-4a7e-bc7c-0ab93d8968ec	2026-01-07 03:13:00.87387+00	6	11	509347	509347
1641b12c-6ba3-450a-ab7a-96b091e268dc	2026-01-07 03:13:00.972452+00	6	11	459654	459654
4c31e7aa-32c3-41da-9c8f-a74ff661badb	2026-01-07 03:13:01.12791+00	6	11	397418	397418
bae4c0ee-a44b-4176-836c-fb979f85e49b	2026-01-07 03:14:01.004949+00	5.5	11.1	483606	483606
562c791a-b9d0-4fb1-982c-d22c03689c4b	2026-01-07 03:14:01.051682+00	5.5	11.1	449053	449053
910d9377-0c48-4f57-952a-5aa173bfe318	2026-01-07 03:15:00.181165+00	3.2	11.1	8107	8107
7a34aa23-e74c-46ea-9b19-fd33a355913b	2026-01-07 03:15:00.996644+00	3.2	11.1	834888	834888
4a40a3ba-cc93-48e3-9bf2-3522d270f198	2026-01-07 03:15:01.017476+00	3.2	11.1	593700	593700
94d7ced7-75b4-4281-b6d6-28096112e724	2026-01-07 03:16:00.719357+00	2.7	11.1	531029	531029
72e825fe-e1b0-46a0-9644-d80718c3ccb1	2026-01-07 03:16:00.787866+00	2.7	11.1	657973	657973
8992f1fb-2a35-45ef-b1e8-23cf97cf4a29	2026-01-07 03:17:00.171498+00	4	11	10429	10429
ed3fbf21-7b37-48bb-bc95-29f8e5044d28	2026-01-07 03:17:00.30402+00	4	11	738118	738118
327d172a-874c-45fd-a801-ff986bc9c821	2026-01-07 03:17:01.14553+00	4	11	409932	409932
2467ba72-9f38-4ea3-ac79-fe3e43f53e57	2026-01-07 03:17:01.186959+00	4	11	355054	355054
b37e4251-bb4e-4623-afd8-e7f1cf4eab6b	2026-01-07 03:18:01.028663+00	3	11	544030	544030
b1d21a6c-14ad-4687-a6b1-303c40006267	2026-01-07 03:18:01.073882+00	3	11	454378	454378
dc28f3d0-ddc3-48e7-adfa-1203bcef333d	2026-01-07 03:18:01.251611+00	3	11	642764	642764
8bcb486c-8279-415f-a9db-22c7e58aee4b	2026-01-07 03:19:00.081575+00	3.8	11	8308	8308
e7196487-648b-4e56-94c5-3673419ebb77	2026-01-07 03:19:00.653366+00	3.8	11	743049	743049
54574c2f-4b86-435b-826b-5f01ae6941e5	2026-01-07 03:19:00.69836+00	3.8	11	630332	630332
095b1bf5-bf4f-493d-87dc-6be0755c539f	2026-01-07 03:20:00.273439+00	2.5	11.1	689564	689564
6f9cdb97-2891-47d4-8ecd-285ba3e08d38	2026-01-07 03:20:00.762382+00	2.5	11.1	658678	658678
781a5447-6bbc-4eaf-811e-26c4eda0be00	2026-01-07 03:20:00.78292+00	2.5	11.1	571950	571950
ff4ac08e-8f5c-496d-829f-bb5173f87428	2026-01-07 03:20:00.918164+00	2.5	11.1	582190	582190
df89a3ab-4a7e-47be-ab64-84a9a545db52	2026-01-07 03:21:00.105376+00	2.6	11	7891	7891
8091d3fe-5ad9-4bd9-a469-c003ae48bc8c	2026-01-07 03:21:00.950008+00	2.6	11	513521	513521
3325497d-f270-42e3-a808-036be56bea60	2026-01-07 03:21:00.958983+00	2.6	11	667552	667552
477fae96-1c28-4a15-ae08-4517057024d2	2026-01-07 03:21:50.947505+00	4	11	17204	11170
70e1af9e-ccf9-4396-8a30-d4ca39d77cb0	2026-01-07 03:22:00.685989+00	2.8	11.1	743679	743679
8248498c-f3b1-44c2-bbf3-122e7e3a27e0	2026-01-07 03:22:00.760751+00	2.8	11.1	687151	687151
9ce142fb-94cf-4d8c-9302-42560bd4d361	2026-01-07 03:23:01.091753+00	3.2	11	454332	454332
fc45b97e-bea4-44f6-a11d-f04fdef61a41	2026-01-07 03:23:01.213036+00	3.2	11	354361	354361
1adf6a13-0445-4159-8a14-a11da242706d	2026-01-07 03:24:00.829261+00	2.5	11	472265	472265
084e7cf3-791d-4580-b99e-6f5d04d61284	2026-01-07 03:24:01.010388+00	2.5	11	586588	586588
9c5d8d2d-392f-4a28-b46e-4a6effbbb953	2026-01-07 03:24:01.147229+00	2.5	11	405110	405110
572b1e4c-524d-4cec-afe0-be05b4951f9c	2026-01-07 03:25:00.08092+00	3.4	11.1	8492	8492
1ffdd012-0d18-484e-9555-b78e977fb106	2026-01-07 03:25:00.957771+00	3.4	11.1	383614	383614
794ad238-af80-44da-945d-4eacd862f1f1	2026-01-07 03:25:00.977435+00	3.4	11.1	653873	653873
1890cbb0-3b77-4718-b159-b83daecf360a	2026-01-07 03:26:00.244769+00	2.8	11	782733	782733
7a18caef-fc7e-47fb-b6c7-acfe6477f3ec	2026-01-07 03:26:00.74713+00	2.8	11	742516	742516
39e925b8-ee2b-4e0d-b224-d53f5f9fe3ae	2026-01-07 03:26:00.786586+00	2.8	11	600744	600744
66cdcc0b-0fdd-4dcb-a1f3-c6b52e46c473	2026-01-07 03:27:00.934112+00	2.6	11	733308	733308
5846c6b7-d57d-48aa-8da1-396d60f2874e	2026-01-07 03:28:01.052685+00	2.6	11	453374	453374
214ad35f-e68b-46a6-bd0e-ab123e76e05f	2026-01-07 03:29:00.984637+00	4.7	11	135512	135512
9786c63a-387b-485e-bc2f-6231dae97859	2026-01-07 03:29:01.246598+00	4.7	11	637324	637324
dab684ca-d0ab-4532-9893-79410c6edd36	2026-01-06 17:43:02.088103+00	45.4	29.5	6016955	6016955
40952fbe-ba8d-4b7f-b684-b076d07656ee	2026-01-06 17:43:25.883431+00	41.5	29.6	2881675	2881675
96ea7232-75f6-445f-b29d-c1f51e7a79c3	2026-01-06 17:44:50.526464+00	31.4	29.4	5019892	5019892
549b2c03-bc7c-4761-ba4f-91b5e1dccf26	2026-01-06 17:45:22.431768+00	44.1	29.5	4882288	4882288
39fce04e-fb75-4167-874d-4ec964b8b800	2026-01-06 17:46:22.404056+00	46.8	29.7	5042780	5042780
81696514-dfa1-4662-b03a-7034791cef93	2026-01-06 17:46:50.628958+00	37.1	29.6	1502179	1502179
e204525f-2236-47e2-97f7-c3ae187b28ac	2026-01-06 17:47:02.109087+00	46.6	29.6	4425745	4425745
d9c50fc6-84b3-4895-821a-00ca08e8e629	2026-01-06 17:47:22.850256+00	45.9	29.5	645110	645110
b62a8ac6-cf6c-4996-9f3b-8b5664ae9510	2026-01-06 17:47:50.522667+00	30.6	29.6	719964	719964
13719358-2c32-4481-af67-830670ebf362	2026-01-06 17:48:51.774023+00	48.3	29.7	5774581	5774581
bd0038b3-f066-4d5c-a9fb-0295c9c887cf	2026-01-06 17:49:22.356202+00	41.8	29.6	2128069	2128069
a6d3758a-6c4b-4247-9b95-5fbcf0bc1b2f	2026-01-06 17:50:02.090528+00	41.4	29.6	4085807	4085807
1b569a52-ebbe-4056-ae69-93d2ef10c6be	2026-01-06 18:16:43.652356+00	39.1	29.7	4400744	119368
8142e430-0a83-4c95-8a35-d61eb0b61622	2026-01-06 18:43:22.827981+00	42.3	29.8	3153502	3153502
ecf61750-4c48-4f6e-a18e-08f363b4493b	2026-01-06 18:43:25.948613+00	45.1	29.7	3008636	3008636
2115b4bb-726e-489b-9b9a-aaf8689b9db5	2026-01-06 18:44:22.780085+00	37.5	29.7	4375172	4375172
ce645606-5c66-4ea7-8a78-e19c12d9aa1e	2026-01-06 18:44:25.959066+00	46	29.8	695309	695309
a0249ef0-6415-404c-9ac3-d601d9ef6695	2026-01-06 18:45:50.321221+00	42.3	29.8	4028881	4028881
d1bcab96-26db-4ce3-b639-8e5748433bc3	2026-01-06 18:45:51.81421+00	72.9	29.8	3371109	3371109
ae76c9ad-8d18-43b2-b18e-8510addd8a89	2026-01-06 18:46:25.888664+00	40.5	29.8	2801160	2801160
d7a80fe6-701d-4626-b5f7-a278d8961268	2026-01-06 18:46:50.388736+00	36	29.8	5457157	5457157
f3e1519e-fcaa-4ae2-9b73-dea14a4ab260	2026-01-06 18:47:50.351909+00	41.2	29.7	2319993	2319993
afb574d4-83a0-4199-a630-58cbc7050adc	2026-01-06 18:47:51.705026+00	73.3	29.7	1286789	1286789
6246a01c-1d30-4971-b5b4-04561de2ffce	2026-01-06 19:09:44.486176+00	42.6	29.9	4480015	110401
070f6abc-8769-4cbc-b603-17665cd98b06	2026-01-06 19:36:02.103915+00	48.6	30	2237158	2237158
06f401c8-6399-4167-ae51-121be8a05d27	2026-01-06 20:03:25.865545+00	48.5	30	5143069	5143069
39de6bba-bc54-4100-80ec-2b4a62a2aa58	2026-01-06 20:03:50.570642+00	35.5	30	3600136	3600136
de484b6e-71f3-443f-937e-96f93942e876	2026-01-06 20:03:51.708102+00	41.3	30	3159308	3159308
363cf41c-c448-4b35-861a-22dc35895a21	2026-01-06 20:26:45.586399+00	32.2	30.2	5041577	129205
6fb59d3a-b5ce-42c8-af2d-5da84000f09a	2026-01-06 20:40:45.780583+00	42.7	30.1	4070574	107049
9b0fbbc1-627f-492c-b3e5-58d8efec7069	2026-01-06 21:07:46.210269+00	4.1	21.6	1479	343
cbb9d275-57b6-4b0d-94b8-68fd848979f4	2026-01-06 21:36:46.543405+00	3.7	21.5	1252	182
4df1c60c-5acb-46e0-ac08-ad450dde2bac	2026-01-06 22:05:46.861078+00	4	21.6	1743	284
a1ae2143-6987-42be-b0e5-e659e9c96f16	2026-01-06 22:34:47.23115+00	3.9	21.6	1582	173
50ad7508-59bb-4c70-94cb-e782550db5a0	2026-01-06 23:03:47.586257+00	4.2	21.5	1794	305
96266b9f-85e5-4d5f-a6a0-463a3e7f471e	2026-01-06 23:32:47.937418+00	2.7	21.4	1615	202
959d6a23-6318-44c6-83ae-c3464cdd44fe	2026-01-07 00:01:48.310561+00	0.9	10.1	1577	13
f2ae2b35-1ef0-4271-8fc8-5fe512ac5d1e	2026-01-07 00:30:48.648647+00	1	10.2	1610	19
b21a73bd-990a-45c3-8ee1-e1268ca1fea6	2026-01-07 00:59:49.081582+00	1	10.1	1319	23
184e91bd-b3f5-4087-a80a-121a2c83e2da	2026-01-07 01:28:49.466597+00	1	10.2	1393	13
7c7cee69-3fda-4fb2-9711-f8946d7e3642	2026-01-07 01:57:00.017597+00	2.4	10.8	11013	11013
3f207633-2412-49a4-ae85-ce29ae868ecc	2026-01-07 01:57:00.467564+00	2.4	10.8	843963	843963
f532230f-0172-457e-b952-b66efcf0eeaa	2026-01-07 01:57:00.64344+00	2.4	10.8	755368	755368
dcec84c6-df0a-4b8b-8fdf-2ad2d3532432	2026-01-07 01:57:00.661415+00	2.4	10.8	644292	644292
d2bc3332-b7b7-4ddc-afa5-6f1d4bb50023	2026-01-07 01:57:00.771846+00	2.4	10.8	658769	658769
295fc629-da10-48be-9d85-a53d7de9da24	2026-01-07 01:58:00.058123+00	2.5	11	12516	12516
219b7f29-855e-4bb5-bb09-e885d3a6c564	2026-01-07 01:58:01.056875+00	2.5	11	475755	475755
59df353b-7558-456e-bd0c-e3d80bec73c0	2026-01-07 01:59:00.708061+00	3.8	11	561432	561432
94d4c03e-8cc4-4aa5-8736-8b6a738625c1	2026-01-07 01:59:00.920051+00	3.8	11	537323	537323
de0d0765-0283-49c1-87db-b8092240e6d0	2026-01-07 02:00:00.75221+00	1.9	11	487320	487320
3ed51242-131e-4a5a-9017-ddfef22b213e	2026-01-07 02:01:00.205584+00	2.9	11	711728	711728
a1692df3-d79f-4baa-9a2e-454f69dd2cfc	2026-01-07 02:01:00.752783+00	2.9	11	734915	734915
0a3f26cb-fa57-44ba-8327-19530d37a7a2	2026-01-07 02:02:00.105895+00	2.7	11	9999	9999
8a9788da-480f-4a1b-b840-23f314446e20	2026-01-07 02:02:00.956785+00	2.7	11	332839	332839
289ee84f-2fe5-47a5-b076-a53512792a9e	2026-01-07 02:03:00.683633+00	2.6	11.1	784433	784433
34b6a108-a26d-4134-b4cb-78e9d995b4fb	2026-01-07 02:04:01.146961+00	2.6	10.9	263455	263455
b31a898c-4ba5-49be-bcd0-36ac8c01e588	2026-01-07 02:04:01.380129+00	2.6	10.9	673206	673206
af290912-ccab-479f-9542-8cffee331a29	2026-01-07 02:05:00.625062+00	3.3	11	672418	672418
ad57b809-e24e-42d7-8204-4be2f2d5b00e	2026-01-07 02:05:00.879469+00	3.3	11	490877	490877
459d5751-22a1-4afa-8d14-7e32c8c717a6	2026-01-07 02:06:00.675312+00	2.8	11	654611	654611
caeff0b0-af40-4c16-a7af-9fdd6bdb7322	2026-01-07 02:07:00.622771+00	3.5	11	668130	668130
0328383e-f48d-4391-83c2-b6368f88d5cc	2026-01-07 02:08:00.067821+00	2.1	11	8560	8560
fefb237e-86e8-4c02-aac4-9df432a8aa22	2026-01-07 02:08:00.661901+00	2.1	11	719553	719553
a6adc482-6968-41f4-b975-83c9c95666db	2026-01-07 02:09:00.898209+00	4.8	11	492694	492694
aad3e235-f05a-4ef9-bfe0-052778e5821a	2026-01-07 02:10:01.179554+00	3.9	11	428484	428484
a46734b8-34a5-4e30-a099-441d51b5b748	2026-01-07 02:11:00.740795+00	2	10.9	496980	496980
ffba56b6-d374-4b1e-9a73-005f19e27861	2026-01-07 02:12:00.156319+00	2.3	11	707570	707570
3e5d3556-06c8-4c42-8b37-15af6295b0af	2026-01-07 02:12:00.659035+00	2.3	11	632608	632608
5b203bb1-1613-441b-b20d-0edec9ed85eb	2026-01-07 02:13:00.949991+00	3.4	11	352630	352630
e8350474-7f85-4a17-95ba-96d383dbe544	2026-01-07 02:14:00.754334+00	2.7	10.9	729207	729207
7dcc6bfc-ec00-4526-b882-01b7cd004828	2026-01-07 02:15:00.305209+00	2.4	11.1	765759	765759
b538164f-af04-4462-9223-24979ff7c8d0	2026-01-07 02:15:00.852248+00	2.4	11.1	652348	652348
c1cbefff-8229-43a9-967c-4b1ac2319bb4	2026-01-07 02:16:00.280321+00	2.3	11	652960	652960
9f7743d4-b6a2-4d66-ac70-d51339f339da	2026-01-07 02:16:00.736622+00	2.3	11	765541	765541
5cbebd4a-aed3-4088-b144-f65f227ae697	2026-01-07 02:17:00.843752+00	2.2	11	638498	638498
650a7c26-d589-454b-93c1-9d21673b0533	2026-01-07 02:17:50.095605+00	2.3	10.9	37685	62669
8b3c65ed-4faa-4a51-92f6-d93e5d692ca4	2026-01-07 02:18:00.953499+00	2.4	11	603600	603600
9fde569e-ec30-438e-9ff6-25858330bfb1	2026-01-07 02:19:00.693516+00	3.5	11	558101	558101
55fc6369-0a2a-4e64-8621-6f4942d958d6	2026-01-07 02:31:50.2721+00	3.4	11.1	26383	18535
cb02c5bd-d19a-44e0-995b-c20dd629e0a8	2026-01-07 02:52:50.57054+00	2.9	11	26665	14547
c4b88116-b73d-4993-8bb8-c0b795d82241	2026-01-07 03:01:00.243491+00	2.8	11.1	730587	730587
a42469a0-b546-45e4-99cf-655fb963ddf4	2026-01-07 03:01:00.833039+00	2.8	11.1	513271	513271
3f108fbe-2d4c-42bb-b3ab-7fd4f0ac11a8	2026-01-07 03:01:00.969488+00	2.8	11.1	626973	626973
29ba0955-7d6c-443b-acc6-f9af0fe573a2	2026-01-07 03:02:00.922527+00	2.8	11	723610	723610
f2fc715c-7f52-4004-9072-319b03cc4dd0	2026-01-07 03:03:00.70716+00	2.1	11	280430	280430
8b2a5d8a-f9e1-4a9f-a794-f94b88223492	2026-01-07 03:04:00.107326+00	2.5	11.1	7999	7999
4c33337b-e284-4004-b4c9-4f41fdb04829	2026-01-07 03:04:01.203176+00	2.5	11.1	595810	595810
cd661864-c1d8-44f5-be99-41bf7a554652	2026-01-07 03:05:01.153188+00	2.8	11	465879	465879
db47b2d6-d3ad-4159-be70-8835dc814f7b	2026-01-07 03:06:00.954116+00	3	11.1	480298	480298
36bfad3e-5b0a-4357-b805-4e025fc63ae4	2026-01-07 03:07:00.694482+00	2.9	11	621800	621800
439b692d-eab3-4545-a543-232f3dc77960	2026-01-07 03:07:00.949351+00	2.9	11	417917	417917
148285a6-5199-493a-91fd-3b0341cc9e13	2026-01-07 03:08:00.180673+00	3.7	11.1	7804	7804
50d2492c-ab2e-4293-937a-c88933823eab	2026-01-07 03:08:00.986667+00	3.7	11.1	649670	649670
9791a9c7-7088-43f0-b833-4e98df226238	2026-01-07 03:09:00.862491+00	4.8	11.1	753396	753396
7429186f-76b2-4265-8301-40e8737babe0	2026-01-07 03:10:00.072949+00	2.6	11	8338	8338
9c2ce9ce-f897-41bf-98d4-2d1fb2778f83	2026-01-07 03:10:00.785198+00	2.6	11	534356	534356
ce9607ea-3fff-4801-a625-c34d1e8a9d66	2026-01-07 03:11:01.015642+00	2.8	11	570056	570056
d8bd0c3c-ce8c-4fe4-bf7a-29369cfb24a5	2026-01-06 17:43:21.539529+00	31.8	29.5	875796	875796
b95a043e-8abe-4df1-bbd8-e878d0990a17	2026-01-06 17:43:22.297284+00	40.4	29.6	4779693	4779693
00febac6-65be-4362-90a8-d7175fe7101c	2026-01-06 17:43:22.678507+00	40.4	29.6	342723	342723
aadc93a2-19d4-4886-974a-c4f2c6baab32	2026-01-06 17:44:02.104658+00	47.8	29.5	528456	528456
7140bef3-7455-43e1-a8df-ef7df3a45844	2026-01-06 17:44:50.450265+00	31.4	29.4	3962366	3962366
efc1332f-6afe-496d-a608-f14382a5729f	2026-01-06 17:45:02.07063+00	43.4	29.6	691027	691027
d375dd6e-ca60-49fe-9177-5dd2703f178d	2026-01-06 17:45:21.532304+00	34.9	29.5	2024303	2024303
b8d914aa-1ebf-42c5-9dcc-7198f39571df	2026-01-06 17:45:22.852426+00	44.1	29.5	5220404	5220404
c94ef866-1bdd-4816-8d17-2930998eeb81	2026-01-06 17:45:50.65378+00	37.4	29.6	5754198	5754198
8cba5df5-65d3-4862-af9e-43b2129b875f	2026-01-06 17:45:50.740236+00	37.4	29.6	1688045	1688045
bf4b3998-599e-44d7-b467-eeb384045e45	2026-01-06 17:45:52.247163+00	48	29.6	405114	405114
ec3e24ed-0246-4ea6-b2f6-865cc9e7f9e1	2026-01-06 17:46:22.841931+00	46.8	29.7	3606955	3606955
d2cc0796-7621-4e9b-9f37-32feecc8b744	2026-01-06 17:46:25.945096+00	54.5	29.6	1727450	1727450
89f2c2b3-e91d-45b5-beb6-9c6f94d0ba03	2026-01-06 17:46:50.527284+00	37.1	29.6	3980479	3980479
2d2dc555-cef9-482b-81bd-226289fb0d6d	2026-01-06 17:46:51.840492+00	40.3	29.6	522217	522217
88a5e7bf-5553-4fef-b0c5-a6042afbaba7	2026-01-06 17:47:22.319889+00	45.9	29.5	4253367	4253367
8b7252f7-f796-4d69-a320-02b20dc4807c	2026-01-06 17:47:22.734009+00	45.9	29.5	168382	168382
ee1d6bd4-6db9-45ad-863f-ca67894b18ca	2026-01-06 17:47:25.919634+00	46.6	29.5	626966	626966
08c58c9c-737f-4288-ac18-64009d927484	2026-01-06 17:47:52.077214+00	38	29.5	2016705	2016705
87052086-eee3-4104-9850-3e775a59a6e5	2026-01-06 17:48:22.869327+00	43.6	29.6	3155924	3155924
e55f1b7b-ff38-448f-8ba5-6a547b7b2af4	2026-01-06 17:48:50.493644+00	41.2	29.7	4981217	4981217
8ca3d18c-d215-4e6a-afae-97a8224e66c0	2026-01-06 17:49:22.748376+00	41.8	29.6	4518970	4518970
52023689-cbde-4ecd-96d2-928601475c4c	2026-01-06 17:49:25.947978+00	56.2	29.6	3540440	3540440
07cce8b6-9f36-482b-91bc-cd75f5fddf82	2026-01-06 17:49:50.387263+00	41.3	29.5	880812	880812
c38e7d5d-8f56-4f5d-b402-9129b6418a8d	2026-01-06 17:49:50.528318+00	41.3	29.5	3952135	3952135
3997b809-ba38-40b8-8da2-80e8fb4624c3	2026-01-06 18:17:43.711249+00	44.5	29.7	5062636	134508
7bf8d668-15e4-459e-949c-dc52f0db1919	2026-01-06 18:43:44.10089+00	41.4	29.7	4118575	110754
ed6cd581-19e3-41b0-a6fd-dfcb4ad01431	2026-01-06 19:10:44.469599+00	36.4	29.9	3619780	97422
6f6d6541-1e00-4b06-90bf-11e19c964138	2026-01-06 19:36:22.71739+00	46.7	30	5273147	5273147
cdcffaba-dfa8-4f62-b159-da9c10d58ec0	2026-01-06 19:36:50.560625+00	38.2	30.1	2562867	2562867
f89c0f76-eee4-4a66-b34c-306b394ef44e	2026-01-06 19:37:21.571122+00	35.1	29.9	5876100	5876100
f55e2f1d-e780-458d-a931-d966af852904	2026-01-06 19:37:22.386039+00	44.7	30.1	4436531	4436531
5833bd94-87d4-4d54-86df-850c3b1a0f3f	2026-01-06 19:38:21.687864+00	31.1	30	4982274	4982274
07b5cdd3-9632-4426-afdc-80f983978ec7	2026-01-06 19:38:22.746884+00	43.5	30	1969019	1969019
80721639-ed5d-4423-b186-75cb7d59dfe3	2026-01-06 19:39:22.655213+00	43.9	30.1	5431029	5431029
895ddbb1-479d-46ea-bbc3-d5f341f1bd27	2026-01-06 19:40:21.551133+00	32.8	30	3567261	3567261
f20c8f9b-634d-44f6-ae67-9c4a56acdccb	2026-01-06 19:41:22.339874+00	53.7	30.1	718247	718247
36db2851-17cf-4bdd-a9d2-a7e2e61f1e65	2026-01-06 19:41:50.615583+00	41.6	30	5045164	5045164
d5561c11-741a-4059-964c-d8aef80eefde	2026-01-06 19:42:22.747007+00	43.3	30.1	3468460	3468460
f6d5cd1d-684e-463a-a53a-8cc53cbcdb60	2026-01-06 19:43:21.55321+00	31	30	2420116	2420116
58f86524-d9ca-4000-a396-0b8012c8dd8c	2026-01-06 19:44:22.824052+00	42.9	30	950450	950450
c795b3e4-0ef3-4f91-87e4-4386dc1d3efc	2026-01-06 19:45:22.771683+00	45.1	30	374489	374489
dbbce4eb-228f-4a80-8d4d-8ff88fa53d8e	2026-01-06 19:45:51.713056+00	52.9	30.1	5896883	5896883
6312f4a4-36cf-49e1-8aa1-7f85149b2dea	2026-01-06 19:46:22.351204+00	41	30	4257684	4257684
0a2d5de4-ef1b-40da-a20a-302a35e68076	2026-01-06 19:47:21.559209+00	30.2	30	1468243	1468243
876bac82-208a-47c7-bd06-e7fe084e29f6	2026-01-06 19:47:22.636727+00	35.5	30.1	1440506	1440506
268824a7-37ba-4982-8504-311c24473eac	2026-01-06 19:48:22.795788+00	43.9	30.1	1308676	1308676
7eddd795-9855-4999-a3b0-d71865d18a9e	2026-01-06 19:48:25.89827+00	43.8	30	5154087	5154087
264076ee-3c51-4549-9502-1a14bd4b02a1	2026-01-06 19:49:02.094038+00	50.8	30	603560	603560
ab5ce6d9-1b4c-4e82-9bf2-1ff977bd7ced	2026-01-06 19:50:22.286101+00	44.4	30	1233256	1233256
8e8a9d1d-6ad2-4813-8ec3-2a6a55b18067	2026-01-06 19:50:25.952203+00	42.7	30.1	2636403	2636403
0c0b50f0-3ada-461e-a4d3-e1f412c2e13b	2026-01-06 19:51:02.111555+00	50	30	4189481	4189481
be5170fa-98d7-4a5b-ab39-dca0ed6e72da	2026-01-06 19:51:50.463337+00	36.7	30	4817115	4817115
944178fa-e018-4894-9c27-99dc0e5e6825	2026-01-06 19:52:22.269462+00	41.3	30.2	6451558	6451558
90819424-1976-4eab-a8ff-15efaf3eb3aa	2026-01-06 19:52:50.487374+00	42.8	30.1	3863313	3863313
ff3c4b0f-f05e-4e7f-b75a-0e6600a5d398	2026-01-06 19:53:22.717346+00	38.3	30	1050333	1050333
f61753a6-b084-491a-9e58-fc30bc6e67a3	2026-01-06 19:53:50.388301+00	38.8	30	755763	755763
a4e7da11-566b-44a3-9cff-52046838ffd2	2026-01-06 19:54:21.566028+00	31.9	29.9	5337504	5337504
05d4c5a7-981a-4e3d-b0e3-c834a12eb99b	2026-01-06 19:54:50.599561+00	35.6	30	740469	740469
9645bfc7-ae15-45ef-9cbc-c9e81f7aaebe	2026-01-06 19:56:22.356816+00	49.6	30	574770	574770
01536e38-d8a8-42ad-98ab-1c1e3b3b347b	2026-01-06 19:56:50.729273+00	34.6	30	5252384	5252384
388911a4-05c3-4a14-a890-60e3ea67c9ff	2026-01-06 19:57:50.629961+00	36.6	30.1	671352	671352
435463f5-9a0e-47d4-9af4-a4f437323083	2026-01-06 19:58:50.392993+00	39.6	30.1	5715183	5715183
98fc2f25-0993-464f-8004-85dfdd820d0f	2026-01-06 19:59:51.723602+00	71	30	4461066	4461066
80068e08-dfda-4d08-95fe-1dda053514eb	2026-01-06 20:00:22.348064+00	49.6	30	3811827	3811827
d101d9ec-3497-4585-9bc9-441d96caf451	2026-01-06 20:01:02.055877+00	48.6	30	4891342	4891342
da79aacf-7781-4a53-ad1e-69f77e8e7a56	2026-01-06 20:01:22.315702+00	38.8	30.1	4005480	4005480
416cb9b4-a0f5-4d42-ad4d-52af8ae584e0	2026-01-06 20:01:25.938486+00	45.3	30.1	3105554	3105554
10592391-4499-4521-8f74-e52c0450590c	2026-01-06 20:01:50.365965+00	40.2	30.1	2778245	2778245
8f944fee-5cd7-43bc-b8c1-feac8c4c744d	2026-01-06 20:02:22.292264+00	36.8	30	2778539	2778539
5cc883f1-d2c2-4715-8620-c6211e27e5db	2026-01-06 20:02:50.534581+00	44.1	30	3286237	3286237
593264f2-301e-4f78-a518-cb651292a9a2	2026-01-06 20:03:45.259595+00	40	30	3698107	95535
e4b20527-79bb-4499-a11f-08f375834773	2026-01-06 20:27:45.623814+00	39.5	30	4140541	109005
997162f7-cec8-4019-9c8b-40cbafda1bec	2026-01-06 20:41:45.827285+00	42.5	30.1	3943620	105461
6ffb3df2-9833-40be-bde9-666c925c04df	2026-01-06 21:08:46.226738+00	4	21.5	1448	331
e57f39c1-a007-49d5-a046-f389df6e9657	2026-01-06 21:37:46.572407+00	4	21.5	1287	197
d068ad50-1cef-44d8-acd7-eea6a76fecab	2026-01-06 22:06:46.879169+00	3.8	21.5	1481	274
9f00ca65-9bb2-4982-a661-e540574c80eb	2026-01-06 22:35:47.230794+00	4	21.5	1317	176
b287b9c5-a668-4870-b9fb-7f60e3c57303	2026-01-06 23:04:47.611885+00	3.8	21.5	1867	308
f9bbcd1c-6844-46de-a4b8-72828452fe59	2026-01-06 23:33:47.949919+00	2.9	21.4	1594	185
172f6eac-dc8b-454f-b9ee-6fc3bfadaa52	2026-01-07 00:02:48.300696+00	0.9	10.1	1517	23
f4418f6d-2ef2-4a04-a524-65d7bc5a0d0a	2026-01-07 00:31:48.674294+00	1	10.2	1505	21
7ea9e7d4-cd85-46ca-8e0b-adae61fb14de	2026-01-07 01:00:49.068795+00	1.1	10.2	1541	9
05817df1-526e-4bdc-a1e8-d87572169eae	2026-01-07 01:29:49.474517+00	0.9	10.2	1671	23
53107efe-d092-4322-a241-4bac4b3495cf	2026-01-07 01:57:00.149036+00	2.4	10.8	505716	505716
a6c1e9a5-95c1-4ebb-8c59-fd90793f2af0	2026-01-07 01:57:00.642262+00	2.4	10.8	851696	851696
c87f264f-6e58-4ac5-9e7c-5e72a95fbd33	2026-01-07 01:57:00.651607+00	2.4	10.8	588610	588610
ac1159fa-d9d6-4097-8d65-7e617da7dee0	2026-01-07 01:57:00.669749+00	2.4	10.8	709621	709621
d55d7236-0a59-4670-8a46-f1c0a1b1a534	2026-01-07 01:58:00.202647+00	2.5	11	660045	660045
7c0a6fb8-8984-4cff-be66-83d2fc858868	2026-01-07 01:58:01.050457+00	2.5	11	414348	414348
4beddc2b-ee9b-48b5-8d15-46bbf9e2bce1	2026-01-07 01:59:00.753271+00	3.8	11	686788	686788
985cd4b9-06ef-4388-8286-834c9c96ebce	2026-01-07 02:00:00.761905+00	1.9	11	738094	738094
94e2d471-00fb-46da-b853-292590f9fced	2026-01-07 02:01:00.705084+00	2.9	11	945465	945465
5e3c6117-a229-457f-a0df-a21e08108baa	2026-01-07 02:02:00.872453+00	2.7	11	226711	226711
83d9a4b4-a1af-4b21-9839-c65f9b8c832f	2026-01-07 02:02:01.143663+00	2.7	11	497243	497243
761eba97-6188-4fc4-893c-4685c5ce6168	2026-01-07 02:03:00.658992+00	2.6	11.1	553772	553772
df1f1bc3-f719-4dc9-bbf5-5cca48227dfb	2026-01-07 02:04:01.246963+00	2.6	10.9	386299	386299
1ced246d-8953-48ff-9b18-55c3b33cd9d0	2026-01-06 17:43:22.796153+00	40.4	29.6	171378	171378
66032dbf-2b9e-4e14-a3b4-91ac22f3cd41	2026-01-06 17:43:43.164103+00	47.5	29.6	4180139	112612
1ebeeb6b-84ab-4114-9b0c-3f754c33dbc4	2026-01-06 17:43:50.627338+00	34.4	29.6	637173	637173
8a70ada6-c959-40a5-b072-9eeebca4255c	2026-01-06 17:44:25.934697+00	57.8	29.5	1824974	1824974
9d354978-89fd-4585-bf78-e9f64068de34	2026-01-06 17:44:43.214753+00	37.9	29.5	4843610	133843
a4e563a5-9d82-4dea-bb59-7f3ac469a0c5	2026-01-06 17:44:52.028304+00	40.3	29.4	2563261	2563261
cade59c7-4de6-4750-beef-69267c8f3969	2026-01-06 17:45:22.931172+00	44.1	29.5	3407426	3407426
c86d7ecf-bfb7-41cb-87e7-caeea13fe8c9	2026-01-06 17:45:43.191496+00	50.9	29.5	3877422	105659
cbe29ad3-31bf-4e55-ad10-39ebbad4cdd2	2026-01-06 17:46:22.753545+00	46.8	29.7	5422840	5422840
197ed474-6cc7-4c77-adcd-2cb28c75d040	2026-01-06 17:46:43.232299+00	42.7	29.5	4030468	109116
0b4a1cd5-2258-4a6c-98e2-0d28c5b9e80f	2026-01-06 17:47:43.24563+00	48.3	29.5	4990068	134721
34a14c2c-221c-4866-b5ba-74ce8c5bbcf5	2026-01-06 17:48:22.354642+00	43.6	29.6	1538023	1538023
83360f5e-73fd-45c8-a20f-e86f8fa11a66	2026-01-06 17:48:25.944288+00	49.1	29.6	2742440	2742440
bbdf4ba5-866e-40f6-b208-981947ef9f02	2026-01-06 17:48:43.258078+00	44.9	29.6	4119459	113393
7ce942b1-d779-4947-871e-09d8db9f9ba5	2026-01-06 17:48:50.353876+00	41.2	29.7	3465270	3465270
b1dfde89-a161-4271-952f-13360c44c5d4	2026-01-06 17:49:43.2686+00	41.9	29.5	3925586	105699
135d4010-8998-496e-ad00-a1246cc02196	2026-01-06 17:49:51.809092+00	45.4	29.5	2887370	2887370
6b1c240f-3671-4265-8910-e6a517f5aa2b	2026-01-06 17:50:21.554544+00	32.3	29.5	3439672	3439672
225750f7-72f0-46cd-933a-4560dd7f8a93	2026-01-06 17:50:22.223237+00	39.1	29.5	6158699	6158699
fff45bf9-eb21-40b4-8eb7-91d875364e74	2026-01-06 17:50:22.764412+00	39.1	29.6	1876692	1876692
c9154ec5-e1b6-4a5d-9651-fe18ceed5e47	2026-01-06 17:50:22.918597+00	39.1	29.6	375769	375769
72d28da5-be97-4fb6-9e31-c555f7a8594a	2026-01-06 17:50:25.912349+00	42.1	29.6	5440001	5440001
39b06a09-81f5-4635-9321-785615ec9b72	2026-01-06 17:50:43.26122+00	49.4	29.6	4276609	115080
f9ed635d-c29f-442b-b04e-f5212ffadb44	2026-01-06 17:50:50.363102+00	37.5	29.6	3595705	3595705
87acfdbc-916e-49dc-aef7-e8ce83d60e7b	2026-01-06 17:50:50.484442+00	37.5	29.6	4755711	4755711
498d79de-33a1-4bc3-a4b5-2838e82491ff	2026-01-06 17:50:51.72792+00	41.6	29.6	3985098	3985098
7903bba5-792c-4663-b89b-206e53e3557a	2026-01-06 17:51:02.136865+00	50.3	29.6	4552769	4552769
8ba351e9-d592-468d-b6b4-2fe33634ea7a	2026-01-06 17:51:21.588415+00	28.2	29.6	5802451	5802451
4c0359c9-8919-46dc-8fa3-9dfa2414672d	2026-01-06 17:51:22.3877+00	51.1	29.6	5824953	5824953
ad1d6083-bd8e-47a9-b3de-f4517bb9ab6b	2026-01-06 17:51:22.805469+00	51.1	29.6	2991649	2991649
e6412c1a-a3a5-47a3-b1ff-816707a341a6	2026-01-06 17:51:22.937392+00	51.1	29.6	323329	323329
3c0cd043-c4cf-4b97-987c-a66b6e4b194a	2026-01-06 17:51:25.922929+00	49.1	29.6	4595253	4595253
ece75b52-b016-4efe-aeb8-f79d02fe5b79	2026-01-06 17:51:43.273721+00	53.3	29.7	3753035	97524
4e840e40-d263-456c-938a-5ee9761ce62b	2026-01-06 17:51:50.489032+00	42.4	29.6	572168	572168
976570fc-0c61-48eb-877a-9a3958296ecf	2026-01-06 17:51:50.568572+00	42.4	29.6	6247108	6247108
4115be4c-6b56-4aeb-ad54-07e731cf55eb	2026-01-06 17:51:51.80711+00	40.9	29.6	3170274	3170274
6638e8c4-6f42-4f8f-91a6-7dfa0ea656b6	2026-01-06 17:52:02.049761+00	46.3	29.6	4008269	4008269
6994b6eb-5fbb-41c2-89eb-75139c1052d9	2026-01-06 17:52:21.54689+00	29.7	29.6	3789869	3789869
4c0bac31-8769-4218-9d03-8d14c991d06e	2026-01-06 17:52:22.290637+00	39.3	29.7	751239	751239
77970558-5b26-4305-b211-15d981a892a4	2026-01-06 17:52:22.693592+00	39.3	29.7	4673030	4673030
671f647a-8fbf-4862-9f19-65f04309f162	2026-01-06 17:52:22.80513+00	39.3	29.7	843104	843104
65d47032-0acd-407e-8379-941bb61b1ddf	2026-01-06 17:52:25.939637+00	54.6	29.5	2173012	2173012
30873dae-7638-4ae6-9a53-0ef0e97d9c3d	2026-01-06 17:52:43.331069+00	43.6	29.6	4102977	111019
82ec6b12-ca5b-4ff0-b53c-9ebb7d832ffc	2026-01-06 17:52:50.395136+00	40	29.7	678032	678032
12c2a7ff-6444-45ea-89b1-7ff5bbdb116c	2026-01-06 17:52:50.531805+00	40	29.7	2950458	2950458
d77459ca-962c-4c51-9bbd-5546948240c9	2026-01-06 17:52:51.685586+00	38	29.7	4542774	4542774
2246c449-02a6-4478-8c10-d2af71511691	2026-01-06 17:53:02.126968+00	51.9	29.6	2414038	2414038
d2b20d78-92fe-4388-9702-479747cd73f4	2026-01-06 17:53:21.5197+00	29.8	29.6	1052385	1052385
da0def20-b7bd-46c3-9977-39e5d027155f	2026-01-06 17:53:22.306447+00	41.3	29.5	5102835	5102835
6f66e874-a424-4bb7-b403-3ec06cf4dfbf	2026-01-06 17:53:22.722053+00	41.3	29.5	264088	264088
3466515a-f265-463a-abcd-db2a01f2b6e6	2026-01-06 17:53:22.812291+00	41.3	29.5	2621189	2621189
720c8e7d-09a9-4618-9f6d-5e2a436a68eb	2026-01-06 17:53:25.942901+00	48.6	29.6	3838374	3838374
3157a4c3-2db2-4981-acb8-c175e79392d1	2026-01-06 17:53:43.358485+00	34.6	29.6	3821464	99511
5c52e673-b9f1-4b3d-bbf7-32840bf0c5e4	2026-01-06 17:53:50.518321+00	37.3	29.6	4696750	4696750
f9b10d1e-3c64-4e28-ad84-81f9a441aa1d	2026-01-06 17:53:50.603229+00	37.3	29.6	4484044	4484044
75dca465-14e5-4639-8385-6754c07ff3e9	2026-01-06 17:53:51.989706+00	42.6	29.6	611541	611541
2f4f2d6f-7017-46d0-b351-4ad647150f12	2026-01-06 17:54:02.128568+00	50.6	29.6	513505	513505
025e01da-6308-46bf-868e-0d755a32f3a8	2026-01-06 17:54:21.581502+00	30.3	29.5	980373	980373
b161e122-c377-4a24-845f-c21a7fa78008	2026-01-06 17:54:22.355073+00	40	29.8	4253286	4253286
d8024de1-67d0-4b31-950d-3504f0f31046	2026-01-06 17:54:22.728814+00	40	29.8	3430282	3430282
00ce4a00-ee9f-484b-90ce-52a132ed0eed	2026-01-06 17:54:22.818756+00	40	29.8	1203616	1203616
abca3728-d595-4a40-a2df-6bc7c8c0b340	2026-01-06 17:54:25.91123+00	43.3	29.6	864052	864052
1731a755-8c52-42fb-b7ed-549e155040c1	2026-01-06 17:54:43.353176+00	46.5	29.7	4195111	114721
c855af29-f275-48e4-bed7-3c6021575d41	2026-01-06 17:54:50.657622+00	34.6	29.5	825890	825890
cb85d0d8-68d1-41cd-8cdb-c625df3cced3	2026-01-06 17:54:50.753605+00	34.6	29.5	542565	542565
fde23afe-c33f-445e-9b78-c5c93a3c7195	2026-01-06 17:54:52.170211+00	42.2	29.7	5961343	5961343
d77073ff-5d9d-4470-9d56-f48f167324b1	2026-01-06 17:55:02.102729+00	48.7	29.7	5068514	5068514
7b5fca3c-c5b0-4eb7-b919-311a4e45ca4b	2026-01-06 17:55:21.549353+00	30.8	29.8	4358923	4358923
f5254537-d059-47e6-84d4-3e5834a5f290	2026-01-06 17:55:22.371266+00	45.1	29.8	3798038	3798038
7e7317b1-0639-400a-bb48-f3725a7f899f	2026-01-06 17:55:22.765391+00	45.1	29.8	216202	216202
275895b3-0e8e-4fd1-8a02-a1b8cd98363e	2026-01-06 17:55:22.893273+00	45.1	29.8	3403114	3403114
fa9515f3-69e1-40d7-8094-357d3fae765c	2026-01-06 17:55:25.956585+00	52.2	29.7	3029419	3029419
7558af8d-18b4-4873-aa2f-e39f105d4d0a	2026-01-06 17:55:43.340226+00	41	29.7	4528426	124663
8be98f59-d022-4709-a507-5769a8915933	2026-01-06 17:55:50.437619+00	33.5	29.7	672984	672984
e872d980-c11e-455b-9ba4-f5b6f7f95899	2026-01-06 17:55:50.559073+00	33.5	29.7	849447	849447
16c4f95e-61d5-4971-b5cf-3548f382ee0e	2026-01-06 17:55:51.735423+00	68.8	29.7	737386	737386
8ca54cfd-a70c-49a0-bf97-431b0c8b0060	2026-01-06 17:56:02.099701+00	48.9	29.6	4894418	4894418
baa397a7-8301-4c5e-b7c7-7cb33f7c3174	2026-01-06 17:56:21.60216+00	30.7	29.7	4581937	4581937
bada18e8-6471-4e88-8ad5-03433bdd4411	2026-01-06 17:56:22.376215+00	43.6	29.5	5792764	5792764
e96594e9-ae1d-4102-823c-fa9476f13d45	2026-01-06 17:56:22.711173+00	43.6	29.5	621862	621862
e04e0847-13f7-437b-a99f-f69b415b95d0	2026-01-06 17:56:22.812622+00	43.6	29.5	1219131	1219131
1abc1997-1238-4832-a277-9b01f6452517	2026-01-06 17:56:25.960086+00	50	29.7	1599649	1599649
3bcfad80-a98a-4d4e-8301-c8b244209c27	2026-01-06 17:56:43.375995+00	48.4	29.7	4207895	116055
2a4e60ba-3691-40fc-a993-745d3da12500	2026-01-06 17:56:50.42647+00	30.9	29.7	4429812	4429812
0986125f-1560-4d9a-8432-9f8767e55059	2026-01-06 17:56:50.559683+00	30.9	29.7	811420	811420
746af3e2-b141-4ecf-96a7-5e61a1d08ae3	2026-01-06 17:56:51.824329+00	42.2	29.7	4270086	4270086
36750e68-7835-42be-8581-4b2a90925cfd	2026-01-06 17:57:02.126048+00	54.2	29.7	5025737	5025737
04d806e0-6d93-4948-98c6-da44e2e99fa2	2026-01-06 17:57:21.551405+00	31.7	29.8	1199030	1199030
786dc2bd-5d63-4a96-ba85-c1ed09311581	2026-01-06 17:57:22.365686+00	36.6	29.8	1049090	1049090
7ce3670c-e712-4862-bd8f-766b4fa4bda0	2026-01-06 17:57:22.784608+00	36.6	29.8	430981	430981
19e76bf6-e3d4-41ef-94ac-260f59dd2c0d	2026-01-06 17:57:22.824472+00	36.6	29.8	273067	273067
bd82dade-2beb-467b-81a4-1f34ee00bc22	2026-01-06 17:57:25.960033+00	49.7	29.6	1481498	1481498
797cba03-fb9f-4a7b-bb50-40c2c3a6d826	2026-01-06 17:57:43.393181+00	35.9	29.8	4362657	116118
23958479-dbac-4cec-bb1d-18f4bd99179b	2026-01-06 17:57:50.612573+00	38.1	29.6	5683717	5683717
274efbe1-5f57-4943-95ac-68ccb047832d	2026-01-06 17:57:50.703758+00	38.1	29.6	762021	762021
3bc1751b-78cc-4a93-82ef-cd347b282892	2026-01-06 17:57:52.09248+00	72.6	29.8	3380192	3380192
ed526edd-3b0f-4104-8bee-87c24fd65658	2026-01-06 17:58:02.065881+00	46.8	29.7	4319888	4319888
c343f529-90a8-4933-8560-80723603b11c	2026-01-07 04:13:00.671482+00	3	11.1	615666	615666
34c4209c-36ee-4e0a-8590-5fbc92d917a4	2026-01-07 04:13:00.873715+00	3	11.1	852679	852679
5b8a1d7d-cc49-4157-8734-8197b46029ef	2026-01-07 04:14:00.798722+00	2.7	11.1	698181	698181
5d6f147c-9316-4ae6-8649-3b8b7106a383	2026-01-07 04:15:01.087712+00	3.1	11.1	492536	492536
84f65aa5-25a9-49c3-8738-389a8867b061	2026-01-07 04:16:00.725962+00	5.8	11.1	699215	699215
b48dde00-76df-47b3-b480-8b2b544d2b57	2026-01-07 04:17:00.224526+00	2.3	11.1	718473	718473
ac6ca86a-2e08-4b93-a49d-5dfaef20c00f	2026-01-07 04:17:00.770471+00	2.3	11.1	265361	265361
4696da5a-f1ad-41ff-81a1-7419379a5c01	2026-01-07 04:18:00.337343+00	2.2	11.1	200132	200132
b0327af7-0297-418b-99af-b322f3b1ef97	2026-01-07 04:18:00.916774+00	2.2	11.1	611357	611357
61681457-da4a-47b4-bfb7-1901443b4633	2026-01-07 04:19:00.766369+00	4.6	11.1	488353	488353
c52b4d21-4f07-4760-86a6-607058cba881	2026-01-07 04:20:01.029149+00	3.4	11.1	567586	567586
7eb62844-3135-48bc-b898-c92cf8b2ffc2	2026-01-07 04:21:00.061496+00	3.1	11.1	9362	9362
a1e3fccb-bf63-491d-a7f5-7f34fdd91beb	2026-01-07 04:21:00.95058+00	3.1	11.1	445268	445268
482e6584-37d6-49b3-a473-c1fef0a75e6d	2026-01-07 04:22:00.355323+00	3.1	11	458044	458044
5989c234-a2dd-4ce1-9a6f-7db1bce6469f	2026-01-07 04:22:00.973387+00	3.1	11	681645	681645
b8ea0136-845b-48e6-ad28-2b06d4d780f3	2026-01-07 04:23:00.139284+00	3.2	11	8926	8926
bd06169e-4b57-4a55-9c80-bbe101442f9e	2026-01-07 04:23:00.73426+00	3.2	11	571045	571045
4c953ef9-88cf-4f30-ab8d-85204530bdd1	2026-01-07 04:24:00.799827+00	2.8	11	577384	577384
2192f1a1-80ea-4bb9-93ff-91566a0f5222	2026-01-07 04:25:00.620794+00	2.8	11	696121	696121
5b436cb6-df07-4433-8841-b02d196d20dd	2026-01-07 04:25:00.846253+00	2.8	11	643413	643413
ef0beeaa-9c77-4c37-ae81-1771a504a474	2026-01-07 04:26:00.756706+00	4	11.1	643931	643931
a6bf23c9-a568-412d-b71d-db8672a9fac1	2026-01-07 04:27:00.751923+00	3.2	11	508429	508429
8e99d1ce-0a72-4879-a28e-67c1c130a267	2026-01-07 04:28:00.695839+00	2.7	11	655263	655263
9d719c3c-cbff-4c15-89ce-02b67af40cb4	2026-01-07 04:28:00.823864+00	2.7	11	714839	714839
923e2459-e178-47b0-8306-cc29108911a3	2026-01-07 04:29:01.036221+00	2.8	11.1	253930	253930
2c62cc34-a718-4963-a746-ec7cd98e5702	2026-01-07 07:47:11.816973+00	29.7	22.6	517209	517209
d71bb4e1-44d9-45b2-9a49-f49be9645cb8	2026-01-07 07:47:32.260811+00	14.1	22.5	750590	750590
d3d95a07-f3a3-455e-ba82-188415e52cfa	2026-01-07 07:48:32.301785+00	11.7	22.5	857914	857914
a6fc07c6-787f-4961-adb0-d0f1b70671d7	2026-01-07 07:48:59.780757+00	8.5	22.5	404208	404208
75a115b7-387c-4b8d-b369-57de39a0a2dc	2026-01-07 07:49:11.670735+00	29.9	22.4	624244	624244
ef0ef922-3e16-44e7-bd95-629c233aac71	2026-01-07 07:50:09.717153+00	22.4	22.6	892234	892234
50cf7fa2-6010-4bb9-88eb-cc6ac399068b	2026-01-07 07:50:58.491705+00	9.1	22.6	192014	192014
14bab13c-f34f-4588-ab57-250d27665aaa	2026-01-07 07:50:59.518004+00	8.9	22.4	345362	345362
115f8394-c74e-4191-a123-e29d81bdd79b	2026-01-07 07:51:09.131378+00	13.1	22.5	514573	514573
43bf9067-5339-4326-b270-7ba5b60c341e	2026-01-07 07:51:59.721684+00	9.6	22.5	422374	422374
5bcd8fd0-8752-48f3-979f-60354539c874	2026-01-07 07:52:09.309509+00	16.9	22.5	501780	501780
30cae24a-e006-47cd-b9d8-8f3a8325442e	2026-01-07 07:52:11.637228+00	17.9	22.5	718654	718654
d59eabd1-0fe0-4a5b-aaff-cfd16baa9360	2026-01-07 07:53:09.96816+00	6.4	22.5	622997	622997
0cb5f32b-7308-4f99-a273-37abfb3128d8	2026-01-07 07:53:59.923424+00	9.6	22.6	333384	333384
5c6d53f7-aff3-4fce-adab-2ce5dba6955f	2026-01-07 07:54:09.516867+00	7.4	22.5	442996	442996
d4f3cec2-b6c0-4d11-9428-32b92cffe6ee	2026-01-07 07:54:10.407127+00	7.4	22.5	1013630	1013630
e1c8d78c-05c8-4ddd-9e84-0b992e3b97d8	2026-01-07 07:54:58.289536+00	8.7	22.5	507403	507403
59b7fb02-9f69-4e40-9f0e-88dd2e9dab93	2026-01-07 07:55:32.346845+00	20.8	22.5	938844	938844
21d3b24c-c307-4fd0-b89e-10f5b91cf035	2026-01-07 07:55:59.602038+00	9.8	22.5	365926	365926
db835d00-4c19-4989-9ffd-527d9207ac9c	2026-01-07 07:56:11.615517+00	74.4	22.5	717756	717756
94a00cdf-64e1-4525-9377-373f3cec3dcd	2026-01-07 07:56:32.138096+00	9.8	22.3	902305	902305
28f76b32-8d57-44d1-8be3-5fb20f9f1e6c	2026-01-07 07:56:51.615044+00	8.1	22.4	33491	33491
9f65705c-df4f-4ef1-87e4-2dcaf81391f2	2026-01-07 07:57:03.719809+00	6.5	22.4	1245379	1245379
015b6996-ed60-4894-98be-4fefe4115efc	2026-01-07 08:01:03.728127+00	5.7	23	276237	276237
e61cfdde-f3d7-455a-a9c7-ce17cff8f0d9	2026-01-07 08:04:03.747661+00	7.4	22.2	343561	343561
86ab1cbc-856f-4290-ba8a-861209cf8794	2026-01-07 08:05:03.77157+00	5.9	22.2	297113	297113
65eee8e6-2c4a-4c94-85cf-cbc5dd95f020	2026-01-07 08:26:54.348389+00	2.8	21.5	1581	246
5fe50f04-a0bd-4cc7-a2a3-8d6ad9c2762f	2026-01-07 09:02:54.646734+00	6.4	25	10952	15722
30866991-488a-4e33-afcc-1d88e8af9159	2026-01-07 09:45:52.125385+00	5	24.6	99215	99215
35159624-252f-4e11-990d-cfe017d81c84	2026-01-07 10:04:12.590831+00	8.3	30.8	7819	71876
c3f67bba-ea80-4a0a-9183-59193aa857bf	2026-01-07 10:26:12.911416+00	5.6	28.9	5054	3336
0e55df5d-7768-4863-a15e-331997a783aa	2026-01-07 10:43:13.125967+00	5	26.4	5202	3668
7211ce33-bdcf-4ad8-842a-9e13344a64d5	2026-01-07 11:00:52.095717+00	11.3	28.2	110155	110155
9253fc63-05e9-42d5-bcf3-81f9ce77ea5e	2026-01-07 11:18:46.871778+00	6.9	31.5	82981	82981
a198bfaf-b70b-4369-bdd7-5318e8255a80	2026-01-07 11:19:46.826811+00	9.6	31.9	212894	212894
cd29a686-dcef-4c77-9a71-7ad6dc276a54	2026-01-07 11:20:46.805011+00	8.5	32.8	5354	5354
efe63eae-22c8-4902-a797-57f175c78f91	2026-01-07 11:38:50.821386+00	31.7	34.7	3906381	3906381
d91350e4-1f4b-4406-bf42-991b1104b9be	2026-01-07 17:37:51.922223+00	10	28.4	231140	231140
7c4fe1ab-b856-44a1-88a9-40a6f4e40be1	2026-01-07 17:38:51.906265+00	10.3	28.4	281308	281308
0b7e3632-d98d-4c69-bd21-355712feb4e7	2026-01-07 17:39:51.908342+00	9.8	28.4	228587	228587
80b24b3f-ae14-462f-82d0-64173dc833c5	2026-01-07 17:40:17.604017+00	9	28.3	1350991	1350991
35f20951-243d-4dfb-9144-11e1022b2753	2026-01-07 17:40:28.97861+00	8.8	28.4	942386	942386
0e4f0910-077a-4ec1-8940-c1d8e302d576	2026-01-07 17:41:17.609122+00	9.5	34	1239282	1239282
7135403f-5c27-4699-99bf-c840181d6194	2026-01-07 17:41:29.017515+00	11.8	35.1	249801	249801
25bbbee7-3c9c-4377-88ae-3eb56702925e	2026-01-07 17:42:17.648294+00	9.6	35	715404	715404
42e30007-ec8e-4099-aa02-a35486cf1498	2026-01-07 17:42:51.9061+00	12	35.7	247682	247682
ff74bac2-b04d-47b1-a6c7-1842dd1a0f48	2026-01-07 17:43:17.606986+00	11.2	35.6	999604	999604
66dfba61-ec4d-48eb-9f91-d6fbe039d28f	2026-01-07 17:43:28.99947+00	10.2	35.8	386903	386903
ab47a240-fe0b-400e-b17f-cc6675ed4207	2026-01-07 17:44:17.587713+00	8.4	38.4	1391337	1391337
2e233692-dfa8-46a8-b459-7e62a32fc3ad	2026-01-07 17:44:28.974713+00	9.9	38.6	648853	648853
070a207f-12bb-4d46-8209-ccf94413f8ad	2026-01-07 17:44:51.875114+00	9.2	38.5	337197	337197
bef9e485-8a9a-4cee-913c-60f440aee56c	2026-01-07 17:45:51.90445+00	9.1	37.6	180203	180203
26a54cff-38e4-454d-9606-ef2815b7ced7	2026-01-07 17:46:17.596911+00	9.3	28.9	1191433	1191433
8445ba09-1dd6-46ab-80d6-a62b8c7c58bb	2026-01-07 17:46:28.981501+00	8.1	28.9	653050	653050
7966f190-20a1-4020-8445-88322b629b46	2026-01-07 17:47:17.610561+00	10.6	33.7	983194	983194
b311c27d-570d-4747-af9f-bebbfe1fd6b7	2026-01-07 17:47:28.990815+00	10.8	33.6	805461	805461
053785d5-fee7-4185-97af-b3fef554f94e	2026-01-07 17:48:17.631774+00	12.6	37.1	772024	772024
0b2c02d7-eb17-456d-aa25-6c0fb01f353d	2026-01-07 17:48:29.1381+00	16.3	37.2	183482	183482
589ad204-d77f-4d69-8f56-4fd0fec4426f	2026-01-07 04:13:00.702638+00	3	11.1	518642	518642
aa0a1cf7-e1bc-4dff-860b-36073b67709e	2026-01-07 04:14:00.113598+00	2.7	11.1	10524	10524
a333702f-a001-4a32-a922-dbe13d548369	2026-01-07 04:14:00.272233+00	2.7	11.1	535193	535193
0ecf9955-06ff-4668-a754-052501ffaf91	2026-01-07 04:14:00.736629+00	2.7	11.1	688100	688100
d06dadb8-eed2-4fd2-87f1-281e56cf9f4b	2026-01-07 04:15:00.114683+00	3.1	11.1	10119	10119
d118bd73-5b4d-4ab3-a78d-6f5e829ecb4f	2026-01-07 04:15:01.048442+00	3.1	11.1	356681	356681
812a6598-70bb-4dfd-9a9a-d5fb2e2456af	2026-01-07 04:16:00.658796+00	5.8	11.1	666832	666832
a9243a16-7003-44ff-872f-654cb429b39b	2026-01-07 04:16:00.819964+00	5.8	11.1	613892	613892
718b6301-fa43-46c6-8c62-c3c9c8423c57	2026-01-07 04:17:00.739596+00	2.3	11.1	333684	333684
a6bb9059-a01c-4698-acbd-449f9f5cf83d	2026-01-07 04:17:00.948631+00	2.3	11.1	738160	738160
160245d1-f36e-4c59-889d-499fe4b1baa9	2026-01-07 04:18:00.940116+00	2.2	11.1	449179	449179
30dca317-2d01-470b-833e-312bf940e770	2026-01-07 04:19:00.213903+00	4.6	11.1	649555	649555
3bfb3ad4-cf40-462e-b1de-c48a4b88ace9	2026-01-07 04:19:00.753266+00	4.6	11.1	563165	563165
647601eb-027c-40b9-809b-a5992608a712	2026-01-07 04:20:00.420041+00	3.4	11.1	254406	254406
8dcf8b1b-9f17-401a-b8d0-1fe7bdc7810c	2026-01-07 04:20:01.035076+00	3.4	11.1	343249	343249
91ad858f-c90d-471d-8ebc-28062a19b93a	2026-01-07 04:21:00.980034+00	3.1	11.1	753255	753255
c83823ae-45fa-4eb3-9f4a-165059c844ab	2026-01-07 04:22:00.066608+00	3.1	11	9650	9650
8d9859c3-880e-46ec-a54b-5e7017ec9e64	2026-01-07 04:22:01.008661+00	3.1	11	750774	750774
1056408f-4373-475d-966f-df67f0b05cb8	2026-01-07 04:23:00.252113+00	3.2	11	647794	647794
90ca9eb3-0fda-419d-a218-46eba6f4076b	2026-01-07 04:23:00.713999+00	3.2	11	733763	733763
ac6c2f4e-83bb-4bf1-936a-95aeb0e87d05	2026-01-07 04:23:01.102824+00	3.2	11	762423	762423
96076df1-dd6f-47ec-8c17-1e86b159745e	2026-01-07 04:24:00.207712+00	2.8	11	609063	609063
d3384024-12c9-43c3-b475-6476d134a3c8	2026-01-07 04:24:00.72147+00	2.8	11	546103	546103
f4992cb8-0936-49f4-9ead-20f8ad45995a	2026-01-07 04:25:00.692514+00	2.8	11	746054	746054
f8adb2ab-0c3a-4614-bdd4-c8252aafdaec	2026-01-07 04:26:00.732198+00	4	11.1	448821	448821
b50b7144-481f-45ff-806f-a2deb775ab1f	2026-01-07 07:47:53.987294+00	11.2	22.5	94821	51388
a8440b34-9e33-4160-ac84-c7f7770500c7	2026-01-07 08:27:54.321648+00	2.6	21.4	3467	964
076f6fa0-4644-43a0-af10-88bb9989de07	2026-01-07 09:03:54.653685+00	6	25	10935	15460
60578397-cb81-480d-9c29-6442e9e9452c	2026-01-07 09:46:12.333004+00	4.7	24.6	3513	1957
bfd606a8-3551-4998-b811-890cd20b9524	2026-01-07 10:04:48.799954+00	25	30.7	14715	14715
725915e7-84a7-4656-a003-543e745a5353	2026-01-07 10:26:48.891178+00	10.8	28.8	2517	2517
901a03c3-fdc4-400f-823e-0e2c5d816c8d	2026-01-07 10:26:52.074797+00	5.7	28.7	77571	77571
c8010e20-6deb-4cc5-8a5b-42ac1e83eb51	2026-01-07 10:43:52.20379+00	4.8	26.4	891201	891201
21f35ec6-5d6d-4700-b021-83e1ab23acc3	2026-01-07 10:44:48.874906+00	23.5	28.6	810080	810080
2ff9f83c-0c70-4f75-9775-18add1073c20	2026-01-07 11:00:52.100875+00	11.3	28.2	73378	73378
6903d6f8-5322-4d77-90cf-a3efae3fa0a9	2026-01-07 11:18:51.884514+00	7.5	31.4	619575	619575
c15e6651-9b05-4982-ac47-3388cadde214	2026-01-07 11:19:52.098637+00	7.8	31.9	0	0
f2cfea9f-807d-4cac-a7d6-73ae12db7839	2026-01-07 11:20:52.069569+00	8	32.8	96328	96328
47125f88-c489-465e-b08e-159909028569	2026-01-07 11:39:13.844448+00	33.9	34.6	4376663	613240
3335dfba-919f-4edf-901e-8174f155792c	2026-01-07 04:13:00.711249+00	3	11.1	378177	378177
429abfed-a864-4fd3-b9f2-6d45d7c5d75f	2026-01-07 04:14:00.754072+00	2.7	11.1	661310	661310
d85903c0-441b-4b70-8560-c95c465bf916	2026-01-07 04:15:01.014997+00	3.1	11.1	209101	209101
4527772e-f508-4e30-b14f-f32dd3a706cb	2026-01-07 04:16:00.048733+00	5.8	11.1	10634	10634
736647f1-0f72-4753-a559-a5a7a3c9b7ed	2026-01-07 04:16:00.718514+00	5.8	11.1	636994	636994
1b777194-4e3d-4625-80ff-751a5c61c8a1	2026-01-07 04:17:00.863191+00	2.3	11.1	585635	585635
23e3bddb-308e-496a-bc98-04c77b107263	2026-01-07 04:18:00.849551+00	2.2	11.1	620451	620451
3e0fc0fd-9ce1-409b-8065-099e7b9ae46e	2026-01-07 04:18:01.017833+00	2.2	11.1	638472	638472
1f36810f-e3f1-4d97-8a69-6b68216dd26e	2026-01-07 04:19:00.079787+00	4.6	11.1	10911	10911
21752d79-90d5-4231-bf3d-c7161a5ae848	2026-01-07 04:19:00.781304+00	4.6	11.1	521078	521078
9bb2924d-1bd3-4835-8ea1-05ad44e7849f	2026-01-07 04:20:01.103068+00	3.4	11.1	443595	443595
b0901fb5-b8f9-457a-ba48-c3f0d04619d0	2026-01-07 04:21:00.308063+00	3.1	11.1	619512	619512
5f88a7a1-dc3a-4733-a83f-ce8ac724bcea	2026-01-07 04:21:00.940549+00	3.1	11.1	356650	356650
f1b1ca59-1dab-428e-8698-7efbefc89b33	2026-01-07 04:22:00.967044+00	3.1	11	611631	611631
1dcec6c8-367e-44ba-8a86-5883f8ee4ee6	2026-01-07 04:22:01.095669+00	3.1	11	893212	893212
85c651f3-0640-4d32-beaf-f54fac85071c	2026-01-07 04:23:01.014467+00	3.2	11	111187	111187
35bebacd-40a8-44ca-a2cc-60a50d50f0bf	2026-01-07 04:24:00.705541+00	2.8	11	606822	606822
3ddb93df-e1b5-44d1-b1c9-83e40723aed3	2026-01-07 04:24:00.892718+00	2.8	11	611471	611471
2a5600e2-02b0-4276-bbee-bf9fbb4c5130	2026-01-07 04:25:00.723216+00	2.8	11	866369	866369
19a23d7c-1ef4-4bf3-a5e3-c1c483ccbea6	2026-01-07 04:26:00.724018+00	4	11.1	771376	771376
970fde14-ce25-48da-992d-61c285740e99	2026-01-07 04:27:00.775044+00	3.2	11	615313	615313
c515920e-16db-4694-be4b-ca594ab036c8	2026-01-07 04:28:00.701678+00	2.7	11	614038	614038
aaf1f4bc-ba0d-4eb3-87fb-59eda1213aae	2026-01-07 07:47:58.329491+00	10.3	22.5	593312	593312
a707e6ea-e149-4d5b-8e51-869c2e6cb733	2026-01-07 07:47:59.464085+00	8.9	22.6	545788	545788
84cee0f6-ae93-4116-b68d-f1251a35315d	2026-01-07 07:48:09.935982+00	18.5	22.5	889219	889219
49bb2ca0-e6e3-4ed2-9f79-10115657f562	2026-01-07 07:48:58.509306+00	9.9	22.5	732162	732162
fba804a4-dff9-4580-b781-62bdae8c1536	2026-01-07 07:48:59.926068+00	8.5	22.5	551975	551975
72cfe74e-acdb-4f93-9459-b47a103a5a99	2026-01-07 07:49:09.382179+00	13.9	22.6	323612	323612
ba66a768-5151-4ca5-952b-48c07e5081d1	2026-01-07 07:49:10.25189+00	13.9	22.6	955840	955840
b8d77878-0844-4c10-bb4f-bb428bca18c0	2026-01-07 07:49:59.785361+00	9	22.6	525516	525516
1a5c5c16-05af-496a-9ce8-b1adec3f9049	2026-01-07 07:50:09.72067+00	22.4	22.6	510421	510421
4d6d5f1b-89e3-4348-92fe-56fd62583577	2026-01-07 07:50:10.590058+00	24.3	22.7	1497697	1497697
cb8035a8-5a99-44f3-aec2-bf234e9ab807	2026-01-07 07:50:32.240971+00	11.3	22.5	770645	770645
f1b15a08-7886-4c1a-bc5d-5ded915c10f3	2026-01-07 07:50:59.51606+00	8.9	22.4	326830	326830
15a66593-db52-438f-80ac-1972632d190a	2026-01-07 07:51:10.022722+00	13.1	22.5	804065	804065
4997fd81-4433-4e0e-9355-e52a4c17a7db	2026-01-07 07:51:58.378022+00	9	22.5	644022	644022
a39064c6-4aea-4671-b05c-35dcb9741d36	2026-01-07 07:52:59.707989+00	9.4	22.5	630974	630974
72307f7a-1bde-4229-af0d-34d78affef41	2026-01-07 07:53:58.591694+00	10.9	22.6	389235	389235
e2b1eb73-73c5-4179-bd08-175e9a17821e	2026-01-07 07:53:59.995477+00	9.6	22.6	374496	374496
265bd27c-6686-45b6-8e66-88640d8f1cfc	2026-01-07 07:55:09.489446+00	16.3	22.5	428812	428812
ace56e91-a25c-46eb-be24-6197cfad7c15	2026-01-07 07:55:10.455346+00	29.6	22.6	526335	526335
e38bef88-5ed5-4130-acf2-15570a8e4b4b	2026-01-07 07:56:09.254241+00	13.5	22.5	919408	919408
be5fd192-702b-4327-8a06-ca5be7c0ad9b	2026-01-07 07:56:32.738658+00	9.8	22.3	638273	638273
ecd38021-8118-47c7-bbb0-f03709204d0d	2026-01-07 08:03:03.729183+00	7.5	22.2	351744	351744
4df4f99b-83f9-47c4-a748-1be87d5d42e9	2026-01-07 08:28:54.334457+00	2.9	21.4	3034	104148
f139008c-3d46-4bf2-92ba-a16477081131	2026-01-07 09:04:54.658293+00	6.6	25	8646	15279
46509fa6-ef22-4670-91b7-f5cf1ca1467e	2026-01-07 09:46:52.132653+00	4.7	24.6	68922	68922
e8443bed-e3dc-45df-9888-51a2382e0598	2026-01-07 10:04:52.079109+00	28	30.7	140557	140557
c07d4073-fc86-4825-8b3d-cca6f58b1b49	2026-01-07 10:27:12.878573+00	10.4	28.8	5388	3833
efe29a02-3bdd-4822-b9f0-00ac20c8a0a7	2026-01-07 10:43:52.205807+00	4.8	26.4	1244345	1244345
bd86ba8c-22b8-4495-9767-405eca02d950	2026-01-07 10:44:52.071309+00	24.3	28.9	660314	660314
c3f6006b-7102-4b07-8ad0-5b170a77ddd5	2026-01-07 11:01:13.278485+00	6.3	28.2	6498	4230
e050d7df-9a99-4a76-a65b-e2e11dab8c1b	2026-01-07 11:19:13.57004+00	7.1	31.5	9621	7266
5715db50-dd65-4eec-a697-26baf246f695	2026-01-07 11:39:44.811401+00	32	34.6	4926908	4926908
121c6329-617e-4075-bdf0-ca6bfb8cf194	2026-01-07 11:39:51.901044+00	33.9	34.6	2535563	2535563
a8da84cc-8c4b-419d-8fc0-bf13af30ffa9	2026-01-07 11:40:44.812687+00	25.7	34.5	746689	746689
2288531a-419e-49ec-82c8-6003250a3563	2026-01-07 11:40:51.930505+00	26	34.5	1084178	1084178
d0f40451-eb0c-41f3-8619-24c04c9100f9	2026-01-07 11:40:59.458103+00	30.5	34.4	906092	906092
b7008304-28d3-4460-9113-7c7b3a801bae	2026-01-07 11:41:51.931455+00	37.6	33.2	3303594	3303594
d33218a6-5cdb-4546-8784-02a02168ee8d	2026-01-07 11:41:59.316177+00	30.5	33.2	1979911	1979911
13d6f7fe-cfed-40e9-8fc8-c4e91a0276af	2026-01-07 11:42:51.934702+00	34.6	33.5	1980212	1980212
b5045826-05c3-4131-95f3-c05bff59c995	2026-01-07 04:13:00.722067+00	3	11.1	709257	709257
79ba1789-a1eb-48d2-8aea-59dbacb2d82b	2026-01-07 04:14:00.713765+00	2.7	11.1	673021	673021
a67e91af-3aad-4154-92a1-65e810fbb85e	2026-01-07 04:15:01.139288+00	3.1	11.1	555058	555058
6da29c16-1b95-4d04-8117-ac13e1ed1c39	2026-01-07 04:16:00.740965+00	5.8	11.1	533867	533867
66f89c3a-605e-459b-9ee6-d3a1facf244e	2026-01-07 04:17:00.809003+00	2.3	11.1	181631	181631
b28e5282-317f-45ab-b410-0326419c41f3	2026-01-07 04:18:00.924201+00	2.2	11.1	595090	595090
75aca7cc-9d9c-431e-817d-a0adc0a8b72b	2026-01-07 04:19:00.850127+00	4.6	11.1	468651	468651
e28dc8e5-e8d2-4666-9e2e-bffa88c7f2cf	2026-01-07 04:20:01.087634+00	3.4	11.1	701678	701678
30fbf079-0b11-4040-93b6-8b45bebd0f38	2026-01-07 04:21:00.957493+00	3.1	11.1	707608	707608
61106eec-4ea1-4f85-9c84-51453e91ff1c	2026-01-07 04:22:00.983151+00	3.1	11	682733	682733
e2997fdd-eddd-430f-aa94-11d3c81181b1	2026-01-07 04:23:00.72883+00	3.2	11	510327	510327
554693ad-b7db-466c-959e-079518e99df2	2026-01-07 04:24:00.759815+00	2.8	11	695580	695580
da5ccc7d-15f4-43f3-ab5d-58785b7115a7	2026-01-07 04:25:00.083627+00	2.8	11	7424	7424
fd6e52fb-f8a2-4de1-8cca-2bc5238a84a3	2026-01-07 04:25:00.703318+00	2.8	11	427387	427387
3221135a-8cb7-4e3e-b5cd-5f1c2998924f	2026-01-07 04:26:00.119256+00	4	11.1	12478	12478
30336a6e-1f9a-46d1-9117-a0691e92b91f	2026-01-07 04:26:00.273895+00	4	11.1	789352	789352
bb7defb8-a0f5-470c-b6f5-473e95336a8f	2026-01-07 04:26:00.7444+00	4	11.1	752262	752262
749e11ae-b8fc-4ef5-9b89-f36cc13b93c3	2026-01-07 07:47:58.41589+00	10.3	22.5	715545	715545
d1d68a3b-a8d0-4b49-b23e-bb967a2a0fa9	2026-01-07 07:47:59.556761+00	8.9	22.6	722130	722130
79cd72f6-cb37-4ae7-a118-f2919325ebb4	2026-01-07 07:48:11.300799+00	24.1	22.6	645325	645325
0b78cfd9-a8f0-4f19-a1d6-d0571d2b73e7	2026-01-07 07:49:32.307922+00	21.4	22.5	542152	542152
b716f0ca-4bb3-4381-b5d9-24b61aeadca7	2026-01-07 07:50:58.469643+00	9.1	22.6	518538	518538
ca66d5b0-eab6-41b4-917e-ca5f559b5a66	2026-01-07 07:51:09.13744+00	13.1	22.5	624024	624024
aefc58b6-6ef7-47b5-8d17-4a12384331d9	2026-01-07 07:52:58.478275+00	10	22.5	733189	733189
e140c5f7-d88c-4640-8484-5fbc86da4d2d	2026-01-07 07:53:09.111875+00	6.4	22.5	695660	695660
5ed3fd1f-4469-4ca5-95b6-fd93a090f22f	2026-01-07 07:54:00.094362+00	9.6	22.6	359794	359794
2ff6fa3a-4bea-4b2b-8c0f-3b1ecb425271	2026-01-07 07:54:11.772705+00	19.7	22.5	875988	875988
6f656693-c483-4ef6-841e-06333a111447	2026-01-07 07:54:59.67092+00	8	22.5	509006	509006
270733f8-cddb-4eb3-ac0a-f0c726c5370b	2026-01-07 08:00:03.740828+00	7.5	23	401759	401759
4f7c484b-b02d-4189-afc0-7ef7a39e270f	2026-01-07 08:28:56.742413+00	3	21.4	241345	241345
68454d0d-7493-40bb-ae2b-2b72e03e2385	2026-01-07 09:05:54.659341+00	5	25	9238	7554
19aa8c56-7ca0-47e4-a4bd-2e9d9f290d59	2026-01-07 09:46:52.137327+00	4.7	24.6	79861	79861
f2b6b06c-5cea-4a11-8c0d-4ba567134e69	2026-01-07 10:05:12.615076+00	14.1	30.7	5816	27689
69d8416d-2da9-4303-b48b-3d6be289ccb0	2026-01-07 10:27:52.087072+00	4.7	28.8	0	0
4c88aa25-cf59-4b8e-b49b-65f83f6d255a	2026-01-07 10:44:13.138334+00	25.3	27.5	1438711	77203
bbb7093a-48b0-4a8a-8e8f-8092c9cb3e8d	2026-01-07 11:01:52.059629+00	10.3	26.8	152052	152052
e63d0c1f-e221-4c1c-9d39-9652c239b698	2026-01-07 11:20:13.579641+00	8.1	32.2	11117	111180
83b1e11c-2d26-4caf-b3a0-f530ac41bfdd	2026-01-07 11:39:50.820542+00	33.9	34.6	5329035	5329035
d086a379-0070-4a44-9321-d55a3952e268	2026-01-07 04:13:00.751445+00	3	11.1	553018	553018
d9424347-4c57-4836-8855-d9e1392d1ca0	2026-01-07 04:14:00.696823+00	2.7	11.1	395545	395545
dbc5869e-4377-4446-a0f0-41e5aa3af23f	2026-01-07 04:14:00.902449+00	2.7	11.1	560871	560871
b9f3c327-6496-41a6-acc4-3b7e742b09d9	2026-01-07 04:15:00.984363+00	3.1	11.1	509185	509185
cb34d85d-f1aa-4f7f-bb1b-5f7898a5ce64	2026-01-07 04:15:01.274698+00	3.1	11.1	512882	512882
ba0636c8-27b6-412e-9638-df85299cdd89	2026-01-07 04:16:00.688526+00	5.8	11.1	641006	641006
bb058ee5-efe0-4f88-835e-c7b6a39cb320	2026-01-07 04:17:00.825688+00	2.3	11.1	606419	606419
6137d48c-8c2e-45c4-b1ec-d4334ab22fea	2026-01-07 04:18:00.873937+00	2.2	11.1	412601	412601
80f7e160-a17d-4f1c-b898-da1455831689	2026-01-07 04:19:00.71588+00	4.6	11.1	492836	492836
ae0db0a9-1d72-4507-ba45-536cb714f764	2026-01-07 04:19:00.947069+00	4.6	11.1	622765	622765
4baba121-1f62-4068-851d-d034c979dedd	2026-01-07 04:20:01.005288+00	3.4	11.1	643341	643341
91a3e02d-53b0-4e2a-93c3-f16f1e240a91	2026-01-07 04:20:01.209905+00	3.4	11.1	495592	495592
eb812078-2550-42d5-a6b7-2a1a88177899	2026-01-07 04:21:00.874721+00	3.1	11.1	503550	503550
78a356aa-1767-43f6-869b-78f13e1a1117	2026-01-07 04:21:01.11482+00	3.1	11.1	322976	322976
a3ad4acc-2575-4a83-8ba8-77a2fa973248	2026-01-07 04:22:01.019052+00	3.1	11	564533	564533
90346a02-e653-40fd-8b70-0f3d617354e3	2026-01-07 04:23:01.020622+00	3.2	11	181075	181075
c1c8da6b-a021-4dbe-aff2-021b1e73e4ba	2026-01-07 04:24:00.781154+00	2.8	11	559568	559568
982aaefa-d819-4a9c-8219-5290bb5818ba	2026-01-07 04:25:00.740838+00	2.8	11	631685	631685
5fd36292-c55a-4443-8e04-2b6973fcf1ee	2026-01-07 04:26:00.709902+00	4	11.1	529334	529334
ceac1187-4ff8-4918-bb06-671d01f0337e	2026-01-07 04:26:00.866126+00	4	11.1	657993	657993
92e8f1bd-17a2-406d-8adf-5271396c0360	2026-01-07 04:27:00.121504+00	3.2	11	8207	8207
4ca76942-0685-4f5a-a922-0fe075d2cc14	2026-01-07 04:27:00.769558+00	3.2	11	556410	556410
b79f8990-2b85-44f0-b9e4-52c512db7074	2026-01-07 04:28:00.711457+00	2.7	11	731116	731116
177ff8d9-8861-4772-b841-f835491d6f34	2026-01-07 04:29:00.168093+00	2.8	11.1	10475	10475
19afddf1-01b7-421e-8a2f-d5ce2d8a4101	2026-01-07 04:29:00.260689+00	2.8	11.1	721611	721611
d0c9ed98-1ab1-4bb2-89c4-6317ecfebde3	2026-01-07 04:29:00.994262+00	2.8	11.1	457806	457806
e45e1903-e1f0-4e6e-85cc-1bb55ed3b989	2026-01-07 04:29:01.133361+00	2.8	11.1	474536	474536
c52a7502-32bb-440f-80cd-4c06f5ae9209	2026-01-07 04:30:00.94092+00	3.1	11.1	580436	580436
1295a753-4626-4678-965d-4f3719a5fe60	2026-01-07 04:30:01.205237+00	3.1	11.1	443963	443963
b760259c-01df-4fde-a22b-20cc782570c4	2026-01-07 04:31:00.850302+00	2.8	11	616819	616819
f99ad33c-16e0-4750-985d-548b9c9ee8a3	2026-01-07 04:31:01.114098+00	2.8	11	315268	315268
1a48df3d-4264-4acf-8120-baac18965c0c	2026-01-07 04:32:00.868724+00	3	11	533340	533340
ad2af2e8-7f1c-4d6b-b024-be195400a66b	2026-01-07 04:32:01.090765+00	3	11	613277	613277
133f82d6-ec80-4108-9eb3-23ccd1ce7083	2026-01-07 04:33:00.983666+00	4.6	11.1	93235	93235
2f2a64bc-e4c9-4054-b6c2-43fc9db744ec	2026-01-07 04:34:00.821303+00	3.5	11.1	647601	647601
664ec839-51db-4562-9b0a-7936edeadce8	2026-01-07 04:35:00.231721+00	5.9	11	414698	414698
8542e97c-61cf-4e0d-bff4-33b21799dccf	2026-01-07 04:35:00.734102+00	5.9	11	693348	693348
db31b194-18f9-4a55-bc9a-78c1c12760db	2026-01-07 07:47:59.463932+00	8.9	22.6	361142	361142
ac41d1bd-0122-4826-b15c-2b413566cf7b	2026-01-07 07:49:58.625161+00	9.7	22.5	715948	715948
3f03b278-cc21-4619-8dee-87d9ad363256	2026-01-07 07:50:59.64751+00	8.9	22.4	605991	605991
f37de4be-5a2c-4a51-bc7b-4f160daadc4a	2026-01-07 07:51:11.391185+00	19.7	22.5	372831	372831
6819bb19-5675-464f-8078-3f9e32904d66	2026-01-07 07:51:32.351379+00	7.6	22.6	735536	735536
6f2ec1e1-cc25-4474-a924-ea5f6e76095f	2026-01-07 07:51:59.807255+00	9.6	22.5	443990	443990
1334b780-4b5c-4785-bfd1-3056a5820a0c	2026-01-07 07:52:09.310459+00	16.9	22.5	923750	923750
a4209d48-de63-4943-843d-f025b2ab6819	2026-01-07 07:52:58.58481+00	10	22.5	741815	741815
2cec6ee1-c418-4288-8c13-d476e606a984	2026-01-07 07:53:32.284784+00	9.8	22.5	728419	728419
6a830389-a803-4e52-a280-e0c91659133f	2026-01-07 07:54:58.365148+00	8.7	22.5	367406	367406
0d4ba257-973a-41e0-8324-d1cbcfa6625c	2026-01-07 07:54:59.583735+00	8	22.5	383941	383941
27133883-38ff-4b2e-84f5-e02dcfbd15d2	2026-01-07 07:55:09.496312+00	16.3	22.5	1220868	1220868
4b20389e-70dd-4ed6-a887-3e2fef843763	2026-01-07 07:55:11.805417+00	29.6	22.6	335752	335752
0b61467a-e360-488d-ba56-0325003c0c57	2026-01-07 07:55:58.393376+00	10.5	22.5	1766777	1766777
57d285c7-bc8f-459d-a618-04f57b21b4cf	2026-01-07 07:55:59.534055+00	9.8	22.5	185315	185315
876fb4cc-5e76-4f4c-9a19-4d1b5c814466	2026-01-07 07:56:10.129923+00	13.5	22.5	1033898	1033898
8ee32975-8dff-48d4-9ba3-935b95ea0390	2026-01-07 07:59:03.715156+00	7.1	23.1	413846	413846
66c5c043-43f9-422d-b6b5-51fc6453b55b	2026-01-07 08:29:54.349078+00	24.7	32.6	4544	2813
e56fdd49-194e-4ad8-9b3e-ef56a8fd5a4a	2026-01-07 09:06:54.671092+00	5.3	25	1621	1691
05955a29-a1cc-4cd9-9025-8e4e8e9f6f95	2026-01-07 09:47:12.339875+00	11.3	24.5	3057	2209
eb9b1419-ee89-49ed-9c47-47ee61576216	2026-01-07 10:05:52.047342+00	27.1	30.4	259916	259916
5616e105-8e0e-4393-bd70-7db0d5bb56f2	2026-01-07 10:27:52.090546+00	4.7	28.8	74904	74904
f6a4bb79-791a-4bdb-b89b-d4ef27ba3300	2026-01-07 10:45:13.165151+00	23.2	30.6	1377004	52506
dd78fee2-2de4-47d6-ab19-782cfb5ede7e	2026-01-07 11:01:52.06211+00	10.3	26.8	128106	128106
5503fdbe-2833-4e39-a99c-4e126d5c3ffd	2026-01-07 11:21:13.555235+00	7.7	32.9	7580	4793
9ae1b793-b10c-452f-9272-b9b409eb7c70	2026-01-07 11:40:13.827952+00	26.1	34.5	1036387	57782
c76cb0cd-56f3-4cf9-ad77-788ea0be69a1	2026-01-07 04:13:00.762131+00	3	11.1	508768	508768
2bd9f1e2-6531-49a7-8418-12139516ceb4	2026-01-07 04:13:51.618796+00	3.1	11	17304	9436
c5c22bdd-5e21-43d0-82a5-ca092ea2f552	2026-01-07 04:14:00.705545+00	2.7	11.1	683630	683630
335688f5-1991-497f-9f8e-2a4f91abe119	2026-01-07 04:14:51.634849+00	2.9	11.1	16912	10436
fb40bb54-3703-4d72-91bb-e0a36e4e3ab4	2026-01-07 04:15:00.247894+00	3.1	11.1	454892	454892
b50f2d32-faeb-49d7-844e-9a36e1718365	2026-01-07 04:15:01.036405+00	3.1	11.1	450385	450385
367c490c-d91b-4226-a9cd-c24bed62834a	2026-01-07 04:15:51.635084+00	2.9	11.1	15783	9320
9d933c0c-a9cb-4a34-9ce9-0c4bd0bbe53e	2026-01-07 04:16:00.190718+00	5.8	11.1	751709	751709
4228a206-dec7-4eec-83ae-126a19190af1	2026-01-07 04:16:00.669788+00	5.8	11.1	562391	562391
e3636f55-2c38-4bb5-b0d5-07b8ae359dfc	2026-01-07 04:16:51.65909+00	6.1	11.1	21074	37606
3f852fa0-b008-46d2-8d29-b463dee03429	2026-01-07 04:17:00.095694+00	2.3	11.1	11150	11150
1bdf3e86-7df3-4ebf-afac-95e615db9da6	2026-01-07 04:17:00.820312+00	2.3	11.1	639839	639839
c220025e-0c45-43d3-8fd7-86426657d108	2026-01-07 04:17:51.675503+00	4	11.1	19360	34149
5decfe14-90a5-46a8-b3ad-e74825ebdce4	2026-01-07 04:18:00.054929+00	2.2	11.1	10562	10562
d885a7b0-99b4-46b1-b680-5e88628cbffc	2026-01-07 04:18:00.898053+00	2.2	11.1	420207	420207
7637d5f2-c71a-4901-8de0-d5dd9438090f	2026-01-07 04:18:51.678321+00	6	11	16731	7370
8c097e27-ede9-4cab-a58f-7ef743c2b386	2026-01-07 04:19:00.825243+00	4.6	11.1	523695	523695
234f43f2-6619-4407-81d4-397c768260fb	2026-01-07 04:19:51.687408+00	5.6	11	19785	29966
965c82f5-b84c-4ee2-a3ff-c06418982521	2026-01-07 04:20:00.18563+00	3.4	11.1	16453	16453
28939ccf-ea47-4128-a4e9-5231d7cd1ba6	2026-01-07 04:20:01.052392+00	3.4	11.1	476504	476504
f0d3418b-bb9a-4787-96d2-12764e10c045	2026-01-07 04:20:51.688415+00	4.8	11	19459	10083
92b5dd07-848d-4c09-9a7a-8340fb417427	2026-01-07 04:21:01.010184+00	3.1	11.1	455842	455842
bcde957e-8192-43ac-8840-e6e4d36f7656	2026-01-07 04:21:51.713462+00	3.2	11.1	18250	21240
b08a2453-73da-4692-bc55-2cd01eb1757c	2026-01-07 04:22:01.012562+00	3.1	11	600941	600941
ddd6e3df-d784-4e18-a1ff-c617df2de80c	2026-01-07 04:22:51.731166+00	6.1	11	17546	13814
42c9da0f-8510-45dc-810f-1adaab08345b	2026-01-07 04:23:00.973757+00	3.2	11	645786	645786
29d71e37-14d6-495c-8a37-fc76f55dc069	2026-01-07 04:23:51.741657+00	4	10.9	19906	8218
3252e8d1-ddca-4e27-b019-e0493cd07ce8	2026-01-07 04:24:00.084871+00	2.8	11	9164	9164
106594c5-5706-4f29-ac7f-9d7a49ea4a3d	2026-01-07 04:24:00.764919+00	2.8	11	378715	378715
4b77360c-c4e0-4456-ad4b-94f1a4ffbf49	2026-01-07 04:24:51.761833+00	4.3	11	21193	32957
8489686c-c0bc-4541-b3ac-bffe3a4dc8de	2026-01-07 04:25:00.188091+00	2.8	11	598790	598790
c64a71cc-c93d-4165-b1ab-45826d209e73	2026-01-07 04:25:00.670749+00	2.8	11	646604	646604
713aa5e1-d2bc-41e5-808c-4e0188706d73	2026-01-07 04:25:51.763931+00	4.3	10.9	15995	8208
8c33c553-1af6-49ec-b56f-c1b0aceea180	2026-01-07 04:26:00.772814+00	4	11.1	621842	621842
f824f31f-d137-4daf-9486-b6bd76f1a86b	2026-01-07 04:26:51.788321+00	6	11	17375	9162
483b9356-e3df-4424-ae85-f720c09ab175	2026-01-07 04:27:00.232914+00	3.2	11	563136	563136
3853b6d2-1a78-4768-9832-23ee8fb92f28	2026-01-07 04:27:00.745599+00	3.2	11	674708	674708
0802924c-2fd0-44cd-ae7f-9837165d05cc	2026-01-07 04:27:00.794394+00	3.2	11	613137	613137
febd1d11-8c85-4f85-8566-5f485d561b41	2026-01-07 04:27:00.815524+00	3.2	11	425058	425058
c3a3365e-ab81-487a-9a7f-fe4d3e523e74	2026-01-07 04:27:00.903801+00	3.2	11	579240	579240
4223cdfc-5ee9-4226-a498-fdca29858efc	2026-01-07 04:27:51.804523+00	5.6	11	19510	12650
72a5e6ae-0349-4a0a-94c5-8d8365375df8	2026-01-07 04:28:00.061797+00	2.7	11	5579	5579
35873517-3162-46c3-b534-5a84398c231a	2026-01-07 04:28:00.206195+00	2.7	11	756892	756892
7c3280a1-0e6c-4452-9d1d-c937fb7156c8	2026-01-07 04:28:00.675522+00	2.7	11	662727	662727
13f850f8-c35f-46fa-84af-089167fa56b0	2026-01-07 04:28:00.723126+00	2.7	11	628907	628907
7e39140d-69a3-454e-89f0-f3ca212fec60	2026-01-07 04:28:00.732291+00	2.7	11	666382	666382
58548e8b-863b-4137-8f54-f86cf60dd862	2026-01-07 04:28:51.820828+00	5.9	11	18137	7373
638654af-1898-4569-8d81-89a75fe1eefc	2026-01-07 04:29:01.011544+00	2.8	11.1	459944	459944
0b472394-b995-4118-b994-bd743f5aae02	2026-01-07 04:29:01.08237+00	2.8	11.1	455356	455356
5be64e2e-f8c2-434a-9ca9-15d4e04c8223	2026-01-07 04:29:01.115592+00	2.8	11.1	707507	707507
6a5d29d3-dc03-449c-ab93-134636478312	2026-01-07 04:29:01.230611+00	2.8	11.1	673540	673540
58a29756-e6ec-4d99-ab02-f15fe9cc797a	2026-01-07 04:29:51.833313+00	3.5	10.9	23414	30911
1351dfa3-ddf4-4051-bbc8-28e6f2fcc225	2026-01-07 04:30:00.083408+00	3.1	11.1	7032	7032
3e11d771-1365-495f-80cc-38e920e4d894	2026-01-07 04:30:00.186896+00	3.1	11.1	687528	687528
b5b2602a-8a0c-4491-90e9-6984a72f93d5	2026-01-07 04:30:00.885499+00	3.1	11.1	482386	482386
2d6ee218-158b-4ebd-94e9-64219b5a7535	2026-01-07 04:30:01.020722+00	3.1	11.1	559274	559274
54fbe38e-e2b6-490f-a715-a4513118dfaf	2026-01-07 04:30:01.034606+00	3.1	11.1	445690	445690
38231151-311c-403a-8993-f178a1aea5df	2026-01-07 04:30:01.058012+00	3.1	11.1	259869	259869
bb21e2d9-2a4e-41ec-a673-54f0a9a38454	2026-01-07 04:30:01.09013+00	3.1	11.1	711847	711847
188bc83b-db17-4ad7-bc70-bbf8d7846a9b	2026-01-07 04:30:51.82949+00	4.2	11	28375	23806
ec93f59f-381f-42e6-b9c4-e2ea1b5cbda6	2026-01-07 04:31:00.059272+00	2.8	11	7080	7080
a399e9ca-7ac5-4ab9-bb22-5e182d771e46	2026-01-07 04:31:00.227356+00	2.8	11	838733	838733
c996142e-4570-49d6-9b2f-199e7ad48b8b	2026-01-07 04:31:00.855226+00	2.8	11	400455	400455
bbe83346-327d-4e26-841f-83267e2cdf48	2026-01-07 04:31:00.880465+00	2.8	11	737606	737606
6af70039-a407-456a-b559-1b39f3bcd73f	2026-01-07 04:31:00.935231+00	2.8	11	464889	464889
dd22fcfe-9a7b-4531-89bf-378be046b91a	2026-01-07 04:31:00.943016+00	2.8	11	665865	665865
31237bd6-944b-4035-982e-25b1f8d79be8	2026-01-07 04:31:00.979057+00	2.8	11	597196	597196
0de04e05-3604-4e14-9d89-1a0a6356ee49	2026-01-07 04:31:51.877906+00	4	11	223955	102462
a8f9205a-10f9-4cdb-864b-7eaface4343d	2026-01-07 04:32:00.128444+00	3	11	11917	11917
34d3e760-71f8-4524-92a4-0323425f47c5	2026-01-07 04:32:00.318053+00	3	11	806037	806037
843f675c-9500-418a-8e99-ba998b9c7273	2026-01-07 04:32:00.885089+00	3	11	721087	721087
b9b64d68-6111-4696-9c39-3761557eaa0f	2026-01-07 04:32:00.894147+00	3	11	452658	452658
84efceeb-0f03-47fe-831a-32c52d049104	2026-01-07 04:32:00.922309+00	3	11	409607	409607
b28da696-0aef-49cc-b7f5-f4004db2ece0	2026-01-07 04:32:00.970511+00	3	11	510495	510495
ac4ede15-2904-49f1-bc1a-c2a06d355b46	2026-01-07 04:32:00.989021+00	3	11	542066	542066
d5d10c37-9469-4648-bacc-5f5099bea8f4	2026-01-07 04:32:51.877577+00	5.6	11.1	909960	170787
ce66a506-2057-4fe4-a612-04dd1a9f80b7	2026-01-07 04:33:00.131437+00	4.6	11.1	6028	6028
b2c54bd2-b661-40b9-9b17-fe687838f0f5	2026-01-07 04:33:00.25202+00	4.6	11.1	532617	532617
32596346-aed0-412c-98f8-d6d80385cd3d	2026-01-07 04:33:00.870832+00	4.6	11.1	708087	708087
b16a888d-d2f8-45e8-9dd2-600e141b2f8d	2026-01-07 04:33:00.888179+00	4.6	11.1	821354	821354
3a748079-4ca7-4506-a08c-f33ff7fef404	2026-01-07 04:33:00.913897+00	4.6	11.1	800538	800538
43386624-97af-468e-9c0b-122c5c1a2e04	2026-01-07 04:33:00.936677+00	4.6	11.1	643032	643032
1d9bbfdd-8887-4d38-bc33-f4362025df4a	2026-01-07 04:33:00.952273+00	4.6	11.1	650480	650480
68557875-2999-4ba3-8237-e8039b94a438	2026-01-07 04:33:01.091709+00	4.6	11.1	626881	626881
a6289bc5-bcd9-4da7-a85a-481a75b214e9	2026-01-07 04:33:51.893048+00	3.2	11.1	800490	183520
4905282d-7093-4e00-bf96-4ccb92b97b50	2026-01-07 04:34:00.053857+00	3.5	11.1	7246	7246
401d5bdd-7682-4e43-8564-cb31b3b5a3c9	2026-01-07 04:34:00.255052+00	3.5	11.1	358624	358624
c24139da-3b39-476f-9dd4-396783f13af7	2026-01-07 04:34:00.767992+00	3.5	11.1	515811	515811
be605ba3-7ff8-4575-b97c-33659a6e806d	2026-01-07 04:34:00.83239+00	3.5	11.1	550259	550259
b8855b36-80df-48af-bda9-146d4d431df6	2026-01-07 04:34:00.872872+00	3.5	11.1	595371	595371
0e2afc68-05f4-403f-8cef-806cbef8d984	2026-01-07 04:34:00.888751+00	3.5	11.1	373386	373386
2e0058be-5b37-46f4-bf8d-e6e1ca7f0f32	2026-01-07 04:34:00.900219+00	3.5	11.1	342305	342305
707d4927-fe86-4be5-89f9-ed155f4fd77c	2026-01-07 04:34:00.995127+00	3.5	11.1	491944	491944
cad8c869-8cfd-417e-b1a8-8b2cc7596685	2026-01-07 04:34:51.907801+00	4.7	11.1	1342067	256159
d6f1d974-7113-4bac-9d73-a5eaaf18bf98	2026-01-07 04:35:00.048603+00	5.9	11	7099	7099
405b6c1d-7dd8-4bb3-8474-003865204156	2026-01-07 04:35:00.678657+00	5.9	11	673135	673135
e2bbee5b-f8d2-452f-a51c-23673b2c8ff7	2026-01-07 04:35:00.70627+00	5.9	11	565456	565456
7c3a3998-3124-41ab-bfa2-d6f81e77a1a0	2026-01-07 04:35:00.751698+00	5.9	11	615199	615199
53ae510c-49d9-4dab-bc78-d02a51ddf0d8	2026-01-07 04:36:00.735213+00	2.8	11.1	743364	743364
bd11f370-885e-450d-b0a2-be9ae5cdbc8c	2026-01-07 04:37:00.045392+00	4	11.1	7978	7978
500e17ad-5b59-4841-8d21-8a422054262e	2026-01-07 04:37:00.645271+00	4	11.1	682209	682209
a9657513-9d88-4696-b73e-f257fbb7378f	2026-01-07 07:48:09.088566+00	18.5	22.5	174421	174421
2a896dd1-b842-47cd-a590-6ab9128bdeb9	2026-01-07 07:49:58.536415+00	9.7	22.5	499943	499943
cbe44019-1dd1-4a5a-be10-5b71b2b9d9a1	2026-01-07 07:49:59.809341+00	9	22.6	350134	350134
9ef47347-3c50-491b-8bab-12682092b2fb	2026-01-07 07:51:58.358023+00	9	22.5	756610	756610
5335a7ce-4ff3-48d2-87a9-acd1b1418233	2026-01-07 07:52:59.570649+00	9.4	22.5	338926	338926
79771604-0901-45f7-a7eb-dee50e380ed9	2026-01-07 07:53:11.395458+00	15.4	22.6	493902	493902
361795ae-cc9d-4a9a-8ba8-203732db40d7	2026-01-07 07:54:32.298572+00	7.5	22.6	692789	692789
61d89c6d-19f6-48f7-93ca-b031fc3511a9	2026-01-07 07:55:59.642789+00	9.8	22.5	1008598	1008598
08e52b6d-248a-484c-b3ff-3505561c373a	2026-01-07 07:56:09.252514+00	13.5	22.5	278335	278335
ec201f10-ed51-4aa5-b56c-da0e8729901f	2026-01-07 07:56:32.678638+00	9.8	22.3	636322	636322
ca2558d4-59b1-4b7c-b46c-6de0a1dbcd81	2026-01-07 08:02:03.746565+00	7.5	22.3	422148	422148
6c636171-5219-4a7f-a7b7-aced2c20912e	2026-01-07 08:29:56.704519+00	9.9	32.6	211700	211700
e57415ce-95b3-4e84-a97c-9e5af0117ed0	2026-01-07 08:30:56.709172+00	9.4	32.6	135493	135493
580187f8-057d-4884-92bf-6fbe790af886	2026-01-07 08:31:56.730725+00	8.5	32.7	215173	215173
a5f993e6-5c18-4c22-a6e8-6a00a6f96d90	2026-01-07 08:36:56.639042+00	6.8	30.6	300647	300647
ef00c423-8089-4ce6-9fd7-6c120a64ce28	2026-01-07 08:37:56.913425+00	7.6	30.9	376777	376777
0cfd7e58-f6b8-4e44-b204-62d3c6f20497	2026-01-07 09:07:54.686137+00	6.3	25.1	4116	3410
c1368653-5e8d-4891-960f-a3dfcbb5e3fe	2026-01-07 09:47:52.203298+00	4.3	24.5	0	0
914a65af-6994-4959-9185-55d92aeeceb9	2026-01-07 10:05:52.066335+00	27.1	30.4	216864	216864
0c12db7e-47b2-4b6d-af76-3265d559be9e	2026-01-07 10:28:12.930162+00	5	26.6	5034	3624
aab63f27-2a83-4e59-b084-6e13365d0227	2026-01-07 10:45:52.13004+00	7.8	31.3	2861074	2861074
83a38da5-0fba-4dfa-9794-4d4f7e46af43	2026-01-07 11:02:13.270134+00	5.3	26.6	6189	4168
30a43dbe-2137-40e0-80ae-1235502c3faf	2026-01-07 11:21:46.842738+00	22.7	32	96599	96599
9b55c81e-fed0-473f-8725-9f1f4fb0cdd1	2026-01-07 11:21:52.071468+00	16.2	32	103403	103403
c92249ab-c522-40a1-a371-e2e76f9ec8d6	2026-01-07 11:40:51.91232+00	26	34.5	1194566	1194566
9c91fcad-49ea-4b2f-8705-cefe8044ad1d	2026-01-07 11:41:44.80135+00	36.4	33.3	2126000	2126000
56c15575-2e4a-467b-982c-4c8731392bfc	2026-01-07 11:41:51.943455+00	37.6	33.2	824745	824745
d745845d-ebb6-4878-80bd-69cb77657ae5	2026-01-07 11:42:44.824607+00	35.9	33.5	629559	629559
d00eac7c-a6a9-42c8-924f-c93ee0a9bdb8	2026-01-07 11:42:51.934726+00	34.6	33.5	365358	365358
ac072e46-59a1-43b4-a1ca-37bf39b205d5	2026-01-07 04:35:00.769767+00	5.9	11	654895	654895
ad2ff35a-b17a-4375-9a27-17ce1a0a6a33	2026-01-07 04:36:00.69524+00	2.8	11.1	723334	723334
6aaf9a75-f8ef-4d4e-96e8-24fed4d12fd6	2026-01-07 04:37:00.179716+00	4	11.1	619627	619627
e46e6c96-6d0b-4920-b433-f0dcbab768fd	2026-01-07 04:37:00.639672+00	4	11.1	521474	521474
a2c15027-d70c-4afd-adf9-682878882932	2026-01-07 07:48:09.090338+00	18.5	22.5	543109	543109
6770a624-9bf3-41da-9f79-84bed772aabc	2026-01-07 07:48:58.465393+00	9.9	22.5	564965	564965
fd87bbfe-c126-4ad0-bff0-32ced1f647a0	2026-01-07 07:48:59.777657+00	8.5	22.5	261850	261850
b248ad7c-9ce1-48ca-bced-c2fe3fa86b00	2026-01-07 07:49:09.371793+00	13.9	22.6	645845	645845
70a59f53-153a-4d37-8210-aef4637ee4bd	2026-01-07 07:49:59.964625+00	9	22.6	338132	338132
a4dce374-0a24-4192-afa6-2e6db5e248e5	2026-01-07 07:50:12.027806+00	24.3	22.7	878321	878321
104d07a4-28f1-450d-985a-6813ac218334	2026-01-07 07:51:59.711724+00	9.6	22.5	284957	284957
3a1be2b7-b3f8-4027-aeae-93983858572d	2026-01-07 07:52:10.231908+00	17.9	22.5	1311036	1311036
de9e5bbc-7d71-48d6-9cf1-6bac1d4c2b87	2026-01-07 07:52:32.31261+00	9.4	22.5	779644	779644
d2e4a94e-1dd7-44f5-b5ec-ad4ddc50e17e	2026-01-07 07:52:59.62792+00	9.4	22.5	248095	248095
fca7268a-76ba-42de-892e-dc47d021e885	2026-01-07 07:53:09.110009+00	6.4	22.5	453974	453974
39aa67a4-4d21-497b-ad8c-d78d7ba1e492	2026-01-07 07:53:58.528231+00	10.9	22.6	629398	629398
165e9b49-c8d9-498b-bef3-ec78cca171db	2026-01-07 07:54:09.512034+00	7.4	22.5	744637	744637
a8a4fe61-d3cb-448f-924f-b11477cbc215	2026-01-07 07:54:59.585589+00	8	22.5	285441	285441
c1fbff6a-5ddb-49ae-92f2-841db40f1e82	2026-01-07 07:55:58.471645+00	10.5	22.5	701974	701974
8e27bfd2-b0e1-48c9-8b64-1f55ef0aaa81	2026-01-07 07:56:32.776116+00	9.8	22.3	779518	779518
6be8ce9e-fee2-46a7-8362-2d412039a6bb	2026-01-07 07:56:41.971605+00	19	22.3	574005	574005
7de54f15-f85a-4a26-a42e-c11a137e15ae	2026-01-07 07:58:03.746144+00	11.5	22.7	997218	997218
7f24503a-feea-4339-b35e-5750515cdf9a	2026-01-07 08:30:54.392148+00	9.9	32.5	4671	2795
b5baf132-11cf-4fc1-948b-437908353e50	2026-01-07 09:08:54.687768+00	4.9	25	3534	2687
27e36b86-76eb-44b0-98d1-9c6c93f4efe7	2026-01-07 09:47:52.204032+00	4.3	24.5	98357	98357
5d4b532f-fee3-43ad-a818-04be49e19e56	2026-01-07 10:06:12.585505+00	19.3	31.5	36308	85634
487a6907-0131-42a2-b6cf-f1163243f280	2026-01-07 10:28:52.117209+00	10.2	26.4	98491	98491
36694bc7-df96-4edf-9f4f-9fdf08d073c9	2026-01-07 10:45:52.147226+00	7.8	31.3	1429401	1429401
688f5cc4-985c-4eb7-a6f3-0c50b2ac304d	2026-01-07 11:02:52.055038+00	7.5	26.7	65576	65576
52efdfca-a6cd-47e7-84cf-8c4ba7e34ab7	2026-01-07 11:22:13.574681+00	10.3	32.3	9899	30669
8353411c-58b4-4185-a9c6-962261f49644	2026-01-07 11:41:13.892968+00	33.7	33.1	2925577	1290637
091478dc-b9e2-4347-a162-42915e2bc867	2026-01-07 04:35:00.77772+00	5.9	11	577535	577535
e99be1d1-d955-4601-8367-423edc8944d7	2026-01-07 04:36:00.764614+00	2.8	11.1	716298	716298
20ff5c99-8230-4565-ad71-c89a35d8a90c	2026-01-07 04:37:00.596886+00	4	11.1	922760	922760
f76f752f-0436-4951-813d-f4e0fecf70bc	2026-01-07 04:37:00.780957+00	4	11.1	691561	691561
ce1bf9a7-151d-406d-a0a7-392738f4fe56	2026-01-07 07:48:54.017292+00	12.7	22.6	76018	35897
fbed12a6-2cb1-4e5a-9dfa-ad8271485ebc	2026-01-07 08:31:54.401429+00	9.3	32.7	4558	2837
79f22825-ef55-42f2-94d9-a95afb95ebbe	2026-01-07 09:09:54.738674+00	13.1	25	3447	3749
e074badb-7003-4663-939b-f86f7570db38	2026-01-07 09:48:12.368789+00	11.1	24.5	3005	2122
a48ea06f-7796-40d8-85ae-41060f9beeb6	2026-01-07 10:06:52.059798+00	12.5	30.4	144973	144973
467a7434-9184-4c8c-9d4a-793e3aabbadc	2026-01-07 10:28:52.117263+00	10.2	26.4	106257	106257
5812834a-a971-479e-b523-f238ce8bea6a	2026-01-07 10:46:13.178928+00	20.8	31.4	1243863	49725
7fec9392-3de3-4aab-aecd-65c81439b02e	2026-01-07 11:02:52.055562+00	7.5	26.7	47377	47377
65166916-4a3f-439e-888b-bf5277ed7d86	2026-01-07 11:22:46.852946+00	20.5	32.1	18765	18765
6d9c9932-7f35-43de-b443-00922da84e19	2026-01-07 11:42:13.860121+00	34.3	33.5	4890749	112615
46ed16c5-306c-4fc8-b2f1-f78dd4d4ebdf	2026-01-07 04:35:00.866785+00	5.9	11	767048	767048
879b8d1d-3008-4518-94d2-a017a1f64f40	2026-01-07 04:35:51.909729+00	4.4	11	638838	128082
6ac9dc64-4185-4613-8920-3f95054274a7	2026-01-07 04:36:00.190459+00	2.8	11.1	652036	652036
12b91279-57de-41a9-a8e4-673f16121573	2026-01-07 04:36:00.681636+00	2.8	11.1	632779	632779
95adf2fa-3134-4886-b819-a6d5d75e4ff8	2026-01-07 04:36:00.869239+00	2.8	11.1	443816	443816
96b1860e-8cce-4fba-8ec6-95f94bfd7a7d	2026-01-07 04:37:00.628874+00	4	11.1	632688	632688
9ac8f8f3-f20d-4d85-a1fb-6ca70280926f	2026-01-07 07:49:54.023561+00	13.6	22.5	93362	39822
6b901af8-cf55-4406-b4f6-fb22d0aff660	2026-01-07 08:32:54.411599+00	9.9	32.8	4552	2829
590f5660-4528-4a48-8058-b15620bd6b2e	2026-01-07 09:10:54.705771+00	5	25	2702	5122
7fe16b65-0d35-4adb-910d-f822617e95fc	2026-01-07 09:48:52.1476+00	4.6	24.5	96855	96855
148fb164-f84a-4578-b248-36158884bf9a	2026-01-07 10:06:52.064799+00	12.5	30.4	0	0
ae0804a7-e251-4f01-bb71-43f2a0497686	2026-01-07 10:29:12.89937+00	10.4	26.4	5382	3543
9482b89a-a611-4de0-83c0-9f568bc77ff3	2026-01-07 10:46:52.098834+00	20.4	31.4	927495	927495
5080f43c-ec34-4d27-abeb-c47690917208	2026-01-07 11:03:13.294394+00	5	26.6	5943	4382
841c358b-3e34-47ee-96de-538660d4603c	2026-01-07 11:22:52.089289+00	26.8	32.2	90401	90401
cb72df2f-5611-4f3c-8505-c8721606742d	2026-01-07 11:43:13.866801+00	39.2	34.6	20488	658884
40b435b7-1a92-4c5e-81f7-c239ffc72837	2026-01-07 04:36:00.089718+00	2.8	11.1	7991	7991
f7165952-ae70-4876-b2a6-f7cfe9380af6	2026-01-07 04:36:00.702705+00	2.8	11.1	498678	498678
6d4395b8-7b33-44dd-b3af-7b0f8aad4139	2026-01-07 04:36:00.714454+00	2.8	11.1	491777	491777
2dee9542-b508-49bb-98f2-748624c424a9	2026-01-07 04:36:51.929063+00	4.1	11	880588	160105
2d7255a6-a177-489a-a260-f1e41ba7566c	2026-01-07 04:37:00.678679+00	4	11.1	585832	585832
a92e257f-531c-483b-a38d-91a553c198bf	2026-01-07 04:37:00.699272+00	4	11.1	729947	729947
95b69f57-9490-4b6f-90ba-54425d752c5b	2026-01-07 04:37:51.946018+00	4.7	11.2	744863	134979
849c3d84-30bf-4223-b6a3-8c7fb52d6639	2026-01-07 04:38:00.171047+00	3	11.1	12687	12687
6313ae0e-c714-466a-abe7-01049f98cd9b	2026-01-07 04:38:00.288726+00	3	11.1	594245	594245
ab9ce552-0222-4fb4-95c1-4554eaa60832	2026-01-07 04:38:01.141627+00	3	11.1	451277	451277
83d0c714-1a32-4b45-bd6f-071ee68703f2	2026-01-07 04:38:01.171039+00	3	11.1	465590	465590
b92d7bb6-7e69-4da2-8353-b823d7d04b15	2026-01-07 04:38:01.189185+00	3	11.1	562192	562192
67f62f2e-228f-44d3-bea7-a310b0d252ca	2026-01-07 04:38:01.19671+00	3	11.1	413990	413990
eb7f8263-b6ee-4421-8069-1145a52a7384	2026-01-07 04:38:01.228412+00	3	11.1	315121	315121
a808d782-1da9-4a90-a29a-2ec0eeca8b72	2026-01-07 04:38:01.246066+00	3	11.1	279734	279734
2a1f1e2c-8dac-4daf-a5ab-2a060f299589	2026-01-07 04:38:01.333632+00	3	11.1	624274	624274
39d24364-e41b-4429-8f31-358394f19316	2026-01-07 04:38:51.965859+00	4.5	11	418709	86596
e0821523-7d10-4fd9-890f-c4cd360e6722	2026-01-07 04:39:00.037789+00	5.9	11	8953	8953
828c70e4-c4cc-474d-b410-204676afd322	2026-01-07 04:39:00.194389+00	5.9	11	528856	528856
cd6c3258-f9ed-41a7-9a1c-eac4028c62e6	2026-01-07 04:39:01.006294+00	5.9	11	68148	68148
4147aa69-7425-4c48-9538-e3debef85ba8	2026-01-07 04:39:01.010669+00	5.9	11	281184	281184
87bdff82-5823-479d-8ca2-6b2f658a7a5d	2026-01-07 04:39:01.020267+00	5.9	11	189842	189842
57adadfb-4730-4d84-ae52-b21644af430d	2026-01-07 04:39:01.033217+00	5.9	11	275954	275954
60d9d00d-b99a-46ab-970b-f73f2c915a98	2026-01-07 04:39:01.041383+00	5.9	11	513294	513294
b8d7cd2c-569c-4c5b-92b9-7cc83dbe0834	2026-01-07 04:39:01.058413+00	5.9	11	317505	317505
4b71995e-f350-4636-a335-e6b0b49dd2ce	2026-01-07 04:39:01.150279+00	5.9	11	598678	598678
b573f85b-fd9f-42e6-be11-40f585145d41	2026-01-07 04:39:51.966374+00	3.1	11	330703	74680
ed077b3b-792e-410a-8333-bf91c5a8ccb2	2026-01-07 04:40:00.032522+00	3.5	11	8615	8615
2dfb3cfb-1bda-4044-9b86-0883f8ab1718	2026-01-07 04:40:00.157735+00	3.5	11	737476	737476
c3336686-949a-49a8-ac9b-a6821024dd70	2026-01-07 04:40:00.723792+00	3.5	11	363628	363628
9ccdd503-4d11-4f2f-a202-418e870bdb91	2026-01-07 04:40:00.738958+00	3.5	11	887174	887174
2fe59821-dd3f-4a97-8cd0-bc6296ab2b31	2026-01-07 04:40:00.752597+00	3.5	11	537783	537783
c36e136b-3f5f-462a-8d58-a46e5d08fbbf	2026-01-07 04:40:00.76656+00	3.5	11	707486	707486
3552d109-5e8a-4e8d-bc61-506ac85a0039	2026-01-07 04:40:00.776533+00	3.5	11	559650	559650
e77d6358-a18d-4936-8060-78288b6b8e6e	2026-01-07 04:40:00.800918+00	3.5	11	441047	441047
a902ec4a-a9cf-431c-9d87-4d4b69cb32a4	2026-01-07 04:40:00.881976+00	3.5	11	698430	698430
db15bdee-e576-4043-9ffb-341b6e7f5ba9	2026-01-07 04:40:51.960813+00	6.1	11	526889	100122
327afbab-c183-4f33-ba98-e2e6fcf82f8a	2026-01-07 04:41:00.137012+00	3.1	11	15403	15403
31a8807e-1f27-4c8a-aa5c-bbd2be7be363	2026-01-07 04:41:00.250412+00	3.1	11	719608	719608
18041d7a-8ce0-42a2-bad5-ed8f38e7818e	2026-01-07 04:41:00.720392+00	3.1	11	409284	409284
fa31b7c4-e996-4042-8443-4d5804671dfa	2026-01-07 04:41:00.730628+00	3.1	11	586673	586673
70d6530d-e56b-44df-a4c2-fa3e9065d5de	2026-01-07 04:41:00.738664+00	3.1	11	622652	622652
d16fdccc-0ec1-4b17-bb74-e7cb7130853f	2026-01-07 04:41:00.758818+00	3.1	11	705916	705916
ccd42d01-8165-4d5d-96c9-06a0de8f010b	2026-01-07 04:41:00.805161+00	3.1	11	789487	789487
e8f2f6b4-fcef-4ff5-a8ec-39302b6e672d	2026-01-07 04:41:00.814124+00	3.1	11	682635	682635
4520e2d6-4758-4031-afbb-0ee23ff13e6e	2026-01-07 04:41:00.894258+00	3.1	11	575029	575029
76da777e-d245-4975-a500-6fd87102e5b4	2026-01-07 04:41:51.994774+00	5.8	11	298945	64063
4ee07350-1acb-4aaa-9b48-2451872e51aa	2026-01-07 04:42:00.052782+00	2.9	11.1	10447	10447
4a9b37ce-ca30-4b53-bb52-98bde2aba3ca	2026-01-07 04:42:00.199753+00	2.9	11.1	752317	752317
633f7905-0869-4d48-9611-a5988b11a6c6	2026-01-07 04:42:00.738088+00	2.9	11.1	534470	534470
3e00a119-26a8-454c-88f2-f25677134184	2026-01-07 04:42:00.75516+00	2.9	11.1	544911	544911
f7a099a2-edaf-4eb4-bfaa-748259dea17e	2026-01-07 04:42:00.766087+00	2.9	11.1	213038	213038
462e9a09-d4e7-47a4-a048-3e12265949fd	2026-01-07 04:42:00.788008+00	2.9	11.1	470129	470129
e6e70599-2683-4806-bb8f-f7877de9ef87	2026-01-07 04:42:00.801666+00	2.9	11.1	382833	382833
8e43b0ae-364a-4a9f-81d9-59e6595039c2	2026-01-07 04:42:00.83221+00	2.9	11.1	454870	454870
8802dedd-76e8-44be-8169-f034cd4cdb57	2026-01-07 04:42:00.983451+00	2.9	11.1	541641	541641
69db599c-1248-4118-b016-3f78d408b5b8	2026-01-07 04:42:52.010361+00	5.9	11.1	270101	59349
c5d4c9d6-5ff5-4d45-b284-8b255f0f5696	2026-01-07 04:43:00.041598+00	5.9	11.1	9552	9552
8b073223-9e78-4058-b975-0a0a719c17b4	2026-01-07 04:43:00.278106+00	5.9	11.1	258148	258148
6ab15be3-ec86-4713-9539-842c58e3d386	2026-01-07 04:43:01.009041+00	5.9	11.1	485275	485275
99add4fc-b81c-4e1e-85d0-ae5fa00b31fb	2026-01-07 04:43:01.054472+00	5.9	11.1	668762	668762
b3d8a01d-4a5d-4096-a8b1-4df2c1983aba	2026-01-07 04:43:01.058429+00	5.9	11.1	499075	499075
7942a781-b68d-4247-bd49-9f23c1a27dac	2026-01-07 04:43:01.06625+00	5.9	11.1	557346	557346
d9477bd0-7a3c-459a-936e-252e7d6dcbd3	2026-01-07 04:43:01.077227+00	5.9	11.1	481203	481203
85c53827-f7f3-4dac-ae54-624e6af41108	2026-01-07 04:43:01.087162+00	5.9	11.1	280173	280173
cca87471-cb8b-430f-b0aa-e25e8fde820b	2026-01-07 04:43:01.203482+00	5.9	11.1	561879	561879
bb4e25cc-1b3d-41a9-a8e4-20342c76ea03	2026-01-07 04:43:52.029781+00	4	11	411476	84924
334fcfec-2069-4776-a6d7-d166e9f85834	2026-01-07 04:44:00.102706+00	3.2	11.1	10446	10446
e2dabe98-d3ea-4c0e-a3db-5550860ed5a5	2026-01-07 04:44:00.266473+00	3.2	11.1	493305	493305
f393fe57-a189-43ce-ac41-0578305ad775	2026-01-07 04:44:00.719953+00	3.2	11.1	616849	616849
d99a1ffa-89d8-4a87-85d3-c05ccd69f0f0	2026-01-07 04:44:00.741206+00	3.2	11.1	626772	626772
2293682c-8d81-4404-b55c-e6b70dc193f5	2026-01-07 04:44:00.752673+00	3.2	11.1	639952	639952
c12abdda-a8d6-4ff3-971c-1688c71e871b	2026-01-07 04:44:00.762094+00	3.2	11.1	820204	820204
ef5bfd24-3544-4d65-9c92-0cd08f0f6ce9	2026-01-07 04:44:00.770293+00	3.2	11.1	631648	631648
62551ccc-c0f0-46b3-9bfa-46a90997a9a8	2026-01-07 04:44:00.78661+00	3.2	11.1	663416	663416
26b2302f-30c2-4a69-b26b-cca01bf33580	2026-01-07 04:44:00.874662+00	3.2	11.1	640246	640246
641b1a7e-30e3-441c-ab83-7e02f3ae7677	2026-01-07 04:44:52.079885+00	5.1	11.1	439390	84146
f3b915df-cef3-4a4d-8242-cf084f5ed5ea	2026-01-07 04:45:00.049483+00	5.5	11.1	9635	9635
fa3ab227-494d-4224-90ca-9babed50d1ec	2026-01-07 04:45:00.151542+00	5.5	11.1	660762	660762
506c6531-01fc-4d4f-8d19-08825f2bd842	2026-01-07 04:45:00.607736+00	5.5	11.1	487354	487354
41519050-6b53-4cf6-a41d-fc859b4362b0	2026-01-07 04:45:00.614384+00	5.5	11.1	618667	618667
0767c50b-d504-4ee7-8ed2-845ebe8a06c5	2026-01-07 04:45:00.63951+00	5.5	11.1	400753	400753
49b2683f-ce25-4754-ab4f-0dc638c5145c	2026-01-07 04:45:00.671054+00	5.5	11.1	565887	565887
19027e7b-628b-4c9b-b7ae-42c972288494	2026-01-07 04:45:00.710649+00	5.5	11.1	827411	827411
17b82004-c8f7-416f-8211-d51081550d74	2026-01-07 04:45:00.743584+00	5.5	11.1	671008	671008
81270670-9b8d-403d-87a0-418851ff760b	2026-01-07 04:45:00.890116+00	5.5	11.1	476013	476013
fc752c7d-fe40-445a-a272-5b5bc504b44e	2026-01-07 04:45:52.059114+00	5.6	11	201422	39908
e5e68ee8-660b-402c-8fea-4a7cabe8832f	2026-01-07 04:46:00.102339+00	2.5	11.1	10421	10421
212ee917-d9f6-420f-9e31-b3f21cfe11b1	2026-01-07 04:46:00.219776+00	2.5	11.1	684666	684666
43c35c37-4e65-4ada-898c-d13ffc6ccdf8	2026-01-07 04:46:00.861139+00	2.5	11.1	120422	120422
022a8931-1af0-49a2-a49a-b5aa3cc9ea86	2026-01-07 04:46:00.883073+00	2.5	11.1	200305	200305
bfb48766-965d-44b4-846f-98f8cddae5da	2026-01-07 04:46:00.89466+00	2.5	11.1	361057	361057
819f5d83-0121-4df1-8903-fad15471923e	2026-01-07 04:46:00.9296+00	2.5	11.1	382104	382104
950c5b14-63e1-465c-9a83-9949e8a6bf67	2026-01-07 04:46:00.971202+00	2.5	11.1	384578	384578
6b40d992-38c4-437a-bf93-3725a7726cc6	2026-01-07 04:46:00.980958+00	2.5	11.1	511683	511683
dbbfe5c3-0bdd-4873-8310-a89542bf506a	2026-01-07 04:46:01.112957+00	2.5	11.1	410852	410852
5acfebc2-eedc-454f-8e47-4f416379bec5	2026-01-07 04:46:52.111462+00	2.6	11	402324	125040
66011344-54b0-407c-9d57-647b467227a2	2026-01-07 04:47:00.081063+00	3.1	11.2	9291	9291
0b65be52-06b8-4586-b5f8-e9652ef7d076	2026-01-07 04:47:00.221381+00	3.1	11.2	681071	681071
97ad307c-fafd-44a4-9519-e861089f51af	2026-01-07 04:47:00.679566+00	3.1	11.2	587974	587974
cc20fcf2-6218-4a6f-8d4f-f343f7ac1fc1	2026-01-07 04:48:01.06707+00	5.7	11	339176	339176
af244ec5-8f2e-4066-abd5-53f62002ac7c	2026-01-07 04:49:00.690905+00	3.2	11	660984	660984
50c22674-d750-47e4-8793-738795edd071	2026-01-07 04:49:00.889598+00	3.2	11	539916	539916
da937099-8c01-4ce9-82d1-dbff81c842fd	2026-01-07 04:50:00.593697+00	3	11	658971	658971
12e2aef5-8eba-462d-9fe7-f288044a796c	2026-01-07 04:50:01.02562+00	3	11	680422	680422
0319344a-6591-43d6-8650-e3eaffa70553	2026-01-07 04:51:00.988031+00	4	11.1	457994	457994
a47d72db-c94b-48f5-84c5-e12d790f86c7	2026-01-07 04:52:01.322294+00	3.2	11.2	403122	403122
143b4b77-fb56-4f9f-8678-85d48151b43b	2026-01-07 04:53:00.16496+00	6.2	11.1	13363	13363
eca8aff0-06cb-447c-8920-a1b5ca55bc88	2026-01-07 04:53:01.287808+00	6.2	11.1	530181	530181
48614bec-e467-40cd-b451-d1ca1cb5df15	2026-01-07 04:54:00.705984+00	2.7	11.1	617556	617556
dfc24213-0154-47aa-9cb3-94349eb0fe52	2026-01-07 04:55:00.048906+00	3.4	11.1	9987	9987
588e4e2e-ce1d-4d3d-8553-aad02fe3c61e	2026-01-07 04:55:01.074622+00	3.4	11.1	105184	105184
13bbfa73-2512-4969-b3b3-b0c75d618f90	2026-01-07 04:56:00.707159+00	3.2	11	578987	578987
851460f6-20e4-422b-9b27-407a740f95ed	2026-01-07 04:56:00.938316+00	3.2	11	463348	463348
9fcbe613-f02d-4471-af56-30a6e022087b	2026-01-07 07:50:54.03068+00	9.1	22.5	82868	37116
c638ecb3-568d-415f-b487-30d80056edaa	2026-01-07 08:32:56.722738+00	9.7	32.8	200153	200153
d91913e7-4e79-47a7-8fbf-92b314197473	2026-01-07 08:35:56.72097+00	6.8	20.9	254798	254798
b80411f1-94de-4912-ac45-136eff9de35f	2026-01-07 09:11:54.708423+00	4.8	25.1	8794	5923
9882ef99-5f5f-41ec-a976-faedc3ffb449	2026-01-07 09:48:52.153562+00	4.6	24.5	61685	61685
ae448b13-f539-46e1-9bbb-d699e39115f2	2026-01-07 10:07:12.608046+00	0	30.4	3374	2031
42a2942f-e441-4de3-a789-61b486bcd015	2026-01-07 10:29:52.176993+00	10.4	27.3	82127	82127
1073af9c-15db-4669-98a7-c92c23eb000d	2026-01-07 10:46:52.098612+00	20.4	31.4	694514	694514
f0d98f94-18ba-43c4-8107-385068632962	2026-01-07 11:03:52.064416+00	6	27.7	111680	111680
df2f1275-e479-45cd-ad25-85cd7aef8abb	2026-01-07 11:23:13.580093+00	23.9	32.4	10708	30219
6b30a119-615b-4da0-a218-6ccdc9ef99dd	2026-01-07 12:01:52.136003+00	62.1	34.9	1537689	1537689
68e2b966-f3ba-438e-807c-9a788936383f	2026-01-07 12:02:52.109741+00	53.1	33.6	3001248	3001248
4dead05d-1c79-44ab-b670-471c7b785483	2026-01-07 12:31:51.98547+00	21	21.6	126700	126700
6da21589-2cd7-497d-991a-6a39ffea90b1	2026-01-07 04:47:00.648618+00	3.1	11.2	449321	449321
4bcef4ed-32b5-44a8-a834-025347d71a4d	2026-01-07 04:47:00.81499+00	3.1	11.2	642715	642715
1e61866f-d8ea-4ed7-a56e-52dca8c52748	2026-01-07 04:48:00.965633+00	5.7	11	534507	534507
4112261c-dfc9-4064-bb80-75e5c33bc40a	2026-01-07 04:48:01.181107+00	5.7	11	570176	570176
796bcab2-68b5-4c06-a855-4de026516b3d	2026-01-07 04:49:00.762293+00	3.2	11	585273	585273
1e2a90b1-f930-43b9-9889-e647ea65741d	2026-01-07 04:50:00.729924+00	3	11	576725	576725
d42d9ac1-9fea-4aab-824d-277d66343f12	2026-01-07 04:51:00.915161+00	4	11.1	411085	411085
b43e012f-2d93-461d-93e7-542b99b2a6a8	2026-01-07 04:51:01.115963+00	4	11.1	501817	501817
8dd55955-cbe0-4cc6-87b2-13d872aff600	2026-01-07 04:52:00.191116+00	3.2	11.2	9613	9613
1ca86fd1-7bc9-4a4f-a981-d5ced746bd77	2026-01-07 04:52:01.332723+00	3.2	11.2	398394	398394
ea601fa2-321f-4ad6-a616-aced9fe38848	2026-01-07 04:53:01.323492+00	6.2	11.1	538032	538032
c6acc028-52cc-4ea0-bc71-22fa91d792ad	2026-01-07 04:54:00.658629+00	2.7	11.1	608528	608528
7ead647e-04b5-4548-8b3d-4f4afdbe2667	2026-01-07 04:55:01.06683+00	3.4	11.1	564338	564338
bcddf7d2-73d2-4bb1-8e98-412992743a7f	2026-01-07 04:56:00.752528+00	3.2	11	276790	276790
bc2f9617-5bf9-4812-85ae-8e0560925629	2026-01-07 04:57:00.612317+00	2.8	11.1	534323	534323
79e41287-86a7-4e48-8fb1-0bd98e3747ec	2026-01-07 04:57:00.730715+00	2.8	11.1	743845	743845
56530df8-be23-439f-a1af-14f24e018b00	2026-01-07 04:58:00.001531+00	3.9	11.2	8965	8965
cb47c731-a967-45ec-9768-690ebdd536b6	2026-01-07 04:58:00.764138+00	3.9	11.2	525012	525012
61a0d4f3-0921-457b-a0cf-c70f5be9e18b	2026-01-07 07:51:53.996708+00	16	22.5	71815	36327
a091f971-0d55-4e93-8392-9fbbc29788f0	2026-01-07 08:33:54.423298+00	9.8	31.2	4684	2775
f24952d9-4579-4803-9f7a-7829af829eb7	2026-01-07 09:12:54.716223+00	7.3	26	1404	1374
a3182079-2a73-4949-af41-b98216908c17	2026-01-07 09:49:12.346387+00	4.6	24.6	3150	1968
9b70f688-90b0-4fbc-b87a-2caa06e6d973	2026-01-07 10:07:45.626562+00	4.8	30.4	108907	108907
16972446-99d5-4fed-9545-7e249cbe96c8	2026-01-07 10:07:55.090518+00	14.4	30.4	190817	190817
b997180f-6c02-4c29-93fd-a56a1d58ba1d	2026-01-07 10:29:52.259395+00	10.4	27.3	0	0
bc8f3f32-646a-46f6-b83a-87c65c2ae3f2	2026-01-07 10:47:13.159299+00	8	31.5	1267078	50468
6681f652-bd79-48a9-84ed-b300a5396eb4	2026-01-07 11:03:52.066178+00	6	27.7	72577	72577
1e6d6f04-7688-4e41-b9aa-4355cbfdc2f0	2026-01-07 11:23:46.88432+00	12.9	31.9	5014	5014
6c3e4eaf-997e-4242-893a-b8ae8e5240dd	2026-01-07 12:01:52.145619+00	62.1	34.9	490128	490128
5da1d1c4-9abc-42a5-bf00-e1397ad927e1	2026-01-07 12:02:10.160219+00	60.8	35.4	1674483	1674483
edfdec30-c087-4b5f-a27f-c2a398e2b7e5	2026-01-07 12:02:29.088236+00	52.5	33.6	4633285	4633285
c0e87a79-4cb1-4fdc-875f-55fb7f63cd84	2026-01-07 12:02:52.108977+00	53.1	33.6	-1566259	-1566259
befc637a-6b1c-465c-a9de-91e841d7620f	2026-01-07 12:03:12.344252+00	50.6	34.7	739207	739207
733f040c-3f90-470f-b00f-c4fb005f8253	2026-01-07 12:31:51.994191+00	21	21.6	474743	474743
e853fb82-2c1f-4aaf-858f-998c0d87af44	2026-01-07 04:47:00.648635+00	3.1	11.2	641419	641419
5e35d613-00ec-40f6-8c9e-01359b487ac2	2026-01-07 04:48:00.270063+00	5.7	11	425502	425502
8cc19f8a-4567-44a1-a440-e4d3953c4df5	2026-01-07 04:48:01.022591+00	5.7	11	599291	599291
f36d2aac-c8e8-4434-bf69-c23a60950184	2026-01-07 04:49:00.210472+00	3.2	11	661629	661629
b5c2b229-4a63-409b-a221-91e5f66c7b11	2026-01-07 04:49:00.799308+00	3.2	11	598826	598826
35fa1509-892c-4140-a91e-095020c3d502	2026-01-07 04:50:00.078952+00	3	11	9242	9242
ced1a4ef-8e40-44d4-a4fc-7895227ad806	2026-01-07 04:50:00.683876+00	3	11	671406	671406
7698622e-d93e-40fb-a73c-da0e5e609e7c	2026-01-07 04:51:00.005145+00	4	11.1	8205	8205
2b2b48a4-824e-4bbd-812b-151c089b21b9	2026-01-07 04:51:00.967734+00	4	11.1	478078	478078
156bc1fe-2b64-41b8-8ef4-8bfc90083e27	2026-01-07 04:52:00.49832+00	3.2	11.2	488426	488426
fa50222f-9f40-454f-a2cf-2412fbe7e890	2026-01-07 04:52:01.267632+00	3.2	11.2	593594	593594
ab13b5bf-7759-4a9e-8eed-333e1e41adf9	2026-01-07 04:53:01.315019+00	6.2	11.1	416347	416347
f579a248-e84f-4100-8ba1-afa311f41452	2026-01-07 04:54:00.141047+00	2.7	11.1	777829	777829
4ffe392b-2168-4ee0-8d41-7e21ab49906b	2026-01-07 04:54:00.635098+00	2.7	11.1	625367	625367
41bac211-19eb-4bc2-a654-16a096586157	2026-01-07 04:54:00.83872+00	2.7	11.1	597017	597017
9d73741d-1cbb-4652-be93-0b6cd9abbfd4	2026-01-07 04:55:01.122544+00	3.4	11.1	544451	544451
54bbf219-fae0-4932-a3a2-27addf9118dc	2026-01-07 04:56:00.069957+00	3.2	11	14641	14641
8fba314b-b319-426b-a61f-11d542021f39	2026-01-07 04:56:00.759053+00	3.2	11	474318	474318
82416217-4832-4fe1-924c-cf7a41d9b171	2026-01-07 07:52:54.008954+00	12.1	22.5	80574	37244
5a3c707a-1bd4-40f8-bb5a-71917d5d70b5	2026-01-07 08:33:56.707421+00	9.2	31.2	153967	153967
d03e7e15-af8e-4436-a36b-774039f65ffc	2026-01-07 08:34:56.718459+00	6.4	21	233238	233238
d099ef12-cac9-41c9-a76a-42812b34e9cc	2026-01-07 09:13:54.763773+00	27.5	28.5	5062	27536
91a87fa0-bbaa-4ef4-add0-eb8f9647df94	2026-01-07 09:49:52.217142+00	4.5	24.5	45215	45215
74f5bb1e-958e-4986-9366-23424cbc3b0c	2026-01-07 10:07:52.060744+00	17.7	30.5	143622	143622
dbc61ca4-3c55-42bd-a14a-b9b5277d9347	2026-01-07 10:30:12.902569+00	10.2	27.3	11236	4408
e3693e0e-5e04-46ed-a544-4d3b19d78bfd	2026-01-07 10:47:52.108263+00	16.9	31.6	915920	915920
d1ee4fef-6db4-4363-acdb-4414bfee0f3a	2026-01-07 11:04:13.312295+00	13	29.1	907238	175112
0f4dfd80-5805-4215-97f2-9d6c808a1645	2026-01-07 11:23:52.03746+00	21.4	31.9	118621	118621
4a5db2c5-bc6b-484b-9010-fca1bedd39ec	2026-01-07 12:03:52.120458+00	47.8	34.6	6129085	6129085
3fda208d-dfea-4c97-8d64-27cbd84670d2	2026-01-07 12:32:48.441339+00	34.8	24.2	800505	800505
f951d54a-ecbf-40aa-b6de-48b716c09d3a	2026-01-07 12:32:51.972367+00	23.8	24.1	370825	370825
b958ed88-dfc2-43c7-83cd-0bca53dda93e	2026-01-07 12:33:25.341295+00	24.5	21.6	762155	762155
212c44b7-67b0-4691-967a-2b1a959d0623	2026-01-07 12:33:51.977611+00	41.8	21.4	529616	529616
a6ff6490-969d-4943-850b-05548c01b583	2026-01-07 12:34:25.210607+00	39.7	21.4	1015081	1015081
78bd1d21-08a6-4ab4-a046-d8cc357c8627	2026-01-07 12:34:51.956905+00	37.5	22.9	4311809	4311809
eb8ed5e2-0c78-40b1-b629-bef557fa84c6	2026-01-07 12:35:52.024581+00	39.3	21.9	510646	510646
227c72e8-dc8e-4fe7-88eb-44db1376d766	2026-01-07 12:36:25.265285+00	33.5	22.1	2583246	2583246
a166eff0-35ae-495a-a41e-344f3f401261	2026-01-07 12:36:51.93635+00	32.4	21.9	0	0
029f3214-f30c-4c06-9794-914802be2a0c	2026-01-07 12:37:25.207487+00	32.3	22.4	813093	813093
85bdcc75-c8f0-4055-a5be-0e6587ede391	2026-01-07 12:37:52.006856+00	33.6	22.2	2571115	2571115
268b6a06-86f3-4b97-927c-ddf73c3f5619	2026-01-07 12:38:52.019979+00	30.1	22.3	529673	529673
27921f41-fd4f-4deb-9eed-bbf4d8560351	2026-01-07 12:39:25.220917+00	33.7	23.6	3416425	3416425
22ed951d-0c0e-487d-860c-d8f9dcecaaac	2026-01-07 12:39:52.002301+00	32.6	23.7	4290741	4290741
1643f40c-920d-462f-bcd1-0504c8947b2c	2026-01-07 12:40:52.007554+00	35.8	23.8	517078	517078
dbbd76bc-778a-4e23-915b-81803c7706a2	2026-01-07 12:41:25.230236+00	34.2	23.8	4214351	4214351
05cb68ff-7770-4c61-b1ad-2e50b2caa075	2026-01-07 12:41:52.008321+00	35.1	23.8	455023	455023
68eeddba-bbe1-4491-af44-1bc1df25bc37	2026-01-07 12:42:52.046143+00	33.4	23.8	405936	405936
39b0ac1f-1a64-4719-b47f-e39a6b52101c	2026-01-07 12:43:52.035361+00	33.7	23.9	7955113	7955113
3f7858fd-fd95-477a-98e1-e157e18738a4	2026-01-07 12:44:25.203206+00	34	26	1507264	1507264
709073e0-a8c3-48e3-86ab-e05e481e64e2	2026-01-07 12:44:32.138544+00	33.6	23.7	616004	616004
bc59b713-6eee-41cc-a8dc-3ebd2582603b	2026-01-07 12:44:51.888873+00	30.9	23.3	147995	147995
b452a24b-c5a5-419b-8b1b-a5ae53d7a562	2026-01-07 12:46:51.87737+00	30.3	23.2	765131	765131
8d8422f6-9434-46ce-8a61-c5968f949845	2026-01-07 12:47:51.894313+00	30	23.3	409201	409201
0e639857-7599-4fe9-8761-1cde84a20a5a	2026-01-07 12:48:51.907304+00	29.9	23.2	259242	259242
edab7d0f-78f1-4c63-9935-ed059a40843c	2026-01-07 12:49:51.899332+00	29.4	23.3	256688	256688
983561c5-432c-4a6b-8fa5-84f4e2ee99f9	2026-01-07 12:50:51.894418+00	41.3	26.9	571809	571809
4393463a-e487-40be-b0a0-566db51dd8c8	2026-01-07 12:51:51.897819+00	36.7	25.4	1092576	1092576
7c17c5f4-5706-4812-8382-3be4c49e2f13	2026-01-07 12:52:51.914797+00	42.5	26.7	3107145	3107145
06c4468a-de5f-437a-bebb-6a38fb3428c0	2026-01-07 12:52:56.215998+00	34.6	26.8	3630418	3630418
acffe2ec-8307-4fb4-a8a0-1c78d4e8c22e	2026-01-07 12:53:51.907455+00	61.4	28.5	244143	244143
42670ca2-cc9b-41da-b75d-8557aabc432f	2026-01-07 12:53:56.197791+00	61.8	27.1	218526	218526
e45d60e8-a370-49a9-85b4-38eca6dfc114	2026-01-07 12:54:51.91846+00	10.6	26.6	501752	501752
8c556c78-50f4-48b9-8e05-e00740f9db86	2026-01-07 12:54:56.194264+00	10.8	26.6	401899	401899
794cdba7-a5eb-458b-aab7-98e51a934006	2026-01-07 12:55:51.944722+00	8.9	26.7	159606	159606
54b67922-bd57-43c1-8cd5-4e6c64d236ed	2026-01-07 12:56:51.92094+00	10.7	24.9	344490	344490
54aa94b5-0a65-4d91-a8a6-c3a550b9f03b	2026-01-07 12:56:56.214126+00	9.8	24.9	339740	339740
e47a57ff-daa4-42ab-afb4-97dbbcebba8e	2026-01-07 12:57:51.949854+00	6.4	28.2	210733	210733
170a1c62-27cd-491f-87c0-83d0f01429fa	2026-01-07 12:58:51.891465+00	45.7	33.5	423944	423944
83e59c1c-5a51-464d-b6ad-1502e40067c7	2026-01-07 12:59:10.456715+00	18.6	31.1	549049	549049
18db3c60-fa92-48c9-b2d3-4ceacdd1ac0a	2026-01-07 12:59:44.53128+00	26.5	28.9	744081	744081
4b87ed72-0759-4c0a-b4b4-35d932013c07	2026-01-07 12:59:52.042259+00	29.6	29.5	3552849	3552849
117d5aa1-43a0-4de1-a842-8ea87d39b488	2026-01-07 12:59:56.243343+00	25.2	29.7	3476938	3476938
48730ece-b5dd-416d-82b5-be21a74900ae	2026-01-07 13:00:51.903309+00	31.4	27.7	1520153	1520153
49ce94f2-141d-4987-926e-a2304c311e81	2026-01-07 13:01:51.9755+00	33.5	27.8	517111	517111
32f9fcf9-0a36-464b-b030-787918bab6e1	2026-01-07 04:47:00.669392+00	3.1	11.2	898019	898019
92ce9e04-15ca-4c70-804f-0ad119cbca5d	2026-01-07 04:47:00.705366+00	3.1	11.2	543930	543930
1586659b-e392-4349-8e7e-0183c5772dcd	2026-01-07 04:47:00.72799+00	3.1	11.2	739718	739718
a237ee4b-64e1-447e-891f-535e9e3bb1b3	2026-01-07 04:47:52.120524+00	5.1	11.1	194812	95941
b8f66b1e-05f5-4118-a1d8-7d2adc4e04f7	2026-01-07 04:48:00.043357+00	5.7	11	8656	8656
d3843b89-8641-4bbc-901a-d31accba0410	2026-01-07 04:48:01.012402+00	5.7	11	466977	466977
52e6cedc-a866-474d-b430-4104cbc4e431	2026-01-07 04:48:01.053564+00	5.7	11	740743	740743
695d43ac-25ee-4e98-a349-1c4cb2307b59	2026-01-07 04:48:01.086398+00	5.7	11	479278	479278
67c4373c-35f1-46af-b382-e0f468ef24eb	2026-01-07 04:48:52.130784+00	5.9	11	243687	97854
ec38e53c-1ad8-4f21-8349-4125ff52eab3	2026-01-07 04:49:00.102051+00	3.2	11	9400	9400
9a4b7e50-7de1-4d41-ac79-3eced59e07c7	2026-01-07 04:49:00.726103+00	3.2	11	582976	582976
dc0068ef-b787-4e1e-82d5-97b6f409b670	2026-01-07 04:49:00.734746+00	3.2	11	884310	884310
8a650cfe-83df-485f-bfc0-8b295e23e6a7	2026-01-07 04:49:00.745341+00	3.2	11	639936	639936
589ce924-ca29-4a32-b12d-0d3199c96c71	2026-01-07 04:49:52.144269+00	5.6	11.1	340366	112471
152d399b-e1bb-4445-8fc2-776c80508908	2026-01-07 04:50:00.209666+00	3	11	625546	625546
089a54da-7327-4b4d-96a3-60f580823adb	2026-01-07 04:50:00.665781+00	3	11	534273	534273
63cacf93-67ff-4d56-832c-7249644dd180	2026-01-07 04:50:00.675717+00	3	11	541404	541404
a203ccbd-5620-4dab-8da7-0965874aaf18	2026-01-07 04:50:00.690288+00	3	11	777025	777025
3a956e01-a157-47c9-9626-22c4295ad4fc	2026-01-07 04:50:52.124028+00	6.2	11.2	166863	77983
7b7ae1e2-902d-4739-a129-f48224b81bc5	2026-01-07 04:51:00.159087+00	4	11.1	556357	556357
7e18a6ae-7fe3-4361-b20b-6aae8a910fc6	2026-01-07 04:51:00.958585+00	4	11.1	448255	448255
0ca8d338-4883-4270-bd5c-4e47e1b455ca	2026-01-07 04:51:00.996411+00	4	11.1	555961	555961
1a35e6f7-71a4-41af-a2f0-3a927cbd76e6	2026-01-07 04:51:01.01796+00	4	11.1	296555	296555
c1946b33-2593-44d2-afe1-c4502eb38c1c	2026-01-07 04:51:52.168584+00	5.9	11.2	163243	77778
b1575afa-cacd-4144-aab5-073926f662bc	2026-01-07 04:52:01.244261+00	3.2	11.2	396910	396910
8be32091-c200-4283-8576-ee9f8987a075	2026-01-07 04:52:01.351406+00	3.2	11.2	398083	398083
89062eb4-30c9-4864-be37-83db108128cc	2026-01-07 04:52:01.403248+00	3.2	11.2	363003	363003
dfff58fe-e2ec-42e4-add1-eedd1ba9d151	2026-01-07 04:52:01.531875+00	3.2	11.2	344219	344219
c9fb9fdb-918d-4a26-807b-f321176939b3	2026-01-07 04:52:52.177659+00	3.5	11.1	252303	97269
c36a133a-1621-4de1-af11-fb8c96d92884	2026-01-07 04:53:00.352743+00	6.2	11.1	635122	635122
766603e7-edba-4565-b16f-5c950f14b0c8	2026-01-07 04:53:01.158801+00	6.2	11.1	388806	388806
e4fab9df-1dbd-434a-8df9-46e973468cf9	2026-01-07 04:53:01.177037+00	6.2	11.1	397693	397693
19f98d9f-6e8e-4559-bbb5-5136e89adcb2	2026-01-07 04:53:01.192571+00	6.2	11.1	490715	490715
a8d78bcb-8782-4306-a300-25f1ab10f8ad	2026-01-07 04:53:01.467177+00	6.2	11.1	448358	448358
5de24284-5d98-44ac-a1a2-7d7acc277a9c	2026-01-07 04:53:52.191754+00	4.5	11.1	140335	67737
8edc0067-b188-4671-8783-ba324bfe51d4	2026-01-07 04:54:00.049556+00	2.7	11.1	8601	8601
89391b00-da9b-4179-9a0c-553f31304b11	2026-01-07 04:54:00.691709+00	2.7	11.1	569288	569288
6ab29541-c47e-48ff-a7d3-fab38bab66da	2026-01-07 04:54:00.700839+00	2.7	11.1	687157	687157
cfa3eedd-b2f0-4bb8-aa8f-966db6b45738	2026-01-07 04:54:00.719803+00	2.7	11.1	654591	654591
7ddd7692-d866-47df-8173-d3bd3f676a78	2026-01-07 04:54:52.208934+00	5.9	11	118002	62485
89ba3bf0-89b2-45f6-b01c-bf2df15b3601	2026-01-07 04:55:00.412752+00	3.4	11.1	125472	125472
d825ee48-1c2f-476b-a681-50c2b678daa0	2026-01-07 04:55:00.860631+00	3.4	11.1	412788	412788
a98d8b8c-0e7e-43e0-a5db-c1d3aacbe3dc	2026-01-07 04:55:01.112915+00	3.4	11.1	472472	472472
8a879027-3b82-4aea-9bc9-e1b127a5c526	2026-01-07 04:55:01.128921+00	3.4	11.1	488274	488274
b0b40437-11e6-4241-aefa-c4fd9555f730	2026-01-07 04:55:01.226627+00	3.4	11.1	561995	561995
cfea234a-272a-45d3-9656-060fc059437c	2026-01-07 04:55:52.168114+00	3.4	11.1	195833	79282
a214277a-bd12-4f16-967b-e54eedacc3cd	2026-01-07 04:56:00.218988+00	3.2	11	642812	642812
10447779-1135-412a-b520-b40db61637db	2026-01-07 04:56:00.72127+00	3.2	11	655625	655625
7ac9dbcf-64d5-4afe-a42b-e6e178389c43	2026-01-07 04:56:00.806377+00	3.2	11	439491	439491
8869ff06-d298-4653-b316-8c9b6f58b522	2026-01-07 04:56:00.828154+00	3.2	11	450781	450781
367a263c-fb14-45e1-88b2-e69ae6991b74	2026-01-07 04:56:52.194703+00	3.6	11.1	127998	64282
729faa78-437e-4180-a370-9318fcdb4561	2026-01-07 04:57:00.029294+00	2.8	11.1	9422	9422
614dc255-96cf-4d98-b3f1-f16616f7d4d5	2026-01-07 04:57:00.16991+00	2.8	11.1	889145	889145
ef72c96f-002f-4654-8e48-90f4d70e5688	2026-01-07 04:57:00.648759+00	2.8	11.1	811971	811971
eb2b5ebb-8925-4f07-8b34-022362b0c1a7	2026-01-07 04:57:00.709113+00	2.8	11.1	657649	657649
da444d28-f34a-419f-b874-6f0c779afe8c	2026-01-07 04:57:00.717695+00	2.8	11.1	721371	721371
898eeffb-280b-4416-b0db-7767676e8c24	2026-01-07 04:57:00.743282+00	2.8	11.1	585986	585986
0364c124-2b30-4d15-a2bd-62b2c882351e	2026-01-07 04:57:00.918898+00	2.8	11.1	604504	604504
8dd2a005-544e-470f-b4fc-6e2145c50e09	2026-01-07 04:57:52.205459+00	5.2	11.1	136433	59061
360d348b-71fa-4753-ac24-a486d7ef2a47	2026-01-07 04:58:00.107303+00	3.9	11.2	717368	717368
dc106b0a-051c-4f46-a3a8-cd2e3b14250a	2026-01-07 04:58:00.708413+00	3.9	11.2	551653	551653
32b61101-a4a4-4f1b-b47a-bd6f96ee0cc3	2026-01-07 04:58:00.745317+00	3.9	11.2	721243	721243
255acebb-f009-4e6b-ae24-aa687e949f0f	2026-01-07 04:58:00.776113+00	3.9	11.2	497037	497037
68e1c0a0-f8b4-4c95-8215-fe04f9fae39e	2026-01-07 04:58:00.783084+00	3.9	11.2	577761	577761
0be63053-88aa-4fd7-8b19-b6f88d5a4f9e	2026-01-07 04:58:00.80405+00	3.9	11.2	724900	724900
c8ad7f1d-eaa7-4df2-9d19-3869ea03d2fb	2026-01-07 04:58:00.913614+00	3.9	11.2	564697	564697
9a309a60-106d-440a-845d-c825d417b312	2026-01-07 04:58:52.257762+00	3	11.1	165009	65617
cc12e84c-6210-41fb-99a5-4d0448d452e2	2026-01-07 04:59:00.050924+00	3.5	11.1	14617	14617
fa5576e0-3975-46e2-bf15-8def9c7337aa	2026-01-07 04:59:00.172341+00	3.5	11.1	832103	832103
8b578314-9553-40c6-b765-fdc69878aff0	2026-01-07 04:59:00.623731+00	3.5	11.1	757782	757782
cb6a180a-b4af-4092-a5f1-b3a25a97a772	2026-01-07 04:59:00.641249+00	3.5	11.1	324616	324616
eee261ce-0103-44d0-ab20-c6247dff7954	2026-01-07 04:59:00.649916+00	3.5	11.1	511129	511129
a23b73be-fd0c-4ae0-acef-5f539eb3e299	2026-01-07 04:59:00.668544+00	3.5	11.1	721167	721167
e1efd335-440c-4874-af85-f261fea7d4da	2026-01-07 04:59:00.700004+00	3.5	11.1	614725	614725
0515d7e6-0e2f-4183-9d1c-bba66af875c9	2026-01-07 04:59:00.727104+00	3.5	11.1	688352	688352
0a72184b-af5a-43b1-8360-52f8528a509e	2026-01-07 04:59:00.805019+00	3.5	11.1	872410	872410
aca6afb0-e55f-4e80-9af9-c5a8ab2da54f	2026-01-07 04:59:31.694035+00	5.5	11.1	253932	253932
410d126c-b520-4a61-818a-64270a4162f6	2026-01-07 04:59:52.269412+00	22.9	23.9	108213	55595
8680f8b4-85a0-435b-a5a2-8d8e0a2459e6	2026-01-07 05:00:00.138578+00	6.4	23.8	10000	10000
936ba274-1a02-444e-8384-2886173cba35	2026-01-07 05:00:00.326176+00	6.4	23.8	310141	310141
d7a8e4b1-f50a-4ac9-868d-7a92bec631ca	2026-01-07 05:00:00.974976+00	6.4	23.8	920410	920410
c9325964-4169-4a5b-925d-e6b75e24a072	2026-01-07 05:00:01.004916+00	6.4	23.8	663892	663892
6ee5198f-2012-4498-8a44-a85a31b2002e	2026-01-07 05:00:01.016563+00	6.4	23.8	719848	719848
1dd75bb5-373f-4e23-8faa-d096fcc96e68	2026-01-07 05:00:01.026624+00	6.4	23.8	777728	777728
85cd370e-ef15-4586-a6d4-68097b0afa14	2026-01-07 05:00:01.034494+00	6.4	23.8	647518	647518
d5725c7d-f605-4974-8241-5d63fa3505db	2026-01-07 05:00:01.179857+00	6.4	23.8	360386	360386
943a7bea-12fd-4d5b-bca8-8389192ba5bb	2026-01-07 05:00:24.475617+00	17.9	30.9	218514	218514
1e2a38fc-3667-4765-9930-457e84d67a91	2026-01-07 05:00:52.248667+00	20.5	31.6	163119	97531
2c3eeab8-6294-43e9-b69a-a2ea2c01398d	2026-01-07 05:01:00.124102+00	20.9	31.3	302403	302403
67cb79c5-25ad-49d9-9bc9-30ac1b2f060c	2026-01-07 05:01:00.230163+00	20.9	31.3	1024320	1024320
e33bbdf1-e610-456b-a6be-33c925e4e698	2026-01-07 05:01:00.944414+00	25.3	31.4	1270619	1270619
78edec0c-509b-403f-a551-e2125e537220	2026-01-07 05:01:00.977028+00	25.3	31.4	858602	858602
65254870-e7ae-4628-98a3-6e3bb891f1e2	2026-01-07 05:01:01.013436+00	25.3	31.4	766034	766034
cd0ddc48-233f-44b2-81c9-95300a724372	2026-01-07 05:01:01.032789+00	25.3	31.4	909248	909248
0ad0c1f5-d1c0-4ccc-be04-fd1939c86cf8	2026-01-07 05:01:01.089413+00	25.3	31.4	845567	845567
49bde694-2bfe-4f1e-9fce-592cae00d46f	2026-01-07 05:01:01.658743+00	25.3	31.4	2847294	2847294
82380147-96e6-41ab-acaa-2ea052f06c4e	2026-01-07 05:01:02.635783+00	72.2	31.4	3495948	3495948
a31a9032-f187-4e02-ae71-f06a617d206a	2026-01-07 05:01:04.416674+00	72.2	31.5	3967692	3967692
0f5bdd6a-a8ec-4863-9da1-f66b1dfe55b3	2026-01-07 05:01:33.639427+00	33.8	31.5	4630700	4630700
340a735e-24b1-4405-a754-35e30f4acf1a	2026-01-07 05:01:52.790416+00	39.2	32	655502	655502
5f434b1d-071c-4bed-8422-5785ca0fdbe3	2026-01-07 05:02:32.134406+00	13.1	31.9	696796	696796
57167a22-afad-44bb-9360-0bfd6450aee5	2026-01-07 05:03:00.143868+00	24.2	25.6	1124226	1124226
cd89d60d-65d3-4cee-92d0-b57cfcd24578	2026-01-07 05:03:32.406275+00	38.2	25.7	2563721	2563721
5fd51161-4a73-4f4e-a0a8-e48109ea47e4	2026-01-07 05:03:59.709133+00	28.4	25.6	1331636	1331636
f5a40f62-b836-4836-a826-6ee58fd7a59d	2026-01-07 07:53:54.060777+00	13.5	22.6	80168	36977
244957aa-20c7-4406-a92a-49b00519f3e0	2026-01-07 08:34:54.431978+00	6.4	21	4662	2793
3046808e-410e-447b-9794-be0ff146ae52	2026-01-07 09:14:54.77248+00	45.1	29	9134	124452
3b1e8893-eb7e-47d6-954e-b458ee757a1c	2026-01-07 09:49:52.217087+00	4.5	24.5	7585	7585
54ece0a4-4279-441d-9332-8c75ade5c44c	2026-01-07 10:08:12.612438+00	13.2	30.4	628	1452
7d5d44ff-6eaf-4bef-8485-8570ef581326	2026-01-07 10:30:52.166614+00	10.2	27.3	0	0
879500e7-52ce-47e4-9825-4d1066d7d257	2026-01-07 10:47:52.109038+00	16.9	31.6	1043468	1043468
c287b93b-8130-4b6d-a266-a05d5b9c85c7	2026-01-07 11:04:52.107112+00	10.4	31.4	10113012	10113012
725ed649-ec2d-4cfa-8653-d0eb12c386cd	2026-01-07 11:24:13.590468+00	21.3	34.8	1683773	151757
0945ebe1-27a4-46b5-a2fc-73fd543c6939	2026-01-07 12:03:52.121319+00	47.8	34.6	2580957	2580957
0f199000-8133-4771-a4f7-840ecdc6005b	2026-01-07 12:03:53.35786+00	47.8	34.6	4212527	4212527
2ca08e19-7f77-456b-8485-22fb8965f767	2026-01-07 12:32:51.956611+00	23.8	24.1	1457215	1457215
535eb2a8-50d4-4495-8945-d9b14893f81a	2026-01-07 12:33:51.99093+00	41.8	21.4	380390	380390
5c90c005-69d0-4d71-959a-90229979d0a6	2026-01-07 12:34:51.961015+00	37.5	22.9	622761	622761
076d56bc-9194-4faa-9e7e-b029ed4f20ff	2026-01-07 12:35:25.227275+00	30.7	22.2	4458060	4458060
f5ab7196-37f8-4516-b446-bfe0313928bc	2026-01-07 12:35:52.016176+00	39.3	21.9	304692	304692
23dfb5e8-8202-4fbd-b131-75b5a2662332	2026-01-07 12:36:51.946107+00	32.4	21.9	4766858	4766858
2638b8b9-ddeb-4a97-a5d5-fde43bd85339	2026-01-07 12:37:52.007632+00	33.6	22.2	0	0
1b86e368-e0f5-4087-b8fa-3b4e93bc4c6e	2026-01-07 12:38:25.216638+00	33.1	22.3	2045900	2045900
265ce5c7-fdc4-473e-9d82-3c54d96e1bad	2026-01-07 12:38:52.009772+00	30.1	22.3	161484	161484
09d04e95-083b-4c59-a646-ff3e08cde629	2026-01-07 12:39:52.008786+00	32.6	23.7	6325839	6325839
626d1355-bb5d-4ad0-9e95-6394eb18f877	2026-01-07 12:40:25.238599+00	33.4	23.8	790890	790890
93704ff8-b630-498e-becd-46ad1ddf8fc7	2026-01-07 12:40:52.022279+00	35.8	23.8	18493	18493
f5e934dd-267c-468f-87ee-c7fa4812852c	2026-01-07 12:41:52.008311+00	35.1	23.8	0	0
34a9cc36-f44d-43c9-a6ee-bcbf275b948b	2026-01-07 12:42:25.23086+00	32.6	23.8	1522384	1522384
829dd4a9-fe1d-4e1b-bad9-4f8903f00516	2026-01-07 12:42:52.012551+00	33.4	23.8	571583	571583
a0b0ade6-ca2a-4b44-b554-a3ce4d5d62d8	2026-01-07 12:43:25.21761+00	35.4	23.8	1117963	1117963
55e99059-f49f-46f1-865c-81f075d5f002	2026-01-07 12:43:52.035426+00	33.7	23.9	3561039	3561039
dea8f7c9-c4f7-44b2-8d0e-54e9a3857567	2026-01-07 12:44:51.887025+00	30.9	23.3	527762	527762
812797e4-289a-465a-9ac8-ea1094cce913	2026-01-07 12:45:51.863068+00	29.5	23.2	403160	403160
a8c47360-4d7b-443e-9e05-0ab5f57ffc3d	2026-01-07 12:45:51.891815+00	29.5	23.2	717013	717013
2c1faf03-a9fb-4600-afb4-96fb3f02dbc9	2026-01-07 12:46:51.875674+00	30.3	23.2	243592	243592
a6255cf7-316f-4195-a9cd-32e8c1045efb	2026-01-07 12:47:51.88812+00	30	23.3	562352	562352
5e024a47-334f-4549-bc3d-22d1fbe695b8	2026-01-07 12:48:51.895661+00	29.9	23.2	293042	293042
0c1e1fbc-4592-4c57-b11f-21061b0746a6	2026-01-07 12:49:51.890503+00	29.4	23.3	417473	417473
56aa73d1-8f3f-4583-b6cd-bcc4f8c0403b	2026-01-07 12:50:51.899437+00	41.3	26.9	1098465	1098465
9c12f803-5f7d-48ca-92dd-8d26fb1a58a2	2026-01-07 12:51:21.233215+00	45.2	27.6	844426	844426
e2b5d7c6-f1da-4cc1-9a30-cc219f0f51ae	2026-01-07 12:51:51.931971+00	36.7	25.4	917757	917757
66ece893-5c83-4e86-badd-ca33ec6d6197	2026-01-07 12:51:56.287749+00	37.4	25.9	318783	318783
7ae69326-a6af-45dc-a023-e77b13623687	2026-01-07 12:52:51.92437+00	42.5	26.7	304116	304116
49e3bd36-9dfb-4eff-a2c9-10cb9f93f311	2026-01-07 12:53:51.898469+00	61.4	28.5	204219	204219
884285e9-f6ff-4b5c-9dab-aa96b906bd5e	2026-01-07 12:54:51.927911+00	10.6	26.6	0	0
836337bf-b6a9-49db-9a90-27f6aef45972	2026-01-07 12:55:51.935199+00	8.9	26.7	362336	362336
fe58a644-f83f-4723-a960-5a46f19d808b	2026-01-07 12:55:56.181423+00	12.9	26.6	387018	387018
efdf209f-aec6-481b-a4a5-0928a3356a3d	2026-01-07 12:56:51.935748+00	10.7	24.9	324056	324056
5b41925a-b6ce-4df6-a367-404815a7217a	2026-01-07 12:57:51.948211+00	6.4	28.2	445504	445504
cf53efc5-3bbb-485a-8c2c-7d661aa6c27f	2026-01-07 12:57:56.21713+00	17.2	28.6	558663	558663
2436269b-15ea-494a-9f37-00685a3d95e9	2026-01-07 12:58:51.913829+00	45.7	33.5	339156	339156
0527e254-34f5-4d7c-95a2-aee2b314d721	2026-01-07 12:58:58.709739+00	42.5	31.2	440465	440465
342e8663-a478-4d1a-bcee-9e577d6b38b0	2026-01-07 12:59:52.029945+00	29.6	29.5	8416855	8416855
f809a3d9-6ced-4975-bc4b-2ebeebe7cb35	2026-01-07 13:00:44.445106+00	34.1	27.7	2573520	2573520
b86227b7-2732-4cbd-a12e-7f275ff97f55	2026-01-07 13:00:51.926095+00	31.4	27.7	2124786	2124786
15bc3606-73fb-4fc8-8034-b887d47b4197	2026-01-07 13:00:56.187802+00	31.1	27.6	1772282	1772282
565f7d61-4c09-4ce6-a12c-0061fa4765e1	2026-01-07 13:01:44.428214+00	35.1	27.9	4339216	4339216
3674d29f-da7e-43d6-b819-84acf36f52fd	2026-01-07 13:01:51.97747+00	33.5	27.8	552274	552274
b22c7899-efdc-4b1e-b648-06a8c9e7634c	2026-01-07 13:01:56.212475+00	36.6	27.7	5223223	5223223
322eed59-e233-46a7-9c1c-5fdf75ecd329	2026-01-07 05:01:32.39473+00	33.8	31.5	3723380	3723380
7b43919f-9e97-43c3-b9a9-4791f5aeeff8	2026-01-07 05:01:52.728629+00	39.2	32	715899	715899
509fcd28-6580-4512-adee-bc6ee0e4626f	2026-01-07 05:02:04.508555+00	46.8	32	294830	294830
5cd9b1cb-049a-4848-b186-d151ae1ba47b	2026-01-07 05:02:59.114602+00	12.6	25.5	312515	312515
de214b0f-a123-4c95-a62a-8f56b65f5242	2026-01-07 05:03:58.697719+00	11.8	25.6	737099	737099
7082839e-8688-4314-a406-5c72ee2cd556	2026-01-07 05:03:59.755972+00	28.4	25.6	1733142	1733142
3a4ea1e3-e42d-44e7-a76d-f4b211cfa738	2026-01-07 05:04:09.56789+00	36.4	25.8	621392	621392
e6616c41-5b05-434f-9299-b803fe15ec02	2026-01-07 05:04:58.402163+00	34.4	25.6	2466784	2466784
73bc090d-dc08-4c94-b935-7f65cfbc1dcb	2026-01-07 05:05:09.62654+00	35.4	28.3	343188	343188
7578185a-08f9-4ab7-ba6c-1f6f3f84312a	2026-01-07 05:05:59.542568+00	7.9	27.1	310449	310449
357a2d80-60cc-4d33-bf1a-3295dd8e5404	2026-01-07 05:06:11.351101+00	35	27.2	775462	775462
0015ca3e-5dec-4558-a72a-310f42f5bc4d	2026-01-07 05:06:58.440772+00	10	27.2	211677	211677
64c63447-dd15-4a8a-b7c5-3629ae8010cb	2026-01-07 05:07:08.909472+00	10.9	27.1	594378	594378
fad6d3f9-167f-4075-ae8e-67a9f3181ed2	2026-01-07 05:07:59.329129+00	7.8	24	452982	452982
2bb02889-cf1f-4829-aedb-f63164b8957a	2026-01-07 05:08:11.16855+00	20.6	23.9	453134	453134
62dd7e0b-1da3-4308-bd3b-4e57b981a4ef	2026-01-07 05:10:09.55406+00	16.9	22.1	1118552	1118552
13612f5e-ab2f-4105-9b89-8d47738ea05b	2026-01-07 05:11:08.882594+00	17.2	22.1	800288	800288
c9e83bb8-9bfd-45cf-ab07-38864617325d	2026-01-07 05:11:58.078762+00	8.6	22.1	687941	687941
ce1eae65-5b65-48a6-af58-b62ead43f953	2026-01-07 05:11:59.394457+00	6.9	22.2	668856	668856
4668976b-41dc-49fd-9456-d454e29931bc	2026-01-07 05:12:09.692475+00	15.1	22.1	1134310	1134310
46b1ac8e-96d3-4178-96ec-f91ba07f34f3	2026-01-07 05:13:59.421788+00	8	22.2	317843	317843
06820573-a479-4cb3-9351-31bbf0c08469	2026-01-07 05:15:32.163753+00	10.7	22.1	959849	959849
89e5f116-3851-4e7c-ade0-b2b174ef7d97	2026-01-07 05:16:32.049697+00	19.2	22.1	695218	695218
b6c64d39-244f-42d4-b1cd-55a36cda7a6b	2026-01-07 05:16:59.362233+00	7.7	22.1	494623	494623
d15ce2f8-59ef-440a-8722-1bee0265f196	2026-01-07 05:17:08.863021+00	9	22.2	1032265	1032265
f48ff77d-01b3-4603-b22a-2b4d61408b54	2026-01-07 05:17:32.031113+00	9.2	22.2	818366	818366
49479df9-e3cf-4877-9061-82e0d939fd3e	2026-01-07 05:17:59.428353+00	8.2	22.2	158376	158376
7a39abdc-9500-4722-8add-df194cb7c0a4	2026-01-07 05:18:09.748617+00	22.5	22.2	737818	737818
d8045732-35f2-486e-bbca-812a11e02f42	2026-01-07 05:18:59.137047+00	7.1	22.2	449204	449204
1150d60d-766e-4d11-b677-3e7633539b28	2026-01-07 05:19:32.183959+00	11.4	22.1	776439	776439
5a07b1e2-1967-4c0c-b684-2be202b591bd	2026-01-07 05:20:08.870642+00	8.1	22.1	976169	976169
5496a0d5-c2c6-4f7b-93c2-74e2c83cab66	2026-01-07 05:20:59.421235+00	8.5	22.1	755289	755289
465520f2-8c66-45f3-9253-f07f2df419d8	2026-01-07 05:21:11.050209+00	18.4	22.2	812416	812416
6cc4d975-0931-409a-ad34-62273a65babf	2026-01-07 05:21:59.44145+00	11.9	23.1	539472	539472
06d34054-4fbd-48d8-af87-6feda9abe22b	2026-01-07 05:22:58.065554+00	13	23.9	665158	665158
13cd3e1a-deaf-48c9-bf2b-9ba7a6cdb8e8	2026-01-07 05:22:59.452929+00	6.4	24.2	483543	483543
2523dc05-ec5f-4164-8fa2-1a1f42fb4d0e	2026-01-07 05:23:09.747339+00	10.2	24.5	1009368	1009368
dcbc0a6f-97ef-4749-9064-84434d98713f	2026-01-07 05:24:59.656537+00	8.8	25.9	255974	255974
ae817409-351b-40b0-a92f-990864cb127d	2026-01-07 05:25:09.206821+00	17.7	25.8	594220	594220
43fee2ca-69d1-4487-aa49-89ab35735588	2026-01-07 05:25:11.467582+00	72.3	25.8	782966	782966
f916fc3a-a458-4273-9d5b-c28b4e2c749c	2026-01-07 05:25:32.339679+00	19.8	25.8	768292	768292
f044abd9-cdf2-482d-8de4-6e3c7e0198af	2026-01-07 05:26:09.123698+00	16.9	22.2	750081	750081
e3960aca-fdd5-44fc-8b87-30cae0524e24	2026-01-07 05:26:32.318605+00	9.7	22.2	747081	747081
877a596a-f39f-44ea-9d03-c9d0e23be97d	2026-01-07 05:26:59.921941+00	6.3	22.2	995016	995016
6fb2a7a0-dfac-4504-ac7f-968240cf269d	2026-01-07 05:27:09.298802+00	7	22.2	779801	779801
147d8ecf-634c-4132-8759-f59f29642cc1	2026-01-07 05:27:59.879191+00	9.1	22.1	214400	214400
77e2fc44-920f-48ef-80ab-6c71939c7064	2026-01-07 05:28:09.52371+00	17.4	22.2	686645	686645
cbb551f1-c349-45a9-a714-44aa6d280d6d	2026-01-07 05:28:58.331177+00	9.4	22.2	683981	683981
5e92661b-6b4c-4f2b-82b6-1176de6ba275	2026-01-07 05:28:59.585238+00	9.8	22.1	453291	453291
639c14dc-1b96-4305-9eb0-e6ccc6b83e2f	2026-01-07 07:54:54.072462+00	15.9	22.5	79573	36132
fcfea977-5ee5-4f9e-9214-b6e63fab7828	2026-01-07 08:35:54.435308+00	6.6	21	4636	2970
baa0a3b5-356e-4877-a31c-61ddeeea43d6	2026-01-07 09:15:54.743953+00	11.9	28.5	8100	115913
26b4f8ed-0dd6-4e1e-a888-e812b8a24a71	2026-01-07 09:50:12.356879+00	4.8	24.6	3510	2308
259e1dc3-d374-4d81-97cd-b359e53bb4ec	2026-01-07 10:08:51.861269+00	16	29	2820577	2820577
05b6e2aa-1395-4aaf-87b4-42d152bd32c4	2026-01-07 10:09:52.016833+00	25.3	31.9	265631	265631
5b1ae623-002e-4de2-a591-0270dccc8905	2026-01-07 10:10:21.756195+00	22.4	31.7	524006	524006
256f2aae-a6df-4148-b2d5-ab7566283a9b	2026-01-07 10:10:55.786004+00	18.8	32.3	583935	583935
105f5d7d-2420-4341-b87e-b9d728160709	2026-01-07 10:30:52.166628+00	10.2	27.3	107113	107113
da8914dd-f301-4a57-a0ff-499e1cebb907	2026-01-07 10:48:13.196318+00	22.4	31.6	1267596	50639
537158bc-a07c-4cf7-a249-c942aa066aa1	2026-01-07 11:04:52.111547+00	10.4	31.4	7377475	7377475
39e96471-8a7c-40f8-b86d-e26d7add31f5	2026-01-07 11:24:52.121609+00	27.6	33.9	19440	19440
52c280e6-05ff-48b6-a5bc-508532bdab7c	2026-01-07 12:04:52.154424+00	59.2	35.2	405272	405272
e9f258ec-e67b-4913-97c0-d242ce3d1d37	2026-01-07 13:02:44.426064+00	34.3	27.8	918315	918315
3a6f42ae-ac48-427b-bed9-57db0a6322ff	2026-01-07 13:02:51.997051+00	33.6	27.8	1123875	1123875
cb77ed95-0010-43bf-95fa-b251f3d641ce	2026-01-07 13:02:56.185785+00	35.7	27.7	3617515	3617515
5401cc5f-bb66-4aac-b213-4998b0bd9848	2026-01-07 13:02:57.913428+00	35.7	27.7	2322006	2322006
089225c8-76b7-463c-9310-e58f28eca6fd	2026-01-07 13:03:31.662772+00	34.4	29.2	397734	397734
3af1e128-928d-4578-8526-11be26e4d8ae	2026-01-07 13:03:52.096719+00	17.7	29.2	113475	113475
626a9aad-6eb8-4c7c-8471-94a1fd2b3168	2026-01-07 13:04:40.310756+00	31.4	31.2	569264	569264
ce4085a5-4065-4b3d-8e0f-0938e4c3fbce	2026-01-07 13:04:52.082255+00	30	30.5	191705	191705
caae6642-2332-403d-9521-772a15babe24	2026-01-07 05:01:33.261137+00	33.8	31.5	3777929	3777929
d32aaabc-4756-4702-b480-8c25dbfc2e29	2026-01-07 05:03:58.66291+00	11.8	25.6	624525	624525
e8fe4571-11cf-47c6-98ff-c4185f5078c2	2026-01-07 05:04:09.593806+00	36.4	25.8	4650563	4650563
4de2ce43-4e01-4dcc-9bf2-85f301aabfbd	2026-01-07 05:04:10.731788+00	47.1	25.7	1427084	1427084
34e082ef-7672-49fd-8111-71d5e4ee7dc8	2026-01-07 05:04:59.688523+00	32.9	26.1	242088	242088
4d5e0332-aaea-4a43-a3e6-fb190e1abba4	2026-01-07 05:05:09.636444+00	35.4	28.3	560559	560559
1ae3c861-2833-4bbf-89ab-df91fb15f548	2026-01-07 05:05:10.736155+00	44.4	27.9	673961	673961
a9a49a6c-921d-4176-8737-da6e966d8a37	2026-01-07 05:05:58.404225+00	10.2	27.1	766585	766585
0900f5c4-6cb3-4d12-9b7c-78de1ce9031d	2026-01-07 05:05:59.542669+00	7.9	27.1	411228	411228
21db36db-8f92-49c1-a63d-fea397953d9b	2026-01-07 05:06:32.233712+00	10.1	27.2	776223	776223
e66556c0-7cca-4456-bc51-81aa7852d0db	2026-01-07 05:06:59.386559+00	8.8	27.2	392043	392043
f91a6363-2c8b-4584-8d5a-2a18120b2247	2026-01-07 05:07:11.226416+00	18.4	27.2	516899	516899
5e22b349-33c9-4e20-8d56-d2cf68449d2c	2026-01-07 05:08:08.912032+00	15.1	24	1170374	1170374
105efb47-4cb6-4a6a-a53d-ec54ca9c0d9b	2026-01-07 05:08:58.119627+00	8.8	24	701996	701996
0860918c-fc29-4659-b3e1-6c34b8e3c9f7	2026-01-07 05:09:08.743078+00	8	23.9	1071659	1071659
f5e28ad6-a4b9-40f9-ac4e-ddfc0689e1b7	2026-01-07 05:09:58.095404+00	9.1	24	355478	355478
4f088711-f094-4cec-8bb6-24c729306ef6	2026-01-07 05:10:09.549479+00	16.9	22.1	425012	425012
3a0f0d47-1171-4497-bbff-182af9ac6b30	2026-01-07 05:11:40.783631+00	11.2	22.1	1123633	1123633
689145b5-48e5-4f47-b2a0-76d58a719d3a	2026-01-07 05:11:59.473788+00	6.9	22.2	499771	499771
d64a2600-df3c-4da9-8eb2-09e57aebf4e9	2026-01-07 05:12:08.914382+00	15.1	22.1	537954	537954
a79a642f-5470-47b2-b55a-2a3dd3a97a45	2026-01-07 05:12:58.071895+00	10.4	22.1	738876	738876
5dc2d53a-44a1-491d-80f2-153bb9aa20f9	2026-01-07 05:13:09.48569+00	14.1	22.1	1235832	1235832
b9a070ed-e103-4cb0-9f8b-518422b59d44	2026-01-07 05:13:32.117168+00	10.1	22.2	1080470	1080470
ed657a7f-d837-47c3-b443-e99da320c5e4	2026-01-07 05:14:08.940876+00	15.2	22.1	619631	619631
a78b4750-5075-468e-aaa0-d69848ccf723	2026-01-07 05:14:59.455944+00	8.8	22.1	387802	387802
4cb7edf6-bd9d-4f06-8aad-26992b252731	2026-01-07 05:15:08.912225+00	16.9	22.1	797417	797417
bb133b4d-3c1a-4a52-8a02-f08520711b00	2026-01-07 05:15:59.373775+00	9.9	22.1	169115	169115
32dad2ac-4cea-4cad-bb7a-5e32f9f553ae	2026-01-07 05:16:58.115442+00	10.5	22	326936	326936
bb6f1dd9-b877-4de4-802a-3711bd0066be	2026-01-07 05:17:59.430049+00	8.2	22.2	224018	224018
678e0293-c141-46ee-90ad-7441acc74f7f	2026-01-07 05:18:59.065901+00	7.1	22.2	706149	706149
3ccd8c60-32be-4153-a9f9-1fb936d48151	2026-01-07 05:19:10.627996+00	34	22.1	640499	640499
03e05cba-96a5-46de-87ee-b86f3c92b90f	2026-01-07 05:21:08.873473+00	15.9	22.3	1128208	1128208
eec2908b-e131-40b9-bf35-3aaa8b1cd4f7	2026-01-07 05:22:08.875013+00	14.6	23.1	45307	45307
1f01f67c-1a81-4267-aa5e-086e651a68a2	2026-01-07 05:23:08.945154+00	10.2	24.5	822231	822231
588d7f52-5942-4bf2-babc-6aac30d3d41b	2026-01-07 05:23:58.242973+00	11.3	25.8	246889	246889
9d486c01-56ea-45cb-b4f1-b8feafb91afb	2026-01-07 05:24:08.99127+00	14.4	25.8	674256	674256
3863fdad-e899-403a-b2e0-cbff6abcde03	2026-01-07 05:24:59.74959+00	8.8	25.9	381597	381597
25dac94b-662f-438e-8174-83f7f1f2426c	2026-01-07 05:25:58.350049+00	9.9	22.3	546954	546954
a2253bf5-aeb2-42e8-ad03-8e025110b137	2026-01-07 05:26:09.878518+00	16.9	22.2	1208722	1208722
fec30f40-1ce7-41c7-b673-73dbb710f152	2026-01-07 05:27:32.295628+00	7.7	22.2	782398	782398
e3f4e7b8-c726-4307-a622-a24f585fea35	2026-01-07 05:27:58.62665+00	8.4	22.1	249945	249945
1a8927c3-d511-4ebb-b8f4-c172f11cab33	2026-01-07 05:27:59.950444+00	9.1	22.1	373011	373011
531ae261-bd51-4936-bb6a-49f63ee75696	2026-01-07 07:55:54.069608+00	12.9	22.5	96307	34341
fdf9af28-35f7-47be-99c4-a33e6aa875d8	2026-01-07 08:36:54.395911+00	7.1	30.6	5519	7866
e1a702c4-a96d-4108-927a-c9b1c391ff55	2026-01-07 09:16:54.747102+00	6.3	28.6	5745	61124
aadc8332-9736-4963-862f-c32d31a9e5d1	2026-01-07 09:50:52.188582+00	4.4	24.6	89390	89390
bb2a02ed-a8d7-4e7f-ae9a-4d74b6dad86f	2026-01-07 10:08:55.871201+00	24.9	28.3	1418801	1418801
4e116696-5ef7-4762-955e-c9c604a48498	2026-01-07 10:09:55.787793+00	25.4	32.6	40254	40254
43983e3f-3aa4-4587-b40c-db9d74b10f86	2026-01-07 10:10:52.052356+00	0	32.2	161429	161429
2009255e-ef36-4ae8-9336-8fcb67450cc4	2026-01-07 10:31:12.970704+00	7.1	27.3	5384	3365
ef6e21b7-bfcf-43ea-8718-23e2b0af1d4b	2026-01-07 10:48:52.089662+00	22.3	31.5	750588	750588
62fa163f-fec1-440d-b160-d6da6084bc4a	2026-01-07 11:05:13.327686+00	22.2	33.1	14500	57972
9e385608-d18a-4adc-bc05-968f31cb3226	2026-01-07 11:24:52.123963+00	27.6	33.9	91965	91965
5d46dae7-2926-4492-87fb-8f1b868f0574	2026-01-07 12:04:52.155743+00	59.2	35.2	155727	155727
21b09d2d-b35d-432e-8389-961c787941ff	2026-01-07 13:02:51.992934+00	33.6	27.8	3768069	3768069
191b425f-661b-4f81-9350-5f57c38b325b	2026-01-07 13:03:40.36597+00	8.9	29.2	568002	568002
e02d0c95-5c51-492c-85b8-25e176ac56fd	2026-01-07 13:03:52.096708+00	17.7	29.2	56535	56535
205d822f-5e91-40aa-8a85-4b90392cc5d4	2026-01-07 13:04:52.078394+00	30	30.5	62284	62284
a7a40314-33fa-45ca-a2e9-00cf7eb6749c	2026-01-07 05:01:33.704919+00	33.8	31.5	3965139	3965139
754ad628-1cce-49fc-91fc-c02f0af9b8f7	2026-01-07 05:02:32.727579+00	13.1	31.9	641647	641647
7891b56e-bbd7-491d-a8e9-ef5a256500ce	2026-01-07 05:02:59.116939+00	12.6	25.5	252675	252675
f38cad3b-f0e4-4cc1-9905-46d7a7ebb605	2026-01-07 05:03:04.368131+00	64.4	25.7	763325	763325
092e2da1-a2c0-4ee5-b805-1383cc00cf04	2026-01-07 05:04:59.695243+00	32.9	26.1	332831	332831
6f9c7018-be3c-4dc9-afe9-48b254c60af5	2026-01-07 05:05:12.135123+00	44.4	27.9	992407	992407
a341cbf1-7d94-43b5-8efd-ec57ebc40d77	2026-01-07 05:05:58.426464+00	10.2	27.1	573725	573725
48f4a129-cd7f-4363-8c1f-676c519b777b	2026-01-07 05:06:09.148555+00	21.3	27.1	475087	475087
41462ec6-45aa-41c9-8a3a-89aec21baeab	2026-01-07 05:06:58.280621+00	10	27.2	567790	567790
bab50715-edde-4d87-9118-5f59030150da	2026-01-07 05:07:32.321262+00	10.2	27.2	919857	919857
541b17a7-e64b-46fa-8a1a-44d7802ebdc9	2026-01-07 05:08:58.115085+00	19.7	23.9	481129	481129
439872af-76e0-440c-8bfb-f129727672b5	2026-01-07 05:08:59.292444+00	9.4	24.1	535977	535977
099b7b1a-3de6-469f-9d75-ebc982b49c29	2026-01-07 05:09:08.730163+00	8	23.9	923662	923662
da23b8c3-57fc-4e03-bcd2-3871b2ca54f3	2026-01-07 05:09:32.665859+00	18.7	24	776715	776715
3c08e52a-410a-4be6-9a50-cd3db8a9a1b6	2026-01-07 05:09:59.557191+00	7.4	22.1	687754	687754
87360bae-005d-4c54-91d2-35c2c8fd8f29	2026-01-07 05:10:58.138128+00	9.9	22.1	389967	389967
f102137f-8793-461a-a00b-c2be1a204ed4	2026-01-07 05:11:09.611422+00	17.2	22.1	975841	975841
fa4ea5e3-39f6-4e3e-be03-f0142b948c8d	2026-01-07 05:11:59.394894+00	6.9	22.2	231550	231550
f605e1c6-fe5b-4300-96ef-e94bcd321138	2026-01-07 05:12:11.088223+00	73.6	22.2	875339	875339
434c9741-f91d-4af3-8f29-94dbb199d0ae	2026-01-07 05:12:59.195783+00	8.1	22.1	212916	212916
a49e9666-5387-4f31-99b2-df563691442a	2026-01-07 05:13:08.695859+00	14.1	22.1	333793	333793
47b91c41-4822-4e77-b46a-6aaca7bf9d5a	2026-01-07 05:13:58.256687+00	7.9	22.1	245647	245647
616daaf5-bb74-4b8f-bdd7-148db50394f4	2026-01-07 05:14:09.7091+00	15.2	22.1	815248	815248
4888c51c-fee6-4b2f-ad42-330d97fe1f77	2026-01-07 05:14:59.371871+00	8.8	22.1	241068	241068
4258194a-3a08-40e5-a608-8382d6c8add5	2026-01-07 05:15:11.033942+00	19.9	22.1	682005	682005
787c90eb-6962-42da-959b-74ef787b571e	2026-01-07 05:15:58.225187+00	9.7	22.2	656257	656257
8a58a62f-5cf8-482b-85de-77e250265bf4	2026-01-07 05:15:59.374946+00	9.9	22.1	261565	261565
e4e85d0b-b9bf-4a22-ae2b-857fbb3f8868	2026-01-07 05:16:09.696901+00	18.5	22.1	1387206	1387206
261f0c1c-d664-486a-8f7d-fdaf5b0508c7	2026-01-07 05:18:08.937082+00	22.5	22.2	579675	579675
6c5af035-d7f6-4201-916d-8ede66910366	2026-01-07 05:18:32.159826+00	7.9	22.1	899106	899106
1f7b2c48-0007-4d7f-8cb9-59c0f226a5a1	2026-01-07 05:19:08.568992+00	18.7	22.1	259855	259855
a4bfbc6f-bb02-4a69-b0c0-09e2bcfcb9d8	2026-01-07 05:19:59.42728+00	10.9	22.2	516414	516414
3b1ce9dd-57f5-4170-80d0-82493d17e0ae	2026-01-07 05:21:09.647188+00	15.9	22.3	885991	885991
e69558c9-57f2-42fa-9277-4cdee442e4ef	2026-01-07 05:21:58.287954+00	11.1	23.1	677761	677761
3e81dd12-f9f8-492e-99d5-2ddfaa10c984	2026-01-07 05:23:08.93531+00	10.2	24.5	5044064	5044064
62ca475f-5285-4e5f-a5f5-5e766810b1b2	2026-01-07 05:23:59.383888+00	9.5	25.9	211348	211348
b3034321-7fe6-4325-8a49-a38c092cab46	2026-01-07 05:24:11.152275+00	22.3	25.9	542327	542327
3a4d9d01-b648-4e67-82bc-98addcfaeca7	2026-01-07 05:26:09.093215+00	16.9	22.2	480280	480280
4cd1426a-5f9a-4594-aa05-9abef2a53a2d	2026-01-07 05:26:58.609029+00	8.8	22.1	258746	258746
3d8552fe-3564-404a-b6ce-d9fafd6a7662	2026-01-07 05:26:59.815109+00	6.3	22.2	397831	397831
a2b2cd9b-4f87-4bdf-8977-8e0643eb4a91	2026-01-07 05:27:11.52999+00	23.6	22.2	996597	996597
4d5c44b0-6508-4a71-840c-f0cdcb369c44	2026-01-07 07:56:54.043948+00	6.9	22.4	14927	22322
34bc27b5-4167-4454-96e2-33a52f7767c1	2026-01-07 08:37:54.40215+00	7.8	30.8	13377	4556
84fbc165-9b25-43fc-8d2c-d5470bb8d1bc	2026-01-07 09:20:33.258188+00	14	30	9178	227972
ecb86808-e3ac-4850-a224-25a13ea1ff2f	2026-01-07 09:50:52.188568+00	4.4	24.6	64519	64519
65cd6d44-80e5-4640-8f1f-f3d517777c40	2026-01-07 10:09:12.629047+00	23.8	28.1	1784757	88638
955d88a2-3e68-49ff-901a-15ecf47d2250	2026-01-07 10:31:52.175736+00	7.1	27.3	217620	217620
cb8abf3a-d1c2-4f9b-9587-62293238aae0	2026-01-07 10:48:52.090455+00	22.3	31.5	7896698721304	7896698721304
5af1c0fc-8add-419c-b806-dd468d2d9e0a	2026-01-07 11:05:52.055275+00	29.7	33	90797	90797
972df758-e783-4bc2-85ba-2877dd15f2cd	2026-01-07 11:25:13.654431+00	25	33.9	9808	30802
c0b4732e-7e1f-436b-888f-64ca77931127	2026-01-07 12:05:24.798161+00	50.5	35.4	402609	402609
289c686a-6081-4a40-9a5d-0a40fea0ec00	2026-01-07 12:05:52.099034+00	57.8	35.3	8593335	8593335
716aa3bd-7ffc-47da-a949-c10e2c7e7e4e	2026-01-07 12:06:13.187136+00	58.8	33.1	3374795	3374795
50c302e2-5e35-4b3e-825d-c50f87b2602f	2026-01-07 13:05:52.078702+00	31.7	30.9	130557	130557
4d9824f4-e5de-4258-bdaa-16ae359e78e7	2026-01-07 05:01:34.112065+00	72.9	31.6	4367841	4367841
233e8854-63a1-4158-a045-af34c2d97382	2026-01-07 05:01:52.256321+00	39.2	32	1177624	320055
075e01ca-5080-4a49-ba86-abdacd588221	2026-01-07 05:01:53.497849+00	39.2	32	553395	553395
5d75c2f8-7131-4b5d-abb4-a6d9427c7cc4	2026-01-07 05:02:52.257622+00	28.9	25.5	33927	19077
d5d3a9f2-ce8b-42ce-8f41-3bc127d55ac2	2026-01-07 05:03:00.03907+00	24.2	25.6	1305441	1305441
0dedfd8b-4c07-4cfa-a3c1-fc2caaa94c20	2026-01-07 05:03:01.215861+00	30.7	25.6	551268	551268
f45882d1-ffb9-45e6-b1bb-5066a05aacd8	2026-01-07 05:04:12.47721+00	76.5	25.7	3109348	3109348
6249cfe7-d04b-40e3-b827-5edd051f4335	2026-01-07 05:04:58.558633+00	34.4	25.6	2241182	2241182
0a3f6201-0c62-42ea-811f-abf970a67b52	2026-01-07 05:06:09.15083+00	21.3	27.1	696374	696374
a00af18f-7e67-4082-8731-41a21b318666	2026-01-07 05:06:59.487118+00	8.8	27.2	498382	498382
a3edd2a0-1db4-4741-aa6c-9e960414e8df	2026-01-07 05:07:58.337478+00	12.1	24	674557	674557
e0158bd7-439a-49f4-8f34-80380b1286d3	2026-01-07 05:08:32.131314+00	13.2	23.9	785665	785665
e446c8c6-958c-4dd7-bec6-241ee6b806f7	2026-01-07 05:09:32.05188+00	18.7	24	926308	926308
71c73ab8-5414-4f57-ac8e-65f7f34b04e1	2026-01-07 05:09:59.468537+00	7.4	22.1	247033	247033
34d6e80c-ca8e-4761-8479-44bb16733a40	2026-01-07 05:10:32.727306+00	11.6	22	877564	877564
7e2e4d1f-4404-42a5-b694-4a9af78bf040	2026-01-07 05:10:59.304227+00	9.3	22.1	277166	277166
782e0c7d-722d-4661-bda4-388533325732	2026-01-07 05:11:11.020377+00	31	22.2	753853	753853
1fec32b3-22d5-42ff-9142-5f20a073bb53	2026-01-07 05:12:08.91629+00	15.1	22.1	786765	786765
433c331a-4592-427d-9ab8-6e4d60d06493	2026-01-07 05:13:08.670804+00	14.1	22.1	871831	871831
548e167a-c2c1-49e3-b7bb-631cc6e79411	2026-01-07 05:14:08.935115+00	15.2	22.1	392773	392773
aeba37d7-bd27-467d-ab66-82f1202ddb0a	2026-01-07 05:14:40.790676+00	17.7	22.1	898851	898851
a2ee6650-842d-4071-9e78-61fa65450afc	2026-01-07 05:15:09.65368+00	16.9	22.1	871660	871660
764e9cc2-f69e-4ede-a7fb-22f3cef811d0	2026-01-07 05:15:58.220063+00	9.7	22.1	314730	314730
a04fb775-68cc-440e-ae7c-415a5101ab0a	2026-01-07 05:16:08.932042+00	18.5	22.1	412770	412770
458cb542-a777-4865-91a1-8375a1c64aab	2026-01-07 05:16:59.279296+00	7.7	22.1	326202	326202
74e9d892-d77b-4925-bec9-cab36a9b8d39	2026-01-07 05:17:09.629514+00	9	22.2	953614	953614
dbb222fa-162c-4591-bf1c-009ea908a142	2026-01-07 05:17:58.345142+00	8.1	22.2	631527	631527
25a88494-7a42-42b8-ab2c-9cffad6b217d	2026-01-07 05:18:40.821128+00	7.9	22.1	41918	41918
6a669ad5-1bd3-41b6-b997-6737a325f01d	2026-01-07 05:19:09.340168+00	18.7	22.1	952891	952891
e2780ea8-c065-4bfc-9f9d-128b45f8286d	2026-01-07 05:20:08.812074+00	8.1	22.1	691009	691009
91f93251-6029-4a05-afcf-5dc5507a6dd3	2026-01-07 05:20:58.279792+00	10.3	22.1	215881	215881
f4fd848e-fc13-4891-819c-a401e9f20b9f	2026-01-07 05:20:59.332144+00	8.5	22.1	590303	590303
1085f20f-f683-471a-930c-053898b2bac1	2026-01-07 05:21:59.355634+00	11.9	23.1	197809	197809
3a7c06ac-9de7-4c52-bfd1-1e5171069315	2026-01-07 05:22:09.619925+00	14.6	23.1	790963	790963
74340d20-f4cc-4e41-8271-564830467cc5	2026-01-07 05:22:59.380975+00	6.4	24.2	657447	657447
44943860-f320-4985-8001-e4df299dd9f2	2026-01-07 05:23:11.116756+00	74.6	24.9	525534	525534
88f0206f-89d3-4448-8816-d1799d7a78ab	2026-01-07 05:23:59.468601+00	9.5	25.9	399591	399591
49b4e692-50d3-4095-82f0-8ead4a29802b	2026-01-07 05:24:32.164769+00	8.4	25.9	842018	842018
b7f4fbb4-24d2-47ff-9f4c-eb4fc2575c4e	2026-01-07 05:25:58.443377+00	9.9	22.3	629448	629448
e5229458-5c35-4f6d-8e9c-dc94b24de320	2026-01-07 05:25:59.453065+00	7.7	22.2	982341	982341
4bc7b278-320a-4596-af99-bb68a6a700a0	2026-01-07 07:57:54.089621+00	9.1	22.5	16242	11795
b6cdd943-8ac5-4f44-a1c7-861775c7021f	2026-01-07 08:38:54.400318+00	14.1	27.7	6086	3338
508bfc1b-f2fc-44a9-a6ce-94c3afde0dc1	2026-01-07 09:21:33.493985+00	6.2	30	1890	2022
d8d3e86f-c66b-4a1b-af54-c7f880ef8fe7	2026-01-07 09:51:12.361307+00	10.4	24.5	3214	2197
4fdd5f2f-cc61-4893-93c5-1090e40294c4	2026-01-07 10:10:12.642341+00	25.5	31.9	6382	18966
5a960b14-7520-4a1c-adc9-3c2027d6517d	2026-01-07 10:31:52.175664+00	7.1	27.3	69631	69631
92300f55-9daf-4774-9b98-43bd65701fa1	2026-01-07 10:49:13.224246+00	21.7	31.5	1247726	49978
08553601-e011-481e-98fc-2cea7af2f614	2026-01-07 11:05:52.058973+00	29.7	33	12649	12649
98539772-3533-4335-8550-d03ce9a0aca7	2026-01-07 11:25:52.059518+00	33.4	32.6	427288	427288
098611b3-7ded-4a2f-829b-35b1df855384	2026-01-07 12:05:52.098414+00	57.8	35.3	2713479	2713479
c375f31e-c72d-499b-84f5-bca1f18beacf	2026-01-07 13:05:52.083716+00	31.7	30.9	92792	92792
6dbbb572-84e9-4437-8d66-ab478ebb377c	2026-01-07 05:02:59.199803+00	12.6	25.5	478955	478955
e6a72ced-da20-4e53-9de3-dbf4f2dab64a	2026-01-07 05:03:52.270947+00	29.7	25.6	2205202	93045
fff261a7-5e6c-4c56-a083-58dd78ee5b3b	2026-01-07 05:03:59.883058+00	28.4	25.6	2236119	2236119
2921bd08-a975-4d20-b21d-f392859982aa	2026-01-07 05:04:32.290827+00	29.8	25.7	1436650	1436650
0f83843b-264f-41a6-bce6-53ab1aec621d	2026-01-07 05:04:52.284959+00	34.4	25.7	2760404	161626
33803084-5ee1-4fb1-afe3-68d3944ab0e0	2026-01-07 05:04:59.836413+00	32.9	26.1	541215	541215
bf751b37-067f-4874-b97f-83ec099581d7	2026-01-07 05:05:32.26726+00	31	27.3	795084	795084
b95cfed4-dbdd-4844-97aa-b1566d6e4986	2026-01-07 05:05:52.303999+00	17.8	27.1	22839	7255
9c705aad-544d-4ec6-8bea-e70b9c7b20a6	2026-01-07 05:05:59.623162+00	7.9	27.1	439886	439886
a3320fc7-c979-475d-82a9-c5b876808265	2026-01-07 05:06:09.991441+00	21.3	27.1	700698	700698
b9860d82-4d4a-4b12-9677-e6299d41fc39	2026-01-07 05:06:52.302309+00	23.5	27.2	36517	20077
ecdf9a8b-84b9-4368-a04a-a5c0ad33c617	2026-01-07 05:06:59.38924+00	8.8	27.2	391181	391181
00bab59a-486b-4d2c-ab6d-2cd9eb59c2c4	2026-01-07 05:07:08.909809+00	10.9	27.1	829171	829171
3a1984cd-b042-4ef5-adb4-492b56340552	2026-01-07 05:07:09.768664+00	10.9	27.1	1241586	1241586
86d48bac-0968-4f16-9cd9-cfbc29237e64	2026-01-07 05:07:52.32826+00	14.2	23.9	201688	33262
38cbfa34-b238-4ac8-b5dc-ecee7783cd05	2026-01-07 05:07:58.288582+00	12.1	24	634837	634837
dd9e75aa-e6f1-4e57-8961-eb931e447d52	2026-01-07 05:07:59.330309+00	7.8	24	318644	318644
5f82165a-4148-4c32-9da1-381830524077	2026-01-07 05:07:59.423801+00	7.8	24	411725	411725
38d7c694-34ba-4ec0-872b-946b718b04fd	2026-01-07 05:08:08.906451+00	15.1	24	1027241	1027241
92bb1abf-cadd-4448-9271-13dba6823b2b	2026-01-07 05:08:09.690604+00	15.1	24	1088475	1088475
d5b72871-c155-451a-8643-8b6950bb580b	2026-01-07 05:08:52.331267+00	13.1	23.9	149172	48060
7c5dbade-6488-4655-b505-ac0bf2a5e4db	2026-01-07 05:08:59.21338+00	9.4	24.1	240327	240327
b473b0d3-eef6-46be-898d-bf1418dac298	2026-01-07 05:08:59.216702+00	9.4	24.1	281090	281090
3520170b-b7e3-4d9a-9d9d-44acc9e1cedc	2026-01-07 05:09:09.489038+00	8	23.9	707648	707648
b088b1d1-3fcc-4b1f-be64-0eec25641dc5	2026-01-07 05:09:10.895486+00	24.6	24.1	707429	707429
f91665e7-6eb2-48d1-8d83-0f874ecaffc0	2026-01-07 05:09:52.389942+00	19.5	22.1	63007	19795
f3f180a3-b849-4f35-a177-922522dbe344	2026-01-07 05:09:59.465877+00	7.4	22.1	194570	194570
31f0600d-6db1-41d2-b385-e0aab2f823e3	2026-01-07 05:10:10.502006+00	70.9	22	1156798	1156798
c2850784-2bfd-4634-b23b-0199f3f3ada2	2026-01-07 05:10:11.775593+00	70.9	22	735825	735825
e4db9ebb-e828-4efe-9bbe-0d8d87b0f34c	2026-01-07 05:10:32.075727+00	11.6	22	881493	881493
ad7ff420-61af-4f38-a339-2278b0013549	2026-01-07 05:10:52.368657+00	16.4	22.2	41314	17121
adf1140a-6977-41ef-b7dd-c924b1fd23c1	2026-01-07 05:10:59.302463+00	9.3	22.1	324526	324526
07eb5481-5237-40d4-b2ab-2cac80832ca1	2026-01-07 05:10:59.39564+00	9.3	22.1	513804	513804
a0200d4d-1490-4a36-821c-c2975b2adb2b	2026-01-07 05:11:08.897777+00	17.2	22.1	1955441	1955441
c5c6a640-312e-4e31-ab9f-af7670e40956	2026-01-07 05:11:32.067175+00	11.2	22.1	983635	983635
da7db96f-f1d8-4883-a509-697af90c0c73	2026-01-07 05:11:52.370856+00	12.1	22.2	203783	31576
05914b20-b62b-4399-a0b3-b3ddae03794d	2026-01-07 05:12:32.10731+00	20.8	22.1	791627	791627
89566aa1-cbb5-4465-8fa0-2eb1e89c6100	2026-01-07 05:12:48.945944+00	7.1	22.1	29108	29108
482e801d-60e1-4ca1-9327-fd7211a75bb9	2026-01-07 05:12:52.419967+00	12.3	22.1	141906	22833
d36719c8-90f4-4dff-80c8-c887d0d50bb1	2026-01-07 05:12:59.198454+00	8.1	22.1	304536	304536
d66ab949-6615-4803-9575-1244415ea3c7	2026-01-07 05:12:59.27482+00	8.1	22.1	487298	487298
f2d9498e-13e6-4c40-b1dd-15ae745b447e	2026-01-07 05:13:10.682102+00	15.9	22.1	672966	672966
95b159f0-f30a-49c9-90e7-1a411b4005a3	2026-01-07 05:13:40.762584+00	10.1	22.2	720105	720105
3592fe95-5567-49c6-9339-256b6464cfae	2026-01-07 05:13:52.431956+00	14.1	22.3	127936	17271
143167c5-2d87-4956-9ba5-294e224bbf1f	2026-01-07 05:13:59.41811+00	8	22.2	327109	327109
328aa8b7-e53d-4a68-88b6-c5590986a75b	2026-01-07 05:13:59.501263+00	8	22.2	434798	434798
4b4ed50c-094c-4a28-99a3-d9f555a28131	2026-01-07 05:14:11.102448+00	30.7	22.2	620902	620902
a0dbe946-c926-4854-8a6a-036ab7091692	2026-01-07 05:14:32.048468+00	17.7	22.1	882916	882916
ded23f89-8245-45fc-a863-d30ab226cdc6	2026-01-07 05:14:52.45049+00	13.4	22.1	65340	14965
fc54015b-72f6-44e4-8bb3-c49c6657755f	2026-01-07 05:14:58.214683+00	10.6	22.1	691705	691705
776d72d5-b6bd-423f-94c3-a43763f7b3a8	2026-01-07 05:14:59.374827+00	8.8	22.1	596658	596658
6eab53eb-1308-45d3-9882-1a094ca02aeb	2026-01-07 05:15:08.917136+00	16.9	22.1	975896	975896
1157ace9-a960-469a-b2c7-79a7fa1fcb6a	2026-01-07 05:15:52.407158+00	12.8	22.1	68144	15935
f728c3cc-2f33-497e-9bd7-02cb080e2d8c	2026-01-07 05:15:59.463829+00	9.9	22.1	386156	386156
0090dcdd-5b10-47e6-9388-d0d802bfde49	2026-01-07 05:16:08.937437+00	18.5	22.1	732996	732996
cb0695b3-3dcf-45aa-901b-17cd406664de	2026-01-07 05:16:11.068185+00	73.5	22.2	638450	638450
82804e63-7a79-486e-a7c2-d7187955f00d	2026-01-07 05:16:32.740978+00	19.2	22.1	858524	858524
8639d769-4035-43b0-8f7d-96469768221a	2026-01-07 05:16:52.47011+00	12.3	22.1	104680	16007
903358b9-04ce-47a8-9a6a-48329848955a	2026-01-07 05:16:59.278177+00	7.7	22.1	159296	159296
bb8188eb-8a04-4eef-87a1-afa05898b1fc	2026-01-07 05:17:08.869504+00	9	22.2	712123	712123
b0b221f3-2b95-4475-8576-dad12c9f47fd	2026-01-07 05:17:11.039924+00	75	22.1	777291	777291
3ef44264-8c0b-4be7-89f0-822c37bafb33	2026-01-07 05:17:32.685215+00	9.2	22.2	965559	965559
1c1b9517-809a-4e8f-ad07-80a2a26981d4	2026-01-07 05:17:52.482219+00	16.1	22.2	66440	19513
d2746d49-0823-4c73-b9e4-0a34fbd30f57	2026-01-07 05:17:59.535061+00	8.2	22.2	439945	439945
e8e436ba-7f3c-40c1-9c23-b2e2e7006089	2026-01-07 05:18:08.930902+00	22.5	22.2	865964	865964
d24197db-bbe2-49a7-a227-51ff29402f1a	2026-01-07 05:18:11.111505+00	18.4	22.2	711293	711293
82d07bbc-dd5c-454b-a088-faf415c75b81	2026-01-07 05:18:52.484422+00	12.1	22.1	84369	18604
ca3dd0d5-20d5-436c-87b7-33299bae20fb	2026-01-07 05:18:57.993175+00	9.8	22.1	835314	835314
dfb04dab-c90e-4887-a83b-90d737e94d9f	2026-01-07 05:18:59.065912+00	7.1	22.2	697102	697102
67770674-d170-4946-a6a9-a615b542e09f	2026-01-07 05:19:08.59205+00	18.7	22.1	947012	947012
87587c4d-0c24-4667-a852-92e9ff685a72	2026-01-07 05:19:52.502389+00	19.6	22.1	51657	12564
8a154b3d-91ea-4180-9c15-8133058a12a9	2026-01-07 05:19:58.281441+00	10.1	22.1	343715	343715
a007a1bb-e72b-494f-bb5d-6104c4acf724	2026-01-07 05:19:58.287717+00	10.1	22.1	446911	446911
a5740c9d-ae24-4f93-9f3a-9cd7bb655802	2026-01-07 05:19:59.330903+00	10.9	22.2	232181	232181
86a28f06-d608-4cfe-9192-91ed63b084ab	2026-01-07 05:19:59.337392+00	10.9	22.2	346895	346895
2e4b5b18-f135-42af-b6cc-859e318efbaf	2026-01-07 05:20:09.629948+00	8.1	22.1	974598	974598
4cd2ae53-0575-4ca9-8617-0b5ef0101232	2026-01-07 05:20:11.012402+00	22.9	22.1	693260	693260
414f4c5b-c31e-4d9c-adbb-da4f9a8e84fb	2026-01-07 05:20:32.185956+00	19.3	22.1	712530	712530
5c02a14a-f0ac-468a-a7ce-8e02ea695d35	2026-01-07 05:20:52.480326+00	13.3	22.2	80287	86537
d501f1c3-efa9-4b7f-9b79-2b50565aeca5	2026-01-07 05:20:58.360007+00	10.3	22.2	488512	488512
b21fb84f-e092-4660-8bc0-a455c9fffe79	2026-01-07 05:20:59.333541+00	8.5	22.1	553627	553627
9c1af08e-7adf-4ef7-b0a5-de334927c84d	2026-01-07 05:21:08.865112+00	15.9	22.3	1456501	1456501
63275886-ba7d-458d-a33c-7e44ad79f064	2026-01-07 05:21:32.252063+00	15.6	22.9	917126	917126
f5376933-fdc9-4a73-86f1-5192fa02ef48	2026-01-07 05:21:52.525208+00	13.9	23.1	107558	157229
51a0bbdd-69ed-4ca5-ac12-f379d5bc6ad6	2026-01-07 05:21:58.249939+00	11.1	23.1	586232	586232
5f24291d-fca8-43bd-97f0-82115e366bc2	2026-01-07 05:21:59.357666+00	11.9	23.1	566779	566779
90635279-1967-4da3-81e6-baa3384986e8	2026-01-07 05:22:08.860969+00	14.6	23.1	892961	892961
70173aea-59a4-4e7a-86c4-6ea487724a14	2026-01-07 05:22:11.003236+00	20.3	23.1	687357	687357
25043a3b-003d-4324-be3e-eac8515c2ef9	2026-01-07 05:22:32.140867+00	13.6	23.4	673886	673886
2de3f17f-16eb-490a-a032-122d47ec2580	2026-01-07 05:22:49.023847+00	13.6	23.4	76169	76169
69228446-fe45-4097-9813-8c0659bdd34b	2026-01-07 05:22:52.541545+00	18.3	24.2	141040	59190
0184409e-288c-4b10-ba8a-1d5931e34d7b	2026-01-07 05:22:59.379564+00	6.4	24.2	440801	440801
e32d1fa3-a170-47b7-b843-5c96b5448bbe	2026-01-07 05:23:32.214793+00	21.2	25.8	809426	809426
c46c38f6-2dd0-4521-9e2b-5371b1c5a210	2026-01-07 05:23:52.559672+00	13.2	25.9	32681	12276
c9ff8446-c221-479b-ba98-f96288a383ea	2026-01-07 05:23:58.249305+00	11.3	25.9	668793	668793
86cec419-1f1c-43d2-a87a-1152e41b2238	2026-01-07 05:23:59.382647+00	9.5	25.9	291505	291505
4b8829bb-d20d-4c6c-bae5-715384f34428	2026-01-07 05:24:08.986358+00	14.4	25.8	936756	936756
84e13912-3953-4474-86dd-23116b30b487	2026-01-07 05:24:09.719619+00	14.4	25.8	1358290	1358290
e1dbddce-3e06-4a8e-b76e-cd8ac322fe4b	2026-01-07 05:24:52.528182+00	19.1	25.9	28164	11918
094a3a18-7781-43b0-8fb2-1fad2a1bdd94	2026-01-07 05:24:58.303633+00	9.2	25.9	212462	212462
51d80aa1-034f-42a4-a37f-f7d621f04fcc	2026-01-07 05:24:59.659241+00	8.8	25.9	419087	419087
f723aec6-217a-4ee5-b4f0-b89431b4452d	2026-01-07 05:25:09.206968+00	17.7	25.8	831150	831150
5a8f9c57-6554-4001-b450-4dc30023832c	2026-01-07 05:25:59.548594+00	7.7	22.2	407429	407429
3c3fa279-e3df-46c8-9ed6-14e5705a4e39	2026-01-07 05:26:58.706782+00	8.8	22.1	404172	404172
3a02250a-d62f-47e6-9ee8-0eb5962718a4	2026-01-07 05:27:58.62116+00	8.4	22.1	724126	724126
472f46bb-bc3f-4e0b-aa46-a596a6a679e5	2026-01-07 05:28:09.52479+00	17.4	22.2	767673	767673
709f6e6b-4c80-400b-9d89-f98a88e0b447	2026-01-07 05:28:32.24747+00	8.6	22.2	788947	788947
9e1f9e8a-4bd0-4ac3-8f0d-a6ee95f8894e	2026-01-07 05:28:59.489252+00	9.8	22.1	234688	234688
3356676b-707d-4ca0-8cd9-3c02493f48c1	2026-01-07 07:58:54.105745+00	8	23	17788	10970
29477941-1f53-4d07-9352-7be773ef45e4	2026-01-07 08:39:52.045942+00	8.7	29.8	135756	135756
1350db28-79a2-40aa-8cc7-9859e0ba1452	2026-01-07 09:22:33.544711+00	11.4	29.9	25850	529888
f073a306-2fb4-42cd-83bf-2349c853a9aa	2026-01-07 09:51:52.222271+00	4.4	24.5	77786	77786
28707b74-6c40-4f31-b514-803623a22de2	2026-01-07 10:11:12.666292+00	14.7	32.1	667689	69468
e0eba726-b295-42c0-bc39-13881d6849c2	2026-01-07 10:32:12.940345+00	5.4	26.5	5487	3500
239124e8-ab50-4d84-a777-e95438faf665	2026-01-07 10:49:52.109381+00	21.8	31.6	61606	61606
d732bcc8-82b8-4211-8bbe-c6df5c7dbacd	2026-01-07 10:49:58.693359+00	21.7	31.6	341727	341727
7f8a8f3a-307b-45c8-97f5-7baf562d8396	2026-01-07 11:06:13.351326+00	40.8	34.4	1008447	88644
58dfb568-b39a-4fca-a083-baaaae6d323a	2026-01-07 11:25:52.06466+00	33.4	32.6	49444	49444
32b1711f-bfe4-468a-9a86-c980396861f9	2026-01-07 12:06:52.139956+00	59.2	33.1	3117200	3117200
93854c45-cbf7-432b-b56f-4ccf141005ea	2026-01-07 13:06:52.095121+00	38.3	29.2	407910	407910
2e375f46-9f6c-40c8-bc21-7ff6c2e59909	2026-01-07 05:24:58.310327+00	9.2	25.9	539525	539525
c4ee012c-0433-4715-b6cf-438eabdcb2aa	2026-01-07 05:25:10.082487+00	17.7	25.8	708717	708717
8fc86d7d-d4a1-4be4-9459-72ffae4b9d58	2026-01-07 05:25:52.542528+00	12.9	22.2	92874	15184
d8fc0a2a-9b35-47f0-9b8f-b8c5454ed6cf	2026-01-07 05:25:59.452483+00	7.7	22.2	400185	400185
0aeb3a06-9770-4489-87f0-05e4c111ae98	2026-01-07 05:26:11.280436+00	72.6	22.2	662553	662553
18ea2028-7fee-44a6-9d6f-7a296b6cdb77	2026-01-07 05:26:52.576296+00	13	22.2	103970	15467
8efee243-9fba-41ad-8e6c-80c260ce5499	2026-01-07 05:26:59.744245+00	6.3	22.2	318975	318975
6d44b223-1411-4f23-80c0-26a34d07cedd	2026-01-07 05:27:09.299453+00	7	22.2	760607	760607
fde5c250-5877-4dd4-89ee-4af1d5e3ebad	2026-01-07 05:27:10.13781+00	7	22.2	1205413	1205413
11d76663-5c9b-4212-a1d2-bbc89f8d5685	2026-01-07 05:27:52.542414+00	13.8	22.1	91092	14604
480679f8-54da-4709-9ec2-24322ebd2764	2026-01-07 05:28:00.059366+00	9.1	22.1	369584	369584
175d5606-5287-4fed-8a8e-4f6f008b291f	2026-01-07 05:28:10.403453+00	24.4	22.2	940014	940014
5aaafc92-a6db-4dfd-9e0e-6074e086004b	2026-01-07 05:28:11.741793+00	24.4	22.2	522120	522120
b4dec2b4-2a80-4137-8198-3ac29a3199af	2026-01-07 05:28:52.55776+00	13.1	22.2	38648	11600
34220d15-25fc-41c2-8c3f-cd2fe0dcc302	2026-01-07 05:28:58.326359+00	28.5	22.2	305632	305632
5cb94cb7-41b1-4584-b76f-52886d958ead	2026-01-07 05:28:59.498951+00	9.8	22.1	336744	336744
d47a08e3-2b73-4673-8a86-1f0b816733cc	2026-01-07 05:29:09.1412+00	13.9	22.2	896174	896174
19056f08-1761-4d44-9a7b-5e06295e8ff9	2026-01-07 05:29:09.141198+00	13.9	22.2	543923	543923
c9b27eb2-74a1-465a-9a77-79558b97cebe	2026-01-07 05:29:09.954086+00	13.9	22.2	819878	819878
aa92e826-efc3-4c25-a1d4-fa0bef0b17c5	2026-01-07 05:29:11.427094+00	34.8	22.3	692210	692210
d7a4d669-b2ae-43a5-b8ed-eb6503dd3918	2026-01-07 05:29:32.261498+00	23.9	22.2	723820	723820
fdb2bbb1-f6a4-475d-a56c-f0f398bc6cb9	2026-01-07 05:29:52.609795+00	10.9	22.1	84790	14597
1166b7d9-2643-4552-839c-f662ea1c976c	2026-01-07 05:29:58.393574+00	8.8	22	533975	533975
0cfc5903-73fd-4a68-b922-61be409281f3	2026-01-07 05:29:58.438655+00	8.8	22	749025	749025
2138a4e3-9486-44b0-9cfb-9013f73c0f77	2026-01-07 05:29:59.538316+00	8.2	22.1	274169	274169
35055989-0f38-4125-8b62-b788b44373a6	2026-01-07 05:29:59.602871+00	8.2	22.1	310143	310143
fd679c74-a909-46d5-a135-e49a559a84b3	2026-01-07 05:29:59.641919+00	8.2	22.1	677746	677746
62729d0e-cf16-495b-a8ec-0fb86af51dba	2026-01-07 05:30:09.24267+00	22.3	22	328170	328170
6e4476fe-6aa4-4011-91e5-7bbe51431b13	2026-01-07 05:30:09.250902+00	22.3	22	759723	759723
558a1521-e40c-4395-a454-f36a4a954461	2026-01-07 05:30:10.072162+00	22.3	22	1332613	1332613
6898acc1-c919-4c38-86b4-74d8f23a1742	2026-01-07 05:30:11.566357+00	20.9	22.1	612850	612850
9b98b1d4-bed1-4dbf-80f2-6d85f9b7a468	2026-01-07 05:30:32.159147+00	11.7	22.2	752616	752616
f39c6586-9c87-401e-a646-bd2aeb5a7453	2026-01-07 05:30:52.58342+00	13.1	22.1	77357	12843
14be60c0-09fe-429d-b74a-aefecc187b04	2026-01-07 05:30:58.380658+00	11.7	22.2	67224	67224
28afd201-dad4-4a9e-a81d-76b5d93b3901	2026-01-07 05:30:58.395457+00	9.1	22.1	676983	676983
4be71df9-f1c9-4169-8494-98a01644277c	2026-01-07 05:30:59.474646+00	5.8	22.1	158216	158216
8acbc45f-b96e-4cb2-8ffd-658fbe7bf067	2026-01-07 05:30:59.478167+00	5.8	22.1	307020	307020
9c199191-3586-4d36-891f-6da002333a9d	2026-01-07 05:30:59.58696+00	5.8	22.1	846206	846206
a55a0c2d-e7b5-429f-b22e-e7f12fec045f	2026-01-07 05:31:09.000212+00	17.3	22.1	542273	542273
eeb82435-67a5-4fd3-b40d-8d0ea29d5a65	2026-01-07 05:31:09.003041+00	17.3	22.1	871649	871649
586afdc3-6963-4496-a3cc-b2e7dde8f7f2	2026-01-07 05:31:09.817611+00	17.3	22.1	768215	768215
9d1b7cdf-2eff-4522-b9b0-102672b8ff23	2026-01-07 05:31:11.262983+00	22.7	22.1	812087	812087
87e86f68-8768-4b6a-a8ee-f51e1bc8c45c	2026-01-07 05:31:32.221638+00	11.9	22.2	994903	994903
e43a7f9d-55c8-4713-bef0-2a32632e827e	2026-01-07 05:31:52.624574+00	12.5	21.9	74500	13052
00e093ba-e726-46d1-8a2e-bff2f024ce38	2026-01-07 05:31:58.247799+00	10.9	22.2	269002	269002
ef34d707-9cd1-4db6-a2bb-56538b0fce7b	2026-01-07 05:31:58.252876+00	10.9	21.9	707463	707463
df7a5c52-edae-4f73-9036-77e6d9e9dedf	2026-01-07 05:31:59.403111+00	7.3	21.9	234344	234344
3f495c67-4758-4238-844d-9a190d3bd362	2026-01-07 05:31:59.405527+00	7.3	21.9	342765	342765
89e4c0cc-407b-47e9-a2c3-31030755eced	2026-01-07 05:31:59.487589+00	7.3	21.9	597009	597009
59303ffe-5ace-4078-bae9-f5d770879244	2026-01-07 05:32:09.055922+00	7.8	22	640590	640590
b1710527-7b03-4f03-ac82-e472aedb9b60	2026-01-07 05:32:09.088709+00	7.8	22	730581	730581
8452fafa-4a5c-4491-982e-441b27ca7f22	2026-01-07 05:32:09.868651+00	7.8	22	759531	759531
2e9b16ce-a930-49c4-b000-b22ab65d452f	2026-01-07 05:32:11.358872+00	18.8	22.2	716903	716903
e56d723c-13e4-4918-be5d-f5e98bd2ae09	2026-01-07 05:32:32.253486+00	8.3	22.1	741377	741377
646672dc-d6c0-44fb-b512-089c710b47f8	2026-01-07 05:32:52.601242+00	14.4	22.1	74346	12577
d09e1835-1fd5-4354-8049-e25cd64bddb7	2026-01-07 05:32:58.532554+00	10.1	22.1	556103	556103
3d216b51-a163-4c1d-b8e1-b9f665cc3c25	2026-01-07 05:32:58.539376+00	10.1	22.1	738295	738295
81489a91-a068-4356-b608-1c868df9cb03	2026-01-07 05:32:59.734951+00	9.3	22.1	190646	190646
af94f038-43c1-44a5-96cb-a8d53c779e1a	2026-01-07 05:32:59.736419+00	9.3	22.1	373677	373677
607034e1-45cb-44c7-83ee-822cbfc21ac1	2026-01-07 05:32:59.822155+00	9.3	22.1	440347	440347
201b9219-c0af-43ef-817a-5f35e9df9232	2026-01-07 05:33:09.240727+00	8.1	22.1	835188	835188
2a8d50f7-5bfd-45f7-9d00-c782940b296f	2026-01-07 05:33:09.241924+00	8.1	22.1	1108334	1108334
ecb5c717-f1eb-4a54-88ee-98fb64930640	2026-01-07 05:33:10.071528+00	8.1	22.1	772602	772602
da60c47f-6508-4bf0-9bf2-6ab69302e082	2026-01-07 05:33:11.489749+00	74.3	22.1	398802	398802
8129a977-9e59-42b2-92c3-b2907281835f	2026-01-07 05:33:32.224716+00	9.6	22.1	776801	776801
2df7d6d6-f531-48a2-888c-ae07ad82a97e	2026-01-07 05:33:52.61129+00	19.2	22.1	31925	11151
65bedb98-9846-41db-a02f-765b74af2c92	2026-01-07 05:33:58.241098+00	8.8	22	281849	281849
5c718dcb-7dc9-47b5-86ab-27bb025076c7	2026-01-07 05:33:58.281244+00	8.8	22.1	708240	708240
60723248-0ce0-415f-8508-73fc65df7941	2026-01-07 05:33:59.372224+00	8.8	22.1	240770	240770
a1fc2bf0-66f3-4156-8f7c-83e8000d246a	2026-01-07 05:33:59.374959+00	8.8	22.1	224366	224366
f673755a-c95d-4055-a630-d6fea1300a0a	2026-01-07 05:33:59.452875+00	8.8	22.1	412833	412833
f2676b50-ea49-4281-9163-6b8bea412ae3	2026-01-07 05:34:08.922898+00	7.7	22.1	880050	880050
c236eea4-b497-43ce-b698-cdf0db6b1d3f	2026-01-07 05:34:08.928372+00	7.7	22.1	814302	814302
fd5ff5a2-4534-4802-aa37-9c2a282ddeb7	2026-01-07 05:34:09.726531+00	7.7	22.1	1038456	1038456
0b397650-f061-4aea-b581-0b47fb4f1b2a	2026-01-07 05:34:11.160166+00	18.6	22	629085	629085
471551a9-c8e7-4d2c-b73e-033e3a299a3c	2026-01-07 05:34:32.212556+00	14.2	22.2	754621	754621
48d939d3-abfc-4703-b1cc-5a223a7d0811	2026-01-07 05:34:52.619744+00	11.8	22.2	67950	12188
244ec8e3-e486-49a6-b461-99e2c6a805b0	2026-01-07 05:34:58.277749+00	9.4	22.2	669131	669131
a4bdc45e-2e2a-417c-802c-ce165d842974	2026-01-07 05:34:58.282922+00	9.4	22.2	666110	666110
c652caa6-8644-4d22-bf15-ca284333570d	2026-01-07 05:34:59.474127+00	7.3	22.1	219570	219570
62f97285-83fa-4fc5-a78e-0ca216e9e4a7	2026-01-07 05:34:59.47413+00	7.3	22.1	344134	344134
5b8a5bec-bcab-401e-974a-a234f733bbb5	2026-01-07 05:34:59.559257+00	7.3	22.1	519070	519070
368ac1d1-bf3f-4f70-b7da-4ecb7f0c454a	2026-01-07 05:35:09.108736+00	19.2	22	758351	758351
50a38014-3565-49c6-9265-61fb95306153	2026-01-07 05:35:09.124344+00	19.2	22	967350	967350
1dc7eb50-102d-42f1-9fd8-7cd164376dba	2026-01-07 05:35:09.86321+00	19.2	22	926967	926967
f55cd851-bc77-4fdf-87be-5ebb05bb11ac	2026-01-07 05:35:11.265619+00	74.5	22.2	670489	670489
d6e9d70f-1557-4a12-ae64-becfbe873fe9	2026-01-07 05:35:32.38508+00	19	22.1	782913	782913
8b272b43-b8ee-4b22-af70-68605f66c1a2	2026-01-07 05:35:52.620499+00	13.7	22.2	83194	16093
34e3b598-3a2e-4dd3-ada7-3a2ec09321b7	2026-01-07 05:35:58.46073+00	8	22.2	599505	599505
636a273b-98f9-49c8-87ff-4bb09c3927f2	2026-01-07 05:35:58.504453+00	8	22.2	623696	623696
fa5d0102-f186-48e7-9452-4b21c7a6c9c3	2026-01-07 05:35:59.64664+00	7.4	22.2	257300	257300
b18a69d8-acc6-48fc-a98a-e2561d480298	2026-01-07 05:35:59.64754+00	7.4	22.2	387997	387997
edc84911-502a-45e9-b732-d023e4163f7b	2026-01-07 05:35:59.752183+00	7.4	22.2	1371502	1371502
c6920290-6fe8-4865-ace7-03d2fbd762d9	2026-01-07 05:36:09.28106+00	7.6	22.1	901249	901249
c20b86e8-6a24-4600-8c98-05c9f56aa34a	2026-01-07 05:36:09.280855+00	7.6	22.1	552059	552059
ba5612e8-49a5-4b3b-8288-e4f2ba0d32d3	2026-01-07 05:36:10.083927+00	7.6	22.1	1055808	1055808
3c80cb38-dd1d-42f1-9701-2edf7cd079fe	2026-01-07 05:36:11.506658+00	30.5	22.2	526372	526372
81b539c7-9f33-4c8b-a772-ca01e0f4768c	2026-01-07 05:36:32.249455+00	19.3	22.1	1388548	1388548
e5ea5b6c-00e9-4826-bde3-095de5679be5	2026-01-07 05:36:52.682512+00	13.9	22.2	71248	12188
3fec0ec6-e9f8-4e7e-9931-ef49d11631d1	2026-01-07 05:36:59.738604+00	7.6	22.1	439210	439210
1b5f085c-59fb-4b08-b729-212e84ee9b64	2026-01-07 05:38:09.00826+00	9	22.1	905136	905136
4c02b18e-78ec-4152-837c-43bf7558b75d	2026-01-07 05:38:59.426858+00	6.2	22.2	684250	684250
c0b0741a-4fb2-4ee8-a556-af04d4e58221	2026-01-07 05:40:32.409666+00	8.8	22.2	710908	710908
0635fa35-1d5b-418a-988f-2ec7ef14c679	2026-01-07 05:40:59.608408+00	8	22.1	505634	505634
b07bee35-98e6-4fdc-a9a8-71ed371dad5d	2026-01-07 05:41:09.012312+00	20.9	22.1	1129815	1129815
717ec751-ee5c-43ec-8620-388d808e9d23	2026-01-07 05:41:59.439232+00	9.4	22.2	211766	211766
22aa2b90-8740-4cdf-a469-6158525f9e37	2026-01-07 05:42:59.371212+00	9.1	22.2	320499	320499
af75f091-2af3-4139-beb8-6a2a1fed8872	2026-01-07 05:43:59.970667+00	5.6	22.2	565394	565394
736589cb-e1e0-4241-9467-d486a99c42d4	2026-01-07 05:44:59.334573+00	5.8	22.2	706732	706732
991129d0-5eea-4960-a3a2-56a6fc26e0ca	2026-01-07 05:45:59.550767+00	5.3	22.2	497109	497109
f11e04a1-f35b-4b9c-bcfa-436bebcbde45	2026-01-07 05:46:58.327791+00	9.4	22.2	725431	725431
2cda6259-9b62-48c9-80af-c8c82bc6125f	2026-01-07 05:46:59.445666+00	8.7	22.2	1710705	1710705
7937ebb8-5571-43b3-b23c-de65f1f7fd13	2026-01-07 05:47:08.934282+00	15.5	22.2	1000174	1000174
93e0a4b7-8d48-4838-a8aa-d873bd14ebdd	2026-01-07 05:49:09.078898+00	15.2	22.2	556045	556045
041daf79-a7a7-4f6d-8567-2b2c1aa79f39	2026-01-07 05:49:59.525853+00	6.6	22.2	554944	554944
9edff7dd-a85d-47f1-9fd1-25f913371b9a	2026-01-07 05:50:11.345038+00	19	22.1	870706	870706
6552c8e3-7712-4e10-85ac-0889d6cddfe5	2026-01-07 05:51:09.854728+00	17.3	22.1	961795	961795
541d66fe-6cf9-4cc5-8aa2-6a88cc72227d	2026-01-07 05:51:58.394263+00	9.9	22.2	527913	527913
24e22eea-1a38-44f6-b43a-3a2551bb875f	2026-01-07 05:52:09.595551+00	22.6	22.2	697408	697408
0467f8dd-e3f1-42a8-a3ae-5f1eec06d50d	2026-01-07 05:52:10.475633+00	22.5	22.2	1281819	1281819
dfa22af8-9aab-42ce-8794-547f1d9863a2	2026-01-07 05:53:59.491434+00	5.6	22.2	707098	707098
11cee8e0-c6dc-4e46-85db-d51837ca8831	2026-01-07 05:54:59.646774+00	8.5	22.2	344396	344396
d724bf15-d1c0-4d26-9d55-4cd02302aab1	2026-01-07 05:55:32.179737+00	17.6	22.3	1075717	1075717
86ee7218-e967-4212-96b0-0626b3d87909	2026-01-07 05:55:59.469538+00	6.9	22.2	166071	166071
ff58a1d5-15bf-49d5-854a-2a310a989e03	2026-01-07 05:56:09.976079+00	14.7	22.2	1062457	1062457
b4c54dc1-b704-49f3-b613-8a358310e946	2026-01-07 05:56:58.326088+00	9	22.2	797956	797956
b901a34e-091f-4613-92d8-9741618fd4be	2026-01-07 05:57:08.899356+00	14.3	22.2	726607	726607
a414ca1f-685c-41dd-8b87-3fbb65d3a87a	2026-01-07 05:58:09.338251+00	13.4	22.2	630064	630064
400b7e01-0c57-429d-994c-97cff44ad224	2026-01-07 05:58:10.232637+00	70.4	22.2	880787	880787
0bbec7ee-7f07-491c-ba2c-735f40d20506	2026-01-07 05:58:32.338995+00	11.9	22.2	761246	761246
ff62577a-8ab9-4d62-8cf9-e544a75ede4f	2026-01-07 05:59:09.463176+00	7.2	22.2	640767	640767
b5208a70-b5e0-40f0-945e-c121a39aed54	2026-01-07 05:59:32.175209+00	9.7	22.3	862426	862426
e5d6924c-4a34-42ee-b32e-7729b740b9aa	2026-01-07 06:00:09.126124+00	21.9	22.3	682879	682879
e7e3f6f3-576a-42ec-a415-fb9ce8b093e6	2026-01-07 06:00:58.564639+00	10.4	22.3	548851	548851
7ef112fc-b1bd-492d-a105-31f34f0a79e6	2026-01-07 06:01:09.850385+00	21.9	22.2	1029469	1029469
de14992e-626b-4e43-b7b6-4bd1e401b818	2026-01-07 06:01:32.178126+00	9.9	22.3	821973	821973
d118a4a5-aeec-4311-a7f0-1d820bdac6d5	2026-01-07 06:01:59.460804+00	8.9	22.3	315174	315174
c109a010-a1b0-4b7b-b898-8807be143a49	2026-01-07 06:02:09.730279+00	8.4	22.2	807188	807188
df62198c-2ad8-4812-92d1-b1a9a6529d22	2026-01-07 06:02:58.249029+00	20.5	22.3	213139	213139
77c0f5e9-7c9d-46ea-aef2-7254a5bea360	2026-01-07 06:02:59.368645+00	9.6	22.2	293375	293375
cad0b767-031b-46f7-bfce-2c5fb4bafca4	2026-01-07 06:03:11.095745+00	25	22.4	663075	663075
8cacb922-72a4-4f88-b35a-743462f5e4bf	2026-01-07 06:03:32.205256+00	9.5	22.3	831424	831424
47c0c9c7-f736-4f38-a2dc-496ed5534d47	2026-01-07 06:04:58.359334+00	8.7	22.2	529491	529491
66e55c93-c8c1-4e91-a462-95839990be68	2026-01-07 06:05:08.991855+00	12.7	22.2	786536	786536
816d769e-7a77-4b7f-9dae-d0db3908db92	2026-01-07 07:59:54.115782+00	7.8	23.1	15735	10864
46cb3e95-835f-4850-a057-89f0f0afa7b4	2026-01-07 08:39:54.419584+00	10.3	29.9	15422	174836
1af09978-fc2a-4028-8996-d004afff80b4	2026-01-07 09:23:33.528334+00	5.8	29.8	5765	7303
8e484e23-3eab-48b8-ac08-fdf4c78da97b	2026-01-07 09:51:52.226022+00	4.4	24.5	88409	88409
a125d01a-932c-49a6-9585-74564885845c	2026-01-07 10:11:52.209549+00	9.3	32.1	51446	51446
085fd90b-3536-4505-8711-b8cecb816775	2026-01-07 10:32:52.08838+00	4.7	26.5	0	0
1ecea7dc-5fcb-4ddc-b376-683b7dd0d0cb	2026-01-07 10:49:52.109413+00	21.8	31.6	110794	110794
bce12334-8f15-4d79-8817-0a9baa5e567b	2026-01-07 11:06:52.074351+00	42.9	33.7	27305	27305
04b91293-9d53-4740-8608-ec786dbd1b68	2026-01-07 11:26:13.668553+00	20.4	32.2	9794	58594
71f2dfdc-f36b-4e70-9833-ab169793fc6a	2026-01-07 12:06:52.143953+00	59.2	33.1	1348445	1348445
a3b3bdf1-069f-4465-b5c7-f53ab01c2c23	2026-01-07 13:06:52.095174+00	38.3	29.2	117784	117784
fa5961ec-66e9-4f7d-8539-0a292fed9af9	2026-01-07 13:06:59.754253+00	31.3	30.5	583896	583896
49411e4a-6246-4dc2-8e90-86eace255614	2026-01-07 05:36:58.275316+00	9.5	22.1	282865	282865
880b76e3-00a9-4e17-a197-c6a85faf0bc6	2026-01-07 05:37:58.267746+00	9.2	22.2	650541	650541
483ebde5-473e-437c-9a21-ad9fc16fefb6	2026-01-07 05:38:32.304336+00	15.9	22.1	659027	659027
fff47a7b-942d-4977-bb8f-f2f5bac6071c	2026-01-07 05:39:09.003398+00	23.8	22.1	859367	859367
fae37e68-1203-4c50-9f3a-6f828bceee38	2026-01-07 05:39:58.247777+00	16.7	22.1	246431	246431
299d7563-c7b7-4fed-822e-de80d7d376ea	2026-01-07 05:40:09.819157+00	14.5	22.2	869359	869359
e286818a-a6dc-435f-a71c-3e5c81ee6023	2026-01-07 05:40:59.523979+00	8	22.1	310950	310950
651a64c0-5307-4015-93da-a64f7e3162d7	2026-01-07 05:41:09.831916+00	20.9	22.1	1029613	1029613
99fd101a-c923-488b-b6eb-427f5269377c	2026-01-07 05:41:32.204859+00	7	22.2	1602930	1602930
bd517b1f-a7a2-4f2b-baf2-67612c184d3e	2026-01-07 05:41:59.44062+00	9.4	22.2	521526	521526
4990b1af-44d1-4bb1-966a-993f53dce833	2026-01-07 05:42:11.312126+00	31.6	22.2	741347	741347
21b50e0a-c29e-402f-899c-3fd816f4aac6	2026-01-07 05:42:59.3728+00	9.1	22.2	272554	272554
860d9c62-b24e-444f-8fe2-d447a7380092	2026-01-07 05:43:09.680257+00	16.9	22.2	1045606	1045606
8722d8ec-1db0-4120-bdf1-eb4a2cab37ed	2026-01-07 05:43:59.862676+00	5.6	22.2	201510	201510
8c0353d3-81f3-44a8-922e-b9e6c7a070c3	2026-01-07 05:44:09.504956+00	14.3	22.1	1138879	1138879
5e6ce0c2-7ad7-4c90-87ca-a7611bd43454	2026-01-07 05:44:10.331714+00	14.3	22.1	1167498	1167498
93c8a77d-9698-42a1-a2c1-97b191950696	2026-01-07 05:44:58.190697+00	8.5	22.2	682522	682522
71e30ae8-8eaf-4fb1-816b-3bcd337339ad	2026-01-07 05:45:08.888329+00	14.9	22.2	1142900	1142900
e244af8e-10b2-46d7-98d5-f3425ae0ccc0	2026-01-07 05:45:58.379661+00	9	22.2	648389	648389
a867c891-7b00-41d0-aa41-2473062793cc	2026-01-07 05:45:59.458995+00	5.3	22.2	278243	278243
273e649e-7267-47d3-a115-aa5f3fc39620	2026-01-07 05:46:09.768086+00	17.3	22.1	871626	871626
8c715c1a-721e-4819-a8ca-767b58902acc	2026-01-07 05:46:59.361628+00	8.7	22.2	154719	154719
ca098439-4261-44c1-bf66-631283104d1d	2026-01-07 05:47:59.586998+00	6.5	22.2	235158	235158
27b62d92-e15b-4aaa-8bf9-a63ab9d6bc6e	2026-01-07 05:48:11.348405+00	29.9	22.1	618876	618876
7535ae42-ac92-4bc5-b6b6-c70591e5cfb1	2026-01-07 05:49:09.077945+00	15.2	22.2	730116	730116
e6cca303-12cb-4095-b717-0b121f48a4ad	2026-01-07 05:49:58.349482+00	9.3	22.1	618986	618986
cd963904-ad7e-402f-bd2c-13b378d808b4	2026-01-07 05:50:09.18774+00	14.2	22.1	539070	539070
00c06b3f-1a7c-4e23-b529-512351bbf455	2026-01-07 05:50:59.482093+00	6.9	22.1	584562	584562
2477d5b6-04e5-4aa1-817c-d453a9b9c45d	2026-01-07 05:51:09.039856+00	17.3	22.1	801406	801406
d5648c34-3373-482b-bd72-c9df92c05c9f	2026-01-07 05:52:32.215834+00	20.3	22.2	931318	931318
9077b256-b513-47f4-9344-aa845b4c6668	2026-01-07 05:52:59.443907+00	8.9	22.2	357898	357898
a2e8c8e5-1369-4450-bf6e-eff16fcc2e42	2026-01-07 05:53:32.175197+00	18.7	22.2	1033576	1033576
8a466303-73b7-47da-b7fc-bec5703857d1	2026-01-07 05:53:59.413015+00	5.6	22.2	317919	317919
25636c03-6ac1-49a2-b0aa-7603b73de9ce	2026-01-07 05:54:11.190787+00	33.6	22.2	585596	585596
30431d33-4ab1-47fe-9de3-2fd09466e428	2026-01-07 05:54:58.321047+00	9.6	22.2	218225	218225
7ac4bf32-f660-4661-b8ab-ccd783313acf	2026-01-07 05:54:59.562548+00	8.5	22.2	358922	358922
e4e6df55-8958-48e9-b619-83b502c2e009	2026-01-07 05:55:11.32459+00	33.3	22.2	642325	642325
f4ebf954-ada8-4ece-ba1e-3777374d0b50	2026-01-07 05:55:58.305672+00	9.2	22.2	724218	724218
34020f14-0738-452d-9af3-78e47718d4bc	2026-01-07 05:56:59.355494+00	6.8	22.2	242173	242173
495d84cf-60b2-4c22-a86e-eafe59bb2304	2026-01-07 05:57:09.686133+00	14.3	22.2	1174793	1174793
001b5893-618e-4d55-9e71-75f4b666f300	2026-01-07 08:00:54.077082+00	7.3	23	16035	8609
10c0205b-60f5-4835-85dc-2ac055c71320	2026-01-07 08:40:52.038094+00	6.6	28.2	198617	198617
ebeb1334-8625-4b98-a990-8c3b1b583dff	2026-01-07 08:43:04.756131+00	6.7	26.5	267980	267980
1ea328c6-ffe6-4aac-9627-6e759b4f562f	2026-01-07 08:44:04.784386+00	7.7	26.8	1139842	1139842
d9ed3bc0-9c5c-4620-8ef7-dc0590778023	2026-01-07 09:24:27.973923+00	23.5	30.2	10810	239469
e8fe60a0-9039-45d1-af4c-f6ac51785d25	2026-01-07 09:52:12.382307+00	8.6	24.5	3594	2186
ca726e58-731c-4c6e-8fa8-604b7b69ac32	2026-01-07 10:11:55.845551+00	14.1	32.3	5762	5762
9f5e8707-8d33-4e6e-b073-c8a0867274d7	2026-01-07 10:32:52.08959+00	4.7	26.5	107445	107445
cf26729f-3a8b-4314-a2e2-94f5c2a3dabd	2026-01-07 10:50:13.245052+00	20.4	31.6	1157162	226709
337c9b72-f039-4744-84aa-b9aa59956531	2026-01-07 11:06:52.090552+00	42.9	33.7	165106	165106
dcb203ad-69d8-4a82-9cde-59e395333700	2026-01-07 11:26:52.114995+00	5.2	32.3	108876	108876
a60964b6-927e-497e-b41b-5d6e3cf2fced	2026-01-07 12:07:27.486493+00	58.5	33.1	464245	464245
c3b742da-b234-4068-afe2-a01f9a35c41f	2026-01-07 12:07:52.115525+00	54.1	34.7	6431815	6431815
db77950b-5538-4039-a238-c62415459c9d	2026-01-07 12:08:51.904264+00	52	36.5	2913061	2913061
2d2711d6-14f4-46e9-b77f-4a18c0fbd13d	2026-01-07 12:08:54.280023+00	51.8	35.1	2708352	2708352
021baa0d-be1d-4385-9907-739c67e89c23	2026-01-07 12:09:51.931625+00	51.7	35.4	1075579	1075579
f9b3cd61-0a21-44ab-8ac1-6a92d446a69b	2026-01-07 12:10:51.965315+00	60.3	35.8	556166	556166
867bb6df-caf7-479d-b455-35fd2ec88de2	2026-01-07 12:10:54.327179+00	53.3	35.8	458198	458198
13338231-98e4-4dc5-b557-04b83a2f0f1d	2026-01-07 12:11:51.969715+00	61.5	36.2	6277879	6277879
ae6596de-d001-45b1-9ef2-1b041edb146b	2026-01-07 12:11:54.390077+00	60.1	36.3	414523	414523
1f22f562-1a05-4f59-9753-6f446ca16ccb	2026-01-07 12:12:51.953514+00	58.1	37	2551805	2551805
f15982a8-4894-489b-aa2f-70f0ee2dcd3f	2026-01-07 12:13:27.271107+00	60.1	32.8	785231	785231
10f9e6d8-3541-419f-a8db-e32de9adff75	2026-01-07 12:13:51.921244+00	55.6	33.7	795643	795643
4fcda116-faca-4ec4-921e-f2d2047d1f26	2026-01-07 12:14:27.879783+00	59	36.7	616128	616128
c2130977-7159-4815-9499-cd0980127f2f	2026-01-07 12:14:54.317414+00	60.4	40.3	2223573	2223573
2b54fecb-9786-4a19-a4f2-ebd15b810ae7	2026-01-07 12:15:51.927234+00	58.7	40.9	784335	784335
3619a3af-56a4-4393-b95e-394a108a485f	2026-01-07 12:16:27.833258+00	77.3	34.4	297299	297299
dde8bfc6-cb23-49f0-b720-c2e4eb76945c	2026-01-07 12:16:54.364203+00	80.8	34.7	368549	368549
55c44b3b-2ccb-4e8c-a79e-83b0e72566bb	2026-01-07 13:07:36.977324+00	33.8	29.9	312035	312035
a5ec14cc-ce11-4d12-8d7e-5bad99a4210b	2026-01-07 13:07:52.199623+00	46.3	30.5	3620601	3620601
6c1446e0-eb54-4511-b092-ae83dfcdaa19	2026-01-07 05:36:58.339202+00	9.5	22.1	733200	733200
a3ba9772-94fa-4966-a994-1b32b5e76966	2026-01-07 05:37:32.281009+00	9.6	22.1	920162	920162
c2ea7bd1-4c63-4f81-8e62-03407c8c99b9	2026-01-07 05:37:59.43762+00	7.2	22.1	246387	246387
53820901-5199-4ad4-9a74-cada61d65512	2026-01-07 05:38:11.242371+00	19.5	22.2	581329	581329
5f87d78f-76ae-4df9-858a-f8ccaebda47f	2026-01-07 05:39:09.00666+00	23.8	22.1	455787	455787
23abe579-46a3-48dc-9b61-35119c4447af	2026-01-07 05:39:59.443507+00	6.4	22.2	314014	314014
6d4f944d-e102-48ca-9ddf-703cfe760096	2026-01-07 05:40:11.203237+00	35	22.1	629377	629377
4aca63cd-4b4d-42f4-8653-f2db82c5542d	2026-01-07 05:41:59.516594+00	9.4	22.2	606494	606494
e4a37288-53d5-4d32-92b7-a86d77571f9c	2026-01-07 05:42:09.140364+00	18.3	22.2	818751	818751
6df23566-1424-4933-8ecc-9b4debef19ce	2026-01-07 05:42:32.297462+00	10.1	22.2	922834	922834
5a81edf1-1dca-49db-bd6a-45666f3172f0	2026-01-07 05:42:59.475483+00	9.1	22.2	660860	660860
238a53de-4049-40bb-b6b6-076957baa827	2026-01-07 05:43:08.906014+00	16.9	22.2	1206560	1206560
3a9b3fae-a290-4564-b897-044ff6851057	2026-01-07 05:43:32.241779+00	14.2	22.2	685058	685058
68160598-7b21-4a50-9bc6-dbf48cee6f47	2026-01-07 05:44:58.185831+00	14.3	22.1	194020	194020
231c7881-ecf6-4b7e-b264-d229c292ddc5	2026-01-07 05:45:32.345126+00	18.8	22.2	879099	879099
717f3eee-d345-4d4d-a9f1-0804560f3c56	2026-01-07 05:46:09.000919+00	17.3	22.1	383850	383850
24fe11fc-1e26-41ef-a27c-577ee705cb7e	2026-01-07 05:46:58.321883+00	9.4	22.2	303882	303882
b4c4e03b-3375-4ed0-91a4-2cb08a613e4c	2026-01-07 05:47:08.923994+00	15.5	22.2	753414	753414
af570112-693e-49c4-a786-744a74768531	2026-01-07 05:48:58.310378+00	10.4	22	274766	274766
eab49911-b8e0-440e-bf81-7f359e7df6ad	2026-01-07 05:48:59.440575+00	6.9	22.1	244761	244761
e58563e8-3d39-4172-8a22-0a153b30c321	2026-01-07 05:49:11.289018+00	17	22.1	946083	946083
8a77d1b3-a635-424b-be58-1c2b1a1aa65a	2026-01-07 05:50:09.17925+00	14.2	22.1	3422227	3422227
0c620d6a-4e35-4fc3-8d60-d39075a629d6	2026-01-07 05:50:32.332917+00	7.9	22.3	947833	947833
0fd90664-c4a1-4d3d-a92d-bd3a429363fc	2026-01-07 05:50:59.392248+00	6.9	22.1	221869	221869
4ed21c99-4a57-4ff6-add1-78068b38c5e1	2026-01-07 05:51:11.209153+00	23.5	22.2	688682	688682
ce3565c3-fd40-490f-af21-74e118f97143	2026-01-07 05:51:58.399206+00	9.4	22.2	677681	677681
5ca26313-89be-47bd-bdf7-03a39c6fedf5	2026-01-07 05:52:00.044086+00	9	22.1	606857	606857
17079db0-62f5-4dc1-94f7-65172d815445	2026-01-07 05:53:09.004633+00	15.2	22.1	981474	981474
6cac70f9-3c06-4dfb-8780-ce928726d134	2026-01-07 05:53:58.189641+00	18.7	22.2	73352	73352
cd06f2d7-d00c-4e18-b137-2e326560f909	2026-01-07 05:53:59.411364+00	5.6	22.2	161312	161312
c09f8bac-421c-49e6-b799-5a7e2bb7592c	2026-01-07 05:54:09.769531+00	13.7	22.1	727854	727854
737b3c20-51fe-402a-a3ad-aa91d91dcf86	2026-01-07 05:55:09.177422+00	15.3	22.3	634319	634319
ef8ecc99-bb2f-4d58-9493-371afd114081	2026-01-07 05:56:09.157373+00	14.7	22.2	190777	190777
2bb25442-5605-4b14-9681-bf9b85429bfa	2026-01-07 05:56:58.289083+00	9	22.3	586012	586012
b28d3833-ebd0-48ea-8e66-fdd3e68bb179	2026-01-07 05:57:32.279136+00	7.9	22.3	722388	722388
9b428297-9025-4ed8-b9c0-55927f927487	2026-01-07 05:57:59.689413+00	8	22.1	323226	323226
625f3883-5564-4afc-9c06-b0af8bc60baa	2026-01-07 05:58:11.606535+00	70.4	22.4	442702	442702
8fcb2f5a-50af-4b17-ae01-ebdcb42a2698	2026-01-07 05:58:59.809085+00	7.7	22.3	701323	701323
b9e94124-da1f-430e-9ea2-9064ff7f1af9	2026-01-07 05:59:11.663097+00	72	22.3	648794	648794
d3c629f6-d205-45b4-b557-32393eb622bb	2026-01-07 05:59:58.223253+00	9.7	22.3	46717	46717
0810ff01-239e-459a-b6ee-99b7491cfe3f	2026-01-07 08:01:54.102969+00	7.6	23.1	14097	8684
a96f0f8c-655d-452c-8119-7cacaad854d7	2026-01-07 08:40:54.419454+00	6.4	28.1	4771	6853
d27f0ea0-ad98-47e7-ab44-e14f5fa6b487	2026-01-07 09:25:28.269418+00	7.2	30.1	1053	2039
9de8f4ed-5375-4e6a-8f77-c7f4c5d5b1aa	2026-01-07 09:52:52.16716+00	8.7	24.5	147220	147220
2f43a9b1-a047-4bb6-a323-0107456fe8ef	2026-01-07 10:12:12.682624+00	8.1	32	4205	2721
c6927ec4-a3f2-42a3-8746-9f5083a71a02	2026-01-07 10:33:12.985389+00	5	26.5	5316	3836
614b3677-3f18-4bf2-b2b4-3d321d39e725	2026-01-07 10:50:52.118957+00	7.5	31.6	16077	16077
b66bf9a6-afe5-4098-8eaf-2747db13d8a4	2026-01-07 11:07:13.341323+00	31.3	34	167255	35977
46dfc2c8-ba07-4d5d-9e96-13c2f97b2d1d	2026-01-07 11:26:52.116702+00	5.2	32.3	367756	367756
3fdafd7c-15bc-4cc4-8971-52329861b02f	2026-01-07 12:07:52.130054+00	54.1	34.7	5193374	5193374
0c8b69da-0c0b-43d4-b55f-35fd7d83b4ec	2026-01-07 12:07:54.356349+00	53.9	34.7	2460041	2460041
db5e95d6-6b1e-47ad-8887-46655b1e5dbf	2026-01-07 12:08:51.908815+00	52	36.5	2053402	2053402
8a9d460c-be0a-458e-b620-11cc240429ce	2026-01-07 12:09:51.901481+00	51.7	35.4	731125	731125
33b3c69e-3931-4242-811e-c1bceac591db	2026-01-07 12:09:54.315009+00	51.7	35.5	531882	531882
723dd59a-41f9-4a81-b8a4-43bf167ff4a0	2026-01-07 12:10:51.970137+00	60.3	35.8	933025	933025
04424ad6-77b4-4826-b633-ea47336d22e8	2026-01-07 13:07:52.199564+00	46.3	30.5	1191984	1191984
eb340fcc-5969-4b28-91b6-0a9cb85b8f22	2026-01-07 05:36:59.742016+00	7.6	22.1	358040	358040
6b7caae2-9d37-4f48-84fd-8d76eb8a9830	2026-01-07 05:37:09.318302+00	18.8	22.2	571323	571323
b3106a50-dba1-4be6-856e-82f0cb91eb5b	2026-01-07 05:37:59.434031+00	7.2	22.1	217001	217001
bafd831f-b602-4dac-8530-d330590d0fd9	2026-01-07 05:38:09.854873+00	9	22.1	935382	935382
51ffd1fa-9c65-4fa7-bcd7-fe7c6640e21d	2026-01-07 05:38:59.342279+00	6.2	22.2	296913	296913
7bea845b-6884-4488-a1e5-d2c4a70c57a0	2026-01-07 05:39:11.093866+00	26	22.1	657150	657150
214247ee-e5b3-4b2d-8591-e46d34fac0ed	2026-01-07 05:39:32.242828+00	10.5	22.1	749765	749765
0854eed6-8a98-40c4-9e8c-f626df591540	2026-01-07 05:39:59.442161+00	6.4	22.2	670461	670461
f59ff1b3-cdc6-4c39-a1ba-7e7cd2d19084	2026-01-07 05:40:08.971412+00	14.5	22.2	973565	973565
f7c76d70-9b2c-40ac-8a14-941c02edb1f8	2026-01-07 05:40:58.552154+00	8.5	22.1	754937	754937
3c411132-9e59-4168-8969-6e1388e3c595	2026-01-07 05:42:58.274575+00	10.2	22.2	488408	488408
6bad84ce-8cc7-4201-bb85-957059a49595	2026-01-07 05:43:08.911967+00	16.9	22.2	731021	731021
7d0a8012-6876-492d-90bf-92186bbb2746	2026-01-07 05:43:59.858039+00	5.6	22.2	163121	163121
9933bc77-60e2-4ca6-a7df-c31337b563b0	2026-01-07 05:44:09.49394+00	14.3	22.1	519428	519428
e90764fc-8af1-44a3-b43d-6f92a2464991	2026-01-07 05:45:08.836526+00	14.9	22.2	1034707	1034707
2b5bbefb-bbd8-4f5a-9824-cd22d41126ff	2026-01-07 05:46:32.227411+00	9.7	22.1	819707	819707
3299ddd3-1852-4047-9407-38a454556a9f	2026-01-07 05:46:59.365233+00	8.7	22.2	208524	208524
b325072e-102e-44a6-86d3-f40e1fc415f4	2026-01-07 05:47:11.083086+00	31.7	22.1	818381	818381
64edaabc-658e-4605-8fb9-890cc7cc1dd7	2026-01-07 05:47:32.192401+00	22.4	22.2	938695	938695
c7167819-571d-4d9f-ad55-acbfca1ec77e	2026-01-07 05:47:49.08241+00	15.4	22.2	36089	36089
20a7d71d-4e05-4150-95bb-abe6efb43468	2026-01-07 05:48:09.119363+00	14	22.2	675430	675430
c8ed71f2-d2c0-4d06-9ffc-7a3e1c25d1f2	2026-01-07 05:48:32.230834+00	24.3	22	769166	769166
132fe41a-4cb2-4d29-ab06-80927b04e477	2026-01-07 05:48:59.528769+00	6.9	22.1	546505	546505
e829df17-671b-4d3d-ab35-12090e575ab5	2026-01-07 05:49:58.380276+00	9.3	22.2	700310	700310
0d97bb19-e8d1-4301-a8c1-4afc8fb5595d	2026-01-07 05:49:59.44438+00	6.6	22.2	469976	469976
b7d895fe-4aaf-4e48-a2e7-ece002639699	2026-01-07 05:51:59.916125+00	9	22.1	400310	400310
ac3fa79e-0779-4145-9a4a-4c2f6c8a92cd	2026-01-07 05:52:11.824829+00	22.5	22.2	856556	856556
183e9bf6-0766-4593-9dfe-6194af60349c	2026-01-07 05:52:58.282785+00	11	22.2	519226	519226
23b3cad7-4153-4f17-b9d2-1975715e7691	2026-01-07 05:53:09.046133+00	15.2	22.1	224908	224908
54a607b1-130f-48bb-83b0-e7f34bc2cd7f	2026-01-07 05:53:58.207664+00	10.6	22.2	746001	746001
dbdf7684-28c5-41b3-9cab-6d9313b6c020	2026-01-07 05:54:08.992338+00	13.7	22.1	651705	651705
e8e0e6f7-cb39-4581-bf67-b4b5aa4c127a	2026-01-07 05:54:32.187401+00	10.2	22.2	1181737	1181737
2a27aad2-1978-4355-83f0-ee67d6931c3a	2026-01-07 05:55:40.868739+00	17.6	22.3	989024	989024
45f0d37f-6a4a-4db6-83e0-57a9c7b15d5c	2026-01-07 05:56:09.148983+00	14.7	22.2	449572	449572
f5581fa4-3053-487f-baf7-1b02c69585f3	2026-01-07 05:56:32.278374+00	10.7	22.3	850410	850410
1ecefa36-8b62-4d5c-9814-9786f985ce13	2026-01-07 05:56:59.352941+00	6.8	22.2	867202	867202
1b9ab9cb-1d7c-45ad-baa7-33205cea6025	2026-01-07 05:57:11.049415+00	34.2	22.2	766128	766128
2100dae5-cfb9-4017-877b-0a4b6fbdeb24	2026-01-07 05:57:58.438401+00	9.8	22.2	391708	391708
42a43f95-a27b-407b-a678-675724413e95	2026-01-07 05:58:58.245292+00	9.9	23.2	671149	671149
00642ac3-fcdc-43d9-92fa-7ac02cb23ea2	2026-01-07 08:02:54.136522+00	7	22.2	17155	8070
3e2981a0-77b6-44d0-aa44-4bcdb267cee0	2026-01-07 08:41:29.78173+00	7	28.3	167159	167159
46a96315-d4ec-47c0-a183-0cb4f97459e1	2026-01-07 09:26:28.255181+00	26.8	29.7	0	0
747e0462-25bd-4cc1-934f-7e5c24fc5bb0	2026-01-07 09:52:52.178672+00	8.7	24.5	89054	89054
1f3d897a-efa4-4a6e-9571-a92370bcbbd2	2026-01-07 10:12:52.056125+00	4.9	29	147829	147829
c33e36f1-9342-4192-b30a-fa28ff1b1374	2026-01-07 10:33:52.080181+00	5.5	26.4	49418	49418
fda6701d-a065-42c8-812a-b1bb83f470cb	2026-01-07 10:50:52.121495+00	7.5	31.6	120751	120751
59a17c88-c5b1-4cf8-8a62-5aeee3a9599b	2026-01-07 11:07:52.161685+00	40.6	35.1	54457	54457
6a731cef-8454-4878-bf5b-1ca16a163055	2026-01-07 11:27:13.64241+00	20.3	32.3	6823	4784
0ecfd986-efbf-436d-8207-c1203dc452e5	2026-01-07 12:11:51.969345+00	61.5	36.2	4081233	4081233
85e63925-a86b-49e1-8ea1-ce0ed4d32f1b	2026-01-07 12:12:51.950632+00	58.1	37	4677683	4677683
d666694b-d1e6-465e-a74c-db395ee2b9e6	2026-01-07 12:12:54.312524+00	56.2	37	3077121	3077121
5bd0ab81-c2dc-4f33-8326-6516933e0abd	2026-01-07 12:13:54.318265+00	57.6	34	635774	635774
8e796e80-5834-4f92-a216-baae348572bd	2026-01-07 12:14:51.974637+00	60.6	38.3	818166	818166
685cded9-7b8f-4a0b-a98c-e90429524fe1	2026-01-07 12:15:27.844868+00	81.4	40.8	293369	293369
e7c8f50d-896b-440b-9bdc-443961b9b0fe	2026-01-07 12:15:54.331041+00	78.6	41	464179	464179
f5af593c-fed0-4745-a279-e0096b6d1129	2026-01-07 12:16:51.954394+00	71.8	34.6	269353	269353
830841a7-688c-430b-969c-d9272bd8bf74	2026-01-07 13:08:36.872418+00	40.1	30.4	2961405	2961405
1ab72d3a-fcbc-41ca-9327-dd130c362a67	2026-01-07 13:08:52.152752+00	40.1	30.1	284809	284809
f80c0048-e9cf-4d83-854e-1540ae10b4c3	2026-01-07 13:09:36.872524+00	40.3	30.2	1799873	1799873
3f5b5cea-cda3-4ed3-bd4a-6d991998978e	2026-01-07 13:09:52.194239+00	41.2	30.1	26107	26107
c780b3ac-b70b-48b8-b2a5-8b8ad06e1590	2026-01-07 13:10:15.10594+00	35.3	30.1	2215629	2215629
10a1883c-ee62-4a6a-be45-32be90bf68ec	2026-01-07 13:10:52.003307+00	33.4	30.3	0	0
358d7b54-6f19-4eb7-9d94-a07cbdd286b9	2026-01-07 13:10:53.812791+00	31.3	30.4	537732	537732
61329dbb-46a7-4c39-bee9-e183f0e05168	2026-01-07 13:11:36.859679+00	35.5	30.9	3778809	3778809
51de2829-4b48-4359-9161-99be11ae1b4d	2026-01-07 13:11:51.96802+00	33.4	28.9	2314544882111	2314544882111
934493ab-0a33-4d29-a76a-9ee089804c08	2026-01-07 13:11:53.799652+00	38.2	28.9	767706	767706
9f9376bd-0bde-462a-ab27-21b47a072911	2026-01-07 13:12:14.996393+00	29.1	29.4	1524891	1524891
910f2d9c-e357-4a38-9fc1-a8117aae1709	2026-01-07 13:12:51.904673+00	33	29.1	254468	254468
e82d59c0-918d-47a2-addf-61682bf63294	2026-01-07 13:12:53.802149+00	32.7	29.1	1763334	1763334
0cc2d7d1-3bec-4e1b-b7c6-67b5c2573a82	2026-01-07 13:13:36.908507+00	34.4	29.2	2396601	2396601
4dc0b721-5379-4559-b886-a393ba87a92a	2026-01-07 13:14:14.991281+00	28.5	29.2	3550640	3550640
762dfac1-f612-4cea-8a00-d855bbe81902	2026-01-07 13:14:51.892701+00	30.1	29.2	835660	835660
70b48c06-117c-490e-a53d-56aaa9b0154c	2026-01-07 13:14:53.827371+00	30.4	29.2	3995188	3995188
916b22d5-4b03-4c6a-965c-e5e385906d43	2026-01-07 13:15:14.988252+00	29.1	29.1	4036832	4036832
bf6c2dd0-29d9-4acb-9c49-4fc2aa91f0c5	2026-01-07 13:15:31.567335+00	31.9	29.1	3275921	3275921
071b7da4-ee16-439b-b3f5-74b6ad0c16b4	2026-01-07 13:15:51.986388+00	34.9	29.1	3566387	3566387
baf669ab-48d7-4c06-807d-fe3f6c977bc5	2026-01-07 13:15:53.915483+00	34	29.1	2494989	2494989
1220b9cc-b46f-4469-96a7-eb94f6bcb2a2	2026-01-07 13:16:31.526909+00	32.8	29.2	3455038	3455038
37db1d3c-fa84-4ab7-9406-751c1bf8238c	2026-01-07 13:16:51.935331+00	39	30.3	4074003	4074003
05a33b49-a8e6-4237-8a7b-0c05fd5c7ff4	2026-01-07 13:16:53.84936+00	36.5	30.4	4742409	4742409
5a73b146-7d94-4cd7-ab45-7961bb1aa148	2026-01-07 13:17:31.514042+00	34.8	30.6	4320260	4320260
87def729-1434-481c-988d-e692804b56bf	2026-01-07 13:17:51.966832+00	29.5	30.5	167721	167721
b132c862-4125-46ea-b4ce-f7938e9d6c5b	2026-01-07 13:17:53.923578+00	34.2	30.4	1580172	1580172
4fc0c890-6690-47b9-bb7b-26942a448a38	2026-01-07 13:18:31.517628+00	36.7	30.6	6800947	6800947
7ac2f4c8-5613-4a8c-bc78-a0f22c1d5b15	2026-01-07 13:18:51.966351+00	32	30.5	210936	210936
66e4ac3d-83e6-4f97-b7f7-0400f38057af	2026-01-07 13:18:53.829568+00	37.7	30.5	1272628	1272628
7eb8aca6-75bf-49f4-9e01-daa0a811af9d	2026-01-07 13:19:36.875265+00	30.8	30.7	665576	665576
292fd280-0cee-403c-9110-85161eecfc50	2026-01-07 13:19:53.8334+00	32.8	30.7	1531251	1531251
6dfe458a-f74f-47c8-8816-a8444a7b176d	2026-01-07 13:20:51.903943+00	30.6	31.1	3724007	3724007
d1fcc000-bb10-4e4e-8f34-938bfa292ac9	2026-01-07 13:20:53.832986+00	32.7	30.8	2897945	2897945
234ba147-20a7-4692-aea0-d5cd0c7abed3	2026-01-07 13:21:31.522549+00	32.1	30.9	4351858	4351858
85128b2f-7a0b-491d-9452-67bd5cea7aec	2026-01-07 13:21:51.962875+00	31	30.8	168864	168864
293b2a6c-63b4-4b39-926f-d69669e0f553	2026-01-07 13:21:53.856329+00	36.3	30.9	2328011	2328011
6ed199f9-a1e1-4d45-9237-f928acde06a4	2026-01-07 13:22:31.565472+00	33.6	30.9	3212291	3212291
c5de2c20-6600-497d-96e5-7ed87a1feebe	2026-01-07 13:22:51.954651+00	35.8	31	244571	244571
8ce79c5f-0113-4f5d-b851-02332985663e	2026-01-07 13:22:53.86557+00	37.4	31.1	1932184	1932184
73544031-e222-45ec-9cba-a0e237b4bfc3	2026-01-07 13:23:36.85201+00	32.2	31	4084749	4084749
d2545eae-8f97-4490-8d66-e0b159f9db4d	2026-01-07 05:36:59.820708+00	7.6	22.1	550100	550100
c27ef9d5-194e-42d0-9b60-903a57cfea5c	2026-01-07 05:37:10.166231+00	18.8	22.2	729917	729917
8824bdf3-9633-4d09-9ae1-82db7a3c7912	2026-01-07 05:37:58.261743+00	9.2	22.1	586578	586578
d158b7f6-8941-47fe-9540-c0bdf6fe0b8a	2026-01-07 05:37:59.535148+00	7.2	22.1	727589	727589
dcf86866-d799-4e79-b62c-3d5f4ef942fe	2026-01-07 05:38:09.004925+00	9	22.1	859362	859362
6e35cc66-4193-491d-8280-8c7351525e29	2026-01-07 05:38:58.235414+00	9.4	22.1	486626	486626
ce0f1b59-4358-4e16-85af-2d45ba1ca939	2026-01-07 05:39:59.521864+00	6.4	22.2	676194	676194
f3455205-1cb2-4a2a-bde2-000a972e4212	2026-01-07 05:40:58.554441+00	8.5	22.1	796698	796698
68707115-f217-45c5-84f1-8597e0aff395	2026-01-07 05:40:59.52443+00	8	22.1	560437	560437
0618631c-17d8-42ac-9bd9-14ad66aec5b5	2026-01-07 05:41:11.192664+00	23.2	22.1	654642	654642
70de2f91-ccc2-4977-bc0a-0a40377c3723	2026-01-07 05:41:58.264523+00	7	22.2	284361	284361
75a7c13f-6a15-4880-bcac-c0339d22f124	2026-01-07 05:42:09.145407+00	18.3	22.2	773981	773981
08540760-1a70-43df-8b84-0795be049096	2026-01-07 05:43:58.383897+00	9.3	22.2	282974	282974
e04cc11e-7142-49ff-85d5-37e238f924b2	2026-01-07 05:44:11.726861+00	18.6	22.2	454772	454772
fc77036c-cb65-4a27-811a-d83649527094	2026-01-07 05:44:59.331343+00	5.8	22.2	505830	505830
583b766e-781c-43fd-8aa9-773757a9f75c	2026-01-07 05:45:09.656794+00	14.9	22.2	939591	939591
c3224d13-f79b-4c87-81a9-1ea2da64cc54	2026-01-07 05:46:09.014762+00	17.3	22.1	828856	828856
2302a5e2-c7ea-42ea-a741-76ba339e1436	2026-01-07 05:47:58.330338+00	9.2	22.1	698584	698584
cfa4c969-ca7c-4108-ba27-99701944dba2	2026-01-07 05:47:59.672133+00	6.5	22.2	607321	607321
f699969a-e168-40a3-b1a7-eb7638a827ff	2026-01-07 05:48:09.125141+00	14	22.2	735363	735363
a13d4a6f-3c76-4dbd-87eb-29e8887f771f	2026-01-07 05:48:58.351355+00	10.4	22.1	742902	742902
f0be0453-81a5-4681-9258-97ac80ca81fc	2026-01-07 05:48:59.44332+00	6.9	22.1	486315	486315
33dced29-c3a3-420e-b565-a66e97eb1119	2026-01-07 05:49:09.937661+00	15.2	22.2	966223	966223
251c4948-1a27-462c-b7b5-45981c58949e	2026-01-07 05:49:32.245389+00	8.3	22.2	626381	626381
ed2f9e4f-283b-43cc-906f-58a0f1a046bc	2026-01-07 05:50:58.411743+00	8.9	22.2	598305	598305
43382a0b-8df6-4514-9002-fcecb34ea163	2026-01-07 05:50:59.396176+00	6.9	22.1	581772	581772
e03f2c22-f7d4-4d08-a558-a17cc5674b24	2026-01-07 05:51:09.024435+00	17.3	22.1	877903	877903
a5ce5eaa-cc00-4dee-acf9-2f88e28247de	2026-01-07 05:52:59.442331+00	8.9	22.2	190876	190876
7a2df9af-ff9f-432b-84e7-28867e91c34f	2026-01-07 05:53:09.835077+00	15.2	22.1	794780	794780
22eb3d73-a979-4016-bd2e-846c2aa425fc	2026-01-07 05:54:58.297981+00	15.5	22.2	296927	296927
a9d3a385-2a70-4950-bf18-5f756661172c	2026-01-07 05:55:09.173559+00	15.3	22.3	311010	311010
a6062c43-d169-425e-b7b4-3389421b7291	2026-01-07 05:55:59.47258+00	6.9	22.2	402656	402656
554857c4-fed6-47da-be72-6190282267e0	2026-01-07 05:57:58.302568+00	9.8	22.2	383498	383498
fed38142-7c62-4201-a8c8-d12d9a824b6b	2026-01-07 05:57:59.689421+00	8	22.1	397708	397708
688ca506-db5a-403b-80e3-6aa5ffb70494	2026-01-07 05:58:58.171733+00	9.9	23.2	647616	647616
5277de80-1740-4757-b690-d647b1fabaaf	2026-01-07 08:03:54.138293+00	7.5	22.3	16286	8683
f408add0-8e3c-4d1a-b06e-bbcc6fff41fe	2026-01-07 08:41:54.432956+00	7.7	28.2	4630	2710
f1a1c507-0dcd-4485-9953-67cc056cb751	2026-01-07 09:27:28.234029+00	27.9	30	9242	38344
1ac74685-670f-4186-8538-37cca0a1b00f	2026-01-07 09:53:12.399975+00	4.6	24.5	4211	2021
39bc6f5f-f16e-4cbf-b56e-eaa8cd2e34fd	2026-01-07 10:12:55.828864+00	5.2	28.8	3467	3467
4b608504-7618-42a8-8929-93b7b9f9a0ed	2026-01-07 10:33:52.08126+00	5.5	26.4	112205	112205
00eed84f-16e6-4201-a1db-d161a03e6b44	2026-01-07 10:51:13.241948+00	19.2	31.7	6697	4066
10d3c1ac-7909-493a-b5d2-c30b610ede9a	2026-01-07 11:07:52.165164+00	40.6	35.1	255827	255827
92692add-e1eb-4d0c-b342-d076849dc160	2026-01-07 11:27:52.082564+00	5.9	32.2	139520	139520
c91a5fb3-f9b1-4ac4-9a21-49e5d80e4b3e	2026-01-07 12:17:27.832563+00	72.4	34.1	287373	287373
2b62b870-c661-4af3-b800-c2839e0867fd	2026-01-07 12:17:54.333943+00	64	34.2	604874	604874
12368342-cc48-4201-906a-dcb612436e45	2026-01-07 12:18:51.913181+00	33.2	34.6	1714524	1714524
f3961a71-06af-4b64-83b2-7bc33d382804	2026-01-07 12:19:27.826594+00	33.1	29.6	261646	261646
9e0e6c83-c1d4-4487-9374-f251374b028f	2026-01-07 12:19:54.277757+00	31.4	29.6	660182	660182
2554037f-a564-47db-aadf-a867510fab46	2026-01-07 13:08:52.153236+00	40.1	30.1	1663476213068	1663476213068
1651f1aa-9b66-4411-84d2-a48578875de6	2026-01-07 13:09:52.194095+00	41.2	30.1	3295247	3295247
cda2a4c0-7a5d-4da7-80f6-60a285345de1	2026-01-07 13:09:53.860707+00	41.2	30.3	2735050	2735050
4a895afd-af6d-4f9d-a648-f3285f0276bf	2026-01-07 13:10:36.846774+00	34.4	30.1	6669655	6669655
4ee3644b-3fbb-449c-9d86-4f7a682f65ce	2026-01-07 13:10:52.003283+00	33.4	30.3	4578048	4578048
76848f3e-fbeb-442e-ac76-2ba9520ca291	2026-01-07 13:11:14.989447+00	30.2	30.3	5206585	5206585
ee10bc8f-677b-42ec-8b8b-b8aed7ef4432	2026-01-07 13:11:51.956602+00	38.2	28.9	4240807	4240807
943b7995-3789-4989-b77e-58df0dc40964	2026-01-07 13:12:36.86388+00	29.8	30.1	5683580	5683580
7e01340d-8fb9-4cf3-9276-4ffee736ac18	2026-01-07 13:13:14.971104+00	32.6	29.2	3543135	3543135
9bcff826-d761-4653-88c6-16dadebaca81	2026-01-07 13:13:51.902487+00	33.8	29.2	6343977	6343977
ee8f3770-34d8-4b62-bdf6-36223ff226c2	2026-01-07 13:13:53.833411+00	29	29.2	1495881	1495881
df8f510a-c245-468a-a054-276a88106f07	2026-01-07 13:14:36.856881+00	32.7	29.2	860583	860583
04eda42c-a11c-48c2-a31d-22a987dfbd29	2026-01-07 13:15:36.847092+00	38	29.2	1116107	1116107
846ca0a3-7803-47f2-bccb-72d8613cc1bc	2026-01-07 13:16:36.869502+00	33	29.4	4570073	4570073
4ad931f3-d28b-476a-b70d-8957ff65fb8d	2026-01-07 13:17:36.860486+00	36.7	30.4	3499388	3499388
d79be707-a9b9-4d80-865c-c61bdacec85c	2026-01-07 13:18:36.860564+00	29.5	30.6	5767126	5767126
2e9de5df-29f1-4d89-8256-e043709b459b	2026-01-07 13:19:31.53542+00	32.3	30.7	4346919	4346919
61377886-1558-48a5-a4b1-554de39902e3	2026-01-07 13:19:51.953068+00	31.9	30.7	143698	143698
9a1d8c25-8581-4725-80bb-32cc5733c6b7	2026-01-07 13:20:31.509466+00	30.7	30.9	632092	632092
75409263-141a-4ef4-92a9-d84af53ba127	2026-01-07 13:20:36.901543+00	31.7	31	1878546	1878546
8aeba20a-09cc-42dc-85e7-f94edf9dbe7f	2026-01-07 13:21:36.90909+00	33.6	30.9	3097821	3097821
464767b7-f14e-4dbc-a112-8b4ba38f82d2	2026-01-07 13:22:36.861463+00	32.7	31	4520391	4520391
2efc6feb-acc2-4306-ac9f-3be0d7c02493	2026-01-07 13:23:31.528007+00	32.9	31.1	1086952	1086952
00da8bea-60b9-4278-b403-fa590fb087bd	2026-01-07 13:23:51.953949+00	36.6	31	198805	198805
7b9e3ecf-9164-4302-aa4c-3c360d050f1a	2026-01-07 13:23:53.835431+00	35.5	31.1	3152044	3152044
66c08682-9ebe-4552-88fa-43b8bacac24c	2026-01-07 13:24:36.900983+00	30.7	31	3793150	3793150
0500e294-d2ba-41d4-8bd8-62b361dea927	2026-01-07 13:25:31.530017+00	31.7	30.9	6122109	6122109
635a61a4-c625-4808-bb37-3284cf36a1f3	2026-01-07 13:25:51.973627+00	31.1	30.7	196619	196619
3db576be-7072-4a1f-a795-79184964b69b	2026-01-07 13:25:53.842102+00	33.7	30.9	3326097	3326097
fa2360e2-f9ed-4c15-9508-f25f07ed0836	2026-01-07 13:26:31.528413+00	32.1	30.8	4175771	4175771
aa9d2774-4aef-4b58-badc-8b4a2f87a1fe	2026-01-07 13:26:51.950297+00	32.4	30.8	248960	248960
78a98aae-a855-42e6-a5b0-112c95074334	2026-01-07 13:26:53.920614+00	32	30.9	417114	417114
5a22a58e-6dbe-43fd-b273-0209eb53822f	2026-01-07 13:27:31.521748+00	30.9	30.9	1886388	1886388
892f8115-0bcc-4016-8e80-907bfd607acf	2026-01-07 13:27:51.919373+00	30.6	30.8	5299386	5299386
e43f0f8c-40e8-4594-9ad2-6c5d87791324	2026-01-07 13:27:53.816825+00	34	30.8	554230	554230
48f64f1b-b7ac-41b5-a078-38a506f2c439	2026-01-07 13:28:36.878885+00	31.3	31	579603	579603
9e66a289-648e-433f-b888-c2400198015e	2026-01-07 13:28:53.845525+00	32.4	31	2291241	2291241
df9afd7c-9084-4938-840a-53323ff540c4	2026-01-07 13:29:36.877989+00	34.5	30.9	4753023	4753023
e6f5e1ad-e4c8-4964-bc87-a8168f80f9dc	2026-01-07 13:30:36.917023+00	30.3	30.9	907959	907959
a7a6759a-babc-4dc2-a0bf-025aba242db8	2026-01-07 13:31:36.931469+00	31.2	30.9	3028399	3028399
e3def859-c979-4412-b555-dcd661cf5f5d	2026-01-07 13:32:31.499029+00	31.5	31	5760380	5760380
5d3b4984-934c-4612-9695-d49e3fe0e0c7	2026-01-07 13:33:31.521007+00	33.4	31	4251326	4251326
bcb7c919-26df-49e3-934a-02c26338dac0	2026-01-07 13:33:51.943132+00	33.2	31.2	181576	181576
b72f70ce-baf3-4f95-80cb-c6c5a49195dc	2026-01-07 13:33:53.928467+00	34.5	31.2	3500527	3500527
8fac13c4-0953-4fe9-a177-62b14c5599ed	2026-01-07 13:34:36.856524+00	26.4	31	1235536	1235536
c142c386-f950-46d4-80fb-8fde62508724	2026-01-07 13:35:36.926598+00	34.3	31.1	236742	236742
0536fd82-ecb7-40f2-aa23-866ce0d5df50	2026-01-07 13:36:36.912643+00	30.8	31.1	2753674	2753674
424dad2d-1d0e-408d-8dd6-638c1a3e18fc	2026-01-07 13:36:53.926774+00	32.7	30.9	1207705	1207705
b1147fd3-3e98-4114-a7bb-657b3dd928dc	2026-01-07 05:37:09.317632+00	18.8	22.2	905618	905618
eb1de104-7a1f-444b-94dc-be79dc7b715b	2026-01-07 05:37:11.625397+00	33.3	22.2	748708	748708
64f1c052-4e91-4011-a277-91ef322c6893	2026-01-07 05:37:52.657222+00	13.8	22.2	58649	10753
2fe097b4-17aa-4937-9de9-bbe5e9b41877	2026-01-07 05:38:52.673245+00	11.9	22.1	61344	11795
9fe7e423-bb62-4959-a5b5-56eb799ac100	2026-01-07 05:38:58.275467+00	9.4	22.1	755161	755161
8fe46c5b-f231-4b12-bd3b-2c7c646fe673	2026-01-07 05:38:59.344687+00	6.2	22.2	226459	226459
65e15e50-bddd-4d05-a1d1-3f6fc0ef29c6	2026-01-07 05:39:09.71047+00	23.8	22.1	1218278	1218278
ae148679-306f-414d-8a3f-bc2156ccddc9	2026-01-07 05:39:52.71428+00	10.6	22.1	67960	12804
3dd3e003-3360-4d01-b337-b6edcf23d3c1	2026-01-07 05:39:58.303859+00	9.6	22.2	752472	752472
e98d3c66-d1d3-4e2e-be8b-df85c7831906	2026-01-07 05:40:08.97049+00	14.5	22.2	892123	892123
cd004f1c-1ddd-4091-92b3-455ccd7bcb57	2026-01-07 05:40:52.689928+00	14	22.1	90628	16651
0c02ba80-9aba-4449-bfa2-065a8d89ddd3	2026-01-07 05:41:09.016539+00	20.9	22.1	753124	753124
494520a8-b2f3-4f49-8214-0e21f5c2bd3d	2026-01-07 05:41:52.696729+00	17.4	22.2	71154	11928
2106efd6-0000-4f26-b4da-9d0d01cd246b	2026-01-07 05:41:58.269696+00	10.1	22.2	655392	655392
1498f237-e865-45f1-8f67-665876d6af79	2026-01-07 05:42:09.913312+00	18.3	22.2	1030762	1030762
8e8c8c44-c040-4b44-8b85-242d630d3cee	2026-01-07 05:42:52.792146+00	12.8	22.2	52138	8619
81ffc62f-468b-437e-8453-31f89b1de4b4	2026-01-07 05:42:58.341745+00	10.2	22.2	680285	680285
bb711d06-883c-447c-bf44-88912ee4d5c1	2026-01-07 05:43:10.985347+00	20.6	22.2	812780	812780
931af84a-90a6-4a43-beec-31db427349ce	2026-01-07 05:43:52.763691+00	11.9	22.2	48836	9976
126596d8-ae35-4d13-ab41-3826f8d0ee4b	2026-01-07 05:43:58.390167+00	9.3	22.2	767903	767903
80e64573-2bfc-4e8e-9179-49fedf3b9a3b	2026-01-07 05:44:32.153056+00	9	22.1	724616	724616
ab6b2e54-55c6-4a91-bd01-89526f6da419	2026-01-07 05:44:52.732805+00	11.7	22.2	65231	12764
047a391f-9a72-440f-9578-40204bd00d03	2026-01-07 05:44:59.423989+00	5.8	22.2	450427	450427
adfd8a57-12cc-4d0d-b2a3-960159b4b9f2	2026-01-07 05:45:11.08783+00	16.8	22.2	610969	610969
c6135b49-f0be-4936-aff5-853631f5e455	2026-01-07 05:45:52.743311+00	11	22.1	76723	14154
e1a7d42a-b99a-4fc8-9fa8-1666de552d14	2026-01-07 05:45:58.307519+00	9	22.2	722768	722768
9ac8bb1e-9189-4418-b322-ca3e5cc9de0b	2026-01-07 05:45:59.458379+00	5.3	22.2	591667	591667
868451e2-597e-46d1-bfb3-e67b83416c25	2026-01-07 05:46:11.233997+00	30.6	22.2	596976	596976
c7e36326-dc19-4adc-9299-9e17e6bd02c3	2026-01-07 05:46:52.764431+00	13.1	22.2	54231	9791
b91e871b-7200-41e0-908a-bcbc831aa8c7	2026-01-07 05:47:09.6751+00	15.5	22.2	1146579	1146579
6d4efd76-feed-4b1e-a64c-aa227f5aab04	2026-01-07 05:47:52.77802+00	10.4	22.2	50215	7676
c0d28c50-0d6f-49e9-a638-49a6bbb735ab	2026-01-07 05:47:59.587018+00	6.5	22.2	346977	346977
85aef27e-4060-42ae-b22f-37bc28eb8032	2026-01-07 05:48:09.938952+00	14	22.2	1124133	1124133
14d42156-a104-4773-b98e-9512114448cd	2026-01-07 05:48:52.794029+00	12.6	22.1	61632	12045
def489ae-df75-4dec-b1ac-26b6064bee4f	2026-01-07 05:49:52.814417+00	19.8	22.2	55341	10752
13e53926-8929-42f3-9319-0ca470c7d151	2026-01-07 05:49:59.437632+00	6.6	22.2	212006	212006
c0fe4232-6d1e-4bfc-bb54-602d51a7b9a2	2026-01-07 05:50:09.955442+00	14.2	22.1	1095616	1095616
40441533-d37f-42d6-ad5a-236393e6ef6a	2026-01-07 05:50:52.805735+00	12.6	22.2	46834	8011
f39f0bd5-c9f5-473d-b9a8-08e641e7a04c	2026-01-07 05:50:58.349831+00	8.9	22.2	542737	542737
d5ff8790-147d-4d24-89ba-9fa341c5c2e7	2026-01-07 05:51:32.236743+00	9.5	22.2	749291	749291
811caa97-2fec-4a7d-928c-46e8c035ef45	2026-01-07 05:51:52.824688+00	13.4	22.2	49793	8492
082c04c6-c5cf-456d-9bb5-d86ec85ac115	2026-01-07 05:51:59.915561+00	9	22.1	265568	265568
c6c321b9-16bf-4941-b92f-e7220faa7604	2026-01-07 05:52:09.58879+00	22.6	22.2	835250	835250
d9ccdedf-efcc-4f0b-bb44-b13b82ffcddc	2026-01-07 05:52:52.871514+00	12.2	22.2	66172	12756
bcd2745a-0950-4689-aff0-1b3a7c0572ab	2026-01-07 05:52:58.257218+00	20.3	22.2	32802	32802
d0672d8e-b2d4-47e8-b45f-41d83d22ea8c	2026-01-07 05:52:59.533755+00	8.9	22.2	597056	597056
150c48b9-792c-4890-a168-ca408465165c	2026-01-07 05:53:11.25932+00	33.5	22.2	664549	664549
4d21aaa9-3f5d-48be-8b73-f70eeca40436	2026-01-07 05:53:52.871348+00	10.7	22.2	50120	10793
6457071e-253d-4c0f-9cae-7a29289381f2	2026-01-07 05:54:08.993332+00	13.7	22.1	828023	828023
d564d12f-e516-4de3-9b24-48c4aec7bf69	2026-01-07 05:54:52.88582+00	17.9	22.2	58836	11456
51395db1-5563-46e6-bc99-fe9b0e928dd8	2026-01-07 05:54:59.555437+00	8.5	22.2	427502	427502
a4609cbb-b0f6-4ee2-b2ef-9f533a8c7ae7	2026-01-07 05:55:09.991103+00	15.3	22.3	950818	950818
e49af01d-e76c-4757-b176-6dfdb2e91d89	2026-01-07 05:55:52.864199+00	12.3	22.2	42733	7225
61c36302-8f08-4b33-90ab-827027499e37	2026-01-07 05:55:59.553469+00	6.9	22.2	520179	520179
670f0bac-5ce5-49fa-82a9-0bbc06b31f17	2026-01-07 05:56:11.416316+00	31	22.4	533205	533205
718f151b-37b8-4abd-a914-5edeb9292f85	2026-01-07 05:56:52.879316+00	18.1	22.2	67159	8562
21a7f3cb-ea79-413d-bf1d-838408374a79	2026-01-07 05:56:59.434915+00	6.8	22.2	586624	586624
300b33c0-ca66-4ea6-ab95-a215ab294ecf	2026-01-07 05:57:08.879504+00	14.3	22.2	1098835	1098835
c2a18a5c-625b-47a5-b126-c447e7e47baf	2026-01-07 05:57:52.894969+00	12.9	22.2	47791	9359
5681a496-d6b2-4991-8d2d-d37c2280e950	2026-01-07 05:57:59.795916+00	8	22.1	490253	490253
3a767c91-31e7-42e5-93cc-e6b0b4f70de1	2026-01-07 05:58:09.335484+00	13.4	22.2	887394	887394
1c31a91c-2be4-4914-aae7-3cb06078f3c4	2026-01-07 05:58:52.944337+00	12.4	22.4	45113	9527
48f25636-6bf4-4409-925a-e7733bb0983f	2026-01-07 05:58:59.811019+00	7.7	22.3	325863	325863
76450e67-26fa-4aa7-a153-36e2cbf3dbaa	2026-01-07 05:58:59.893357+00	7.7	22.3	631197	631197
6d3ad667-606e-471b-a909-121a3b998880	2026-01-07 05:59:09.486125+00	7.2	22.2	275479	275479
5a10160d-92c0-46fc-a830-458b62face4a	2026-01-07 05:59:10.308246+00	7.2	22.2	1043776	1043776
a462a84b-3190-4f5e-806b-b7c8750e668e	2026-01-07 05:59:52.918818+00	12	22.2	63142	12248
37412912-e15f-405f-966e-ffeef8783c0b	2026-01-07 05:59:58.248949+00	9.8	22.3	514905	514905
d9f0586c-eaf3-4b7d-a474-23db90daa4ec	2026-01-07 05:59:59.349257+00	7.5	22.3	698944	698944
238ad51d-54f0-4502-b614-b7295c54b0ce	2026-01-07 05:59:59.349422+00	7.5	22.3	350998	350998
2e8f8ab3-2bfb-4679-91a8-1086727953d7	2026-01-07 05:59:59.43918+00	7.5	22.3	617756	617756
3ab0b6a4-5961-475b-8baf-1a2648d0fc68	2026-01-07 06:00:09.175575+00	21.9	22.3	621791	621791
f7f29343-a4c1-456c-8dd3-dc5fa6084360	2026-01-07 06:00:10.005782+00	21.9	22.3	1414820	1414820
fd6f45d9-11c2-4dfa-99b3-7f09cf70c4de	2026-01-07 06:00:11.396748+00	18.4	22.3	853375	853375
dbfcf43a-aeb0-4bf2-9a1e-70497069d10d	2026-01-07 06:00:32.323257+00	8.9	22.4	1163871	1163871
2305e1e7-6d9c-42d6-a043-a86e98dcbcda	2026-01-07 06:00:52.964237+00	18.3	22.3	87410	12003
7d5f8e0d-35d6-4ed3-87a4-e1c5e1eeeaf8	2026-01-07 06:00:58.465236+00	10.4	22.3	715434	715434
d89236ce-22ec-47bf-99c6-62da5c2714d1	2026-01-07 06:00:59.566398+00	9	22.2	421236	421236
14786f45-a166-40e5-9c4e-3dd71ae7025e	2026-01-07 06:00:59.600635+00	9	22.2	381157	381157
e2a333a6-5902-4077-9c6f-f284def70900	2026-01-07 06:00:59.681654+00	9	22.2	655033	655033
3588db64-5b65-4ffa-8984-f0202346512f	2026-01-07 06:01:09.092113+00	21.9	22.2	602459	602459
1d5c4cee-e23a-4787-af39-dbc662a3c0c9	2026-01-07 06:01:09.095363+00	21.9	22.2	434114	434114
1940047e-9259-45d8-bdfa-1e830e798831	2026-01-07 06:01:11.229699+00	73.6	22.2	846049	846049
b982ace2-228e-4523-8e1e-a6cd324a1ddd	2026-01-07 06:01:52.977886+00	10	22.3	74966	10915
9b670f8c-374c-46ae-af97-33491079add9	2026-01-07 06:01:58.244293+00	9.4	22.3	280157	280157
55b51c26-6e3c-49d1-9f9c-25700fe9b21d	2026-01-07 06:01:58.250803+00	9.4	22.2	639955	639955
ac0b7597-bb1e-4b83-b6aa-7236315c4f34	2026-01-07 06:01:59.369563+00	8.9	22.3	247953	247953
512e373c-3bd3-4391-b2cd-424eccab30dd	2026-01-07 06:01:59.369645+00	8.9	22.3	404441	404441
95f35a35-fa6f-496a-bcb8-018ba764176c	2026-01-07 06:02:08.957406+00	8.4	22.2	977140	977140
47fbea62-1e7a-412a-ad59-018bfd849f5b	2026-01-07 06:02:08.965955+00	8.4	22.2	796422	796422
62aacaf5-1194-4117-bbd0-0cd4e406cc28	2026-01-07 06:02:11.099487+00	24.9	22.2	856829	856829
e172b952-db25-4015-a53a-c09233438efb	2026-01-07 06:02:32.200051+00	11.3	22.3	885796	885796
70805c9b-6160-4495-b90f-238f85545561	2026-01-07 06:02:52.98068+00	12.9	22.3	49564	9725
44abd764-3ea1-4e81-9cd2-bc2944bcf611	2026-01-07 06:02:58.262391+00	10.9	22.2	641394	641394
bb6783ce-a42a-4e01-a752-47d999aa7a14	2026-01-07 06:02:59.368473+00	9.6	22.2	214751	214751
a31855e4-711b-4289-a9c2-41b9d4137300	2026-01-07 06:02:59.463234+00	9.6	22.2	582143	582143
ee615bab-5f2d-40b9-9e16-d24dbefa54f9	2026-01-07 06:03:08.94987+00	22.2	22.3	913781	913781
d6acfb2c-e776-4485-82d7-895f964908ea	2026-01-07 06:03:08.958373+00	22.2	22.3	550178	550178
4226f08c-1d85-482a-bbeb-2f4027ff47a0	2026-01-07 06:03:58.409198+00	10.6	22.3	707269	707269
904a8039-8b99-495d-aa16-bfc847e620fc	2026-01-07 06:03:59.608094+00	8.6	22.2	328919	328919
af92b19d-da15-4484-a26f-f953771e2dc3	2026-01-07 06:04:09.107934+00	15.7	22.2	550231	550231
4edec0ea-0d0e-4512-b816-c0885081863f	2026-01-07 06:04:32.214654+00	10.7	22.3	880258	880258
51f60ede-34e5-4b80-a025-41c37566e7d9	2026-01-07 06:05:08.98438+00	12.7	22.2	568934	568934
92a8e826-5302-40b3-a0aa-db704ada6ec2	2026-01-07 06:05:58.234225+00	10	22.3	323784	323784
a134203c-80ad-4e35-93e1-361f5b03bc6f	2026-01-07 06:05:59.408705+00	9	22.2	309656	309656
ecf2ad45-a66f-4d17-93f8-74b314ca1646	2026-01-07 06:06:09.829119+00	17.1	22.2	673000	673000
c6b8c213-e05f-4ea6-a9d5-d49d19ba1eeb	2026-01-07 06:06:32.206815+00	8.8	22.2	730792	730792
1cb6682a-d36c-476b-b4a6-7f455708f169	2026-01-07 06:06:59.567928+00	8.1	22.3	606228	606228
31bf02da-df0d-4263-929c-c09941e45149	2026-01-07 06:07:11.231217+00	29.6	22.2	694151	694151
0a485270-7fa9-4337-887b-99550a650e9f	2026-01-07 06:07:59.371219+00	7.7	22.3	350626	350626
48f0d69a-343c-46d2-a23c-fb0446f6e9ff	2026-01-07 06:08:11.114509+00	73.1	22.2	659284	659284
0d71198b-6ca8-49ec-a9ab-8d06ab9d5b80	2026-01-07 06:08:58.353538+00	8.9	22.2	290856	290856
1ac6e128-0514-4a4b-9eb1-17804e47775d	2026-01-07 06:09:58.511705+00	8.6	22.2	41987	41987
1872a34b-535f-4db5-bf2e-bd676bcc0bf6	2026-01-07 06:10:09.184319+00	7.8	22.3	573213	573213
40b17a8e-0c6a-43a9-983b-d3eefcbcfb0e	2026-01-07 06:12:09.506065+00	15.5	22.3	958209	958209
0ea577b9-4b5f-49d5-8caf-d50592229272	2026-01-07 06:12:10.357175+00	15.5	22.3	1135862	1135862
08b124d3-1626-47d1-8c47-e3d9e8b333f1	2026-01-07 06:13:32.190734+00	9.9	22.3	827807	827807
f26f231c-8044-457d-bd07-7c1307a6e4d1	2026-01-07 06:14:59.885899+00	7.9	22.2	493004	493004
09133a46-de66-4d22-bcc4-699af0fc549d	2026-01-07 06:16:10.631052+00	29.7	22.2	1013675	1013675
90dc41fe-9eca-42e6-8ddc-100f82e198cc	2026-01-07 06:19:59.387527+00	6.9	22.3	501523	501523
0bc3e21e-8ba7-462d-8952-395e1389f744	2026-01-07 06:21:11.458784+00	71.7	22.3	642068	642068
3a7bf7a3-461f-466e-ba33-110a62e6820f	2026-01-07 06:21:58.521926+00	10.3	22.3	214432	214432
4f0c7a83-c94b-411b-9563-3326b1497606	2026-01-07 06:22:09.315273+00	18.4	22.3	886068	886068
de5c6092-da11-4f27-9829-0056bb2e3e66	2026-01-07 06:22:58.42571+00	8.9	22.4	500653	500653
c3350449-e289-4afc-adde-b0ff009e1d4c	2026-01-07 08:04:54.112726+00	7.9	22.2	15801	7711
26501720-b181-4fef-8f1b-8a78ed63e5f6	2026-01-07 08:41:56.649578+00	7.1	28.2	320383	320383
9f5e8ede-d0ec-4811-bd37-80eb6eaa55a2	2026-01-07 09:27:56.691231+00	24.9	29.9	8814	176434
e8a001d7-1a3e-472a-a078-63d9136afb41	2026-01-07 09:53:52.096107+00	4.6	24.5	100497	100497
4e2b31ab-35c9-4b78-8663-03dad7d9c159	2026-01-07 10:13:12.7308+00	15.3	28.6	3970	2639
f8685c3f-bf39-4ee1-a7b6-fa8e43a0910b	2026-01-07 10:34:12.961315+00	5.7	26.4	4767	3302
df744706-e359-4b0f-8db3-f3d457b9f3ac	2026-01-07 10:51:52.107543+00	11.8	31.6	568956992139	568956992139
36ffee87-e5a6-4475-a56c-336b814d006c	2026-01-07 11:08:13.352275+00	53.7	34.2	130518	34009
d0af6bf5-9303-4479-8f64-f081039ecd9a	2026-01-07 11:27:52.082554+00	5.9	32.2	0	0
059990bf-0f71-49a6-bb3f-c87e19082254	2026-01-07 12:17:51.923774+00	67.3	34.1	442649	442649
a6e9c1dd-684f-46be-b2a9-4ff4a74c22da	2026-01-07 12:18:27.820471+00	46.3	35.3	5932867	5932867
6dd119a3-868b-4c31-83bf-9de16c53c303	2026-01-07 12:18:54.299666+00	67.3	34.6	780885	780885
399076fd-df87-48b2-85ed-d68429ccbd9d	2026-01-07 12:19:51.899968+00	31.6	29.6	450711	450711
d041096e-365c-41d9-904e-21d052fa58ad	2026-01-07 13:24:31.512919+00	30.1	30.9	2614851	2614851
158ffb08-11bd-4a0b-8efa-edd58dd3a03c	2026-01-07 13:24:51.901259+00	33.3	30.9	273724	273724
9d6e7940-30a4-4c2b-b008-a99051c7547d	2026-01-07 13:24:53.820199+00	33.3	30.9	3820253	3820253
04a5b888-f7a5-43a6-8c5a-950f3f5cbe14	2026-01-07 13:25:36.902028+00	31.7	31	2545112	2545112
3f9dd395-e812-47e4-a4ba-0174f09b6fdf	2026-01-07 13:26:36.870772+00	31.3	30.9	1301531	1301531
ec5b8c2f-175a-4fe7-ada6-5c4ed63434fd	2026-01-07 13:27:36.860783+00	31.4	30.9	6366758	6366758
de9d74f5-36cd-4874-a855-9d6668fa7a73	2026-01-07 13:28:31.536014+00	32.6	31	860182	860182
7e292cb0-be55-44c3-8489-1622398325d9	2026-01-07 13:28:51.902381+00	33.7	31	244350	244350
9a8463e3-a9e5-4449-8ea7-9b6103331b41	2026-01-07 13:29:31.508444+00	29.6	30.8	1322454	1322454
e7392912-4fd1-4314-b462-738b96df9dcc	2026-01-07 13:29:51.999679+00	35.1	30.8	152111	152111
d3b368c0-d08d-4e5f-b955-ba30d0d099d4	2026-01-07 13:29:53.831927+00	37.8	30.9	3352281	3352281
f1cc6bf1-ae04-4245-b6a2-dba79a6a210c	2026-01-07 13:30:31.610853+00	32.8	31.1	2878227	2878227
179c332e-1e2e-437c-9dab-1a390774808a	2026-01-07 13:30:51.895392+00	32.4	31	200590	200590
8c706d58-a147-4a5f-839b-cd4994c77d3c	2026-01-07 13:30:53.837354+00	34.7	31	5517157	5517157
e4adca59-0644-451e-b6eb-0fd99ddda035	2026-01-07 13:31:31.520016+00	32.8	31	3083105	3083105
de45ff72-8389-4abe-aea6-8989a2b65878	2026-01-07 13:31:48.151467+00	33.5	30.9	2448363	2448363
49ca5e08-0477-4293-b643-cbc9b29736ca	2026-01-07 13:31:53.855392+00	37.1	30.9	4085996	4085996
11eb3e2b-39a0-4e38-8358-c299650f7302	2026-01-07 13:32:27.851782+00	34.9	30.9	385629	385629
2eb81308-6fce-4216-9f94-2c3edfc05765	2026-01-07 13:32:36.884772+00	32.8	30.9	3525513	3525513
5e6b9b83-315d-41b8-89ad-d56fc506daaa	2026-01-07 13:32:53.844378+00	30.8	31	3841525	3841525
07f77d3a-dc3b-43f0-b02d-68b2b8dbbc83	2026-01-07 13:33:36.906905+00	33.8	30.9	1479655	1479655
e5d6ba1d-7c9b-4d5e-9412-3d4b8e7ef432	2026-01-07 13:34:31.541526+00	31	30.9	3633920	3633920
74117b32-4d7d-4400-8d33-47a61d8a30d4	2026-01-07 13:34:51.941669+00	30.1	31	3821913	3821913
e69f0d76-c1a2-46be-b905-fa5fa968ace3	2026-01-07 13:34:53.842051+00	32.2	31.1	2088529	2088529
95fe3a05-37fa-40e2-afe6-4d35f5a43671	2026-01-07 13:35:31.515559+00	32	31.2	1381660	1381660
e1709cc5-00a0-4de4-b1bc-a6543ec58645	2026-01-07 13:35:51.92895+00	30.6	31	3150070	3150070
53006b01-b9a4-42e5-92b4-504aedc38468	2026-01-07 13:35:53.83941+00	32.6	31	3342781	3342781
d2408b15-d5d8-468d-8ffe-0c4579d38d9f	2026-01-07 13:36:31.512125+00	30.4	31	4787371	4787371
f76281a6-b37c-4db2-9837-fc9212934ac3	2026-01-07 13:36:51.959552+00	30.6	31.1	3255949	3255949
9919e7bb-f3d1-4c46-b5ac-4dfd2f2bc14a	2026-01-07 13:37:36.852332+00	32.7	31	4950824	4950824
5cbc2b83-14c2-48d3-a14d-5c28d57d4f4d	2026-01-07 06:03:09.708713+00	22.2	22.3	1049858	1049858
dbecb72f-04d9-495f-95c8-b275defbb274	2026-01-07 06:03:52.99882+00	18.5	22.2	47935	9626
aa3ced15-50f3-47df-927f-242028667d22	2026-01-07 06:03:59.496687+00	8.6	22.2	309849	309849
d374f197-aa79-4f37-ab7f-9c865407eb02	2026-01-07 06:04:09.111228+00	15.7	22.2	526184	526184
3b894ac0-e571-43ce-81b1-158fade86eca	2026-01-07 06:04:59.435506+00	7.7	22.3	310109	310109
c4b3c6dd-549a-45d8-aaeb-2c7dffa5192e	2026-01-07 06:05:11.134097+00	18.5	22.2	680234	680234
93753abf-5a99-4d08-8d6e-8b6e26f16dd2	2026-01-07 06:05:32.244815+00	23.4	22.3	877206	877206
c2d71440-82f6-49ca-a8c3-c216b011f53f	2026-01-07 08:05:54.114818+00	9.7	22.2	17811	12835
abacd4d2-3cc9-485d-8cd7-35654b8e49ae	2026-01-07 08:42:08.457988+00	6.6	28.2	285528	285528
9439e9f4-ba11-4ff9-b469-d7b1b7e23841	2026-01-07 08:45:04.249692+00	8	27.1	305750	305750
af58e208-3ce9-42b7-84bb-71f8f2835bbc	2026-01-07 09:27:57.663274+00	24.9	29.9	110931	110931
d1d8c415-33bb-45db-9a3c-76b929a31823	2026-01-07 09:28:52.02304+00	5.7	29.3	233988	233988
579ad905-8e61-4580-a6ef-7812c24c1ff2	2026-01-07 09:28:54.008271+00	8.9	29.4	7688	7688
86d87295-3466-4157-a3cf-1b9546b97cbf	2026-01-07 09:29:25.491484+00	6	29.6	122133	122133
e2df15e5-e408-449a-a3e3-89cf67f0aec6	2026-01-07 09:29:51.919102+00	7.5	29.3	321311	321311
10335f5d-966b-4594-8660-00eb3101e140	2026-01-07 09:30:51.961307+00	8.4	29	145645	145645
0574ba17-20be-4299-bca0-74a79f136304	2026-01-07 09:31:51.850469+00	23.9	29	815556	815556
31cec088-980c-4065-83cb-2c270c70a7fc	2026-01-07 09:32:51.950551+00	10.8	28.4	201330	201330
01633ce8-0b31-4cc6-957b-52ede406d863	2026-01-07 09:33:52.025606+00	8.2	29.2	88532	88532
0908aaff-698a-4af8-a82c-697b440f3f47	2026-01-07 09:34:52.000727+00	11.1	30.7	530421	530421
0a6d5029-2f63-4f11-b4ce-8cf8a0bb710b	2026-01-07 09:35:51.899622+00	28.5	30	467229	467229
c20e270c-8074-4c80-9965-7c8bd893ea9b	2026-01-07 09:36:51.867271+00	41.6	32.4	492874	492874
9ecc9e57-70e9-4767-8d8f-cd5ea5e40b0a	2026-01-07 09:53:52.106056+00	4.6	24.5	95766	95766
4315a508-027a-4ae9-9d14-85383ffa12c4	2026-01-07 10:13:52.119773+00	4.4	28.7	1057394	1057394
94b128d9-f1a0-4238-8bfe-263820c215e2	2026-01-07 10:34:52.099263+00	5	26.4	153566	153566
2986732f-df2d-4a25-bef6-f7275d43544b	2026-01-07 10:51:52.107541+00	11.8	31.6	35175	35175
df10d081-90eb-4035-90aa-ba462ba99879	2026-01-07 11:08:52.077741+00	37.2	32.2	244490	244490
86a9459c-3a5a-4eb3-97d9-58d8587295ae	2026-01-07 11:28:13.634544+00	21.3	30.4	7571	4577
aa741437-3bb4-47cf-909f-2ab0f64307b1	2026-01-07 12:20:51.93931+00	29.6	34.4	508084	508084
2e173d4b-6de7-472a-b3bf-6d3042e62923	2026-01-07 12:20:54.316011+00	33.5	35.6	525172	525172
d5e235f1-74d7-4e31-a906-be5755852904	2026-01-07 12:21:51.902483+00	19.8	31.5	790067	790067
9bef904b-e2d9-4364-aa7b-681ef067ac7f	2026-01-07 13:37:31.516154+00	32.1	31	6563378	6563378
9fc08f31-e6ce-4897-8458-85a5ffbd76a9	2026-01-07 13:37:51.951385+00	31.6	31	2997079	2997079
7dbd7194-1f0f-4a4d-9fb6-7710afacd4b3	2026-01-07 13:37:53.830421+00	31.7	31	4277309	4277309
31209e4e-9462-4579-ba02-b5e14ec92acf	2026-01-07 13:38:31.514498+00	32	31.1	553099	553099
2ac7da1a-ef17-4e0b-83e6-0447f042fea0	2026-01-07 06:03:58.403755+00	10.6	22.3	301605	301605
b5c7ce20-3174-4b76-8f56-31ed71378259	2026-01-07 06:04:11.261525+00	24.4	22.3	858680	858680
93fc3f3c-4019-48af-b6ae-ba8bd58199e4	2026-01-07 06:04:59.434417+00	7.7	22.3	469565	469565
64670a86-6a47-4aa1-8b31-76171d28e1b3	2026-01-07 06:05:09.77116+00	12.7	22.2	967098	967098
27e4da52-da7a-43fd-97ee-b514d5cee479	2026-01-07 06:05:58.240119+00	10	22.2	690621	690621
ca90a465-3379-4592-a41d-1e51671c7535	2026-01-07 06:05:59.498589+00	9	22.2	694457	694457
55e885af-0793-40c1-a191-563bd3af0aa0	2026-01-07 06:06:59.486079+00	8.1	22.3	629480	629480
5e74042e-d304-4fb7-8217-0a9cc5b56275	2026-01-07 06:07:32.217977+00	19.8	22.2	786516	786516
12396b62-4cf0-4631-88e4-ecad50b33f35	2026-01-07 06:07:59.370217+00	7.7	22.3	331723	331723
430ef758-deea-4295-9eb0-2aa036e02a98	2026-01-07 06:08:09.690286+00	22.2	22.3	819421	819421
e38c9f23-8c96-4a3d-b79d-d6f05b7a2476	2026-01-07 06:08:49.098734+00	20.5	22.2	39133	39133
ddb1915b-336e-41e1-8e47-0f0558f777ee	2026-01-07 06:08:59.544627+00	7.1	22.3	543413	543413
771503d7-3c66-4c2f-8a43-56e04912e29e	2026-01-07 06:09:11.509873+00	73.6	22.2	880097	880097
a4240702-00b9-4028-9e55-48335118f5ab	2026-01-07 06:09:32.385049+00	10.4	22.2	1117719	1117719
48df5585-d7ee-414c-a822-1685a01675e0	2026-01-07 06:10:09.181994+00	7.8	22.3	262756	262756
323f3ac3-1196-425c-a16e-22905a475e77	2026-01-07 06:10:58.232193+00	10.2	22.2	600641	600641
12378054-0dcd-4723-8ed8-29a392c5fbbc	2026-01-07 06:11:09.000949+00	7.3	22.3	874123	874123
88dbcc33-f91b-4956-aada-91098a00a908	2026-01-07 06:11:58.435586+00	11.5	22.3	721011	721011
2c3a0b15-6bcb-47cf-8e35-b3871f628e3b	2026-01-07 06:12:58.49493+00	9.3	22.3	500337	500337
729069f1-7a14-449e-abdf-aef366ce3e57	2026-01-07 06:12:59.751944+00	6.2	22.3	721463	721463
55a6151c-668f-4d70-be4a-40434c6440a4	2026-01-07 06:13:11.631197+00	23.9	22.2	586390	586390
4294c866-7fb1-4c9b-87b9-1ec1e0063d74	2026-01-07 06:13:58.564338+00	10.1	22.4	614913	614913
88f37105-65aa-4f4f-b667-4487dc8f7403	2026-01-07 06:15:58.638389+00	9.1	22.2	356050	356050
5dd880ed-c79e-46ce-ad5d-78c0e3f42f58	2026-01-07 06:16:00.071643+00	8.1	22.2	448053	448053
a5dc86fd-f76a-4c7b-adab-e8f7870242c6	2026-01-07 06:16:12.115269+00	29.7	22.2	740306	740306
29048d34-4fef-48d3-91f9-f83a17bc6940	2026-01-07 06:16:58.304702+00	9.2	22.2	549280	549280
14c98b50-b099-4920-b51f-08c95ab4daed	2026-01-07 06:16:59.370857+00	8.5	22.3	339984	339984
70c4f143-e18c-496d-8603-76ff7726bb96	2026-01-07 06:17:09.875226+00	17	22.3	1219702	1219702
17468f7b-848c-40ca-a8d1-dce3ca3596b2	2026-01-07 06:17:58.405495+00	9.6	22.4	751933	751933
ed02a674-1fca-4d80-b8ac-f259378e90e6	2026-01-07 06:18:09.152336+00	9.4	22.3	553446	553446
13a181c6-2543-45b6-a223-25a0c8391854	2026-01-07 06:19:09.115222+00	16.5	22.3	20884	20884
8f799576-6fce-4f74-a902-851d7c695f1e	2026-01-07 06:19:59.386254+00	6.9	22.3	1587592	1587592
b5ddfec2-08c2-4ce6-b317-7a63e9061e22	2026-01-07 06:20:11.178692+00	73.6	22.3	744105	744105
d755654a-0b37-4e79-a424-b7d10be54d32	2026-01-07 06:20:58.427109+00	10.6	22.3	530227	530227
5533d076-da09-45f7-a9fd-86de427a90ed	2026-01-07 06:20:59.506489+00	9.6	22.3	144196	144196
bf6b6ddc-e54a-4654-8dea-59e8397af41d	2026-01-07 06:21:10.045541+00	8.5	22.3	892369	892369
8f06cb78-9255-41f6-9817-d2ac67ae6312	2026-01-07 06:22:59.620081+00	8.4	22.3	421960	421960
6d6dcd83-4d51-40e8-8dc0-8f86a9ed4322	2026-01-07 08:06:03.746721+00	5.9	22.1	379461	379461
6261f368-dd90-423b-a1d8-f06203969fa1	2026-01-07 08:08:03.716934+00	7.4	22.2	340766	340766
1ca39e62-8b4c-498b-aded-08e09cf1548f	2026-01-07 08:09:03.731714+00	6.8	22.2	348093	348093
5aaf148e-0967-47a6-8a48-06e54e1a1e68	2026-01-07 08:11:03.737488+00	6.5	22.1	427803	427803
f4509e09-6552-414b-ae4e-e2453fcfb897	2026-01-07 08:12:03.739218+00	7.8	22.1	286919	286919
b3a82563-7b57-43c2-bf1a-cae1c643fde3	2026-01-07 08:19:03.721085+00	7.3	22.1	446186	446186
5bf15dc6-5861-4456-bf9d-2d76559d71cf	2026-01-07 08:22:03.768438+00	7	22.2	339638	339638
4fa38369-d97b-4e7b-9a0b-4ad155f080a9	2026-01-07 08:23:03.801742+00	6.5	22.1	105248	105248
bbb343cf-d2f8-4bdc-91bf-19e14d0d2070	2026-01-07 08:42:54.487826+00	8.4	26.5	4429	3819
057e5f80-0baf-4679-b8ea-76a1f73edc51	2026-01-07 09:28:35.666282+00	7	29.3	194006	194006
82bdccd3-e39c-4bf7-86fe-349dd3435f84	2026-01-07 09:30:25.584305+00	6.7	29.1	127664	127664
8dc1d9d6-e4e5-4d41-8cc5-85263859b9d3	2026-01-07 09:31:08.102786+00	9.7	29.1	318744	318744
4a59fd39-aa2b-42c7-8495-5f641bbb8b57	2026-01-07 09:32:08.203234+00	10.6	29.2	64482	64482
19250fb5-f1b1-4389-bcdf-14d6bbf89508	2026-01-07 09:33:08.112505+00	7.8	29.1	110416	110416
920fe5dd-1e79-4f4b-999d-217efadaa16d	2026-01-07 09:34:08.102617+00	7.9	29.2	75598	75598
e69dfc48-386a-407f-b73c-a639db77b0f2	2026-01-07 09:35:08.138742+00	8.3	30.8	338439	338439
120b64d4-8dee-4a54-bd41-4f71b5b8491b	2026-01-07 09:36:08.103823+00	20.7	30.1	98921	98921
917c4782-2e32-4131-8c7d-777abf57ebec	2026-01-07 09:54:12.407005+00	4.6	24.5	3552	2102
5cee0d69-4f75-4ad2-8d24-0779eadb4faf	2026-01-07 10:13:55.908086+00	13.8	28.7	5943	5943
246684df-c137-41d4-9012-76b502d5ba6b	2026-01-07 10:34:52.099317+00	5	26.4	0	0
e6dacb28-0a07-4789-8a0e-067c0d062947	2026-01-07 10:52:13.215473+00	8.1	29.1	6781	4686
9363b2a8-b82d-4366-be47-51ba957bbb99	2026-01-07 11:08:52.078825+00	37.2	32.2	73921	73921
361b9c57-a74b-453a-a30d-3c0ac84d8549	2026-01-07 11:28:52.036561+00	5.2	30.3	127214	127214
77c55cf1-5d82-4d44-a73a-72e066b8117b	2026-01-07 12:20:51.94167+00	29.6	34.4	540210	540210
5e962f13-8fc0-4820-8dab-d2359e256475	2026-01-07 12:21:41.485404+00	19.5	31.4	830491	830491
36e5c78d-b7e9-4d1b-9531-55f94d2658a9	2026-01-07 12:21:51.910426+00	19.8	31.5	123636	123636
2fbdc478-204a-428b-b0ff-01c413d054a1	2026-01-07 13:38:36.876762+00	32.9	31.1	3594345	3594345
82cdf85e-a236-42fa-9c16-1b0b54618ddb	2026-01-07 13:39:31.524471+00	31.1	30.9	1204863	1204863
09cc2f8f-4197-4eec-825f-0851adbe05e8	2026-01-07 13:39:51.945059+00	30.2	31	1683217	1683217
3e77938a-5699-44c7-89cd-2d766214606d	2026-01-07 13:40:31.507893+00	34.1	31.1	3273053	3273053
c6332f80-9de7-4dbb-9747-10518c2257a4	2026-01-07 13:40:51.932162+00	29.7	31.1	4299954	4299954
cda87f42-4952-417b-9e30-f17baa52272e	2026-01-07 13:40:53.849487+00	32.9	31.2	1466834	1466834
a43cd6dd-b891-40f2-ae34-d84b3893c989	2026-01-07 13:41:36.919232+00	28.7	31	1419225	1419225
5cef1871-fb1a-4fff-bb87-f0e439c115fb	2026-01-07 13:42:36.902288+00	31.5	31	3476000	3476000
af03744a-5700-43ac-bc8a-8d831310c4c5	2026-01-07 13:42:53.859631+00	32.7	31	2812106	2812106
ccac6bbe-7c20-4867-8229-6a7d1e73bca6	2026-01-07 13:43:36.861677+00	27.7	31.2	2920656	2920656
50c3193d-37e0-49a2-b910-bed79357b576	2026-01-07 13:43:53.839147+00	32	31.3	3386776	3386776
11c9b2b1-d45f-4c9a-ac29-4759a23778e6	2026-01-07 13:44:31.515938+00	31.3	31	6274569	6274569
a5ed61bc-e7a6-40e7-a41f-77f7a25437c5	2026-01-07 13:44:51.964469+00	32.3	31	314706	314706
361ccbe2-d81b-407e-8cef-9c96d5ee7932	2026-01-07 13:44:53.952034+00	32.1	31.1	2326755	2326755
ecb9efda-72d0-44ae-b638-b668a03dcfd4	2026-01-07 13:45:36.936052+00	31.7	31.2	2485197	2485197
498cdc28-5516-4b47-bd28-422b4576663f	2026-01-07 13:46:36.479381+00	36.4	31	2342372	2342372
0f2a12a6-13f2-4b95-9c68-8fe9c2fc2813	2026-01-07 13:46:51.972197+00	32.3	31	3571390	3571390
96d0f496-ea4d-441e-8e6a-553ebe7ea469	2026-01-07 13:46:53.853614+00	32.4	31	3673052	3673052
57fcb108-7b93-47bd-86cd-bceeb544ae1a	2026-01-07 13:47:36.890954+00	35	31.2	2369090	2369090
30be241f-3df2-46c3-ac43-906d0b6ea02d	2026-01-07 13:48:36.880251+00	38.4	31	2027655	2027655
2245c31f-8962-4478-8b14-766dd1488ece	2026-01-07 13:49:36.401809+00	31	31.1	1032476	1032476
cfc7bd3e-01f6-4990-ad93-88eb75997392	2026-01-07 13:49:51.93342+00	34.2	31.1	238151	238151
bef894d4-a63e-4ab5-90d1-642e685b4ee3	2026-01-07 13:50:36.390409+00	30	31.3	2891187	2891187
cfb7c331-436c-4579-9e49-903116fe55a3	2026-01-07 13:50:51.906053+00	28.7	31.2	3733072	3733072
05afd382-d060-4063-b49c-5fe26f4c5b73	2026-01-07 13:51:36.901815+00	30.5	31.1	2948915	2948915
4232a13f-f75a-4c6d-aac9-bcab338d8870	2026-01-07 13:52:36.39061+00	30.3	31.1	3030475	3030475
a7489641-e2c8-476c-86d7-70a8a5ff96b1	2026-01-07 13:52:51.90424+00	31.9	31.2	3258241	3258241
a97ac98a-ecb8-4de3-a531-9c48da4c0e6a	2026-01-07 13:53:36.905322+00	36.6	31.1	1305751	1305751
c26ed398-8517-412f-aba7-3159e371598b	2026-01-07 13:54:36.870732+00	33.4	31.1	4373140	4373140
ed4aa5c0-b750-4af9-8ac0-ba08254d1671	2026-01-07 13:55:36.853133+00	32.7	30	1293567	1293567
17cf41ff-d717-4df3-996c-88b652fd8544	2026-01-07 13:56:36.354557+00	61.1	31.9	1278189	1278189
08700187-ba06-42a8-967a-5c3bd3034e75	2026-01-07 13:56:47.826267+00	31.9	31.5	713063	713063
fd263d47-7a4d-4d51-b05b-dc4a2091590c	2026-01-07 13:57:22.937014+00	39.2	31.1	1651448	1651448
cc92d9d1-452b-4c1d-b574-db35056ab439	2026-01-07 13:57:36.373929+00	43.6	31.4	3073167	3073167
579f2b2e-fc89-48cb-8f5b-d515a09b4603	2026-01-07 06:03:59.495617+00	8.6	22.2	256282	256282
724ca6a4-c957-4d3c-a1e7-b2f9f41d2e5b	2026-01-07 06:04:09.884289+00	15.7	22.2	1082892	1082892
eb1d702b-123e-4566-ae75-de23688e4030	2026-01-07 06:04:53.011648+00	12.1	22.2	75340	11267
d4e2514f-e67b-4ade-9ede-0a23ba8644df	2026-01-07 06:04:58.280928+00	8.7	22.2	435969	435969
8c8b85fe-0ee3-4cc6-ae75-53101ab8dd6d	2026-01-07 06:04:59.514387+00	7.7	22.3	654492	654492
5e53b6ab-27de-4a34-99ee-5f5fa7dbda16	2026-01-07 06:05:53.01076+00	13.4	22.3	79033	10006
779317fd-d91d-4eaf-a70e-31f81ec81d45	2026-01-07 06:05:59.413206+00	9	22.2	361521	361521
e08b53aa-e938-47c2-80e5-6ff7e81ef6c6	2026-01-07 06:06:08.963542+00	17.1	22.2	877173	877173
f9a128fc-aded-4ce5-8f76-cb08196c0829	2026-01-07 06:06:09.052633+00	17.1	22.2	429116	429116
f6cc266a-4ec2-4dca-b425-e580746778d0	2026-01-07 06:06:11.268916+00	29.8	22.3	614856	614856
63e0de65-3f0c-4f5c-b4b2-a5b28858b388	2026-01-07 06:06:49.085042+00	8.8	22.2	32491	32491
bfc072b3-5049-42e5-9ac2-0101a7f36dba	2026-01-07 06:06:53.025262+00	16.4	22.3	54198	9146
57409116-4fc1-4864-b1cc-78b72a68378e	2026-01-07 06:06:58.343819+00	9.4	22.2	404744	404744
96e2cac1-1350-4ee8-8538-942921b03f03	2026-01-07 06:06:59.486077+00	8.1	22.3	644455	644455
f6d0de04-8972-4f94-b922-514dbfb8dbaf	2026-01-07 06:07:09.021912+00	14	22.2	754916	754916
6a5bb1aa-5416-439c-a664-b1ac852d9aa5	2026-01-07 06:07:09.027109+00	14	22.2	738579	738579
cc6d7048-eaee-4335-ac16-4d9598ebd65b	2026-01-07 06:07:09.797447+00	14	22.2	1248106	1248106
db550a5d-9d2f-44c4-a082-565d73a1514a	2026-01-07 06:07:53.043521+00	12.2	22.3	48823	10414
d63b74f1-b6fe-462a-adfe-d1b5b938547b	2026-01-07 06:07:58.267589+00	9.2	22.2	672966	672966
de4c62e0-a59b-497d-8653-128629359938	2026-01-07 06:07:58.307805+00	9.2	22.2	687188	687188
35a043ce-eed5-4341-88aa-5d501e44cfaa	2026-01-07 06:07:59.450007+00	7.7	22.3	688782	688782
39ea47a2-f1c3-4ad3-8da7-3d20262f5dd0	2026-01-07 06:08:08.916908+00	22.2	22.3	971664	971664
10355c55-b14c-403c-9a5d-3637abde84cc	2026-01-07 06:08:08.925514+00	22.2	22.3	928281	928281
46cf5e34-6a69-4943-bf87-640112124480	2026-01-07 06:08:32.196689+00	20.5	22.2	594181	594181
7febf9a6-fc13-4119-ac35-611e596c9ea9	2026-01-07 06:08:53.054653+00	11.8	22.2	48183	9901
59f9d791-bd05-4729-a3af-72b413982382	2026-01-07 06:08:59.543804+00	7.1	22.3	442505	442505
d6b8db59-c0de-41b9-8f39-8952a5a5f09b	2026-01-07 06:08:59.641566+00	7.1	22.3	505341	505341
d76e6164-5eba-4bfb-b238-530d6a2bfc22	2026-01-07 06:09:09.28647+00	6.4	22.2	421523	421523
12d9899c-114b-4804-8c0d-d1cb73c70b05	2026-01-07 06:09:09.287358+00	6.4	22.2	788255	788255
0ce804a0-0cc4-4a59-99ba-d59c4f01394b	2026-01-07 06:09:10.157773+00	6.4	22.2	1058311	1058311
4fd9bc8b-30cf-45b7-9c07-7900cd36223a	2026-01-07 06:09:53.072708+00	12.2	22.2	76470	10437
b2fafe01-86c8-4a0f-9ebf-27c01fb86a42	2026-01-07 06:09:58.476896+00	8.6	22.2	404533	404533
17662507-15dd-42a8-baa9-4909c0aae9bd	2026-01-07 06:09:59.506326+00	7	22.4	236621	236621
b7d202dd-7559-4bea-a9c8-649a7ceec788	2026-01-07 06:09:59.563248+00	7	22.4	295363	295363
c622738e-ba2a-4d6c-a586-0e04e07b4467	2026-01-07 06:09:59.618606+00	7	22.4	680035	680035
4fc5e6a4-4486-4ebb-8f67-890b55aa7162	2026-01-07 06:10:10.072239+00	7.8	22.3	1040292	1040292
59f026e8-121a-43e0-b979-04edf610c2a6	2026-01-07 06:10:11.501252+00	18.6	22.2	462942	462942
e1558f66-eaad-4fd3-9d0b-5226f762570a	2026-01-07 06:10:32.261606+00	20.8	22.3	609801	609801
f9d7fae1-895f-4ad8-9a81-0d0689f6b0be	2026-01-07 06:10:53.071617+00	13.1	22.3	73684	9856
b7baadbb-17e2-4c28-a360-2c4cf89d2ed4	2026-01-07 06:10:58.237233+00	10.2	22.3	736416	736416
b8b508c8-13c4-4674-a5eb-d28fcbaa44ee	2026-01-07 06:10:59.338862+00	8.8	22.2	403969	403969
077d4ac7-3d59-460e-9c0f-c3b7038dd21e	2026-01-07 06:10:59.341823+00	8.8	22.2	289361	289361
b8eb985c-e805-4abd-b554-b29013720a4d	2026-01-07 06:10:59.430855+00	8.8	22.2	517562	517562
b0d6d769-7a82-45fa-8d2c-2334a7cfd4ea	2026-01-07 06:11:08.978211+00	7.3	22.3	1019944	1019944
446d221b-e553-47da-804f-4ca17772adea	2026-01-07 06:11:09.773595+00	7.3	22.3	760388	760388
8e817e77-5f2f-4211-b1d4-5238905b90b1	2026-01-07 06:11:11.202495+00	16.8	22.2	774492	774492
9a48af7e-baa9-4a18-a6cc-113f80a9655c	2026-01-07 06:11:32.21468+00	14.2	22.3	1053951	1053951
3cc9757c-53e4-4a79-9796-c3266ccaec80	2026-01-07 06:11:53.077391+00	13	22.3	60968	12572
f01f7343-cbc2-4e7b-aff6-f2cc492d2db7	2026-01-07 06:11:58.429455+00	11.5	22.3	522474	522474
58b84b00-8d88-4a31-b49c-e952ea77d835	2026-01-07 06:11:59.87753+00	6.8	22.3	451119	451119
2980e99c-6367-4c24-887e-546cc9f9d0d5	2026-01-07 06:11:59.879079+00	6.8	22.3	143683	143683
9fbe8b00-015e-458b-8a11-cf8a6c33dbe7	2026-01-07 06:11:59.984827+00	6.8	22.3	675338	675338
a0e9b9e5-00a9-4076-a7dc-fac72d543fa9	2026-01-07 06:12:09.493719+00	15.5	22.3	497314	497314
4bc1b373-d120-45e6-8850-535b000cc071	2026-01-07 06:12:11.777662+00	19.8	22.3	774380	774380
d8ca6e80-8ef8-4a28-a612-13d253637c06	2026-01-07 06:12:32.234335+00	8.6	22.3	1008774	1008774
0a09ce34-72fb-4c59-803a-5a29010bb331	2026-01-07 06:12:53.050045+00	10.7	22.3	64932	12274
c4bc82ed-e6c9-4b86-88ad-edc39f709556	2026-01-07 06:12:58.500331+00	9.3	22.3	407755	407755
3d8ec10b-d74f-4838-9617-802ac93b6035	2026-01-07 06:12:59.615032+00	6.2	22.3	424613	424613
d379d718-8195-412e-a504-3a80bf5b75bf	2026-01-07 06:12:59.618808+00	6.2	22.3	307086	307086
001cfed5-280e-48f0-b5e3-c79e72bf1813	2026-01-07 06:13:09.287124+00	6.3	22.2	890645	890645
6e116fe6-7f64-4c6e-bc84-2aaf9e8c9920	2026-01-07 06:13:09.292242+00	6.3	22.2	864160	864160
19008485-a58b-4d3e-8942-458549fab990	2026-01-07 06:13:10.20877+00	23.9	22.2	990658	990658
a71967e0-0447-4719-9fd6-bbaa6aab808b	2026-01-07 06:13:53.108267+00	13.6	22.3	80538	11471
d1bb99b6-7a3f-4b6d-a568-1c0942cc44de	2026-01-07 06:13:58.558446+00	10.1	22.3	211545	211545
2d24abfb-06ae-4252-804b-3db302f3413e	2026-01-07 06:13:59.81227+00	7.1	22.3	219489	219489
a18247b2-74dc-4e7e-9b74-960251b1d568	2026-01-07 06:13:59.814144+00	7.1	22.3	986389	986389
04a870c6-6c42-4f32-8196-4f96533b5ecf	2026-01-07 06:13:59.991731+00	7.1	22.3	1550690	1550690
505a6a0e-2ba9-467a-bc24-d537666fd061	2026-01-07 06:14:09.375751+00	7.6	22.3	686973	686973
8005f072-3c29-4e9f-9680-7704990ce3cf	2026-01-07 06:14:09.377425+00	7.6	22.3	542869	542869
95cfea69-63c1-4fe2-aca8-5383f7bc5842	2026-01-07 06:14:10.249094+00	7.6	22.3	802293	802293
c75fcc6f-2d57-4fd4-8161-926662a7df34	2026-01-07 06:14:11.654265+00	22.3	22.3	924140	924140
eb2dd735-e496-44ed-a120-cffd2aae49f9	2026-01-07 06:14:32.253626+00	7.8	22.1	673253	673253
cd0b1364-26b7-4738-a29d-35fe2e932037	2026-01-07 06:14:53.106762+00	16.4	22.2	76048	11250
aba67e4b-1992-4f15-87e4-546feeee4491	2026-01-07 06:14:58.42666+00	9.7	22.1	639473	639473
8e8eaa5d-7c8d-49a7-9918-66816f2b8c54	2026-01-07 06:14:58.5704+00	9.7	22.1	364906	364906
9d431e69-5be7-44d4-85da-d9c9e63354c0	2026-01-07 06:14:59.758075+00	7.9	22.2	457597	457597
54a12267-b442-48cf-a2e5-8065b4052b59	2026-01-07 06:14:59.786599+00	7.9	22.2	416595	416595
1b8e5904-0146-4940-a445-c9b8f6a8eeaa	2026-01-07 06:15:09.524614+00	18.8	22.3	576086	576086
7df931f5-67c3-422b-bbbc-fff7d79c7c09	2026-01-07 06:15:09.53224+00	18.8	22.3	456658	456658
5743d8f0-1a77-43cf-bf89-8776abb80ce7	2026-01-07 06:15:10.603276+00	33	22.1	641738	641738
025befbd-4d54-4dc8-b303-4165e4f2afe3	2026-01-07 06:15:11.87344+00	33	22.1	951136	951136
3d520ecd-447c-4969-bfc6-4ffa75e05230	2026-01-07 06:15:32.235881+00	8.5	22.3	750496	750496
20d9c0d6-9d77-4c35-864e-d23476ff6d97	2026-01-07 06:15:53.095736+00	12	22.2	82306	13405
24a0153d-c63b-40e5-bb82-c702646fff0d	2026-01-07 06:15:58.704398+00	9.1	22.2	606494	606494
9c5d0dec-e253-4f4c-9139-616fa280bda5	2026-01-07 06:16:00.04456+00	8.1	22.2	259779	259779
c1b58f15-e0f0-49d1-9d92-09ee9cb9dbee	2026-01-07 06:16:00.221117+00	8.1	22.2	415529	415529
7bb650ce-eea0-4598-a42e-7cf57f1a36db	2026-01-07 06:16:09.781253+00	7.2	22.2	0	0
7f98ac75-0eda-4087-8255-efdb53e3b93e	2026-01-07 06:16:09.781248+00	7.2	22.2	638480	638480
edbafa55-e9b7-4837-a33b-fb1230ad1124	2026-01-07 06:16:32.240321+00	7	22.2	843340	843340
92f07cbc-65f0-4ab0-8a9f-6ab3ad86dae5	2026-01-07 06:16:53.123971+00	11.1	22.3	60936	12601
5e8df528-76fa-4e39-bf6b-5ecdb36891c2	2026-01-07 06:16:58.345836+00	9.2	22.3	409833	409833
7cc4b40d-506e-4b2f-9b34-db55a74a156f	2026-01-07 06:16:59.368173+00	8.5	22.3	281193	281193
56e67520-935e-4519-8a6a-ad2caaa1d144	2026-01-07 06:16:59.47324+00	8.5	22.3	407531	407531
6b5a0b7f-3970-4d80-bab8-511b2a409191	2026-01-07 06:17:09.057707+00	17	22.3	733022	733022
b82c74e6-6b29-4e0d-a4ef-fd6dd62f8ac2	2026-01-07 06:17:09.101738+00	17	22.3	929883	929883
d08c3bd5-967b-4166-9bef-38fa2a39b2d9	2026-01-07 06:17:11.383442+00	41.8	22.3	297769	297769
7357c971-17a6-4c3c-ba97-0786849a35ca	2026-01-07 06:17:32.226129+00	21.1	22.3	818690	818690
21a6673f-5f96-439f-9a77-d3b5dde77a0c	2026-01-07 06:17:53.136788+00	12.5	22.3	56013	10971
99e4579e-054f-40fa-bde5-9807ae903b15	2026-01-07 08:06:54.121344+00	7.4	22.2	10998	12104
9d27d414-9c5d-40c3-bfdd-1a890fa20b95	2026-01-07 08:43:54.457397+00	7.7	27	2809	2534
5af3e4d8-06a0-4948-9453-ea9087e93fdd	2026-01-07 09:28:56.952272+00	7.2	29.4	0	0
97d1cca3-6a20-417b-adb3-ec35b22d7047	2026-01-07 09:54:52.122613+00	4.6	24.6	0	0
cc7c6340-7811-4edb-95d8-9a1d871597fc	2026-01-07 10:14:12.678815+00	12.9	28.8	4997	2626
06baf5fe-d47f-45e2-8505-2a3182255fb9	2026-01-07 10:35:12.98278+00	4.9	26.4	5275	3652
69d6515b-74e5-4b33-a772-b439f7c0fa21	2026-01-07 10:52:52.096047+00	5.3	28.5	273682	273682
49c62b91-6f11-44c6-8540-09bda297d8c5	2026-01-07 11:09:13.368249+00	16.5	32.7	14169	255282
2631dd8c-f7b0-4d50-b638-a254b64f5934	2026-01-07 11:28:52.040254+00	5.2	30.3	0	0
046b6411-6f29-49fa-92e7-6c80327de049	2026-01-07 12:22:51.917105+00	19.4	31.9	862597	862597
5910fac0-0ee9-44db-a795-b0f0674dc967	2026-01-07 13:38:51.954092+00	29.7	31.1	250341	250341
06fb6aa8-56d3-4aa5-84bb-f7a3b763d2fc	2026-01-07 13:38:53.85241+00	39.8	31.2	4554957	4554957
33dcb1ed-53fe-4007-9b8c-654f412cf8f9	2026-01-07 13:39:36.920024+00	34.7	31	2755856	2755856
22a32317-bd78-49db-8e05-37460683c624	2026-01-07 13:39:53.871515+00	31.5	31	3114146	3114146
0fbc9287-f683-4490-b193-a6284b477237	2026-01-07 13:40:36.866005+00	34	31.1	3070066	3070066
521740fb-1638-4c5a-8e41-072577f62d8b	2026-01-07 13:41:31.536241+00	30.8	31	5934265	5934265
b6916c50-329f-4b10-b650-d13d5caae88c	2026-01-07 13:41:51.912514+00	31.4	31.2	3271732	3271732
3dcc96f4-e365-4e35-9065-a0d6e7cc1e15	2026-01-07 13:41:53.919745+00	31.5	31.2	1132300	1132300
91924d19-e659-4842-8054-a8f9339a14dc	2026-01-07 13:42:31.53179+00	34.5	31.1	1099148	1099148
6ab06efd-9c91-45ea-ba6a-32f3b78d437f	2026-01-07 13:42:51.954696+00	29.7	31	353925	353925
2e621d75-81ae-4fa2-81eb-7f43893fe2a1	2026-01-07 13:43:31.522636+00	32.6	31.3	4101592	4101592
34d6c71c-94c8-4296-8fae-dd66087ca44f	2026-01-07 13:43:52.007038+00	32.6	31.3	5151925	5151925
42e967d8-db54-48ca-966a-6091f09b95a5	2026-01-07 13:44:36.876997+00	28.9	31.1	5079037	5079037
8a5710e8-de4c-4709-b194-2eafed817177	2026-01-07 13:45:31.528983+00	30.6	31.2	3388714	3388714
dfead207-a189-4930-95fe-116522fa83fb	2026-01-07 13:45:51.96939+00	29	31	3038775	3038775
1ccadcb9-db51-4d86-b898-f64f0fc8f3c4	2026-01-07 13:45:53.841871+00	31.9	31	4488077	4488077
2c30f27a-7fe6-44de-b1d5-09754a0c7e78	2026-01-07 13:46:31.527727+00	29.7	31.1	936377	936377
648b6faf-07ec-41fe-a5eb-c44deebf822b	2026-01-07 13:46:36.925543+00	36.4	31	3113271	3113271
44a0e4ca-e022-488e-bacd-7a168addd953	2026-01-07 13:47:36.374313+00	31.7	31.2	1174502	1174502
57015a05-aa31-4761-bec9-568e4b8317ef	2026-01-07 13:47:51.935473+00	27.1	31.1	224027	224027
31419bee-f5ac-43b8-9195-ce2c93ec6566	2026-01-07 13:47:53.865596+00	31.5	31	4085844	4085844
26173e0a-ce13-4b9b-8e9c-b03035072327	2026-01-07 13:48:36.367519+00	31.8	31.1	762109	762109
2aec151d-58e8-4a43-a755-b8e0f1d4680c	2026-01-07 13:48:51.89142+00	31.8	31	5422066	5422066
1687a8bd-8d26-44b8-88bc-cd6510d3f7fa	2026-01-07 13:48:53.840382+00	33.3	31.1	3264200	3264200
c5fada5e-17eb-4d19-b3db-36b6ac4d26b7	2026-01-07 13:49:36.899545+00	31.2	31.1	370219	370219
d56112c8-b2d0-4976-a7e3-b7aa96812d4d	2026-01-07 13:49:53.839023+00	32	31	4190469	4190469
83d9aad8-c9f6-4cbf-8545-26890f3a4196	2026-01-07 13:50:36.855052+00	30	31.3	3856048	3856048
62e45517-c6bd-41bf-880e-9bc4dc9db4fb	2026-01-07 13:50:53.824186+00	31.6	31.2	2342815	2342815
56cf9505-ba54-424d-97f6-1ca7f0921578	2026-01-07 13:51:36.365167+00	30.5	31.1	3372134	3372134
afb82ced-baab-47a2-8129-33733107e920	2026-01-07 13:51:51.923206+00	32.7	31.2	282831	282831
4d890270-c4dd-4d34-a28c-b7ff205fffcd	2026-01-07 13:51:53.865356+00	32.4	31.1	1735377	1735377
626092d5-4700-487c-9125-1c21e48287a0	2026-01-07 13:52:36.910464+00	30.3	31.1	2398532	2398532
ae33a629-c3a9-4501-98b9-608379b554fc	2026-01-07 13:52:53.827041+00	31.9	31.2	816536	816536
6bf2f333-3917-4426-854f-b7f014b31e78	2026-01-07 13:53:36.432134+00	36.6	31.1	3310744	3310744
9a03c988-2588-419a-a990-b1915fe114f4	2026-01-07 13:53:51.912372+00	30.9	31.1	277940	277940
7889dcda-9a62-4cd8-8088-cd7a4106f111	2026-01-07 13:53:53.944404+00	31.3	31	2175859	2175859
ac24272e-f309-44df-83f3-9e0be88eb77e	2026-01-07 13:54:36.388484+00	33.4	31.1	3549000	3549000
9c8aee22-915b-473c-8378-8c5025b417db	2026-01-07 13:54:51.859458+00	32.7	30.2	374542	374542
d99507f7-2a37-4b98-ac3c-85cfedffd50d	2026-01-07 13:54:53.814933+00	36.2	31	624662	624662
bc40cc45-0676-411a-8160-2f516e7fc442	2026-01-07 13:55:36.357239+00	32.7	30	1300236	1300236
646c1a22-0902-49d6-9759-28b073383e7a	2026-01-07 13:55:51.880348+00	33.3	32	202026	202026
db3d91c0-a223-4159-8020-a5305ada6194	2026-01-07 13:55:53.824956+00	35.9	32.2	712329	712329
1e74e1b9-9596-409e-b21d-5ff88f33a158	2026-01-07 13:56:36.84439+00	61.1	31.9	1103426	1103426
c5a884e4-b983-4e4c-b587-9c5d7239c91f	2026-01-07 13:56:51.930864+00	38.8	30.2	1359985	1359985
6b54b305-0833-4463-acde-cd868b83bc84	2026-01-07 13:56:53.812176+00	38.8	30.3	1145133	1145133
d7f6c83e-899a-4977-98ed-11ac30000dc7	2026-01-07 13:57:53.799337+00	39.7	31.3	1485804	1485804
fa61f47b-925f-4d9f-a5f0-138b694021ef	2026-01-07 13:58:36.364136+00	43.5	31.7	1243840	1243840
3461061d-3eaf-450d-9475-9fc20e5bcefa	2026-01-07 13:58:53.856068+00	41.1	31.7	3108811	3108811
38fdd714-ffbc-47c5-bdac-caff0016309b	2026-01-07 13:59:22.806867+00	41.6	31.7	1112091	1112091
2b0ae0ea-4646-4561-ae3c-57e6befd0b31	2026-01-07 13:59:36.356267+00	41.9	31.7	3224736	3224736
ef46e215-630b-4276-acab-d14e674c6e3a	2026-01-07 13:59:36.851216+00	41.9	31.7	582629	582629
a9baeaf5-2345-4550-93dc-1631ac3fc7c4	2026-01-07 13:59:53.851352+00	42.5	31.6	4302886	4302886
e58c390a-9e46-469a-911e-93abe71e83d9	2026-01-07 14:00:36.358142+00	57.6	31.2	1385079	1385079
1301323c-3a40-43b2-859f-577c2d89f079	2026-01-07 14:00:53.824509+00	58.4	30.8	524256	524256
a3d9ceff-713b-4533-9325-7d14edd4b3df	2026-01-07 14:01:22.789399+00	57	31.7	1198270	1198270
a4315e0f-3884-4001-aa69-49a9bc93bc87	2026-01-07 14:01:36.354306+00	57.4	31.7	1031038	1031038
30416030-bc2d-4b7e-9a12-54dbb0873319	2026-01-07 14:02:36.37254+00	57.1	31.6	1042213	1042213
a8626b51-0916-4e78-b50f-8fb15e2e154e	2026-01-07 14:02:53.830769+00	56.9	31.4	363388	363388
7e8535c0-a09f-46cd-9dfe-cc226630c215	2026-01-07 14:03:36.837137+00	57.3	31.4	471710	471710
0a76d03f-faa8-4f68-9934-e60f7770f6fb	2026-01-07 14:03:51.889754+00	58	31.4	109229	109229
c9f7ca17-8504-43e7-b667-fb8069339d7b	2026-01-07 14:04:27.184333+00	63.8	31.9	793123	793123
8b59119c-8169-48b5-8c2a-ae7d82a995c4	2026-01-07 14:04:36.353619+00	64.9	31.4	921035	921035
9b16e91e-ce82-4c7d-98ef-d6e36dcc998c	2026-01-07 14:04:53.840276+00	54.3	31.6	2404861	2404861
aeebaf35-474f-4e62-9b92-4293a36013b3	2026-01-07 14:05:21.426987+00	34.8	31.6	1034846	1034846
9cda7a66-f838-4982-8aa4-ceaab0199e3c	2026-01-07 14:05:36.854338+00	33.9	28.9	911290	911290
4900ae86-b157-4feb-8992-9ec8af2e2e65	2026-01-07 14:05:51.888599+00	32.5	29.8	247121	247121
78959e5f-0c96-4e58-9191-cd9d37440140	2026-01-07 14:05:54.832395+00	34.3	29.8	1019049	1019049
73ac40ed-7500-4567-9075-ace7954d31f2	2026-01-07 14:06:27.163969+00	33.8	30.7	1160708	1160708
ab227b5d-f9a6-41ac-9d31-d86374f28ca2	2026-01-07 14:06:36.841854+00	29.7	30.8	774832	774832
7cec1702-2176-4263-a4b0-677aaf1d7496	2026-01-07 14:07:36.854715+00	32.5	31	1055390	1055390
e4ec3974-1613-4dca-93c5-19a125e165f7	2026-01-07 14:07:53.806218+00	36.5	31.2	569498	569498
c9287fe1-670b-43c9-b23b-c07dee1f6f07	2026-01-07 14:07:54.694977+00	36.5	31.2	1229253	1229253
15347cc5-f087-4724-9e45-fa2504a6d1b0	2026-01-07 06:17:58.398543+00	9.6	22.3	542874	542874
49d2736e-a130-49df-8586-7b1cc14fff10	2026-01-07 06:18:58.327566+00	7.3	22.3	621305	621305
08c09c7b-ab28-409b-8688-48c9008d9d7a	2026-01-07 06:18:59.515442+00	7.6	22.2	398275	398275
35749866-4322-47fa-8cbe-d5971412a77f	2026-01-07 06:19:11.374138+00	33.2	22.2	679337	679337
b0f84153-167d-443c-925d-769872f843d3	2026-01-07 06:19:58.321863+00	9.1	22.3	845385	845385
13fa0273-a2bf-410a-b289-fa1827458213	2026-01-07 06:19:59.473184+00	6.9	22.3	527661	527661
23fc5ffd-ad43-4715-ab2d-bb5e6271f9f5	2026-01-07 06:20:09.738156+00	13.5	22.3	810703	810703
25fbab2b-96f8-44bc-87bc-4f7879f81052	2026-01-07 06:21:09.255414+00	8.5	22.3	906853	906853
d4b79606-94ff-41d0-9398-bd8630de07d6	2026-01-07 06:22:09.313828+00	18.4	22.3	659998	659998
d6d35990-93cb-44b8-90ba-23b3ac987fc3	2026-01-07 06:22:11.695501+00	19.3	22.3	581706	581706
710d1132-8be2-4b8f-b12c-8a3e0a943130	2026-01-07 08:07:03.72834+00	6	22.3	407813	407813
71982a95-0bca-45a7-9f7d-a26c439f3539	2026-01-07 08:10:03.817374+00	7	22.2	408575	408575
cb574dd9-53e6-4228-b503-72ce73d2118b	2026-01-07 08:14:03.729462+00	7.1	22.2	478676	478676
4381f4ea-7b27-4fc4-811c-4617987c0a2a	2026-01-07 08:16:03.75673+00	5.6	22.3	291866	291866
ef2c1a57-3024-4726-8f75-cae36e6e2c2f	2026-01-07 08:21:03.724492+00	7.7	22.2	335722	335722
7819aac7-352a-4125-a22e-5b87ff69f876	2026-01-07 08:44:54.464961+00	10	27.2	7630	66884
c2ebe4a8-50bd-40ae-a2ef-a631a86ee8b8	2026-01-07 09:29:56.963307+00	7	29.2	0	0
0c771615-5c3d-4b2b-9703-1258abe55ea4	2026-01-07 09:54:52.126208+00	4.6	24.6	108320	108320
0cf2fb0e-fc26-4313-a9c5-59995dba2cc4	2026-01-07 10:14:52.108751+00	12.9	26.4	92484	92484
69de1729-0202-468c-bc70-a691499974ea	2026-01-07 10:35:52.069741+00	5.2	26.4	89337	89337
c462d0cb-7fa0-469d-88bc-e74b7ef431d7	2026-01-07 10:52:52.096069+00	5.3	28.5	142297	142297
fd0934ac-bfed-43c4-9572-aab5df92b4c4	2026-01-07 11:09:52.250837+00	28	33.7	117267	117267
dc981e8a-a3ce-45b9-bbb5-4fa15e1b55cd	2026-01-07 11:29:13.661963+00	5.4	30.3	7007	4280
30316fb3-3765-4d38-9865-dbeb9c69ff0f	2026-01-07 12:22:51.929416+00	19.4	31.9	819506	819506
1eb8187c-b714-4a34-b738-2a3985282559	2026-01-07 13:57:36.883895+00	43.6	31.4	2495226	2495226
8f5da4f7-6d47-49df-8498-3326b2512349	2026-01-07 13:57:51.891208+00	42.4	31.2	2100967	2100967
b9c8e2ac-ff19-4837-bee9-da008cfe8dca	2026-01-07 13:58:22.810584+00	39.9	31.7	3259738	3259738
9306cb34-1f02-4e43-ad8d-c086dc670988	2026-01-07 13:58:36.868201+00	43	31.8	6014382	6014382
1070f488-0770-4cae-850e-3d0c6d544dfc	2026-01-07 13:58:51.925839+00	42	31.7	207359	207359
aff69d15-4c2a-48cf-b961-537f72abf5fa	2026-01-07 13:59:51.905077+00	38.3	31.6	295863	295863
7dc9415e-8d2e-484a-bf12-3203ef2e6a3b	2026-01-07 14:00:22.785719+00	50.5	30.9	971452	971452
759dc54a-2c50-4a48-81fd-6394a9fa4471	2026-01-07 14:00:36.839973+00	57.6	31.2	957927	957927
21d0f241-4e10-40e2-b170-c64d5697d9b8	2026-01-07 14:00:51.87358+00	57.8	30.8	334053	334053
ed0ef838-326c-499b-981a-5ae831bd0e18	2026-01-07 14:01:36.841475+00	57.4	31.6	943200	943200
89821e3d-b409-43e0-898a-fd5345fd1676	2026-01-07 14:01:51.890086+00	57.6	31.6	203306	203306
835c057c-c12a-48bf-ae04-9ea0dac3d1e4	2026-01-07 14:01:53.832054+00	58	31.8	416659	416659
e3c54e66-f864-419a-960b-d984a6292d0b	2026-01-07 14:02:19.529822+00	57.4	31.6	873016	873016
da7b809f-bbdb-4b46-9b8e-613611cb4fde	2026-01-07 14:02:27.216697+00	58.3	31.5	1020509	1020509
5a9cbe34-49b6-41a6-822c-0b9a2e07743c	2026-01-07 14:02:36.846127+00	57.1	31.6	1121233	1121233
969ef5f6-11ac-4aba-9588-2abe8c482cca	2026-01-07 14:02:51.874347+00	57.7	31.5	296695	296695
0e2a86b8-1ea8-42e2-af13-a9780eb5fb10	2026-01-07 14:03:27.176331+00	57.5	31.3	926250	926250
fe8e028e-fa67-4e73-9e41-27dcf082aa94	2026-01-07 14:03:36.359608+00	57.3	31.4	1203955	1203955
1e745643-fa19-43ea-bec3-75dd1d9167eb	2026-01-07 14:03:53.826801+00	57.8	31.4	298028	298028
5aed338c-2cd8-4a1d-ae24-62ef12507756	2026-01-07 14:04:36.849886+00	64.9	31.4	647849	647849
9da82639-aa78-493b-b1d7-2c6ab817369b	2026-01-07 14:04:51.896477+00	77.4	31.9	11048879	11048879
a8031624-5c95-4309-ad47-1a68c3d0f95f	2026-01-07 14:05:27.181261+00	29.5	31	1055986	1055986
f507725b-0ab6-4441-beb2-b2c4e83557a9	2026-01-07 14:05:36.352967+00	31.7	29	1156570	1156570
4603a3fa-2ceb-4f0c-924e-a9e478889c0b	2026-01-07 14:05:53.826886+00	34.3	29.8	572788	572788
d51cbe5b-b7c1-4012-8682-f34b5daec684	2026-01-07 14:06:36.354742+00	29.7	30.8	827147	827147
2c24f556-eb47-4b6a-a483-ec2be75caad5	2026-01-07 14:06:51.909912+00	28.3	31	258271	258271
97130fa2-ab8e-4d36-93d7-83cd44356979	2026-01-07 14:06:53.823777+00	33.4	31.1	945589	945589
92b52f2a-63c5-4f16-b33e-ea2a2fda5887	2026-01-07 14:06:54.703125+00	32.7	31	1500368	1500368
6b39428f-ab7d-4681-88e0-57ff37069f72	2026-01-07 14:07:27.169798+00	35.8	31	994718	994718
fc43ca8d-6235-43bb-abd7-22426ef8255b	2026-01-07 14:07:36.351895+00	32.5	31	1496366	1496366
7697c14f-a2f2-4112-80ce-6b98962254b7	2026-01-07 14:07:51.878984+00	28.2	31	393208	393208
c5a27808-f1a4-48ed-bf2e-19b0d9710d86	2026-01-07 14:08:27.175928+00	32.6	31	1534665	1534665
ba56b317-e1bd-4981-8f27-177a7d7bf369	2026-01-07 14:08:36.358858+00	32.5	31	1347288	1347288
329e823e-e119-4206-99ac-2c8e1e704c74	2026-01-07 06:17:59.59666+00	6.7	22.3	149881	149881
64436225-9820-41fb-953a-aef78908d20f	2026-01-07 06:18:09.999243+00	9.4	22.3	925557	925557
de639667-75ec-47df-ad71-059ba042b981	2026-01-07 06:18:32.254695+00	12.4	22.3	620846	620846
b4d11f87-6170-4630-bf87-b64b94094ca3	2026-01-07 06:19:09.115191+00	16.5	22.3	737935	737935
83e9c94f-714d-4f23-9ce2-e724a4b98fc6	2026-01-07 06:19:58.251217+00	9.1	22.3	213348	213348
60bb0a91-3043-4451-b638-26c717de1d07	2026-01-07 06:20:58.432327+00	10.6	22.3	1782007	1782007
cff97a33-9533-4701-9920-2ed1318fb756	2026-01-07 06:20:59.508371+00	9.6	22.3	243688	243688
a373aa85-e706-48cc-b480-058bbf0192ed	2026-01-07 06:21:58.442936+00	10.3	22.4	330068	330068
3ef3cfc1-dca6-4262-8851-0e93f89e5c42	2026-01-07 06:21:59.833469+00	8.5	22.3	453810	453810
f2813936-bd83-41d9-a088-d6eb1c9bc88e	2026-01-07 06:22:59.521359+00	8.4	22.3	562604	562604
c1fac2e8-d600-4e6a-84ba-496ae951112c	2026-01-07 08:07:54.133741+00	7.4	22.3	15364	8228
f939abd4-aa9c-47e3-a6ae-dd348cec3766	2026-01-07 08:45:31.2029+00	6.2	27.2	420771	420771
12b118ed-7e18-4813-b97a-2c63a39e86c0	2026-01-07 08:48:31.190382+00	5.6	28.7	249815	249815
19e197f7-5b7a-4ad1-81fe-d811074ce102	2026-01-07 08:51:53.318971+00	9.1	28.5	182434	182434
46da3a29-c110-41a6-abfa-bf9a738db277	2026-01-07 08:52:53.357293+00	63.3	29.6	159991	159991
ee3b6fcb-9a88-411a-beca-3085dcbb1415	2026-01-07 08:55:53.304113+00	26.4	30.8	352576	352576
f0c973b5-6bd5-4416-a06d-55c7a6c9995e	2026-01-07 09:30:56.963025+00	8.7	29.2	6765	6446
81c80f6a-aa41-4d97-b306-087f6e1d023d	2026-01-07 09:55:12.42191+00	5.1	24.6	3074	2007
f290f64f-e67b-4b94-b7d0-2902737ed258	2026-01-07 10:15:12.746648+00	9.6	26.1	4334	2718
036c87c4-b76b-4f2d-aadf-75d12ece274d	2026-01-07 10:35:52.072229+00	5.2	26.4	0	0
a3d7673e-28a1-4f04-b4ad-5e537dd8595a	2026-01-07 10:53:13.261829+00	5.5	28.5	6504	4468
66563572-a801-4a09-887c-536a459ec6f2	2026-01-07 11:09:52.251218+00	28	33.7	119205	119205
03fcc452-55f6-4395-94c6-b53fa90df04a	2026-01-07 11:29:52.149584+00	5.2	30	0	0
25066add-8172-4376-8c0c-9a0be29b3d9f	2026-01-07 12:23:51.950739+00	74.5	33.6	671570	671570
25368cd2-26fc-4385-9da4-db9675bed8c4	2026-01-07 14:08:36.869586+00	32.5	31	719788	719788
444fa16e-0ea5-4088-98c4-0f365d176326	2026-01-07 14:08:53.825374+00	32.5	31.2	575461	575461
69342958-27be-420a-a8b3-a13568ad027b	2026-01-07 14:09:27.178079+00	36.2	31.2	945241	945241
0efe45a0-7be9-4c27-acb1-cb41a213f860	2026-01-07 14:09:36.358399+00	32.3	31.3	1073271	1073271
2090cbb4-d8c1-4402-8b6d-eed243886d4d	2026-01-07 14:09:52.010699+00	32.2	31.4	188492	188492
0491abd1-a3c6-4d0d-be7d-5562d3d3554a	2026-01-07 14:10:36.85372+00	32.1	31.6	1031189	1031189
4aa32116-558c-484b-a414-ce9b203d1322	2026-01-07 14:10:53.834202+00	36.6	31.4	389268	389268
e1b2a06b-264f-4ab5-81b5-f306affacc7c	2026-01-07 14:11:27.166607+00	31.6	31.2	1349001	1349001
2c6f52a3-2e8e-4d2c-b79d-f1c09197d523	2026-01-07 14:11:51.879207+00	31.3	31.5	293995	293995
4a3ca34e-e90d-4113-8a23-d3d5852b288e	2026-01-07 14:12:36.348379+00	31.7	31.3	1243382	1243382
c863d1f9-99af-49a0-b1d7-cfe928f503f6	2026-01-07 14:12:51.883485+00	31.8	31.3	228567	228567
47960012-a989-41a6-a73b-6246acfb55bd	2026-01-07 14:12:53.833352+00	32.8	31.3	777305	777305
f06486c0-365e-4abe-9bd0-62531798c741	2026-01-07 14:13:36.848007+00	33.1	31.2	1330742	1330742
884c9ffe-10af-464f-b215-d65a3089bac3	2026-01-07 14:13:54.690406+00	33.9	31.2	627425	627425
ee691c4e-95ec-4153-b577-6a451ca08eb5	2026-01-07 14:14:27.17473+00	30.6	31.1	1273683	1273683
116662ce-15dd-425c-953a-63b27e554867	2026-01-07 14:14:36.354317+00	32.3	31.2	1349452	1349452
010abf4f-c421-419a-8ab4-86eeb9c6dfa8	2026-01-07 14:14:51.878112+00	32.3	31.3	385984	385984
411ff0e2-f74c-4dd2-a7c8-59d8eb5c9657	2026-01-07 14:15:27.16345+00	33.4	31.2	1618827	1618827
720424d3-ae66-4120-8bae-50728ba83e61	2026-01-07 14:15:36.359413+00	30.4	31.3	794932	794932
03bcfdbd-4a2d-41db-ad91-cf8070c397ce	2026-01-07 14:15:51.868303+00	33.2	31	406554	406554
20e1e914-f56d-4bb9-90b5-ffe0c95a5a36	2026-01-07 14:16:27.176971+00	34.4	29	1094678	1094678
01159ea3-f9d1-48c5-a112-5860636dd153	2026-01-07 14:16:36.352598+00	32.2	30.1	1142470	1142470
58b60114-4f48-4fe1-bfca-5172558e7e70	2026-01-07 14:16:39.357565+00	36	30	1252270	1252270
79e7fef6-0818-4e8c-9d49-e733ea377c50	2026-01-07 14:16:51.874247+00	33.2	30.1	259458	259458
2577ec90-4e79-4416-b056-30294747a435	2026-01-07 14:16:53.80845+00	31.3	30.1	548242	548242
466ed2fa-0f48-439a-a89f-635e1d64d298	2026-01-07 14:17:27.171022+00	32.2	31.5	1409543	1409543
cd8c8e57-bb41-491e-b659-bf8d5a0614fe	2026-01-07 14:17:36.359531+00	30.8	31.2	1458028	1458028
4d028ea9-1f8d-45a0-95ac-89a8b6b0b6aa	2026-01-07 14:17:53.817689+00	36.3	31.3	431947	431947
e1224533-f25e-4c5a-b7d6-38d3d5edc0c2	2026-01-07 14:18:36.855213+00	74	32.9	801870	801870
fe11d241-eaed-456a-8d15-bc50c1ef3fcd	2026-01-07 14:18:39.31698+00	52.7	34.2	886750	886750
feb21387-db77-4559-94b1-cc83a33de233	2026-01-07 14:18:51.876779+00	58.7	31	342461	342461
9fde6213-a885-4742-9b83-407df60bd6db	2026-01-07 14:18:55.736901+00	36.4	30.1	802493	802493
7c411e0a-6be4-4a84-ad21-b47172c7809a	2026-01-07 14:19:36.855332+00	31.6	31	846101	846101
8eb5e4c2-79f7-46af-bfbb-268163e1dfca	2026-01-07 14:19:39.306719+00	38.6	30.9	1584612	1584612
7ff1ab8e-0855-4640-a7f7-ac81fbeaa2ae	2026-01-07 14:19:51.868231+00	32.3	31	511509	511509
9775f60f-a35b-48e1-b8a9-f61ba91ec7cb	2026-01-07 14:19:53.790766+00	32.9	30.9	578418	578418
2aeb864e-5fa4-4207-b303-d6eeb8236a98	2026-01-07 14:20:27.165055+00	31.5	31	1117125	1117125
9ca18a63-7cc7-45b3-a191-558c42cac4b8	2026-01-07 14:20:36.850438+00	34.2	30.9	1237880	1237880
cbb7af49-238f-4cb8-9ead-87417e03568f	2026-01-07 14:20:39.302398+00	33	31.1	803081	803081
6b5c151f-34e9-4bc3-9d78-e71d539c6c2e	2026-01-07 14:20:51.885143+00	32.6	31	356249	356249
2c000d02-1007-4d6c-9dbe-539c498c8473	2026-01-07 14:21:36.844416+00	32.4	31.1	940402	940402
5cb5e924-bf39-4805-8311-4a96bff6caf6	2026-01-07 14:21:51.879177+00	32.2	31.2	374850	374850
bff8b22a-8f39-44cb-be3c-4bd48a59a6e4	2026-01-07 14:22:36.900565+00	20.3	31	334249	334249
123e0dde-3110-4243-927f-b575a404805a	2026-01-07 14:22:39.336528+00	17.8	30.9	761004	761004
3468923f-1a24-43ed-8ec8-04a2cd84abb1	2026-01-07 14:22:51.876141+00	31.2	31.2	392809	392809
5fefcd41-c35a-426c-8e08-b01926d0da9e	2026-01-07 14:23:36.884735+00	15.4	31.3	437593	437593
03143de8-d2ec-4b80-8cd0-e664b90969ac	2026-01-07 14:23:39.345963+00	18.3	31.3	882328	882328
89e8efd1-ef28-489a-9a2a-04c599a363f8	2026-01-07 14:23:51.908824+00	16.2	31.4	262742	262742
f81566cf-24b5-4a34-ae3b-9e56646a17f1	2026-01-07 14:24:15.583954+00	26.4	30.9	829975	829975
daefbc5f-689e-4d73-82fc-75fcca01c0de	2026-01-07 14:24:39.426823+00	36.1	32.4	2988767	2988767
7a4fada2-7bde-45ca-9c89-40204dcd7dab	2026-01-07 14:24:51.942292+00	35.9	31	120173	120173
64b79315-f9ef-454b-9190-5c50e58d8fb4	2026-01-07 14:27:15.433265+00	9.8	29.9	777661	777661
ba58a22c-b024-4260-a31d-613b49377011	2026-01-07 14:27:39.357132+00	9.3	29.8	507673	507673
04ebc4dd-1b16-404f-a8c6-b722054190cb	2026-01-07 14:27:51.940389+00	8.4	29.9	143137	143137
6996c792-52f5-4ed8-831c-31adbf172f08	2026-01-07 14:28:11.419261+00	26	29.9	1013553	1013553
a62bfaa7-a7a0-4475-8a84-014822a6a317	2026-01-07 14:29:15.464726+00	12.9	31.4	810917	810917
529150d3-28cc-4f3a-afeb-5cc8a2f448b5	2026-01-07 14:29:39.383737+00	9.3	31.1	420128	420128
9be44082-d040-434f-9b3c-acbd1a79b73c	2026-01-07 14:29:51.908014+00	12.4	31.1	221914	221914
3f54a491-82fa-491e-a82f-6aad6259a644	2026-01-07 14:31:15.467959+00	11.6	28.4	286034	286034
5b4898df-cb26-4b56-be0f-1f0ea540bd7f	2026-01-07 14:31:39.323032+00	9	25.5	830658	830658
c70dc9d8-fb88-4c1f-bd1a-3d1cf12c6d78	2026-01-07 14:31:51.88561+00	9	25.6	332591	332591
c3aaf296-f8e9-4b02-a047-0f0deff51e59	2026-01-07 14:33:15.42186+00	10.1	24.4	546852	546852
630bda63-3d31-4218-a723-92865da15fb7	2026-01-07 14:33:39.377375+00	12.4	25.1	1003646	1003646
8d5d1721-a5ac-4d5f-ad65-7ac2c79f70cf	2026-01-07 14:33:51.988741+00	27.4	27.7	276031	276031
052207bb-b562-43e4-96e1-2f2784da827a	2026-01-07 14:35:15.489799+00	24	28.8	1252104	1252104
41a2e06b-3e8d-4341-a352-77f2fef11202	2026-01-07 14:35:39.382744+00	26.2	29.9	422331	422331
c89af9dd-c52b-4293-91b3-60ea448d416a	2026-01-07 14:35:51.878395+00	9.6	30	366768	366768
a21f1e09-64e0-4c03-9373-085c7d9959f0	2026-01-07 14:36:51.963197+00	27.4	30.4	1733024	1733024
864f2fb8-115e-4576-8d0d-7696e3a0c8c6	2026-01-07 14:37:15.430749+00	36.9	30.5	7027150	7027150
27a2f2b2-66e3-45a2-9fb6-1bcb8e4e9aa0	2026-01-07 14:37:51.953479+00	32.9	30.5	358023	358023
3e5d6fa4-e696-4ae1-a4b0-c06dca83cac6	2026-01-07 06:17:59.600309+00	6.7	22.3	474914	474914
8491e60b-5db5-48ee-b5e0-b3a226accb9e	2026-01-07 06:18:11.468628+00	18.3	22.2	674952	674952
de32e774-712c-421c-95a1-887b931ec459	2026-01-07 06:18:58.389939+00	7.3	22.3	361004	361004
5a671ca7-77ea-473a-80a1-2caced33255a	2026-01-07 06:18:59.517081+00	7.6	22.2	712303	712303
6d416657-0ea4-4402-aa5e-777f0e96c19c	2026-01-07 06:19:09.93976+00	16.5	22.3	1110846	1110846
52caa944-279f-4b36-a5a5-46c23435e41a	2026-01-07 06:19:32.231399+00	9.6	22.3	715815	715815
11408f52-4d24-4a4d-878a-cf6ec0729cb8	2026-01-07 06:20:08.964239+00	13.5	22.3	419007	419007
61025ea2-770d-499f-9f3c-03c766f481cb	2026-01-07 06:21:09.249348+00	8.5	22.3	228742	228742
24771806-3c57-4124-902c-3ebbd502afc4	2026-01-07 06:21:59.698802+00	8.5	22.3	686960	686960
b8c9de57-d671-46f1-994d-2b659fd9b119	2026-01-07 06:22:58.295783+00	8.9	22.4	580591	580591
6efbae8f-cf71-4293-8313-abfaa8660ab3	2026-01-07 08:08:54.136303+00	7.6	22.2	15095	7439
4b5c45ba-041e-40b7-8857-88f6c54391c2	2026-01-07 08:45:54.506608+00	6.6	27.2	1552	908
5a134c83-3dc2-4f66-a71a-2a7f6948787b	2026-01-07 09:31:57.035852+00	12.8	29.2	14039	253550
a30129dc-20f6-48be-91e1-cb4b42fda360	2026-01-07 09:55:52.109785+00	5.1	24.6	128399	128399
d35f54d2-fea5-4645-be56-26710fa3fddc	2026-01-07 10:15:40.476617+00	5.6	26.1	682865	682865
2b22441e-a7b9-47d3-ad72-ce5a4e0faa84	2026-01-07 10:15:42.863721+00	11.6	26.2	553729	553729
76261d1a-74b0-4cd0-b830-0bf33461ea99	2026-01-07 10:36:12.998592+00	4.8	26.4	5049	3513
0e0f1306-049e-4104-8514-c5ef275e6a90	2026-01-07 10:53:52.10501+00	9	28.5	-370627	-370627
0ef72111-0ddf-42e4-bc1f-b3a9debebc9b	2026-01-07 11:10:13.388343+00	28.4	33.8	6378	4264
c9b097f3-7264-4e92-8ac9-e6923f6ad6c9	2026-01-07 11:29:52.152387+00	5.2	30	124743	124743
ac5af0d4-4887-47e4-81fb-f548ed581459	2026-01-07 12:23:51.954285+00	74.5	33.6	306085	306085
088fb668-bc7a-4a8a-82d6-d9852cbee405	2026-01-07 14:08:51.877029+00	32	31	318985	318985
3b54efe2-082a-4e80-9b52-c16fdea67251	2026-01-07 14:08:54.694635+00	32.5	31.2	1266379	1266379
0f2a3444-1a98-4143-abb4-3d8dc7dfed77	2026-01-07 14:09:36.838244+00	32.3	31.3	1018922	1018922
740eabf6-52af-47a3-ad1e-9ff4c3338997	2026-01-07 14:09:53.816943+00	32.4	31.3	878154	878154
b3ede89a-3dae-4c63-b3f8-f270cea7dba8	2026-01-07 14:09:54.699561+00	32.4	31.3	1064931	1064931
fb720396-b452-4463-b1fc-0b9fccdcc73d	2026-01-07 14:10:27.1703+00	33.9	31.6	1073864	1073864
bc8b8ef1-7526-45a4-bf6b-23ee2ee56ec5	2026-01-07 14:10:36.368421+00	32.1	31.6	861381	861381
97948e5e-ade9-4012-894b-2ab0844aa2f5	2026-01-07 14:10:51.871876+00	32.2	31.4	308807	308807
a1d81116-dcaf-406e-9bc7-9073138f9863	2026-01-07 14:10:54.696782+00	36.6	31.4	4778255	4778255
9a296b77-0019-413a-864f-a0864be840f0	2026-01-07 14:11:36.367832+00	32.5	31.5	1001784	1001784
0339e580-5c29-4380-9272-5cebb0d3c7f4	2026-01-07 14:11:36.840906+00	32.5	31.5	756251	756251
1864f375-0ed9-4715-a263-95e61554ded4	2026-01-07 14:11:53.812389+00	32.5	31.4	462307	462307
d74fc7a0-947c-4391-bb4d-9d3a0c6f4d74	2026-01-07 14:11:54.698904+00	32.5	31.4	1624312	1624312
f6a03bfe-bbd2-46fa-b1de-e24cce78940c	2026-01-07 14:12:27.198152+00	32.2	31.4	823916	823916
f668fbba-dc95-4108-80cd-a22c33dcb374	2026-01-07 14:12:36.846628+00	32.7	31.3	1117454	1117454
a0a26f1a-0b79-47d5-9132-b8c638d0c689	2026-01-07 14:12:54.69826+00	32.6	31.3	1226520	1226520
b758d110-22ef-4df6-b537-8b0cd08e3514	2026-01-07 14:13:27.175927+00	32.1	31	1192283	1192283
078308a7-ab2b-48a8-850d-d2aa0678bebf	2026-01-07 14:13:36.361023+00	33.1	31.2	1258464	1258464
4297e1a7-0bf3-427d-9df5-a9d44b98d75a	2026-01-07 14:13:51.904112+00	32.3	31.3	271289	271289
d7274b64-0261-4e90-8566-fcf55d726588	2026-01-07 14:13:53.824074+00	32.3	31.2	650353	650353
37892c5b-20c3-456b-95c9-ccdf2e713ee7	2026-01-07 14:14:36.843948+00	32.3	31.2	1279124	1279124
0593b4d5-1d2f-4d9e-b7f0-94b4a01f0b05	2026-01-07 14:14:53.803893+00	32.9	31.2	651584	651584
b27966f9-b90f-4f16-abf1-3de396b92fe6	2026-01-07 14:14:54.68918+00	32.9	31.2	1502195	1502195
41c2135e-f505-4bbe-af73-55b55e9e3171	2026-01-07 14:15:36.845174+00	30.4	31.3	1103696	1103696
ce1d7256-b665-480c-aad1-57017cc8bde9	2026-01-07 14:15:53.820839+00	34.7	31	603266	603266
b59b9752-6a9d-45cb-acc4-bdfa57545fd0	2026-01-07 14:15:54.707309+00	34.7	31	1091631	1091631
65936351-f57b-4e7f-bf4a-16665b0a12a2	2026-01-07 14:16:36.845329+00	32.2	30.1	501539	501539
e3d400b1-1a25-4ba0-b73a-fdd951daaa38	2026-01-07 14:17:36.838625+00	30.8	31.2	1309846	1309846
295562fd-36cf-45b8-82dc-d2019298bc66	2026-01-07 14:17:39.304773+00	32.3	31.2	1588399	1588399
114d8340-6593-40b6-ab73-f68c430648ca	2026-01-07 14:17:51.883996+00	35.9	31.1	290259	290259
49e60340-8b26-4613-9671-783d020f4211	2026-01-07 14:18:27.179277+00	37.5	31.9	1269484	1269484
3f9837a0-4edf-4c3b-8d07-232139c98fbd	2026-01-07 14:18:36.374222+00	74	32.9	918542	918542
ed4535f7-0710-4a17-ad7a-6733f0d4236d	2026-01-07 14:18:53.828607+00	45.5	30.4	641788	641788
e71efb78-d729-430a-b3f1-bb34f8677314	2026-01-07 14:19:27.169931+00	32.3	30.6	1288087	1288087
560e0f47-4399-4ad7-8e13-a5f379a3062a	2026-01-07 14:19:36.355274+00	31.6	30.8	1210162	1210162
3efa7a25-2ade-4dcc-b95a-8a560e858f9f	2026-01-07 14:20:36.364063+00	32.3	31	1245555	1245555
dcb33830-0b9f-4fd1-ba19-f117495743b1	2026-01-07 14:20:53.821687+00	32.7	31	543542	543542
ee7154ab-5b9a-4475-8c30-e73dab743097	2026-01-07 14:21:27.173822+00	32.4	31	1040253	1040253
d5c6e510-6d8f-4693-91b7-0d5f7cfec497	2026-01-07 14:21:36.359691+00	32.4	31.1	1738702	1738702
87a33dba-cf5e-4dd7-8ea6-ed985ebd4f09	2026-01-07 14:21:39.297396+00	33	31	730727	730727
eac615d7-74dc-4b46-8348-51b44585f8ee	2026-01-07 14:21:53.820291+00	33	31.1	797079	797079
92523c8a-0d77-4d32-9c0a-3ea206a48cf1	2026-01-07 14:22:27.161791+00	31.7	31	1618226	1618226
5414c597-1381-479c-a60a-91c268471266	2026-01-07 14:22:36.397267+00	20.3	31	861074	861074
00e0006c-3677-4b9e-91e6-6552f4de864e	2026-01-07 14:22:53.874339+00	28.7	31.3	452162	452162
e6e1388c-e777-4f1e-a684-4e1f4cbb8730	2026-01-07 14:23:27.248538+00	15.5	31.2	346581	346581
4b573a6b-0012-4ee6-951f-fffe7730fb62	2026-01-07 14:23:36.397034+00	15.4	31.3	716107	716107
bde09b32-dc2c-4c1a-ad6c-73fda091476f	2026-01-07 14:25:15.442986+00	39.2	30.9	699100	699100
66a084b5-2181-4340-bf42-8c6d16517313	2026-01-07 14:25:39.430282+00	36.2	30.9	276695	276695
113a104d-138f-4321-b415-c1adf418616e	2026-01-07 14:25:51.923797+00	37.7	31	239584	239584
2dd09adc-4d81-41ee-974c-2e3ba25e4935	2026-01-07 14:26:15.429356+00	26.1	29.9	691732	691732
3e3a8d39-ba8f-4305-ac67-fbf39b1f3379	2026-01-07 14:26:39.326564+00	10.8	29.9	842825	842825
e56d9fb7-170b-4003-a656-051a65d8a37b	2026-01-07 14:26:51.90075+00	9.3	29.9	178623	178623
a18f2a68-26c2-4636-af27-9f1512349f48	2026-01-07 14:28:15.422312+00	25.8	29.8	1480315	1480315
afa63c98-9a91-40c0-a22f-1d97c985118c	2026-01-07 14:28:39.389034+00	16.6	29.9	608579	608579
13b02e29-f3c5-4e74-97b3-ab3b22fb0781	2026-01-07 14:28:51.905101+00	11.1	29.9	209905	209905
2657f67b-ebde-4f77-a168-f9cd6df278c4	2026-01-07 14:30:15.420482+00	9.6	31.3	714556	714556
0cd05fdb-9b78-4c3f-a8c9-f1bc15144277	2026-01-07 14:30:39.356856+00	8.5	31.2	356716	356716
aac88d9a-90a8-4044-a63f-068279a5f24f	2026-01-07 14:30:51.904655+00	9.7	31.1	300357	300357
524c2fd0-afec-4aad-88ec-68c965de611c	2026-01-07 14:32:15.429972+00	8.8	25.6	465220	465220
b354aea0-f83e-4a38-9697-2f4c5c3f7793	2026-01-07 14:32:39.36116+00	8.3	25.6	377033	377033
abd31675-9c97-4b07-b58e-5f2ef077fd09	2026-01-07 14:32:51.901568+00	9.3	25.6	250823	250823
b7d9adef-14c1-45ab-bb1b-879c4d4a3872	2026-01-07 14:34:15.441348+00	7.3	28.3	915302	915302
8e7d0a83-2476-468a-bc63-58c99e5588ea	2026-01-07 14:34:39.388717+00	13.3	28.8	300017	300017
86aa8499-e119-4009-9fdd-2f1fb42c2eea	2026-01-07 14:34:51.885317+00	10.4	28.8	396910	396910
40068e22-f73a-46d8-80f6-960b2f920df9	2026-01-07 14:36:15.440231+00	27	29.9	1440449	1440449
8464e87c-e8c5-46c4-a4aa-6231698894e6	2026-01-07 14:36:39.421263+00	28.5	30.4	1203039	1203039
1c66dc8e-b75e-4faf-b144-6a44f31896b0	2026-01-07 14:36:48.940889+00	26.7	30.4	1008438	1008438
7b8c0cb8-d0f0-477a-a676-c73876175a62	2026-01-07 14:37:39.345784+00	31.1	30.4	1470841	1470841
a539d506-f28d-4ac2-8294-84817ad9c627	2026-01-07 14:38:15.445229+00	34.7	30.6	4367643	4367643
7a0137a8-8817-4500-b651-8f8bb8a551de	2026-01-07 06:17:59.714819+00	6.7	22.3	600568	600568
e8dc6a77-57e5-440f-a3d9-ba8310cfd455	2026-01-07 06:18:09.145593+00	9.4	22.3	802960	802960
8809e184-fb25-40a5-8d63-95cacfbaecdc	2026-01-07 06:18:53.115778+00	13.2	22.2	67366	11454
7cfd3a7d-7df8-4caf-93ca-e481758e10e4	2026-01-07 06:18:59.60754+00	7.6	22.2	643461	643461
6770038a-5ac5-411f-865d-a10eee7ea7a6	2026-01-07 06:19:53.114033+00	12.2	22.3	77415	13113
3c5016d8-9a46-4281-807b-08c697c86edc	2026-01-07 06:20:08.962581+00	13.5	22.3	612365	612365
5df2fe31-d765-4c73-b79d-bb9b58771be5	2026-01-07 06:20:32.239322+00	18.8	22.2	859274	859274
749d168a-78d7-4b4f-aeb1-70e4aaa478bd	2026-01-07 06:20:53.156023+00	13	22.3	73475	10921
e7be0293-b2e7-473a-afcd-e2bdca6dcb4b	2026-01-07 06:20:59.632073+00	9.6	22.3	589839	589839
ee327ece-9c0d-477c-8720-3e3525d160e5	2026-01-07 06:21:32.192199+00	9.6	22.4	861637	861637
e6502dfa-d0b4-4e88-aa07-ae59b397c4be	2026-01-07 06:21:53.141693+00	13.1	22.3	45974	9970
94c7bf75-9432-442f-bee5-7b3386a1f8c0	2026-01-07 06:21:59.697113+00	8.5	22.3	468716	468716
6df794e8-2d4b-4f37-b33c-c236385d32b0	2026-01-07 06:22:10.190488+00	18.4	22.3	1962787	1962787
da9da527-dd8a-4269-8222-a6efe1209b4f	2026-01-07 06:22:32.284352+00	8.6	22.3	636085	636085
216c73c1-c7c5-4a94-8b8c-d4c83ab9ef51	2026-01-07 06:22:53.180586+00	11.8	22.3	61316	9694
734e8b3c-91b2-4a70-818d-fdaacce2f664	2026-01-07 06:22:59.522465+00	8.4	22.3	284096	284096
3b742b58-fe73-4f73-83a1-5a37f084e7ab	2026-01-07 06:23:09.163809+00	8.5	22.3	571343	571343
2ee8d3ef-aa2b-4e0c-b816-f0d0a077ba58	2026-01-07 06:23:09.163809+00	8.5	22.3	608572	608572
9c51b8af-9fbd-43bb-b643-8f252673f367	2026-01-07 06:23:09.958798+00	8.5	22.3	848116	848116
8a0043d3-a66e-40dc-aeef-759deb8a124a	2026-01-07 06:23:11.458302+00	33.1	22.3	733080	733080
7237eafc-ca28-4652-9911-9b054e5794c3	2026-01-07 06:23:32.306275+00	10.1	22.3	879610	879610
c89f737c-4e56-4295-85b5-1869b553a3ec	2026-01-07 06:23:53.189221+00	13.2	22.3	64940	10846
1f804bac-6e2d-4c52-9e11-1da89cc7bb5f	2026-01-07 06:23:58.727997+00	9.8	22.3	245455	245455
751fcbb8-ec94-4c29-b6cb-450c5e86495a	2026-01-07 06:23:58.855143+00	9.8	22.3	440247	440247
16547c74-a4ca-412e-94f6-b38a515d2e87	2026-01-07 06:23:59.806946+00	7.5	22.3	345520	345520
e75af733-8767-45ff-8964-485d20759420	2026-01-07 06:23:59.856833+00	7.5	22.3	276268	276268
f4db3f39-0f11-4912-8734-eb386cce1d79	2026-01-07 06:23:59.95648+00	7.5	22.3	466113	466113
cdf94fee-6382-41ab-91ab-f7cb40ccdb15	2026-01-07 06:24:09.408759+00	7.7	22.4	602632	602632
3b68c30d-a6b6-4609-87a7-487a272704f0	2026-01-07 06:24:09.438287+00	7.7	22.4	859207	859207
4bad983a-d19a-46ac-9572-ec4b4034433b	2026-01-07 06:24:10.310048+00	7.7	22.4	1125020	1125020
cf0bf516-fc04-4a66-9c3c-d22466c367f6	2026-01-07 06:24:11.80527+00	18.4	22.3	600230	600230
17779b6b-51c7-4135-bf24-1b5e80773ada	2026-01-07 06:24:32.36718+00	8.5	22.3	1087394	1087394
6bb779e2-e96a-478e-b28f-f80be21416a5	2026-01-07 06:24:53.15546+00	20.3	22.3	74776	12248
3fb2b914-4d50-426b-9513-b2f0f57fed29	2026-01-07 06:24:58.326397+00	9.8	22.3	642087	642087
2d10b9d3-d2a0-4f22-a2ee-6504948667e9	2026-01-07 06:24:58.442519+00	9.8	22.3	567488	567488
a1bbf367-7711-4676-a280-855612ae7763	2026-01-07 06:24:59.82404+00	7.4	22.3	1355674	1355674
3b845f01-7a5a-41bd-b70a-98ae607b7bdb	2026-01-07 06:24:59.824349+00	7.4	22.3	384133	384133
8175317e-278d-4a15-b8f6-b54c1b0d7938	2026-01-07 06:24:59.907661+00	7.4	22.3	455545	455545
3c36a610-7777-42e0-925f-327dda1da76a	2026-01-07 06:25:09.486522+00	23.3	22.3	940838	940838
cc6abbff-e137-4977-836f-ed83a878f5aa	2026-01-07 06:25:09.487949+00	23.3	22.3	1124911	1124911
4dd6085c-c012-4c3e-8045-b17da99b0102	2026-01-07 06:25:10.359825+00	23.3	22.3	1038863	1038863
1288e066-2237-4d66-966f-c3f6853c0031	2026-01-07 06:25:11.811224+00	32.4	22.3	516528	516528
aaef4061-da1b-4ba0-923e-d0a6560b9275	2026-01-07 06:25:32.232329+00	24.1	22.3	457880	457880
2c923bd9-d83c-40ba-a585-4dcbed044ec3	2026-01-07 06:25:53.193886+00	18.8	22.3	55553	11466
e23c18ba-42ff-4588-b866-4cda29367b91	2026-01-07 06:25:58.455948+00	11.1	22.3	319444	319444
3472c3b0-f8f9-411f-b1d6-afe015ad893f	2026-01-07 06:25:58.484674+00	11.1	22.3	190139	190139
f0f07c89-faad-45f5-9d15-82c0a4e3f2bc	2026-01-07 06:25:59.802514+00	8.5	22.3	740818	740818
ef2e5688-f5cf-46f9-9e4b-45ef2680b875	2026-01-07 06:25:59.865598+00	8.5	22.3	367782	367782
cc540492-a22b-48d4-91cd-aedbd6f807f0	2026-01-07 06:25:59.886954+00	8.5	22.3	473403	473403
268d0e07-eeda-4374-8935-e2f8fe2559e0	2026-01-07 06:26:09.410778+00	14.5	22.4	651850	651850
8b010fca-4b64-4b70-9fea-032bb30bbe9c	2026-01-07 06:26:09.425933+00	14.5	22.4	1095574	1095574
024f76c3-ca58-438f-afbb-43c334b1a29e	2026-01-07 06:26:10.310466+00	14.5	22.4	825757	825757
f5dfe78d-9e8a-4bd1-a2c6-ac449ed2007b	2026-01-07 06:26:11.686675+00	30.3	22.3	442721	442721
cbdfd259-3293-440d-a3db-32e8c29faa3e	2026-01-07 06:26:32.250896+00	20.5	22.2	632680	632680
971e46ad-1448-48e8-b98d-05d6464fd46d	2026-01-07 06:26:53.209304+00	12.6	22.1	47191	9836
fdde740f-3f2c-44e6-bf4c-b7bcbb33ca6c	2026-01-07 06:26:58.343285+00	9.5	22.2	441865	441865
8acebb5f-30a8-4f23-8385-7b9186b2c73b	2026-01-07 06:26:58.392246+00	9.5	22.2	483490	483490
7a04a873-679f-4fc3-a0af-4a1a1fc47805	2026-01-07 06:26:59.440794+00	8.4	22.2	320934	320934
e08dabd0-2567-4302-a3a2-8be41667b1ab	2026-01-07 06:26:59.441765+00	8.4	22.2	266776	266776
903fee73-9b89-4c8c-8a5e-ba04317d60b4	2026-01-07 06:26:59.535748+00	8.4	22.2	366511	366511
5a3904f1-994a-46f1-99e5-95a1895cb6c3	2026-01-07 06:27:09.062805+00	14	22.3	563093	563093
1ee0ca65-e067-4d55-bfd7-a48fc2bbbb98	2026-01-07 06:27:09.067983+00	14	22.3	768520	768520
46fb07ea-97d2-4055-9b29-9f939dfb1f87	2026-01-07 06:27:09.872482+00	14	22.3	802472	802472
308e2bce-291d-4760-b2f3-ea96c482a2e2	2026-01-07 06:27:11.337625+00	33.5	22.2	922884	922884
a74a9d33-4130-4c87-840e-9d7e19589a39	2026-01-07 06:27:32.207011+00	24.1	22.4	702801	702801
aef8851e-053d-411c-be54-d189fb47532f	2026-01-07 06:27:53.214053+00	12.8	22.3	60742	9821
9dc5d365-0f2e-4388-a705-61d93c8b77f1	2026-01-07 06:27:58.617502+00	8.3	22.4	214209	214209
7fcbfc3a-f086-48de-84a0-6113e5e6abed	2026-01-07 06:27:58.672763+00	8.3	22.4	651151	651151
fea0e22f-ef90-484e-be4f-fcd0d8fd8d13	2026-01-07 06:27:59.826624+00	6.9	22.3	425774	425774
b522f5af-2b51-4194-9e12-23bb35610f6b	2026-01-07 06:27:59.828872+00	6.9	22.3	555949	555949
447ed78c-110b-4fbf-b1cf-bf79a58490ec	2026-01-07 06:27:59.993063+00	6.9	22.3	326315	326315
40d4f68b-baca-4428-a61f-038b44feb10a	2026-01-07 06:28:09.399273+00	8.1	22.3	1089268	1089268
7af77fb7-4a85-4466-830b-5564e9f2879a	2026-01-07 06:28:09.406801+00	8.1	22.3	845203	845203
10d5f129-4b0f-4ec6-b0ae-540819e34154	2026-01-07 06:28:10.288463+00	8.1	22.3	743534	743534
11c3926d-58e4-4d84-b96a-ce1294af135a	2026-01-07 06:28:11.694357+00	72.6	22.3	1964757	1964757
626e9ffa-228f-4b67-8fae-bef82198965c	2026-01-07 06:28:32.257242+00	10.7	22.3	809144	809144
4787e889-347a-4223-ae62-52c373a2d814	2026-01-07 06:28:53.181713+00	13.8	22.3	59187	10013
70f00937-c524-4463-8431-6a2a2d0db828	2026-01-07 06:28:58.330254+00	9.7	22.3	619774	619774
c86ece04-7f95-4cfd-aa2b-a4e31cd849bb	2026-01-07 06:28:58.397068+00	9.7	22.3	806067	806067
ec1a3bdf-aef4-414f-ac72-c417643e69c4	2026-01-07 06:28:59.497858+00	7.4	22.3	262123	262123
8a533d25-238f-402e-a3e1-2a532338118a	2026-01-07 06:28:59.499497+00	7.4	22.3	503052	503052
2649210b-7024-4814-8bc9-c7393edbc756	2026-01-07 06:28:59.581459+00	7.4	22.3	553535	553535
b5865a68-ccc6-41f1-b092-52a9a82aa578	2026-01-07 06:29:09.225687+00	14.4	22.4	142830	142830
f9053aab-2921-42cf-a8c4-fbf7f52d5994	2026-01-07 06:29:09.23252+00	14.4	22.4	730909	730909
92ddcf46-2411-4b07-99d3-05860cea0c75	2026-01-07 06:29:10.044505+00	14.4	22.4	965725	965725
cae6f46f-5504-4a6f-af83-29e09c4563ee	2026-01-07 06:29:11.444391+00	24.2	22.2	585371	585371
ba28ef52-fe0d-4b63-a98d-3212fea48e89	2026-01-07 06:29:32.217688+00	10	22.3	1083302	1083302
b32274d2-243e-4761-8050-3e603865e74b	2026-01-07 06:29:53.226458+00	13.6	22.3	56107	9349
18a57f56-ef34-4f0c-aa6a-bb08a1192704	2026-01-07 06:29:58.424964+00	9.5	22.3	481729	481729
f77ef867-921a-4d19-a741-d1e3231a7855	2026-01-07 06:29:58.563466+00	9.5	22.3	404798	404798
f13403fa-470c-4926-90e7-99c221887b9b	2026-01-07 06:29:59.699657+00	7.7	22.3	382335	382335
15ce7a4d-aa19-47b5-8a2d-383b18656f9f	2026-01-07 06:29:59.784714+00	7.7	22.3	650019	650019
3faf714e-1ee5-43cb-bb95-d35edbc2ed57	2026-01-07 06:29:59.841941+00	7.7	22.3	814837	814837
4df9c06c-fbd7-4bb1-90b2-9f8ba1394577	2026-01-07 06:30:09.344576+00	8	22.3	464065	464065
654275b7-28cf-4da1-97c4-46f72c607052	2026-01-07 06:30:09.345593+00	8	22.3	901785	901785
a215d154-f2f0-4dc3-a8dd-18f68be2fe68	2026-01-07 06:30:10.233316+00	8	22.3	1186755	1186755
45290ea0-7ff2-42f7-bdcf-0b7634d41c19	2026-01-07 06:30:11.686023+00	71.6	22.4	663339	663339
208e5e59-2a85-4dbc-a325-7d07367701a4	2026-01-07 06:30:32.341524+00	13.9	22.4	829943	829943
d13032e8-a8cd-4e8c-abec-aa01d5ff3f9d	2026-01-07 06:30:53.224624+00	10.8	22.3	63596	11147
32850236-603a-4b24-bf4d-664d6cebe948	2026-01-07 06:31:10.667869+00	31.5	22.2	1047948	1047948
1063bcd2-2faa-435a-af07-92c2ba5b4516	2026-01-07 06:31:58.551364+00	10.5	22.3	628918	628918
429141da-0b29-4b04-a6c8-dbe56a44d825	2026-01-07 06:32:10.363111+00	17.2	22.3	1168318	1168318
af37c871-ddfe-44fc-9120-70d3a6917a21	2026-01-07 06:32:58.555533+00	8.5	22.3	480807	480807
1fcec43a-c12e-49c0-9bd6-134cc684274f	2026-01-07 06:32:59.929863+00	6.9	22.3	521295	521295
6047ae41-d50a-4598-88ea-ece3fddadc22	2026-01-07 06:33:09.724662+00	13.1	22.4	703210	703210
9707e038-b245-43e1-b893-dc706d7d7446	2026-01-07 06:34:10.07749+00	21.5	22.3	670192	670192
5afac3fe-76a1-427f-82a4-202216e368bf	2026-01-07 06:35:09.29998+00	13.3	22.4	219062	219062
2c208b92-03ee-4ad4-98fd-34330a281f15	2026-01-07 06:35:58.510964+00	10	22.3	579621	579621
853e765d-aeb2-4539-8109-50fd0971a7ed	2026-01-07 08:09:54.15424+00	8.5	22.2	13394	9664
3145fde8-9914-4d3a-bfac-a623172189a1	2026-01-07 08:46:31.210168+00	8.3	26.4	118704	118704
f67cf249-3ced-40a9-a402-3fb18033646a	2026-01-07 08:48:35.366453+00	7	28.7	420793	420793
8510a9a0-5b25-4d23-b09a-2fc7155e7aca	2026-01-07 08:49:35.361722+00	8.7	29.1	261332	261332
30bf45da-5263-4f85-8841-d7320c6d1d0f	2026-01-07 08:50:53.270297+00	6	28.5	141982	141982
fe6162df-53ba-4043-a286-176ed935e539	2026-01-07 08:53:53.303052+00	62.2	29.4	167459	167459
37b05a1f-49b9-4329-ad7a-4aff37690fb4	2026-01-07 09:32:56.999372+00	11	28.4	3142	7264
5dec6b2e-93da-4bd4-9879-4fe85055e584	2026-01-07 09:55:52.109809+00	5.1	24.6	26447	26447
5f036b8b-9f53-4e09-bc25-56d49788cc48	2026-01-07 10:15:52.013458+00	8	26.5	852995	852995
44f2974d-cd05-41e8-9d90-a4d78bcf40e6	2026-01-07 10:36:52.116799+00	4.8	26.4	181903	181903
911d3e2b-0bc4-4dad-8a0d-15abd3d228f5	2026-01-07 10:53:52.105029+00	9	28.5	103480	103480
2dff34ff-987d-4428-a87e-c15456daf676	2026-01-07 11:10:52.055128+00	28.2	33.6	234114	234114
19b987bf-63e9-4284-ab96-c69238be043d	2026-01-07 11:10:52.055124+00	28.2	33.6	81752	81752
c419d941-4a04-4610-97a9-5afbe78cb90d	2026-01-07 11:30:13.674211+00	15.1	27.8	7245	4651
6c3d3746-210a-4924-8203-0d8964485104	2026-01-07 12:24:52.074529+00	95.3	36.5	109649	109649
d366fda8-209c-4c43-9c79-addb9e9fe4ef	2026-01-07 12:25:51.92951+00	66.9	32.9	0	0
ff1018e2-c9f0-44b8-81a0-9bb0095c60c9	2026-01-07 12:26:52.0365+00	83.4	29.9	366360	366360
7eb4d830-2cd8-42d0-8579-b6d86f60681b	2026-01-07 14:38:39.377969+00	34.3	29.8	1664521	1664521
aaf477cf-65e1-42f8-befc-f54a297d2de7	2026-01-07 14:39:39.294294+00	30.8	32.3	649863	649863
c238665c-1462-43f6-a816-d11d5fa21e3f	2026-01-07 14:40:15.444914+00	32.4	33.4	569957	569957
fb799d07-dd50-40fe-a86b-063e33b157c8	2026-01-07 14:40:39.394359+00	52.8	35	400701	400701
50bac820-22a5-4fe6-b300-5c9db0596724	2026-01-07 14:40:51.878813+00	33.7	32.4	294510	294510
3779e8bd-c715-43e4-b357-ea7ad2a23c65	2026-01-07 14:41:38.332406+00	37.8	30.5	1416640	1416640
902fe2b0-2aac-47c5-b0d4-b455d5b54ea1	2026-01-07 14:42:39.362433+00	37.6	31.4	2076090	2076090
2c862db2-964b-4acb-96dd-3a483237b937	2026-01-07 14:42:51.931101+00	39.2	31.3	2115260	2115260
4c14c98b-2f17-4aa7-94a9-ed7f2b18de66	2026-01-07 14:43:39.320982+00	32.8	30.2	930833	930833
6b19e6f6-360c-4ad7-a590-15dbc2ffccf4	2026-01-07 14:43:51.861647+00	33.4	31.3	252476	252476
3939e310-a145-45e4-a6c1-6ded9062ba4c	2026-01-07 14:44:39.320189+00	31.3	31.2	748233	748233
3d672deb-c518-45a7-8eb4-a6e759ef65b9	2026-01-07 14:44:51.915774+00	25.2	31.3	202471	202471
d15df899-ab6f-4302-8c6d-c3dec9747d66	2026-01-07 14:45:39.362978+00	10.8	31.2	334110	334110
9bdb8d45-6541-4643-8201-23ace61d8dc2	2026-01-07 14:45:51.897499+00	10.5	31.2	226185	226185
2ef681cf-e147-4e9d-bf5b-7ea064b0cca8	2026-01-07 14:46:39.341793+00	11.4	31.2	552754	552754
6e4b56ca-5e01-4bc7-b7c3-ef64aa86555c	2026-01-07 14:46:51.928211+00	11.4	28.3	242116	242116
aad9ba4a-3bea-4958-9cd6-5be894afae58	2026-01-07 14:47:39.321329+00	12.2	28.3	818079	818079
af47dade-3baa-4109-a04c-abe4e0dda40c	2026-01-07 14:47:51.885677+00	12.2	28.3	333384	333384
f9ed1a8a-f41e-4723-9f97-091d79f501b1	2026-01-07 14:48:39.351987+00	11.1	28.2	359503	359503
d656d6c6-e245-4f4e-b0b3-546d692edeb4	2026-01-07 14:48:51.894706+00	11.4	25.2	194981	194981
7e7c0ae8-f86b-44d3-9e60-b86b20ac6a76	2026-01-07 14:49:39.386131+00	12.4	31.8	342316	342316
2cd95802-7810-4ea1-b0f5-e855e7ceb197	2026-01-07 14:49:51.949246+00	15	31.8	85184	85184
c1b0a5bd-f763-4af9-8351-d1464b4d69fd	2026-01-07 14:50:32.112386+00	38.3	33.9	818547	818547
1d65c949-3b7e-425d-9590-bf1f8e0aff57	2026-01-07 14:51:15.427905+00	9	33.2	561950	561950
bea7203c-6cbe-472e-a027-5c3883b42bb1	2026-01-07 14:52:15.412476+00	9.9	33.2	708114	708114
e3729511-6c55-42d2-94a1-2c7958fd2b53	2026-01-07 14:53:15.462359+00	10.9	28.4	349295	349295
c4ba1068-fcba-4fbb-89e9-06eafdf0f513	2026-01-07 14:53:39.353985+00	11.3	28.4	452434	452434
afd921ae-0c5d-47da-9e85-af5c46d3f5f5	2026-01-07 14:53:51.916417+00	10.6	28.3	187457	187457
f45e97c5-344a-4792-99d7-0c3f9e283070	2026-01-07 14:54:39.355757+00	11.6	25	333617	333617
944e1dc9-e9aa-4910-9cfd-b2ba56ed05cf	2026-01-07 14:54:51.905057+00	11.4	25	274033	274033
f3a9e18f-98ef-450a-ae00-e9b0d43db3f3	2026-01-07 14:55:39.353494+00	11.4	25	247029	247029
60b2351a-2634-4a67-b9c9-fb065223a6d0	2026-01-07 14:55:51.901398+00	10.8	25	227866	227866
4fcbfb64-11e8-48ab-a6a0-207e227ca49d	2026-01-07 14:56:39.322127+00	10.8	25	657459	657459
2ca6370b-e0b6-485d-a5de-3d2c9d2890e0	2026-01-07 14:56:51.922637+00	10.4	25.1	313522	313522
9b398f4f-787d-4fd2-8250-2d91a5dc8098	2026-01-07 14:57:39.345729+00	30.2	28.9	1746132	1746132
82d9be17-a898-4657-9d38-955e8603d1fa	2026-01-07 14:57:51.905522+00	28.6	28.9	985665	985665
33e61e24-b560-4065-9acb-501efd079ca3	2026-01-07 14:58:39.329175+00	11.1	29.1	520326	520326
7ac4852f-c1f2-4270-a756-5b109da7a8ab	2026-01-07 14:58:51.867857+00	10.5	29	294410	294410
7eba68d2-158d-4517-b17d-357c11723b06	2026-01-07 14:59:32.260207+00	10.5	29.1	1539442	1539442
7cb0ef13-4905-4527-aa7b-94693c76d014	2026-01-07 15:00:15.41491+00	9.6	26.3	728618	728618
6b0d360b-e030-4325-ad98-20e29f347de4	2026-01-07 15:01:32.2735+00	11.1	26.3	1044536	1044536
5dbba0d7-f1ad-4f0b-9a6c-14d1d8347fed	2026-01-07 15:02:32.283075+00	11.1	25.4	889134	889134
cec2fe16-38fb-4d2e-84a1-28c2af15dbc3	2026-01-07 15:03:32.296594+00	28.5	25.2	1906866	1906866
f95efced-8247-488f-928d-cabaa0035a56	2026-01-07 15:03:56.815247+00	31.9	26.1	245161	245161
482d2126-57d5-4a4c-a0c6-94a1f4846d99	2026-01-07 15:05:15.451672+00	37.7	31.5	3778663	3778663
cf3c5641-4a6f-4880-9c47-38cc6cdc6770	2026-01-07 15:05:39.336769+00	32.7	31.7	1130039	1130039
8bf13399-396c-45cc-92f5-6619c873186b	2026-01-07 15:05:51.928676+00	35.4	31.6	4676372	4676372
19f2146d-8d96-47b9-8e00-121cd4603545	2026-01-07 15:06:39.320262+00	36.7	31.7	1076833	1076833
65ef352f-cffc-425b-90ff-fd707d6502bf	2026-01-07 15:06:51.950594+00	39.6	31.6	5843185	5843185
3dc7119c-5908-489e-a8e2-3b68f8555e7f	2026-01-07 15:07:39.334944+00	28.3	31.8	899800	899800
d61d673e-c76e-48a6-a555-0c438b20f322	2026-01-07 15:07:51.893246+00	10.9	31.8	254860	254860
8ed2c2ff-9e5b-4f75-9053-a3eccbbd1b70	2026-01-07 06:30:58.477778+00	9.9	22.3	608730	608730
c2755481-b89c-491d-bae2-87bb7f525422	2026-01-07 06:30:59.746242+00	7.5	22.3	432787	432787
f21446c1-624e-46eb-a461-386f75d0eccd	2026-01-07 06:31:09.712414+00	21.6	22.4	394218	394218
599432db-49cd-4ac5-8344-59a9bc119acb	2026-01-07 06:31:59.675215+00	7.1	22.4	284337	284337
89ae2ed0-58e8-4004-801c-4a4c161cdc1a	2026-01-07 06:33:09.725432+00	13.1	22.4	577435	577435
01243ea9-6128-45d2-9251-98bbe34d9285	2026-01-07 06:33:10.616118+00	20.4	22.3	1117557	1117557
a2eb0f1f-033e-4c3b-bdfd-52199a1af4e7	2026-01-07 06:33:59.692609+00	8.6	22.4	432613	432613
bf22eb39-48ff-4495-8c68-f4fba2efa58c	2026-01-07 06:34:58.402731+00	9.8	22.5	655603	655603
47f40a9d-d692-4b27-84f6-c80eb1331c40	2026-01-07 06:35:09.302501+00	13.3	22.4	514625	514625
c0ed8252-1b76-4530-910f-0cc00c9d92bf	2026-01-07 06:36:09.754193+00	7.3	22.4	731532	731532
2c08c4c2-79ce-4164-834c-ea5f9a437961	2026-01-07 06:37:09.066496+00	17	22.4	811225	811225
16d3ca1f-bee0-423b-8f4e-9d009ae8392e	2026-01-07 06:37:59.561719+00	8.3	22.4	618306	618306
d901e425-c9b0-4fd7-82d4-6cdcd17497ca	2026-01-07 06:38:09.841174+00	8.7	22.4	950168	950168
bfab9ba7-928b-4e7d-81c3-ce25fe5ffb44	2026-01-07 06:38:32.364414+00	20.5	22.5	1134766	1134766
e0f9335d-315a-44cc-acbb-59f9ada2a447	2026-01-07 06:38:59.598081+00	8.9	22.5	519456	519456
25e617f8-5b27-4ae4-95dd-ca7357cf32b4	2026-01-07 06:39:09.218912+00	13.7	22.4	538993	538993
6d121543-317f-4d54-80bd-3777f7618435	2026-01-07 06:39:10.072197+00	13.7	22.4	777550	777550
34016bfe-d685-4bac-9bb4-dffe4670f37b	2026-01-07 06:40:09.297465+00	17.3	22.4	721427	721427
713948cb-d61e-4303-aaca-0782fa867b68	2026-01-07 06:40:10.208893+00	17.3	22.4	945235	945235
7bcfc770-d6a6-42dc-9f01-504280eb1524	2026-01-07 06:40:58.338594+00	10.5	22.3	272039	272039
8d50dc91-5a2a-470c-990e-12f9a48c3b49	2026-01-07 06:40:59.64378+00	7.7	22.3	534793	534793
03e6e5dd-c6bb-4856-9f12-eff5681be099	2026-01-07 06:41:58.369532+00	10.3	22.4	279952	279952
b5574c52-7c0c-4139-94d4-251927754e7b	2026-01-07 06:41:59.632574+00	7.6	22.3	525329	525329
9fe46630-ba8b-441d-8b47-8893b8855ed9	2026-01-07 06:42:09.037047+00	16.2	22.3	700157	700157
b49e6920-7341-44a1-a283-0a7f9dedf4fb	2026-01-07 06:43:09.933416+00	16.3	22.3	733175	733175
bdc399d6-fbb6-4e29-a767-97267a8c0362	2026-01-07 06:44:59.60493+00	8.7	22.2	468573	468573
3e5292fc-40b3-4d09-9bf8-f990fe24ed34	2026-01-07 06:45:11.410112+00	17.4	22.3	1011821	1011821
906071dc-5176-4999-a813-65a2a64417dc	2026-01-07 06:45:58.336343+00	11.8	22.3	662544	662544
021d1d9f-4531-4b47-926a-a4e0a3487402	2026-01-07 06:45:59.618452+00	7.3	22.4	723140	723140
dbfd0644-9210-49b5-a8c7-5eafe9ff2a4c	2026-01-07 06:46:09.234746+00	15	22.4	655419	655419
b295696f-1d69-4d4a-99bc-37ec5f6c92cf	2026-01-07 06:46:32.297951+00	9.1	22.4	810572	810572
e420af2c-8898-402c-b010-da38e98703c0	2026-01-07 06:47:58.342152+00	11	22.4	587586	587586
bde814ef-aa88-4c54-ac6f-00692a77194e	2026-01-07 06:47:59.694518+00	7.1	22.4	527577	527577
b32efe4d-0cf6-4a3a-be3f-ea6676395524	2026-01-07 06:48:09.471677+00	14.9	22.4	478709	478709
ddbb3763-b989-4de1-8ef7-9c919f22dd3f	2026-01-07 06:48:11.786129+00	30.3	22.3	386616	386616
9197465c-7dbf-420b-8311-34fe88c8d59a	2026-01-07 06:48:58.453392+00	10.5	22.5	527410	527410
dbe8cc62-35f2-45cf-bc49-5bc4846b2bb1	2026-01-07 06:49:09.170204+00	18.2	22.3	493205	493205
d033e3a7-8dd0-46d8-9af5-6943953784dc	2026-01-07 06:49:32.327863+00	8.9	22.4	748745	748745
d32b7603-cb91-4e42-bad5-3778a5e4cad3	2026-01-07 06:50:09.944331+00	7.7	22.4	1291022	1291022
b53f4232-d333-40d9-b82a-56adbf7d53b9	2026-01-07 06:51:58.552974+00	9.4	22.4	480434	480434
7fd211ff-6f80-45db-b87c-1620a8b07dd2	2026-01-07 06:52:09.166237+00	11.5	22.4	547260	547260
350d1e70-ab91-417d-b731-f8d36beb60f0	2026-01-07 06:53:58.530514+00	10.7	22.4	707806	707806
e5564d42-f0f3-46d0-b14c-6cc953425b8d	2026-01-07 06:54:58.325212+00	10.1	22.4	621452	621452
db02a55f-2688-4789-889b-bd3d81b27a19	2026-01-07 06:55:58.552365+00	11.4	22.4	657066	657066
beb32a48-5f0e-471b-a2be-e57d97628c76	2026-01-07 06:55:59.732731+00	7.3	22.3	505526	505526
050796c5-fb2e-4462-a299-fe4d59246a2a	2026-01-07 06:56:11.963795+00	18.7	22.3	691656	691656
59ae9363-b7f7-441c-9ceb-637205d3c786	2026-01-07 06:57:09.074812+00	6.9	22.4	895847	895847
a49689ba-3370-4810-a82e-b497d13f02fe	2026-01-07 06:57:58.322233+00	11.1	22.4	712586	712586
06b09258-5647-4688-8f45-c87aef5051d2	2026-01-07 06:57:59.639706+00	7.6	22.3	543371	543371
d08ff991-3985-4a71-af3e-8f7e972db826	2026-01-07 06:58:58.367307+00	9.9	22.3	618329	618329
d270afe2-7742-43bd-b652-c9a8e6883f65	2026-01-07 06:59:09.459599+00	8.1	22.4	493723	493723
16b09fa2-54b2-4f38-9ce4-f8c3ce104ba8	2026-01-07 08:10:54.147627+00	8.3	22.2	12685	7527
6a08e12c-08a3-4308-a807-0f3e0696810c	2026-01-07 08:46:54.477986+00	8	26.3	28922	668109
6894ab90-e551-4228-8886-f8961283f332	2026-01-07 09:33:56.986609+00	7.8	29.2	2388	3575
a5ead33a-36d2-4ab4-bdd1-8256d257710c	2026-01-07 09:56:12.440406+00	4.6	24.6	3205	2324
44fb5ec0-d2fe-4dac-87ea-f038de226f85	2026-01-07 10:16:12.761407+00	23.2	28.7	42493	16504
557f2c74-ad94-4757-a3d3-8e81cc7ee774	2026-01-07 10:36:52.116789+00	4.8	26.4	76974	76974
bd64d061-96de-4e62-ad4e-03621cd72fc1	2026-01-07 10:54:13.268148+00	11.6	26.8	6431	4315
3824aede-24a5-4a0d-abea-47cf6f032b54	2026-01-07 11:11:13.410184+00	15.6	33.5	6362	4396
df24a707-a9e6-433f-a48d-63da33f0bb0d	2026-01-07 11:30:52.050905+00	18.8	27.7	281935	281935
bebc9849-192d-43c8-9803-0115b0d8ccd1	2026-01-07 12:24:52.089437+00	95.3	36.5	650954	650954
af2a0dd3-bd12-4b97-a964-c6c3b5445d1e	2026-01-07 12:25:51.938849+00	66.9	32.9	697693	697693
5ce7cfd2-f688-4e9c-80c2-83f3a7cad465	2026-01-07 12:26:52.042402+00	83.4	29.9	0	0
0ef46132-0b78-4a39-9bb3-d0f94a8053bd	2026-01-07 14:38:51.882055+00	33.2	30.5	131908	131908
e9d127b2-8dbd-43e2-a741-6d7a580bdf83	2026-01-07 14:39:15.41787+00	32.3	31.8	613577	613577
fa657322-09c8-4776-bf57-f32c61ddef33	2026-01-07 14:39:51.881927+00	37	32.3	273175	273175
2598bede-57e7-4655-ba5f-39f7e0355359	2026-01-07 14:41:09.61157+00	31.9	31.5	852756	852756
eeeba8ce-cad6-4fd8-bcd5-9a9fdb0b979f	2026-01-07 14:41:15.422979+00	38.8	31.6	1492508	1492508
7d1b795d-1464-4e19-adde-9072d15b7942	2026-01-07 14:42:15.434237+00	39.6	31.5	2108575	2108575
51f39ac4-bbff-4988-8ffb-0983062c1ef8	2026-01-07 14:43:15.421442+00	33.8	32.2	451616	451616
39aa3b2e-a81d-4cc1-a860-543bec6aafdf	2026-01-07 14:44:15.42266+00	31.3	31.3	982216	982216
7b550e6b-db45-4443-a0d8-e8551d735e92	2026-01-07 14:45:15.428361+00	11	31.3	685202	685202
f68d41ae-b15e-4cef-9fb3-0913e7e3f8fd	2026-01-07 14:46:38.233654+00	11.4	31.3	1569500	1569500
ee8728a2-f8e2-41fb-909e-dda38697db8a	2026-01-07 14:47:15.419178+00	9.5	28.3	1313482	1313482
739a7649-cc63-4665-b028-f1f6bc38ce02	2026-01-07 14:47:32.335359+00	11.9	28.3	1150996	1150996
afaad2e2-d483-4db7-b932-0a58a9ded0b7	2026-01-07 14:48:32.260654+00	10.3	28.3	1412357	1412357
39ba9a1c-eb3c-41d3-a0a1-2b32efcdd88b	2026-01-07 14:49:32.307291+00	19.9	31.8	539578	539578
d81d7c7f-7914-4c7a-8243-a290649026e4	2026-01-07 14:50:39.358063+00	35.7	33.2	451334	451334
b6d862e5-54d1-46ae-bfec-f248b98c36d1	2026-01-07 14:50:51.881563+00	11.2	33.2	367191	367191
f9b64ca6-c95b-4e8e-9c05-e4dee1e82a4b	2026-01-07 14:51:39.316304+00	8.2	33.2	648893	648893
b7b4ef4e-3334-43e9-94e0-68284d942ac2	2026-01-07 14:51:51.903245+00	10.6	33.3	325096	325096
f19ac6a4-4c6f-4309-9003-b674b6524595	2026-01-07 14:52:39.372812+00	11.5	28.5	324615	324615
050be394-dcb2-4ba2-8426-b97f1e486fb4	2026-01-07 14:52:51.874307+00	9.7	28.4	334472	334472
1cc10a8e-9abb-44a7-92ae-350f5e6a685b	2026-01-07 14:54:32.299908+00	11.8	25.1	408578	408578
a590e6e5-0f0f-43d3-bf59-ff184832ba67	2026-01-07 14:55:15.426489+00	10.5	24.9	753504	753504
6e9a7e90-6dd2-46a7-abd4-b8069ccf460a	2026-01-07 14:56:32.295019+00	11.2	25.1	696580	696580
f99c4dc6-61f6-443c-a205-b88f381163da	2026-01-07 14:57:32.276103+00	19.5	28.6	1676234	1676234
16a59a3b-bf8e-4e75-b69a-a2274916f311	2026-01-07 14:58:15.452868+00	12.5	29	438865	438865
aff21bb5-a437-4dec-bcfe-ef5e21bf4b82	2026-01-07 14:59:15.415113+00	9.9	29.1	486293	486293
fe0b105d-6bfe-4151-b864-adcc5f79dfc2	2026-01-07 15:00:32.29102+00	11.2	26.3	650913	650913
bbe2850c-6931-4fab-820f-064834da3742	2026-01-07 15:01:15.414907+00	10.1	26.4	867338	867338
ea0f7b3e-a908-4b8f-b6fc-0c2e36fa809c	2026-01-07 15:02:15.410838+00	13	25.3	687078	687078
299b2e48-e599-497c-8f8c-88ac77c79bec	2026-01-07 15:03:15.443142+00	11.1	25.2	410298	410298
78664c74-4829-47ac-b39b-46e4c9581413	2026-01-07 15:03:39.342343+00	18.4	25.5	1900037	1900037
03ddca5a-acfc-4717-b48a-616d30ba5692	2026-01-07 15:03:51.89876+00	29.7	25.7	211006	211006
2c7e47c9-18be-4c65-b942-b492bd9c1ebc	2026-01-07 15:04:15.449995+00	37.7	28.9	3213170	3213170
680d4c57-11e9-4680-bce2-4df552d01cb4	2026-01-07 15:04:39.328524+00	39.7	31	887747	887747
edebd8e6-537e-4a0c-8235-bc0046b88d99	2026-01-07 06:30:58.534789+00	9.9	22.3	684852	684852
7facb149-21d6-4a46-9d57-63af0a1275bf	2026-01-07 06:30:59.640406+00	7.5	22.3	542439	542439
c4ba0def-d540-4c0a-af73-23df62a67654	2026-01-07 06:31:59.739469+00	7.1	22.4	442585	442585
93f38ab9-673a-4519-b63b-20c92985b819	2026-01-07 06:33:00.110768+00	6.9	22.3	623423	623423
ee0a1aa0-436b-4481-9a37-7c76b4f94576	2026-01-07 06:33:12.030175+00	20.4	22.3	753217	753217
8174cb2b-5206-4652-838d-ebb9d33e6743	2026-01-07 06:33:58.331031+00	12.9	22.4	555355	555355
c6311b21-607d-481d-8b70-bd87abef7ccd	2026-01-07 08:11:54.198973+00	7.4	22.2	9494	6277
b7ea9ae4-cf24-4785-b5f1-36539b6d3a7d	2026-01-07 08:47:31.179603+00	8	28.6	250988	250988
70ef3e63-585b-47ef-b1d0-aef81b1edfe9	2026-01-07 09:34:57.010836+00	10.7	30.8	2161	4298
908f3be9-fd94-4875-8fb9-aaf5dadbf9bd	2026-01-07 09:56:52.082255+00	4.6	24.5	100740	100740
c8944cc2-cb6c-4404-a312-37c9532d2d8d	2026-01-07 10:16:42.867259+00	25.3	30.5	801844	801844
5e61d20b-0ae6-4044-b6e1-5980179e22d9	2026-01-07 10:17:42.798006+00	8.5	30.6	126268	126268
cb9204a7-62bb-4de0-ab08-0c256ad70b8d	2026-01-07 10:37:13.016243+00	4.9	26.4	5605	3649
bf128eac-3b9a-482a-887e-2e9c3f111462	2026-01-07 10:54:52.122787+00	12.4	26.5	60914	60914
c390c984-0021-4d62-8fdf-f2c4ee6954d4	2026-01-07 11:11:52.130413+00	28.5	33.4	89822	89822
36a4fa77-b25d-4673-9463-03bf53b1d176	2026-01-07 11:30:52.051451+00	18.8	27.7	132656	132656
f1a5fce3-525a-4310-8196-2d3a80d399d5	2026-01-07 12:27:52.279093+00	82.3	25.7	382229	382229
339d139c-a76b-45f8-b9c3-46d6b707a86a	2026-01-07 12:28:52.383355+00	83.7	25.3	229656	229656
f66658c9-50f1-4019-8d3c-2eebc3f1a32a	2026-01-07 14:41:39.338727+00	37.8	30.5	2758751	2758751
b71af8b8-268e-4ebd-92e0-9e7b296d0e38	2026-01-07 14:41:51.891153+00	42.2	30.5	4792610	4792610
d40a0d97-f7d7-4a5f-becf-70bdcba368fd	2026-01-07 14:42:38.342766+00	37.6	31.4	2632590	2632590
8c4fc324-c204-4304-b250-ae65c81ea0f4	2026-01-07 14:43:38.242384+00	31.7	30.4	1713462	1713462
6d0db58f-58fe-4b92-b1ce-d891c457efe9	2026-01-07 14:44:38.237533+00	34.1	31.2	1770207	1770207
73bc213b-c57e-4320-a012-1e73bea03f82	2026-01-07 14:45:38.261152+00	10.8	31.2	645959	645959
c765947f-e3a8-42d2-b61d-0ffb3b3242a8	2026-01-07 14:46:15.479459+00	11.3	31.2	167525	167525
e3e930c4-f445-452c-8ad4-f271e837bf2e	2026-01-07 14:48:15.421144+00	12.2	28.2	938010	938010
05a3db20-8356-4de3-8b8c-984621977c3c	2026-01-07 14:49:15.42205+00	11.6	29.1	692964	692964
6e549ddd-433f-44f4-9728-be210b9adf13	2026-01-07 14:50:15.442714+00	56.6	37.6	657928	657928
5ddea930-492b-4250-abda-69760f59108b	2026-01-07 14:50:32.293226+00	38.3	33.9	1500998	1500998
7f057f10-c3c7-4dfc-a552-f9290bfba186	2026-01-07 14:51:32.30487+00	11.1	33.2	947316	947316
eaa8da63-58f5-43ec-91ed-02afe34ad98c	2026-01-07 14:52:32.298222+00	13.3	28.4	684383	684383
ceb2fd08-3c28-4357-a79c-585808ed0cc1	2026-01-07 14:53:32.25645+00	11.1	28.5	1362733	1362733
a14a99e8-c06f-450c-8b67-d7279b17a1b8	2026-01-07 14:54:15.457152+00	10.8	28.4	352293	352293
d90709c7-f928-4389-8d99-6095a1252b6c	2026-01-07 14:55:32.296708+00	12.5	25	800708	800708
1f2321bf-29c1-4413-b659-b0cbc30d419b	2026-01-07 14:56:15.422888+00	11.2	25	585010	585010
6c991aa2-933c-47dd-bb9b-f9a7b7aab38a	2026-01-07 14:57:15.454122+00	10.7	25	277248	277248
3589aecd-7681-465c-9f92-aa96e8954b6f	2026-01-07 14:58:32.293482+00	11.7	29.1	722241	722241
bc1a9200-7c0c-4eb1-835e-cdb8ea05b461	2026-01-07 14:59:39.373541+00	12.6	29.1	407655	407655
912db213-0e9c-4210-b73e-60a201f9fa1c	2026-01-07 14:59:51.900314+00	11	26.3	352632	352632
15c4d698-4bea-4689-b399-92a798cc5425	2026-01-07 15:00:39.370105+00	11.1	26.3	386784	386784
ef49465f-f1ce-404c-8cd0-9c49fe32675c	2026-01-07 15:00:51.903691+00	13.6	26.3	427360	427360
a5639485-5187-4f9e-a26e-0d78f55ae01f	2026-01-07 15:01:39.35403+00	10.5	25.9	201920	201920
1cfaa811-14b6-4171-8a1b-e5e08bec0431	2026-01-07 15:01:51.900791+00	10.7	25.3	478241	478241
36a06962-973f-4d34-84e6-4608d7070e5d	2026-01-07 15:02:39.3515+00	10.6	25.2	297173	297173
c2090aa3-0e80-4edd-b850-5c88f050db2c	2026-01-07 15:02:51.904362+00	10.1	25.3	463054	463054
25098fed-de2c-4a37-b87e-24d60cf06233	2026-01-07 15:04:32.306214+00	43.1	31	2127783	2127783
4f7a39de-f847-4f8b-9039-7beaac47a41b	2026-01-07 15:04:56.698291+00	40.5	31.2	6072342	6072342
6adc3294-43bf-42de-97bc-b63d2c7af100	2026-01-07 15:06:15.409417+00	35.7	31.6	5662904	5662904
5eb53d78-efde-4cdf-bda5-b1b6700171b0	2026-01-07 15:06:32.277152+00	37.4	31.8	762929	762929
aa772746-6344-4c9e-88cd-897a196a44cb	2026-01-07 15:06:56.691041+00	37.2	31.7	5967266	5967266
b9d36946-2052-40d9-9bfd-c108131418d9	2026-01-07 15:07:28.392426+00	37.5	31.9	4504923	4504923
f53c457c-57b1-4650-ade6-49c7692e1bac	2026-01-07 15:07:32.395585+00	32.3	31.7	1019628	1019628
adfcfdae-db42-4c45-b825-d7efdd262810	2026-01-07 15:08:32.273216+00	10.7	31.9	754909	754909
d6ea2142-e72a-42bb-890b-a57976b79e67	2026-01-07 15:08:39.376557+00	10.6	31.8	614074	614074
40583044-ef7f-478e-8821-763de16b3b6e	2026-01-07 15:09:15.419516+00	10.6	31.8	865655	865655
34b92fd2-8898-49d5-a579-23c2eb438ac4	2026-01-07 15:09:39.330485+00	12.1	27.3	881848	881848
45d613ac-c264-4843-a3e7-6836b4e6013b	2026-01-07 15:09:51.897208+00	10.4	26.2	302131	302131
98aa4701-b269-4e06-9062-3fa4deec63ce	2026-01-07 15:10:39.314494+00	20.8	26.2	1337604	1337604
79e5ef29-aeec-47ed-8cac-0217de8f1a96	2026-01-07 15:10:51.891734+00	17.2	26.5	1149616	1149616
482e7617-775e-4f9e-b0ef-c09874f0b2f4	2026-01-07 15:11:17.737408+00	28.9	30.8	1430900	1430900
9e7d825b-27cd-45ac-80a9-43860b59c049	2026-01-07 06:30:59.641111+00	7.5	22.3	476956	476956
f091fb18-d13b-4933-a578-4988986ad52f	2026-01-07 06:31:09.714015+00	21.6	22.4	623777	623777
0541bf14-d861-4739-a224-34325c691c56	2026-01-07 06:31:12.017315+00	31.5	22.2	836105	836105
2ad77c6d-16fa-4849-bc7a-1fed4ad103ad	2026-01-07 06:31:32.27269+00	9.3	22.4	784869	784869
632e7529-cbbc-4222-afec-e6993e7e57ad	2026-01-07 06:31:53.231716+00	17.9	22.3	64188	9622
3f536753-af3e-4c75-bd96-fb92b8f65962	2026-01-07 06:31:58.558276+00	10.5	22.3	745643	745643
f019bb42-128d-4ac8-bb15-34d4b5e808e8	2026-01-07 06:31:59.841092+00	7.1	22.4	468072	468072
6f74a98e-c07e-4da6-9346-f0d6309ea014	2026-01-07 06:32:09.495029+00	17.2	22.4	899614	899614
6ed99b2f-9f79-4686-a67e-c3d210de5874	2026-01-07 06:32:32.230027+00	14	22.4	806543	806543
f5072135-ce3f-48ee-8ad7-c330c16f8319	2026-01-07 06:32:59.930309+00	6.9	22.3	844916	844916
9dcbe01d-88ce-4df1-9f0f-4d591c52dba8	2026-01-07 06:33:58.318782+00	14.1	22.4	375469	375469
e559ff59-3d97-452c-b14b-7726b582d502	2026-01-07 06:34:09.239228+00	21.5	22.3	728070	728070
495e0919-023e-4d01-8929-4f9398f7e1cb	2026-01-07 06:34:11.576121+00	20.6	22.3	762056	762056
182a5eb4-6783-4846-9558-d91b9df0d4eb	2026-01-07 06:34:58.525498+00	9.8	22.5	424870	424870
8f3f3ed4-1276-46e4-bde8-eabbc05b17fb	2026-01-07 06:34:59.443372+00	8.7	22.4	200611	200611
7c8eb4dc-f775-4247-bc5d-0a1ce276e90a	2026-01-07 06:35:32.242377+00	23.3	22.4	1001825	1001825
9842c610-d626-470e-9751-c3edfdb972fb	2026-01-07 06:35:58.452879+00	10	22.3	489367	489367
5bb2b1ca-38b7-433f-b0f7-475405390ae5	2026-01-07 06:35:59.950182+00	5.8	22.3	322190	322190
c00fe1d0-e846-4e91-b2f7-8ecf4dc7f0b8	2026-01-07 06:36:00.084796+00	5.8	22.3	190882	190882
a8a165ba-be42-41d7-9494-c784fa089b08	2026-01-07 06:36:12.097603+00	19.3	22.5	818415	818415
3f4ad92c-d111-451c-a39e-5e04ab3bc0f7	2026-01-07 06:36:32.212835+00	17.5	22.4	767891	767891
c98dc2dc-e673-4b9e-94a7-1ac518613782	2026-01-07 06:36:58.461343+00	8.7	22.4	661960	661960
38de2f5e-257d-4ee8-8d77-8200d357e53d	2026-01-07 06:36:59.593273+00	7.7	22.4	449994	449994
dba93fad-3086-4792-be3a-80715330c8a7	2026-01-07 06:37:11.296567+00	16.6	22.4	799588	799588
d65633d7-85cd-4c03-ac1c-3bd450c6031e	2026-01-07 06:37:58.417874+00	9.1	22.4	610240	610240
45567b2a-afd5-44c1-a76c-3935a5c519b6	2026-01-07 06:37:59.475794+00	8.3	22.4	146339	146339
d56a020f-ec0c-4e7a-a1a4-3b3a511f4365	2026-01-07 06:38:09.069752+00	8.7	22.4	984339	984339
3b175786-0f02-4d36-84d4-fd11b8873bc1	2026-01-07 06:38:11.318787+00	72.4	22.3	792969	792969
943d4391-a520-4b6f-9c08-d69f3fef6d8a	2026-01-07 06:38:58.526912+00	9.4	22.4	649503	649503
cade96e9-fb0f-408a-bcad-7f0a4eced234	2026-01-07 06:38:59.598828+00	8.9	22.5	315884	315884
f244539b-4ccb-4483-9bac-8d092a5deccc	2026-01-07 06:39:11.645415+00	15.8	22.4	789455	789455
49575190-89ea-499e-b6dd-bd0ae479934a	2026-01-07 06:39:58.572742+00	8.8	22.4	797937	797937
fb9cb5f9-6711-4e7d-b598-da5f598aef28	2026-01-07 06:40:58.38819+00	10.5	22.4	516579	516579
cddd1209-7d76-48b7-b43b-ce454de1bb65	2026-01-07 06:41:09.211418+00	21.5	22.4	737952	737952
ddf18298-5f59-46ed-997c-a896bc5120fc	2026-01-07 06:41:58.425775+00	10.3	22.3	655647	655647
e18ef19a-9903-491c-a20a-020c1aca2616	2026-01-07 06:41:59.514288+00	7.6	22.3	175945	175945
93dae338-15ce-47cc-8302-c207aea67704	2026-01-07 06:42:09.875327+00	16.2	22.3	1067108	1067108
9880ae1c-9ee5-4dc2-8527-aeb69db34f2f	2026-01-07 06:42:32.421859+00	10.1	22.3	889755	889755
7dbab0ab-f066-4c91-b085-a6a4f0ac0edd	2026-01-07 06:43:09.947271+00	16.3	22.3	773124	773124
68130ee9-483d-4fc3-9be4-c01e8c231ba7	2026-01-07 06:43:10.703119+00	16.4	22.3	1011903	1011903
e64d4361-1240-454a-aa0a-7b2328e3262e	2026-01-07 06:43:58.613416+00	12.2	22.2	567183	567183
e2299c7f-38ac-4d8e-9e44-56c593d2b94d	2026-01-07 06:43:59.733637+00	9	22.3	186517	186517
8bbb21b9-0f60-4b14-bafe-3dc33fe887f6	2026-01-07 06:44:09.352668+00	7.9	22.4	745084	745084
f123c811-fdd1-4ef1-821a-79184fb0a0cd	2026-01-07 06:44:10.249142+00	22	22.4	1009099	1009099
55e660a4-86b0-448b-91d8-e4f2f0dcf118	2026-01-07 06:44:32.370081+00	7.9	22.4	530759	530759
f86e31a7-a153-4036-bb40-eb5f4fdc5083	2026-01-07 06:44:58.5873+00	9.7	22.3	485684	485684
32218b9d-c980-4483-bb3d-dbfe6f7a48d7	2026-01-07 06:45:32.310245+00	9.8	22.4	840286	840286
c1871161-eb14-4cbc-a223-900283eb321b	2026-01-07 06:45:58.240675+00	11.8	22.3	550536	550536
5fcc9c67-c41c-488b-9c99-92f90831fc0f	2026-01-07 06:45:59.699748+00	7.3	22.4	718880	718880
37dfd538-7ada-493f-9046-63d503cc8ffe	2026-01-07 06:46:09.23332+00	15	22.4	605949	605949
0eded970-23cb-4d0e-842b-82ad7cb14017	2026-01-07 06:46:11.692751+00	18.2	22.4	628722	628722
b716202e-164b-4922-90e2-b2f08239839d	2026-01-07 06:47:00.068886+00	7.2	22.4	617109	617109
c6b430fb-d552-40db-85f7-754aa7bedfef	2026-01-07 06:47:09.640449+00	7.4	22.4	532838	532838
2d862f52-eed8-48a6-8eba-80071e73fae0	2026-01-07 06:47:58.299026+00	11	22.4	249047	249047
a283f409-5b55-4398-8c67-36e66c7eb733	2026-01-07 06:47:59.696285+00	7.1	22.4	732232	732232
4ff428d6-120f-49f3-8392-d23e9abf0c62	2026-01-07 06:48:10.382472+00	30.3	22.3	1227394	1227394
0fd4abc2-a979-4dd5-8344-6678bde0e6db	2026-01-07 06:48:32.238624+00	10.5	22.3	966072	966072
3d0fb837-be5d-4666-a5e0-4c8089882bb8	2026-01-07 06:48:58.507056+00	10.5	22.5	661283	661283
6dcbea0f-17eb-4062-a3b3-edc55380452b	2026-01-07 06:48:59.506763+00	9.8	22.3	487883	487883
6fbbe693-f4d4-43b9-87f8-2ab08193a681	2026-01-07 06:49:11.512012+00	22.4	22.5	775345	775345
fefe64f9-0ab2-4cf1-9359-ebd5939a8648	2026-01-07 06:49:58.322401+00	10.9	22.4	599428	599428
f2748db7-bfee-41aa-bbc2-15ca84aedccf	2026-01-07 06:49:59.435944+00	7.7	22.4	306395	306395
2b2760ee-3cde-4c4c-b9f0-2b3cdd6f6034	2026-01-07 06:50:11.413989+00	24.5	22.4	441994	441994
b1457ce6-adfb-4691-8184-e68d2d5f2073	2026-01-07 06:50:32.552176+00	8.8	22.4	681016	681016
751206ad-5697-494f-b5de-b84adf3712fb	2026-01-07 06:50:58.723439+00	8.6	22.4	820957	820957
a896dc7d-944c-4560-b706-31e495eb613e	2026-01-07 06:51:00.331832+00	6.8	22.4	395778	395778
2c110af9-77b8-4b8c-9122-cc262089e0b3	2026-01-07 06:51:00.412347+00	6.8	22.4	349357	349357
90374339-868d-4bc9-a55a-58ff6bf8e7b2	2026-01-07 06:51:10.807553+00	18.7	22.4	1212607	1212607
77ac0340-8344-4ef5-b365-bf9703e7cf5a	2026-01-07 06:51:12.290948+00	18.7	22.4	636221	636221
efbe274e-81e7-467e-8500-5a22a5d2b3df	2026-01-07 06:51:59.701178+00	6.9	22.4	275560	275560
f56a7d3d-5471-4b4b-a7f2-64f141e1010e	2026-01-07 06:52:09.17093+00	11.5	22.4	838777	838777
48d7fa11-8d7c-4b82-a33e-b95180c38ed4	2026-01-07 06:52:32.240588+00	9.6	22.4	697332	697332
2e798d0f-aeb0-4a41-9c32-4425af828a66	2026-01-07 06:52:59.809689+00	8.3	22.4	578587	578587
a0721437-e6fe-4e19-a8af-662aafa5b0b2	2026-01-07 06:52:59.891059+00	8.3	22.4	332435	332435
5d4a27a3-ef49-475e-9e8e-3b2d402da3bd	2026-01-07 06:53:09.490744+00	12.7	22.4	119849	119849
43987055-c21a-4793-aca4-4c7a59ed1c36	2026-01-07 06:53:10.35249+00	71.7	22.4	1139707	1139707
c50f61bd-7e0e-4b02-bd88-c7382639a16e	2026-01-07 06:53:11.744715+00	71.7	22.5	353379	353379
2580f6b1-5541-4870-ae23-d3c24dc9a42c	2026-01-07 06:53:58.488849+00	10.7	22.4	630885	630885
fbdab817-e85e-42a3-8e45-59c436266c3f	2026-01-07 06:53:59.596501+00	8.7	22.4	438898	438898
1c08857d-9a11-4b25-8f55-3e478db68b7a	2026-01-07 06:54:09.322213+00	14.9	22.4	682727	682727
e2e108b9-5faa-4126-8fc1-f27a89e4072a	2026-01-07 06:54:10.197536+00	19.3	22.5	755423	755423
c037c8db-812a-469c-ad0c-2a2ffc7b7e6e	2026-01-07 06:54:59.898116+00	6.5	22.4	562799	562799
90f589b6-cfec-4e7e-b87b-d0b7dae0c4b7	2026-01-07 06:55:09.72153+00	17.3	22.4	852694	852694
87d372b5-ea4b-479f-8ab0-5d10fad42d43	2026-01-07 06:55:32.235082+00	7.8	22.5	697137	697137
ae961ce3-bb5f-4702-87cf-bcfe4133ccb9	2026-01-07 06:55:59.732733+00	7.3	22.3	401335	401335
9dc1202d-3caf-4737-ba55-46fe37e518a9	2026-01-07 06:56:09.71588+00	6.2	22.3	718300	718300
3dec7b8f-ff19-4c65-a55f-7f4713695537	2026-01-07 06:56:09.716657+00	6.2	22.3	1937649	1937649
c1339d96-f90c-45fb-94c5-a7ede2484e1e	2026-01-07 06:56:10.67914+00	18.7	22.3	571252	571252
15980b3c-06b9-4ab2-948a-04af26a7a4af	2026-01-07 06:56:32.22287+00	12.5	22.4	890732	890732
7954f0b9-2935-46be-ac10-0eb74ceeff02	2026-01-07 06:56:58.347076+00	8.9	22.4	252646	252646
2504224f-ceb3-418c-bd54-d703958872c2	2026-01-07 06:56:59.456925+00	7.6	22.4	230785	230785
ac698a39-836c-4f06-af9f-afd01c18fea0	2026-01-07 06:57:11.266078+00	29.5	22.4	687496	687496
99f31c07-0621-4d16-b3bd-8170b581f607	2026-01-07 06:57:58.283443+00	11.1	22.4	687309	687309
ca6ec598-45f5-4ea7-9852-7fe38014e960	2026-01-07 06:57:59.639629+00	7.6	22.3	292199	292199
9e9e3d1c-603d-4ffe-bd9b-52b5016cadc8	2026-01-07 06:58:09.28578+00	8.3	22.4	404045	404045
dfd60997-0f36-441e-8597-7c22db7026ea	2026-01-07 06:58:10.167417+00	29.9	22.4	1013077	1013077
696ed009-c6f0-40d3-a106-47a42f0e01a8	2026-01-07 06:58:32.290603+00	9.7	22.1	682180	682180
3976380c-d6d1-4f73-ba2a-18611dcdca68	2026-01-07 06:32:09.48045+00	17.2	22.4	467630	467630
03499d4b-a997-4feb-8422-14785b78ff50	2026-01-07 06:32:11.777835+00	16.6	22.3	571990	571990
c81eb3b1-6093-458f-a366-7961585c7c00	2026-01-07 06:32:53.244312+00	13	22.4	61166	10132
995198db-1076-4583-b8f9-46387b7afe48	2026-01-07 06:32:58.455595+00	8.5	22.3	326304	326304
5523a58f-8361-4699-816b-36b0e0e103e0	2026-01-07 06:33:32.179487+00	15.2	22.4	1007238	1007238
72ad1302-209e-43f8-8608-eaa7e7deff1a	2026-01-07 06:33:53.221367+00	13.5	22.4	61658	10440
b8b11e12-29be-4dfb-b9f1-92c558e53085	2026-01-07 06:33:59.692242+00	8.6	22.4	410692	410692
f697b5f3-d478-4494-9c30-3582fcf64f75	2026-01-07 06:33:59.779948+00	8.6	22.4	442594	442594
947932d4-3252-4c04-bcf8-4910acbecc46	2026-01-07 06:34:09.243846+00	21.5	22.3	453112	453112
a0f051e2-4946-4f7f-9506-3c65abc2eed0	2026-01-07 06:34:32.262851+00	23.8	22.4	792067	792067
314b92de-259d-4ec7-bacd-57355437be7b	2026-01-07 06:34:53.265219+00	14	22.5	55095	8606
7845644b-2e7b-4203-a5dd-c68454b32ac9	2026-01-07 06:34:59.523196+00	8.7	22.4	485923	485923
3138392a-4314-4992-80ab-98d39eff938e	2026-01-07 06:34:59.592361+00	8.7	22.4	454210	454210
cb091fbf-38fe-48ab-936a-7d088f1d9268	2026-01-07 06:35:10.152853+00	13.3	22.4	856737	856737
dbf49d71-f075-4fba-824b-1bfa40ed128e	2026-01-07 06:35:11.610301+00	18.5	22.5	588527	588527
670607e9-2624-46f6-95fe-90911def2eb0	2026-01-07 06:35:53.266192+00	12.3	22.3	55696	8996
4ef8c170-fe4d-479f-b0ec-eddeae191d23	2026-01-07 06:35:59.943462+00	5.8	22.3	173291	173291
6f905563-1ad7-44a3-b908-6a54d6bbd920	2026-01-07 06:36:09.756067+00	7.3	22.4	397634	397634
f8e13485-92c6-4da8-b63b-72b001bcada8	2026-01-07 06:36:10.648453+00	19.3	22.5	952843	952843
95ca699d-3773-4fd3-a495-bff402d1053e	2026-01-07 06:36:53.28321+00	10.4	22.5	54606	9105
18b324e0-1e3c-4b67-b9aa-27416c1df4fc	2026-01-07 06:36:58.394154+00	22.3	22.4	573144	573144
0d13402d-e1cc-4480-921c-b67eb7364a34	2026-01-07 06:36:59.526188+00	7.7	22.4	235819	235819
631376b7-6d28-477d-8593-7aec32ffd17c	2026-01-07 06:36:59.65739+00	7.7	22.4	560452	560452
e4778beb-a77c-48b9-9215-a51bb700cdfd	2026-01-07 06:37:09.063972+00	17	22.4	377665	377665
1e18c0ff-9238-441d-be80-7d4d6b4fcaa5	2026-01-07 06:37:09.926527+00	17	22.4	803283	803283
6d9e5c2d-d336-4e78-91d7-3803052852c3	2026-01-07 06:37:32.248666+00	7.4	22.4	919092	919092
0c56a603-29ff-4b5f-8f4b-e663724a81be	2026-01-07 06:37:53.255857+00	18.3	22.5	60737	9550
a3c2adac-c816-4553-bc82-e9ae25795f3c	2026-01-07 06:37:58.376118+00	9.1	22.4	721366	721366
64532d85-0ed8-4730-93ac-164559eaa569	2026-01-07 06:37:59.522343+00	8.3	22.4	282948	282948
be682e24-793e-46ff-a5b0-08feec8a4d83	2026-01-07 06:38:09.068531+00	8.7	22.4	954060	954060
63c3cbec-183c-45ad-af17-24daaf44ef98	2026-01-07 06:38:53.279613+00	17.8	22.4	59992	10893
35a6dadd-1c9c-4c6a-b106-7782c2cd7d47	2026-01-07 06:38:58.577904+00	9.4	22.4	752578	752578
ebc00937-9f76-4d11-b8a3-dbe71c65ead0	2026-01-07 06:38:59.74792+00	8.9	22.5	513013	513013
baf7b88c-8dba-4a52-b5db-68175692d23d	2026-01-07 06:39:09.223689+00	13.7	22.4	755214	755214
0537fbce-c18d-4923-a553-7852ca3f1114	2026-01-07 06:39:32.225056+00	20.2	22.4	850980	850980
ce9e72f1-6f86-402d-9d67-adfa32b21f31	2026-01-07 06:39:53.308058+00	13.7	22.4	54949	8869
263f38d3-1022-4741-bcc7-689d6db35e5b	2026-01-07 06:39:58.595281+00	8.8	22.4	585937	585937
c82e7ee9-64da-4449-80e4-c8dbe48fbf6e	2026-01-07 06:39:59.724974+00	7.5	22.4	360894	360894
813114f4-ca29-4746-a9c1-67229b5d20c9	2026-01-07 06:39:59.785354+00	7.5	22.4	147133	147133
d8cd4dc6-0c76-4811-b9ce-59b11edf2c39	2026-01-07 06:39:59.896394+00	7.5	22.4	448896	448896
8948dd59-97ee-45c5-8a22-371883ab283c	2026-01-07 06:40:09.298268+00	17.3	22.4	846731	846731
9e6c87ca-559b-4f61-a036-420b60362422	2026-01-07 06:40:11.589225+00	20.7	22.3	759229	759229
fe170c34-f95d-4a26-ad2d-713c746ef39f	2026-01-07 06:40:32.226527+00	22.8	22.3	738567	738567
798243e0-843c-4b2a-be98-a309cb9875cd	2026-01-07 06:40:53.306473+00	12.7	22.3	57715	9977
b7f2415b-c474-4883-b058-8d6e5541b8c1	2026-01-07 06:40:59.556783+00	7.7	22.3	617829	617829
7771135d-d694-4d98-88f6-32d0f0d8ac80	2026-01-07 06:40:59.556783+00	7.7	22.3	301393	301393
1c06cbcd-bbfb-455c-a390-5f209ac2a236	2026-01-07 06:41:09.214992+00	21.5	22.4	605220	605220
88a7d8e4-514c-4ac6-ba41-cd4fdde80c70	2026-01-07 06:41:10.001754+00	21.5	22.4	935527	935527
73c836b8-0222-456a-8eb9-b7284139b80a	2026-01-07 06:41:11.47232+00	20.5	22.3	563450	563450
84c5f533-cb97-4ecc-998c-b247bea52939	2026-01-07 06:41:32.203631+00	7.6	22.4	932090	932090
72c99831-c781-41da-bd1d-454a9407458c	2026-01-07 06:41:53.298627+00	19.3	22.3	64997	11655
cb9c8603-90b6-483b-935a-2ccbc33bcfc2	2026-01-07 06:41:59.517963+00	7.6	22.3	315534	315534
25c31ae9-a1a8-4946-b784-0f64866ff0c1	2026-01-07 06:42:09.042156+00	16.2	22.3	715076	715076
1d648940-062a-4c23-ada8-f3ea8053f4eb	2026-01-07 06:42:11.36686+00	73	22.3	540954	540954
46a71e77-06ee-43d2-8ac6-abfee19168fd	2026-01-07 06:42:53.34906+00	18.4	22.4	63975	10799
12ea5aeb-bdde-4d44-9e89-f501a0dd3c9c	2026-01-07 06:42:58.834893+00	9.8	22.4	244421	244421
25a34458-a276-4cfa-974b-5b34c45dc17f	2026-01-07 06:42:58.842143+00	9.8	22.4	682284	682284
0ea94d7b-6a08-4cbd-b53a-a74bada106a8	2026-01-07 06:43:00.194325+00	8.7	22.4	567145	567145
214d7fe0-247e-49b5-b6ba-54aaa2ba0b6a	2026-01-07 06:43:00.210769+00	8.7	22.4	302098	302098
d4f8cef4-3fd6-475b-951d-d1dda7c0ca43	2026-01-07 06:43:00.333838+00	8.7	22.4	1734529	1734529
6c30aeda-fcc0-46c3-bdb7-513125f8eabf	2026-01-07 06:43:12.153997+00	16.4	22.4	736298	736298
4c52d661-8258-47fd-bf74-d7ade5b344da	2026-01-07 06:43:32.263699+00	9.5	22.1	1302011	1302011
4801f08f-1814-4a2f-bd7f-2903bf04c4d0	2026-01-07 06:43:53.365978+00	13.3	22.2	67000	11097
921d6e3c-4b2b-4e60-a329-57e1ad922b5e	2026-01-07 06:43:58.670712+00	12.2	22.2	867226	867226
7652c12d-d99b-42c6-8467-631c41ba6fdc	2026-01-07 06:43:59.76813+00	9	22.3	508489	508489
e48ad1fc-4ed3-4425-a380-99ddd5541a93	2026-01-07 06:43:59.84182+00	9	22.3	577788	577788
233dcf9c-f850-440d-a6d7-f7464a60fc33	2026-01-07 06:44:09.367051+00	7.9	22.4	778812	778812
5fceb3a2-3985-4c4c-a0da-a16238de0bd8	2026-01-07 06:44:11.774059+00	22	22.3	312908	312908
5bdb0f22-f328-42fa-b2e6-0850c0da9ff5	2026-01-07 06:44:53.355183+00	12.4	22.3	56516	9390
10933070-e11a-4e48-8778-c8234a3e8a64	2026-01-07 06:44:58.622613+00	9.7	22.3	692201	692201
efb66168-7f7f-417b-839a-d4277429524e	2026-01-07 06:44:59.692559+00	8.7	22.2	265097	265097
3084260b-7474-40da-a252-001530d50fdc	2026-01-07 06:44:59.732015+00	8.7	22.2	463835	463835
4235d82f-a0b7-48b8-a329-de853026f322	2026-01-07 06:45:09.156408+00	21.1	22.4	598157	598157
5d9c4972-0331-4904-8f4d-be979bd6068a	2026-01-07 06:45:09.156407+00	21.1	22.4	533926	533926
ab5ea1ea-5203-4e80-bd2d-668833b7ac2e	2026-01-07 06:45:09.982886+00	21.1	22.4	927390	927390
e2ba268f-9bb2-4259-a956-524cf7e0182e	2026-01-07 06:45:53.365253+00	13.8	22.3	59021	9861
40c0ec97-6737-4ce3-9343-ce33a65ac475	2026-01-07 06:45:59.617079+00	7.3	22.4	684661	684661
277e8246-2287-46b2-83e7-6886ba3dc2dd	2026-01-07 06:46:10.06592+00	15	22.4	797908	797908
5586b5ef-f444-4411-bfa0-dbff4276b5aa	2026-01-07 06:46:53.370056+00	12.4	22.4	54481	9083
71c934c9-91d6-48a2-bb55-029740bd3c99	2026-01-07 06:46:58.588699+00	8	22.4	447236	447236
a42d0324-57d3-4c5f-8a2d-cf10835786cc	2026-01-07 06:46:58.595158+00	8	22.4	510591	510591
9f27e7ee-71ee-4176-995e-4eab6b88126b	2026-01-07 06:46:59.969683+00	7.2	22.4	342290	342290
3515a656-eff0-444a-abf5-87a89a1ee626	2026-01-07 06:46:59.97447+00	7.2	22.4	503190	503190
ce17835a-9588-42e1-91c8-02e08471b9b8	2026-01-07 06:47:09.644536+00	7.4	22.4	517745	517745
8482350c-ec12-4da2-b68f-769f3732dc79	2026-01-07 06:47:10.498038+00	24.2	22.4	1026103	1026103
bae4d1cd-0497-4971-bc17-97b6ef471ec8	2026-01-07 06:47:11.97479+00	24.2	22.4	872690	872690
ef8816a7-e97e-4198-b043-4636c9c6c052	2026-01-07 06:47:32.204226+00	8.2	22.4	700819	700819
98eca646-cda9-4848-af4a-d54834909ecf	2026-01-07 06:47:53.349592+00	18	22.3	61102	10237
c80f7fbe-d623-4544-b69b-57dfe0e57aeb	2026-01-07 06:47:59.784784+00	7.1	22.4	414750	414750
7e34526d-2754-4afe-b620-871f382b7bad	2026-01-07 06:48:09.491119+00	14.9	22.4	800847	800847
6bd85ae5-9b04-4e4f-8673-f16b336f1e4c	2026-01-07 06:48:53.390979+00	13.1	22.3	64544	10639
54819499-b7f1-49e0-9f69-247280d48bb7	2026-01-07 06:48:59.49038+00	9.8	22.3	283103	283103
767312b9-18b3-48ae-877e-88ab67fac195	2026-01-07 06:48:59.626364+00	9.8	22.3	600429	600429
3bd41639-93db-4e22-89d3-45d8267c61ac	2026-01-07 06:49:09.1748+00	18.2	22.3	830222	830222
770abe17-56b0-4eca-ba04-20669ddb55ae	2026-01-07 06:49:10.07375+00	18.2	22.3	1026748	1026748
ecaf3874-d219-46e6-bcc1-59d5dfad0334	2026-01-07 06:49:53.372933+00	12.2	22.3	65374	10518
f0a38505-8b4b-41f5-aafc-bf16dc14a483	2026-01-07 06:49:58.298439+00	10.9	22.4	767241	767241
03505e10-1518-4cf8-a1cb-89fb29ede31c	2026-01-07 06:49:59.434003+00	7.7	22.4	293657	293657
28a3c40f-4278-4a42-9ca6-b79588e5e8fd	2026-01-07 06:50:09.141321+00	7.7	22.4	286797	286797
abbc276d-10f2-4e66-b1a4-63e59581b3a9	2026-01-07 06:51:10.031054+00	8.4	22.4	771548	771548
b54a816e-f654-445f-96b9-26e9ae2e2a82	2026-01-07 06:51:59.719298+00	6.9	22.4	337988	337988
c8db67b1-07d1-4447-80a5-e5c46385260b	2026-01-07 06:52:58.731699+00	10.3	22.4	599714	599714
f0de70c9-d9e8-4e7f-a499-f4d68c51b805	2026-01-07 06:53:59.604274+00	8.7	22.4	224088	224088
59599fe9-eb58-42a9-836a-9bc6e99ab7b2	2026-01-07 06:54:58.362052+00	10.1	22.4	542104	542104
25721a5d-c4df-4ee4-bd6e-7e3be57c51fb	2026-01-07 06:55:58.440666+00	11.4	22.4	229501	229501
987b9fd2-6963-4de1-8d2b-33892de1afa0	2026-01-07 06:55:59.858183+00	7.3	22.3	769882	769882
503f1be6-16a3-4aa9-8658-4950d4eb15a2	2026-01-07 06:56:59.457109+00	7.6	22.4	450918	450918
ceedd388-8ec3-47b0-a320-51a188b5880a	2026-01-07 06:57:09.852763+00	6.9	22.4	956758	956758
bee79301-e4a5-4005-b68a-97670f49ce0b	2026-01-07 06:57:32.268423+00	10.3	22.4	522806	522806
d4ea0f80-0141-493c-b5b2-02c9bfa76946	2026-01-07 06:58:59.814085+00	7.9	22.2	213444	213444
4cd42049-779b-4aba-a23b-a8d40de237fa	2026-01-07 06:59:11.776674+00	18.6	22.4	691382	691382
7a2a25fa-9a93-4e24-b555-4a993f8528fb	2026-01-07 07:00:09.072983+00	16.8	22.3	780034	780034
7a75302e-20c6-4df7-a6b5-80cdbcafb267	2026-01-07 07:00:59.703421+00	5.9	22.4	534291	534291
1d5e385c-56fd-4c6c-b33c-48e7615e02b8	2026-01-07 07:01:09.414238+00	22.2	22.4	510644	510644
f394f33f-a340-4575-988e-e3adcbe05070	2026-01-07 07:02:09.605631+00	18.4	22.4	574598	574598
d408332b-0aa1-4149-8c29-af287c473218	2026-01-07 08:12:54.17492+00	7.2	22.1	14522	8019
2e079455-eb7d-4766-974f-bfc69920b363	2026-01-07 08:47:54.492703+00	6	28.6	1928	979
dadc2e1b-80a7-493a-b253-9159fb46e4fa	2026-01-07 09:35:57.014515+00	27.3	30	4515	31828
f0e40d24-3231-436b-ad37-2f66300d2a9e	2026-01-07 09:56:52.082297+00	4.6	24.5	84076	84076
63da6a64-0f8d-4d0f-8d56-399147cb6b51	2026-01-07 10:16:51.998482+00	22.8	30.6	70515	70515
2fb39b3c-784f-4969-b48b-03c86ce4dcc7	2026-01-07 10:17:52.06908+00	11.1	30.7	74161	74161
4615d575-7eef-41e3-a729-800d1ad36705	2026-01-07 10:37:52.075901+00	5.2	26.5	131047	131047
b2baeaaa-9172-4e4c-906f-04a07dcd92a3	2026-01-07 10:54:52.124001+00	12.4	26.5	0	0
08321da6-b33a-4f7a-a8d6-76a353de05a7	2026-01-07 11:11:52.133217+00	28.5	33.4	141161	141161
ad24a2f8-766b-4909-99fe-93197e45c84b	2026-01-07 11:12:00.583957+00	17.1	33.5	88204	88204
8717768f-e1b4-4e70-b034-f3e4a0f40acd	2026-01-07 11:31:13.699133+00	11.6	27.5	7054	4511
516237b3-850f-433a-9908-794e7c8a7058	2026-01-07 12:27:52.330553+00	82.3	25.7	229623	229623
d148b1bc-b94d-4a68-8eb6-981bf3c80003	2026-01-07 15:04:51.936785+00	40.7	31.1	194147	194147
741f73ad-1b74-4b65-95f1-efa85bed1c45	2026-01-07 15:05:32.311152+00	39.1	31.7	2990128	2990128
edb806e2-02c9-4102-b6f2-e86c02cc17ad	2026-01-07 15:05:56.736162+00	38.9	31.6	3244558	3244558
dd61f81a-6c6e-49d5-8060-e03c195f4623	2026-01-07 15:07:15.415462+00	42.5	31.7	957057	957057
4bf17a61-83d7-42ff-b8d1-ab7a2292d7db	2026-01-07 15:08:15.423653+00	9.4	31.8	772949	772949
35fa5ede-b8ac-46ad-88be-48c397cb5af1	2026-01-07 06:49:59.540973+00	7.7	22.4	637412	637412
b1826a58-ee68-46c5-be9e-4f4c19edecdf	2026-01-07 06:51:10.089707+00	8.4	22.4	740247	740247
e48ee4e9-c529-4173-8804-52a145be8cd1	2026-01-07 06:51:32.37915+00	23.5	22.4	899780	899780
bc7ea6be-decf-4c0a-98db-f92be9661b2e	2026-01-07 06:51:59.782472+00	6.9	22.4	660969	660969
a7fbce31-ffa9-407d-8aa9-e8c1a046a70d	2026-01-07 06:52:11.499035+00	18	22.3	580612	580612
dc9ea43c-7e85-4e39-b466-593a158ce8ec	2026-01-07 06:53:00.008548+00	8.3	22.4	484122	484122
eaf20dc0-444b-49d5-a6a1-0bedf36abe15	2026-01-07 06:53:32.290706+00	8.2	22.5	961824	961824
373c7bb5-f569-46f1-8d65-128f4cecc864	2026-01-07 06:53:59.70487+00	8.7	22.4	586474	586474
0d0acf99-bc43-4571-b045-6f0e4efb2dcb	2026-01-07 06:54:11.666861+00	19.3	22.5	759824	759824
4098a5cc-571e-4901-8d1a-8611d8828ff7	2026-01-07 06:54:59.816919+00	6.5	22.4	521025	521025
d47c232f-be41-4183-a1f2-1db5b391dd6f	2026-01-07 06:55:11.918073+00	15.9	22.4	601819	601819
e8fe7daf-a71e-413f-859e-b55959f19cef	2026-01-07 06:56:59.533747+00	7.6	22.4	324411	324411
35793d28-8e3e-4118-a4dc-bc72e4a0691f	2026-01-07 06:57:09.073489+00	6.9	22.4	972867	972867
f7db85a9-5ab8-446b-95d7-f567b0f5110f	2026-01-07 06:57:59.716878+00	7.6	22.3	418769	418769
162b2a3c-56a2-4ac3-8ce0-df5c3a46953b	2026-01-07 06:58:09.288315+00	8.3	22.4	762042	762042
ca5b4e1a-8e25-4131-8571-04c199aa852b	2026-01-07 06:58:11.596047+00	29.9	22.5	598039	598039
5d9deda8-4c31-4862-a880-44f245e32d20	2026-01-07 06:59:58.484897+00	11.2	22.4	852755	852755
8a89454d-93b7-4523-a1ae-062070a43b6e	2026-01-07 06:59:59.603688+00	7.3	22.3	548562	548562
724bb212-7934-42ba-a272-cfcebb19bce6	2026-01-07 07:00:58.368142+00	9.5	22.3	771836	771836
3ef69a13-da1d-48ae-835a-7a3eaf0bf4e6	2026-01-07 07:01:11.658891+00	23.8	22.4	633806	633806
688df031-82eb-4a6b-9251-954fdc4491ba	2026-01-07 07:02:00.118654+00	9.1	22.3	948955	948955
fa2bd105-80d7-4a1c-9196-3746f7d22e88	2026-01-07 07:02:09.608192+00	18.4	22.4	693577	693577
8e556d37-ac45-4681-8a4f-0c80e4931b89	2026-01-07 07:02:10.494134+00	32.4	22.4	1403547	1403547
b5f8f195-7bd3-4342-adfa-aa787c14cc70	2026-01-07 07:02:59.906138+00	8.8	22.5	472296	472296
439484db-ca1e-442c-b329-ce4c0c866e4c	2026-01-07 07:03:59.587536+00	8.2	22.3	277944	277944
c981b36f-eeb7-40e8-a1cb-6982d6dbda5d	2026-01-07 07:04:58.522326+00	9.4	22.4	374745	374745
77faa009-aa9d-4b9e-9f61-be78b2ac54d7	2026-01-07 07:05:09.205879+00	11.7	22.4	619651	619651
4ceb23bd-16c2-466a-a46c-e424db38cd4b	2026-01-07 08:13:03.73339+00	6.8	22.2	371182	371182
e76a0d65-1f52-4615-80da-7061173761a8	2026-01-07 08:18:03.716065+00	7.4	22.2	494791	494791
80625c12-4f15-4471-aa5f-48a24b48d709	2026-01-07 08:24:03.720974+00	5.6	22.1	377051	377051
15e244bc-a341-4c34-a45e-9eefa7f8ade6	2026-01-07 08:48:54.505989+00	8.8	28.6	7285	38473
3f41c69f-8317-4507-98f1-c6be68ed9594	2026-01-07 09:36:57.038451+00	50.8	36.2	4997	28070
426e65fc-4cbd-4337-815a-df3a582b449f	2026-01-07 09:57:12.447588+00	4.6	24.5	2841	1924
926e9e6b-dc93-4da5-b8c8-b448223183ee	2026-01-07 10:17:12.744097+00	14.9	30.5	684158	94848
3b7c6364-7355-47fc-bc80-72f74d8b9c31	2026-01-07 10:37:52.075906+00	5.2	26.5	0	0
68331124-0f48-4e6d-8bbc-28b6c078fbfa	2026-01-07 10:55:13.237402+00	5	26.5	6326	4496
b4c4a2de-1e36-4c09-8a15-6e70c19d8ce2	2026-01-07 11:12:13.400414+00	30.9	33.5	9408	8394
97484595-fb33-4943-8598-d8eb87eb519c	2026-01-07 11:31:52.045112+00	13.6	27.6	173811	173811
a352506e-b2bf-4675-ab03-0d6d3deaf121	2026-01-07 12:28:52.330288+00	83.7	25.3	358873	358873
1854e151-41f6-423c-a2ea-49009773e197	2026-01-07 15:08:51.889812+00	11.4	31.8	203167	203167
dfed275b-1434-4bba-a738-d3cf6e1f8390	2026-01-07 15:10:15.422176+00	11.3	26.3	712039	712039
18634736-bc91-4b4c-ba35-d9d6c1d48510	2026-01-07 15:11:15.462036+00	29.4	30.7	1239932	1239932
65d8585e-15d2-4d5c-82c6-60bc09e0f5f2	2026-01-07 15:11:32.29681+00	44.7	32	1130311	1130311
8b39c529-d569-4902-ae9d-1b40d8abab09	2026-01-07 15:11:51.93566+00	34.5	31.8	3525471	3525471
b55537c9-94ce-4a90-858b-d55d6beb4b62	2026-01-07 15:12:15.388361+00	32.4	31.7	1516086	1516086
963dce5a-7770-47af-ba63-c1fd07c74870	2026-01-07 15:12:17.63205+00	32.8	31.8	2499342	2499342
3d4ab621-2c88-4076-83c3-38f01f2b2fd3	2026-01-07 15:12:32.395573+00	36.6	31.8	3303449	3303449
844db133-3850-4935-9b9f-776221a7bbfd	2026-01-07 15:13:39.343185+00	36.2	31.7	5009510	5009510
2a36d06d-10fd-45e0-a0ce-d26747048960	2026-01-07 15:13:51.895268+00	38.2	32	4640710	4640710
5f53e1c4-0dc4-4f7a-a054-553a40e86fa0	2026-01-07 15:14:17.619933+00	39.8	32	5357478	5357478
1a892b39-ca46-4ebf-805f-f9a80525fb88	2026-01-07 15:14:32.302292+00	37.1	32.1	5982979	5982979
9bcc1d5a-2ff1-4573-b95c-545f7e00889f	2026-01-07 15:14:51.909871+00	29.7	31.9	2060783	2060783
09508fbe-855e-4b5b-b239-252ce80f4706	2026-01-07 15:15:32.31982+00	32.3	32.1	1183759	1183759
821e91b7-8555-4ffa-a273-455390e4bc56	2026-01-07 15:15:51.940486+00	33.5	31.8	4274361	4274361
df932f43-cdc4-441d-ba9b-130eac9f1131	2026-01-07 15:17:17.618697+00	32.3	31.6	4236887	4236887
7fe210f7-caed-4242-8b93-382691cb049c	2026-01-07 15:17:32.398284+00	31.2	31.7	1768770	1768770
05a6b4f0-8b48-4860-882c-5d34bd726fbb	2026-01-07 15:17:51.89902+00	33.3	31.7	6272463	6272463
872d75b9-cf7d-48b3-bdfb-035a929ca3a7	2026-01-07 15:20:17.648504+00	33.3	32.5	2825550	2825550
d6737ed1-c6b1-4916-92d0-cf537359bac7	2026-01-07 15:20:32.306329+00	33.2	32.6	4125429	4125429
ec0182b4-2a60-43f8-8d91-d062002398f1	2026-01-07 15:20:51.948085+00	32.1	33.2	82644	82644
81b522ee-1c74-4695-9197-0f8976490a88	2026-01-07 15:21:32.310664+00	35.2	33.1	1801340	1801340
8c78b48d-ac72-4127-91ae-8ae31a0dae8f	2026-01-07 15:21:51.938768+00	31.7	33	2614488	2614488
b652d69c-1075-4a6a-82d4-1d58c955a973	2026-01-07 15:22:17.630186+00	32.8	33.1	3163211	3163211
a88f30ce-dd77-4543-a4b9-3365e8127af3	2026-01-07 15:22:32.368766+00	31.2	33	2600854	2600854
eecc2511-b682-4f11-ae37-27970cad6f9c	2026-01-07 15:23:17.621847+00	32.8	33	1106964	1106964
98a3e7bc-a853-4e00-8e65-321611b9e03e	2026-01-07 15:23:32.344179+00	32	33.1	4104276	4104276
5166c45b-b8f6-4573-8aad-a0cc4e125bc3	2026-01-07 15:23:51.921806+00	35.2	32.8	1196840	1196840
53578986-5f13-480c-a458-69d5e22e7675	2026-01-07 15:24:51.913678+00	31.5	32.8	2605972	2605972
7086fd00-17e1-4d87-adc9-8886680422cd	2026-01-07 15:25:17.630028+00	33.1	32.3	3621630	3621630
e38a232e-25c1-4f96-89bc-d8d76e7ecd4f	2026-01-07 15:25:32.341973+00	34.3	32.2	5128543	5128543
ad29b5cb-85aa-41b3-8231-bec93abbc16c	2026-01-07 15:26:51.93004+00	33.2	31.5	5995719	5995719
e49fa797-29d7-4315-b091-864ae97143a2	2026-01-07 15:29:17.6545+00	31.7	31.9	2659229	2659229
9501251e-211e-4213-991f-8c58ecfe1ac9	2026-01-07 15:29:32.296734+00	33.8	31.9	979890	979890
9e9eb158-7dd3-4d8b-a67c-dcdc40763c9a	2026-01-07 15:29:51.891364+00	31.9	32	7192977	7192977
bdba2c43-670a-472b-9202-1750671a24df	2026-01-07 15:30:17.62594+00	33.7	32.3	5805175	5805175
692be8a3-369e-4b00-a344-060b57658e09	2026-01-07 15:30:32.391142+00	33.3	32.2	1170155	1170155
dcd26840-d9e6-484c-9e76-f3ea624dedbd	2026-01-07 15:30:51.902519+00	30.7	32.3	291198	291198
f2b4ff60-0fb2-404d-8af3-561826e6656f	2026-01-07 15:31:17.647407+00	30.3	32.3	3574468	3574468
8b33c9e9-7398-4a7c-a837-a29068e565ee	2026-01-07 15:31:32.378557+00	30.9	32.2	1981634	1981634
12fa9e79-b78f-4f8e-9751-5488e46c63e4	2026-01-07 15:31:51.899835+00	29.8	32.2	354459	354459
a1ba503e-7b71-4b22-9677-457f5e0f9346	2026-01-07 15:32:17.629434+00	33.7	32.2	3782180	3782180
59883557-acc6-4cd2-8e83-3bfdb62f4a9d	2026-01-07 15:32:32.299169+00	35.4	32.2	530332	530332
ddb2a6ae-8cb7-4ce4-874e-b975b418123f	2026-01-07 15:33:17.61914+00	33.2	32.2	4222495	4222495
5b97ed26-3777-4ecc-8b58-d85c7f91d2c6	2026-01-07 15:33:32.311746+00	32.2	32.5	553520	553520
a6b1b2b0-117b-4a88-80ca-6cc0228be3d9	2026-01-07 15:34:17.653266+00	34.1	33	1192892	1192892
68ba1400-e715-4ed1-8e11-c63102bd53f4	2026-01-07 15:34:32.306071+00	29.9	33	5436937	5436937
15e037bf-0b1b-46cf-b20f-9f164e69e107	2026-01-07 15:34:51.906335+00	33.2	33	6569691	6569691
4ea10a77-f8b6-4805-8363-4df5184f01a1	2026-01-07 15:35:17.634462+00	33.5	33	797888	797888
c0c94fb3-a34c-4b27-afdf-3cfc090100be	2026-01-07 15:35:32.404274+00	28.9	33	2344669	2344669
4afa6f91-2453-42bd-b132-0b77be5c3020	2026-01-07 15:36:17.619554+00	40.3	33	1081580	1081580
ac13d82b-e83e-493c-85be-d942fe29dcf8	2026-01-07 15:36:32.281142+00	32.1	32.5	661966	661966
a656627b-256a-49e4-9045-a71a3509ddff	2026-01-07 15:36:51.862908+00	31	31.1	424225	424225
eeccf8d4-6af7-46cb-a79f-c539ae4b9f6b	2026-01-07 15:37:09.307149+00	31.3	30.8	1134112	1134112
66981935-b0e9-4998-bfa4-3fc803854e4f	2026-01-07 15:37:17.622238+00	30.5	31.9	685668	685668
486f4fd2-ec4e-49d9-9cc8-4f7b46388ac5	2026-01-07 15:38:17.622554+00	28.8	31.9	638439	638439
2db34bf2-7d89-44a4-be48-9c6c00062aca	2026-01-07 06:50:09.116047+00	7.7	22.4	838562	838562
c436359c-6c19-40f4-a598-6d3fffd4f0b8	2026-01-07 06:50:53.411365+00	10.8	22.4	61158	10023
a8d93f40-7572-4a4f-8580-0d97a0d468a9	2026-01-07 06:50:58.717221+00	8.6	22.4	630380	630380
33a4a707-8ee5-41bd-b1e1-4e453a582f0c	2026-01-07 06:51:00.511775+00	6.8	22.4	417255	417255
bd0fc694-5db4-4ec7-b744-88c52e119c0d	2026-01-07 06:51:53.38718+00	11.9	22.3	56697	9852
59a3ad33-9ef9-4707-a507-11b81abac918	2026-01-07 06:51:58.474868+00	9.4	22.4	466057	466057
f986651e-a6c0-42b3-814f-b7c8e2f0549b	2026-01-07 06:52:10.071714+00	11.5	22.4	728771	728771
42e45556-955a-41ed-986b-6c19932e2bf5	2026-01-07 06:52:53.400463+00	13.2	22.4	55266	9530
b2222428-65f4-4d24-89e8-f76d6e49d94c	2026-01-07 06:52:58.7312+00	10.3	22.4	382008	382008
c760c61c-04fa-4e1b-8103-790e750cc8c6	2026-01-07 06:53:09.487894+00	12.7	22.4	592584	592584
19e4e049-05d7-41ab-8ea0-095eaf44b325	2026-01-07 06:53:53.417572+00	19	22.4	56172	10491
df2f6403-df41-467d-857e-4dc286b5d39d	2026-01-07 06:54:09.316086+00	14.9	22.4	671835	671835
96a93d4f-cbb9-493b-a816-15fb10af8ef5	2026-01-07 06:54:32.355176+00	7.3	22.3	892616	892616
b50ac44d-813d-4587-af9d-3905805d0995	2026-01-07 06:54:53.467015+00	13.4	22.4	68148	13492
179cef31-a468-4348-b521-b2525138cebe	2026-01-07 06:54:59.814987+00	6.5	22.4	339961	339961
a9881d7c-5aaa-4e76-bdf5-16f5222750d6	2026-01-07 06:55:09.722225+00	17.3	22.4	568180	568180
15a022bf-cdcb-4ab2-b270-c9b55e1de6cc	2026-01-07 06:55:10.572032+00	15.9	22.4	1015747	1015747
da956449-53d0-42b5-ba14-454f2e32e29d	2026-01-07 06:55:53.430226+00	16.7	22.3	63735	11230
9baab131-543c-4c0e-868e-e0aace825f79	2026-01-07 06:56:53.497995+00	20	22.4	72150	23277
61614615-1290-4fbd-a6ec-a24f67e9f750	2026-01-07 06:56:58.273132+00	8.9	22.4	374625	374625
e0462903-9b93-4195-a637-3bac9f90892e	2026-01-07 06:57:53.451974+00	18.4	22.4	388354	130664
daf5b410-1553-498e-b095-ae253c192943	2026-01-07 06:58:53.484145+00	19.5	22.2	0	0
654e5c5a-f7da-4b37-a380-0a0a167d7c9e	2026-01-07 06:58:59.818341+00	7.9	22.2	354542	354542
90c1de45-c105-4d17-bef8-34cb1fa61d96	2026-01-07 06:59:09.486617+00	8.1	22.4	86082	86082
c4e1a351-d468-4d16-956c-f0d542bf511f	2026-01-07 06:59:10.337868+00	8.1	22.4	1193067	1193067
275a18a9-2f1e-487f-b1de-06a4701bab4f	2026-01-07 06:59:32.294183+00	8.2	22.4	758960	758960
39227875-fc3a-42b2-bbd2-88a0e714295c	2026-01-07 06:59:59.506432+00	7.3	22.3	373065	373065
70eee6bb-a1de-49a1-9178-e85d1f4fb288	2026-01-07 07:00:09.075357+00	16.8	22.3	555442	555442
594be052-5c73-4394-b348-ecdab7573dc4	2026-01-07 07:00:59.705656+00	5.9	22.4	333629	333629
94191a74-6886-4178-97f7-67d73b9030a6	2026-01-07 07:01:09.437711+00	22.2	22.4	706213	706213
8534e9cc-3a75-4a36-abee-c1fb946b6ecc	2026-01-07 07:01:58.655908+00	11.2	22.3	366842	366842
0bf015e3-45c3-40ac-8c0b-0b96305252f7	2026-01-07 07:02:59.748528+00	8.8	22.5	357026	357026
6c9f6695-7373-46b9-824f-03eb306bf8f6	2026-01-07 07:03:09.339931+00	15	22.4	723043	723043
e3f313bc-93c8-48f9-896c-42f04be87057	2026-01-07 07:03:10.24455+00	15	22.4	613267	613267
e1bc7c1c-798a-4311-aa1d-adc1cb0dbe54	2026-01-07 07:03:58.599917+00	11.5	22.5	579978	579978
ce3e62fa-e9b8-4c59-832e-b3da105dd919	2026-01-07 07:03:59.679068+00	8.2	22.3	624021	624021
e9dc5ac8-af11-4e91-acdf-d50f21cca6a4	2026-01-07 08:13:54.221236+00	6.4	22.3	13838	8202
aa7b8477-3185-4b97-af29-01a685884fd5	2026-01-07 08:49:54.522248+00	10.2	29.1	3877	4960
56056869-4533-430f-b4d4-6da5580be7e3	2026-01-07 09:37:11.975658+00	24	30.2	10623	180305
5f8061e9-ff21-471b-80e1-ec6a7d157e1e	2026-01-07 09:57:52.082858+00	4.6	24.5	159736	159736
0e5bd779-dc50-4836-af37-23c96272983b	2026-01-07 10:18:12.793129+00	13	30.7	4148	2935
8a4b97c5-bb1e-4d86-97e1-aed0d35e7a51	2026-01-07 10:38:13.045995+00	5.5	26.4	6125	4043
d6d03561-4816-42f9-8ed4-66d42251ed71	2026-01-07 10:55:52.099378+00	9.9	26.5	170783	170783
bbd79e25-59c8-4686-b790-82467cd8ab47	2026-01-07 11:12:35.814503+00	33.6	33.2	116530	116530
52fdc285-d1dc-4b33-b179-cb965aa50be1	2026-01-07 11:12:44.249867+00	32	33	583876	583876
bb57dcc1-3b89-4c50-8a11-d6addcd4184d	2026-01-07 11:13:35.880805+00	42.5	33.5	80755	80755
8ade4cb9-5823-4d98-b187-127ebba52903	2026-01-07 11:13:52.115968+00	40.2	33.8	2565657	2565657
570951f6-92f9-45db-b71d-57f828c33c62	2026-01-07 11:31:52.102242+00	13.6	27.6	483007	483007
101a7baf-b353-4db9-9c27-e4ea8d066b58	2026-01-07 12:29:52.006668+00	81.4	26	488164	488164
188500fe-ebc5-4c6f-9471-7d7e7564257b	2026-01-07 15:09:32.289412+00	10	31.8	639964	639964
9a0678be-b314-4412-b1d0-2c1b385ac933	2026-01-07 15:10:32.292064+00	10.9	26.3	547494	547494
b19a4804-8bb7-4cb1-9a18-f4e199f4057f	2026-01-07 15:11:39.336336+00	40.5	32.1	3200252	3200252
b6443b09-5c35-4144-b291-bfee84823e57	2026-01-07 15:12:39.318241+00	40.6	31.8	3569876	3569876
012deb08-32fc-486b-951b-6a6663f41a6b	2026-01-07 15:12:51.919239+00	40.4	31.8	4853231	4853231
5544dc4e-dbbc-48bc-80ef-9f4b27755035	2026-01-07 15:13:15.408612+00	37.7	31.7	4659697	4659697
27a6b48e-a511-48fc-9d3e-9e0d49db5caa	2026-01-07 15:13:17.634418+00	39.6	31.8	1658092	1658092
0f0498cc-5a52-4a77-a21e-660c8202b076	2026-01-07 15:13:32.321154+00	31.3	31.9	4410779	4410779
2d50e064-dc89-450c-8c1f-cd6b475284e3	2026-01-07 15:15:17.666407+00	31.7	32	2325465	2325465
38996b33-3262-41ff-9a22-f08f83cf8ac1	2026-01-07 15:16:17.616177+00	32.6	31.9	3778485	3778485
d0a0a982-a1c4-4771-a975-2e1a72d482ec	2026-01-07 15:16:32.281212+00	35.7	31.5	5755670	5755670
29809966-a84b-4dd0-84a3-d05bcf2a4251	2026-01-07 15:16:51.932052+00	31.3	31.5	3850426	3850426
097f5f70-2d7e-4c4e-b2d3-b67553abf84b	2026-01-07 15:18:17.617126+00	34.7	31.7	2005611	2005611
7096e7f1-e2ef-4d5d-85f2-b1f44eede72b	2026-01-07 15:18:32.31425+00	36.1	31.7	4607409	4607409
424b2f55-5266-4b75-8ca5-a6a0b7d1dddb	2026-01-07 15:18:51.951272+00	31.9	31.7	3281915	3281915
ae2473ca-6ade-443e-a392-76681e145570	2026-01-07 15:19:17.620685+00	32.3	31.8	5202285	5202285
cb8ddfb1-e52c-48b7-b4ad-602c7951d589	2026-01-07 15:19:32.372039+00	34.2	31.8	3120528	3120528
53a661e0-4de7-4b78-b922-f9b50de99478	2026-01-07 15:19:51.940187+00	35.3	32.4	5823992	5823992
e500257d-88ad-415f-962e-030a9f57d95c	2026-01-07 15:21:17.637861+00	32.8	33	3621139	3621139
287ac0c1-ad69-47fd-b833-cb30d8607525	2026-01-07 15:22:51.954167+00	33.4	33.1	1154422	1154422
c62bb05c-e820-4fcf-a689-13768bf0580e	2026-01-07 15:24:17.690375+00	33	33.1	1835577	1835577
9733180b-1b7b-407f-b41f-9f0f51720e7a	2026-01-07 15:24:32.299483+00	31.4	32.9	3715542	3715542
71e87d88-3c44-4e2a-96a0-a00f6047bee9	2026-01-07 15:25:51.924077+00	30.4	31.3	229325	229325
6dad6b3c-4e53-4900-a225-b618e67302a7	2026-01-07 15:26:17.619674+00	33.1	31.3	5559261	5559261
bc6d43ae-b21b-46ac-aca1-3079ba8dcac8	2026-01-07 15:26:32.286856+00	31.7	31.5	2362840	2362840
7012dc63-3b44-4452-886e-48c9d0aff0db	2026-01-07 15:27:17.625122+00	32	31.5	3134192	3134192
43331257-af6e-4a30-b90e-967f214d9b1c	2026-01-07 15:27:32.381935+00	36.6	31.5	4844669	4844669
19ceb9f6-0960-4710-b502-710098f4ddae	2026-01-07 15:27:51.885+00	28.8	31.5	353641	353641
b65030da-c341-40e8-82dc-8076a0c3ea93	2026-01-07 15:28:17.631248+00	34.3	32	3968270	3968270
3000f65c-d775-4ab7-baf9-688e42123936	2026-01-07 15:28:32.285833+00	32.6	31.9	2100224	2100224
a1a85a25-d5ca-4c3f-a92e-4a9ab2ca2972	2026-01-07 15:28:51.892617+00	32.8	31.9	4800304	4800304
f0721198-c8c1-4edb-ad75-697e78c889a5	2026-01-07 15:32:51.927614+00	33	32.3	123219	123219
062eb2b4-cfab-4ab5-9541-b33169ef9db6	2026-01-07 15:33:51.920802+00	30.5	33	362454	362454
442f30d6-abde-40f9-aa5e-2f97917d45f7	2026-01-07 15:35:51.928185+00	33.5	33	4533390	4533390
47cf41ab-9f5c-471e-9827-c4dc27cc1851	2026-01-07 15:36:50.591403+00	31	31.2	536036	536036
c0a3b65c-ab65-4b1d-b9de-85f7fbb1dd72	2026-01-07 15:37:51.885874+00	28.7	31.9	309626	309626
a03c5cf0-6137-489f-b633-5a323716b8d6	2026-01-07 06:58:58.306927+00	9.9	22.3	714458	714458
9f5d4850-7fb4-4b9c-a9ab-65e33dda773f	2026-01-07 06:58:59.900498+00	7.9	22.2	612522	612522
133f65e7-83d2-4218-864e-7422232ca653	2026-01-07 06:59:53.486067+00	11.9	22.4	91486	51966
39cb9976-2a10-49a6-9383-a64ebb91ecdf	2026-01-07 06:59:58.33433+00	11.2	22.4	605136	605136
bc5b3fc3-3a52-40c8-9b9e-2aa2c711f8ae	2026-01-07 06:59:59.51051+00	7.3	22.3	279156	279156
9d606971-3928-4509-8329-dfea1925ee90	2026-01-07 07:00:09.92124+00	16.8	22.3	808307	808307
8603327f-bdd0-4e11-b4f9-13c4f5d66589	2026-01-07 07:00:11.473745+00	71.6	22.3	799012	799012
21d0e5cc-2081-4e24-bf88-43a7af1f4050	2026-01-07 07:00:32.316062+00	11.1	22.4	752080	752080
f5ee1ce2-5022-4d0d-964f-e48cc123cf07	2026-01-07 07:00:53.487564+00	10.7	22.3	15065	31043
6b3ce4fd-047a-4478-94f5-8690b3ebd36d	2026-01-07 07:00:58.308564+00	9.5	22.3	657558	657558
9db0f7dd-8c2e-40b5-a12d-4f2f9b0ab351	2026-01-07 07:00:59.786598+00	5.9	22.4	659449	659449
8546fcbd-3a91-4b04-a795-7a32f23d0ea0	2026-01-07 07:01:10.300738+00	23.8	22.4	1100357	1100357
e489248a-d7ea-4ef1-b08f-2cc158aa7c9d	2026-01-07 07:01:32.294808+00	24.6	22.4	516312	516312
282a84f9-99db-44af-91ad-de8b28b99e8b	2026-01-07 07:01:53.498254+00	13.9	22.3	21439	27465
f375e3c3-7a2f-4975-bd51-fa4b86f739f4	2026-01-07 07:01:58.71637+00	11.2	22.3	703534	703534
ae4f01f0-085c-4f24-8375-9f943e7dc035	2026-01-07 07:01:59.908241+00	9.1	22.3	567893	567893
21a24478-bd31-4d23-8728-62639e9d8f27	2026-01-07 07:01:59.91116+00	9.1	22.3	393725	393725
d160e21e-84bb-4ae1-92d2-c76bebd8780e	2026-01-07 07:02:11.804115+00	32.4	22.5	606169	606169
9d4be063-c650-4261-bd96-4db698ce6413	2026-01-07 07:02:32.334512+00	23.3	22.4	913417	913417
a379a473-93cc-4dc4-8d6d-8ec516d97cff	2026-01-07 07:02:53.5506+00	16	22.4	245123	25787
56a1232b-ee26-49c0-8646-04bd105ad025	2026-01-07 07:02:58.643515+00	10.3	22.4	313883	313883
65ac495e-f83c-4c0c-b3ef-8a74f1ce83b7	2026-01-07 07:02:58.650837+00	10.3	22.4	747965	747965
aafd797a-0d33-4c71-9c15-e93a0865911c	2026-01-07 07:02:59.825587+00	8.8	22.5	353330	353330
27c96363-cba6-40ab-8908-5db0468c8ad3	2026-01-07 07:03:09.336646+00	15	22.4	570720	570720
b2a7dc74-254d-4b53-8ad2-637a7654171a	2026-01-07 07:03:11.624094+00	23.8	22.3	624783	624783
c34f627c-d4e4-4a76-95c7-80960f7b011f	2026-01-07 07:03:32.382414+00	10.3	22.4	809942	809942
1779e1b4-3b2e-4fbc-962c-a8334439ca59	2026-01-07 07:03:53.568231+00	10.3	22.3	40024	77278
1e52e30f-9bf5-48b7-9407-3e81f7268f33	2026-01-07 07:03:58.593871+00	11.5	22.5	408536	408536
edf882b2-93d1-4707-968b-fa7dba59d3c3	2026-01-07 07:03:59.613831+00	8.2	22.3	212389	212389
fd879b9d-2538-47f2-be10-17c9a7db1706	2026-01-07 07:04:09.136435+00	11.4	22.4	706707	706707
6a29fce0-3637-4b6d-a400-7ce503e62c3e	2026-01-07 07:04:09.142343+00	11.4	22.4	805299	805299
d824f916-b491-44ff-8463-9c7cfb583258	2026-01-07 07:04:09.99197+00	11.4	22.4	939485	939485
25b8cf78-0146-46c4-86a5-716e2c0e0a51	2026-01-07 07:04:11.435127+00	21.6	22.5	593990	593990
1e15d413-715e-4f87-aefd-00195650e8cd	2026-01-07 07:04:32.260278+00	18.8	22.5	704506	704506
7b9179d8-d833-4a88-a1de-5fb976a7ffd3	2026-01-07 07:04:53.553026+00	16.4	22.4	8160	12474
8916ca63-53dd-473d-b1f4-f287e24e65cb	2026-01-07 07:04:58.375306+00	9.4	22.4	247485	247485
4a509c53-e626-4b6a-b068-5e72c987cf6f	2026-01-07 07:04:59.562223+00	7.8	22.4	326423	326423
0b66a540-58e6-4bf5-b416-738606a23e59	2026-01-07 07:04:59.635777+00	7.8	22.4	451739	451739
0555861d-4368-41a8-898a-a4685aa87283	2026-01-07 07:04:59.66479+00	7.8	22.4	567521	567521
a139e9f7-6da8-4b99-9d04-553c12946523	2026-01-07 07:05:09.208114+00	11.7	22.4	815875	815875
733f2024-cf16-47e7-957d-c5017c39de53	2026-01-07 07:05:10.028544+00	11.7	22.4	965962	965962
5e5c5236-f9a2-4e49-99c8-5e185243c6e5	2026-01-07 07:05:11.529706+00	18.9	22.5	650992	650992
bca1dbb9-48e8-4b76-b2ca-1734c07050c7	2026-01-07 07:05:32.224211+00	14.6	22.5	906387	906387
24a4cf67-d028-4269-9d80-af981dd3fa60	2026-01-07 07:05:53.580677+00	12.5	22.4	9504	13035
f086b9d6-8e14-42b9-8a1a-d6c0813957fe	2026-01-07 07:05:58.393254+00	10.7	22.4	481075	481075
d65ffbc1-b94e-47c6-ab43-7905301f8fc0	2026-01-07 07:05:58.436562+00	10.7	22.4	505376	505376
513f0117-c706-439b-a6b8-bf2e8cec6c1d	2026-01-07 07:05:59.499028+00	7.3	22.4	258612	258612
669b10b6-45c5-43bb-8549-0c4184cbe073	2026-01-07 07:05:59.499448+00	7.3	22.4	320706	320706
4acc0699-29f3-465a-90c1-df9c34016a81	2026-01-07 07:05:59.603478+00	7.3	22.4	663652	663652
d6c2d92b-36a6-4694-bf28-0fbf4d1e079e	2026-01-07 07:06:09.23069+00	13.2	22.3	684564	684564
8382b8ab-3bb4-459d-993f-7322a0036fcd	2026-01-07 07:06:09.23237+00	13.2	22.3	981122	981122
bdb7d403-d380-4f0c-96d1-5e70d63b6b74	2026-01-07 07:06:10.102664+00	13.2	22.3	596384	596384
e12a5ad0-2a26-475b-909a-46c5486e4c43	2026-01-07 07:06:11.60391+00	29.6	22.4	755682	755682
7d9479d9-d6b5-4786-a962-e4737cc13318	2026-01-07 07:06:32.306212+00	9.6	22.5	871812	871812
c0194f4f-a783-4927-aed8-73c659dbc50f	2026-01-07 07:06:53.558361+00	14.2	22.5	83538	23812
b4d471d1-bbbf-4ac4-8a58-63778ca1c2c3	2026-01-07 07:06:58.38083+00	9.8	22.5	430572	430572
85fac182-0ebb-4460-99f1-ad656700628b	2026-01-07 07:06:58.463096+00	9.8	22.5	453470	453470
dc18b283-2da2-419a-bb9f-7a150dbe26ad	2026-01-07 07:06:59.542193+00	6.4	22.4	348352	348352
0c5573c6-047c-4064-bc49-2df06bf8dd48	2026-01-07 07:06:59.543787+00	6.4	22.4	337407	337407
934de3ed-91c9-44f6-bec6-bf88abd1c51e	2026-01-07 07:06:59.632753+00	6.4	22.4	482043	482043
784f3038-0bc7-49c0-97cb-0ff21f58c006	2026-01-07 07:07:09.088557+00	12.9	22.4	511058	511058
10f32c4e-87c4-4785-9f0c-90146ba562ff	2026-01-07 07:07:09.092252+00	12.9	22.4	761021	761021
49254b08-7163-447e-9d99-9afd03c679d7	2026-01-07 07:07:09.927496+00	12.9	22.4	854589	854589
d1677093-d50f-4c2a-b7c7-731d2b96a4de	2026-01-07 07:07:11.319691+00	18.3	22.4	720057	720057
b86f3fff-7051-4411-9caf-1c68e9ecd3a8	2026-01-07 07:07:32.264004+00	10.4	22.4	764910	764910
7893ca4a-f9b1-46e8-b805-0dfdaad6d1d3	2026-01-07 07:07:53.611694+00	14.4	22.5	208242	23121
bbca63c3-fb07-47c8-b8b0-41875c5024f7	2026-01-07 07:07:58.447889+00	12.9	22.5	1246395	1246395
fb845865-be39-4cfe-ad27-8b7bcceff394	2026-01-07 07:07:58.563033+00	12.9	22.5	629941	629941
184c27c0-d9f2-4c81-af87-577455cea036	2026-01-07 07:07:59.579133+00	8.1	22.5	233095	233095
db5b27d4-1583-4e11-b3c8-19ce967acb6d	2026-01-07 07:07:59.589297+00	8.1	22.5	379855	379855
277433f6-94d1-412d-a2f9-25c6eb9f9aab	2026-01-07 07:07:59.673867+00	8.1	22.5	469590	469590
8394bc4f-7eee-466e-b239-fc90ec567a7a	2026-01-07 07:08:09.079572+00	18.4	22.4	716955	716955
2ce516e6-4f1d-4ec0-aaca-02f8f5ce0e77	2026-01-07 07:08:09.089265+00	18.4	22.4	602843	602843
e98dbe7c-1b74-4504-ad74-623ad91bde07	2026-01-07 07:08:09.897308+00	18.4	22.4	807474	807474
c9923e10-2f4e-4ffb-984a-5594b70f98fc	2026-01-07 07:08:11.36976+00	18.1	22.4	882250	882250
f61a44b4-9aea-4df3-8e4a-fdd27e0f2a3a	2026-01-07 07:08:32.294597+00	11.3	22.4	824250	824250
e8a75bc0-11a7-49d2-b1fa-15daec1d1a23	2026-01-07 07:08:53.622588+00	12.3	22.5	8667	13238
a041bf01-45f7-499e-8bc2-9e8b56a880db	2026-01-07 07:08:58.255202+00	8.2	22.4	328229	328229
683bcf43-e3d7-4745-89af-310a9dbeae31	2026-01-07 07:08:58.321734+00	8.2	22.4	597474	597474
91ab04a4-b205-4f63-ae2a-3148daf361da	2026-01-07 07:08:59.429069+00	7.8	22.5	374380	374380
6d5493f8-d498-4e81-93d0-c4f4796ecee0	2026-01-07 07:08:59.432173+00	7.8	22.5	230518	230518
927f70f4-1790-49d5-955d-88dfdf1b6e9a	2026-01-07 07:08:59.526177+00	7.8	22.5	623678	623678
3fdee609-d9a8-4600-96da-b07787d6f000	2026-01-07 07:09:09.099609+00	16.8	22.4	703646	703646
963c672b-a2ab-45f0-a6cd-25729e8dcd0a	2026-01-07 07:09:09.106444+00	16.8	22.4	1114287	1114287
9b731a66-73f2-4bb8-9f48-83d282c9d881	2026-01-07 07:09:09.894207+00	16.8	22.4	1004518	1004518
bdb888ff-5090-4e9f-a337-69c692a6032e	2026-01-07 07:09:11.406713+00	24.7	22.4	615464	615464
1197083b-82b4-4815-9893-70627528288b	2026-01-07 07:09:32.260234+00	17.5	22.4	1082223	1082223
121a1669-a9b3-4379-904c-9357a8a95c14	2026-01-07 07:09:53.631149+00	15.9	22.4	7041	9619
44626048-237b-4608-a422-7b19cdaa05a4	2026-01-07 07:09:58.275043+00	7.7	22.4	232309	232309
71077691-bb23-4832-9adc-1bd1b171d335	2026-01-07 07:09:58.337865+00	7.7	22.4	865681	865681
211353ce-3b16-4013-8001-399aae5ce6e9	2026-01-07 07:09:59.392621+00	6.6	22.4	534478	534478
a74fc8d0-a262-4c8f-82a9-2e005e29afc7	2026-01-07 07:09:59.393223+00	6.6	22.4	724395	724395
46c95fdf-f4b9-4dc1-b6e8-db28a255774a	2026-01-07 07:09:59.470318+00	6.6	22.4	672051	672051
e6037704-9cb3-47d6-824f-528268bd6b02	2026-01-07 07:10:09.083369+00	8.7	22.4	458836	458836
df48c1e4-05a5-43cc-a077-7390d17dc819	2026-01-07 07:10:09.107245+00	8.7	22.4	728986	728986
acc15f21-2ea0-46fa-8658-a79c5e1d6991	2026-01-07 07:10:09.939074+00	8.7	22.4	647036	647036
7219ad5e-d16d-4aaf-95d1-63248440b01f	2026-01-07 07:10:11.380476+00	18.3	22.4	1102514	1102514
310e33e0-663f-451c-a2b8-7b911dcd9ac7	2026-01-07 07:10:32.2829+00	8.1	22.5	667846	667846
3e847d4a-afc9-4b4a-92ad-5f65be810d83	2026-01-07 07:10:53.604381+00	12.2	22.4	39482	14212
290e0378-15d6-4a22-9cd4-3aaff2776b4f	2026-01-07 07:10:59.823435+00	6.9	22.4	470389	470389
cf8730d1-9c76-448f-853b-1bbfebdf2773	2026-01-07 07:11:09.530361+00	14	22.5	705175	705175
021dc62f-abd0-46d5-8b6e-82dc77b73e16	2026-01-07 07:12:09.119901+00	8.2	22.5	634431	634431
a8f90689-3f90-4efd-8096-fe9c8a5a8ac8	2026-01-07 07:13:09.065127+00	22.4	22.4	433213	433213
54887757-a775-4772-b42c-a918bd7ab5da	2026-01-07 07:13:32.348652+00	10	22.3	657494	657494
8281509f-27e4-4fea-9d42-38e32a61d46f	2026-01-07 07:14:58.535495+00	7.7	22.4	518841	518841
6756327b-b50c-42c3-b6bf-cb90932f9149	2026-01-07 07:15:58.221642+00	9.1	22.4	425293	425293
ebbd7c1f-1626-4fd8-ace1-6cc00fc21d5a	2026-01-07 07:17:09.882753+00	18.7	22.4	794186	794186
4d71596d-dddb-4e95-a796-0cf1ad6465ef	2026-01-07 07:18:09.71762+00	22.9	22.5	724497	724497
052ef324-2a46-4005-b213-9fb557f55ab8	2026-01-07 07:18:58.53997+00	8.7	22.5	466864	466864
d0232137-fdcc-4681-9d35-69ff9c1848e6	2026-01-07 07:18:59.527218+00	6.7	22.5	330158	330158
1d3659b7-45c3-4e5b-af07-3f0fe515d60e	2026-01-07 07:19:10.072897+00	18.1	22.4	1029613	1029613
15446dc6-3a0d-4e45-99b5-238e9d6c9c7e	2026-01-07 07:19:32.199379+00	8.1	22.4	870875	870875
2b0af4d8-365f-4569-94c7-49a3e745602c	2026-01-07 07:20:00.062979+00	7.2	22.4	247371	247371
f90ee9eb-6390-4b6a-89d6-173327cbffd2	2026-01-07 07:20:11.999774+00	31.2	22.5	681973	681973
6beae193-925a-4264-8bc9-aa47057e3ad0	2026-01-07 07:21:09.208111+00	24	22.3	589051	589051
d34dbc76-fff5-4877-9ded-571f6dc31bb8	2026-01-07 07:21:59.460696+00	8.8	22.5	239932	239932
13e8306d-8375-47da-8347-4ea222c185a8	2026-01-07 07:22:32.248113+00	8.5	22.4	891714	891714
f2dda724-7d9f-400c-a0cb-b6eeb6aa1d05	2026-01-07 08:14:54.235759+00	6.8	22.3	13852	7739
6c543790-578e-4dd4-84f2-aad0821a640b	2026-01-07 08:50:09.981191+00	9.9	28.5	0	0
3fefda35-2633-4706-ba90-5b6795f2932c	2026-01-07 09:37:13.303005+00	24	30.2	344512	344512
66f87d28-719a-4726-a455-5a9bdc96b748	2026-01-07 09:37:51.995518+00	7.1	29.4	753146	753146
83116fc7-aae9-40f4-a55f-23497173679a	2026-01-07 09:38:08.170131+00	7.6	25.5	55857	55857
51267a4b-c3fe-4059-b606-3c8f9d1cc3ab	2026-01-07 09:38:52.11768+00	7	25.5	138711	138711
3ec32921-4b4c-4c1c-abd4-2aed9976ca9d	2026-01-07 09:39:08.045083+00	7	25.5	136088	136088
0d8d2b98-d77e-49c5-b715-d2735c408a1b	2026-01-07 09:39:51.969782+00	6.9	25.5	384831	384831
86337fb5-9535-43b5-9bbf-b6468672cff1	2026-01-07 09:40:08.149177+00	6.8	24.5	32888	32888
e0193399-c7cd-489e-9da2-2659e1c96790	2026-01-07 09:40:51.872101+00	7.6	24.6	606996	606996
17b9dd04-2985-49d1-9633-32ae2bc7f730	2026-01-07 09:41:08.140567+00	6.4	24.7	61695	61695
796bcfdc-423d-4c09-8ee6-ec44cbe3332e	2026-01-07 09:41:52.027064+00	7.2	24.7	77527	77527
7c2ab207-1f4f-4fcd-8830-e5191842904c	2026-01-07 09:42:08.881768+00	6.5	24.6	154797	154797
3743ce11-3183-4a79-a2cb-d20652056d40	2026-01-07 09:42:51.932547+00	8.2	24.6	469880	469880
67004978-5314-4a70-b506-337c86592969	2026-01-07 09:57:52.082851+00	4.6	24.5	0	0
7b88fd87-d691-4a8c-94fa-aa27b781338e	2026-01-07 10:18:42.842162+00	4.9	30.4	4151	4151
c0f799a5-fd62-4407-9d70-cc5d3095f50a	2026-01-07 10:18:52.077885+00	9.2	29.4	78265	78265
3ee20856-7a03-4b5b-a80a-bd674b7b6926	2026-01-07 10:38:52.087903+00	5.5	26.4	95915	95915
366a5c0f-abdb-4eb7-8583-457b6d6ba2b7	2026-01-07 10:55:52.101674+00	9.9	26.5	72210	72210
163993c3-d30b-4210-b6ca-06e65f92114b	2026-01-07 11:12:51.867773+00	41.2	33.1	868021	868021
c123fb42-6262-4a36-bfd8-ceb13efab65c	2026-01-07 11:13:16.611807+00	36.3	33.2	433272	433272
5f66d791-ef0a-49a8-97a0-334a2d85a80c	2026-01-07 11:32:13.690582+00	8.8	27.6	6916	4554
758275b8-dd04-4aa8-b140-21e29e12c172	2026-01-07 12:29:52.019612+00	81.4	26	608466	608466
aca80ff1-a4f0-4ef9-b088-dc197bad37fd	2026-01-07 15:38:51.857065+00	29.8	31.9	338719	338719
dce84c18-0aef-45d0-b178-fdef3872a805	2026-01-07 15:39:51.870928+00	36.4	31.3	360443	360443
98f5944e-da74-494d-84a4-11024f1b3db4	2026-01-07 15:40:17.607786+00	41.6	31.9	870225	870225
59936e50-bf22-4d5a-a8d3-85aa2c436a12	2026-01-07 15:41:51.867168+00	37.9	32.9	285760	285760
0a4c751a-8191-44f5-8327-22214ebc0fbb	2026-01-07 15:42:51.877865+00	28.5	32.8	348313	348313
8ba3883b-8bc6-4e6f-b50c-f3a7b2338de1	2026-01-07 15:44:17.630596+00	29.9	32.7	298985	298985
1e777ae6-8a7d-4b98-a0c9-a2d42a274e62	2026-01-07 15:45:17.62605+00	31.1	33.3	626394	626394
b8da887a-e156-4399-9d01-11b777768eba	2026-01-07 15:45:51.880061+00	41.8	34.9	501768	501768
2b822d88-b673-4575-a275-9ff9424103a1	2026-01-07 15:46:51.89129+00	29.9	33.5	213729	213729
fe4ee873-576d-44a2-9e41-11c9ec3ee0aa	2026-01-07 15:47:51.873669+00	30	32	379342	379342
f5cb4b00-51d7-4bc2-a991-8c4771ab9ece	2026-01-07 15:48:51.868733+00	29.9	33.5	334680	334680
a42ef627-c8f2-41a2-8e52-3a512187dcc4	2026-01-07 15:49:51.883342+00	26.6	33.6	228679	228679
e76e523a-733b-4161-aefd-877d21a4ae7e	2026-01-07 15:50:51.867601+00	31	30.5	436642	436642
2e83b5da-e9be-4cdd-8ffd-0d2a51073fa5	2026-01-07 15:51:51.884863+00	30.4	31.6	244460	244460
4b8851af-a549-4024-8036-74133400c3d8	2026-01-07 15:52:51.865909+00	28.7	31.8	332785	332785
faeae916-d53a-4ae2-8d32-cbc2e6d287fc	2026-01-07 15:53:51.876435+00	28.9	33	375932	375932
bd0797b7-83d5-403e-a79c-99068d4da5c5	2026-01-07 15:54:51.888407+00	29.1	32.4	322476	322476
6e10119d-1d51-4e24-a3e1-b7fae6a20480	2026-01-07 15:55:51.942866+00	32.5	32.4	366460	366460
5bd73736-fe6d-4c46-b516-ae8646905cb8	2026-01-07 15:56:51.87372+00	30.3	32.5	323766	323766
9bf6d422-e971-4773-9ea2-46846ffe0e51	2026-01-07 15:57:17.59537+00	29.5	32.4	929795	929795
318d56e7-d803-4da7-962b-0ea629aa8b8f	2026-01-07 15:57:51.877769+00	32	32.3	259147	259147
862942b7-ed91-4e4f-a88b-367b568a3c4d	2026-01-07 15:58:17.589451+00	30.2	32.4	643555	643555
1c9cb03a-96c9-4ad1-bdfb-c699edd3640a	2026-01-07 15:58:51.883102+00	30.2	32.4	242183	242183
c2c0bdd8-7fb7-4174-9ba2-61366c89e66f	2026-01-07 15:59:51.867592+00	30	32.4	295897	295897
3e19bb1e-5755-445c-ab77-53afd9cabd97	2026-01-07 16:00:51.880229+00	30.3	32.5	356443	356443
68a37c12-2065-4dde-8403-075ff9201916	2026-01-07 16:01:17.624227+00	29.9	32.4	686417	686417
bb1abe74-8052-489d-ba51-44470df973d8	2026-01-07 16:02:17.59917+00	30.4	32.4	933856	933856
6b5f8cf9-22f4-4d4a-9448-7861a08da788	2026-01-07 16:03:17.619794+00	30.3	32.4	697406	697406
6d9d8005-a0b4-44fd-9658-8996956f4122	2026-01-07 16:03:51.908065+00	30.8	32.4	332742	332742
45a53c14-7d4f-4e92-90ce-6ff7ca1b55ea	2026-01-07 16:04:51.866808+00	30.4	32.4	414022	414022
0cae7eee-4c7e-4e5f-b45f-aeb802458c77	2026-01-07 16:05:51.881139+00	31.5	32.6	251417	251417
c338ebb4-5127-481e-86b6-436d0c149a6f	2026-01-07 16:06:51.876507+00	31.6	31.6	313501	313501
f903e9d9-e9c2-4ff1-83c0-da5fd59867e6	2026-01-07 07:10:58.528829+00	8.9	22.5	650708	650708
f7aaff26-9454-48ee-88df-db8ff39ccce1	2026-01-07 07:11:32.15943+00	7.9	22.4	814177	814177
aeeeff0f-9877-4900-85d1-0e7b70e8c2a9	2026-01-07 07:11:49.029701+00	7.9	22.4	37924	37924
368064f3-74bb-4ec6-b53b-47b4b4e00ab0	2026-01-07 07:11:59.490554+00	8	22.5	448255	448255
84524612-29b3-4d12-a4c4-6684aa7708e6	2026-01-07 07:12:11.404013+00	16.5	22.4	654380	654380
8ea54a98-1356-420c-8ade-5c876283be83	2026-01-07 07:12:32.281472+00	21.5	22.2	819020	819020
82f20791-e17c-45fa-8c96-1cbe2513c77c	2026-01-07 07:12:59.508443+00	7.3	22.3	678228	678228
6cced92d-f259-485d-bd99-3736756a7fe5	2026-01-07 07:13:58.407223+00	9.7	22.4	662891	662891
3e45f0d4-467a-4963-955f-d25f063fb2ea	2026-01-07 07:14:09.312583+00	6.7	22.4	704666	704666
c8c4977b-e8d7-42d2-8459-51e094f52a18	2026-01-07 07:14:11.670433+00	23.2	22.5	519967	519967
9d209991-7638-43de-a339-6efe7c9cd249	2026-01-07 07:14:32.387265+00	8	22.4	818462	818462
44f81139-a800-4934-a8cc-e90b7ee3075e	2026-01-07 07:15:09.186591+00	17.8	22.4	393365	393365
4007c484-52d5-48a7-b0ac-d9fb33aaf613	2026-01-07 07:15:59.867576+00	5.9	22.4	644091	644091
6e272d90-7453-4dae-adad-39807d718877	2026-01-07 07:16:09.623377+00	14	22.4	937234	937234
267a2493-2541-4f2e-a6c0-876dac9449a3	2026-01-07 07:16:10.462726+00	22.7	22.4	1225578	1225578
670d467d-18ee-41d9-afba-2124f389bf78	2026-01-07 07:16:58.295449+00	9.1	22.5	608113	608113
4847572e-552a-4027-a54d-482535e5cd2d	2026-01-07 07:17:09.051487+00	18.7	22.4	645231	645231
c7544fd5-744b-4205-b39f-e96369e07de3	2026-01-07 07:17:58.744535+00	9.1	22.4	649259	649259
18f453dc-0740-4ec9-969a-e46d16c5ef9a	2026-01-07 07:18:00.173261+00	8.1	22.5	616749	616749
0a1d584a-bcda-47b2-85ec-905cbf4c24e1	2026-01-07 07:18:11.903988+00	72	22.5	982316	982316
bd0b403d-8725-4f8c-af0b-422e274f9d20	2026-01-07 07:20:09.745612+00	23.6	22.5	708428	708428
677430d1-4fb4-42a5-8aeb-3c04ab474a86	2026-01-07 07:20:59.527263+00	7.1	22.4	491626	491626
54c3b9d9-a46b-4b38-b7e5-3ca9301ab740	2026-01-07 07:21:10.112815+00	24	22.3	876533	876533
413d540d-959f-4b46-a8d8-05df3fd72229	2026-01-07 07:22:58.541651+00	10.2	22.5	638596	638596
8f3f359e-207a-4e8d-894d-56ee91f1493a	2026-01-07 07:22:59.827068+00	7.7	22.5	365357	365357
e11720fe-f9c4-4f86-8089-db93795f3200	2026-01-07 08:15:03.73096+00	7.5	22.3	447082	447082
5c95f9b4-7a36-4848-b77f-b13af5cab515	2026-01-07 08:20:03.772217+00	7.6	22.1	313523	313523
09a99b19-279c-4b73-9971-6116b15dcfd2	2026-01-07 08:50:54.530779+00	7.6	28.5	22948	22290
bd85de82-3f3d-415e-96ab-9a260753f862	2026-01-07 09:38:12.297507+00	7.6	25.4	1845	7506
4c00157d-b757-4298-a62f-d52bc5906416	2026-01-07 09:58:12.457502+00	4.6	24.6	2973	1953
f2733611-f066-473b-80ca-8e54e4e86542	2026-01-07 10:19:12.748462+00	8.9	29.2	4486	3331
37c6c45d-1a7e-42d1-a039-d568a871a13e	2026-01-07 10:38:52.089999+00	5.5	26.4	200746	200746
f4cd4e87-39b2-4907-8e2e-47c9d6b7953a	2026-01-07 10:56:13.242845+00	5.1	26.5	5719	4127
aae3a43a-ddfe-40ef-987d-bb35d338e3fb	2026-01-07 11:13:13.430251+00	37.9	33.1	1334087	87274
22c40cf1-da26-443c-a34f-d41af40e150f	2026-01-07 11:32:52.05761+00	5.1	27.6	0	0
8cf693bf-6fed-4a3d-9a8f-278115ee4c17	2026-01-07 15:39:17.609334+00	34	32.3	752795	752795
d55bff17-060f-4595-9a72-ec69e70cc19b	2026-01-07 15:40:51.878914+00	37.8	31.6	235627	235627
e48c1daa-4ca9-445c-809e-14b6865a7189	2026-01-07 15:41:17.602356+00	36.9	32.7	481845	481845
380a84e5-8752-4650-8721-1949092735e5	2026-01-07 15:42:17.64338+00	35.5	34.4	645224	645224
5879119f-c693-4d6a-9d87-e4be55d9c0d7	2026-01-07 15:43:17.619468+00	32.8	32.8	683377	683377
c341f417-01ee-4065-9aa0-cd0fb1d9732b	2026-01-07 15:43:51.873898+00	29	32.8	281732	281732
aa58b4a0-e71a-496c-8e4c-8cdcadc12440	2026-01-07 15:44:51.877489+00	29.9	34	372551	372551
2b5851c9-2790-4756-a102-28f26f414c92	2026-01-07 15:46:17.616107+00	30.5	32.2	370892	370892
c3392ac0-8ead-457d-bf29-424f8193357f	2026-01-07 15:47:17.628385+00	29.9	33.5	513304	513304
8dc7f89b-62be-46ab-a7a0-6f7c0beec8c0	2026-01-07 15:48:17.63712+00	30	33.6	458933	458933
a0638f06-02c5-48fd-93fb-87616c252cfc	2026-01-07 15:49:17.621112+00	29.9	33.4	625049	625049
cd90f775-1e29-43b5-b3b9-fe929e5886c8	2026-01-07 15:50:17.655663+00	32.8	32.8	447817	447817
7f4c4936-d9e4-4968-afe4-dce0b1c4a92d	2026-01-07 15:51:17.620237+00	29.7	31.7	604705	604705
81fcf0fd-5974-495f-88b7-73e26494b6e8	2026-01-07 15:52:17.620296+00	32.3	31.9	682121	682121
de18f40e-99db-4ef0-b855-e5f20630b70b	2026-01-07 15:53:17.634316+00	27.8	31.9	915367	915367
273cfad5-66ed-4b80-8d0f-e298006a8972	2026-01-07 15:54:17.643737+00	28.1	32.5	475341	475341
a793049d-f855-4ecf-b38f-76dba921c270	2026-01-07 15:55:17.614945+00	30.4	32.6	701587	701587
8753bdf5-4bdb-4ff3-87ef-fb863ad93add	2026-01-07 15:56:17.617595+00	30.1	32.4	632512	632512
6de2539d-0699-4048-b4c0-d0d40db9ef34	2026-01-07 15:59:17.787627+00	29	32.4	346298	346298
6a138f17-8568-4007-ad33-cce011c7db35	2026-01-07 16:00:17.623701+00	29.6	32.3	688785	688785
f3f43460-e348-4799-8547-e480ca2937bd	2026-01-07 16:01:51.902878+00	29.5	32.4	101798	101798
64bda05a-f1aa-40d9-b958-0afcd336fd6a	2026-01-07 16:02:51.866939+00	30.4	32.4	286096	286096
eff7f36c-99ec-4035-9957-1f43e8fd0f57	2026-01-07 16:04:17.646252+00	30	32.3	743840	743840
65bd6500-45aa-4a5d-8c6b-8f934fc2092f	2026-01-07 16:05:17.609492+00	30.1	32.4	291664	291664
706b0931-296d-4898-b555-9e88e863b9c9	2026-01-07 16:06:17.622454+00	32.9	32.4	461056	461056
08b21441-228c-4616-9e1f-9c4970e98088	2026-01-07 07:10:58.537938+00	8.9	22.5	522141	522141
01934331-2239-40af-85b4-b45f761b96f3	2026-01-07 07:10:59.990462+00	6.9	22.4	597974	597974
60e8d38f-42e9-403e-b2a5-f6d52d41bf23	2026-01-07 07:11:59.490428+00	8	22.5	242244	242244
2ed799c4-fb1a-4db8-acca-a82d579bcdce	2026-01-07 07:12:58.383533+00	10	22.3	706119	706119
515a8e9e-52b9-4aab-9852-c4a4ba49d27d	2026-01-07 07:13:09.927094+00	22.4	22.4	922450	922450
c9912aa3-8c42-43e0-b213-e32d56ef8a0c	2026-01-07 07:13:59.76971+00	8.1	22.3	456503	456503
5c4e201d-30fa-416e-82e4-c4ebc6a15dd0	2026-01-07 07:14:59.687373+00	7	22.4	629386	629386
c64a0cd2-191c-4a11-98a7-b5319be7954e	2026-01-07 07:15:11.488816+00	15.9	22.4	559115	559115
e8d7a196-77b2-4436-b9c3-83c861519cf7	2026-01-07 07:15:32.225813+00	8.2	22.4	595947	595947
a2800e9a-c4b8-4140-a31c-7d986a5c5321	2026-01-07 07:16:09.615014+00	14	22.4	509065	509065
6eede395-21aa-4d19-be47-135ea53914cb	2026-01-07 07:16:59.500484+00	9.4	22.5	335401	335401
2c8e9bdb-b3b6-4c58-a889-0340a477d42c	2026-01-07 07:17:11.308647+00	29.2	22.3	863743	863743
b50dd839-179e-4c16-83f4-c3e250392866	2026-01-07 07:17:58.786182+00	9.1	22.4	595995	595995
d99a59ba-7cdd-4a61-915b-b2d51b20c976	2026-01-07 07:18:09.718187+00	22.9	22.5	1004827	1004827
d6df03de-3520-4cbe-8f03-3ba6e7cf5c07	2026-01-07 07:19:58.717904+00	8.9	22.4	551890	551890
b0247546-be41-4c79-896f-84976b424768	2026-01-07 07:20:09.74357+00	23.6	22.5	671434	671434
a6e29849-f8d9-4702-af80-f7265f72b604	2026-01-07 07:20:58.307989+00	8.8	22.5	641807	641807
71569da5-0bf4-48f9-bceb-f511226a4765	2026-01-07 07:21:09.21074+00	24	22.3	718179	718179
76075154-7555-4283-8a68-f21f7c90d0fc	2026-01-07 07:21:58.339496+00	9.4	22.5	1844454	1844454
928ad3ff-7898-4f97-91db-4ec2b4e4889d	2026-01-07 07:21:59.457082+00	8.8	22.5	301963	301963
3d299bf0-a654-45cd-8a71-5d0b5140e7fc	2026-01-07 07:22:09.921364+00	16.2	22.4	827447	827447
3cbd8ef7-5e5e-4393-bce5-da6689778fdd	2026-01-07 08:15:54.199268+00	6.2	22.1	13909	7712
0aba88a0-de47-4f1d-a1c3-6e062bb1f149	2026-01-07 08:51:54.574729+00	9.1	28.5	11216	18125
32e10833-d8af-47aa-aa48-26011cc6436f	2026-01-07 09:39:12.277371+00	6.6	25.5	2572	8660
1f1374fc-55bf-43e4-9e59-b3eddbf00182	2026-01-07 09:58:32.274684+00	4.6	24.5	92976	92976
234e7c97-f3d9-4daa-8d79-4db2852e3ff3	2026-01-07 09:58:34.309856+00	4.8	24.4	127168	127168
299b39e7-2117-43b7-8dd9-8d6fd2134b9b	2026-01-07 09:58:48.214391+00	10.7	25.7	170371	170371
4e6dbdd8-6bdd-4b39-bc00-cc19345dff60	2026-01-07 09:58:52.108936+00	4.8	25.7	65136	65136
099125b3-4b65-45ca-b0c7-b087188b2851	2026-01-07 09:59:52.066212+00	6.6	26	76441	76441
692fbf07-d402-4e6d-8942-31952cd8e134	2026-01-07 10:00:52.035038+00	6.3	28.3	144712	144712
0e6824ea-ca6e-429b-84d3-294dcc4f3b09	2026-01-07 10:19:42.798785+00	4.4	29.2	4266	4266
4c5c4d47-01eb-4e6c-9c3f-5dcd688b9450	2026-01-07 10:19:51.999382+00	4.8	29.2	69800	69800
f087995b-0888-4a61-8ddf-7dfd08f81fe2	2026-01-07 10:39:13.024693+00	4.8	26.4	5330	3351
aed8fee5-7328-4909-a790-13fb5d2db264	2026-01-07 10:56:52.211609+00	4.7	26.6	51917	51917
8045e4e1-77dc-4452-9f6c-65d2e3a2ab98	2026-01-07 11:14:13.449775+00	31.6	33.8	806315	324532
c9a509c2-6a29-4aa4-8a4a-172d82fe35fe	2026-01-07 11:32:52.059218+00	5.1	27.6	194327	194327
65e73ddf-e6f1-447b-a99b-c4186db6532f	2026-01-07 16:07:17.610827+00	30	31.7	869238	869238
d1e0ed4f-60f2-46c0-a6a1-0ba4ee4bb831	2026-01-07 16:08:17.615666+00	29.8	31.8	594517	594517
731011d4-e9cd-4502-8189-c57e66a60cf4	2026-01-07 07:10:59.823524+00	6.9	22.4	273397	273397
4a852c82-4962-4bc2-b0eb-8cbbced0c9f4	2026-01-07 07:11:11.764653+00	25	22.4	781353	781353
9e0e6c76-8889-41c9-984e-cf49a6092dc4	2026-01-07 07:11:59.583128+00	8	22.5	640636	640636
c3bf4c4c-497b-454d-8e73-5013be0890ab	2026-01-07 07:12:59.509674+00	7.3	22.3	243416	243416
ef0031cc-81b2-48e9-8150-ba0d97851da8	2026-01-07 07:13:11.379863+00	24.9	22.3	567655	567655
b9b17d51-8cdc-40d0-9914-a1cc31107893	2026-01-07 07:13:59.701411+00	8.1	22.3	323609	323609
7edec122-31a2-4366-866a-8b684735d657	2026-01-07 07:15:09.194583+00	17.8	22.4	727799	727799
d7afb1e4-a7f5-4b84-8873-bc417be61556	2026-01-07 07:16:59.572832+00	9.4	22.5	682293	682293
a96a1ed0-6d11-4e21-b487-67a4c907b848	2026-01-07 07:17:32.35602+00	8.1	22.4	694603	694603
4f07a1b8-8631-434b-818a-ab7f4b012eb6	2026-01-07 07:18:00.097405+00	8.1	22.5	358322	358322
533a35a9-6315-4ae4-9767-229bd03bc90d	2026-01-07 07:18:32.322653+00	9.7	22.4	699277	699277
5451d204-dab3-45b9-9fbc-9918fa9fd46e	2026-01-07 07:18:59.615461+00	6.7	22.5	416770	416770
193084fa-507b-45e4-bf9b-d8ece20074a7	2026-01-07 07:19:09.132944+00	18.1	22.4	483840	483840
b0c68a10-667c-4493-aa07-2cb30e576ecb	2026-01-07 07:19:11.605819+00	28.6	22.4	635119	635119
77fee157-6ead-41b9-8e52-1b387062248f	2026-01-07 07:20:00.236436+00	7.2	22.4	612351	612351
2aa3b7d3-2af0-4400-b4a0-28aa17658657	2026-01-07 07:20:32.251212+00	20.7	22.5	1031828	1031828
ad2e353d-08c4-409d-8216-b35e5c741fe6	2026-01-07 07:20:59.629539+00	7.1	22.4	423587	423587
a3d3d62b-dadd-4829-b1c8-299f72fc8fd2	2026-01-07 07:21:11.567899+00	25.4	22.4	708830	708830
5f29bcf2-cea9-4668-816b-aefd519ceb58	2026-01-07 07:21:58.301354+00	9.4	22.5	634628	634628
61405d1c-e284-4dd0-96e5-164d77205400	2026-01-07 07:22:09.101292+00	16.2	22.4	226803	226803
f86337c7-0464-433c-bf3a-b658d857e75b	2026-01-07 07:22:59.720819+00	7.7	22.5	655737	655737
68afdf08-d67f-4010-99bb-19475130cd19	2026-01-07 07:23:09.401224+00	8.8	22.5	835959	835959
92b83a5d-9d2f-46cd-bc58-40d53650602c	2026-01-07 07:23:10.29213+00	8.8	22.5	958547	958547
b8e24715-f6cf-4861-bc12-49636fc1eaa4	2026-01-07 08:16:54.208139+00	7.3	22.2	8814	7873
2b0dc805-e04f-4914-9303-d42cf32390e3	2026-01-07 08:52:54.557254+00	63.3	29.6	8666	11781
8a7ac8a6-c061-4f67-be1b-477f34540eae	2026-01-07 09:40:12.288703+00	7.3	24.6	2355	7930
a062dbb2-02f7-44f3-9d26-0d329084d8b0	2026-01-07 09:58:45.777459+00	8.7	25.7	221150	221150
e86e5bc8-6a9c-4855-b25d-421466dae9e5	2026-01-07 09:59:48.92447+00	7.6	26.1	96206	96206
bdd8f074-8ea9-4892-af4e-3238d9543f08	2026-01-07 10:00:48.797481+00	11.2	27.5	8736	8736
4ed838a8-d67b-42be-8bfd-edcf76948fe7	2026-01-07 10:20:12.793087+00	7.4	29.1	1504023	122929
269af5c4-6c6d-4730-8e93-e6c92b576e00	2026-01-07 10:39:52.156774+00	7.7	26.3	97562	97562
154d0ab4-8b94-4cd4-802e-1606f92d44fb	2026-01-07 10:56:52.212385+00	4.7	26.6	65279	65279
f8aed222-0a0d-494e-a815-f564c0af87f3	2026-01-07 11:14:35.816445+00	55.5	32.5	29727	29727
d14b82b8-53fb-4deb-b075-b043ed3dfa7e	2026-01-07 11:33:13.711573+00	5.1	27.6	6835	4289
e61e9878-c0c5-432f-a844-948270679fe6	2026-01-07 16:07:51.884136+00	30.1	31.6	345242	345242
c6670b68-5635-4912-b706-de215bc04cec	2026-01-07 07:11:09.533886+00	14	22.5	1013577	1013577
6e93fb86-d962-4bd0-a520-0919dbfb44a5	2026-01-07 07:11:10.431306+00	25	22.4	762254	762254
d16b678f-aab1-45af-8a97-aa66ee2548bd	2026-01-07 07:11:53.647159+00	18	22.5	136890	16007
c1dbb2c1-bc9a-403d-a008-51195d5d82fd	2026-01-07 07:11:58.286067+00	8.1	22.5	562510	562510
5c9283f0-dccf-4d47-9db2-7c8412579bd5	2026-01-07 07:12:09.117803+00	8.2	22.5	574998	574998
ebf4d245-90c2-4d79-aedd-4d5d9a8e6af0	2026-01-07 07:12:59.6128+00	7.3	22.3	412526	412526
6f938c71-49ea-4bdf-927e-9351008cdced	2026-01-07 07:14:59.642152+00	7	22.4	305064	305064
842e0ddd-ca47-49a2-9fda-de92c537c5f2	2026-01-07 07:15:58.273788+00	9.1	22.4	688166	688166
b0eaf1fc-acff-4c66-88e3-16df49520b6a	2026-01-07 07:15:59.950612+00	5.9	22.4	538127	538127
dd243978-5837-4078-a012-dbef5e741651	2026-01-07 07:16:11.940063+00	22.7	22.4	663390	663390
7f0963ef-a1cb-4a0a-832e-075fae929a3c	2026-01-07 07:16:32.282325+00	14.3	22.4	891148	891148
8b960672-7b36-4360-a420-53c49e8d7709	2026-01-07 07:16:59.499535+00	9.4	22.5	364049	364049
b8585280-e2e5-49b6-88f4-e148240bfbf8	2026-01-07 07:17:09.061016+00	18.7	22.4	203712	203712
979aa31f-e5b6-4b3d-ba44-1aa0d3b1cb2b	2026-01-07 07:20:10.569804+00	23.6	22.5	1088562	1088562
36d45a51-2020-4328-bd07-8b20951385f6	2026-01-07 07:20:58.440005+00	8.8	22.5	755857	755857
2ef9251f-8ef0-4dbf-8fcd-98acead6a527	2026-01-07 07:22:09.066131+00	16.2	22.4	683735	683735
b8eac9a9-b113-4714-b236-bb895d22e41e	2026-01-07 07:22:59.722328+00	7.7	22.5	263021	263021
ddce01f5-a2df-4f3b-85c2-4d431fdc2ec7	2026-01-07 08:17:03.739026+00	7.1	22.1	349388	349388
b5613576-9173-4a3e-be08-84e4f2016f4e	2026-01-07 08:53:54.563425+00	62.2	29.4	12739	42052
556da768-d6b8-48d8-9236-8cffb34539a2	2026-01-07 09:41:12.305567+00	9.8	24.7	3149	7693
d10576c0-69f2-43b0-97f0-8f2c5d9ae450	2026-01-07 09:59:12.480977+00	6.2	25.7	15546	14453
2eb14fc7-074b-4de8-947b-15bba47882fd	2026-01-07 10:20:42.803902+00	17.5	30.5	466008	466008
0deba6fb-639a-4c61-8ccd-2b9321d61830	2026-01-07 10:20:48.548798+00	17.7	30.4	578930	578930
7158f30c-a45a-4663-baf8-861275fecc3c	2026-01-07 10:21:48.823262+00	7.4	31.2	123699	123699
fb279386-fed1-42c6-b3eb-be21980d9522	2026-01-07 10:22:48.813484+00	8.6	31.2	722192	722192
f49d779e-36b5-453f-9e93-38cd375cce09	2026-01-07 10:23:48.814553+00	22.7	31.2	852396	852396
9fdfd716-e870-4680-a3f1-03b7d5f11bd2	2026-01-07 10:39:52.157499+00	7.7	26.3	101666	101666
8efd428e-09ae-4406-bf20-a625c94caddc	2026-01-07 10:57:13.260323+00	5.4	26.8	369019	78411
c9fc6de5-7fee-494f-aff7-5c56ee704dd5	2026-01-07 11:14:52.109802+00	51.9	33.7	114425	114425
f45706a3-71c8-4ddf-9921-a9fa3052eee2	2026-01-07 11:33:48.461369+00	5.1	27.6	122904	122904
7d74a3bf-fedb-449f-a7f2-fafd9be5e58c	2026-01-07 11:33:50.5112+00	5.2	27.4	276476	276476
6b6aa40d-c388-4fce-8ff6-2d2649e8c295	2026-01-07 11:34:50.882673+00	16.2	30	524147	524147
ce182a19-8cca-4cb5-880e-4451256a23dd	2026-01-07 16:08:51.863078+00	30.4	31.8	371141	371141
dde987c6-06ea-4f71-b6c5-7b28905f18ac	2026-01-07 16:09:17.639194+00	30.2	31.7	313724	313724
4331fa25-57ad-4c0f-a324-4238396ec197	2026-01-07 16:10:17.608459+00	30.7	31.7	589024	589024
95c62f67-3799-4e01-8514-a4d00a2eb279	2026-01-07 16:11:51.879869+00	30.7	30.8	257443	257443
d9aade8e-2c52-4f96-b016-ed6056de55a0	2026-01-07 16:12:51.873096+00	30.2	31.8	306515	306515
00a221f4-a3a4-4ecd-9a4f-8b9820cfc579	2026-01-07 16:13:17.608175+00	30.1	31.9	767706	767706
cd7d8343-b35c-4ba2-9cbe-ccdd8777b5d9	2026-01-07 16:14:17.617574+00	29.6	31.7	463120	463120
7573d285-1103-491a-b1ea-b8719ded7693	2026-01-07 16:15:17.593673+00	30.1	31.8	899291	899291
011c0ae2-be55-442e-8f3b-f2562d2be365	2026-01-07 16:15:51.869717+00	30.4	31.8	277092	277092
31617844-bb84-46a7-ba41-07d451484d4f	2026-01-07 16:16:51.866589+00	30	31.9	297343	297343
9c1526c1-2789-42c9-873e-63706c6b64d2	2026-01-07 16:17:51.87735+00	32.5	32	326681	326681
f4634c4f-39ed-4bba-95bb-46bc717473c2	2026-01-07 16:18:51.871497+00	32.6	32.7	325105	325105
86e75d49-3e41-4188-abd4-794495fe3c9d	2026-01-07 16:19:51.886543+00	11.1	33.2	302210	302210
41f09198-c3e9-4b53-ad3d-2ad4460773c7	2026-01-07 16:20:51.899447+00	7.7	33.3	269108	269108
25bd5960-ea45-41cf-bb7c-7e6d0dde3017	2026-01-07 16:21:51.891671+00	8	33.3	355317	355317
c341cda7-2e64-4e5d-bc18-53e59512e36a	2026-01-07 16:22:51.907009+00	7.7	27.4	214914	214914
2cc6a751-fc1d-4418-9567-f2e0c817be0c	2026-01-07 16:23:51.892927+00	7.4	27.7	259197	259197
d43748fe-edfc-4149-958d-0014ee2e038d	2026-01-07 16:24:17.62575+00	10.6	30.1	692147	692147
e965c5f3-2fe8-4304-8076-0d3d4913e778	2026-01-07 16:25:17.602069+00	8.6	34.2	833498	833498
b78ed647-669a-427d-891d-515ee991c4ac	2026-01-07 16:26:17.728128+00	7.6	34.2	233838	233838
174c5075-30ac-429f-b086-cfc26a7696f8	2026-01-07 16:27:17.641851+00	7.2	35.1	307909	307909
da394855-0b61-4766-87f9-0e9ec63bd031	2026-01-07 16:28:17.624741+00	6.6	35	744187	744187
cebf9927-0e53-44a9-948d-4d902ad5d025	2026-01-07 16:29:17.630275+00	7.2	31.3	637165	637165
87089a3f-f4c8-47f7-86a5-d7b97592cbdb	2026-01-07 16:30:17.617719+00	26.5	33.6	852425	852425
2c0839fe-2e84-430f-88ab-b69c237b91a1	2026-01-07 16:31:17.618067+00	8.5	33.7	666663	666663
c7e56aa0-d24a-4fc4-8058-4fba7698d877	2026-01-07 16:32:17.631911+00	11.8	33	687838	687838
0e78d909-ef53-4c0f-a75c-c55283a463d3	2026-01-07 16:33:17.618498+00	11.5	33.9	633300	633300
4dcf7c19-720c-4b96-898c-e0803a9103e1	2026-01-07 16:34:17.592749+00	7.6	33.9	781710	781710
4d5515f3-0552-4ece-bd52-902a93b9eb1e	2026-01-07 16:35:17.607408+00	9.4	30.3	668956	668956
8f387254-6a0d-43c6-aa3d-cbfa13ad1d13	2026-01-07 16:35:51.884759+00	12.1	31.8	217497	217497
66eceeb6-e12c-4ac4-84a6-4a6111620d88	2026-01-07 16:36:51.87932+00	7	33.6	326902	326902
ba09b85a-f5d8-4347-b800-2702b2cccfa2	2026-01-07 07:12:09.954807+00	8.2	22.5	758942	758942
cd209809-0c18-41ca-9481-795e889b599b	2026-01-07 07:12:53.661694+00	13.1	22.3	42003	14139
f0488657-1e1f-498d-8790-d9dfc0485cae	2026-01-07 07:12:58.3639+00	10	22.3	332524	332524
0fbd23b0-7100-45c7-9fef-c53f3ed56627	2026-01-07 07:13:09.068903+00	22.4	22.4	961425	961425
f77663f2-976d-4cc0-908b-6f729b2301b8	2026-01-07 07:13:53.665761+00	13.4	22.3	74185	20083
0a18ed58-cd64-4cf6-bbde-713965c3d080	2026-01-07 07:13:58.555668+00	9.7	22.4	307558	307558
5c132298-65df-4dd6-80f5-c98e58e339cc	2026-01-07 07:13:59.610955+00	8.1	22.3	376483	376483
f3a66ece-8811-4e86-8955-4be06b84a4b8	2026-01-07 07:14:09.311934+00	6.7	22.4	491401	491401
31e54958-cabb-4ac7-a90e-33960861d1f1	2026-01-07 07:14:10.169046+00	23.2	22.4	1064431	1064431
6309a536-110c-4781-b9a7-dbf8ce9c2263	2026-01-07 07:14:53.684177+00	15.3	22.4	85526	23659
b9fd255c-9cba-4c32-9803-ba2897f227ef	2026-01-07 07:14:58.574996+00	7.7	22.4	891897	891897
7b8feb64-9787-4c00-8bd5-ee9514e2d9bd	2026-01-07 07:14:59.566303+00	7	22.4	464954	464954
d3666fa2-9454-43ab-a442-894bce21837b	2026-01-07 07:15:10.009061+00	17.8	22.4	772677	772677
2fda13ae-bb11-4716-8182-2d0d9527ddb6	2026-01-07 07:15:53.686859+00	12.1	22.5	165930	84996
5fb4aadb-38a1-46be-a02b-00aaf531d0a2	2026-01-07 07:15:59.869161+00	5.9	22.4	449340	449340
bcd595eb-1017-403c-8c33-b897c568407d	2026-01-07 07:16:53.692827+00	10.2	22.4	148170	84088
97a1cf5e-804c-464c-a0d2-1a9d529e5210	2026-01-07 07:16:58.325611+00	9.1	22.5	463563	463563
ffa52caa-ebe3-4264-8483-d6adad7492e1	2026-01-07 07:17:53.706769+00	13	22.5	70840	70784
63c453b3-9bc7-4e4c-a37d-47cb1205f919	2026-01-07 07:18:00.081934+00	8.1	22.5	309687	309687
65aa609e-8a35-4b7b-973f-143a809555ad	2026-01-07 07:18:10.534639+00	22.9	22.5	891800	891800
6212d99b-e775-442f-850f-e9b4b2200a9a	2026-01-07 07:18:53.711433+00	12	22.5	72109	69763
11583f51-de3a-42ed-8f65-0649f1288214	2026-01-07 07:18:58.442189+00	8.7	22.5	480437	480437
85ac65e9-613e-4387-b071-fc4467f31696	2026-01-07 07:18:59.68724+00	6.7	22.5	639180	639180
af227294-de39-4835-a54b-e677bb0a4fb2	2026-01-07 07:19:09.136769+00	18.1	22.4	876334	876334
d4f82723-9e18-47e3-afd0-ace9f6b26fa6	2026-01-07 07:19:53.698351+00	19.3	22.4	77807	39827
b1887bf2-2edf-4fa1-bb2d-f8a5c21c5786	2026-01-07 07:19:58.773162+00	8.9	22.4	708764	708764
9999bcd4-5634-4cca-944b-ffafe039043e	2026-01-07 07:20:00.082986+00	7.2	22.4	307406	307406
2f8d0d73-6548-4284-a365-8283c9796b73	2026-01-07 07:20:53.735921+00	12.1	22.5	130237	67527
830c0a63-9a90-4e6b-a988-66f0f2b7319b	2026-01-07 07:20:59.528217+00	7.1	22.4	288736	288736
9cc7af71-111e-46e0-9b54-43095e03d601	2026-01-07 07:21:32.27686+00	11.2	22.5	828207	828207
fe44bf81-4f38-4721-96fb-7295108f4a9c	2026-01-07 07:21:53.749591+00	13.5	22.5	130652	67786
c768de36-768e-4517-800f-e187d1ce62ac	2026-01-07 07:21:59.540992+00	8.8	22.5	526177	526177
7f5c80ce-ba03-47d3-bf63-7cc12ded8b1a	2026-01-07 07:22:11.334357+00	71.9	22.4	595381	595381
b48c36e9-971a-4058-b4e6-13d309397c61	2026-01-07 07:22:53.762901+00	18.9	22.5	90307	67352
c7b6c994-475e-4ced-a83e-7c3eaa806d3b	2026-01-07 07:22:58.595712+00	10.2	22.5	728325	728325
4f60dfeb-f40f-4121-9736-733552ba0f02	2026-01-07 07:23:09.370971+00	8.8	22.5	828753	828753
f78cc748-39b4-4ace-8017-aa288c7bff45	2026-01-07 07:23:11.803149+00	71.2	22.4	595112	595112
07ee3a42-6a48-4ac5-a937-65e220114bb5	2026-01-07 07:23:32.198151+00	6.5	22.4	566644	566644
85f95b50-9d2e-401b-957a-861bb0fcbe41	2026-01-07 07:23:53.763745+00	19.7	22.5	62815	61658
6a1b937e-0013-412c-ba7b-4894018e8a42	2026-01-07 07:23:58.248865+00	8.8	22.4	533175	533175
aa405ce2-7157-483a-bcc2-edac5fba9ac6	2026-01-07 07:23:58.257772+00	8.8	22.4	715159	715159
2ff93193-d078-4765-9dd0-7dbafb4fdea8	2026-01-07 07:23:59.420958+00	9	22.4	202572	202572
4bfe74ed-a858-408a-ab7c-2a5fa170febc	2026-01-07 07:23:59.425592+00	9	22.4	348917	348917
4965786d-fcaa-48ca-b0ee-eed7121ba782	2026-01-07 07:23:59.511894+00	9	22.4	541214	541214
7273f628-c9d2-45ea-b7c1-f6567c42ca6e	2026-01-07 07:24:09.075429+00	9.3	22.5	1308874	1308874
a341c2dd-1b85-4831-ac61-592f4f177ed4	2026-01-07 07:24:09.109647+00	9.3	22.5	879075	879075
83142927-0abf-48d6-8108-ef9abd9b1db6	2026-01-07 07:24:09.86903+00	9.3	22.5	1334234	1334234
5df1ed3f-07f7-4487-83ff-284e99b6ed43	2026-01-07 07:24:11.319464+00	24.8	22.7	749235	749235
9fd83015-e716-496a-be70-fbfbbe6f5761	2026-01-07 07:24:32.191296+00	10.2	22.4	777065	777065
be57cbad-9633-4470-a71e-f94138624042	2026-01-07 07:24:53.77951+00	12	22.5	112323	64609
86ef6033-d29f-4d4b-bd0d-7f18c83e6aec	2026-01-07 07:24:58.441757+00	9.1	22.4	541507	541507
0be7b105-8035-4fee-8392-177b44d8798b	2026-01-07 07:24:58.480071+00	9.1	22.5	661408	661408
ece7adba-575a-425c-9362-f0354d0028e1	2026-01-07 07:24:59.607281+00	7.7	22.5	260416	260416
99e592ab-a6fd-464c-8596-ba7445356e9c	2026-01-07 07:24:59.608622+00	7.7	22.5	403478	403478
8a460969-449c-428d-92b7-af22fda885b5	2026-01-07 07:24:59.781854+00	7.7	22.5	652005	652005
72612f51-e0bd-4148-8408-3ef0ec114ac7	2026-01-07 07:25:09.274141+00	16.5	22.4	727082	727082
f53ad6d1-756c-4baa-8134-5f8f83b174da	2026-01-07 07:25:09.275186+00	16.5	22.4	1666001	1666001
6d0a4197-c17d-45de-a6cd-b29ae36a7e43	2026-01-07 07:25:10.194555+00	16.5	22.4	1022830	1022830
ecfb1eae-3cf1-43be-8529-887efcb890e3	2026-01-07 07:25:11.553733+00	32.4	22.4	730906	730906
6d49f54d-2053-4767-bcde-cc4121a4843c	2026-01-07 07:25:32.325075+00	23.5	22.4	866591	866591
23a27f9f-49f5-40b8-9fac-5d7eea5c81ec	2026-01-07 07:25:53.780213+00	11	22.4	119261	62996
7c102a6d-e40d-4cd9-a255-21932a746a62	2026-01-07 07:25:58.396883+00	9.7	22.5	571836	571836
ceec2769-d569-46d4-9f6a-987a65f56a9b	2026-01-07 07:25:58.512186+00	9.7	22.5	746430	746430
1e0221ca-ec38-4056-9f09-7d9cb922b6ec	2026-01-07 07:25:59.664971+00	10.1	22.6	245122	245122
27e5087f-d329-48b0-8ff3-e713e791d16b	2026-01-07 07:25:59.708908+00	10.1	22.6	498284	498284
ea827fa1-bfac-4325-aad5-54fae098d638	2026-01-07 07:25:59.741326+00	10.1	22.6	666964	666964
2c9b1686-3d0b-4733-a51c-5fa593ed8fd3	2026-01-07 07:26:09.23398+00	7.8	22.4	535215	535215
6cf1c10c-6e8e-4a36-b19e-3cfe1a4f07bd	2026-01-07 07:26:09.236579+00	7.8	22.4	642046	642046
549830f0-75d7-4094-b85a-27c3b5e0d4b1	2026-01-07 07:26:10.066641+00	7.8	22.4	1135864	1135864
87a7c53d-f6eb-4126-a31a-b7b2222c349d	2026-01-07 07:26:11.509733+00	72.7	22.4	358286	358286
693320aa-64cf-4848-8835-f99ef283ee69	2026-01-07 07:26:32.312389+00	10	22.5	586075	586075
d68245be-1213-45af-96e6-627ca04a953c	2026-01-07 07:26:53.793937+00	12.1	22.4	103450	55950
05afa105-02dd-4f85-b6c4-c8107cfddc49	2026-01-07 07:26:58.347221+00	12.1	22.4	379150	379150
93f0aa4c-64dd-49ae-b5a1-8c282b82b3e1	2026-01-07 07:26:58.388123+00	12.1	22.4	680317	680317
7fdab9aa-bcdd-470c-8f11-0b1e44108b0c	2026-01-07 07:26:59.469185+00	6.6	22.6	347443	347443
f516d4c1-699b-434e-ad70-225a4833f69e	2026-01-07 07:26:59.469988+00	6.6	22.6	202104	202104
451083a4-f9bc-4175-84d4-d72a6efedc8b	2026-01-07 07:26:59.562224+00	6.6	22.6	517828	517828
8b2f850c-17b6-4538-aa0c-5e05daf90f84	2026-01-07 07:27:09.022828+00	21.3	22.4	737921	737921
eae3b5a3-8c08-4467-9de3-3969968fed88	2026-01-07 07:27:09.025532+00	21.3	22.4	454574	454574
1c1ff47a-46c4-484d-9c3c-1544e2283b9d	2026-01-07 07:27:09.887657+00	21.3	22.4	857171	857171
7ad659dd-bf09-4f23-b30f-f568b119765f	2026-01-07 07:27:11.269322+00	23.7	22.5	897723	897723
f732d510-2471-4272-9dff-cb4d539ed763	2026-01-07 07:27:32.291149+00	24.1	22.5	928615	928615
b4d36e66-5f14-46c9-93d5-1678dac2a249	2026-01-07 07:27:53.77454+00	17.3	22.4	83509	61142
9846193e-c002-48cd-b46e-b730662cdfea	2026-01-07 07:27:58.35598+00	9.2	22.4	748403	748403
40f478ea-e503-4d2c-99b7-9770c0a14010	2026-01-07 07:27:58.397503+00	9.2	22.4	776294	776294
37268bf0-388b-4ba4-b6a4-6487fc213180	2026-01-07 07:27:59.434138+00	7.9	22.4	214266	214266
5d7a6b37-8c46-4359-a79a-32166709b61b	2026-01-07 07:27:59.445451+00	7.9	22.4	335678	335678
57c9f838-d8b8-4dc1-a368-b88fa864ac16	2026-01-07 07:27:59.527556+00	7.9	22.4	612891	612891
f7bf01ff-7076-4dfb-95b4-99279fa9a84b	2026-01-07 07:28:09.042922+00	13.9	22.3	599589	599589
f9fb3277-534f-4386-bb15-bef99f5ae966	2026-01-07 07:28:09.101472+00	13.9	22.3	208124	208124
ae69da1a-fa30-4f34-a51d-eecae8c3d119	2026-01-07 07:28:09.963278+00	13.9	22.3	855321	855321
0bbfcef5-a7a3-4e89-afd7-27352c67ddb4	2026-01-07 07:28:11.492745+00	17.5	22.2	647485	647485
6fbdc3fa-9eda-4c4b-84f3-7c6e64372e22	2026-01-07 07:28:32.323885+00	16.9	22.4	931235	931235
79b85cda-6c90-4c97-bea4-42ab73729cc4	2026-01-07 07:28:53.821784+00	13	22.4	77220	55790
386fd723-45f8-42a6-baf9-2bc7c4605dbf	2026-01-07 07:28:58.626989+00	8.8	22.4	580145	580145
f52d63e8-716a-4826-9165-cd82ed8f7113	2026-01-07 07:28:58.67397+00	8.8	22.4	639999	639999
47909a04-4b93-435b-ad16-2948830e79c9	2026-01-07 07:28:59.816095+00	8	22.3	409101	409101
a05a0902-c0a2-4194-bf8d-42c32e191bf2	2026-01-07 07:28:59.81841+00	8	22.3	563957	563957
c1cb8b14-e461-47e4-80fe-39af323f4323	2026-01-07 07:29:11.751517+00	72.3	22.4	625529	625529
9a9660e9-aaad-4ae6-9050-8173524957db	2026-01-07 07:29:59.628433+00	8.3	22.4	515458	515458
6ce4f196-5b00-47f1-802f-603d5c589e21	2026-01-07 08:17:54.221629+00	7.3	22	13030	7286
e8126528-8156-4c33-812b-adc79eb38b58	2026-01-07 08:54:53.285455+00	24.8	30.2	214179	214179
5d548b9e-2c50-4f93-82af-bb6b421c76c2	2026-01-07 09:42:12.275384+00	7.6	24.6	18972	18742
6e0c9bce-322a-4004-92c0-252134538c5e	2026-01-07 10:00:12.490561+00	5.2	26.3	5793	60207
eea4051a-697a-4197-8855-d786214a0b6d	2026-01-07 10:20:51.868296+00	12.4	30.4	435688	435688
42a398de-4773-41b9-998b-f4cb24fe2a87	2026-01-07 10:21:52.07128+00	22	31.3	52534	52534
7c103f33-b286-4cf2-80e9-8186a9e15c69	2026-01-07 10:22:52.018437+00	18.9	31.2	59246	59246
470ce87e-54c5-4ea1-ba3b-2a5a166e0488	2026-01-07 10:23:52.058542+00	7	31.3	65535	65535
0b98a935-813c-4066-b9a3-212b34500ea9	2026-01-07 10:40:13.085154+00	7.7	26.4	5214	3480
32065ce0-8ee9-4c55-9940-ce01b5d41dc8	2026-01-07 10:57:52.067648+00	18.5	30.2	129334	129334
faee4ed6-45a5-4cd7-85d0-11ea843335ce	2026-01-07 11:15:13.480632+00	25.6	33.9	358633	92331
732bbb23-79ac-4503-96ac-986708f589d2	2026-01-07 11:33:51.943809+00	5.2	27.4	143867	143867
90be5e68-afe3-4a3d-9140-bd9a444da50a	2026-01-07 11:34:47.465973+00	10	29.7	424436	424436
aebf6f8a-31e7-4919-ad0a-744229864561	2026-01-07 11:34:51.88809+00	16.2	30	1171930	1171930
42653966-7daf-4858-b5b5-f9caf8417413	2026-01-07 16:09:51.880212+00	30	31.7	317173	317173
1e9dbc39-e8f1-4dfd-9764-5c4ef289c433	2026-01-07 16:10:51.869626+00	46.4	32.5	330549	330549
7c290a02-1172-4bb6-a21a-8932b97c66e3	2026-01-07 16:11:17.618519+00	35	34.2	493282	493282
76b632dc-ddcd-45e8-855e-c15fd7a3efb2	2026-01-07 16:12:17.620468+00	31.1	31.7	771703	771703
dcd7096e-c972-444f-9abb-83bdaeb1b76a	2026-01-07 16:13:51.865563+00	28.9	31.9	325472	325472
a2b7d11f-c8ce-47c9-a180-5590c4edd743	2026-01-07 16:14:51.854964+00	30	31.8	289264	289264
c7c0c767-4957-4c37-a199-8cb108c1bdfb	2026-01-07 16:16:17.613163+00	30.1	31.9	753889	753889
d81eefba-33a6-468a-adc3-274788ad9869	2026-01-07 16:17:17.640847+00	30.5	31.8	615248	615248
aca810a1-26a0-4329-9365-226910f51413	2026-01-07 16:18:17.618049+00	27.9	31.9	296237	296237
a19d37c2-d4b4-413e-b2b2-82d5c9ebe087	2026-01-07 16:19:17.61519+00	29.7	32.5	552821	552821
c8186282-8fc6-4cfd-9ed6-7a0315771614	2026-01-07 16:20:17.616318+00	7.8	32.7	837277	837277
42130e66-87eb-4aaa-833e-e5e232e8a588	2026-01-07 16:21:17.613168+00	5.4	33.3	567791	567791
11dff457-e923-4200-80c3-f5c1c3d710bb	2026-01-07 16:22:17.663786+00	7.2	33.3	604391	604391
76588978-9d91-4689-a0b5-b337413ae8bb	2026-01-07 16:23:17.605097+00	7.2	27.5	917277	917277
94bafb6e-8163-4556-8674-17eec8386fad	2026-01-07 16:24:51.940147+00	11.9	35.1	66321	66321
53d8f04d-53b0-4350-8d17-7f800a110f0f	2026-01-07 16:25:51.875684+00	7.6	34.3	250516	250516
49487465-e347-46c9-a023-f3ee086f92ef	2026-01-07 16:26:51.908459+00	8.2	34.9	276519	276519
0fa0f280-340c-4a64-8b25-8b93bdf6fe25	2026-01-07 16:27:51.886726+00	7.9	35.1	358304	358304
9306fb8f-9f1b-4511-b0d8-086fd4e6a039	2026-01-07 16:28:51.876425+00	8.5	31.3	379662	379662
b1e27e04-5ddb-482b-a158-d3a99d569f64	2026-01-07 16:29:51.862481+00	22.4	34.9	301315	301315
03302e28-a0b2-42c9-ae44-247a3d8e6239	2026-01-07 16:30:51.879431+00	28.1	33.6	170725	170725
426c66e7-c09b-4a01-9dda-23ece8c8ead2	2026-01-07 16:31:51.905205+00	20	33.3	303816	303816
531d8371-ea90-457b-b7db-9fd37a583282	2026-01-07 16:32:51.907231+00	8.7	33.1	156805	156805
ca4d6fe4-8650-480d-8ff9-3488d7259c16	2026-01-07 16:33:51.934526+00	8.1	33.9	177201	177201
4375e51e-b1eb-49af-b739-74e14b6ce3cb	2026-01-07 16:34:51.896915+00	10.9	33.8	258364	258364
4f494658-1625-4b95-9ddf-cc1c1b68d765	2026-01-07 16:36:17.653311+00	8.7	32.1	327669	327669
4efb9635-c022-4f96-b50d-fdb6d8bc1a2a	2026-01-07 16:37:17.653996+00	6.6	36.3	302606	302606
421a1384-fa2c-44a4-9c54-8428236774e0	2026-01-07 07:28:59.99226+00	8	22.3	926372	926372
4345a567-b464-4e4f-aa59-b15b23d1d4bd	2026-01-07 07:29:09.536476+00	7.1	22.5	797201	797201
85a9715e-aa94-48db-bac5-ac5944eefd3b	2026-01-07 07:29:58.41439+00	7.8	22.4	249604	249604
abbbc9ac-af3a-4f80-a1f8-d65d4259def8	2026-01-07 07:29:59.513692+00	8.3	22.4	394936	394936
271c5228-4997-41ba-9d16-30290469f6dd	2026-01-07 07:30:10.062999+00	12.7	22.3	1089771	1089771
dce8c9e8-562f-4fcd-a4b0-28f6bd1ba962	2026-01-07 07:30:59.593138+00	7.9	22.4	274754	274754
5eb97496-2aa2-43c2-9cc3-968b3e2f5615	2026-01-07 07:31:11.489906+00	33.3	22.5	642036	642036
cfa60fa3-d182-4d40-8338-63e956423e67	2026-01-07 07:31:59.728024+00	8.3	22.5	408947	408947
ba638cb0-dd6d-41ea-9efe-d9ae72937dcf	2026-01-07 07:32:09.183379+00	14.7	22.4	442285	442285
885863f4-558e-4774-af63-241d43467c76	2026-01-07 07:32:58.584162+00	8.8	22.5	488740	488740
626bb8f0-3b80-4b86-bbd6-fee65d773418	2026-01-07 07:32:59.649984+00	7.9	22.4	296540	296540
6d32d53e-1beb-476d-8e53-9565b300b1c3	2026-01-07 07:33:09.320992+00	7.4	22.6	760018	760018
c486d048-f68b-42c3-b0e8-8ad736e93a09	2026-01-07 07:33:11.642735+00	22.1	22.6	562041	562041
9f6607df-325b-4ef7-b597-2cb3711e71ef	2026-01-07 07:34:58.38115+00	9.2	22.6	689952	689952
7d941e51-66cf-4e9d-abf2-c7325b7dfacd	2026-01-07 08:18:54.235558+00	9.3	22.1	13506	6508
900ffb7e-28aa-490d-b49c-5cd50386e7e0	2026-01-07 08:54:54.586897+00	24.8	30.2	13763	44494
1193ccdf-29eb-4f42-8ae1-b76a5bba268a	2026-01-07 09:43:12.279248+00	6.3	24.6	2954	2366
91657b8e-359d-4b41-a1ca-35dcdd0f7ff5	2026-01-07 10:01:12.508849+00	8.4	29.3	10588	68101
b4450de9-37d3-478d-874f-80e849c8c098	2026-01-07 10:21:12.824037+00	27	30.5	936093	140662
96223cf4-ebd3-4210-bbbc-a70fbd81d29e	2026-01-07 10:40:52.253671+00	4.8	26.4	86985	86985
cf788ae1-e46e-418e-982c-65ddf7d64217	2026-01-07 10:57:52.070623+00	18.5	30.2	141113	141113
59e4a475-ef44-482b-b8b3-d23710e3358d	2026-01-07 11:15:35.864316+00	12.9	34.1	132393	132393
b2325268-8b53-4d6b-b83d-90c119fa3d5b	2026-01-07 11:34:13.772651+00	10.2	27.5	7627	4877
6a489331-4208-46a7-b8db-d66fb6a8b15f	2026-01-07 16:37:51.889338+00	8.7	36.4	338022	338022
71231577-10b7-4fe7-abd2-9e47fd93348a	2026-01-07 16:38:51.886175+00	8.3	35.6	260291	260291
ed79f6bc-2345-48e4-ba15-150dc73ef427	2026-01-07 07:29:09.548599+00	7.1	22.5	863977	863977
3135aef6-dd92-4bad-851c-629cb1e57274	2026-01-07 07:29:10.428593+00	72.3	22.4	748948	748948
97d2239d-9d2b-4bc9-83db-10a8a2c79fc4	2026-01-07 07:30:58.248363+00	8.6	22.5	469398	469398
db3dcc38-57bc-48f3-8a07-dd5ab638bbdf	2026-01-07 07:30:59.592274+00	7.9	22.4	632956	632956
17c4105b-6a5b-490d-a6f8-302fac78b78b	2026-01-07 07:31:59.630348+00	8.3	22.5	397560	397560
2876e540-a366-497d-a302-07e4f1b9c105	2026-01-07 07:32:09.186072+00	14.7	22.4	434105	434105
fa989524-69db-4ec2-8e48-c463805a24f7	2026-01-07 07:32:59.647084+00	7.9	22.4	313369	313369
9dcf5e0a-9a48-4076-a7e3-a689c33dec03	2026-01-07 07:33:58.729342+00	8.1	22.5	592732	592732
f64efd89-5d16-4d50-a205-6b6acc24a859	2026-01-07 08:19:54.248487+00	7.4	22.1	17858	10105
9bf2a697-2332-4c16-82b5-1e55c2da41d3	2026-01-07 08:55:54.601612+00	26.4	30.8	9492	37245
16e09a29-84bc-4339-89ee-efe5e162c990	2026-01-07 09:43:52.247262+00	6.6	24.6	89251	89251
d615b4bb-1078-4c7d-b4e1-0bba011f3136	2026-01-07 10:01:48.89658+00	15.5	29.7	1179	1179
3185521c-d998-49ec-ada7-a8f68fab1566	2026-01-07 10:01:52.359328+00	11.7	29.7	422184	422184
7e7733d1-0afe-447d-8309-16b76318fb4b	2026-01-07 10:22:12.776646+00	6.3	31.2	12184	3849
e9a073fa-61c2-441a-94ec-09bd672018ba	2026-01-07 10:40:52.253744+00	4.8	26.4	114988	114988
e84fbe72-8acc-4bce-a115-6c6c502f6cde	2026-01-07 10:58:13.30196+00	8.6	30.3	6703	4467
cae6f8c4-5bbe-4741-ac42-3d359009f92e	2026-01-07 11:15:52.0838+00	34.7	34.4	282999	282999
accc0a3a-c06a-4efe-82e0-18a5dae72565	2026-01-07 11:35:13.791168+00	23.1	31.8	1140753	95518
099405d5-8881-4df8-ab40-2a48dd9323cc	2026-01-07 16:38:17.634239+00	13.5	35.5	346397	346397
f1cfbfc2-4272-408a-9b4f-743cb47c6d95	2026-01-07 07:29:32.294392+00	8.8	22.4	800334	800334
42a5a129-1462-4d4a-afd5-2ba770802633	2026-01-07 07:29:53.83415+00	19.7	22.4	136068	76113
6e3c87ac-059d-4887-83cf-b124c7debd5b	2026-01-07 07:29:58.31905+00	7.8	22.4	683104	683104
46b6b3ca-040c-4438-9a91-d8b1d11288f2	2026-01-07 07:29:59.513692+00	8.3	22.4	584781	584781
3c10ca49-db64-43a6-a71d-304102dcd96f	2026-01-07 07:30:09.126195+00	12.7	22.3	1147501	1147501
0101e44c-8d18-46da-888f-96902fd50542	2026-01-07 07:30:11.44815+00	33.8	22.3	665047	665047
30b0b7eb-de21-4daa-9627-930e450ea38f	2026-01-07 07:30:32.286605+00	7.9	22.4	841896	841896
f6b3b27e-4ec8-4e49-b362-00f711f4be88	2026-01-07 07:30:58.313214+00	8.6	22.5	473080	473080
10c1a7d3-c279-491b-967c-dd4fccaa265b	2026-01-07 07:30:59.688153+00	7.9	22.4	687441	687441
8db52b83-473a-4e3e-b306-47717db8246e	2026-01-07 07:31:09.173765+00	16.6	22.5	503961	503961
a55a6856-7bdb-4fbf-b172-6e5f32245400	2026-01-07 07:31:09.175982+00	16.6	22.5	458605	458605
202a3cc2-b0ed-43d9-a046-0ff9dacb8632	2026-01-07 07:31:32.198495+00	21	22.5	766928	766928
ea77c979-3cd7-4e49-a435-3aae7699a233	2026-01-07 07:31:58.52191+00	9.3	22.6	244023	244023
3128cd8b-fb79-47a1-a4aa-b6ffd6676378	2026-01-07 07:31:59.591797+00	8.3	22.5	383485	383485
0544cd5a-a7aa-498c-a8cd-f53bcc802dd0	2026-01-07 07:32:11.371858+00	17.9	22.4	738905	738905
f3a05f5a-e6c0-4c8b-9754-422ac7857fe4	2026-01-07 07:32:58.511942+00	8.8	22.5	320877	320877
d05f4679-b4c6-4edd-a16f-d6b5fb826898	2026-01-07 07:32:59.822565+00	7.9	22.4	459487	459487
502df729-f4a7-42e5-af87-b9864f9d9675	2026-01-07 07:33:09.323238+00	7.4	22.6	801230	801230
43d3efa6-635b-4eae-98ee-bfd5a91cf59c	2026-01-07 07:33:32.378602+00	18.5	22.5	687245	687245
7a4460a4-4f1f-4a54-8462-8bcd27af97cb	2026-01-07 07:33:58.637814+00	8.1	22.5	620489	620489
f2045218-aaf4-4934-855e-9e4525beafa1	2026-01-07 07:34:00.001577+00	8.4	22.5	601636	601636
0f322efd-175e-4ccc-a68a-31fa9441d8c4	2026-01-07 07:34:11.825478+00	30.5	22.5	909161	909161
0a544ae5-9d5e-4fa1-97ca-1f2813fce4b7	2026-01-07 07:34:58.333241+00	9.2	22.6	473334	473334
f28420c4-8874-4cd5-9a82-6b9a97797704	2026-01-07 07:34:59.426279+00	8.2	22.5	344054	344054
14b201f7-2e32-46f2-9b52-d65bc3cadcf9	2026-01-07 07:34:59.512405+00	8.2	22.5	647894	647894
d0de9d49-88ac-4fbf-bfbe-36bda98bc9d5	2026-01-07 07:35:09.025726+00	14.6	22.6	708825	708825
40a16fda-efa5-4a93-b5d6-c212402ccbd3	2026-01-07 07:35:11.470582+00	72	22.5	424266	424266
3529423f-e8dd-4eff-9fa8-938670dcc685	2026-01-07 07:35:58.460911+00	9.4	22.5	1421536	1421536
cceeed7f-66df-4366-b3ef-13503bbd8a62	2026-01-07 07:35:59.633676+00	8.4	22.5	575382	575382
6d6ee84f-fa71-4c2d-8370-727ebc5b8393	2026-01-07 07:36:58.494736+00	9.3	22.5	742580	742580
ee38f61f-227c-42a9-bb55-109958760352	2026-01-07 07:36:59.838714+00	8.1	22.5	494301	494301
f274494e-28db-4274-a66f-6a6bbb2f7e0b	2026-01-07 07:37:09.337976+00	21.4	22.5	772207	772207
d3883563-7eab-4210-942d-27f61b892cc7	2026-01-07 07:37:10.169072+00	21.4	22.5	1094400	1094400
af6a6319-d5f6-40d9-a108-7ee12b5562e9	2026-01-07 07:37:11.575267+00	16.3	22.5	897383	897383
646a330c-744d-4730-beb2-98078e4b387c	2026-01-07 07:37:58.430479+00	8.9	22.5	667955	667955
1b831f94-9377-4ac9-9b6c-51b796045f8d	2026-01-07 07:37:59.834988+00	9.6	22.5	522779	522779
db464de7-9c6d-4693-ac4f-44cb6ea0987c	2026-01-07 07:37:59.884863+00	9.6	22.5	591866	591866
c82573e1-a900-43ab-acf4-6e2f2ec757a3	2026-01-07 07:38:11.696222+00	32.1	22.5	541441	541441
5c82d05e-da1c-4d28-a659-0d2e6213d464	2026-01-07 07:38:32.217462+00	10.3	22.5	800516	800516
67bf2b07-f1e0-40f8-af18-f5971dab63d3	2026-01-07 07:38:59.390873+00	8.2	22.5	477961	477961
c07577de-9ecf-4ac1-85b5-c31d1d5d8f61	2026-01-07 07:39:08.87947+00	15.1	22.5	933672	933672
2d22806e-f76f-4190-b4be-4a8516abce2a	2026-01-07 07:39:58.788694+00	8.4	22.5	810210	810210
79695735-ff7e-49e9-aa94-3ff9524961eb	2026-01-07 07:39:59.735467+00	10.4	22.5	595682	595682
6e95f168-07cf-491a-aeb0-6da685cfa634	2026-01-07 07:40:10.237653+00	8.2	22.5	928472	928472
31a44334-c7bb-40e0-9d2c-094d7d6e349f	2026-01-07 07:40:59.468869+00	8.3	22.5	599342	599342
3f59c604-774f-4e76-92fb-2c70966fe14d	2026-01-07 07:41:08.987737+00	10.9	22.5	481240	481240
1d7c1129-ac54-4cd7-9bee-abc50734cc75	2026-01-07 07:41:09.780519+00	10.9	22.5	637977	637977
8ee27194-ee4b-44a4-8836-0a25e8f2372c	2026-01-07 07:41:32.254294+00	19.1	22.5	1243129	1243129
7f26a2c9-9b12-4535-8660-6191c21241c8	2026-01-07 07:41:58.42115+00	10	22.5	177899	177899
925ac173-4d92-4cf8-97fa-863e7a9731ea	2026-01-07 07:41:59.95771+00	10.1	22.5	281886	281886
3a624bc8-56fb-4107-92b7-ae084b57192f	2026-01-07 07:42:09.632356+00	16.8	22.6	300105	300105
17908c15-a8fc-4cb5-9237-3d618902bdcf	2026-01-07 07:42:10.484327+00	22.6	22.6	1074412	1074412
eb76310d-59ce-41e1-9ed3-8e6234d9089f	2026-01-07 07:42:58.924712+00	10.2	22.5	659269	659269
5f774aed-a8ed-4de7-a7b9-307ff147c742	2026-01-07 07:43:09.707619+00	7.4	22.5	719540	719540
b4d49a51-2932-4e15-8da5-efd0fa92ea66	2026-01-07 07:43:10.531966+00	18.8	22.5	930129	930129
47ea5c7b-b64d-44b0-b9cb-66b04eec849d	2026-01-07 07:43:58.444038+00	10.1	22.4	290569	290569
21771a07-fc8d-4f1e-825d-c2be5b1bd513	2026-01-07 07:43:59.667298+00	10.1	22.5	630317	630317
d1b898be-94d1-4563-96f4-897dc6fd3ae0	2026-01-07 07:44:09.189031+00	21.8	22.5	930318	930318
b646b0ed-aad2-4e13-9abd-fe22e7482d02	2026-01-07 07:44:58.476453+00	8.7	22.5	613451	613451
7cd5287c-debc-477d-b86c-4aae8e48a797	2026-01-07 07:44:59.863512+00	9.2	22.5	465542	465542
53767bb7-fb67-409e-ab6a-1e9eac2e356f	2026-01-07 07:45:11.775865+00	22	22.5	685213	685213
bc7d481e-970c-40a4-85ee-06190e964e4f	2026-01-07 07:46:09.571645+00	14.8	22.5	595285	595285
6904dd1a-702c-4b41-855a-14a229d23c60	2026-01-07 07:46:58.392822+00	8.4	22.5	798061	798061
c873ce3a-a318-4bd1-8124-135f38ab56e0	2026-01-07 07:46:59.91726+00	11	22.5	353862	353862
20fe955c-e81b-40b1-8a32-9d61745010da	2026-01-07 08:20:54.245158+00	10.4	22.1	16095	8134
fb7980ac-5c19-49fd-803a-b45184b80857	2026-01-07 08:56:54.619656+00	9	27.4	17429	447036
6ae1339b-09aa-426a-9b2c-1d1a3bcb4564	2026-01-07 09:43:52.247305+00	6.6	24.6	148845	148845
1643414a-30f7-4197-ab02-5385b955526e	2026-01-07 10:02:12.526042+00	6.5	30.1	7613	68000
9b75b821-ca09-49c7-8fb3-b4fa66a8a6d7	2026-01-07 10:23:12.800318+00	8.5	31.2	6465	6560
dd94e7bb-833e-436d-a297-45e4746fe9ed	2026-01-07 10:41:13.073806+00	4.9	26.4	5548	3669
e842f603-040b-45cb-ba1f-991f8109ca18	2026-01-07 10:58:52.082262+00	4.8	30.3	72667	72667
0bf582c1-7869-4775-9d68-da4471797ef1	2026-01-07 11:16:13.494124+00	32.5	33.3	10403	85221
4e1b38b8-ff91-4be4-bdc7-016bef6e9792	2026-01-07 11:35:50.846526+00	20	31.8	549697	549697
cd6df4a8-e8eb-4930-b5c7-4071de58b928	2026-01-07 11:35:51.952726+00	20	31.8	1345621	1345621
43e92bb8-d59c-4b35-aa5a-71131ca85d26	2026-01-07 11:36:50.942119+00	36.2	33.1	3331595	3331595
a3609945-0451-4807-8f11-d9c81694753b	2026-01-07 11:37:45.022268+00	34.5	33.2	2765402	2765402
52382b11-a0a0-47d5-b49d-d88193d80532	2026-01-07 11:37:51.920967+00	33.7	33.7	3459062	3459062
8a755ee9-7855-4946-9ef5-944e9d626372	2026-01-07 16:39:17.616715+00	9.1	33.9	726299	726299
5c11ffa4-3233-4f18-8d47-9cf2d2b2cf29	2026-01-07 07:30:09.128969+00	12.7	22.3	629864	629864
c88087c9-aa20-434b-92b5-4fa59d1e11a8	2026-01-07 07:30:53.841099+00	11.8	22.4	113317	55709
f70b4356-7e0a-48d2-bcc1-3b742009e843	2026-01-07 07:31:10.007074+00	16.6	22.5	936940	936940
338d8377-9054-466f-92b6-3de38b3ab85f	2026-01-07 07:31:53.847907+00	18.6	22.5	120426	69062
addf1b6e-80fb-494b-a4c4-25bb2af3be79	2026-01-07 07:31:58.385412+00	9.3	22.5	296323	296323
a2a5fda3-6c74-4bfd-848d-ab3b99398619	2026-01-07 07:32:09.986678+00	14.7	22.4	1034063	1034063
64f71858-4c3c-4d25-9ef2-9f3aac782399	2026-01-07 07:32:32.308141+00	10.2	22.5	1100905	1100905
8c9a7883-e413-4081-aedf-0ca999ebdfaf	2026-01-07 07:32:53.862051+00	18	22.4	58477	47417
7d84a013-e3f1-4ae6-9ad7-6cfbeb7a59b4	2026-01-07 07:33:10.183322+00	7.4	22.6	820061	820061
9253dcd9-abde-43e9-914a-fd1ca67b9001	2026-01-07 07:33:53.878288+00	13.9	22.5	111292	65823
068462d3-1440-49e2-8051-0a57b6b18b50	2026-01-07 07:33:59.823165+00	8.4	22.5	388320	388320
edc740cb-62d5-4376-bfc7-5af80c5b3990	2026-01-07 07:33:59.824837+00	8.4	22.5	298629	298629
5356afed-6e75-41dc-90fb-6cac2e0891af	2026-01-07 07:34:09.387992+00	13.8	22.5	474558	474558
fb726b51-8268-4d24-acbf-e12c99116d98	2026-01-07 07:34:09.395646+00	13.8	22.5	639714	639714
76aea5dd-f770-4260-ad66-4aa48c68f981	2026-01-07 07:34:10.321497+00	13.8	22.5	1558046	1558046
eba2f30a-0455-4022-93a6-f6b0b22bc154	2026-01-07 07:34:32.218461+00	9.9	22.6	776678	776678
57a9720e-9550-4cbe-b739-3e6d03870d5d	2026-01-07 07:34:53.87889+00	13.3	22.6	96426	48367
167bd394-e549-48b4-85e5-56c58e4346c5	2026-01-07 07:34:59.423073+00	8.2	22.5	216913	216913
3f0f21df-3cd8-4a3a-b229-5893579cd0df	2026-01-07 07:35:09.016749+00	14.6	22.6	643039	643039
ac76587a-1c7e-4eef-91bc-69880b1ecd7b	2026-01-07 07:35:09.951664+00	14.6	22.6	996583	996583
bd56b920-27dd-478b-9ad9-92d77d0ad9aa	2026-01-07 07:35:32.22746+00	13.2	22.5	971678	971678
fed58e41-3047-446b-aa8b-40408f02c295	2026-01-07 07:35:53.880149+00	12.8	22.5	101088	47887
9f850dcf-b8ff-45c4-bb1e-f9cbdc3fab08	2026-01-07 07:35:58.379822+00	9.4	22.5	434986	434986
d232246f-66db-4c43-8a42-b3001ce1ea26	2026-01-07 07:35:59.633672+00	8.4	22.5	408754	408754
7f3f9d66-c3dd-4003-b798-8980acbddb1e	2026-01-07 07:35:59.743588+00	8.4	22.5	529958	529958
77be6968-0e6c-4f3a-acc8-463eb4290169	2026-01-07 07:36:09.330711+00	13.8	22.5	414985	414985
41c749fa-6897-4f80-8d00-68fab6ba31aa	2026-01-07 07:36:09.334923+00	13.8	22.5	656097	656097
2bba0e9e-6643-429c-a48c-c9d397c3663e	2026-01-07 07:36:10.23589+00	13.8	22.5	996393	996393
7db6e75e-3392-4dc0-8e7c-9639073c9501	2026-01-07 07:36:11.620944+00	19.3	22.7	739923	739923
bd40bfea-ecc0-43e1-aa1c-d29a5e00cd3d	2026-01-07 07:36:32.401228+00	23.3	22.4	940550	940550
6b4ca7c4-d8e7-4667-ba16-ea71ac3e2264	2026-01-07 07:36:53.896211+00	17.9	22.5	110242	55707
9991a076-e991-4099-a907-fee1a6e0f6ca	2026-01-07 07:36:58.60351+00	9.3	22.5	330101	330101
71c0f242-22bf-4890-abce-68da957ca206	2026-01-07 07:36:59.67517+00	8.1	22.5	545876	545876
0382f8cf-584a-428c-9b89-b9141a71c973	2026-01-07 07:36:59.764041+00	8.1	22.5	251461	251461
d832fe3b-1532-4720-a78e-9a9f970267d9	2026-01-07 07:37:09.34449+00	21.4	22.5	1039017	1039017
870c4c1c-4db4-4233-9a0a-63933eff7f22	2026-01-07 07:37:32.273468+00	11.1	22.5	684541	684541
142bf59d-52b3-4ad5-8572-07d14ff7049e	2026-01-07 07:37:53.897796+00	14.4	22.4	50337	44700
824e8edb-9f1d-433b-967e-955491bdeb15	2026-01-07 07:37:58.379288+00	8.9	22.5	484115	484115
dd97abb4-b8aa-4a06-8f96-bfba7bcde866	2026-01-07 07:37:59.797982+00	9.6	22.5	553311	553311
a2fe77eb-8062-4251-906e-5cadf42dba55	2026-01-07 07:38:09.359918+00	15	22.4	595717	595717
60f175a1-f0ca-4670-b547-1a98bd35c6f6	2026-01-07 07:38:09.373875+00	15	22.4	737155	737155
fcc6d7a3-9b95-49b7-a8d0-9b71b74fb46c	2026-01-07 07:38:10.279694+00	15	22.4	852547	852547
49f4cdf4-7879-4495-b2ca-fe03e5227eea	2026-01-07 07:38:53.906322+00	10.4	22.4	89792	44510
e107226d-d934-468c-8c81-db1ae1eab84b	2026-01-07 07:38:58.177827+00	9.2	22.5	477090	477090
80cca76d-86ea-4dc3-a0fd-a58d1be65097	2026-01-07 07:38:58.208014+00	9.2	22.5	544921	544921
28f1376e-9d84-43cf-b8df-dae1b1b744dd	2026-01-07 07:38:59.305389+00	8.2	22.5	305916	305916
a36b29e2-d4e5-45bb-ba4b-f001321c1481	2026-01-07 07:38:59.307749+00	8.2	22.5	217371	217371
a4361212-8282-42e8-9b92-e360b6da780f	2026-01-07 07:39:08.882023+00	15.1	22.5	749089	749089
8908f258-00dd-430b-867b-0bb0636f1968	2026-01-07 07:39:09.661481+00	15.1	22.5	1005181	1005181
6ee4c8e6-fb9f-4277-b88c-84dfa9d83e2c	2026-01-07 07:39:11.039738+00	73.2	22.5	777765	777765
b07ba281-78e2-47d0-a252-5a3e4577dfbb	2026-01-07 07:39:32.497285+00	8.2	22.5	1099655	1099655
44928eaa-a032-44c9-b7a2-b67bb3488b34	2026-01-07 07:39:53.920431+00	13.5	22.5	107349	47297
c903eb0f-5fb2-4299-8e12-c0b688a3c241	2026-01-07 07:39:58.782873+00	8.4	22.5	786028	786028
c41cf60f-b2e3-44c6-8912-91317d71feda	2026-01-07 07:39:59.757532+00	10.4	22.5	277559	277559
88aa9c6c-905c-4f46-8117-707e31da517e	2026-01-07 07:39:59.879912+00	10.4	22.5	415762	415762
49124ae1-86fc-4493-96a1-95044d1b6acf	2026-01-07 07:40:09.344948+00	8.2	22.5	516690	516690
77fbea11-29a0-496a-914c-489b2893b614	2026-01-07 07:40:09.345992+00	8.2	22.5	588740	588740
c1d44655-8feb-4de4-8c8e-f58c699cd545	2026-01-07 07:40:11.601788+00	17.3	22.6	562853	562853
ef7d8d2f-2f33-4abc-996a-a98b41b9e6f0	2026-01-07 07:40:32.200643+00	12.5	22.5	768351	768351
faaff13d-2a13-4f8a-90da-739da01d7bb7	2026-01-07 07:40:53.923697+00	12.3	22.5	109736	47614
86778b1a-76e2-430c-9b89-c5c8fc995002	2026-01-07 07:40:58.229826+00	10.9	22.5	304292	304292
9bea7371-1738-44c7-9656-3322be4dcfd8	2026-01-07 07:40:58.369018+00	10.9	22.5	449633	449633
9ff44acc-1f55-49ec-af88-902367447576	2026-01-07 07:40:59.468928+00	8.3	22.5	514243	514243
5329b92d-cc40-48ae-ba72-cf60254c33b3	2026-01-07 07:40:59.555516+00	8.3	22.5	698321	698321
3ef7798f-2eb4-49b4-8969-7d5e32ae3d17	2026-01-07 07:41:08.987167+00	10.9	22.5	1014687	1014687
240f858f-db93-46ae-a490-509d1e02f176	2026-01-07 07:41:11.259259+00	19	22.4	564842	564842
6c3f28f7-982d-4424-8749-80828daa0ffa	2026-01-07 07:41:53.935161+00	11.9	22.4	66658	56352
fa8342d5-b86f-454a-808d-9bd658fd2c12	2026-01-07 07:41:58.522827+00	10	22.5	645259	645259
bb75d386-9ca3-490f-ab49-5330ff94dda5	2026-01-07 07:41:59.890509+00	10.1	22.5	523082	523082
876e6161-7565-44ca-9c8f-efc540e52c43	2026-01-07 07:41:59.999211+00	10.1	22.5	487930	487930
db50ebed-33b9-46d1-8229-0a6311d73c05	2026-01-07 07:42:09.626806+00	16.8	22.6	487295	487295
ac4e63cf-08cc-49cc-b4b8-e9a4c26f1b19	2026-01-07 07:42:11.876815+00	22.6	22.6	631186	631186
063f194b-bd64-4bbd-a8a3-3557a483eceb	2026-01-07 07:42:32.391661+00	8.8	22.5	614171	614171
c1a5f362-c8d1-47e3-8a93-833524baa953	2026-01-07 07:42:53.949189+00	18.4	22.5	98446	43444
d1cdd2df-621c-4d92-a552-92247726ca76	2026-01-07 07:42:58.984793+00	10.2	22.5	772685	772685
b55a3119-880d-4332-8553-59f771eb225c	2026-01-07 07:42:59.992684+00	8.3	22.5	260360	260360
10c0941a-8a05-403a-ad88-e625d0b5c9c5	2026-01-07 07:42:59.993499+00	8.3	22.5	497708	497708
0dd90317-bd8f-48d7-8394-7e8b6acf1bfa	2026-01-07 07:43:00.15096+00	8.3	22.5	437885	437885
0cde9e93-b38b-4e7a-b5d9-a2c041587d68	2026-01-07 07:43:09.70768+00	7.4	22.5	640314	640314
02e13f47-ae8d-4fb0-b65f-d39ebe67eebd	2026-01-07 07:43:11.887891+00	18.8	22.6	552464	552464
e5aa3839-5250-4a3d-9a94-618b4ed15c87	2026-01-07 07:43:32.209036+00	20.4	22.5	887448	887448
47ed5fe3-8fd4-4653-adf6-68a468277394	2026-01-07 07:43:53.961633+00	18.3	22.5	80321	38338
b321f784-3e46-4a1d-914c-ab746f03d8bf	2026-01-07 07:43:58.367422+00	10.1	22.5	270098	270098
39dad673-0a0a-4aa3-b012-a7e509052f4f	2026-01-07 07:43:59.604862+00	10.1	22.5	249003	249003
c100938d-d483-428c-8b5f-08d9c8db365e	2026-01-07 07:43:59.726003+00	10.1	22.5	595255	595255
11af4221-b186-4e18-bcfb-205ffd337e4f	2026-01-07 07:44:09.187795+00	21.8	22.5	755686	755686
45b8709e-93e6-4d81-a1df-135d81ceec47	2026-01-07 07:44:09.987553+00	21.8	22.5	1110965	1110965
63b1aa9e-9919-4785-83bb-565d705459a5	2026-01-07 07:44:11.468895+00	22.1	22.5	928372	928372
cc4174e6-f6f2-4d5a-904a-64b404203402	2026-01-07 07:44:32.326914+00	11.8	22.5	845097	845097
09898b1b-5ead-4d09-a0f6-ac839ba8ef46	2026-01-07 07:44:53.976434+00	18.8	22.5	99978	41849
9b472f37-12b1-4e1f-922c-03b7179a89cc	2026-01-07 07:44:58.514473+00	8.7	22.5	585862	585862
f62becd5-fd75-4129-bb26-5527ddfa5348	2026-01-07 07:44:59.781713+00	9.2	22.5	262154	262154
97a0e605-0651-4921-9a08-eaa903bcc436	2026-01-07 07:44:59.80651+00	9.2	22.5	387909	387909
a3022140-b988-4127-b4a6-90ee358742ff	2026-01-07 07:45:09.412518+00	7.7	22.6	709321	709321
38508fc5-418b-418b-981e-fc1068b404f9	2026-01-07 07:45:09.431995+00	7.7	22.6	676461	676461
99679c22-23ea-402a-a351-63d224066fe7	2026-01-07 07:45:10.347603+00	7.7	22.6	992346	992346
6d7b3ef8-80b1-4b9c-9ad8-47d4729f4324	2026-01-07 07:45:32.311944+00	10.6	22.5	755815	755815
d1f3eae9-873d-4d2c-9a90-c4085222151e	2026-01-07 07:45:53.977067+00	13.2	22.5	92945	41533
3f2f2cec-028a-44f1-953b-83dc44e9391a	2026-01-07 08:21:54.299731+00	7.9	22.1	15529	7329
6176ba46-d111-440e-9586-f7961baef7c2	2026-01-07 08:57:54.594695+00	5.3	27.3	8314	4890
a5691730-4bc6-421a-b5a7-7a6ee1c06afb	2026-01-07 09:44:12.299693+00	4.7	24.6	3276	2157
f63f3d5c-0e2e-49a6-930f-ee16b5d9bc2a	2026-01-07 10:02:48.828534+00	7.3	30.3	3739	3739
c4fa0764-51e0-48d6-a9d2-017930e56c06	2026-01-07 10:24:12.868218+00	12.4	31.3	71124	133734
72e4db2b-828c-466b-a72d-42622bd5b386	2026-01-07 10:41:52.158247+00	4.8	26.4	0	0
c22e37b1-a089-4e69-a400-9dfeb9d4e387	2026-01-07 10:58:52.085714+00	4.8	30.3	0	0
537395f5-e9ad-4416-a3ba-9f03e978229f	2026-01-07 11:16:35.892007+00	5.7	33.4	104012	104012
2de97d77-a1aa-46f0-af23-5eb21f3a84f2	2026-01-07 11:16:52.021349+00	31.9	33.4	92644	92644
736cad16-a0ba-4145-901d-8c54940e00a6	2026-01-07 11:36:13.807312+00	23.7	32.9	1071775	189275
fa6d7733-daee-4ee8-9443-77c6250f6b01	2026-01-07 16:39:51.902822+00	10.4	33.9	205031	205031
0c19c3aa-5f21-408d-a8c6-4660eeda0c6a	2026-01-07 16:40:52.126173+00	71.5	35.2	12368471	12368471
e9db6f60-70ab-4ab6-83c1-25c5c9ff694a	2026-01-07 16:41:51.931727+00	67.2	37	8109931	8109931
38f27061-4573-41b5-84c7-c6e190b9d3ba	2026-01-07 16:42:51.890684+00	65	33.4	7102696	7102696
af0a33c6-a1ce-4488-9a1c-f03ea911d8b0	2026-01-07 16:43:51.974153+00	64.4	32.5	8441439	8441439
a57d77bf-7800-4670-9d16-0c646297eea2	2026-01-07 16:44:51.948668+00	66.2	32.4	7200841	7200841
da489609-38ff-4724-8675-457025bfc1b1	2026-01-07 16:46:17.659495+00	60.2	33.7	3089967	3089967
335ea757-8606-456b-a7cd-4b1efb55bbbf	2026-01-07 16:47:17.731465+00	63.3	33.6	13088563	13088563
23210382-c49b-4896-97d6-a0863c5c8284	2026-01-07 16:47:51.927666+00	65.9	33.8	982927	982927
ffa9144e-3550-4979-ba27-2072f2f1a1b7	2026-01-07 16:49:17.648189+00	65.3	33.6	9269831	9269831
2a1a77bb-e796-4050-b535-97996e7d355d	2026-01-07 16:50:17.641948+00	61.6	32.8	5625561	5625561
5523892b-56eb-4002-8da9-6277c33a0098	2026-01-07 16:51:17.679997+00	64.2	33.9	4023381	4023381
31c6946a-6a45-47d2-b731-0f142907f8a1	2026-01-07 16:52:17.659227+00	64.4	34.2	629492	629492
47dc721b-3c40-4a3e-b180-105ce7dcf3cd	2026-01-07 16:53:51.907017+00	64.1	36.1	8882276	8882276
0055605f-92c4-4959-881b-63b65f4f8f15	2026-01-07 16:55:17.670077+00	67.3	37.4	9070567	9070567
e815c4c4-161c-40d0-9623-71a4d2664485	2026-01-07 16:57:17.717204+00	50.4	37.7	502150	502150
82fea989-00ce-4510-b349-1979cd228982	2026-01-07 16:58:17.691956+00	46.8	37.6	710839	710839
25ffdcc6-adc2-41c8-a5e1-0d0928348f4f	2026-01-07 16:58:51.937681+00	48.3	37.6	532251	532251
c7187e0a-e9f7-460d-aeac-447b0e59e54b	2026-01-07 16:59:51.881102+00	39.2	36.8	605921	605921
e6528952-ef9f-4a0f-aa1c-71dfc82bb1dc	2026-01-07 17:00:17.721309+00	52.4	36.7	571973	571973
38614969-cae4-4347-95b5-a851d2b1156a	2026-01-07 17:01:10.651453+00	52.7	39.6	911244	911244
7f84f239-99b2-4aa0-a685-49fa6ab56c7d	2026-01-07 17:01:29.090298+00	52.7	39.5	460497	460497
75782376-8394-40da-a30d-03c94a56da5b	2026-01-07 17:02:17.598686+00	53.2	39.6	936273	936273
eed83e2c-873a-443c-8c14-b9056df41825	2026-01-07 17:02:29.069261+00	54.2	38.5	363206	363206
396e19f6-bfa2-4e5c-90be-ec3105895354	2026-01-07 17:04:29.054517+00	56.4	36.4	623730	623730
99cedf29-8a13-4c18-89bc-79cfc57736b2	2026-01-07 17:04:51.951728+00	54.2	38.3	303560	303560
1d02a89a-ee6c-4c80-a1f9-ddd35711480e	2026-01-07 17:05:17.638902+00	53.1	39.4	867205	867205
7ce42dbc-4211-4aa4-a68f-5577df8bb2ba	2026-01-07 17:05:29.097684+00	54.4	39.5	615041	615041
c2aeae69-fd96-49d3-b532-28009ce66159	2026-01-07 17:06:51.935339+00	54.9	37.2	463171	463171
15c89ba6-dc19-4ea1-bfd4-bfe2b0407c1a	2026-01-07 07:45:58.390284+00	11.7	22.5	603762	603762
405da92b-91d5-478b-b294-1b855b8711e6	2026-01-07 08:22:54.305142+00	7.6	22.2	13457	8092
4fd9e07b-e70b-4844-be6d-dd4939e00ce1	2026-01-07 08:58:54.605581+00	6.3	26.9	8208	4568
7242e1b5-08d6-4769-ac7f-33b63c9b5b84	2026-01-07 09:44:52.151275+00	4.8	24.5	112773	112773
387649f3-42ba-43bf-8332-d9956324befb	2026-01-07 10:02:52.045431+00	9.2	30.4	471886	471886
4cc2c26b-7b5e-4326-b88e-3d4b112af3a1	2026-01-07 10:24:48.804593+00	9.1	31.4	3681	3681
9cfa7c77-fe70-4989-af84-4c0a816e36c2	2026-01-07 10:41:52.165476+00	4.8	26.4	109470	109470
25593edc-35b4-4047-b62a-a30e8d6d3651	2026-01-07 10:59:13.255288+00	5.1	30.3	6618	4481
22a4186e-15c1-4c24-8a49-2bab47975f3e	2026-01-07 11:17:13.487358+00	20.4	33.4	6858	4780
75392dd1-1b82-4228-8b8a-2830e344dd33	2026-01-07 11:36:44.909531+00	26.2	33	1041374	1041374
a0a0283f-a1c6-40e1-b230-2522f03891d0	2026-01-07 11:36:51.947769+00	36.2	33.1	8300607	8300607
a0dbc94a-eb2b-4b2f-8c84-dcba9cd86b70	2026-01-07 11:37:50.933982+00	33.7	33.7	1935993	1935993
b5a15291-01df-4ece-bedd-164ee2a02331	2026-01-07 16:40:17.619945+00	10.1	32.3	470746	470746
a046441a-0f57-4a61-810c-fa40cd6d6419	2026-01-07 16:41:17.69186+00	69.6	35.7	7167085	7167085
6659e078-7d5a-458f-8552-9b6e2aa4e8e0	2026-01-07 16:42:17.649226+00	65.6	37.2	6528348	6528348
a70df5e3-8eaf-48f2-b11d-e6f08bcf3c08	2026-01-07 16:43:17.659871+00	62.6	33	6116266	6116266
ec7d3e98-5709-41fa-b549-b2c0cde53d8a	2026-01-07 16:44:17.610039+00	66.9	32.5	6488146	6488146
ff93420a-3b02-4547-86a3-4c0bb5e4230d	2026-01-07 16:45:17.685621+00	63.8	32.6	4122671	4122671
382e08ed-dc36-4d61-a887-2d8692713c3b	2026-01-07 16:45:51.914927+00	66.7	33.5	9758155	9758155
4799e62d-3fcc-4910-b7f3-25e1c4fe214a	2026-01-07 16:46:51.881823+00	63.2	33.4	7175850	7175850
0cbdb7f5-f8d9-4674-822b-380afec23461	2026-01-07 16:48:17.64419+00	64.3	33.8	5649327	5649327
d5ac41d7-68ff-42b3-b5ca-0049f82a0a46	2026-01-07 16:48:51.881088+00	65.6	33.6	13195766	13195766
1519b4e5-98da-4848-b732-6940ed9c0440	2026-01-07 16:49:51.940809+00	63.3	32.7	13484107	13484107
a3332d26-1725-461b-8db7-dd8272461251	2026-01-07 16:50:51.883546+00	62.9	32.9	784297	784297
6e298495-e3e6-4eae-8c27-c806bfa5343c	2026-01-07 16:51:51.980033+00	62.7	34.1	880375	880375
37026bfc-a819-4b1a-a9c7-a4e0757020e6	2026-01-07 16:52:51.904251+00	62.8	33.3	305582	305582
a18331fc-5032-4dc8-a65f-f2cdba909ccd	2026-01-07 16:53:17.664632+00	61.2	33.2	13163572	13163572
e72f676d-cbd7-4449-aedb-7cc48361f370	2026-01-07 16:54:17.665517+00	64.2	36.1	571772	571772
6e50303f-9b4c-474c-9ccb-3de657b3841c	2026-01-07 16:54:51.962535+00	65.7	36.1	12304442	12304442
2da3afb9-d3e6-4929-8bf1-3e3f554c8503	2026-01-07 16:55:51.876978+00	69.6	37.5	809214	809214
8cd97182-adfd-4d4c-885a-4f21da59b3bd	2026-01-07 16:56:17.659725+00	64.4	37.6	1499157	1499157
a8c4fa49-7550-4697-8cab-a6059acbb65f	2026-01-07 16:56:51.95424+00	47.8	37.5	228850	228850
a1834529-ccd6-44f6-945a-9e2888f3674a	2026-01-07 16:57:51.952899+00	52.8	37.7	584641	584641
4ea9f5e5-17b8-49f5-9f89-f4dd7021b827	2026-01-07 16:59:17.654298+00	49.6	33.5	640322	640322
f60c3c92-c46b-47e4-9003-9003ca8d37be	2026-01-07 17:00:51.979868+00	51.8	35.8	618174	618174
8dae79bf-fb9e-4a02-bedb-622e2caa879d	2026-01-07 17:01:08.834704+00	49.9	39.6	963529	963529
e5030d42-cf0b-417a-a518-bcca19914fab	2026-01-07 17:01:17.679202+00	50.2	39.5	651891	651891
f5024cfa-e889-4148-87b8-6993779ee6a1	2026-01-07 17:01:51.953173+00	53.5	39.6	327664	327664
60c313cc-a041-48bd-89c8-bfc33c948e97	2026-01-07 17:02:51.934134+00	53.6	39.7	656090	656090
ecc49830-3a6f-44cf-b93d-cdfa434ab811	2026-01-07 17:03:17.661181+00	54.4	36.2	622042	622042
71d6045a-fddb-4db8-b130-fc29b4b32c56	2026-01-07 17:03:29.063179+00	57.6	36.3	525220	525220
8870a655-5a0e-4655-b267-0ff7bc8cbeb8	2026-01-07 17:03:51.921752+00	53.8	36.5	98517	98517
df53dcb6-9e1b-489c-a2ae-1368ed212633	2026-01-07 17:04:17.668629+00	51	36.5	1115180	1115180
3b25c8b8-3c40-4e21-9b00-b6cfaebb1b43	2026-01-07 17:05:51.929506+00	51.6	39.4	454073	454073
8be539c8-00ee-4305-9963-694723ca194b	2026-01-07 17:06:17.665015+00	54	39.4	633262	633262
26ddd7dc-ae82-4a35-8d0e-a6afa1f54927	2026-01-07 17:06:29.105344+00	53.1	37.2	1173425	1173425
d683a47c-03f6-423e-b999-69969e770088	2026-01-07 07:45:58.459287+00	11.7	22.5	760972	760972
4cc5e06a-552e-4cb7-aaef-138fb74bcd26	2026-01-07 07:46:00.014762+00	10.4	22.5	395865	395865
87d34fe2-fcd4-4961-ac2b-ed2085709e8a	2026-01-07 07:46:58.446943+00	8.4	22.5	716119	716119
809544d3-26d3-48c0-8430-c3ec05106945	2026-01-07 07:46:59.827212+00	11	22.5	443047	443047
22e7da9e-474e-4fda-9eda-c3aebf3020da	2026-01-07 07:47:09.556577+00	5.9	22.6	338731	338731
b0318caf-82a7-4044-811c-efacd2e9473b	2026-01-07 07:47:10.445345+00	29.7	22.6	1092910	1092910
17fdc592-a832-49e7-b9ac-d2adcea48157	2026-01-07 08:23:54.283363+00	11.5	22.2	14697	10300
abf27211-76a9-45f3-ba08-080ac396cc71	2026-01-07 08:59:54.615911+00	5.9	26.5	7605	5427
e5ed5cd3-268c-4e34-ba68-56d609b5abcc	2026-01-07 09:44:52.151386+00	4.8	24.5	0	0
b261df59-f6d8-4e5a-b702-f98abd53b2cb	2026-01-07 10:03:12.527654+00	9.1	30	4681	26011
6d65dacf-673a-4718-b54a-50fe09a6545a	2026-01-07 10:24:52.071996+00	13.1	31.4	415981	415981
ff8b0b97-b070-444b-b7c6-a5e5dea7ca9c	2026-01-07 10:42:13.05529+00	4.8	26.4	5325	3666
f194c066-9405-413e-9b5a-3787a0f7eb83	2026-01-07 10:59:52.139097+00	4.8	28.3	0	0
52075830-7a5a-4867-8127-74633ba088c1	2026-01-07 11:17:35.822014+00	5.2	33.4	5194	5194
f4a69214-2e94-4b0f-91b9-c2906f2b322e	2026-01-07 11:17:40.043338+00	5.5	33.3	176753	176753
502588b3-fca9-4001-bf84-e0362be5fa11	2026-01-07 11:17:46.152583+00	22.2	33.3	161616	161616
91c5145d-b2ae-4686-ba46-c1cbd5d98144	2026-01-07 11:37:13.777658+00	36.3	33.2	4478279	113973
c1db2f7d-56f3-4641-8d8f-2a8226df14f3	2026-01-07 17:07:17.691386+00	54.7	37.4	713313	713313
05fde76b-54c7-4ba8-b743-f77199482623	2026-01-07 17:07:29.071596+00	50.9	37.2	494265	494265
7d6cc91d-6f24-421c-8e24-63bd34901d60	2026-01-07 17:07:51.942391+00	55.2	37.3	267286	267286
d5546474-4d0c-4ad3-aaee-de5323efc93d	2026-01-07 17:08:17.610074+00	47	37.2	1492408	1492408
e056d249-b456-47dd-9303-4e308e51faae	2026-01-07 17:08:29.088425+00	50.9	33.8	956963	956963
bf935266-321a-495e-a3c4-53f12fc7a04d	2026-01-07 17:09:51.884923+00	54.2	35.7	525036	525036
419594eb-f4fa-4b17-910e-af0b90492cd9	2026-01-07 17:10:17.605957+00	49.2	38.1	1780888	1780888
c24bffc1-6bf5-4371-868d-134ac035032e	2026-01-07 17:10:29.115589+00	52.6	38.3	817236	817236
b11ef735-58e5-4155-bbfd-c9eb8743f348	2026-01-07 17:11:51.939602+00	53.2	39	213359	213359
ab78487c-03a4-49d8-af75-3201db8ca3e9	2026-01-07 17:12:51.950049+00	53.3	31.9	387868	387868
c7d66d56-3e64-4944-ac62-675e8dbaff03	2026-01-07 17:13:17.663753+00	52.2	32.4	1433705	1433705
0c55b9b6-9f20-466a-ab02-66ddc8fe4ef4	2026-01-07 17:13:29.065516+00	53.4	32.5	489451	489451
28299837-8cfa-456e-9f18-a025d0c24753	2026-01-07 17:15:29.093681+00	53.5	32.7	474345	474345
de1f877b-9c44-4cab-8b0f-b4c030fdc606	2026-01-07 17:16:51.947467+00	53.3	33.1	459621	459621
7e9df493-3b26-48a0-9293-35c0225b8fc2	2026-01-07 17:17:17.670634+00	52.5	33.1	728506	728506
98f18d45-9d5c-441d-b4dc-8ebe8afc9165	2026-01-07 17:17:29.100714+00	52.9	33.2	387036	387036
07439583-ec8a-49b1-91cb-d9b6042cb850	2026-01-07 17:19:17.674292+00	53.2	33.1	688126	688126
dc928142-9da6-4896-919d-dce25612698b	2026-01-07 17:19:29.088005+00	55.3	33.2	601159	601159
023046f4-a41d-41d1-8b33-7b81955674fe	2026-01-07 17:20:51.911899+00	53.2	33.4	718001	718001
4a25e178-2fd2-4aa3-8864-d1f2632d416e	2026-01-07 17:21:17.673829+00	49.9	33.4	503711	503711
c2457146-417e-4091-a9a7-17cac0d1462a	2026-01-07 17:21:29.045912+00	48.2	33.4	632896	632896
e543a5a3-e0fc-44d9-92ef-7f95a7050c85	2026-01-07 17:23:51.975466+00	54.3	33.5	660148	660148
12dbd6f3-00aa-4df9-aae1-004518c3dae4	2026-01-07 17:24:51.937882+00	53.5	33.4	835043	835043
b0dddbef-6578-4733-afbb-b3c8643ccff3	2026-01-07 17:25:17.599664+00	51.7	33.5	1816867	1816867
1a3d933f-f9f8-4849-89ea-8de4b835d503	2026-01-07 17:25:29.110378+00	50.3	33.4	816315	816315
ea59fee2-1f9f-420e-a9de-0f41c2b31ea3	2026-01-07 17:25:51.927655+00	53.2	33.5	509704	509704
c2fd1df7-b56b-425b-a1b4-f43ae1c2a54c	2026-01-07 17:26:17.654187+00	53.5	33.5	754446	754446
6f0f87ca-f6f5-45e0-aec5-487b906c0646	2026-01-07 17:26:29.021432+00	48.3	33.6	726233	726233
947558a4-5ef5-466f-bca9-f4780d5e64ac	2026-01-07 17:27:51.901867+00	54.1	33.8	951026	951026
fa2b0e36-a19f-48a5-81ed-657d4359d830	2026-01-07 17:28:17.606056+00	48.8	33.9	1654189	1654189
4951d1e9-a19b-4d71-ac54-eeeae13502da	2026-01-07 17:28:51.928741+00	52.5	33.8	521749	521749
d25bd4ee-65e0-4225-a972-309a9c607357	2026-01-07 17:29:51.930816+00	54.8	33.9	474705	474705
cbe74748-9f89-47d5-94e7-cbca5fd8133c	2026-01-07 17:30:17.615815+00	52.4	33.9	1261461	1261461
38b5749a-b388-4255-8014-c07b0cd92975	2026-01-07 17:30:29.076656+00	52.9	34	261982	261982
5556b345-0c0f-4bf1-9bdc-32e63d267eba	2026-01-07 17:31:17.597242+00	59.1	33.9	1175589	1175589
319099a4-8107-4234-9cfe-58c4b1cb4fb9	2026-01-07 17:31:28.997328+00	27.3	34.1	387395	387395
e9a20e92-7224-44eb-900e-ebe5e89731c6	2026-01-07 17:32:17.642205+00	5.5	31.6	926489	926489
4b329057-8b75-4ef8-a045-c39e9eeded9f	2026-01-07 17:32:28.971484+00	11.7	31.6	744367	744367
a120ad72-881b-4b35-ac4b-ac056a384332	2026-01-07 17:32:51.906689+00	9.3	31.6	198234	198234
d1b9195d-85a1-4b70-a265-5e4acd5bb321	2026-01-07 17:33:51.912091+00	12.5	31.6	185311	185311
50dc77de-3268-41cf-822c-119524826d73	2026-01-07 17:34:17.637596+00	11.1	28.5	765412	765412
5ef92ab5-dab2-4510-81e7-1c428bd8892b	2026-01-07 17:34:51.901366+00	9.4	28.5	264319	264319
273614f5-809a-4ff5-9806-23472dd924f1	2026-01-07 17:35:17.601003+00	9.1	28.5	1665768	1665768
43c260bf-14eb-44f4-aadf-f9c344690b93	2026-01-07 17:35:28.970182+00	9.7	28.5	695478	695478
8c81b1ee-17ec-4d3d-b6eb-abe1b53e1f39	2026-01-07 17:36:51.903221+00	9.3	28.4	219348	219348
8feb7cc1-b51a-4c57-b011-9a17c8d1e7a6	2026-01-07 07:45:59.919729+00	10.4	22.5	180095	180095
2ecfcd90-13e3-45e1-aace-8bfa638794a3	2026-01-07 07:46:09.578389+00	14.8	22.5	566879	566879
637531df-8a88-484d-abfe-ce2a8841d2fe	2026-01-07 07:46:10.458047+00	14.8	22.5	1189705	1189705
dbf6efcd-f96e-481e-8ae3-691ddf7b4e4c	2026-01-07 07:46:32.22925+00	7.7	22.6	857026	857026
a4c8eb66-8f2b-4a1b-9434-e833d91717c9	2026-01-07 07:46:59.828368+00	11	22.5	395360	395360
97713f3f-93ce-4304-b6bc-c6cb36ce3270	2026-01-07 08:24:54.299548+00	3.9	22.1	1461	258
77035b0c-479d-4e66-aa29-1bc4442a5e04	2026-01-07 09:00:54.663162+00	6.5	25.1	8354	6850
b8d210db-0020-4eab-95d5-d8955f3ebe7e	2026-01-07 09:45:12.322508+00	0	24.6	3438	2126
3f1be2e0-9a13-41e3-8c44-1b077ed03e35	2026-01-07 10:03:48.815777+00	6.9	30.4	2886	2886
2d3dcf27-5f8d-4c8f-857b-d4ca4ec44051	2026-01-07 10:25:12.891422+00	10.3	31.4	6029	3687
d01fd413-648f-4a20-964e-c68cff004378	2026-01-07 10:42:52.116141+00	4.8	26.4	111751	111751
996aedce-979e-423f-bd8c-5cc388fd5add	2026-01-07 10:59:52.139085+00	4.8	28.3	231031	231031
2842ea3d-9acd-4499-8504-57eebcbffbad	2026-01-07 11:17:51.94512+00	20.7	33.5	141492	141492
4eb635dd-3451-41ec-ad86-8da32c9e2b31	2026-01-07 11:38:13.815135+00	35.3	34.5	4874836	123155
1855a932-acec-42df-93a3-acbc7c30960b	2026-01-07 17:08:51.967891+00	53.8	34	545964	545964
e49d0253-17f7-466d-bcf4-0064194ec12c	2026-01-07 17:09:17.668453+00	54.3	33.9	754789	754789
6239b101-6341-470d-a6c7-cab77995f376	2026-01-07 17:09:29.074666+00	54.9	33.9	633596	633596
90c32633-1cc3-4290-be5a-3eb1bf8bd00e	2026-01-07 17:10:51.945968+00	56	38.5	301801	301801
699cab07-42c2-4349-8943-05a7601504c5	2026-01-07 17:11:17.654796+00	50.6	38.9	682079	682079
f75c43b5-8e0d-42fe-927f-a13257584c80	2026-01-07 17:11:29.019001+00	54.5	38.9	651540	651540
27880c3a-26d6-4298-b3c0-9db7b6672454	2026-01-07 17:12:17.631+00	49	35.2	1271885	1271885
0500384b-412c-464c-9b32-df2468b2027d	2026-01-07 17:12:29.055597+00	51.2	35.2	522008	522008
60921ce3-dc38-431f-bbaf-f2960c25bc8a	2026-01-07 17:13:51.943295+00	56.4	32.6	676140	676140
acc19296-ef68-44ed-8dbe-85939a7b441e	2026-01-07 17:14:17.672115+00	51.5	32.2	612170	612170
c7df818a-d0c9-4a78-a1e0-e814c3798340	2026-01-07 17:14:29.055525+00	56.8	32	477042	477042
ae9b3b6b-b519-4143-8562-e58d2199ea1d	2026-01-07 17:14:51.945298+00	53.1	32.3	368895	368895
ff5591fa-c9cc-4403-9281-8bd60af42c69	2026-01-07 17:15:17.652611+00	50.7	32.6	899665	899665
6105ab96-fbb3-4844-a2a8-f5a894a10316	2026-01-07 17:15:51.947541+00	53.5	32.7	286071	286071
8c83e11f-1a9b-44b8-b872-270aee5fbdec	2026-01-07 17:16:17.658269+00	53.6	33.2	695338	695338
24d18cdf-db67-4034-b3bf-7ffddc761af9	2026-01-07 17:16:29.061295+00	55.2	33.1	893692	893692
244bcdd5-f57b-43bf-8bb2-6671301c22c2	2026-01-07 17:17:51.950136+00	53.8	33.2	465031	465031
404273ed-8de9-491f-9621-d0d34328460d	2026-01-07 17:18:17.596802+00	49.2	33.2	1897563	1897563
72c9e13e-5a65-42a7-b4b9-b8abc44b9745	2026-01-07 17:18:29.083475+00	50.5	33.1	796064	796064
217219cc-c4a4-4c6b-a8b6-daa7a9b5a5ef	2026-01-07 17:18:51.930619+00	53	33.1	333548	333548
07e7f997-2973-4158-8da4-9c77f6e00617	2026-01-07 17:19:51.937142+00	55.2	33.4	448630	448630
b30881f0-e24d-4f6c-becb-f8db2712a3f4	2026-01-07 17:20:17.593311+00	51.2	33.4	1524447	1524447
58e6b99f-b15c-44e9-aeec-024ce8a0d528	2026-01-07 17:20:29.060582+00	52.1	33.4	510565	510565
71fc3d91-2f85-41c0-8a46-36d4717f43c2	2026-01-07 17:21:51.899579+00	52.7	33.4	254961	254961
ca43b5be-30dd-418f-966b-b62536fe8847	2026-01-07 17:22:17.60113+00	52.2	33.4	2045490	2045490
e4ba17d9-c45d-4fb3-8bf0-a8dd0a8d12fa	2026-01-07 17:22:29.060523+00	56.9	33.4	615409	615409
455a912e-7335-4229-9579-de5db6ed4afd	2026-01-07 17:22:51.935744+00	53.3	33.4	428412	428412
8c9f084f-b2b1-4701-8061-bdafce0cfcb0	2026-01-07 17:23:17.672645+00	54.5	33.4	619306	619306
62cc5cbd-3048-4e44-a0a1-e44132351250	2026-01-07 17:23:29.098356+00	55.1	33.5	372129	372129
d7a4eb01-7998-4ea3-bb79-0b6344d23b2c	2026-01-07 17:24:17.665217+00	53.9	33.4	641965	641965
f38ca1b8-b806-4199-8e34-e7c23cb03846	2026-01-07 17:24:28.983056+00	57.7	33.5	811035	811035
854b59bc-bf79-49ed-b8ce-8a02ee3281aa	2026-01-07 17:26:51.931589+00	55.5	33.6	544793	544793
735ec9ed-0897-4669-8844-c55435c1609b	2026-01-07 17:27:17.700019+00	52.8	33.7	662545	662545
367e2297-47bf-470b-b9e4-934a9cc2556c	2026-01-07 17:27:29.104339+00	56.9	33.5	594802	594802
7754119c-31e3-4465-ba60-c64dd27748d0	2026-01-07 17:28:29.081301+00	50.6	33.8	344548	344548
d6d18a87-debf-4e35-8c0e-dc6a6d9cb6c8	2026-01-07 17:29:17.682602+00	49.2	33.9	388073	388073
2bd5ffef-7c9b-4dab-a94a-942d667bb6b8	2026-01-07 17:29:29.009017+00	51.5	33.9	730641	730641
bad007f7-0a1e-4bba-83d5-45b02344d185	2026-01-07 17:30:51.940935+00	55.7	33.9	285181	285181
522d5819-8b87-4292-9a74-3ca70eaaae01	2026-01-07 17:31:51.906263+00	33.1	35	297594	297594
35728d67-beb8-4af0-af79-cd31953f39f4	2026-01-07 17:33:17.729455+00	9.1	31.7	1469724	1469724
4118e0df-af46-4a33-bd7c-fba0dcf2fa24	2026-01-07 17:33:29.001808+00	9.7	31.7	638777	638777
558728cd-564d-486d-b551-5d200cba8fd2	2026-01-07 17:34:28.972082+00	8.6	28.5	879610	879610
82c320e7-a378-4ae5-bc17-4bd730b6ad5f	2026-01-07 17:35:51.902947+00	12.4	28.6	274996	274996
6f741ed6-8a2a-4654-b9d6-feca62e5ab47	2026-01-07 17:36:17.63625+00	9.1	28.3	790174	790174
380620a2-ac20-4560-ab06-29938822214c	2026-01-07 17:36:28.9824+00	9	28.4	638250	638250
261f9dda-72c4-4ba3-b322-b1896f29e0a2	2026-01-07 07:45:59.921577+00	10.4	22.5	515585	515585
c56bbc81-935d-47b1-8706-2488f213e9a8	2026-01-07 07:46:11.81249+00	22.7	22.5	574108	574108
99e78194-f91f-4cd8-a811-d95d1ab0683d	2026-01-07 07:46:53.987829+00	20.3	22.4	80208	38353
6ec2dd71-1218-4fd6-a16b-2b6f8329d68a	2026-01-07 07:47:09.551423+00	5.9	22.6	716871	716871
955cec4c-791f-4766-9582-010b4923b315	2026-01-07 08:25:54.335578+00	2.7	22.1	1602	288
0ec7f068-a151-4d9b-a9a3-669d072964ba	2026-01-07 09:01:54.630297+00	6.3	25	9740	15597
ef9ec9c9-1b24-4358-8e9e-f2629e070053	2026-01-07 09:45:52.121699+00	5	24.6	116741	116741
34ba43fa-04cb-437d-a656-441480c6a957	2026-01-07 10:03:52.157752+00	9.1	30.5	366557	366557
ecbb932e-7b4a-46bb-8d6e-f0764f1044ab	2026-01-07 10:25:48.813743+00	4.9	31.4	3606	3606
d90d840b-03d4-4635-9b15-c97d6b4209dd	2026-01-07 10:25:52.068217+00	4.9	31.4	138133	138133
d9540cfb-f340-4325-8f77-572a57ff3863	2026-01-07 10:42:52.116111+00	4.8	26.4	138837	138837
4e11688b-1d10-4c4a-a7f2-49a206962593	2026-01-07 11:00:13.255808+00	11.3	28.3	7106	4560
b166f122-6a30-44d8-91b5-0b01c21d4142	2026-01-07 11:18:13.510083+00	6.1	31.6	8446	6476
64010fe6-6d12-468d-a576-9e00880439ab	2026-01-07 11:38:44.824277+00	30.6	34.6	4976988	4976988
c8e16da8-251e-46b5-a0a3-b31659b4d54a	2026-01-07 11:38:51.914703+00	32.2	34.6	6352962	6352962
31eaa9a3-e931-4371-adae-3e8e90e307da	2026-01-07 17:37:17.614076+00	9.3	28.4	923868	923868
bbdd2853-461e-4437-8e41-385a1dcc273f	2026-01-07 17:37:29.032361+00	8.8	28.4	307998	307998
2a9377f3-004f-4026-9bc4-8889a0cd8db7	2026-01-07 17:38:17.595973+00	9.1	28.4	1210538	1210538
cee43748-94fa-4a64-95df-b7a8e5d54635	2026-01-07 17:38:28.971456+00	10.5	28.3	636531	636531
9819510f-394a-483c-9664-5fd31d3683de	2026-01-07 17:39:17.64067+00	10	28.3	568474	568474
00c502e9-7cce-4f01-bad6-c1a8e077d8a3	2026-01-07 17:39:29.003235+00	9.4	28.4	284823	284823
6874ff38-4780-44be-9843-7a468b749b5b	2026-01-07 17:40:51.892438+00	12.6	28.4	273396	273396
4dccb737-d556-4490-b46f-20f9507eab07	2026-01-07 17:41:51.917991+00	8.7	35	289222	289222
7861167d-c90d-455a-a1db-7957765d490d	2026-01-07 17:42:29.012553+00	7.7	35	251070	251070
f5cacd27-ee96-4e79-83c8-f1a0dcca80bc	2026-01-07 17:43:51.861401+00	14.6	38.4	340941	340941
64259b7c-b267-47f8-a1e0-02f883e643cb	2026-01-07 17:45:17.596797+00	9.8	38.5	1168495	1168495
46ebd0a7-32bd-47eb-afda-e487489408e2	2026-01-07 17:45:29.041051+00	9.4	38.6	278179	278179
53bb2760-f75a-430d-b4b3-18aacb733bf5	2026-01-07 17:46:51.889517+00	10.3	28.8	216062	216062
b971ded5-32fb-49b2-9969-b5b05300ddba	2026-01-07 17:47:51.879007+00	11.3	37.6	341189	341189
6c3a2d1f-0dc5-4b68-891f-0147ce5bf6cb	2026-01-07 17:48:51.870034+00	52.8	38.7	369734	369734
\.


--
-- Data for Name: telegram_ads; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.telegram_ads (id, channel_id, name, ad_text, ad_link, tracking_code, clicks, impressions, start_date, end_date, budget, spent, status, is_active, created_at, updated_at) FROM stdin;
\.


--
-- Data for Name: telegram_bots; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.telegram_bots (id, name, token, description, is_active, created_at, updated_at) FROM stdin;
\.


--
-- Data for Name: vpn_profiles; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.vpn_profiles (id, name, config, is_active, created_at, updated_at) FROM stdin;
\.


--
-- Name: activity_logs activity_logs_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.activity_logs
    ADD CONSTRAINT activity_logs_pkey PRIMARY KEY (id);


--
-- Name: ad_clicks ad_clicks_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.ad_clicks
    ADD CONSTRAINT ad_clicks_pkey PRIMARY KEY (id);


--
-- Name: ad_purchases ad_purchases_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.ad_purchases
    ADD CONSTRAINT ad_purchases_pkey PRIMARY KEY (id);


--
-- Name: ad_sales ad_sales_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.ad_sales
    ADD CONSTRAINT ad_sales_pkey PRIMARY KEY (id);


--
-- Name: admins admins_email_key; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.admins
    ADD CONSTRAINT admins_email_key UNIQUE (email);


--
-- Name: admins admins_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.admins
    ADD CONSTRAINT admins_pkey PRIMARY KEY (id);


--
-- Name: ai_requests ai_requests_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.ai_requests
    ADD CONSTRAINT ai_requests_pkey PRIMARY KEY (id);


--
-- Name: app_settings app_settings_key_key; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.app_settings
    ADD CONSTRAINT app_settings_key_key UNIQUE (key);


--
-- Name: app_settings app_settings_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.app_settings
    ADD CONSTRAINT app_settings_pkey PRIMARY KEY (id);


--
-- Name: backups backups_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.backups
    ADD CONSTRAINT backups_pkey PRIMARY KEY (id);


--
-- Name: channel_ad_rates channel_ad_rates_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.channel_ad_rates
    ADD CONSTRAINT channel_ad_rates_pkey PRIMARY KEY (id);


--
-- Name: disk_snapshots disk_snapshots_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.disk_snapshots
    ADD CONSTRAINT disk_snapshots_pkey PRIMARY KEY (id);


--
-- Name: dns_configs dns_configs_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.dns_configs
    ADD CONSTRAINT dns_configs_pkey PRIMARY KEY (id);


--
-- Name: firewall_rules firewall_rules_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.firewall_rules
    ADD CONSTRAINT firewall_rules_pkey PRIMARY KEY (id);


--
-- Name: media_channels media_channels_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.media_channels
    ADD CONSTRAINT media_channels_pkey PRIMARY KEY (id);


--
-- Name: monitored_hosts monitored_hosts_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.monitored_hosts
    ADD CONSTRAINT monitored_hosts_pkey PRIMARY KEY (id);


--
-- Name: network_traffic network_traffic_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.network_traffic
    ADD CONSTRAINT network_traffic_pkey PRIMARY KEY (id);


--
-- Name: security_settings security_settings_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.security_settings
    ADD CONSTRAINT security_settings_pkey PRIMARY KEY (id);


--
-- Name: service_uptime service_uptime_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.service_uptime
    ADD CONSTRAINT service_uptime_pkey PRIMARY KEY (id);


--
-- Name: services services_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.services
    ADD CONSTRAINT services_pkey PRIMARY KEY (id);


--
-- Name: system_metrics system_metrics_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.system_metrics
    ADD CONSTRAINT system_metrics_pkey PRIMARY KEY (id);


--
-- Name: telegram_ads telegram_ads_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.telegram_ads
    ADD CONSTRAINT telegram_ads_pkey PRIMARY KEY (id);


--
-- Name: telegram_ads telegram_ads_tracking_code_key; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.telegram_ads
    ADD CONSTRAINT telegram_ads_tracking_code_key UNIQUE (tracking_code);


--
-- Name: telegram_bots telegram_bots_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.telegram_bots
    ADD CONSTRAINT telegram_bots_pkey PRIMARY KEY (id);


--
-- Name: vpn_profiles vpn_profiles_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.vpn_profiles
    ADD CONSTRAINT vpn_profiles_pkey PRIMARY KEY (id);


--
-- Name: idx_metrics_timestamp; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX idx_metrics_timestamp ON public.system_metrics USING btree ("timestamp" DESC);


--
-- Name: idx_network_traffic_recorded_at; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX idx_network_traffic_recorded_at ON public.network_traffic USING btree (recorded_at DESC);


--
-- Name: idx_service_uptime_checked_at; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX idx_service_uptime_checked_at ON public.service_uptime USING btree (checked_at DESC);


--
-- Name: idx_service_uptime_service_id; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX idx_service_uptime_service_id ON public.service_uptime USING btree (service_id);


--
-- Name: ad_purchases update_ad_purchases_updated_at; Type: TRIGGER; Schema: public; Owner: postgres
--

CREATE TRIGGER update_ad_purchases_updated_at BEFORE UPDATE ON public.ad_purchases FOR EACH ROW EXECUTE FUNCTION public.update_updated_at_column();


--
-- Name: ad_sales update_ad_sales_updated_at; Type: TRIGGER; Schema: public; Owner: postgres
--

CREATE TRIGGER update_ad_sales_updated_at BEFORE UPDATE ON public.ad_sales FOR EACH ROW EXECUTE FUNCTION public.update_updated_at_column();


--
-- Name: admins update_admins_updated_at; Type: TRIGGER; Schema: public; Owner: postgres
--

CREATE TRIGGER update_admins_updated_at BEFORE UPDATE ON public.admins FOR EACH ROW EXECUTE FUNCTION public.update_updated_at_column();


--
-- Name: app_settings update_app_settings_updated_at; Type: TRIGGER; Schema: public; Owner: postgres
--

CREATE TRIGGER update_app_settings_updated_at BEFORE UPDATE ON public.app_settings FOR EACH ROW EXECUTE FUNCTION public.update_updated_at_column();


--
-- Name: channel_ad_rates update_channel_ad_rates_updated_at; Type: TRIGGER; Schema: public; Owner: postgres
--

CREATE TRIGGER update_channel_ad_rates_updated_at BEFORE UPDATE ON public.channel_ad_rates FOR EACH ROW EXECUTE FUNCTION public.update_updated_at_column();


--
-- Name: dns_configs update_dns_configs_updated_at; Type: TRIGGER; Schema: public; Owner: postgres
--

CREATE TRIGGER update_dns_configs_updated_at BEFORE UPDATE ON public.dns_configs FOR EACH ROW EXECUTE FUNCTION public.update_updated_at_column();


--
-- Name: firewall_rules update_firewall_rules_updated_at; Type: TRIGGER; Schema: public; Owner: postgres
--

CREATE TRIGGER update_firewall_rules_updated_at BEFORE UPDATE ON public.firewall_rules FOR EACH ROW EXECUTE FUNCTION public.update_updated_at_column();


--
-- Name: media_channels update_media_channels_updated_at; Type: TRIGGER; Schema: public; Owner: postgres
--

CREATE TRIGGER update_media_channels_updated_at BEFORE UPDATE ON public.media_channels FOR EACH ROW EXECUTE FUNCTION public.update_updated_at_column();


--
-- Name: security_settings update_security_settings_updated_at; Type: TRIGGER; Schema: public; Owner: postgres
--

CREATE TRIGGER update_security_settings_updated_at BEFORE UPDATE ON public.security_settings FOR EACH ROW EXECUTE FUNCTION public.update_updated_at_column();


--
-- Name: services update_services_updated_at; Type: TRIGGER; Schema: public; Owner: postgres
--

CREATE TRIGGER update_services_updated_at BEFORE UPDATE ON public.services FOR EACH ROW EXECUTE FUNCTION public.update_updated_at_column();


--
-- Name: telegram_ads update_telegram_ads_updated_at; Type: TRIGGER; Schema: public; Owner: postgres
--

CREATE TRIGGER update_telegram_ads_updated_at BEFORE UPDATE ON public.telegram_ads FOR EACH ROW EXECUTE FUNCTION public.update_updated_at_column();


--
-- Name: telegram_bots update_telegram_bots_updated_at; Type: TRIGGER; Schema: public; Owner: postgres
--

CREATE TRIGGER update_telegram_bots_updated_at BEFORE UPDATE ON public.telegram_bots FOR EACH ROW EXECUTE FUNCTION public.update_updated_at_column();


--
-- Name: vpn_profiles update_vpn_profiles_updated_at; Type: TRIGGER; Schema: public; Owner: postgres
--

CREATE TRIGGER update_vpn_profiles_updated_at BEFORE UPDATE ON public.vpn_profiles FOR EACH ROW EXECUTE FUNCTION public.update_updated_at_column();


--
-- Name: ad_clicks ad_clicks_ad_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.ad_clicks
    ADD CONSTRAINT ad_clicks_ad_id_fkey FOREIGN KEY (ad_id) REFERENCES public.telegram_ads(id) ON DELETE CASCADE;


--
-- Name: ad_purchases ad_purchases_our_channel_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.ad_purchases
    ADD CONSTRAINT ad_purchases_our_channel_id_fkey FOREIGN KEY (our_channel_id) REFERENCES public.media_channels(id) ON DELETE SET NULL;


--
-- Name: ad_sales ad_sales_channel_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.ad_sales
    ADD CONSTRAINT ad_sales_channel_id_fkey FOREIGN KEY (channel_id) REFERENCES public.media_channels(id) ON DELETE CASCADE;


--
-- Name: ad_sales ad_sales_rate_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.ad_sales
    ADD CONSTRAINT ad_sales_rate_id_fkey FOREIGN KEY (rate_id) REFERENCES public.channel_ad_rates(id) ON DELETE SET NULL;


--
-- Name: channel_ad_rates channel_ad_rates_channel_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.channel_ad_rates
    ADD CONSTRAINT channel_ad_rates_channel_id_fkey FOREIGN KEY (channel_id) REFERENCES public.media_channels(id) ON DELETE CASCADE;


--
-- Name: telegram_ads fk_telegram_ads_channel; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.telegram_ads
    ADD CONSTRAINT fk_telegram_ads_channel FOREIGN KEY (channel_id) REFERENCES public.media_channels(id) ON DELETE CASCADE;


--
-- Name: service_uptime service_uptime_service_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.service_uptime
    ADD CONSTRAINT service_uptime_service_id_fkey FOREIGN KEY (service_id) REFERENCES public.services(id) ON DELETE CASCADE;


--
-- Name: telegram_ads telegram_ads_channel_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.telegram_ads
    ADD CONSTRAINT telegram_ads_channel_id_fkey FOREIGN KEY (channel_id) REFERENCES public.media_channels(id) ON DELETE CASCADE;


--
-- Name: ai_requests AI Requests: Create (Authenticated); Type: POLICY; Schema: public; Owner: postgres
--

CREATE POLICY "AI Requests: Create (Authenticated)" ON public.ai_requests FOR INSERT WITH CHECK ((auth.role() IS NOT NULL));


--
-- Name: ai_requests AI Requests: Read Own or Admin; Type: POLICY; Schema: public; Owner: postgres
--

CREATE POLICY "AI Requests: Read Own or Admin" ON public.ai_requests FOR SELECT USING (((auth.user_id() IS NOT NULL) OR (auth.role() = ANY (ARRAY['admin'::text, 'superadmin'::text]))));


--
-- Name: ad_clicks Ad Clicks: Insert (Public); Type: POLICY; Schema: public; Owner: postgres
--

CREATE POLICY "Ad Clicks: Insert (Public)" ON public.ad_clicks FOR INSERT WITH CHECK (true);


--
-- Name: ad_clicks Ad Clicks: Read (Authenticated); Type: POLICY; Schema: public; Owner: postgres
--

CREATE POLICY "Ad Clicks: Read (Authenticated)" ON public.ad_clicks FOR SELECT USING ((auth.role() IS NOT NULL));


--
-- Name: ad_purchases Ad Purchases: All (Admin); Type: POLICY; Schema: public; Owner: postgres
--

CREATE POLICY "Ad Purchases: All (Admin)" ON public.ad_purchases USING ((auth.role() = ANY (ARRAY['admin'::text, 'superadmin'::text])));


--
-- Name: channel_ad_rates Ad Rates: Modify (Admin); Type: POLICY; Schema: public; Owner: postgres
--

CREATE POLICY "Ad Rates: Modify (Admin)" ON public.channel_ad_rates USING ((auth.role() = ANY (ARRAY['admin'::text, 'superadmin'::text])));


--
-- Name: channel_ad_rates Ad Rates: Read (Authenticated); Type: POLICY; Schema: public; Owner: postgres
--

CREATE POLICY "Ad Rates: Read (Authenticated)" ON public.channel_ad_rates FOR SELECT USING ((auth.role() IS NOT NULL));


--
-- Name: ad_sales Ad Sales: All (Admin); Type: POLICY; Schema: public; Owner: postgres
--

CREATE POLICY "Ad Sales: All (Admin)" ON public.ad_sales USING ((auth.role() = ANY (ARRAY['admin'::text, 'superadmin'::text])));


--
-- Name: admins Admins: Delete (Superadmin only); Type: POLICY; Schema: public; Owner: postgres
--

CREATE POLICY "Admins: Delete (Superadmin only)" ON public.admins FOR DELETE USING ((auth.role() = 'superadmin'::text));


--
-- Name: admins Admins: Insert (Superadmin only); Type: POLICY; Schema: public; Owner: postgres
--

CREATE POLICY "Admins: Insert (Superadmin only)" ON public.admins FOR INSERT WITH CHECK ((auth.role() = 'superadmin'::text));


--
-- Name: admins Admins: Read (Authenticated); Type: POLICY; Schema: public; Owner: postgres
--

CREATE POLICY "Admins: Read (Authenticated)" ON public.admins FOR SELECT USING ((auth.role() = ANY (ARRAY['admin'::text, 'superadmin'::text])));


--
-- Name: admins Admins: Update (Self or Superadmin); Type: POLICY; Schema: public; Owner: postgres
--

CREATE POLICY "Admins: Update (Self or Superadmin)" ON public.admins FOR UPDATE USING (((auth.user_id() = id) OR (auth.role() = 'superadmin'::text)));


--
-- Name: ad_purchases Allow public delete access to ad_purchases; Type: POLICY; Schema: public; Owner: postgres
--

CREATE POLICY "Allow public delete access to ad_purchases" ON public.ad_purchases FOR DELETE USING (true);


--
-- Name: ad_sales Allow public delete access to ad_sales; Type: POLICY; Schema: public; Owner: postgres
--

CREATE POLICY "Allow public delete access to ad_sales" ON public.ad_sales FOR DELETE USING (true);


--
-- Name: channel_ad_rates Allow public delete access to channel_ad_rates; Type: POLICY; Schema: public; Owner: postgres
--

CREATE POLICY "Allow public delete access to channel_ad_rates" ON public.channel_ad_rates FOR DELETE USING (true);


--
-- Name: media_channels Allow public delete access to media_channels; Type: POLICY; Schema: public; Owner: postgres
--

CREATE POLICY "Allow public delete access to media_channels" ON public.media_channels FOR DELETE USING (true);


--
-- Name: services Allow public delete access to services; Type: POLICY; Schema: public; Owner: postgres
--

CREATE POLICY "Allow public delete access to services" ON public.services FOR DELETE USING (true);


--
-- Name: telegram_ads Allow public delete access to telegram_ads; Type: POLICY; Schema: public; Owner: postgres
--

CREATE POLICY "Allow public delete access to telegram_ads" ON public.telegram_ads FOR DELETE USING (true);


--
-- Name: telegram_bots Allow public delete access to telegram_bots; Type: POLICY; Schema: public; Owner: postgres
--

CREATE POLICY "Allow public delete access to telegram_bots" ON public.telegram_bots FOR DELETE USING (true);


--
-- Name: ad_clicks Allow public insert access to ad_clicks; Type: POLICY; Schema: public; Owner: postgres
--

CREATE POLICY "Allow public insert access to ad_clicks" ON public.ad_clicks FOR INSERT WITH CHECK (true);


--
-- Name: ad_purchases Allow public insert access to ad_purchases; Type: POLICY; Schema: public; Owner: postgres
--

CREATE POLICY "Allow public insert access to ad_purchases" ON public.ad_purchases FOR INSERT WITH CHECK (true);


--
-- Name: ad_sales Allow public insert access to ad_sales; Type: POLICY; Schema: public; Owner: postgres
--

CREATE POLICY "Allow public insert access to ad_sales" ON public.ad_sales FOR INSERT WITH CHECK (true);


--
-- Name: channel_ad_rates Allow public insert access to channel_ad_rates; Type: POLICY; Schema: public; Owner: postgres
--

CREATE POLICY "Allow public insert access to channel_ad_rates" ON public.channel_ad_rates FOR INSERT WITH CHECK (true);


--
-- Name: media_channels Allow public insert access to media_channels; Type: POLICY; Schema: public; Owner: postgres
--

CREATE POLICY "Allow public insert access to media_channels" ON public.media_channels FOR INSERT WITH CHECK (true);


--
-- Name: services Allow public insert access to services; Type: POLICY; Schema: public; Owner: postgres
--

CREATE POLICY "Allow public insert access to services" ON public.services FOR INSERT WITH CHECK (true);


--
-- Name: telegram_ads Allow public insert access to telegram_ads; Type: POLICY; Schema: public; Owner: postgres
--

CREATE POLICY "Allow public insert access to telegram_ads" ON public.telegram_ads FOR INSERT WITH CHECK (true);


--
-- Name: telegram_bots Allow public insert access to telegram_bots; Type: POLICY; Schema: public; Owner: postgres
--

CREATE POLICY "Allow public insert access to telegram_bots" ON public.telegram_bots FOR INSERT WITH CHECK (true);


--
-- Name: ad_clicks Allow public read access to ad_clicks; Type: POLICY; Schema: public; Owner: postgres
--

CREATE POLICY "Allow public read access to ad_clicks" ON public.ad_clicks FOR SELECT USING (true);


--
-- Name: ad_purchases Allow public read access to ad_purchases; Type: POLICY; Schema: public; Owner: postgres
--

CREATE POLICY "Allow public read access to ad_purchases" ON public.ad_purchases FOR SELECT USING (true);


--
-- Name: ad_sales Allow public read access to ad_sales; Type: POLICY; Schema: public; Owner: postgres
--

CREATE POLICY "Allow public read access to ad_sales" ON public.ad_sales FOR SELECT USING (true);


--
-- Name: channel_ad_rates Allow public read access to channel_ad_rates; Type: POLICY; Schema: public; Owner: postgres
--

CREATE POLICY "Allow public read access to channel_ad_rates" ON public.channel_ad_rates FOR SELECT USING (true);


--
-- Name: media_channels Allow public read access to media_channels; Type: POLICY; Schema: public; Owner: postgres
--

CREATE POLICY "Allow public read access to media_channels" ON public.media_channels FOR SELECT USING (true);


--
-- Name: services Allow public read access to services; Type: POLICY; Schema: public; Owner: postgres
--

CREATE POLICY "Allow public read access to services" ON public.services FOR SELECT USING (true);


--
-- Name: telegram_ads Allow public read access to telegram_ads; Type: POLICY; Schema: public; Owner: postgres
--

CREATE POLICY "Allow public read access to telegram_ads" ON public.telegram_ads FOR SELECT USING (true);


--
-- Name: telegram_bots Allow public read access to telegram_bots; Type: POLICY; Schema: public; Owner: postgres
--

CREATE POLICY "Allow public read access to telegram_bots" ON public.telegram_bots FOR SELECT USING (true);


--
-- Name: ad_purchases Allow public update access to ad_purchases; Type: POLICY; Schema: public; Owner: postgres
--

CREATE POLICY "Allow public update access to ad_purchases" ON public.ad_purchases FOR UPDATE USING (true);


--
-- Name: ad_sales Allow public update access to ad_sales; Type: POLICY; Schema: public; Owner: postgres
--

CREATE POLICY "Allow public update access to ad_sales" ON public.ad_sales FOR UPDATE USING (true);


--
-- Name: channel_ad_rates Allow public update access to channel_ad_rates; Type: POLICY; Schema: public; Owner: postgres
--

CREATE POLICY "Allow public update access to channel_ad_rates" ON public.channel_ad_rates FOR UPDATE USING (true);


--
-- Name: media_channels Allow public update access to media_channels; Type: POLICY; Schema: public; Owner: postgres
--

CREATE POLICY "Allow public update access to media_channels" ON public.media_channels FOR UPDATE USING (true);


--
-- Name: services Allow public update access to services; Type: POLICY; Schema: public; Owner: postgres
--

CREATE POLICY "Allow public update access to services" ON public.services FOR UPDATE USING (true);


--
-- Name: telegram_ads Allow public update access to telegram_ads; Type: POLICY; Schema: public; Owner: postgres
--

CREATE POLICY "Allow public update access to telegram_ads" ON public.telegram_ads FOR UPDATE USING (true);


--
-- Name: telegram_bots Allow public update access to telegram_bots; Type: POLICY; Schema: public; Owner: postgres
--

CREATE POLICY "Allow public update access to telegram_bots" ON public.telegram_bots FOR UPDATE USING (true);


--
-- Name: app_settings App Settings: Modify (Admin); Type: POLICY; Schema: public; Owner: postgres
--

CREATE POLICY "App Settings: Modify (Admin)" ON public.app_settings USING ((auth.role() = ANY (ARRAY['admin'::text, 'superadmin'::text])));


--
-- Name: app_settings App Settings: Read (Authenticated); Type: POLICY; Schema: public; Owner: postgres
--

CREATE POLICY "App Settings: Read (Authenticated)" ON public.app_settings FOR SELECT USING ((auth.role() IS NOT NULL));


--
-- Name: backups Backups: All (Admin); Type: POLICY; Schema: public; Owner: postgres
--

CREATE POLICY "Backups: All (Admin)" ON public.backups USING ((auth.role() = ANY (ARRAY['admin'::text, 'superadmin'::text])));


--
-- Name: dns_configs DNS: All (Admin); Type: POLICY; Schema: public; Owner: postgres
--

CREATE POLICY "DNS: All (Admin)" ON public.dns_configs USING ((auth.role() = ANY (ARRAY['admin'::text, 'superadmin'::text])));


--
-- Name: firewall_rules Firewall: All (Admin); Type: POLICY; Schema: public; Owner: postgres
--

CREATE POLICY "Firewall: All (Admin)" ON public.firewall_rules USING ((auth.role() = ANY (ARRAY['admin'::text, 'superadmin'::text])));


--
-- Name: media_channels Media Channels: Modify (Admin); Type: POLICY; Schema: public; Owner: postgres
--

CREATE POLICY "Media Channels: Modify (Admin)" ON public.media_channels USING ((auth.role() = ANY (ARRAY['admin'::text, 'superadmin'::text])));


--
-- Name: media_channels Media Channels: Read (Authenticated); Type: POLICY; Schema: public; Owner: postgres
--

CREATE POLICY "Media Channels: Read (Authenticated)" ON public.media_channels FOR SELECT USING ((auth.role() IS NOT NULL));


--
-- Name: network_traffic Network Traffic: Insert (System); Type: POLICY; Schema: public; Owner: postgres
--

CREATE POLICY "Network Traffic: Insert (System)" ON public.network_traffic FOR INSERT WITH CHECK (true);


--
-- Name: network_traffic Network Traffic: Read (Authenticated); Type: POLICY; Schema: public; Owner: postgres
--

CREATE POLICY "Network Traffic: Read (Authenticated)" ON public.network_traffic FOR SELECT USING ((auth.role() IS NOT NULL));


--
-- Name: security_settings Security: All (Admin); Type: POLICY; Schema: public; Owner: postgres
--

CREATE POLICY "Security: All (Admin)" ON public.security_settings USING ((auth.role() = ANY (ARRAY['admin'::text, 'superadmin'::text])));


--
-- Name: service_uptime Service Uptime: Insert (System); Type: POLICY; Schema: public; Owner: postgres
--

CREATE POLICY "Service Uptime: Insert (System)" ON public.service_uptime FOR INSERT WITH CHECK (true);


--
-- Name: service_uptime Service Uptime: Read (Authenticated); Type: POLICY; Schema: public; Owner: postgres
--

CREATE POLICY "Service Uptime: Read (Authenticated)" ON public.service_uptime FOR SELECT USING ((auth.role() IS NOT NULL));


--
-- Name: services Services: Modify (Admin); Type: POLICY; Schema: public; Owner: postgres
--

CREATE POLICY "Services: Modify (Admin)" ON public.services USING ((auth.role() = ANY (ARRAY['admin'::text, 'superadmin'::text])));


--
-- Name: services Services: Read (Authenticated); Type: POLICY; Schema: public; Owner: postgres
--

CREATE POLICY "Services: Read (Authenticated)" ON public.services FOR SELECT USING ((auth.role() IS NOT NULL));


--
-- Name: system_metrics System Metrics: Insert (System); Type: POLICY; Schema: public; Owner: postgres
--

CREATE POLICY "System Metrics: Insert (System)" ON public.system_metrics FOR INSERT WITH CHECK (true);


--
-- Name: system_metrics System Metrics: Read (Authenticated); Type: POLICY; Schema: public; Owner: postgres
--

CREATE POLICY "System Metrics: Read (Authenticated)" ON public.system_metrics FOR SELECT USING ((auth.role() IS NOT NULL));


--
-- Name: telegram_ads Telegram Ads: All (Admin); Type: POLICY; Schema: public; Owner: postgres
--

CREATE POLICY "Telegram Ads: All (Admin)" ON public.telegram_ads USING ((auth.role() = ANY (ARRAY['admin'::text, 'superadmin'::text])));


--
-- Name: telegram_bots Telegram Bots: All (Admin); Type: POLICY; Schema: public; Owner: postgres
--

CREATE POLICY "Telegram Bots: All (Admin)" ON public.telegram_bots USING ((auth.role() = ANY (ARRAY['admin'::text, 'superadmin'::text])));


--
-- Name: vpn_profiles VPN: All (Admin); Type: POLICY; Schema: public; Owner: postgres
--

CREATE POLICY "VPN: All (Admin)" ON public.vpn_profiles USING ((auth.role() = ANY (ARRAY['admin'::text, 'superadmin'::text])));


--
-- Name: activity_logs; Type: ROW SECURITY; Schema: public; Owner: postgres
--

ALTER TABLE public.activity_logs ENABLE ROW LEVEL SECURITY;

--
-- Name: ad_clicks; Type: ROW SECURITY; Schema: public; Owner: postgres
--

ALTER TABLE public.ad_clicks ENABLE ROW LEVEL SECURITY;

--
-- Name: ad_purchases; Type: ROW SECURITY; Schema: public; Owner: postgres
--

ALTER TABLE public.ad_purchases ENABLE ROW LEVEL SECURITY;

--
-- Name: ad_sales; Type: ROW SECURITY; Schema: public; Owner: postgres
--

ALTER TABLE public.ad_sales ENABLE ROW LEVEL SECURITY;

--
-- Name: admins; Type: ROW SECURITY; Schema: public; Owner: postgres
--

ALTER TABLE public.admins ENABLE ROW LEVEL SECURITY;

--
-- Name: ai_requests; Type: ROW SECURITY; Schema: public; Owner: postgres
--

ALTER TABLE public.ai_requests ENABLE ROW LEVEL SECURITY;

--
-- Name: ad_clicks allow_all_ad_clicks; Type: POLICY; Schema: public; Owner: postgres
--

CREATE POLICY allow_all_ad_clicks ON public.ad_clicks USING (true) WITH CHECK (true);


--
-- Name: ad_purchases allow_all_ad_purchases; Type: POLICY; Schema: public; Owner: postgres
--

CREATE POLICY allow_all_ad_purchases ON public.ad_purchases USING (true) WITH CHECK (true);


--
-- Name: ad_sales allow_all_ad_sales; Type: POLICY; Schema: public; Owner: postgres
--

CREATE POLICY allow_all_ad_sales ON public.ad_sales USING (true) WITH CHECK (true);


--
-- Name: admins allow_all_admins; Type: POLICY; Schema: public; Owner: postgres
--

CREATE POLICY allow_all_admins ON public.admins USING (true) WITH CHECK (true);


--
-- Name: ai_requests allow_all_ai_requests; Type: POLICY; Schema: public; Owner: postgres
--

CREATE POLICY allow_all_ai_requests ON public.ai_requests USING (true) WITH CHECK (true);


--
-- Name: backups allow_all_backups; Type: POLICY; Schema: public; Owner: postgres
--

CREATE POLICY allow_all_backups ON public.backups USING (true) WITH CHECK (true);


--
-- Name: channel_ad_rates allow_all_channel_ad_rates; Type: POLICY; Schema: public; Owner: postgres
--

CREATE POLICY allow_all_channel_ad_rates ON public.channel_ad_rates USING (true) WITH CHECK (true);


--
-- Name: activity_logs allow_all_delete_activity_logs; Type: POLICY; Schema: public; Owner: postgres
--

CREATE POLICY allow_all_delete_activity_logs ON public.activity_logs FOR DELETE USING (true);


--
-- Name: app_settings allow_all_delete_app_settings; Type: POLICY; Schema: public; Owner: postgres
--

CREATE POLICY allow_all_delete_app_settings ON public.app_settings FOR DELETE USING (true);


--
-- Name: dns_configs allow_all_delete_dns_configs; Type: POLICY; Schema: public; Owner: postgres
--

CREATE POLICY allow_all_delete_dns_configs ON public.dns_configs FOR DELETE USING (true);


--
-- Name: firewall_rules allow_all_delete_firewall_rules; Type: POLICY; Schema: public; Owner: postgres
--

CREATE POLICY allow_all_delete_firewall_rules ON public.firewall_rules FOR DELETE USING (true);


--
-- Name: monitored_hosts allow_all_delete_monitored_hosts; Type: POLICY; Schema: public; Owner: postgres
--

CREATE POLICY allow_all_delete_monitored_hosts ON public.monitored_hosts FOR DELETE USING (true);


--
-- Name: network_traffic allow_all_delete_network_traffic; Type: POLICY; Schema: public; Owner: postgres
--

CREATE POLICY allow_all_delete_network_traffic ON public.network_traffic FOR DELETE USING (true);


--
-- Name: security_settings allow_all_delete_security_settings; Type: POLICY; Schema: public; Owner: postgres
--

CREATE POLICY allow_all_delete_security_settings ON public.security_settings FOR DELETE USING (true);


--
-- Name: system_metrics allow_all_delete_system_metrics; Type: POLICY; Schema: public; Owner: postgres
--

CREATE POLICY allow_all_delete_system_metrics ON public.system_metrics FOR DELETE USING (true);


--
-- Name: vpn_profiles allow_all_delete_vpn_profiles; Type: POLICY; Schema: public; Owner: postgres
--

CREATE POLICY allow_all_delete_vpn_profiles ON public.vpn_profiles FOR DELETE USING (true);


--
-- Name: activity_logs allow_all_insert_activity_logs; Type: POLICY; Schema: public; Owner: postgres
--

CREATE POLICY allow_all_insert_activity_logs ON public.activity_logs FOR INSERT WITH CHECK (true);


--
-- Name: app_settings allow_all_insert_app_settings; Type: POLICY; Schema: public; Owner: postgres
--

CREATE POLICY allow_all_insert_app_settings ON public.app_settings FOR INSERT WITH CHECK (true);


--
-- Name: dns_configs allow_all_insert_dns_configs; Type: POLICY; Schema: public; Owner: postgres
--

CREATE POLICY allow_all_insert_dns_configs ON public.dns_configs FOR INSERT WITH CHECK (true);


--
-- Name: firewall_rules allow_all_insert_firewall_rules; Type: POLICY; Schema: public; Owner: postgres
--

CREATE POLICY allow_all_insert_firewall_rules ON public.firewall_rules FOR INSERT WITH CHECK (true);


--
-- Name: monitored_hosts allow_all_insert_monitored_hosts; Type: POLICY; Schema: public; Owner: postgres
--

CREATE POLICY allow_all_insert_monitored_hosts ON public.monitored_hosts FOR INSERT WITH CHECK (true);


--
-- Name: network_traffic allow_all_insert_network_traffic; Type: POLICY; Schema: public; Owner: postgres
--

CREATE POLICY allow_all_insert_network_traffic ON public.network_traffic FOR INSERT WITH CHECK (true);


--
-- Name: security_settings allow_all_insert_security_settings; Type: POLICY; Schema: public; Owner: postgres
--

CREATE POLICY allow_all_insert_security_settings ON public.security_settings FOR INSERT WITH CHECK (true);


--
-- Name: system_metrics allow_all_insert_system_metrics; Type: POLICY; Schema: public; Owner: postgres
--

CREATE POLICY allow_all_insert_system_metrics ON public.system_metrics FOR INSERT WITH CHECK (true);


--
-- Name: vpn_profiles allow_all_insert_vpn_profiles; Type: POLICY; Schema: public; Owner: postgres
--

CREATE POLICY allow_all_insert_vpn_profiles ON public.vpn_profiles FOR INSERT WITH CHECK (true);


--
-- Name: media_channels allow_all_media_channels; Type: POLICY; Schema: public; Owner: postgres
--

CREATE POLICY allow_all_media_channels ON public.media_channels USING (true) WITH CHECK (true);


--
-- Name: activity_logs allow_all_select_activity_logs; Type: POLICY; Schema: public; Owner: postgres
--

CREATE POLICY allow_all_select_activity_logs ON public.activity_logs FOR SELECT USING (true);


--
-- Name: app_settings allow_all_select_app_settings; Type: POLICY; Schema: public; Owner: postgres
--

CREATE POLICY allow_all_select_app_settings ON public.app_settings FOR SELECT USING (true);


--
-- Name: dns_configs allow_all_select_dns_configs; Type: POLICY; Schema: public; Owner: postgres
--

CREATE POLICY allow_all_select_dns_configs ON public.dns_configs FOR SELECT USING (true);


--
-- Name: firewall_rules allow_all_select_firewall_rules; Type: POLICY; Schema: public; Owner: postgres
--

CREATE POLICY allow_all_select_firewall_rules ON public.firewall_rules FOR SELECT USING (true);


--
-- Name: monitored_hosts allow_all_select_monitored_hosts; Type: POLICY; Schema: public; Owner: postgres
--

CREATE POLICY allow_all_select_monitored_hosts ON public.monitored_hosts FOR SELECT USING (true);


--
-- Name: network_traffic allow_all_select_network_traffic; Type: POLICY; Schema: public; Owner: postgres
--

CREATE POLICY allow_all_select_network_traffic ON public.network_traffic FOR SELECT USING (true);


--
-- Name: security_settings allow_all_select_security_settings; Type: POLICY; Schema: public; Owner: postgres
--

CREATE POLICY allow_all_select_security_settings ON public.security_settings FOR SELECT USING (true);


--
-- Name: system_metrics allow_all_select_system_metrics; Type: POLICY; Schema: public; Owner: postgres
--

CREATE POLICY allow_all_select_system_metrics ON public.system_metrics FOR SELECT USING (true);


--
-- Name: vpn_profiles allow_all_select_vpn_profiles; Type: POLICY; Schema: public; Owner: postgres
--

CREATE POLICY allow_all_select_vpn_profiles ON public.vpn_profiles FOR SELECT USING (true);


--
-- Name: service_uptime allow_all_service_uptime; Type: POLICY; Schema: public; Owner: postgres
--

CREATE POLICY allow_all_service_uptime ON public.service_uptime USING (true) WITH CHECK (true);


--
-- Name: telegram_ads allow_all_telegram_ads; Type: POLICY; Schema: public; Owner: postgres
--

CREATE POLICY allow_all_telegram_ads ON public.telegram_ads USING (true) WITH CHECK (true);


--
-- Name: telegram_bots allow_all_telegram_bots; Type: POLICY; Schema: public; Owner: postgres
--

CREATE POLICY allow_all_telegram_bots ON public.telegram_bots USING (true) WITH CHECK (true);


--
-- Name: activity_logs allow_all_update_activity_logs; Type: POLICY; Schema: public; Owner: postgres
--

CREATE POLICY allow_all_update_activity_logs ON public.activity_logs FOR UPDATE USING (true);


--
-- Name: app_settings allow_all_update_app_settings; Type: POLICY; Schema: public; Owner: postgres
--

CREATE POLICY allow_all_update_app_settings ON public.app_settings FOR UPDATE USING (true);


--
-- Name: dns_configs allow_all_update_dns_configs; Type: POLICY; Schema: public; Owner: postgres
--

CREATE POLICY allow_all_update_dns_configs ON public.dns_configs FOR UPDATE USING (true);


--
-- Name: firewall_rules allow_all_update_firewall_rules; Type: POLICY; Schema: public; Owner: postgres
--

CREATE POLICY allow_all_update_firewall_rules ON public.firewall_rules FOR UPDATE USING (true);


--
-- Name: monitored_hosts allow_all_update_monitored_hosts; Type: POLICY; Schema: public; Owner: postgres
--

CREATE POLICY allow_all_update_monitored_hosts ON public.monitored_hosts FOR UPDATE USING (true);


--
-- Name: network_traffic allow_all_update_network_traffic; Type: POLICY; Schema: public; Owner: postgres
--

CREATE POLICY allow_all_update_network_traffic ON public.network_traffic FOR UPDATE USING (true);


--
-- Name: security_settings allow_all_update_security_settings; Type: POLICY; Schema: public; Owner: postgres
--

CREATE POLICY allow_all_update_security_settings ON public.security_settings FOR UPDATE USING (true);


--
-- Name: system_metrics allow_all_update_system_metrics; Type: POLICY; Schema: public; Owner: postgres
--

CREATE POLICY allow_all_update_system_metrics ON public.system_metrics FOR UPDATE USING (true);


--
-- Name: vpn_profiles allow_all_update_vpn_profiles; Type: POLICY; Schema: public; Owner: postgres
--

CREATE POLICY allow_all_update_vpn_profiles ON public.vpn_profiles FOR UPDATE USING (true);


--
-- Name: app_settings; Type: ROW SECURITY; Schema: public; Owner: postgres
--

ALTER TABLE public.app_settings ENABLE ROW LEVEL SECURITY;

--
-- Name: backups; Type: ROW SECURITY; Schema: public; Owner: postgres
--

ALTER TABLE public.backups ENABLE ROW LEVEL SECURITY;

--
-- Name: channel_ad_rates; Type: ROW SECURITY; Schema: public; Owner: postgres
--

ALTER TABLE public.channel_ad_rates ENABLE ROW LEVEL SECURITY;

--
-- Name: dns_configs; Type: ROW SECURITY; Schema: public; Owner: postgres
--

ALTER TABLE public.dns_configs ENABLE ROW LEVEL SECURITY;

--
-- Name: firewall_rules; Type: ROW SECURITY; Schema: public; Owner: postgres
--

ALTER TABLE public.firewall_rules ENABLE ROW LEVEL SECURITY;

--
-- Name: media_channels; Type: ROW SECURITY; Schema: public; Owner: postgres
--

ALTER TABLE public.media_channels ENABLE ROW LEVEL SECURITY;

--
-- Name: monitored_hosts; Type: ROW SECURITY; Schema: public; Owner: postgres
--

ALTER TABLE public.monitored_hosts ENABLE ROW LEVEL SECURITY;

--
-- Name: network_traffic; Type: ROW SECURITY; Schema: public; Owner: postgres
--

ALTER TABLE public.network_traffic ENABLE ROW LEVEL SECURITY;

--
-- Name: security_settings; Type: ROW SECURITY; Schema: public; Owner: postgres
--

ALTER TABLE public.security_settings ENABLE ROW LEVEL SECURITY;

--
-- Name: service_uptime; Type: ROW SECURITY; Schema: public; Owner: postgres
--

ALTER TABLE public.service_uptime ENABLE ROW LEVEL SECURITY;

--
-- Name: services; Type: ROW SECURITY; Schema: public; Owner: postgres
--

ALTER TABLE public.services ENABLE ROW LEVEL SECURITY;

--
-- Name: system_metrics; Type: ROW SECURITY; Schema: public; Owner: postgres
--

ALTER TABLE public.system_metrics ENABLE ROW LEVEL SECURITY;

--
-- Name: telegram_ads; Type: ROW SECURITY; Schema: public; Owner: postgres
--

ALTER TABLE public.telegram_ads ENABLE ROW LEVEL SECURITY;

--
-- Name: telegram_bots; Type: ROW SECURITY; Schema: public; Owner: postgres
--

ALTER TABLE public.telegram_bots ENABLE ROW LEVEL SECURITY;

--
-- Name: vpn_profiles; Type: ROW SECURITY; Schema: public; Owner: postgres
--

ALTER TABLE public.vpn_profiles ENABLE ROW LEVEL SECURITY;

--
-- PostgreSQL database dump complete
--

\unrestrict HtQEF16DByZAoWFWcHLot9IfgGJRf8Yeg2hmS6mxFjKIsNCrA0A9ofkLHF5910B

