--
-- PostgreSQL database dump
--

\restrict ooTo6xBfrOOURBEZInhTLftDygIleGdmEnb1HayfUFccuQoBHdH1IaUQg0Rtp6m

-- Dumped from database version 16.11
-- Dumped by pg_dump version 16.11

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET xmloption = content;
SET client_min_messages = warning;
SET row_security = off;

--
-- Name: pgcrypto; Type: EXTENSION; Schema: -; Owner: -
--

CREATE EXTENSION IF NOT EXISTS pgcrypto WITH SCHEMA public;


--
-- Name: EXTENSION pgcrypto; Type: COMMENT; Schema: -; Owner: 
--

COMMENT ON EXTENSION pgcrypto IS 'cryptographic functions';


--
-- Name: cleanup_old_data(); Type: FUNCTION; Schema: public; Owner: postgres
--

CREATE FUNCTION public.cleanup_old_data() RETURNS void
    LANGUAGE plpgsql
    AS $$
BEGIN
    DELETE FROM system_metrics WHERE timestamp < now() - interval '7 days';
    DELETE FROM network_traffic WHERE recorded_at < now() - interval '7 days';
    DELETE FROM disk_snapshots WHERE timestamp < now() - interval '7 days';
END;
$$;


ALTER FUNCTION public.cleanup_old_data() OWNER TO postgres;

--
-- Name: update_updated_at_column(); Type: FUNCTION; Schema: public; Owner: postgres
--

CREATE FUNCTION public.update_updated_at_column() RETURNS trigger
    LANGUAGE plpgsql
    AS $$
BEGIN
    NEW.updated_at = now();
    RETURN NEW;
END;
$$;


ALTER FUNCTION public.update_updated_at_column() OWNER TO postgres;

SET default_tablespace = '';

SET default_table_access_method = heap;

--
-- Name: activity_logs; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.activity_logs (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    action_key text,
    target text,
    user_name text,
    activity_type text,
    "timestamp" timestamp with time zone DEFAULT now(),
    description text,
    metadata jsonb
);


ALTER TABLE public.activity_logs OWNER TO postgres;

--
-- Name: admins; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.admins (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    email text NOT NULL,
    password_hash text,
    name text NOT NULL,
    phone text,
    telegram_chat_id text,
    telegram_username text,
    role text DEFAULT 'admin'::text,
    avatar_url text,
    is_active boolean DEFAULT true,
    receive_notifications boolean DEFAULT true,
    last_login_at timestamp with time zone,
    created_at timestamp with time zone DEFAULT now(),
    updated_at timestamp with time zone DEFAULT now(),
    online_status text DEFAULT 'offline'::text,
    last_seen_at timestamp with time zone
);


ALTER TABLE public.admins OWNER TO postgres;

--
-- Name: ai_requests; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.ai_requests (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    model text DEFAULT 'gpt-4'::text,
    prompt text,
    response text,
    tokens_used integer DEFAULT 0,
    cost numeric(10,4) DEFAULT 0,
    created_at timestamp with time zone DEFAULT now()
);


ALTER TABLE public.ai_requests OWNER TO postgres;

--
-- Name: app_settings; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.app_settings (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    key text NOT NULL,
    value jsonb,
    created_at timestamp with time zone DEFAULT now(),
    updated_at timestamp with time zone DEFAULT now()
);


ALTER TABLE public.app_settings OWNER TO postgres;

--
-- Name: backups; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.backups (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    name text NOT NULL,
    type text,
    size_bytes bigint,
    path text,
    status text DEFAULT 'completed'::text,
    created_at timestamp with time zone DEFAULT now()
);


ALTER TABLE public.backups OWNER TO postgres;

--
-- Name: disk_snapshots; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.disk_snapshots (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    name text,
    mount_point text,
    used_bytes bigint,
    total_bytes bigint,
    percent double precision,
    fs_type text,
    "timestamp" timestamp with time zone DEFAULT now()
);


ALTER TABLE public.disk_snapshots OWNER TO postgres;

--
-- Name: dns_configs; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.dns_configs (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    name text NOT NULL,
    primary_dns text,
    secondary_dns text,
    is_active boolean DEFAULT true,
    created_at timestamp with time zone DEFAULT now(),
    updated_at timestamp with time zone DEFAULT now()
);


ALTER TABLE public.dns_configs OWNER TO postgres;

--
-- Name: firewall_rules; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.firewall_rules (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    port text NOT NULL,
    from_ip text DEFAULT 'LAN'::text,
    protocol text DEFAULT 'tcp'::text,
    comment text,
    is_active boolean DEFAULT true,
    created_at timestamp with time zone DEFAULT now(),
    updated_at timestamp with time zone DEFAULT now()
);


ALTER TABLE public.firewall_rules OWNER TO postgres;

--
-- Name: media_channels; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.media_channels (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    name text NOT NULL,
    platform text NOT NULL,
    channel_id text,
    username text,
    channel_url text,
    subscribers integer DEFAULT 0,
    views integer DEFAULT 0,
    engagement numeric(5,2) DEFAULT 0,
    growth numeric(5,2) DEFAULT 0,
    videos_count integer DEFAULT 0,
    is_monetized boolean DEFAULT false,
    watch_hours integer DEFAULT 0,
    avg_view_duration integer DEFAULT 0,
    ctr numeric DEFAULT 0,
    revenue numeric DEFAULT 0,
    likes integer DEFAULT 0,
    comments integer DEFAULT 0,
    shares integer DEFAULT 0,
    is_active boolean DEFAULT true,
    last_synced_at timestamp with time zone,
    created_at timestamp with time zone DEFAULT now(),
    updated_at timestamp with time zone DEFAULT now(),
    CONSTRAINT media_channels_platform_check CHECK ((platform = ANY (ARRAY['youtube'::text, 'tiktok'::text, 'rutube'::text, 'telegram'::text, 'max'::text, 'vk'::text])))
);


ALTER TABLE public.media_channels OWNER TO postgres;

--
-- Name: monitored_hosts; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.monitored_hosts (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    name text NOT NULL,
    host text NOT NULL,
    check_type text DEFAULT 'ping'::text,
    status text DEFAULT 'unknown'::text,
    response_time_ms integer,
    last_check_at timestamp with time zone,
    is_active boolean DEFAULT true,
    created_at timestamp with time zone DEFAULT now(),
    updated_at timestamp with time zone DEFAULT now()
);


ALTER TABLE public.monitored_hosts OWNER TO postgres;

--
-- Name: network_traffic; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.network_traffic (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    interface_name text,
    rx_bytes bigint,
    tx_bytes bigint,
    recorded_at timestamp with time zone DEFAULT now(),
    rx_rate bigint,
    tx_rate bigint
);


ALTER TABLE public.network_traffic OWNER TO postgres;

--
-- Name: security_settings; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.security_settings (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    ufw_status text DEFAULT 'unknown'::text,
    fail2ban_status text DEFAULT 'unknown'::text,
    ssh_port integer DEFAULT 22,
    last_check_at timestamp with time zone,
    created_at timestamp with time zone DEFAULT now(),
    updated_at timestamp with time zone DEFAULT now()
);


ALTER TABLE public.security_settings OWNER TO postgres;

--
-- Name: service_uptime; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.service_uptime (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    service_id uuid,
    status text NOT NULL,
    response_time_ms integer,
    checked_at timestamp with time zone DEFAULT now()
);


ALTER TABLE public.service_uptime OWNER TO postgres;

--
-- Name: services; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.services (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    name text NOT NULL,
    description text,
    category text DEFAULT 'admin'::text,
    port text NOT NULL,
    url text,
    icon text DEFAULT 'server'::text,
    is_active boolean DEFAULT true,
    status text DEFAULT 'unknown'::text,
    last_check_at timestamp with time zone,
    response_time_ms integer,
    created_at timestamp with time zone DEFAULT now(),
    updated_at timestamp with time zone DEFAULT now()
);


ALTER TABLE public.services OWNER TO postgres;

--
-- Name: system_metrics; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.system_metrics (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    "timestamp" timestamp with time zone DEFAULT now(),
    cpu_percent double precision,
    ram_percent double precision,
    net_rx_total bigint,
    net_tx_total bigint
);


ALTER TABLE public.system_metrics OWNER TO postgres;

--
-- Name: telegram_bots; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.telegram_bots (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    name text NOT NULL,
    token text NOT NULL,
    username text,
    description text,
    is_active boolean DEFAULT true,
    created_at timestamp with time zone DEFAULT now(),
    updated_at timestamp with time zone DEFAULT now()
);


ALTER TABLE public.telegram_bots OWNER TO postgres;

--
-- Name: vpn_profiles; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.vpn_profiles (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    name text NOT NULL,
    config text,
    is_active boolean DEFAULT true,
    created_at timestamp with time zone DEFAULT now(),
    updated_at timestamp with time zone DEFAULT now()
);


ALTER TABLE public.vpn_profiles OWNER TO postgres;

--
-- Data for Name: activity_logs; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.activity_logs (id, action_key, target, user_name, activity_type, "timestamp", description, metadata) FROM stdin;
acf215a5-2dd4-4663-b6bb-88d8d463ee98	serviceStarted	Stats Recorder	Stats Recorder	server	2026-01-04 14:49:25.073421+00	\N	\N
ff03bea8-9ad2-4276-828d-ee3fadb040ca	serviceStarted	Stats Recorder	Stats Recorder	server	2026-01-05 08:36:30.923264+00	\N	\N
71e4e35c-0f6a-499f-85f4-acfcc71b4254	serviceStarted	Stats Recorder	Stats Recorder	server	2026-01-05 11:56:00.662673+00	\N	\N
3eb4fd64-2287-4ce8-b9fc-e44e4ac85a0c	serviceStarted	Stats Recorder	Stats Recorder	server	2026-01-05 12:33:12.737701+00	\N	\N
e1cade4b-1c37-49a8-9b3c-b41028e72987	serviceStarted	Stats Recorder	Stats Recorder	server	2026-01-05 14:45:35.029883+00	\N	\N
03541d41-1935-40d0-9201-9bfdb0fe4532	serviceStarted	Stats Recorder	Stats Recorder	server	2026-01-06 06:27:34.97324+00	\N	\N
6d9e1fb7-75e9-4f1b-ad31-77c9aad0f6da	cacheCleared	Browser Storage	admin	server	2026-01-06 11:11:20.270706+00	\N	\N
e2534415-e7ff-46a1-9bdd-c1387e146941	serviceStarted	Stats Recorder	Stats Recorder	server	2026-01-07 17:49:30.604696+00	\N	\N
00828e02-4838-4683-87ee-317a67ba5a53	\N	\N	\N	LOGIN_SUCCESS	2026-01-07 18:33:50.997959+00	User admin@example.com logged in successfully	{"user_id": "8aae7ff5-abf6-41b1-ae4f-4485a9d3b160", "timestamp": "2026-01-07T18:33:50.997Z", "ip_address": "::ffff:172.18.0.12", "user_agent": "system-api"}
d9b67e3e-a30c-46d0-9e06-4fbc6f6d334d	\N	\N	\N	LOGIN_FAILED	2026-01-08 02:00:46.239368+00	Failed login attempt for non-existent user: admin@example.comadmin@example.com	{"user_id": null, "timestamp": "2026-01-08T02:00:46.238Z", "ip_address": "::ffff:172.18.0.12", "user_agent": "system-api"}
5af981eb-d00a-4aa4-896d-bee3e0cea124	\N	\N	\N	LOGIN_FAILED	2026-01-08 02:00:53.695714+00	Failed login attempt for non-existent user: admin@example.comadmin@example.com	{"user_id": null, "timestamp": "2026-01-08T02:00:53.695Z", "ip_address": "::ffff:172.18.0.12", "user_agent": "system-api"}
344b9327-172c-444d-ba52-d6bbd4372787	\N	\N	\N	LOGIN_SUCCESS	2026-01-08 02:05:20.811124+00	User admin@example.com logged in successfully	{"user_id": "8aae7ff5-abf6-41b1-ae4f-4485a9d3b160", "timestamp": "2026-01-08T02:05:20.810Z", "ip_address": "::ffff:172.18.0.12", "user_agent": "system-api"}
c7509e38-5724-49bb-8fd7-bad997db8198	\N	\N	\N	LOGIN_SUCCESS	2026-01-08 02:06:25.408684+00	User admin@example.com logged in successfully	{"user_id": "8aae7ff5-abf6-41b1-ae4f-4485a9d3b160", "timestamp": "2026-01-08T02:06:25.408Z", "ip_address": "::ffff:172.18.0.12", "user_agent": "system-api"}
9cad7c23-e3fe-46d2-a285-26dad6f56be4	\N	\N	\N	LOGIN_SUCCESS	2026-01-08 02:09:10.534724+00	User admin@example.com logged in successfully	{"user_id": "8aae7ff5-abf6-41b1-ae4f-4485a9d3b160", "timestamp": "2026-01-08T02:09:10.534Z", "ip_address": "::ffff:172.18.0.12", "user_agent": "system-api"}
c6b06cf9-4fc4-4fe9-be86-2cd23b623dd0	\N	\N	\N	LOGIN_FAILED	2026-01-08 07:28:13.578746+00	Failed login for admin@example.com (invalid password)	{"user_id": "8aae7ff5-abf6-41b1-ae4f-4485a9d3b160", "timestamp": "2026-01-08T07:28:13.577Z", "ip_address": "::ffff:172.18.0.12", "user_agent": "system-api"}
a5cf7a18-c513-4fd9-93a3-279f802593de	\N	\N	\N	LOGIN_FAILED	2026-01-08 07:31:19.138355+00	Failed login for admin@example.com (invalid password)	{"user_id": "8aae7ff5-abf6-41b1-ae4f-4485a9d3b160", "timestamp": "2026-01-08T07:31:19.138Z", "ip_address": "::ffff:172.18.0.12", "user_agent": "system-api"}
924fdfea-0943-433c-816d-514bc32f576f	\N	\N	\N	LOGIN_FAILED	2026-01-08 07:47:10.945142+00	Failed login for admin@example.com (invalid password)	{"user_id": "8aae7ff5-abf6-41b1-ae4f-4485a9d3b160", "timestamp": "2026-01-08T07:47:10.944Z", "ip_address": "::ffff:172.18.0.12", "user_agent": "system-api"}
83995379-52fa-4e6d-a6e6-3196dadae4e6	\N	\N	\N	LOGIN_FAILED	2026-01-08 07:52:06.165461+00	Failed login for admin@example.com (invalid password)	{"user_id": "8aae7ff5-abf6-41b1-ae4f-4485a9d3b160", "timestamp": "2026-01-08T07:52:06.165Z", "ip_address": "::ffff:172.18.0.12", "user_agent": "system-api"}
d9d0e85a-85f2-41af-87e1-d5ea562e3eb0	\N	\N	\N	LOGIN_SUCCESS	2026-01-08 08:02:18.867305+00	User admin@example.com logged in successfully	{"user_id": "8aae7ff5-abf6-41b1-ae4f-4485a9d3b160", "timestamp": "2026-01-08T08:02:18.867Z", "ip_address": "::ffff:172.18.0.12", "user_agent": "system-api"}
9bf8dcc2-397d-49e7-84e7-30ef6ca3a796	serviceStarted	Stats Recorder	Stats Recorder	server	2026-01-09 10:09:58.167107+00	\N	\N
a37e6ec4-c621-48cc-9b3e-101d880b4788	serviceStarted	Stats Recorder	Stats Recorder	server	2026-01-09 15:16:58.052265+00	\N	\N
f386fae8-03ac-411e-920d-8fbea2f23f73	serviceStarted	Stats Recorder	Stats Recorder	server	2026-01-24 14:07:52.958673+00	\N	\N
bf087a63-1076-4aa3-863d-7d16ec26b1f2	serviceStarted	Stats Recorder	Stats Recorder	server	2026-01-24 14:14:52.812866+00	\N	\N
7c5b0b3e-319a-4bbd-996e-b9d7231bbd84	serviceStarted	Stats Recorder	Stats Recorder	server	2026-01-24 14:15:27.995347+00	\N	\N
eba1d459-470a-4c4c-8558-eaa58f2d293b	serviceStarted	Stats Recorder	Stats Recorder	server	2026-01-24 14:16:54.155743+00	\N	\N
\.


--
-- Data for Name: admins; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.admins (id, email, password_hash, name, phone, telegram_chat_id, telegram_username, role, avatar_url, is_active, receive_notifications, last_login_at, created_at, updated_at, online_status, last_seen_at) FROM stdin;
8aae7ff5-abf6-41b1-ae4f-4485a9d3b160	admin@example.com	$2a$10$UTqk.96MNkxFI90Jt41Q0.xn7TAm1MijZRFfM3Z5yg6E/LB248.lS	Admin User	\N	\N	\N	superadmin	\N	t	t	2026-01-08 08:02:18.853485+00	2026-01-02 15:31:19.536938+00	2026-01-08 08:02:18.853485+00	offline	\N
\.


--
-- Data for Name: ai_requests; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.ai_requests (id, model, prompt, response, tokens_used, cost, created_at) FROM stdin;
\.


--
-- Data for Name: app_settings; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.app_settings (id, key, value, created_at, updated_at) FROM stdin;
\.


--
-- Data for Name: backups; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.backups (id, name, type, size_bytes, path, status, created_at) FROM stdin;
d36e9da3-7582-4727-b463-d3251abb02dc	creationhub_security_fixed_v2.6	manual	6450729	/home/inno/compose_ARCHIVED_DO_NOT_USE/backups/creationhub_security_fixed_20260109_1230	completed	2026-01-09 09:32:52.954402+00
\.


--
-- Data for Name: disk_snapshots; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.disk_snapshots (id, name, mount_point, used_bytes, total_bytes, percent, fs_type, "timestamp") FROM stdin;
b9f0ce73-1822-48db-b1e7-6ad0a0b3c19a	System	/	190099058688	248215199744	80.2	ext4	2026-01-24 14:21:54.449564+00
5e09b2fe-8a71-49a5-8b9a-ded5ae53a2a6	Backups	/home/inno/compose/backups	29595119616	195762728960	15.9	ext4	2026-01-24 14:21:54.452699+00
aea84ffb-ce1a-4b58-8b6b-0ab49b31caac	Media	/home/inno/compose/volumes/media	12288	3936818806784	0	ext4	2026-01-24 14:21:54.453801+00
9f98e212-974a-4e5f-97e2-b314366bfdfb	System	/	190194335744	248215199744	80.3	ext4	2026-01-24 20:31:55.620436+00
d6f93be7-d975-4cc8-84fc-f1fd3b50bef0	Backups	/home/inno/compose/backups	29595119616	195762728960	15.9	ext4	2026-01-24 20:31:55.623366+00
ad9d8736-5031-43b2-b1ce-e1e62ff9a17d	Media	/home/inno/compose/volumes/media	12288	3936818806784	0	ext4	2026-01-24 20:31:55.624328+00
135aafe3-8357-4c22-9b34-eabbe8106495	System	/	190100467712	248215199744	80.2	ext4	2026-01-24 14:26:54.513131+00
fa212d7d-1a5b-4439-98e4-da6fa22b2213	Backups	/home/inno/compose/backups	29595119616	195762728960	15.9	ext4	2026-01-24 14:26:54.519291+00
d333a434-2e65-447e-9d02-ee03a2e5ffcd	Media	/home/inno/compose/volumes/media	12288	3936818806784	0	ext4	2026-01-24 14:26:54.520662+00
df9c9a18-8c73-46f9-b7d4-fa0df29539c4	System	/	190195634176	248215199744	80.3	ext4	2026-01-24 20:36:55.663949+00
a631771b-a0b9-4ef5-86b5-015b76b16798	Backups	/home/inno/compose/backups	29595119616	195762728960	15.9	ext4	2026-01-24 20:36:55.667095+00
5bb59baf-c3f5-4cff-ae15-ee52e0457be0	Media	/home/inno/compose/volumes/media	12288	3936818806784	0	ext4	2026-01-24 20:36:55.668139+00
82f04978-4df3-4981-930c-1a0c3b73d822	System	/	190102470656	248215199744	80.2	ext4	2026-01-24 14:31:54.574158+00
f9d35d16-ad96-4a6f-9089-91431d8945f2	Backups	/home/inno/compose/backups	29595119616	195762728960	15.9	ext4	2026-01-24 14:31:54.578217+00
ba63ad8e-adc5-49b6-b75e-5f6268b517c6	Media	/home/inno/compose/volumes/media	12288	3936818806784	0	ext4	2026-01-24 14:31:54.579278+00
0ee7eae6-51fa-43f2-b134-9ccb577dac35	System	/	190196953088	248215199744	80.3	ext4	2026-01-24 20:41:55.692471+00
805b6e6d-cd59-4011-8c2f-2b525bbfee01	Backups	/home/inno/compose/backups	29595119616	195762728960	15.9	ext4	2026-01-24 20:41:55.695398+00
ab661cd6-1ba0-4628-9a77-db96be6f3f68	Media	/home/inno/compose/volumes/media	12288	3936818806784	0	ext4	2026-01-24 20:41:55.696426+00
09e3796d-4784-49fe-ba8a-941cdf0a6102	System	/	190103900160	248215199744	80.2	ext4	2026-01-24 14:36:54.491785+00
086a222f-bba5-4b48-ab4d-3dca4a7d9724	Backups	/home/inno/compose/backups	29595119616	195762728960	15.9	ext4	2026-01-24 14:36:54.495889+00
078e2c4a-7ea5-4de7-a0a8-ba0db174b31e	Media	/home/inno/compose/volumes/media	12288	3936818806784	0	ext4	2026-01-24 14:36:54.498526+00
3cf056d7-bd31-4c9b-b292-cf347deb3185	System	/	190198239232	248215199744	80.3	ext4	2026-01-24 20:46:55.66718+00
c4e76d2f-4a5a-47fc-a0ac-cb6d70d9cd82	Backups	/home/inno/compose/backups	29595119616	195762728960	15.9	ext4	2026-01-24 20:46:55.671119+00
daa5d912-e5df-4bcc-9d2d-3ad71953b297	Media	/home/inno/compose/volumes/media	12288	3936818806784	0	ext4	2026-01-24 20:46:55.672306+00
9e221a35-125e-4676-bc3d-e3f7860a70ed	System	/	190105198592	248215199744	80.2	ext4	2026-01-24 14:41:54.529559+00
38348388-711d-407e-ae7f-774eee0f3a7d	Backups	/home/inno/compose/backups	29595119616	195762728960	15.9	ext4	2026-01-24 14:41:54.533698+00
c67c3061-2017-4836-a889-e0196841747c	Media	/home/inno/compose/volumes/media	12288	3936818806784	0	ext4	2026-01-24 14:41:54.534584+00
3c8808fd-8621-4216-bc73-a5cd1c819dde	System	/	190199549952	248215199744	80.3	ext4	2026-01-24 20:51:55.754142+00
a954983c-779c-45f6-ac92-2196382dba00	Backups	/home/inno/compose/backups	29595119616	195762728960	15.9	ext4	2026-01-24 20:51:55.759831+00
7a6b65d2-705a-4de7-96b1-659eddc929c3	Media	/home/inno/compose/volumes/media	12288	3936818806784	0	ext4	2026-01-24 20:51:55.761384+00
b4ad4367-51af-439f-87fc-2be31f1ae6b3	System	/	190106492928	248215199744	80.2	ext4	2026-01-24 14:46:54.672887+00
60617c4a-fedc-41ed-9feb-98e5d87ebd24	Backups	/home/inno/compose/backups	29595119616	195762728960	15.9	ext4	2026-01-24 14:46:54.676314+00
9386e8a0-53b2-4229-9a3c-dbf7f547facc	Media	/home/inno/compose/volumes/media	12288	3936818806784	0	ext4	2026-01-24 14:46:54.677381+00
c2daf6f0-3c1d-4c3c-96d0-a75a38ab3be3	System	/	190200840192	248215199744	80.3	ext4	2026-01-24 20:56:55.697353+00
56ee1a03-420b-4863-b0fa-091f44b0815e	Backups	/home/inno/compose/backups	29595119616	195762728960	15.9	ext4	2026-01-24 20:56:55.701124+00
662fcb44-d163-4a84-87d4-16ccdc930532	Media	/home/inno/compose/volumes/media	12288	3936818806784	0	ext4	2026-01-24 20:56:55.702239+00
e99416ad-523e-45e8-9b66-54aa16e61c04	System	/	190107791360	248215199744	80.2	ext4	2026-01-24 14:51:54.669934+00
a6ae4e15-67b9-4990-9d2b-1ee4538d7850	Backups	/home/inno/compose/backups	29595119616	195762728960	15.9	ext4	2026-01-24 14:51:54.673422+00
5e7f7546-f236-429c-986d-6a618df7145c	Media	/home/inno/compose/volumes/media	12288	3936818806784	0	ext4	2026-01-24 14:51:54.674413+00
e3e97d1d-01a2-4f71-bdd0-b9444c0257b7	System	/	189907984384	248215199744	80.1	ext4	2026-01-24 21:01:55.613165+00
bdbf3f17-8793-407a-82c1-ffe5492974a1	Backups	/home/inno/compose/backups	29595119616	195762728960	15.9	ext4	2026-01-24 21:01:55.616811+00
578d693e-3d4f-4b4c-9eae-3fe73693f9a0	Media	/home/inno/compose/volumes/media	12288	3936818806784	0	ext4	2026-01-24 21:01:55.617725+00
4b904411-1daa-4bb6-b32b-db86b85ca43b	System	/	190109093888	248215199744	80.2	ext4	2026-01-24 14:56:54.579817+00
974d5b35-5c59-420c-ab90-f306ae4ce819	Backups	/home/inno/compose/backups	29595119616	195762728960	15.9	ext4	2026-01-24 14:56:54.582398+00
8e29d3cc-8222-42e2-bec3-d67371f4c832	Media	/home/inno/compose/volumes/media	12288	3936818806784	0	ext4	2026-01-24 14:56:54.583307+00
0eb995cd-703f-47bc-9608-b1c815bacc59	System	/	189909286912	248215199744	80.1	ext4	2026-01-24 21:06:55.807035+00
a90ec247-f676-447a-8029-4ea8849f588c	Backups	/home/inno/compose/backups	29595119616	195762728960	15.9	ext4	2026-01-24 21:06:55.81283+00
309a6033-e3fb-4f9b-bedd-57309803fecd	Media	/home/inno/compose/volumes/media	12288	3936818806784	0	ext4	2026-01-24 21:06:55.814419+00
0dc9a671-52db-4edf-a015-3916d87a3154	System	/	190110392320	248215199744	80.2	ext4	2026-01-24 15:01:54.610549+00
fdaaae00-0791-4213-9f00-9bbf13d4def4	Backups	/home/inno/compose/backups	29595119616	195762728960	15.9	ext4	2026-01-24 15:01:54.614121+00
7f00c12e-38f8-4a04-8886-65105eeedaa5	Media	/home/inno/compose/volumes/media	12288	3936818806784	0	ext4	2026-01-24 15:01:54.615638+00
a418c72e-16e9-47ca-84ff-34c2497c906f	System	/	189910044672	248215199744	80.1	ext4	2026-01-24 21:11:55.790818+00
93c3d137-c0d0-4248-b639-6048cb5b55d9	Backups	/home/inno/compose/backups	29595119616	195762728960	15.9	ext4	2026-01-24 21:11:55.793405+00
9647e3a2-d8ec-4de1-89a7-ed07c50ed021	Media	/home/inno/compose/volumes/media	12288	3936818806784	0	ext4	2026-01-24 21:11:55.794376+00
18949919-938c-4cde-b709-e74e0112cff2	System	/	190111674368	248215199744	80.2	ext4	2026-01-24 15:06:54.654945+00
3e0990c4-90ac-4442-83d7-e0e681521457	Backups	/home/inno/compose/backups	29595119616	195762728960	15.9	ext4	2026-01-24 15:06:54.657671+00
3f6b30a1-a9a8-4077-a505-77bbad659644	Media	/home/inno/compose/volumes/media	12288	3936818806784	0	ext4	2026-01-24 15:06:54.660132+00
24761c30-08a5-4680-b3c3-c96112fde45a	System	/	189911334912	248215199744	80.1	ext4	2026-01-24 21:16:55.690283+00
63d7e6f1-b220-4392-bfd3-284d28ea7128	Backups	/home/inno/compose/backups	29595119616	195762728960	15.9	ext4	2026-01-24 21:16:55.693182+00
3a75c553-9514-4af7-967d-9e0d24d86219	Media	/home/inno/compose/volumes/media	12288	3936818806784	0	ext4	2026-01-24 21:16:55.694156+00
f5a4173f-26d0-4fd6-af3f-2a2774c6c985	System	/	190112976896	248215199744	80.2	ext4	2026-01-24 15:11:54.616292+00
88903348-8acf-4275-9d65-eea9b4bbc2e9	Backups	/home/inno/compose/backups	29595119616	195762728960	15.9	ext4	2026-01-24 15:11:54.620594+00
760c969e-8282-4e0b-b8be-25cb03532037	Media	/home/inno/compose/volumes/media	12288	3936818806784	0	ext4	2026-01-24 15:11:54.621548+00
4f8ac3da-44ad-4c5f-8e55-3c2cb83f1c80	System	/	189912653824	248215199744	80.1	ext4	2026-01-24 21:21:55.717323+00
14f612a8-a2bd-4eae-bcb8-7b00894e73ef	Backups	/home/inno/compose/backups	29595119616	195762728960	15.9	ext4	2026-01-24 21:21:55.719894+00
bcd085e8-ce63-44f1-a272-e59b778c8b8c	Media	/home/inno/compose/volumes/media	12288	3936818806784	0	ext4	2026-01-24 21:21:55.720779+00
6e7e587b-f49e-449d-a8ef-d2986681f933	System	/	190114271232	248215199744	80.2	ext4	2026-01-24 15:16:54.754014+00
34456466-75f3-4f16-9d27-28ee8a025614	Backups	/home/inno/compose/backups	29595119616	195762728960	15.9	ext4	2026-01-24 15:16:54.755593+00
e6d9694e-fbe3-460e-b317-f7186b42838a	Media	/home/inno/compose/volumes/media	12288	3936818806784	0	ext4	2026-01-24 15:16:54.75658+00
d174cb78-cdff-4be3-97fc-24841cb60132	System	/	189913944064	248215199744	80.1	ext4	2026-01-24 21:26:55.732412+00
0cfbadfb-590f-4605-a79c-99ab9a8d514d	Backups	/home/inno/compose/backups	29595119616	195762728960	15.9	ext4	2026-01-24 21:26:55.735097+00
1e377d0c-c6cf-431f-b57d-6f0db3a14812	Media	/home/inno/compose/volumes/media	12288	3936818806784	0	ext4	2026-01-24 21:26:55.736245+00
3cf78fc2-a6aa-4711-a4c0-767b17b474e1	System	/	190115581952	248215199744	80.2	ext4	2026-01-24 15:21:54.636692+00
4d29236c-118a-4951-ab35-e5affe4773e4	Backups	/home/inno/compose/backups	29595119616	195762728960	15.9	ext4	2026-01-24 15:21:54.639688+00
68e7ed52-8870-4e3f-8747-0df57e674122	Media	/home/inno/compose/volumes/media	12288	3936818806784	0	ext4	2026-01-24 15:21:54.642051+00
430c4b43-5c84-401e-872e-d583f3dd9426	System	/	189919318016	248215199744	80.1	ext4	2026-01-24 21:31:55.775742+00
cbe490da-2d53-41eb-8e3e-aa0dfd5897af	Backups	/home/inno/compose/backups	29595119616	195762728960	15.9	ext4	2026-01-24 21:31:55.778121+00
e1d842d5-29ae-4ba2-ba75-15ab8af1b0a0	Media	/home/inno/compose/volumes/media	12288	3936818806784	0	ext4	2026-01-24 21:31:55.779142+00
89300cd7-46e6-46ec-9985-e633819f112c	System	/	190120939520	248215199744	80.2	ext4	2026-01-24 15:26:54.686278+00
877d5631-8b1d-4da2-86f8-40bd786cd9c3	Backups	/home/inno/compose/backups	29595119616	195762728960	15.9	ext4	2026-01-24 15:26:54.68947+00
7baf49a2-7c44-44ee-b670-c9fbd270be56	Media	/home/inno/compose/volumes/media	12288	3936818806784	0	ext4	2026-01-24 15:26:54.690385+00
c6097a7e-5752-4fd7-ad7e-f1a834714f5f	System	/	189920600064	248215199744	80.1	ext4	2026-01-24 21:36:55.820414+00
a3b2f518-c268-40b2-8147-e86301ad9395	Backups	/home/inno/compose/backups	29595119616	195762728960	15.9	ext4	2026-01-24 21:36:55.823705+00
cb0824e0-a9f3-4200-9ca8-5bf4c973bcba	Media	/home/inno/compose/volumes/media	12288	3936818806784	0	ext4	2026-01-24 21:36:55.825615+00
46a0f1c4-e6cd-4fd9-bdc7-15336553d415	System	/	190122233856	248215199744	80.2	ext4	2026-01-24 15:31:54.787046+00
2bf8b0d9-d7b9-4711-a857-6a5b559e79f4	Backups	/home/inno/compose/backups	29595119616	195762728960	15.9	ext4	2026-01-24 15:31:54.794006+00
13f1a6a5-2b97-48a4-a316-d2b0ca54be2f	Media	/home/inno/compose/volumes/media	12288	3936818806784	0	ext4	2026-01-24 15:31:54.795358+00
670e23c1-12f0-4b93-8790-9b4135b243dc	System	/	189921923072	248215199744	80.1	ext4	2026-01-24 21:41:55.832802+00
0ee8399d-66b1-4b99-ba22-d6a82c459067	Backups	/home/inno/compose/backups	29595119616	195762728960	15.9	ext4	2026-01-24 21:41:55.837219+00
fe8fcc44-c97c-4d6d-aafa-9e3640811afc	Media	/home/inno/compose/volumes/media	12288	3936818806784	0	ext4	2026-01-24 21:41:55.838521+00
1fa12e35-00bb-4990-ad40-c62c437c5fec	System	/	190123520000	248215199744	80.2	ext4	2026-01-24 15:36:54.77828+00
88e2a81f-e1ef-4db3-9fea-073b9b872d6c	Backups	/home/inno/compose/backups	29595119616	195762728960	15.9	ext4	2026-01-24 15:36:54.781921+00
1c649d44-df6a-430b-803c-dfda429cb14e	Media	/home/inno/compose/volumes/media	12288	3936818806784	0	ext4	2026-01-24 15:36:54.783045+00
7e956cc4-ac6c-4d00-96a7-9a2d6cbf8749	System	/	189923213312	248215199744	80.1	ext4	2026-01-24 21:46:55.780993+00
ef53117b-69e4-4acb-9757-461516265672	Backups	/home/inno/compose/backups	29595119616	195762728960	15.9	ext4	2026-01-24 21:46:55.783367+00
c9412dab-39b2-408d-a926-51b11212f675	Media	/home/inno/compose/volumes/media	12288	3936818806784	0	ext4	2026-01-24 21:46:55.784257+00
cdfac023-3401-448b-8546-a70c0683ad0d	System	/	190124834816	248215199744	80.2	ext4	2026-01-24 15:41:54.784634+00
6a398ee4-49a0-49d8-8259-0c24584dc949	Backups	/home/inno/compose/backups	29595119616	195762728960	15.9	ext4	2026-01-24 15:41:54.788935+00
caa13175-8b05-4828-9817-430d681419c5	Media	/home/inno/compose/volumes/media	12288	3936818806784	0	ext4	2026-01-24 15:41:54.79+00
061a19a0-53f1-486f-bb63-68235a629a3f	System	/	189924519936	248215199744	80.1	ext4	2026-01-24 21:51:55.763571+00
55c9b1f2-f9c1-4f0c-a8b4-ebc5f034d5e1	Backups	/home/inno/compose/backups	29595119616	195762728960	15.9	ext4	2026-01-24 21:51:55.766067+00
727dbf9a-4b93-48db-bcda-feb29a83fa49	Media	/home/inno/compose/volumes/media	12288	3936818806784	0	ext4	2026-01-24 21:51:55.767041+00
5829739c-3cdd-4e0d-979c-72f845bb8966	System	/	190126125056	248215199744	80.2	ext4	2026-01-24 15:46:54.73083+00
3fdd758a-dc99-46b8-9b17-6733075ad2ab	Backups	/home/inno/compose/backups	29595119616	195762728960	15.9	ext4	2026-01-24 15:46:54.740155+00
b95ac798-2962-413d-9a34-32f533e05d87	Media	/home/inno/compose/volumes/media	12288	3936818806784	0	ext4	2026-01-24 15:46:54.743609+00
ea45cac0-bda8-455f-b775-3f3b7bdc5856	System	/	189925814272	248215199744	80.1	ext4	2026-01-24 21:56:55.797609+00
de1f14bf-6892-4712-b52c-436f677e6859	Backups	/home/inno/compose/backups	29595119616	195762728960	15.9	ext4	2026-01-24 21:56:55.802306+00
3224a166-5a98-4210-a155-70e20de70604	Media	/home/inno/compose/volumes/media	12288	3936818806784	0	ext4	2026-01-24 21:56:55.803309+00
f47f300d-72ce-4312-8eb4-7f37241c297f	System	/	190127439872	248215199744	80.2	ext4	2026-01-24 15:51:54.734876+00
8425cb28-23a6-4861-a421-03c8e8028563	Backups	/home/inno/compose/backups	29595119616	195762728960	15.9	ext4	2026-01-24 15:51:54.737207+00
1f2134b7-e8ad-4acd-beba-274ad15c0e0c	Media	/home/inno/compose/volumes/media	12288	3936818806784	0	ext4	2026-01-24 15:51:54.738352+00
22cfdf5c-337e-4bb1-b4f9-14ac6120e997	System	/	189927153664	248215199744	80.1	ext4	2026-01-24 22:01:55.927126+00
7bbcc85b-8fee-497e-be67-d81c71cfadd2	Backups	/home/inno/compose/backups	29595119616	195762728960	15.9	ext4	2026-01-24 22:01:55.932874+00
6bbb834d-e053-4199-a6a2-0d8449465f08	Media	/home/inno/compose/volumes/media	12288	3936818806784	0	ext4	2026-01-24 22:01:55.935924+00
32983079-a953-4b4a-8ab6-0ee77cd81685	System	/	190128738304	248215199744	80.2	ext4	2026-01-24 15:56:54.992593+00
51078abf-94c8-466c-8dce-bd3fec74069c	Backups	/home/inno/compose/backups	29595119616	195762728960	15.9	ext4	2026-01-24 15:56:54.999947+00
d27f23a3-8ed8-42b5-83c2-214622569c61	Media	/home/inno/compose/volumes/media	12288	3936818806784	0	ext4	2026-01-24 15:56:55.001538+00
32090264-a40d-414e-b90f-674c405647ab	System	/	189928435712	248215199744	80.1	ext4	2026-01-24 22:06:55.832125+00
097269b9-b4f8-42ae-8029-01d6aa3a5971	Backups	/home/inno/compose/backups	29595119616	195762728960	15.9	ext4	2026-01-24 22:06:55.835799+00
5683976c-697e-4343-9e77-bf8bf8162563	Media	/home/inno/compose/volumes/media	12288	3936818806784	0	ext4	2026-01-24 22:06:55.836917+00
b63b82ed-b4c0-4bd8-9091-3dcc23efed9b	System	/	190130044928	248215199744	80.2	ext4	2026-01-24 16:01:54.848879+00
d1698763-d191-47bf-8e9e-f497aec5591b	Backups	/home/inno/compose/backups	29595119616	195762728960	15.9	ext4	2026-01-24 16:01:54.853395+00
d043f518-d66d-4c24-8623-3723f7dda3e4	Media	/home/inno/compose/volumes/media	12288	3936818806784	0	ext4	2026-01-24 16:01:54.855415+00
3cfa5e2e-20df-4b17-87a1-0aa3f36f94bb	System	/	189929742336	248215199744	80.1	ext4	2026-01-24 22:11:55.784978+00
be9b7fc8-80e7-4adf-ac17-5026a30cca35	Backups	/home/inno/compose/backups	29595119616	195762728960	15.9	ext4	2026-01-24 22:11:55.789985+00
2a08dd65-4d94-4615-b225-fbd79679b126	Media	/home/inno/compose/volumes/media	12288	3936818806784	0	ext4	2026-01-24 22:11:55.791077+00
1b252fa3-5054-4e31-a401-e016a6b7ac04	System	/	190131339264	248215199744	80.2	ext4	2026-01-24 16:06:54.793868+00
da0e528b-3549-40fa-a70e-9e1d8be9cb01	Backups	/home/inno/compose/backups	29595119616	195762728960	15.9	ext4	2026-01-24 16:06:54.796442+00
68905558-9b1a-437b-941c-664a47854c71	Media	/home/inno/compose/volumes/media	12288	3936818806784	0	ext4	2026-01-24 16:06:54.797334+00
fae49a29-bf90-4927-8d12-996ac2f122c9	System	/	189931032576	248215199744	80.1	ext4	2026-01-24 22:16:55.785748+00
0e180d9e-4695-4a0b-85cb-0e40b9084580	Backups	/home/inno/compose/backups	29595119616	195762728960	15.9	ext4	2026-01-24 22:16:55.787132+00
61fc4d3a-3ae9-4823-a83e-eb494dc0958a	Media	/home/inno/compose/volumes/media	12288	3936818806784	0	ext4	2026-01-24 22:16:55.788531+00
8dc2cc7d-83d9-4cf7-8683-ad98f7bf5414	System	/	190132658176	248215199744	80.2	ext4	2026-01-24 16:11:54.816661+00
c0769c15-35aa-4383-8e5d-7b7c1399e39b	Backups	/home/inno/compose/backups	29595119616	195762728960	15.9	ext4	2026-01-24 16:11:54.820723+00
6e700ab9-4eb4-4760-a91e-7e6a857a8058	Media	/home/inno/compose/volumes/media	12288	3936818806784	0	ext4	2026-01-24 16:11:54.821687+00
13e37228-6b6a-42f3-b735-518412071f7f	System	/	189932351488	248215199744	80.1	ext4	2026-01-24 22:21:55.784639+00
013fdc46-5ffe-4679-9ac8-273ec6ce6051	Backups	/home/inno/compose/backups	29595119616	195762728960	15.9	ext4	2026-01-24 22:21:55.78894+00
25418a87-aa57-440a-8fe4-67cc9f8b3b2c	Media	/home/inno/compose/volumes/media	12288	3936818806784	0	ext4	2026-01-24 22:21:55.789924+00
a625a4d0-efb5-4d57-801d-f81a54cad359	System	/	190133948416	248215199744	80.2	ext4	2026-01-24 16:16:54.896652+00
d4c6916e-4093-4e45-ad4d-96dd25756b30	Backups	/home/inno/compose/backups	29595119616	195762728960	15.9	ext4	2026-01-24 16:16:54.898152+00
c3a6f69b-55e2-4c2e-a159-9d2cd516d0ef	Media	/home/inno/compose/volumes/media	12288	3936818806784	0	ext4	2026-01-24 16:16:54.899233+00
361d7f20-66c7-4c60-811d-6b8d65705041	System	/	189933645824	248215199744	80.1	ext4	2026-01-24 22:26:55.848635+00
651a5e1c-63fb-46e9-ba30-42fee38499ff	Backups	/home/inno/compose/backups	29595119616	195762728960	15.9	ext4	2026-01-24 22:26:55.851039+00
755b5c61-968a-4d1d-88bb-0ed4ab7caea1	Media	/home/inno/compose/volumes/media	12288	3936818806784	0	ext4	2026-01-24 22:26:55.851937+00
43e8472e-b92c-4999-9537-41cfdc8e09f4	System	/	190135255040	248215199744	80.2	ext4	2026-01-24 16:21:54.827923+00
98772257-2616-447e-aefd-6b510593e936	Backups	/home/inno/compose/backups	29595119616	195762728960	15.9	ext4	2026-01-24 16:21:54.830635+00
1966df78-85db-4ab7-8768-6151f2c29da6	Media	/home/inno/compose/volumes/media	12288	3936818806784	0	ext4	2026-01-24 16:21:54.831602+00
1d0ab676-52c9-4b5c-af00-5ecc216eb9ee	System	/	189939146752	248215199744	80.1	ext4	2026-01-24 22:31:55.998649+00
2225bf94-b515-4523-89d1-1c6ac114a5a0	Backups	/home/inno/compose/backups	29595119616	195762728960	15.9	ext4	2026-01-24 22:31:56.00592+00
3ef3eb54-1751-466f-97ac-16d3c0aa66aa	Media	/home/inno/compose/volumes/media	12288	3936818806784	0	ext4	2026-01-24 22:31:56.007455+00
7eee0290-631f-41ca-aece-90e7e8729f8e	System	/	190136561664	248215199744	80.2	ext4	2026-01-24 16:26:54.839189+00
2f9662f6-2feb-4697-a27f-e4f286847caf	Backups	/home/inno/compose/backups	29595119616	195762728960	15.9	ext4	2026-01-24 16:26:54.843405+00
721d106f-c56d-4e1e-a0ec-1290fcb8384c	Media	/home/inno/compose/volumes/media	12288	3936818806784	0	ext4	2026-01-24 16:26:54.844415+00
bd4906d1-8376-45a7-bbf2-245290203141	System	/	189940441088	248215199744	80.1	ext4	2026-01-24 22:36:55.832094+00
b050fdd5-0691-43f4-b9d3-3e8935c257a6	Backups	/home/inno/compose/backups	29595119616	195762728960	15.9	ext4	2026-01-24 22:36:55.834622+00
e804a0f4-9993-43c0-93ca-c45191202609	Media	/home/inno/compose/volumes/media	12288	3936818806784	0	ext4	2026-01-24 22:36:55.835545+00
e072c716-b38e-446c-b29c-1cb375b3fc9b	System	/	190142156800	248215199744	80.2	ext4	2026-01-24 16:31:54.957713+00
c5579b49-16db-4f3a-aaf8-7f9851734c72	Backups	/home/inno/compose/backups	29595119616	195762728960	15.9	ext4	2026-01-24 16:31:54.961883+00
14789875-274a-4ab9-8ce7-326205f3fadd	Media	/home/inno/compose/volumes/media	12288	3936818806784	0	ext4	2026-01-24 16:31:54.962881+00
9edf0449-2fa2-485a-bc1e-38729277b232	System	/	189941751808	248215199744	80.1	ext4	2026-01-24 22:41:55.882515+00
71ef8fde-290c-4030-818e-dbc0a45d84bd	Backups	/home/inno/compose/backups	29595119616	195762728960	15.9	ext4	2026-01-24 22:41:55.884888+00
76f6122e-a529-487e-9f74-c8ca5c151d74	Media	/home/inno/compose/volumes/media	12288	3936818806784	0	ext4	2026-01-24 22:41:55.886349+00
9f3dc478-8f4d-4f8e-a2a7-ad0c0cab4f98	System	/	190143442944	248215199744	80.2	ext4	2026-01-24 16:36:55.058188+00
5192b555-a19d-4e26-9efe-8642761d2c01	Backups	/home/inno/compose/backups	29595119616	195762728960	15.9	ext4	2026-01-24 16:36:55.064165+00
6653694e-e07a-4869-8fd7-d1717a650a25	Media	/home/inno/compose/volumes/media	12288	3936818806784	0	ext4	2026-01-24 16:36:55.065504+00
9e130bf4-1afe-4eab-a87e-b79abedb2a21	System	/	189943058432	248215199744	80.1	ext4	2026-01-24 22:46:55.916683+00
bc8ff25a-549d-4069-b6b8-cabe73382342	Backups	/home/inno/compose/backups	29595119616	195762728960	15.9	ext4	2026-01-24 22:46:55.919041+00
3f8d7eb2-f14b-4b07-bce3-1aa615792e41	Media	/home/inno/compose/volumes/media	12288	3936818806784	0	ext4	2026-01-24 22:46:55.919941+00
6f21d27a-e75d-42ed-b3db-348a632ae4b9	System	/	190144757760	248215199744	80.2	ext4	2026-01-24 16:41:55.020782+00
d345c46e-b399-44f5-9559-cf6925e8f9bf	Backups	/home/inno/compose/backups	29595119616	195762728960	15.9	ext4	2026-01-24 16:41:55.024508+00
b1936c45-b034-4c00-9ce0-45f6ce1f3801	Media	/home/inno/compose/volumes/media	12288	3936818806784	0	ext4	2026-01-24 16:41:55.025553+00
05050d4f-2131-4305-b96e-b380d3ba35d0	System	/	189944369152	248215199744	80.1	ext4	2026-01-24 22:51:55.846562+00
47803bfc-cab0-45e9-af69-a728021ed753	Backups	/home/inno/compose/backups	29595119616	195762728960	15.9	ext4	2026-01-24 22:51:55.848914+00
32e694c8-d924-4079-9b79-a5a7174c1ee1	Media	/home/inno/compose/volumes/media	12288	3936818806784	0	ext4	2026-01-24 22:51:55.849801+00
55672714-b8fb-40b0-a713-da67a7bb6b6b	System	/	190146052096	248215199744	80.2	ext4	2026-01-24 16:46:55.046664+00
d8285ec9-61ca-4932-a0fb-d0a55c64fddf	Backups	/home/inno/compose/backups	29595119616	195762728960	15.9	ext4	2026-01-24 16:46:55.052314+00
70304502-9333-4569-b1f9-64d8a75e4463	Media	/home/inno/compose/volumes/media	12288	3936818806784	0	ext4	2026-01-24 16:46:55.053691+00
768834df-4cbb-40e6-9350-b5419bd6531a	System	/	189945659392	248215199744	80.1	ext4	2026-01-24 22:56:55.85116+00
ffe6bffc-45d1-4dc3-99c2-4f8818d85e83	Backups	/home/inno/compose/backups	29595119616	195762728960	15.9	ext4	2026-01-24 22:56:55.855723+00
b94233e8-08fc-45cb-a365-bb3e8eb89f7c	Media	/home/inno/compose/volumes/media	12288	3936818806784	0	ext4	2026-01-24 22:56:55.858853+00
13a42f17-019d-467f-a23b-c88103cbe252	System	/	190147383296	248215199744	80.2	ext4	2026-01-24 16:51:55.102088+00
332167c8-7224-4769-8b10-58ada2de5c3e	Backups	/home/inno/compose/backups	29595119616	195762728960	15.9	ext4	2026-01-24 16:51:55.108089+00
0bcdae00-f4cb-4010-8a22-5f076e211afb	Media	/home/inno/compose/volumes/media	12288	3936818806784	0	ext4	2026-01-24 16:51:55.10941+00
f76d26c4-ee42-4457-9fce-3165c0b6ed03	System	/	189947396096	248215199744	80.1	ext4	2026-01-24 23:01:55.956448+00
ce634017-0a23-42c0-90b9-732d113618db	Backups	/home/inno/compose/backups	29595119616	195762728960	15.9	ext4	2026-01-24 23:01:55.960075+00
9ed5ad81-378d-46e8-8e9c-4e3026a96414	Media	/home/inno/compose/volumes/media	12288	3936818806784	0	ext4	2026-01-24 23:01:55.961305+00
9d0b32a0-be98-4479-8668-0287a21c0a29	System	/	190148673536	248215199744	80.2	ext4	2026-01-24 16:56:55.078839+00
f4478e6b-9a63-4aaa-a24e-99434312d724	Backups	/home/inno/compose/backups	29595119616	195762728960	15.9	ext4	2026-01-24 16:56:55.082681+00
5afbc23d-9329-4665-a30e-31594c5d2891	Media	/home/inno/compose/volumes/media	12288	3936818806784	0	ext4	2026-01-24 16:56:55.083831+00
b5af528d-2edf-49c4-b6d7-7c7e01714a7b	System	/	189948690432	248215199744	80.1	ext4	2026-01-24 23:06:55.978405+00
472891c8-2a71-4b7e-84a9-5fa0d1300b00	Backups	/home/inno/compose/backups	29595119616	195762728960	15.9	ext4	2026-01-24 23:06:55.980839+00
64f34cc0-a792-4315-9186-ee057a7c1b21	Media	/home/inno/compose/volumes/media	12288	3936818806784	0	ext4	2026-01-24 23:06:55.981775+00
a92fd7d6-ce7c-4b4b-a9b7-5fcd2c034d23	System	/	190154043392	248215199744	80.2	ext4	2026-01-24 17:01:55.013806+00
0976158d-f931-4453-8a4f-7bf64c6efee6	Backups	/home/inno/compose/backups	29595119616	195762728960	15.9	ext4	2026-01-24 17:01:55.017498+00
f99e67e6-c37c-4eaf-a10b-9860bb13e188	Media	/home/inno/compose/volumes/media	12288	3936818806784	0	ext4	2026-01-24 17:01:55.018435+00
546d44ec-f427-47f5-bb55-1a1af442c3d5	System	/	189949997056	248215199744	80.2	ext4	2026-01-24 23:11:55.969711+00
e7863a18-aa47-4cd4-9b38-0c56644f0cdc	Backups	/home/inno/compose/backups	29595119616	195762728960	15.9	ext4	2026-01-24 23:11:55.97213+00
8f117362-67c4-40cf-b207-4809aafc3e22	Media	/home/inno/compose/volumes/media	12288	3936818806784	0	ext4	2026-01-24 23:11:55.9731+00
c28499b3-c2be-4740-8b01-d20a479ebd94	System	/	190155341824	248215199744	80.2	ext4	2026-01-24 17:06:55.010708+00
f2364550-4248-4dbb-87e5-726f25912ee2	Backups	/home/inno/compose/backups	29595119616	195762728960	15.9	ext4	2026-01-24 17:06:55.013368+00
2ea29c9f-56e3-4488-bab1-45b248a76e6c	Media	/home/inno/compose/volumes/media	12288	3936818806784	0	ext4	2026-01-24 17:06:55.014245+00
9faf3981-0907-4ad7-89bd-c28798d19dd8	System	/	189951291392	248215199744	80.2	ext4	2026-01-24 23:16:55.958212+00
574a867d-63de-46be-afd8-26744121f0d8	Backups	/home/inno/compose/backups	29595119616	195762728960	15.9	ext4	2026-01-24 23:16:55.959526+00
93556e21-2248-42dd-9c37-51fc34762890	Media	/home/inno/compose/volumes/media	12288	3936818806784	0	ext4	2026-01-24 23:16:55.960471+00
6553e00c-561c-4a57-8411-d57594cb7294	System	/	190122233856	248215199744	80.2	ext4	2026-01-24 17:11:55.10006+00
62b7cd60-8006-4adc-acdb-7ef410d7311d	Backups	/home/inno/compose/backups	29595119616	195762728960	15.9	ext4	2026-01-24 17:11:55.103442+00
9bbc17fd-8355-4e96-9a83-17ff036e8e4d	Media	/home/inno/compose/volumes/media	12288	3936818806784	0	ext4	2026-01-24 17:11:55.104472+00
ebd8a137-3cfd-4240-9191-2ac35bd433cd	System	/	189952614400	248215199744	80.2	ext4	2026-01-24 23:21:55.888316+00
8c3b40f5-f309-402b-97f1-f204ff90045f	Backups	/home/inno/compose/backups	29595119616	195762728960	15.9	ext4	2026-01-24 23:21:55.890734+00
ccb3d7f8-aa24-407e-b702-9a7338805780	Media	/home/inno/compose/volumes/media	12288	3936818806784	0	ext4	2026-01-24 23:21:55.891686+00
79716710-ad45-4d4f-8353-5afbe7be4b7d	System	/	190123835392	248215199744	80.2	ext4	2026-01-24 17:16:55.005515+00
3d80f260-d310-4231-964e-5f2ffbc2ad9e	Backups	/home/inno/compose/backups	29595119616	195762728960	15.9	ext4	2026-01-24 17:16:55.007502+00
40c3f533-e92b-4c1e-9c03-0ebc50182f80	Media	/home/inno/compose/volumes/media	12288	3936818806784	0	ext4	2026-01-24 17:16:55.008946+00
611d8c0d-7ea4-4944-a2e3-120abe07a162	System	/	189953912832	248215199744	80.2	ext4	2026-01-24 23:26:56.010409+00
6436f35a-b35f-4d65-845a-c250b511f6fe	Backups	/home/inno/compose/backups	29595119616	195762728960	15.9	ext4	2026-01-24 23:26:56.014393+00
178fe9ad-4230-44f6-b452-cb270170cf66	Media	/home/inno/compose/volumes/media	12288	3936818806784	0	ext4	2026-01-24 23:26:56.015355+00
56c5da52-485f-4938-8310-0ac8d17f3e1b	System	/	190125142016	248215199744	80.2	ext4	2026-01-24 17:21:55.120693+00
57978057-8af2-4911-87cf-9157a2579ac4	Backups	/home/inno/compose/backups	29595119616	195762728960	15.9	ext4	2026-01-24 17:21:55.123701+00
ff2467a4-eb11-4659-85a5-6a4c97ee6605	Media	/home/inno/compose/volumes/media	12288	3936818806784	0	ext4	2026-01-24 17:21:55.124738+00
ad7a0479-6395-4562-bfc2-bbefa84286f8	System	/	189959282688	248215199744	80.2	ext4	2026-01-24 23:31:56.011155+00
6a2b9530-6ba0-4375-a791-d390b333458a	Backups	/home/inno/compose/backups	29595119616	195762728960	15.9	ext4	2026-01-24 23:31:56.014362+00
65d6dd4f-66b2-4b12-ab4e-db88b4451eb8	Media	/home/inno/compose/volumes/media	12288	3936818806784	0	ext4	2026-01-24 23:31:56.015391+00
5e5ea250-9daa-4a22-9f2a-31ec066dd2ff	System	/	190126432256	248215199744	80.2	ext4	2026-01-24 17:26:55.087725+00
893d29b1-af69-4f19-8ac2-183e7c42eccb	Backups	/home/inno/compose/backups	29595119616	195762728960	15.9	ext4	2026-01-24 17:26:55.09048+00
a6b6f1eb-be0c-43c6-9663-1b0a5f053edd	Media	/home/inno/compose/volumes/media	12288	3936818806784	0	ext4	2026-01-24 17:26:55.091431+00
3cf94519-412a-4fee-b252-5f2617fe62e2	System	/	189960581120	248215199744	80.2	ext4	2026-01-24 23:36:55.911438+00
600eb2a8-8380-4e81-87f2-5561f5d33de1	Backups	/home/inno/compose/backups	29595119616	195762728960	15.9	ext4	2026-01-24 23:36:55.916015+00
c672b8d1-9ccc-4e7b-83b0-e129de7e3c3e	Media	/home/inno/compose/volumes/media	12288	3936818806784	0	ext4	2026-01-24 23:36:55.918552+00
f1db7e43-3e91-431a-9caf-aad1d37e1a8b	System	/	190127734784	248215199744	80.2	ext4	2026-01-24 17:31:55.195196+00
ad3ed16f-6789-4e59-8e36-5be5f517564c	Backups	/home/inno/compose/backups	29595119616	195762728960	15.9	ext4	2026-01-24 17:31:55.199669+00
92c21355-79c6-482a-87d8-86e4c06d64fc	Media	/home/inno/compose/volumes/media	12288	3936818806784	0	ext4	2026-01-24 17:31:55.200987+00
4103a7ad-0458-4578-b538-60a88d139949	System	/	189961879552	248215199744	80.2	ext4	2026-01-24 23:41:56.088015+00
7fa0d08a-067c-40ca-8d9a-4c203c1f40dd	Backups	/home/inno/compose/backups	29595119616	195762728960	15.9	ext4	2026-01-24 23:41:56.091706+00
93c9eda3-f3e6-4361-abcd-bc610c04cf60	Media	/home/inno/compose/volumes/media	12288	3936818806784	0	ext4	2026-01-24 23:41:56.092976+00
d7a9acde-0a77-4610-9e96-1e7f70c16506	System	/	190129025024	248215199744	80.2	ext4	2026-01-24 17:36:55.130549+00
bc146eb0-e78a-48c3-9118-18e7a0634a20	Backups	/home/inno/compose/backups	29595119616	195762728960	15.9	ext4	2026-01-24 17:36:55.134788+00
db3542cc-2cd2-4df4-895e-09bcc6b781f1	Media	/home/inno/compose/volumes/media	12288	3936818806784	0	ext4	2026-01-24 17:36:55.135752+00
eaf14c6d-18ae-494b-9cfb-eba5aa6806d0	System	/	189963173888	248215199744	80.2	ext4	2026-01-24 23:46:56.07362+00
578b68fe-cf61-40cd-8128-4ba0ef900ffc	Backups	/home/inno/compose/backups	29595119616	195762728960	15.9	ext4	2026-01-24 23:46:56.077309+00
a3aef1d1-8823-4519-b848-05995e720b5a	Media	/home/inno/compose/volumes/media	12288	3936818806784	0	ext4	2026-01-24 23:46:56.0785+00
1b1726d2-d269-4bf4-8f47-20375f8966ca	System	/	190130352128	248215199744	80.2	ext4	2026-01-24 17:41:55.079311+00
96e620d2-2e3c-4833-b47f-256a31465b5d	Backups	/home/inno/compose/backups	29595119616	195762728960	15.9	ext4	2026-01-24 17:41:55.082041+00
b6a7e6a4-45d3-4f30-9472-db02fd2d1403	Media	/home/inno/compose/volumes/media	12288	3936818806784	0	ext4	2026-01-24 17:41:55.082881+00
d46fe713-0761-4f29-93d3-ea98e142744c	System	/	189964484608	248215199744	80.2	ext4	2026-01-24 23:51:56.025111+00
52fc2c18-0c9d-4848-ac25-72f0308b01ea	Backups	/home/inno/compose/backups	29595119616	195762728960	15.9	ext4	2026-01-24 23:51:56.029551+00
b0fc50ec-baf7-4f53-a6cc-3767a286fbfa	Media	/home/inno/compose/volumes/media	12288	3936818806784	0	ext4	2026-01-24 23:51:56.030617+00
315f2d6c-72ed-4219-9083-1f64c0afab55	System	/	190131650560	248215199744	80.2	ext4	2026-01-24 17:46:55.263194+00
96c3774d-399b-4c6b-9c7e-9714dd338b5e	Backups	/home/inno/compose/backups	29595119616	195762728960	15.9	ext4	2026-01-24 17:46:55.269399+00
1925e225-ac0e-4cc9-b061-8e9c0be519f4	Media	/home/inno/compose/volumes/media	12288	3936818806784	0	ext4	2026-01-24 17:46:55.272696+00
58208bcc-f80e-43a2-a2e7-084c30fa8b89	System	/	189965787136	248215199744	80.2	ext4	2026-01-24 23:56:56.056023+00
ba332a23-3fd3-4aea-b930-2ecf60ad3af6	Backups	/home/inno/compose/backups	29595119616	195762728960	15.9	ext4	2026-01-24 23:56:56.05845+00
3b586a16-a953-4e96-badf-d0f1bfe7c416	Media	/home/inno/compose/volumes/media	12288	3936818806784	0	ext4	2026-01-24 23:56:56.059344+00
5ea543b1-e60d-4348-8d7d-8da7ee92b57e	System	/	190132948992	248215199744	80.2	ext4	2026-01-24 17:51:55.157386+00
acc6b40d-a207-4272-b43c-71d2388d4aba	Backups	/home/inno/compose/backups	29595119616	195762728960	15.9	ext4	2026-01-24 17:51:55.161842+00
1bd90616-03f6-429e-83f9-d24ecb86f23e	Media	/home/inno/compose/volumes/media	12288	3936818806784	0	ext4	2026-01-24 17:51:55.162778+00
f21355a3-51ce-4e35-a983-96e05f08f539	System	/	190134243328	248215199744	80.2	ext4	2026-01-24 17:56:55.126792+00
8797a0d3-f476-4cf1-8c5a-d76079b0c0ea	Backups	/home/inno/compose/backups	29595119616	195762728960	15.9	ext4	2026-01-24 17:56:55.131039+00
b0d8ce38-18d5-42b9-a7ed-0a56d2d3de75	Media	/home/inno/compose/volumes/media	12288	3936818806784	0	ext4	2026-01-24 17:56:55.132083+00
2cc97a39-a742-4323-bb24-8b8bde4f7935	System	/	190139609088	248215199744	80.2	ext4	2026-01-24 18:01:55.242922+00
5fa2fed7-3edd-4de8-82ee-a39e8b93bf75	Backups	/home/inno/compose/backups	29595119616	195762728960	15.9	ext4	2026-01-24 18:01:55.246783+00
73398dfa-0782-4b24-8176-c946d1df1cfe	Media	/home/inno/compose/volumes/media	12288	3936818806784	0	ext4	2026-01-24 18:01:55.248238+00
9a544b93-6e41-40e6-bac1-a7549594bc67	System	/	190140907520	248215199744	80.2	ext4	2026-01-24 18:06:55.227574+00
2dcf1d43-0bc4-4dba-9432-f6aa81a7b682	Backups	/home/inno/compose/backups	29595119616	195762728960	15.9	ext4	2026-01-24 18:06:55.231829+00
fcf6bb4e-4a30-4d05-96a7-00cb29dcef17	Media	/home/inno/compose/volumes/media	12288	3936818806784	0	ext4	2026-01-24 18:06:55.232801+00
2a01fc4e-66b3-4c2b-aa18-4c2b2eaad5db	System	/	190142210048	248215199744	80.2	ext4	2026-01-24 18:11:55.175033+00
461c0722-24b3-49c4-8ef2-31a8a4f015a6	Backups	/home/inno/compose/backups	29595119616	195762728960	15.9	ext4	2026-01-24 18:11:55.179635+00
d79445cc-3321-4032-b261-964ef90e09c9	Media	/home/inno/compose/volumes/media	12288	3936818806784	0	ext4	2026-01-24 18:11:55.181655+00
3e80328e-23bd-4770-ada2-402f31a345cb	System	/	190143500288	248215199744	80.2	ext4	2026-01-24 18:16:55.366151+00
1583f497-2d21-4575-bc10-147e4d88ce6c	Backups	/home/inno/compose/backups	29595119616	195762728960	15.9	ext4	2026-01-24 18:16:55.36933+00
4d837651-cef0-4d11-bca4-a0c1d97f9add	Media	/home/inno/compose/volumes/media	12288	3936818806784	0	ext4	2026-01-24 18:16:55.371194+00
91a5ac6a-3f32-4c07-b0cb-59191529d96e	System	/	190144819200	248215199744	80.2	ext4	2026-01-24 18:21:55.263805+00
aee56148-5da6-4085-a3e9-7bf857883b19	Backups	/home/inno/compose/backups	29595119616	195762728960	15.9	ext4	2026-01-24 18:21:55.267669+00
ecd1a857-2556-4784-b8c0-26d6966fcd79	Media	/home/inno/compose/volumes/media	12288	3936818806784	0	ext4	2026-01-24 18:21:55.26865+00
aa24e638-03ba-4d20-b7f2-7b7a6e5ee8e0	System	/	190146101248	248215199744	80.2	ext4	2026-01-24 18:26:55.216578+00
66a3d395-64e7-4284-9fa4-022133fe12b7	Backups	/home/inno/compose/backups	29595119616	195762728960	15.9	ext4	2026-01-24 18:26:55.219274+00
3b05e270-8da0-447d-9459-76df770bfbcf	Media	/home/inno/compose/volumes/media	12288	3936818806784	0	ext4	2026-01-24 18:26:55.220663+00
7d628631-ccb1-41a7-bece-0ba6f6d6cdd2	System	/	190147416064	248215199744	80.2	ext4	2026-01-24 18:31:55.328031+00
e65e3109-3b83-4c57-8804-81c9c2eca8b8	Backups	/home/inno/compose/backups	29595119616	195762728960	15.9	ext4	2026-01-24 18:31:55.331075+00
caebec22-814a-4fbd-bec7-ebc72f9ac823	Media	/home/inno/compose/volumes/media	12288	3936818806784	0	ext4	2026-01-24 18:31:55.332033+00
68cc7328-9390-474c-b509-c4c8760da7e8	System	/	190148714496	248215199744	80.2	ext4	2026-01-24 18:36:55.243851+00
42554cd5-fd88-4175-849d-69c92d5255bf	Backups	/home/inno/compose/backups	29595119616	195762728960	15.9	ext4	2026-01-24 18:36:55.252977+00
61d5092a-f57f-45ee-a129-9d60f2ed62bb	Media	/home/inno/compose/volumes/media	12288	3936818806784	0	ext4	2026-01-24 18:36:55.255001+00
58de3698-e4b6-43a0-bbb2-49fee990f505	System	/	190150025216	248215199744	80.2	ext4	2026-01-24 18:41:55.260747+00
f01d54c6-eaf0-4f0b-97ce-c305612cc902	Backups	/home/inno/compose/backups	29595119616	195762728960	15.9	ext4	2026-01-24 18:41:55.265435+00
87702b6d-825b-4034-82d4-75dcd41fee6f	Media	/home/inno/compose/volumes/media	12288	3936818806784	0	ext4	2026-01-24 18:41:55.268459+00
1f1239ae-70d4-4c70-a658-50898978e34e	System	/	190151311360	248215199744	80.2	ext4	2026-01-24 18:46:55.319018+00
a11eeae8-99ac-47f6-8f5f-f62e903bebac	Backups	/home/inno/compose/backups	29595119616	195762728960	15.9	ext4	2026-01-24 18:46:55.321982+00
6721fc35-3b22-497f-9a50-864cdd8acf40	Media	/home/inno/compose/volumes/media	12288	3936818806784	0	ext4	2026-01-24 18:46:55.322865+00
1e99ea13-dafe-4d59-8170-a8b7b7a1318b	System	/	190152626176	248215199744	80.2	ext4	2026-01-24 18:51:55.371596+00
c48f2c05-8d47-4308-b9e5-a462f516f421	Backups	/home/inno/compose/backups	29595119616	195762728960	15.9	ext4	2026-01-24 18:51:55.376028+00
508996d5-f3f1-4f1f-b32c-aa2849aec68b	Media	/home/inno/compose/volumes/media	12288	3936818806784	0	ext4	2026-01-24 18:51:55.377115+00
50c796b2-58f2-46dc-a810-53f4311380bb	System	/	190153916416	248215199744	80.2	ext4	2026-01-24 18:56:55.305195+00
5f5513e2-f3a3-4609-ace8-c5b98fdd7da7	Backups	/home/inno/compose/backups	29595119616	195762728960	15.9	ext4	2026-01-24 18:56:55.30787+00
1141294a-6e72-49fa-8769-a4d0ab72968a	Media	/home/inno/compose/volumes/media	12288	3936818806784	0	ext4	2026-01-24 18:56:55.308752+00
f44a454c-aa99-46c7-b639-fa48b33b55e8	System	/	190162575360	248215199744	80.2	ext4	2026-01-24 19:01:55.386635+00
5c842453-0aea-46c3-8dc9-a76881e49125	Backups	/home/inno/compose/backups	29595119616	195762728960	15.9	ext4	2026-01-24 19:01:55.389214+00
2283f2e5-b481-4745-8ac8-2c7abecbdb4c	Media	/home/inno/compose/volumes/media	12288	3936818806784	0	ext4	2026-01-24 19:01:55.39018+00
5c7c7cd1-3618-4bf4-a300-c247c245a883	System	/	190163865600	248215199744	80.2	ext4	2026-01-24 19:06:55.451127+00
0a67f815-6ca0-4bcb-bd58-3b18189d43ef	Backups	/home/inno/compose/backups	29595119616	195762728960	15.9	ext4	2026-01-24 19:06:55.454013+00
44545d83-9de6-4ef3-8daa-72c54458995a	Media	/home/inno/compose/volumes/media	12288	3936818806784	0	ext4	2026-01-24 19:06:55.455237+00
ce1fa208-a393-4a0a-b3f9-066299ce6162	System	/	190165168128	248215199744	80.2	ext4	2026-01-24 19:11:55.404314+00
017b99d5-187f-4ea8-9b72-dc372e9ca840	Backups	/home/inno/compose/backups	29595119616	195762728960	15.9	ext4	2026-01-24 19:11:55.407208+00
d3b8ed06-05f7-4e7f-a369-7a25c3aa7620	Media	/home/inno/compose/volumes/media	12288	3936818806784	0	ext4	2026-01-24 19:11:55.408125+00
c1e119c2-cabc-47fe-bc04-92d17e5ea878	System	/	190166470656	248215199744	80.2	ext4	2026-01-24 19:16:55.436126+00
e5b1958e-5d0d-467d-a03b-13895e3e72ab	Backups	/home/inno/compose/backups	29595119616	195762728960	15.9	ext4	2026-01-24 19:16:55.437864+00
a84326bb-6961-458b-96bf-f2e6a0c0f5a5	Media	/home/inno/compose/volumes/media	12288	3936818806784	0	ext4	2026-01-24 19:16:55.438911+00
a8e34e0f-dc68-45e5-a28d-49fa1f500303	System	/	190167785472	248215199744	80.2	ext4	2026-01-24 19:21:55.510131+00
35bb81e0-f2a1-47c4-824e-9fb848717be4	Backups	/home/inno/compose/backups	29595119616	195762728960	15.9	ext4	2026-01-24 19:21:55.516952+00
604a31fb-b679-4bc6-a7c0-90c02f957c5c	Media	/home/inno/compose/volumes/media	12288	3936818806784	0	ext4	2026-01-24 19:21:55.518455+00
6ecc3ab2-28d1-44c6-803d-bb82c893fcd4	System	/	190169137152	248215199744	80.2	ext4	2026-01-24 19:26:55.42912+00
5d52edbf-bf9f-447e-b50d-7149940a2472	Backups	/home/inno/compose/backups	29595119616	195762728960	15.9	ext4	2026-01-24 19:26:55.433064+00
fb16e7fb-b2a8-417a-8d92-9f1abcbdd559	Media	/home/inno/compose/volumes/media	12288	3936818806784	0	ext4	2026-01-24 19:26:55.434085+00
66528155-ec3a-4009-96f7-e6c73f0829ed	System	/	190170439680	248215199744	80.2	ext4	2026-01-24 19:31:55.519537+00
ea92fea0-eec4-4a28-97aa-08730fa2c5c9	Backups	/home/inno/compose/backups	29595119616	195762728960	15.9	ext4	2026-01-24 19:31:55.522014+00
995dcaa7-8424-4fc4-8fda-7f1e75bf38b6	Media	/home/inno/compose/volumes/media	12288	3936818806784	0	ext4	2026-01-24 19:31:55.522891+00
4c37fab7-eb81-450b-8559-5d29a62c6dad	System	/	190171734016	248215199744	80.2	ext4	2026-01-24 19:36:55.427055+00
f96b1bcf-c15e-440e-bef9-bfb30fccf746	Backups	/home/inno/compose/backups	29595119616	195762728960	15.9	ext4	2026-01-24 19:36:55.4301+00
39c870e9-ba82-4640-9c76-3b201a3acef0	Media	/home/inno/compose/volumes/media	12288	3936818806784	0	ext4	2026-01-24 19:36:55.431121+00
9ed23226-7ed9-4430-bc86-ac5c102f1235	System	/	190173048832	248215199744	80.2	ext4	2026-01-24 19:41:55.517729+00
cf8a3802-29de-44b9-87c3-6633578be640	Backups	/home/inno/compose/backups	29595119616	195762728960	15.9	ext4	2026-01-24 19:41:55.522685+00
1b98044f-0463-40fe-a4bf-cda56946e608	Media	/home/inno/compose/volumes/media	12288	3936818806784	0	ext4	2026-01-24 19:41:55.523787+00
6645f2d2-e4e8-461f-8522-16cca57ef660	System	/	190178410496	248215199744	80.2	ext4	2026-01-24 19:46:55.66232+00
61f166eb-f633-4241-8e0d-3bb502564263	Backups	/home/inno/compose/backups	29595119616	195762728960	15.9	ext4	2026-01-24 19:46:55.670564+00
97c0c9bb-600d-473d-a0b2-24a03c72c27e	Media	/home/inno/compose/volumes/media	12288	3936818806784	0	ext4	2026-01-24 19:46:55.672507+00
b0512e46-cf5f-480c-a479-5698e84c9f5b	System	/	190179717120	248215199744	80.2	ext4	2026-01-24 19:51:55.482856+00
e094e34b-8390-4d92-81c1-646a1e1fbdac	Backups	/home/inno/compose/backups	29595119616	195762728960	15.9	ext4	2026-01-24 19:51:55.487188+00
afb462aa-de40-4571-ae38-e58ca519ddb4	Media	/home/inno/compose/volumes/media	12288	3936818806784	0	ext4	2026-01-24 19:51:55.488148+00
bc5d9c6e-defb-4234-a3f1-85aedf68d083	System	/	190181007360	248215199744	80.2	ext4	2026-01-24 19:56:55.629758+00
9416776f-c5e2-4081-92b9-0d4453c8bbb7	Backups	/home/inno/compose/backups	29595119616	195762728960	15.9	ext4	2026-01-24 19:56:55.635694+00
53d250bf-3261-426d-912c-414e814353e4	Media	/home/inno/compose/volumes/media	12288	3936818806784	0	ext4	2026-01-24 19:56:55.63741+00
0c2b8377-2e70-4e2e-a884-387866361ab3	System	/	190182330368	248215199744	80.2	ext4	2026-01-24 20:01:55.487378+00
ad09e429-dc05-4327-a63c-61af70aca8e4	Backups	/home/inno/compose/backups	29595119616	195762728960	15.9	ext4	2026-01-24 20:01:55.492036+00
5347fd7a-f61b-47be-83c5-63ad89794aba	Media	/home/inno/compose/volumes/media	12288	3936818806784	0	ext4	2026-01-24 20:01:55.492927+00
ef27e995-3c06-4444-9d86-e5837056d2cf	System	/	190183624704	248215199744	80.2	ext4	2026-01-24 20:06:55.506685+00
5133f81b-3443-4dac-a1eb-110c5e6f84c9	Backups	/home/inno/compose/backups	29595119616	195762728960	15.9	ext4	2026-01-24 20:06:55.511209+00
0cb092c4-1c9d-40e7-800d-1e20de27e9f4	Media	/home/inno/compose/volumes/media	12288	3936818806784	0	ext4	2026-01-24 20:06:55.512333+00
e839d3a0-7a97-46a2-9b45-4346157e1210	System	/	190184939520	248215199744	80.2	ext4	2026-01-24 20:11:55.662128+00
ef872a25-773b-4f71-9c57-9c6c320cb502	Backups	/home/inno/compose/backups	29595119616	195762728960	15.9	ext4	2026-01-24 20:11:55.666688+00
197f08ee-21b5-43e9-9b9d-6d107027b693	Media	/home/inno/compose/volumes/media	12288	3936818806784	0	ext4	2026-01-24 20:11:55.66771+00
41017ea7-76d9-448b-b650-aca572894b0c	System	/	190186237952	248215199744	80.3	ext4	2026-01-24 20:16:55.587512+00
1c3e7d42-3906-4aea-a6f8-90d902508264	Backups	/home/inno/compose/backups	29595119616	195762728960	15.9	ext4	2026-01-24 20:16:55.590931+00
98f60b2f-3dac-4421-a35c-23126ca2718b	Media	/home/inno/compose/volumes/media	12288	3936818806784	0	ext4	2026-01-24 20:16:55.592209+00
bca1d90b-1c2c-4989-a426-0670d97311b2	System	/	190187556864	248215199744	80.3	ext4	2026-01-24 20:21:55.541657+00
08bbf226-7981-4aad-8445-670a295e0880	Backups	/home/inno/compose/backups	29595119616	195762728960	15.9	ext4	2026-01-24 20:21:55.545746+00
348a2005-c6e0-44bb-8ff0-389ea718403b	Media	/home/inno/compose/volumes/media	12288	3936818806784	0	ext4	2026-01-24 20:21:55.546627+00
c0c763bc-7eb8-4189-af21-dbc027201a4e	System	/	190188843008	248215199744	80.3	ext4	2026-01-24 20:26:55.753783+00
34c67bef-e54e-4b93-8641-0ad9b89ed7e9	Backups	/home/inno/compose/backups	29595119616	195762728960	15.9	ext4	2026-01-24 20:26:55.759486+00
6c49fd6a-cd0d-4704-8b6f-bf5b800108d5	Media	/home/inno/compose/volumes/media	12288	3936818806784	0	ext4	2026-01-24 20:26:55.760994+00
b36f7b52-e4b7-4b80-b7cc-bdd5549ae84e	System	/	190097616896	248215199744	80.2	ext4	2026-01-24 14:15:28.106505+00
fa04298b-687a-4528-be9e-e5bbf40072f5	Backups	/home/inno/compose/backups	29595119616	195762728960	15.9	ext4	2026-01-24 14:15:28.110573+00
b2b7ca01-7cb2-47d1-8daa-72639f1d4c8c	Media	/home/inno/compose/volumes/media	12288	3936818806784	0	ext4	2026-01-24 14:15:28.111759+00
9bb08636-6175-4d3e-bf9c-e193f1c1a3b2	System	/	190098030592	248215199744	80.2	ext4	2026-01-24 14:16:54.263617+00
db979b72-648d-44b3-972a-cc566079c27e	Backups	/home/inno/compose/backups	29595119616	195762728960	15.9	ext4	2026-01-24 14:16:54.26659+00
5c1302d7-a00f-42a8-9c7e-4f6edbd8e9d7	Media	/home/inno/compose/volumes/media	12288	3936818806784	0	ext4	2026-01-24 14:16:54.269189+00
\.


--
-- Data for Name: dns_configs; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.dns_configs (id, name, primary_dns, secondary_dns, is_active, created_at, updated_at) FROM stdin;
\.


--
-- Data for Name: firewall_rules; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.firewall_rules (id, port, from_ip, protocol, comment, is_active, created_at, updated_at) FROM stdin;
\.


--
-- Data for Name: media_channels; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.media_channels (id, name, platform, channel_id, username, channel_url, subscribers, views, engagement, growth, videos_count, is_monetized, watch_hours, avg_view_duration, ctr, revenue, likes, comments, shares, is_active, last_synced_at, created_at, updated_at) FROM stdin;
\.


--
-- Data for Name: monitored_hosts; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.monitored_hosts (id, name, host, check_type, status, response_time_ms, last_check_at, is_active, created_at, updated_at) FROM stdin;
\.


--
-- Data for Name: network_traffic; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.network_traffic (id, interface_name, rx_bytes, tx_bytes, recorded_at, rx_rate, tx_rate) FROM stdin;
e1cd7588-1707-472c-849e-3ecb6510bbd8	enp0s31f6	0	0	2026-01-24 14:17:54.412799+00	0	0
f69ee019-ef1f-4669-87fb-d16cd9c370de	wlx30169d2252f8	237980	4258786	2026-01-24 14:17:54.417548+00	7927	141865
a432802b-7bf6-4f14-8193-b1611df5cb92	enp0s31f6	0	0	2026-01-24 17:13:27.74132+00	0	0
86b0ffa2-663c-48ee-9541-9bcd6f4bf7b1	wlx30169d2252f8	3690	12559	2026-01-24 17:13:27.748337+00	4300	14635
37d2830d-a22a-467d-9998-3007a71dfd73	enp0s31f6	0	0	2026-01-24 19:24:00.226488+00	0	0
6de6e858-649a-4be9-b355-f9ba83ae5da4	wlx30169d2252f8	1524	350	2026-01-24 19:24:00.23015+00	1096	251
1574eb79-ac6e-4e86-9d7f-c9d2dc216643	enp0s31f6	0	0	2026-01-24 22:19:33.873631+00	0	0
f01624b5-bd8e-4086-b602-aa5b76eadcfe	wlx30169d2252f8	19796	12544	2026-01-24 22:19:33.880338+00	2840	1800
18225ca5-8963-46ab-8075-36d96ae0e202	enp0s31f6	0	0	2026-01-24 14:18:24.387291+00	0	0
87dc1e39-fe24-4479-8b66-d4b5fa05adcd	wlx30169d2252f8	106634	64286	2026-01-24 14:18:24.392362+00	3557	2144
38763599-8912-4384-921c-5aec2a0ea679	enp0s31f6	0	0	2026-01-24 17:13:57.692623+00	0	0
c11543fc-925a-4d56-9837-f1ca1b3d3977	wlx30169d2252f8	614	126	2026-01-24 17:13:57.694379+00	845	173
0a86e623-ab56-4c11-9782-4f041cbad8ba	enp0s31f6	0	0	2026-01-24 19:24:30.27008+00	0	0
92b8accf-6f13-4cce-84a0-1bc7ff7151f6	wlx30169d2252f8	4976	8776	2026-01-24 19:24:30.27529+00	1509	2662
b5fb2e4b-e0e6-4a88-8719-b022ca8ea95c	enp0s31f6	0	0	2026-01-24 22:20:03.848628+00	0	0
dbccacde-41d9-47b8-87a3-361b0b22dc0b	wlx30169d2252f8	17786	4201	2026-01-24 22:20:03.854805+00	7144	1687
044cadfb-f596-4fa8-962b-43f51bcb1070	enp0s31f6	0	0	2026-01-24 14:18:54.457434+00	0	0
83d5aaec-ba47-4c18-9c18-b0bc8f7b4d6b	wlx30169d2252f8	0	0	2026-01-24 14:18:54.464436+00	0	0
acfc0e1d-23c3-4946-9121-cee3f2f18853	enp0s31f6	0	0	2026-01-24 17:14:27.732881+00	0	0
0e9d9607-2e29-4146-95e9-9ef02a61b660	wlx30169d2252f8	3748	13610	2026-01-24 17:14:27.735457+00	4435	16105
81f15e1d-ce45-4592-9196-c0a71d8b642d	enp0s31f6	0	0	2026-01-24 19:25:00.242731+00	0	0
34a94b23-d4f9-4654-842d-fbcafa2a1a8d	wlx30169d2252f8	1506	350	2026-01-24 19:25:00.246499+00	1086	252
da4155e8-c72c-44b0-acfb-207f002de010	enp0s31f6	0	0	2026-01-24 22:20:33.855807+00	0	0
47aa4057-0729-486b-bd43-b36740dd6197	wlx30169d2252f8	26602	10788	2026-01-24 22:20:33.859673+00	3801	1541
4885ab1d-9ba7-4348-8812-0314d856292a	enp0s31f6	0	0	2026-01-24 14:19:24.413836+00	0	0
21f02c68-4bde-4501-84b4-1cc00068a694	wlx30169d2252f8	94662	56224	2026-01-24 14:19:24.417724+00	3156	1874
cefb553a-fe89-4eed-9441-62116244fecb	enp0s31f6	0	0	2026-01-24 17:14:57.720737+00	0	0
5a03c48d-fc84-4d28-8a0a-69db0727a393	wlx30169d2252f8	374	126	2026-01-24 17:14:57.722801+00	506	170
5eb55041-5cc7-430f-b714-a86e767d20c0	enp0s31f6	0	0	2026-01-24 19:25:30.295001+00	0	0
f8d0a776-7623-4dc5-b2cb-c51cd4e23522	wlx30169d2252f8	6558	12732	2026-01-24 19:25:30.302241+00	1910	3709
87004c9f-809d-4b1f-9e10-8a08eb041f06	enp0s31f6	0	0	2026-01-24 22:21:03.864759+00	0	0
a5ca3c44-1390-4e3e-ad1c-8516124cb9d9	wlx30169d2252f8	17476	4127	2026-01-24 22:21:03.868697+00	7018	1657
9c399c78-28e6-4b3b-a760-ffe6e83074e3	enp0s31f6	0	0	2026-01-24 14:19:54.42238+00	0	0
aa9fc326-d450-4c5f-be81-8c9fc61c36a5	wlx30169d2252f8	0	0	2026-01-24 14:19:54.427332+00	0	0
159fdd7c-c7aa-43db-a29c-0ce91761786e	enp0s31f6	0	0	2026-01-24 17:15:27.765233+00	0	0
81c7fb9d-c5f6-4627-a95a-0021f70ac51f	wlx30169d2252f8	3292	10618	2026-01-24 17:15:27.772245+00	3767	12151
2485b821-3a4d-4800-929c-633a1829d4aa	enp0s31f6	0	0	2026-01-24 19:26:00.265805+00	0	0
14018da5-f366-47ea-a936-fa1db9df46ad	wlx30169d2252f8	1584	350	2026-01-24 19:26:00.270035+00	1131	250
69850e78-aefc-4ccb-88cb-d787c1471dc9	enp0s31f6	0	0	2026-01-24 22:21:33.919457+00	0	0
e1fa6eac-50ae-4469-a348-72c531947158	wlx30169d2252f8	19048	12135	2026-01-24 22:21:33.926684+00	2710	1726
8ab88211-75b7-4bf7-a5eb-4a9e762056a0	enp0s31f6	0	0	2026-01-24 14:20:24.42169+00	0	0
61f2ade9-ab9b-4952-8831-1ea6530f8df4	wlx30169d2252f8	86841	56828	2026-01-24 14:20:24.425928+00	2894	1893
b34aff6c-a32d-4ec2-aadd-f0b974bec455	enp0s31f6	0	0	2026-01-24 17:15:57.75066+00	0	0
4ae788ac-5a40-4574-8bf2-a960aa7f9fc1	wlx30169d2252f8	728	208	2026-01-24 17:15:57.754284+00	976	278
0646f0ca-61d4-4ea5-ae7d-1f90467b5b78	enp0s31f6	0	0	2026-01-24 19:26:30.316455+00	0	0
f0233ac8-3f77-403b-977b-50293bb6e66c	wlx30169d2252f8	6938	13193	2026-01-24 19:26:30.323784+00	2057	3911
f79b1b65-ca92-4d6c-bde8-980aa473e2b1	enp0s31f6	0	0	2026-01-24 22:22:03.888322+00	0	0
a77e18cc-3d54-477b-a056-d6048b6dc3ba	wlx30169d2252f8	17714	3981	2026-01-24 22:22:03.89394+00	7045	1583
85a03f82-ed73-4a71-98f2-25531710a8d0	enp0s31f6	0	0	2026-01-24 14:20:54.525012+00	0	0
4dcdb339-708e-4452-a28a-250f9de903e3	wlx30169d2252f8	0	0	2026-01-24 14:20:54.533062+00	0	0
fabebe60-dfd0-46fa-91fe-763e3faf2b6a	enp0s31f6	0	0	2026-01-24 17:16:27.792261+00	0	0
223e80b1-ce33-4e39-a015-808905b28c9e	wlx30169d2252f8	3410	12385	2026-01-24 17:16:27.795198+00	3762	13664
932bfe08-85c9-4696-afb6-e43df0ea1f9b	enp0s31f6	0	0	2026-01-24 19:27:00.291356+00	0	0
3c044efd-dcc9-4ffb-800d-e8f545023d25	wlx30169d2252f8	1644	350	2026-01-24 19:27:00.295938+00	1148	244
c8161c9d-95ec-4a81-b61b-a12d59946f52	enp0s31f6	0	0	2026-01-24 22:22:33.940332+00	0	0
834e938b-ec15-444c-b519-e818fb179d92	wlx30169d2252f8	20732	16664	2026-01-24 22:22:33.948984+00	2931	2356
93c2f9fc-deda-4bb9-aa0e-a3a67a0f8eeb	enp0s31f6	0	0	2026-01-24 14:21:24.489385+00	0	0
02b08526-14cc-4e07-ad27-53acdc07bd98	wlx30169d2252f8	95148	573935	2026-01-24 14:21:24.496447+00	3172	19136
ccf042b2-7dbe-469a-9f05-159eac7c5c4e	enp0s31f6	0	0	2026-01-24 17:16:57.771199+00	0	0
bf7dc033-5219-4fe9-b712-60f05b0160a1	wlx30169d2252f8	2203	350	2026-01-24 17:16:57.773267+00	2892	459
49716dac-a778-4120-b7d8-4970ccefeda0	enp0s31f6	0	0	2026-01-24 19:27:30.335462+00	0	0
abde41d6-d8d2-4037-acd0-72e96820ddfb	wlx30169d2252f8	5024	10065	2026-01-24 19:27:30.34267+00	1510	3026
9bd76f90-b491-448c-94c6-830fcaca09d8	enp0s31f6	0	0	2026-01-24 22:23:03.914035+00	0	0
a1f5a989-f1ba-42a3-87ad-7da9e6f168e1	wlx30169d2252f8	19524	3981	2026-01-24 22:23:03.919314+00	7699	1569
2e56a5f5-5860-4ac9-b9f5-8c47a9640e55	enp0s31f6	0	0	2026-01-24 14:21:54.440743+00	0	0
eb78b1cc-207c-4028-95a5-410e99311cb5	wlx30169d2252f8	0	0	2026-01-24 14:21:54.442267+00	0	0
4ebef023-af5a-407e-a6fa-c89ef4d04d56	enp0s31f6	0	0	2026-01-24 17:17:27.82438+00	0	0
7607bb97-0cb5-447f-916c-971b375615b8	wlx30169d2252f8	3308	10615	2026-01-24 17:17:27.833662+00	3675	11794
511e1e22-dac2-43dd-8b76-a4d032d57a44	enp0s31f6	0	0	2026-01-24 19:28:00.29346+00	0	0
6a43599b-2fac-4def-a768-0943934477c2	wlx30169d2252f8	1448	574	2026-01-24 19:28:00.297543+00	1022	405
d780e2bf-63c9-4d36-81d3-d395c2fd7d42	enp0s31f6	0	0	2026-01-24 22:23:33.947907+00	0	0
0ffb7fa4-aad3-4180-9d2a-f4db92045f92	wlx30169d2252f8	22056	13363	2026-01-24 22:23:33.957069+00	3123	1892
02cb14a3-6ce6-44b7-b225-3dd6c45cc0ae	enp0s31f6	0	0	2026-01-24 14:22:24.465192+00	0	0
4dec480b-c4c6-4615-a88f-43817c3ed0a0	wlx30169d2252f8	803	4047	2026-01-24 14:22:24.470608+00	1428	7196
2c7a64c4-fa38-4da5-8351-519dca005c7a	enp0s31f6	0	0	2026-01-24 17:17:57.791632+00	0	0
70ee1843-0b8e-48df-b516-8ed7d9bd0b92	wlx30169d2252f8	2004	444	2026-01-24 17:17:57.795532+00	2537	562
d8672f0d-14ae-489a-966f-29545e4b26cd	enp0s31f6	0	0	2026-01-24 19:28:30.351269+00	0	0
c7ecfd77-ea8c-4a6a-8abf-52212c54d855	wlx30169d2252f8	8056	18311	2026-01-24 19:28:30.356937+00	2404	5465
567d30dd-8c91-4ddb-83ef-09a516462739	enp0s31f6	0	0	2026-01-24 22:24:03.916355+00	0	0
cbf97074-189b-4c39-b7f2-2692ecdde073	wlx30169d2252f8	25993	3985	2026-01-24 22:24:03.921919+00	10398	1594
e1073e1e-6a9a-4327-983a-351965a2dc98	enp0s31f6	0	0	2026-01-24 14:22:54.518565+00	0	0
aaa9fe96-356a-4a1f-adac-3fd6d42d3813	wlx30169d2252f8	0	0	2026-01-24 14:22:54.526261+00	0	0
9b3eec1b-aac5-409c-a36f-6a458684fb2c	enp0s31f6	0	0	2026-01-24 17:18:27.844843+00	0	0
3aa7bc8d-8398-435b-bc8d-7b66fa0c676e	wlx30169d2252f8	3874	11751	2026-01-24 17:18:27.85205+00	4089	12404
e43b99fb-8fa6-4cb0-9c97-f2b634a77cf8	enp0s31f6	0	0	2026-01-24 19:29:00.325918+00	0	0
f9410624-f49c-4cfe-ad48-7ca9482a7b9b	wlx30169d2252f8	1766	574	2026-01-24 19:29:00.330672+00	1257	408
692241f7-9b77-496c-baa4-c6cb6c9b8a77	enp0s31f6	0	0	2026-01-24 22:24:33.968997+00	0	0
ac751a82-d0cf-4f12-8b1a-5905b9eb2c6b	wlx30169d2252f8	18032	10240	2026-01-24 22:24:33.976278+00	2539	1442
b6187745-3ba3-4650-8d12-1545990d2466	enp0s31f6	0	0	2026-01-24 14:23:25.241258+00	0	0
0938469c-4e08-4cc5-8102-3204e7c6269b	wlx30169d2252f8	209572	3327489	2026-01-24 14:23:25.255277+00	8283	131526
532045e7-5bce-470e-8fb8-632020af0d76	enp0s31f6	0	0	2026-01-24 17:18:57.810744+00	0	0
8a397a81-3ce4-40ec-89d6-8b4093054b8c	wlx30169d2252f8	982	350	2026-01-24 17:18:57.812898+00	1278	455
d726e24c-aba6-4c6a-909d-4a5a696bcf35	enp0s31f6	0	0	2026-01-24 19:29:30.378368+00	0	0
816d851c-da58-4535-80f4-e2ac0ec2d618	wlx30169d2252f8	6150	15758	2026-01-24 19:29:30.38943+00	1750	4484
701b3f7a-5346-464c-bbfb-95dea2941379	enp0s31f6	0	0	2026-01-24 22:25:03.939375+00	0	0
4dc0933d-7d0d-481f-bad1-b841b9ab418a	wlx30169d2252f8	19446	3985	2026-01-24 22:25:03.94329+00	7771	1592
55c01260-9991-4acd-b771-6815f33e8bf8	enp0s31f6	0	0	2026-01-24 14:23:54.620403+00	0	0
2d5a2690-f1be-4a53-9d7d-6d71f0cb4e36	wlx30169d2252f8	0	0	2026-01-24 14:23:54.62994+00	0	0
d91e0969-2703-43a7-a769-e31e3ca96140	enp0s31f6	0	0	2026-01-24 17:19:27.866519+00	0	0
2e6b54b1-eb79-4908-84fa-f78e4b0af3dd	wlx30169d2252f8	5066	12705	2026-01-24 17:19:27.873769+00	5530	13870
3f03314f-68d6-46df-b42b-9d4681bf0708	enp0s31f6	0	0	2026-01-24 19:30:00.332593+00	0	0
38a27b43-9c40-4c02-8421-bb8e1d40e5ce	wlx30169d2252f8	1996	574	2026-01-24 19:30:00.334147+00	1408	405
573a2418-b042-4823-93a7-4952c8604b5f	enp0s31f6	0	0	2026-01-24 22:25:33.975176+00	0	0
6f3a4d80-ed1a-4ef7-aeda-ed534004610d	wlx30169d2252f8	18512	14013	2026-01-24 22:25:33.982331+00	2619	1982
69c6fc1d-0d0d-40dd-b087-6ac7cf35f803	enp0s31f6	0	0	2026-01-24 14:24:24.549661+00	0	0
5fa9f0bc-4eb6-491d-9fbf-53af44dc39c2	wlx30169d2252f8	167936	1288922	2026-01-24 14:24:24.565254+00	5604	43012
aa8e58e1-9c13-48ef-9f2e-bed34b4073e3	enp0s31f6	0	0	2026-01-24 17:19:57.832008+00	0	0
c7214f9a-1e92-42f9-922e-a7c515d7d67d	wlx30169d2252f8	608	350	2026-01-24 17:19:57.835949+00	770	443
00acc9c2-2cca-4fb1-a755-4bd2aa0b9963	enp0s31f6	0	0	2026-01-24 19:30:30.369915+00	0	0
ef29a846-0a75-475d-82d1-a1e7c8e3e817	wlx30169d2252f8	7174	16570	2026-01-24 19:30:30.373335+00	2053	4744
f59ea409-0aa7-4253-a156-7d99b1094abc	enp0s31f6	0	0	2026-01-24 22:26:03.946559+00	0	0
ff52923c-0d83-43e0-bb64-d0ef5b654382	wlx30169d2252f8	17654	3985	2026-01-24 22:26:03.950341+00	7020	1584
51bcb530-3b76-4ee0-99fa-ffed649f0b52	enp0s31f6	0	0	2026-01-24 14:24:54.530259+00	0	0
89a4fa2f-0b46-4c06-b761-c14115539283	wlx30169d2252f8	10500	550494	2026-01-24 14:24:54.534023+00	248676	13037635
750e158a-6e91-442d-8bdb-5b0921dcdad5	enp0s31f6	0	0	2026-01-24 17:20:27.845736+00	0	0
a1e75c1e-cc21-4882-9624-06f503c2c209	wlx30169d2252f8	3250	10612	2026-01-24 17:20:27.849216+00	3394	11083
d0b68b0e-db85-4534-ad86-d2e37c920938	enp0s31f6	0	0	2026-01-24 19:31:00.369171+00	0	0
3122927b-5b20-40bf-9cb3-47fad2c04ef0	wlx30169d2252f8	1818	574	2026-01-24 19:31:00.374881+00	1262	398
c2a89a55-43c7-4145-a771-a1013bd75f10	enp0s31f6	0	0	2026-01-24 22:26:33.995321+00	0	0
512ddaa5-5643-4c3e-8ab2-8fe8a2451905	wlx30169d2252f8	20822	12546	2026-01-24 22:26:33.998949+00	2970	1789
deeebbf8-ebe7-424c-8307-d87bfa276dd2	enp0s31f6	0	0	2026-01-24 14:25:24.599538+00	0	0
7aa1cf57-c11f-41d7-8fe1-0b9e45d0f3b7	wlx30169d2252f8	62875	52311	2026-01-24 14:25:24.610236+00	3248	2702
bb9fec5c-1610-465a-9179-6f7d849d31b4	enp0s31f6	0	0	2026-01-24 17:20:57.838499+00	0	0
04d92c4b-2050-4270-aade-b2c27e3b1c48	wlx30169d2252f8	796	350	2026-01-24 17:20:57.839973+00	1051	462
c6dd604b-7e8f-4e4e-843e-3b2d9869b339	enp0s31f6	0	0	2026-01-24 19:31:30.421253+00	0	0
c9abfea9-439c-4a78-998a-060ed5a55cfb	wlx30169d2252f8	6256	12451	2026-01-24 19:31:30.428552+00	1789	3561
a915ff8e-8680-4cbd-a981-2c524efce8a8	enp0s31f6	0	0	2026-01-24 22:27:03.968796+00	0	0
919807c7-6fa2-4b9f-b304-b95840ab6021	wlx30169d2252f8	18130	3985	2026-01-24 22:27:03.97424+00	7190	1580
e267efd4-2d52-4953-b729-4262dfc33d88	enp0s31f6	0	0	2026-01-24 14:25:54.539265+00	0	0
994fde1a-53f4-46bb-8f01-2fd19e3361e5	wlx30169d2252f8	0	0	2026-01-24 14:25:54.541248+00	0	0
2cb866b5-321a-4c2d-b961-ee16b50ba137	enp0s31f6	0	0	2026-01-24 17:21:27.904456+00	0	0
346e840c-4775-421f-9e82-0a04419bee30	wlx30169d2252f8	4648	14402	2026-01-24 17:21:27.910409+00	4819	14933
80de6fb3-32fc-45b5-acc7-d84847ec90cc	enp0s31f6	0	0	2026-01-24 19:32:00.391401+00	0	0
f72bdbf5-897f-4781-a315-6e4f74a66f28	wlx30169d2252f8	2110	566	2026-01-24 19:32:00.396022+00	1447	388
647cb433-f64d-4a29-8abc-6d8a5ed98a86	enp0s31f6	0	0	2026-01-24 22:27:34.020985+00	0	0
213543c1-0604-4d34-aae3-296ea6396547	wlx30169d2252f8	19762	9818	2026-01-24 22:27:34.029574+00	2783	1382
9aa0c0d4-d36c-4a71-805e-28c5d90a3c85	enp0s31f6	0	0	2026-01-24 14:26:24.6065+00	0	0
f340f5c0-8b5f-41b8-9fd1-7a2d635303a1	wlx30169d2252f8	94088	56665	2026-01-24 14:26:24.618279+00	3132	1886
42660687-7599-4ffa-9227-12c73941e975	enp0s31f6	0	0	2026-01-24 17:21:57.873075+00	0	0
076e6964-e4ad-482b-8ed7-514f67f787cc	wlx30169d2252f8	676	350	2026-01-24 17:21:57.877085+00	836	432
b00e6fa5-bc75-4a18-9b8b-f86e16e1440e	enp0s31f6	0	0	2026-01-24 19:32:30.426042+00	0	0
8151c2d6-b744-4eb7-8ea4-dc37724d424a	wlx30169d2252f8	5744	14012	2026-01-24 19:32:30.429141+00	1643	4009
e815af6e-3458-4fbf-94fb-d94c59e4a7d4	enp0s31f6	0	0	2026-01-24 22:28:03.976276+00	0	0
8a34a173-6abd-41cb-b466-f6e4123077b7	wlx30169d2252f8	18122	3985	2026-01-24 22:28:03.979855+00	7232	1590
75a3a657-9989-4c9e-a2b7-3834ecd84b75	enp0s31f6	0	0	2026-01-24 14:26:54.56476+00	0	0
7608ad97-25f8-424a-beb9-06cf560d037b	wlx30169d2252f8	0	0	2026-01-24 14:26:54.56725+00	0	0
174c9ab9-fd68-405c-8a2a-809a7178337a	enp0s31f6	0	0	2026-01-24 17:22:27.887311+00	0	0
e4932aa8-4d67-47e6-a1c5-9031cc0e83a0	wlx30169d2252f8	3250	8204	2026-01-24 17:22:27.889666+00	3256	8221
e22b827d-a97b-47f9-bd19-e4388bb2c096	enp0s31f6	0	0	2026-01-24 19:33:00.397275+00	0	0
80a754a6-e906-4d1f-b619-30192e79dcb3	wlx30169d2252f8	3268	566	2026-01-24 19:33:00.399793+00	2278	394
4bc2b0df-b44f-47ad-b4a5-64c068f187eb	enp0s31f6	0	0	2026-01-24 22:28:34.043307+00	0	0
82fcab5b-cd60-4258-a7ee-bb48ac4dc8cb	wlx30169d2252f8	26101	12466	2026-01-24 22:28:34.051827+00	3672	1754
bd4be0cd-915d-44c1-9473-6c0cd21def2d	enp0s31f6	0	0	2026-01-24 14:27:24.610613+00	0	0
190e69ce-4644-44e2-b391-77433b3563c5	wlx30169d2252f8	2002	4464	2026-01-24 14:27:24.617623+00	2634	5873
e8250552-87c6-4f60-87a6-b4f7628a9967	enp0s31f6	0	0	2026-01-24 17:22:57.893553+00	0	0
8a528cf5-c6ff-45ff-8e04-fdf66ddbe7ad	wlx30169d2252f8	838	350	2026-01-24 17:22:57.897649+00	1064	444
201fdb1d-4033-45e7-9437-f50b5e48b253	enp0s31f6	0	0	2026-01-24 19:33:30.425942+00	0	0
991e80ac-1a4e-4cba-b586-b985a40d28ed	wlx30169d2252f8	6352	13271	2026-01-24 19:33:30.428187+00	1813	3788
81d14069-2f2e-4b38-8351-d7bc22ae0bc4	enp0s31f6	0	0	2026-01-24 22:29:04.013072+00	0	0
4fd90c1f-a404-45bf-8268-9386038c57f9	wlx30169d2252f8	17930	3899	2026-01-24 22:29:04.018251+00	7098	1543
a59f069f-939e-4fed-9f5f-6482f74c4b86	enp0s31f6	0	0	2026-01-24 14:27:54.621861+00	0	0
03502a00-09a4-44e4-aaef-5134ce957231	wlx30169d2252f8	562	0	2026-01-24 14:27:54.627826+00	7088	0
a90ea3bb-b8a3-42fa-9498-840d45f3418b	enp0s31f6	0	0	2026-01-24 17:23:27.930222+00	0	0
c47a67df-e30e-494f-8474-509ff9328ed5	wlx30169d2252f8	4830	11744	2026-01-24 17:23:27.933567+00	4926	11978
2a76049e-4239-4c3b-9651-00e452005376	enp0s31f6	0	0	2026-01-24 19:34:00.419729+00	0	0
1578dbee-9d98-4bea-bb51-816f46307214	wlx30169d2252f8	1502	566	2026-01-24 19:34:00.421682+00	1051	396
2f9db480-9423-45de-9671-187347396b1b	enp0s31f6	0	0	2026-01-24 22:29:34.026916+00	0	0
693a086e-2d2c-4d87-a043-1e176ba60bc8	wlx30169d2252f8	20806	16743	2026-01-24 22:29:34.030839+00	2911	2342
bd48b8cb-c063-44b5-a7b9-c3bfe4b8b27b	enp0s31f6	0	0	2026-01-24 14:28:24.614369+00	0	0
2c410254-4cac-4e00-b10a-709300a73afa	wlx30169d2252f8	19015	492791	2026-01-24 14:28:24.619552+00	10931	283292
51a493d0-b266-449d-9f71-3b829ec2a856	enp0s31f6	0	0	2026-01-24 17:23:57.915111+00	0	0
40b1160f-6ac9-412a-8303-c62bc5d24fdd	wlx30169d2252f8	632	350	2026-01-24 17:23:57.918619+00	782	433
1c1d7851-e0de-4301-a06a-602fb58adb62	enp0s31f6	0	0	2026-01-24 19:34:30.48677+00	0	0
a1c719ff-1586-44d4-8036-36108971dcb7	wlx30169d2252f8	5176	10574	2026-01-24 19:34:30.49545+00	1471	3007
3581c641-4f75-41e2-bbfe-bcc48b3361e5	enp0s31f6	0	0	2026-01-24 22:30:04.021113+00	0	0
e8f96d0f-7a55-4109-8f6f-10228bb53961	wlx30169d2252f8	17954	3981	2026-01-24 22:30:04.024224+00	7058	1565
2763faac-c049-464b-aed6-8091658779a1	enp0s31f6	0	0	2026-01-24 14:28:54.621397+00	0	0
78e5820c-1d4c-48c4-ac7a-78d0e9bae136	wlx30169d2252f8	174	224	2026-01-24 14:28:54.625612+00	1800	2318
f5daa1e7-e33b-4dfc-8306-ff6cf551f65c	enp0s31f6	0	0	2026-01-24 17:24:27.967472+00	0	0
fbb9308e-f905-4247-a7b9-d9289d62c941	wlx30169d2252f8	5266	15924	2026-01-24 17:24:27.976561+00	5202	15731
5506d892-7423-4298-89c3-595c76ab8bad	enp0s31f6	0	0	2026-01-24 19:35:00.45587+00	0	0
923c1fbd-9d60-45f7-a6de-ba6cc58a5eef	wlx30169d2252f8	1622	566	2026-01-24 19:35:00.45965+00	1117	389
a4f994a8-c3bc-456a-9b6c-b4081fa86c6c	enp0s31f6	0	0	2026-01-24 22:30:34.049196+00	0	0
774dc204-4b97-4dc8-9440-8686776cc352	wlx30169d2252f8	18980	9821	2026-01-24 22:30:34.053137+00	2664	1378
780adee9-5be5-4f2b-a592-3fe02459871b	enp0s31f6	0	0	2026-01-24 14:29:24.671153+00	0	0
bb402523-1624-4798-8d6d-f7d378e9272f	wlx30169d2252f8	3797	10292	2026-01-24 14:29:24.679293+00	2089	5663
f4598cf5-7330-4844-988d-a2eded2ed32a	enp0s31f6	0	0	2026-01-24 17:24:57.936534+00	0	0
2ac58468-3267-4ff7-bb03-2b4c5c982661	wlx30169d2252f8	916	350	2026-01-24 17:24:57.94024+00	1123	429
1f7c437a-da8f-4dba-8397-2b4605f7fef7	enp0s31f6	0	0	2026-01-24 19:35:30.509929+00	0	0
448dae84-700b-4bc0-bf22-a2c6e0c661b0	wlx30169d2252f8	4516	10035	2026-01-24 19:35:30.517181+00	1268	2817
dbf0b578-9832-4a05-b935-e8f8a4cb44ba	enp0s31f6	0	0	2026-01-24 22:31:04.057495+00	0	0
c1e6960a-15e8-483e-ba20-63893e6bdd4e	wlx30169d2252f8	20533	4118	2026-01-24 22:31:04.077573+00	8092	1623
a262b20e-95ef-4903-b479-5a8f63bbbe91	enp0s31f6	0	0	2026-01-24 14:29:54.622626+00	0	0
322a3dc0-fa5a-4d62-bb42-e6c3b2190ba2	wlx30169d2252f8	0	0	2026-01-24 14:29:54.624426+00	0	0
bca37ed1-0ade-4eb6-a142-b4a2c78fbfe6	enp0s31f6	0	0	2026-01-24 17:25:27.991379+00	0	0
9461457f-e37c-4885-a09e-886b49f35286	wlx30169d2252f8	3472	12393	2026-01-24 17:25:27.998622+00	3199	11418
e6cefa98-39cc-4f01-801c-5a12ad3fab7b	enp0s31f6	0	0	2026-01-24 19:36:00.479027+00	0	0
afdffa02-1871-4c92-a0d5-32fe0111424d	wlx30169d2252f8	1382	566	2026-01-24 19:36:00.483014+00	937	384
e772f8e1-f619-4585-96b4-27f67c730ace	enp0s31f6	0	0	2026-01-24 22:31:34.108213+00	0	0
6cf70b10-65dc-4295-aae0-ab732d98c189	wlx30169d2252f8	19132	13452	2026-01-24 22:31:34.1126+00	2666	1874
462732c3-ba27-4446-819e-aa729d2cf02a	enp0s31f6	0	0	2026-01-24 14:30:24.688924+00	0	0
66a71e86-9ab8-48c9-88fa-6e8160266201	wlx30169d2252f8	3749	9369	2026-01-24 14:30:24.696315+00	2073	5181
10385ead-6bf5-43a2-9c2b-7fd68b2aaf06	enp0s31f6	0	0	2026-01-24 17:25:57.957727+00	0	0
76337499-41fb-46cd-b0df-c5bd5e25a979	wlx30169d2252f8	778	350	2026-01-24 17:25:57.961473+00	931	419
676bac4e-917e-4a45-b377-45b6a8c26bd4	enp0s31f6	0	0	2026-01-24 19:36:30.507372+00	0	0
1c306172-8220-4e1b-8fce-a29bda037ea9	wlx30169d2252f8	18524	11407	2026-01-24 19:36:30.510074+00	5215	3211
ce4863bb-62d4-4c89-9ee1-650d5a7e8fa2	enp0s31f6	0	0	2026-01-24 22:32:04.079485+00	0	0
6ca9e2d0-687b-4880-96f0-69475f785012	wlx30169d2252f8	26080	4118	2026-01-24 22:32:04.083169+00	10119	1597
5b730e24-29e4-4aab-9627-df7bfa41bd5e	enp0s31f6	0	0	2026-01-24 14:30:54.643646+00	0	0
aa76e410-ff34-4d10-bfa0-9236e7d3d94b	wlx30169d2252f8	42	0	2026-01-24 14:30:54.646441+00	552	0
6509a5b3-c49e-4570-baeb-2feb6234b889	enp0s31f6	0	0	2026-01-24 17:26:28.010722+00	0	0
10467970-3fa6-4ff0-869c-9cff8514a128	wlx30169d2252f8	4308	14500	2026-01-24 17:26:28.01794+00	4259	14337
527820e9-b77e-4560-8992-7912a3fa0cb4	enp0s31f6	0	0	2026-01-24 19:37:00.501298+00	0	0
1466122c-dbca-49d9-92ce-e188db5ddca2	wlx30169d2252f8	1280	566	2026-01-24 19:37:00.504861+00	868	383
0ccf3404-683e-420d-9167-c7a8a8ea76a6	enp0s31f6	0	0	2026-01-24 22:32:34.135059+00	0	0
38219e6b-9202-445a-ac4a-ea5541d64a21	wlx30169d2252f8	20524	14737	2026-01-24 22:32:34.143598+00	2831	2032
9eb5bc17-523e-4723-a93f-35d6a8fdc9b0	enp0s31f6	0	0	2026-01-24 14:31:24.705175+00	0	0
2201c57d-c3e8-4489-ab55-621dfea0799c	wlx30169d2252f8	3809	7738	2026-01-24 14:31:24.712787+00	2043	4151
b2108e0a-8c80-4dd2-8576-48b08cbded85	enp0s31f6	0	0	2026-01-24 17:26:57.978644+00	0	0
50b4b4d1-59cf-43d5-b2b2-5a1d89f50d90	wlx30169d2252f8	778	350	2026-01-24 17:26:57.982405+00	922	415
b300035e-1e64-4d76-92a7-69e9061bbf17	enp0s31f6	0	0	2026-01-24 19:37:30.554387+00	0	0
003f2d3f-3624-4032-9358-729a06824429	wlx30169d2252f8	5316	11547	2026-01-24 19:37:30.562206+00	1493	3243
2de534ab-ba02-4f01-925d-3783f5ab6ee5	enp0s31f6	0	0	2026-01-24 22:33:04.087137+00	0	0
aa504287-7b15-4c78-b1b8-d4d2bfc06d08	wlx30169d2252f8	18591	4002	2026-01-24 22:33:04.090202+00	7298	1571
29139b4f-af2c-40ed-bb03-8184b536af0d	enp0s31f6	0	0	2026-01-24 14:31:54.674935+00	0	0
79b2ba01-4821-459f-a028-ab5ec2d20c15	wlx30169d2252f8	0	0	2026-01-24 14:31:54.677893+00	0	0
ff81aee5-b54a-4127-bc8f-e7b9884165dc	enp0s31f6	0	0	2026-01-24 17:27:28.019495+00	0	0
766e6d59-d4d5-4d42-a125-26938f2b43c0	wlx30169d2252f8	4246	10610	2026-01-24 17:27:28.026425+00	3738	9341
de0897a3-c429-44d4-bc79-3fb241e952bd	enp0s31f6	0	0	2026-01-24 19:38:00.523622+00	0	0
d30c4dcf-8eaf-4257-bad6-68264501b13e	wlx30169d2252f8	1400	566	2026-01-24 19:38:00.528851+00	947	382
e1f6a328-c318-44c0-9ca7-e1e63f78ebf6	enp0s31f6	0	0	2026-01-24 22:33:34.144546+00	0	0
d0ed0a16-568c-4299-b30d-254398ebd90e	wlx30169d2252f8	17498	9957	2026-01-24 22:33:34.147932+00	2435	1385
e0e5d53b-f687-4d0e-bcf9-3db2645f0102	enp0s31f6	0	0	2026-01-24 14:32:24.728215+00	0	0
203a5cc4-2297-4768-97d7-1b497104e6c2	wlx30169d2252f8	4037	7633	2026-01-24 14:32:24.73578+00	2174	4111
307dfd82-a469-405f-80d6-1cc937300dc2	enp0s31f6	0	0	2026-01-24 17:27:57.987575+00	0	0
6e1892d5-5e69-489d-9230-375e1433fa52	wlx30169d2252f8	2041	444	2026-01-24 17:27:57.991711+00	2419	526
f34713b0-50a0-457a-bee1-ebaccc8e1915	enp0s31f6	0	0	2026-01-24 19:38:30.570365+00	0	0
b3074238-2006-40f9-a2b0-50d7169e3638	wlx30169d2252f8	6164	12613	2026-01-24 19:38:30.577491+00	1701	3481
ba86b4a3-9851-45bf-a835-baf3efbef0ac	enp0s31f6	0	0	2026-01-24 22:34:04.124771+00	0	0
cfd067a8-7d0a-4bc7-8040-2b03f1a5ba24	wlx30169d2252f8	18467	4251	2026-01-24 22:34:04.130269+00	7198	1657
a35426ed-0dc6-4023-9345-b569898651f2	enp0s31f6	0	0	2026-01-24 14:32:54.69542+00	0	0
f15b3eb6-8c1b-47f5-a942-a02d32b71449	wlx30169d2252f8	181	0	2026-01-24 14:32:54.69953+00	2079	0
25696028-062c-43f5-b5d1-e1e2fa470fad	enp0s31f6	0	0	2026-01-24 17:28:28.017911+00	0	0
7614c38c-df83-4c86-a465-9ab9a45231d7	wlx30169d2252f8	2860	8379	2026-01-24 17:28:28.020485+00	2531	7416
ae917d02-55ca-442b-84ab-623637086912	enp0s31f6	0	0	2026-01-24 19:39:00.543014+00	0	0
656e3142-6dda-41c3-8327-3345d71115c0	wlx30169d2252f8	1674	636	2026-01-24 19:39:00.546746+00	1118	424
74cbfd8a-0b2a-41a7-ad8b-8ee3aeca63d6	enp0s31f6	0	0	2026-01-24 22:34:34.178364+00	0	0
14b82a98-8089-413b-a8be-22d96e12a777	wlx30169d2252f8	21027	17467	2026-01-24 22:34:34.187407+00	2915	2421
0c6fbae8-79cf-40b5-985e-0a2e912f13cc	enp0s31f6	0	0	2026-01-24 14:33:24.74617+00	0	0
e914645a-4f10-408d-9bce-db6ed3a3725e	wlx30169d2252f8	3804	7728	2026-01-24 14:33:24.753711+00	2035	4135
68042fce-2ace-4b9d-a376-25f9cae49a8f	enp0s31f6	0	0	2026-01-24 17:28:58.008157+00	0	0
a2456476-06d2-4107-965f-cb631c15cbb5	wlx30169d2252f8	718	444	2026-01-24 17:28:58.012379+00	848	524
d51e8cec-2d94-4fc7-960a-0d055de6a7cc	enp0s31f6	0	0	2026-01-24 19:39:30.578791+00	0	0
bc427993-87a1-4153-ab27-73245a046495	wlx30169d2252f8	5526	13565	2026-01-24 19:39:30.587406+00	1545	3794
1cb83a6d-cf78-450b-8f1a-23963dfea996	enp0s31f6	0	0	2026-01-24 22:35:04.133604+00	0	0
37ad4cb4-a643-419e-8816-0796ba61b8c6	wlx30169d2252f8	19145	4377	2026-01-24 22:35:04.135964+00	7464	1706
288e2c56-3839-46db-a2fb-2bcf7ac1fa96	enp0s31f6	0	0	2026-01-24 14:33:54.714891+00	0	0
112be628-c131-480d-993a-0a17b6c2461e	wlx30169d2252f8	181	0	2026-01-24 14:33:54.71914+00	1823	0
ec72f839-95f0-43df-aa9b-e96fe66033b7	enp0s31f6	0	0	2026-01-24 17:29:28.063111+00	0	0
7f31fb60-b33c-4809-b4d8-e2772e157710	wlx30169d2252f8	5640	16154	2026-01-24 17:29:28.070653+00	4845	13877
70ada77b-e78d-4451-b083-e32b4a083224	enp0s31f6	0	0	2026-01-24 19:40:00.531153+00	0	0
9017e34b-2090-494f-9507-d9891d30878d	wlx30169d2252f8	3270	566	2026-01-24 19:40:00.532679+00	2250	389
45dd8736-0bdf-458f-a93a-66f9a9da22de	enp0s31f6	0	0	2026-01-24 22:35:34.165204+00	0	0
184f168b-e30f-4ad9-805a-214eefcc2fad	wlx30169d2252f8	28272	16325	2026-01-24 22:35:34.169222+00	3893	2248
148cde1f-7a88-4197-bc0e-f96645edf4dc	enp0s31f6	0	0	2026-01-24 14:34:24.763428+00	0	0
7a3d2616-88f4-4843-a6e6-e51cd3f1825f	wlx30169d2252f8	89903	51539	2026-01-24 14:34:24.769275+00	2994	1716
7077ca67-ddfc-40c1-b32c-60cb4a17f8b4	enp0s31f6	0	0	2026-01-24 17:29:58.030632+00	0	0
b3e4e9a3-5657-4e4a-baea-123a83a03254	wlx30169d2252f8	796	350	2026-01-24 17:29:58.034383+00	964	424
088d15b8-57ab-48c8-bba8-b2532091e432	enp0s31f6	0	0	2026-01-24 19:40:30.596477+00	0	0
b17250ce-2f98-4f1f-8fed-5e00b2a06486	wlx30169d2252f8	4964	7631	2026-01-24 19:40:30.606977+00	1387	2133
d87a62fc-485e-4d54-a654-90276735a289	enp0s31f6	0	0	2026-01-24 22:36:04.169569+00	0	0
16663262-a301-4cdc-a428-143b12282e81	wlx30169d2252f8	18727	4605	2026-01-24 22:36:04.17477+00	7264	1786
1d2be22c-5a84-490e-94df-0f003e4a73e4	enp0s31f6	0	0	2026-01-24 14:34:54.735272+00	0	0
dc098f78-158e-4f2c-9e09-740f12ccb049	wlx30169d2252f8	347	0	2026-01-24 14:34:54.739467+00	3402	0
04efaa04-79f2-44c8-b635-28322f807958	enp0s31f6	0	0	2026-01-24 17:30:28.070469+00	0	0
98f74446-0072-4e6d-91b3-237910992617	wlx30169d2252f8	4608	13355	2026-01-24 17:30:28.078843+00	3926	11379
8bd3bcb1-2e08-4eea-ade1-723bd7528599	enp0s31f6	0	0	2026-01-24 19:41:00.553366+00	0	0
a05121bb-36c4-4cd9-a5b7-958a22b7300a	wlx30169d2252f8	1424	566	2026-01-24 19:41:00.555314+00	976	388
4909d7c2-a544-43be-9fb9-e48c49c1623c	enp0s31f6	0	0	2026-01-24 22:36:34.208891+00	0	0
b039a269-5f89-4064-a7f9-c93d1ba8d27c	wlx30169d2252f8	27800	12357	2026-01-24 22:36:34.216107+00	3849	1710
2864cefc-08e8-4b19-824f-4779eb45b983	enp0s31f6	0	0	2026-01-24 14:35:24.789438+00	0	0
6eab4ce6-2d74-4dfd-8ced-94299a18405e	wlx30169d2252f8	80520	52151	2026-01-24 14:35:24.798828+00	2682	1737
7efe1ab5-79ab-4408-acdb-036f312ca138	enp0s31f6	0	0	2026-01-24 17:30:58.0242+00	0	0
e1985154-d6d4-448d-a04c-7ec8292cc6fd	wlx30169d2252f8	294	350	2026-01-24 17:30:58.027033+00	355	423
5ebcb56b-20f4-4061-9334-cbebc3028aef	enp0s31f6	0	0	2026-01-24 19:41:30.578596+00	0	0
f98990e4-e532-409b-8822-2837fd6fa068	wlx30169d2252f8	4556	10045	2026-01-24 19:41:30.580987+00	1255	2768
bacc25c4-cf83-48d8-ab46-e98d6834d1f6	enp0s31f6	0	0	2026-01-24 22:37:04.178874+00	0	0
7ca6283b-908d-4ff8-9a4c-b3e6adffe3b6	wlx30169d2252f8	20421	4894	2026-01-24 22:37:04.183806+00	7905	1894
c8fe776c-7e02-4a57-9faa-629ed90e0ae4	enp0s31f6	0	0	2026-01-24 14:35:54.754398+00	0	0
4f16f58c-0edb-4275-8b70-21baf43b59b1	wlx30169d2252f8	60	0	2026-01-24 14:35:54.75848+00	596	0
acc4c249-ec24-413e-b2bf-d278e5c9e73e	enp0s31f6	0	0	2026-01-24 17:31:28.066483+00	0	0
3d241656-72c2-4f94-ad8e-3e5c4bf6df77	wlx30169d2252f8	4044	10687	2026-01-24 17:31:28.070798+00	3476	9187
f890cc84-7d64-48e2-8615-f8e6ba3870e2	enp0s31f6	0	0	2026-01-24 19:42:00.589234+00	0	0
18f8980e-c8d8-40bb-af21-e53ad448ca17	wlx30169d2252f8	1628	566	2026-01-24 19:42:00.592953+00	1099	382
15fc75c0-7e0c-43ef-abc2-f60ad7c0d0f3	enp0s31f6	0	0	2026-01-24 22:37:34.196431+00	0	0
5d722769-997c-4a09-a0d4-2b8f51595984	wlx30169d2252f8	20719	12374	2026-01-24 22:37:34.198704+00	2844	1698
e4791550-5db8-4da3-a48d-d7de560196a5	enp0s31f6	0	0	2026-01-24 14:36:24.806329+00	0	0
4b5e1855-5585-489f-abe0-2bae87db06b9	wlx30169d2252f8	80007	51830	2026-01-24 14:36:24.813376+00	2665	1726
94c94b84-ea47-4c6d-b63b-6a15a2b91f6a	enp0s31f6	0	0	2026-01-24 17:31:58.061286+00	0	0
5f29264e-4b03-405b-8315-fc60586cdbb5	wlx30169d2252f8	714	350	2026-01-24 17:31:58.065547+00	856	419
18ddf0bb-5fb8-4f76-9dfd-aebf43d8fb65	enp0s31f6	0	0	2026-01-24 19:42:30.601291+00	0	0
426f375d-5535-48a7-89dc-230953d14543	wlx30169d2252f8	6274	14067	2026-01-24 19:42:30.606076+00	1736	3894
6ed3460b-4e72-47d0-aa30-991e97d0acf1	enp0s31f6	0	0	2026-01-24 22:38:04.19762+00	0	0
f107c8f5-17eb-4b9b-a861-f5fc31deb6a4	wlx30169d2252f8	20672	5929	2026-01-24 22:38:04.201682+00	7999	2294
e3afe4fe-1faa-4f1b-9728-01963afbeb0f	enp0s31f6	0	0	2026-01-24 14:36:54.775775+00	0	0
99c17a31-bb40-416b-97e9-d84ef50d7ce4	wlx30169d2252f8	60	0	2026-01-24 14:36:54.779688+00	427	0
a2f3e981-eaff-49b9-8b57-793df0751880	enp0s31f6	0	0	2026-01-24 17:32:28.073361+00	0	0
4f4b0aa5-d967-4da3-8e96-c7a351ccfe3f	wlx30169d2252f8	3108	10608	2026-01-24 17:32:28.075905+00	2684	9163
2ccc68a4-fb9d-44e4-86e7-1812beac9710	enp0s31f6	0	0	2026-01-24 19:43:00.607289+00	0	0
eb142a74-17d6-4c0f-bb81-582ed7a30caf	wlx30169d2252f8	1217	350	2026-01-24 19:43:00.612844+00	819	235
3cdcfb87-cae4-40bb-8be7-e444c1ffaef9	enp0s31f6	0	0	2026-01-24 22:38:34.212113+00	0	0
c08b4c52-178d-4693-9f0a-17f2ef7ead5b	wlx30169d2252f8	20239	11589	2026-01-24 22:38:34.215838+00	2793	1599
ac8a37c4-9c05-485f-92a7-0fac7b1d3d31	enp0s31f6	0	0	2026-01-24 14:37:24.826218+00	0	0
18ec5da9-8e42-4dd9-8b70-cbf52c78197e	wlx30169d2252f8	80868	51558	2026-01-24 14:37:24.830818+00	2693	1717
88537e02-63b7-4f03-bc10-1d2848900aee	enp0s31f6	0	0	2026-01-24 17:32:58.080926+00	0	0
0f4032f7-8f70-4e99-9fa5-d5441f0685fa	wlx30169d2252f8	586	350	2026-01-24 17:32:58.084467+00	698	417
d0529180-455b-45f3-8847-9bd81fa7fe2c	enp0s31f6	0	0	2026-01-24 19:43:30.660088+00	0	0
01286a95-490d-447f-8f97-a5d97901dea2	wlx30169d2252f8	6114	12362	2026-01-24 19:43:30.667055+00	1607	3249
fb2f6d95-f168-405f-86fa-c3869bf32534	enp0s31f6	0	0	2026-01-24 22:39:04.219822+00	0	0
9dd019fa-04e3-438e-b321-292cf5339053	wlx30169d2252f8	28011	5969	2026-01-24 22:39:04.225146+00	10821	2305
1c261339-cd6f-4279-aceb-b677f3b2148a	enp0s31f6	0	0	2026-01-24 14:37:54.782511+00	0	0
8d9d0d15-7ed0-4e9c-8876-e21698e150d0	wlx30169d2252f8	0	0	2026-01-24 14:37:54.785153+00	0	0
5276f5a1-806e-4f06-be67-41400a7977f1	enp0s31f6	0	0	2026-01-24 17:33:28.124268+00	0	0
89dbc82d-4f95-42c8-a90d-76fcd4b16fa2	wlx30169d2252f8	4708	16509	2026-01-24 17:33:28.129929+00	3791	13294
78b1ec53-a2ab-4eb3-8deb-c04c9d4cf8ea	enp0s31f6	0	0	2026-01-24 19:44:00.628331+00	0	0
b8d3fc71-57d6-4459-8afc-dbf0a69533c4	wlx30169d2252f8	1517	350	2026-01-24 19:44:00.632073+00	1019	235
8317097e-b7cb-45d8-a9c1-5f45681594fd	enp0s31f6	0	0	2026-01-24 22:39:34.232647+00	0	0
dace2caa-0be6-4217-a452-e37a12b031f4	wlx30169d2252f8	20577	12044	2026-01-24 22:39:34.236371+00	2800	1639
96268c2d-d2bb-4960-9113-627a036c1ed4	enp0s31f6	0	0	2026-01-24 14:38:24.839043+00	0	0
e21fc060-d078-4edc-af7f-29a12c22cb16	wlx30169d2252f8	109565	54625	2026-01-24 14:38:24.848215+00	3649	1819
e66d90a1-fb01-4a88-8be8-f013ba956e5d	enp0s31f6	0	0	2026-01-24 17:33:58.094846+00	0	0
5cc4fb02-f260-4b93-ada4-df60de1b768a	wlx30169d2252f8	456	350	2026-01-24 17:33:58.098509+00	544	417
8c8a8383-5f81-42cc-8f0b-dd663555038e	enp0s31f6	0	0	2026-01-24 19:44:30.679173+00	0	0
a41d43d2-47c7-4887-ae01-0a929238bf4d	wlx30169d2252f8	5574	12230	2026-01-24 19:44:30.688145+00	1471	3229
d231d1fa-2bb6-4775-b9f4-ec524a8ba061	enp0s31f6	0	0	2026-01-24 22:40:04.239551+00	0	0
9dafd648-01bf-4f89-9da0-b294fccc0690	wlx30169d2252f8	19410	5023	2026-01-24 22:40:04.243692+00	7473	1933
2932e5c1-2e4b-46ee-8734-f2b4e98e270b	enp0s31f6	0	0	2026-01-24 14:38:54.792315+00	0	0
7bedf083-c136-4399-adbb-01e8dd843694	wlx30169d2252f8	60	0	2026-01-24 14:38:54.793891+00	477	0
cd54b610-59b3-420b-8937-2263fc14167f	enp0s31f6	0	0	2026-01-24 17:34:28.150204+00	0	0
a9684181-68cb-42d3-bf88-9a13ece80142	wlx30169d2252f8	4240	9490	2026-01-24 17:34:28.1574+00	3549	7945
3ccaf3db-155b-4bf7-844d-0bf1ad4309b4	enp0s31f6	0	0	2026-01-24 19:45:00.644033+00	0	0
33cf4fcd-ca68-4040-89ff-fade8ffe0a72	wlx30169d2252f8	1457	350	2026-01-24 19:45:00.646908+00	980	235
80b33092-5fe1-4497-8861-53469446a17f	enp0s31f6	0	0	2026-01-24 22:40:34.292987+00	0	0
48128439-e62d-4e68-9fe4-6a6f66603678	wlx30169d2252f8	20963	13230	2026-01-24 22:40:34.299103+00	2824	1782
83b813f9-351d-4156-8ae2-d4edfb722a99	enp0s31f6	0	0	2026-01-24 14:39:24.857513+00	0	0
9974e38a-438c-4f3e-9659-fb9dee0584fb	wlx30169d2252f8	88419	51020	2026-01-24 14:39:24.864999+00	2944	1698
3f017d11-6f80-4257-8a13-c60379a6e940	enp0s31f6	0	0	2026-01-24 17:34:58.117436+00	0	0
02f81fe9-3aa5-460e-acfa-1f5cd400550f	wlx30169d2252f8	676	350	2026-01-24 17:34:58.121671+00	804	416
e1cc1d00-8aa2-4545-be73-7dadab5da4c9	enp0s31f6	0	0	2026-01-24 19:45:30.669873+00	0	0
a2833498-0ebb-4ca9-8fcf-c09dd61e4551	wlx30169d2252f8	5864	14069	2026-01-24 19:45:30.672396+00	1555	3731
2a87397c-f13e-493d-ad19-265f7a48bb24	enp0s31f6	0	0	2026-01-24 22:41:04.262585+00	0	0
5269a0a6-2986-4b45-b1c3-cd0ccbe1e016	wlx30169d2252f8	20484	5887	2026-01-24 22:41:04.266452+00	7795	2240
fe5bbf60-23b7-4af9-a825-992e15eeb5e8	enp0s31f6	0	0	2026-01-24 14:39:54.828265+00	0	0
caa9dac2-96f7-4720-b7dd-962dee2d2823	wlx30169d2252f8	0	0	2026-01-24 14:39:54.832471+00	0	0
236e7921-dd9c-4b3f-b8f5-f560f9704c92	enp0s31f6	0	0	2026-01-24 17:35:28.169477+00	0	0
3206a483-a5b9-4fcb-88a3-6174eb2b406c	wlx30169d2252f8	5650	16267	2026-01-24 17:35:28.176866+00	4539	13069
45ed1c22-269f-4ca4-a45a-dfccb556cb99	enp0s31f6	0	0	2026-01-24 19:46:00.672141+00	0	0
21e29b84-0c49-47d6-9aaa-bb325475eb0c	wlx30169d2252f8	1277	350	2026-01-24 19:46:00.675827+00	854	234
69eb538c-d640-4b30-9aff-ff2ba5144b9f	enp0s31f6	0	0	2026-01-24 22:41:34.309897+00	0	0
a143c800-8c2b-41e6-88a3-4846726a5b4b	wlx30169d2252f8	33621	15412	2026-01-24 22:41:34.317024+00	4536	2079
2a223547-db2c-4a42-af52-28add17a264c	enp0s31f6	0	0	2026-01-24 14:40:24.879856+00	0	0
74bd7ff8-2633-4279-ac3d-cfb7a2681909	wlx30169d2252f8	86324	51600	2026-01-24 14:40:24.887379+00	2875	1718
c43f7aa3-ca6e-48f6-a49f-9e365bcf38a7	enp0s31f6	0	0	2026-01-24 17:35:58.138045+00	0	0
484c94bf-74e8-4976-8e48-76001a2a3cbe	wlx30169d2252f8	474	350	2026-01-24 17:35:58.141697+00	557	411
b8a9a12e-6139-4813-a6c5-431ce93ed2d9	enp0s31f6	0	0	2026-01-24 19:46:30.696205+00	0	0
0ab82112-0926-4f3f-a242-1e3742d18370	wlx30169d2252f8	4170	9895	2026-01-24 19:46:30.698705+00	1103	2617
0acb5871-5d85-4044-9e75-b033ea868d1f	enp0s31f6	0	0	2026-01-24 22:42:04.279545+00	0	0
e04f73af-19eb-4c56-bd42-a6bf55a0b3ae	wlx30169d2252f8	19916	5949	2026-01-24 22:42:04.28307+00	7624	2277
64c57666-9de2-4f50-8fa0-2bab5a56aac4	enp0s31f6	0	0	2026-01-24 14:40:54.847889+00	0	0
3e9cc84d-a9dd-410c-ad1b-8e6d30f24f92	wlx30169d2252f8	60	0	2026-01-24 14:40:54.85189+00	472	0
bcc313b8-604d-466e-9447-3fd5b03d8718	enp0s31f6	0	0	2026-01-24 17:36:28.190448+00	0	0
13069650-de9b-40c1-b406-576e3c5377a3	wlx30169d2252f8	4726	12562	2026-01-24 17:36:28.199068+00	3845	10221
073e07f4-0ac5-4572-b46a-ad3986e1e4b8	enp0s31f6	0	0	2026-01-24 19:47:00.694639+00	0	0
3920dda7-746f-4eb9-b355-4ea08b5946ef	wlx30169d2252f8	775	350	2026-01-24 19:47:00.697623+00	514	232
077f7867-230c-454f-8a54-b0be8b007b8f	enp0s31f6	0	0	2026-01-24 22:42:34.292325+00	0	0
7a575f29-faf0-412f-a77a-f3836a16693a	wlx30169d2252f8	21033	12869	2026-01-24 22:42:34.296107+00	2859	1749
5b362492-85f3-40e3-96f4-d69d2c711e1d	enp0s31f6	0	0	2026-01-24 14:41:24.900212+00	0	0
df0da1fe-86b1-489b-afd9-37c30f4e1290	wlx30169d2252f8	87904	52054	2026-01-24 14:41:24.907915+00	2928	1733
4f799b8b-d835-47ae-be76-8910e2ddc4be	enp0s31f6	0	0	2026-01-24 17:36:58.158914+00	0	0
0a3b6f6f-75b4-42b5-a0ac-b7655454d1d5	wlx30169d2252f8	678	350	2026-01-24 17:36:58.162515+00	760	392
d7cb71bf-c35d-4d99-946c-d39fae352b88	enp0s31f6	0	0	2026-01-24 19:47:30.738739+00	0	0
a514db3d-9d6e-4e09-85fe-f6dcd2478e96	wlx30169d2252f8	6328	11188	2026-01-24 19:47:30.745862+00	1682	2974
25d13282-5df1-473c-b4b8-5187ff9fe068	enp0s31f6	0	0	2026-01-24 22:43:04.301709+00	0	0
be2de58a-af5b-4a78-9a3f-f7e21864f1f9	wlx30169d2252f8	21366	7792	2026-01-24 22:43:04.307355+00	8149	2972
2bc1a057-645f-4c66-98c5-2780814de24c	enp0s31f6	0	0	2026-01-24 14:41:54.868306+00	0	0
05582bdd-1b2a-4a2c-8012-f6c64689489c	wlx30169d2252f8	0	0	2026-01-24 14:41:54.87245+00	0	0
35b9aef0-bbcb-4671-a374-5a72046fe7a4	enp0s31f6	0	0	2026-01-24 17:37:28.197298+00	0	0
778f05fd-d885-4c7b-a34f-f972c0bc548c	wlx30169d2252f8	3270	10612	2026-01-24 17:37:28.201067+00	2677	8690
181a82eb-3fcb-4862-9c03-c711bd4e3193	enp0s31f6	0	0	2026-01-24 19:48:00.707411+00	0	0
2aba554b-8d56-42cd-ab87-98d13432ee7e	wlx30169d2252f8	2747	350	2026-01-24 19:48:00.713173+00	1819	231
5d574215-6c77-45c7-8085-bfa5baa0da88	enp0s31f6	0	0	2026-01-24 22:43:34.352884+00	0	0
1bb05e31-594e-4cd4-ac18-722ae5b568a2	wlx30169d2252f8	29122	16443	2026-01-24 22:43:34.360113+00	3914	2210
55838e59-3ec4-429d-b964-a9f30ae61441	enp0s31f6	0	0	2026-01-24 14:42:24.922+00	0	0
48d6a4f1-1d17-48e9-90aa-a527422c1860	wlx30169d2252f8	79760	51912	2026-01-24 14:42:24.930862+00	2656	1729
da446ad2-446b-41c3-b5a9-56fcfe426e2a	enp0s31f6	0	0	2026-01-24 17:37:58.165464+00	0	0
1b83f549-4f71-406f-bbfb-00e2c9400fcc	wlx30169d2252f8	2188	350	2026-01-24 17:37:58.167044+00	2474	395
8ed726ed-2314-4936-b8b7-f2304980ad0d	enp0s31f6	0	0	2026-01-24 19:48:30.748772+00	0	0
dd45beee-c764-4cd8-8c66-f045fa9ff6a3	wlx30169d2252f8	5696	12730	2026-01-24 19:48:30.755955+00	1503	3360
e66857b8-89b0-429d-bb5d-ae3dc09b31ad	enp0s31f6	0	0	2026-01-24 22:44:04.319822+00	0	0
a3c2cdc5-694b-41c9-b77e-8cfc6ec6b781	wlx30169d2252f8	21196	7568	2026-01-24 22:44:04.323486+00	8082	2885
41a90aad-3f2d-4b61-a075-7a369bee5076	enp0s31f6	0	0	2026-01-24 14:42:54.88768+00	0	0
6d122733-d999-430a-a12e-13edaed5e11d	wlx30169d2252f8	60	0	2026-01-24 14:42:54.891754+00	399	0
b76b12e0-8164-44e3-b0bd-44ddfc574c23	enp0s31f6	0	0	2026-01-24 17:38:28.2325+00	0	0
12a9e628-ed94-4659-a3c8-910781580dd3	wlx30169d2252f8	4412	13670	2026-01-24 17:38:28.240026+00	3395	10521
b107747f-1ed7-457e-b458-20d08867096e	enp0s31f6	0	0	2026-01-24 19:49:00.716042+00	0	0
232cb758-0f24-4c82-98c9-e3a72d92dfdd	wlx30169d2252f8	2765	350	2026-01-24 19:49:00.720863+00	1844	233
9121653f-ebe7-4cf7-9d82-f5b4b10f2dce	enp0s31f6	0	0	2026-01-24 22:44:34.371783+00	0	0
5c6cd05c-bca8-4a83-9433-7637dfa88b18	wlx30169d2252f8	19989	11303	2026-01-24 22:44:34.380892+00	2686	1518
bfcf3f3b-7b6a-4447-acab-0ebed69b3a41	enp0s31f6	0	0	2026-01-24 14:43:24.939672+00	0	0
3d9ac684-d333-4225-9974-c82d479909c8	wlx30169d2252f8	78154	50991	2026-01-24 14:43:24.947424+00	2603	1698
510a27a8-0d37-44d5-b9d7-7b4301080fec	enp0s31f6	0	0	2026-01-24 17:38:58.18545+00	0	0
390d3e46-a622-4197-b5de-676fb2f43ba2	wlx30169d2252f8	7232	444	2026-01-24 17:38:58.186954+00	8399	515
049d14c4-a348-4350-b854-c43788fa30d8	enp0s31f6	0	0	2026-01-24 19:49:30.768264+00	0	0
a59a6869-4bb9-4241-b09a-f778e0c68c1a	wlx30169d2252f8	6111	12244	2026-01-24 19:49:30.775589+00	1580	3165
8dc90d1f-11c6-4c71-a29b-38d4b20aac78	enp0s31f6	0	0	2026-01-24 22:45:04.346593+00	0	0
34bffd38-a529-4fc5-ad99-a5984532c468	wlx30169d2252f8	20944	7692	2026-01-24 22:45:04.356012+00	7968	2926
22d21e62-ec4b-45a4-b11c-5c4c2befd3ea	enp0s31f6	0	0	2026-01-24 14:43:54.892812+00	0	0
0ce50af2-a7e2-4627-9da6-048c750fc538	wlx30169d2252f8	42	0	2026-01-24 14:43:54.894313+00	258	0
8bb18a30-9bff-436b-a0ca-3b1e44b40fca	enp0s31f6	0	0	2026-01-24 17:39:28.213571+00	0	0
536e13bb-14e1-4576-b1a1-9cfcff2e6d8e	wlx30169d2252f8	3476	11228	2026-01-24 17:39:28.217439+00	2597	8391
6cf604e1-020b-43d1-89ba-e99687424ea7	enp0s31f6	0	0	2026-01-24 19:50:00.736496+00	0	0
8f7fb2f3-d0e4-461c-b815-4165a5404143	wlx30169d2252f8	895	350	2026-01-24 19:50:00.741366+00	588	229
2591f698-6647-4f1c-9e9a-a12d7f34c848	enp0s31f6	0	0	2026-01-24 22:45:34.376026+00	0	0
5262f152-69a2-4be7-ba9c-632a9a34dae6	wlx30169d2252f8	20153	14368	2026-01-24 22:45:34.384795+00	2704	1928
4c22bcfe-917a-4fe9-be41-eef103d44e8a	enp0s31f6	0	0	2026-01-24 14:44:24.92008+00	0	0
090ff19e-ad57-4da1-ab6a-014108507257	wlx30169d2252f8	79931	51219	2026-01-24 14:44:24.924029+00	2662	1706
03fbca71-61cc-445b-af3d-69bd66bf7a50	enp0s31f6	0	0	2026-01-24 17:39:58.221583+00	0	0
16de0c60-2d90-4a93-a6f0-5880b7a60a75	wlx30169d2252f8	474	350	2026-01-24 17:39:58.227163+00	536	396
3f189ff4-47d3-4a3b-8584-2336a8d32519	enp0s31f6	0	0	2026-01-24 19:50:30.789433+00	0	0
2c26bc9c-e3dd-4dc3-9851-3ebc37b7b003	wlx30169d2252f8	5787	10397	2026-01-24 19:50:30.79666+00	1505	2705
d57a97e6-b988-44d4-aba5-fba25c963f03	enp0s31f6	0	0	2026-01-24 22:46:04.346495+00	0	0
d86d77de-7b0e-4e59-a06a-6cb8eea1b8f6	wlx30169d2252f8	16313	7786	2026-01-24 22:46:04.352285+00	6261	2988
87d341f6-17fe-448d-8957-7a8b9e04f137	enp0s31f6	0	0	2026-01-24 14:44:54.915503+00	0	0
8902c04a-b4cd-471e-a4cd-c88ceaec5ff6	wlx30169d2252f8	42	0	2026-01-24 14:44:54.917441+00	251	0
10df1054-0adb-4233-8b39-7ce212016f0f	enp0s31f6	0	0	2026-01-24 17:40:28.2386+00	0	0
4bd999e3-e515-432a-840f-3bcaf5bbcd62	wlx30169d2252f8	4734	13671	2026-01-24 17:40:28.242821+00	3549	10251
a6de0cd1-18e7-4513-a9a1-a07a08939105	enp0s31f6	0	0	2026-01-24 19:51:00.744144+00	0	0
faed20f0-a086-4423-b6b3-c48867d78be7	wlx30169d2252f8	1195	350	2026-01-24 19:51:00.74742+00	791	231
7f6b4205-20a2-4d9e-95e1-63ae7f22fecf	enp0s31f6	0	0	2026-01-24 22:46:34.401724+00	0	0
eb125a03-63b0-4c15-b45a-5dd93d012a32	wlx30169d2252f8	14878	11619	2026-01-24 22:46:34.410214+00	1998	1560
4fca61ad-3946-41d2-8e78-4791dbace5b0	enp0s31f6	0	0	2026-01-24 14:45:24.946755+00	0	0
6679ca1d-a183-4af6-a2bb-5f756192221c	wlx30169d2252f8	83148	52497	2026-01-24 14:45:24.951084+00	2769	1748
43f9d65e-3dd3-49bf-8674-7e1811cc4370	enp0s31f6	0	0	2026-01-24 17:40:58.243147+00	0	0
1f7252f7-71a7-43ce-932b-6de6fd673372	wlx30169d2252f8	456	350	2026-01-24 17:40:58.246852+00	523	402
680c3ad8-b0bc-4311-9231-24e99d01c67e	enp0s31f6	0	0	2026-01-24 19:51:30.799486+00	0	0
f86529b7-3f6b-4749-ac1a-d9c8fc8bc0d7	wlx30169d2252f8	5699	12527	2026-01-24 19:51:30.806927+00	1499	3296
9f088bdf-c914-4f0d-95f4-ca1ffc831c9d	enp0s31f6	0	0	2026-01-24 22:47:04.369562+00	0	0
dca03b51-0183-4379-9bba-5b2c625a2f2b	wlx30169d2252f8	23418	7592	2026-01-24 22:47:04.375203+00	8820	2859
041820ee-0f64-497e-90cf-d69c69b976bf	enp0s31f6	0	0	2026-01-24 14:45:54.947006+00	0	0
14f02903-7064-460a-9a9b-c486f488ac03	wlx30169d2252f8	284	224	2026-01-24 14:45:54.951085+00	1789	1411
003cf5c6-8f24-466e-8f69-db4ea6c176a1	enp0s31f6	0	0	2026-01-24 17:41:28.29348+00	0	0
cbcaabe0-43e6-4d39-a582-eb41871c8d49	wlx30169d2252f8	5162	11832	2026-01-24 17:41:28.300706+00	3896	8931
18021c0d-8547-4aee-a32a-8b05444fb9fc	enp0s31f6	0	0	2026-01-24 19:52:00.77053+00	0	0
e17948de-9767-4cfe-864d-d1194b00044d	wlx30169d2252f8	1111	444	2026-01-24 19:52:00.774365+00	736	294
7059ff37-7ec1-4110-983a-7f29c7022759	enp0s31f6	0	0	2026-01-24 22:47:34.421913+00	0	0
dd4878c5-6112-402b-af19-591640b4b7d6	wlx30169d2252f8	18890	13638	2026-01-24 22:47:34.430404+00	2525	1823
b4264799-df18-49e5-8227-1092d3867f69	enp0s31f6	0	0	2026-01-24 14:46:24.989269+00	0	0
e482bc18-3007-40ec-a11e-58ca1ac9e34b	wlx30169d2252f8	92459	52042	2026-01-24 14:46:24.996553+00	3080	1734
9c9f4abc-2d34-4cbd-bec5-48428d3f1c03	enp0s31f6	0	0	2026-01-24 17:41:58.262573+00	0	0
799f70c1-5c12-491b-89b0-4fdd8b0fbf09	wlx30169d2252f8	696	350	2026-01-24 17:41:58.266281+00	780	392
b27ab1a1-0ce9-4eac-9664-3013b80462f3	enp0s31f6	0	0	2026-01-24 19:52:30.820998+00	0	0
71e04e47-7875-4a52-929c-57f0671321bd	wlx30169d2252f8	13747	16323	2026-01-24 19:52:30.828247+00	3605	4280
3d0f7f58-f72b-46b9-93d6-dc11200e6b18	enp0s31f6	0	0	2026-01-24 22:48:04.378699+00	0	0
9c162953-9774-45a8-9f5a-5a70da9e053f	wlx30169d2252f8	15995	7574	2026-01-24 22:48:04.381909+00	6080	2879
b1a284d8-b1d7-432e-be5f-8246758cf313	enp0s31f6	0	0	2026-01-24 14:46:54.957321+00	0	0
27cde4ac-093c-4059-ab4b-41952994a080	wlx30169d2252f8	164	224	2026-01-24 14:46:54.963352+00	979	1338
98f50d8c-f480-4700-9ac1-1c586315c561	enp0s31f6	0	0	2026-01-24 17:42:28.269049+00	0	0
11515470-8545-4bf8-9069-dd6d32ace4c2	wlx30169d2252f8	4625	12871	2026-01-24 17:42:28.271243+00	3355	9337
e5d8b610-9b01-4035-b22d-499117fb48cc	enp0s31f6	0	0	2026-01-24 19:53:00.790908+00	0	0
13a44c91-ee6b-4007-ae81-a6908f8abc38	wlx30169d2252f8	1431	695	2026-01-24 19:53:00.796339+00	929	451
9a0a8c78-ee8f-4c37-a0d4-17b7fede2f81	enp0s31f6	0	0	2026-01-24 22:48:34.445696+00	0	0
11bf7a42-80c5-436e-aac2-4082d98252bf	wlx30169d2252f8	14688	11315	2026-01-24 22:48:34.453199+00	1964	1513
ffbeef2b-f9c4-44bf-b109-bf4105580feb	enp0s31f6	0	0	2026-01-24 14:47:25.009157+00	0	0
4d61520e-388e-4b1f-9467-c2c37ed3b12f	wlx30169d2252f8	96628	70894	2026-01-24 14:47:25.01678+00	3218	2361
2507ccc1-8f95-48ab-8d74-864b37070771	enp0s31f6	0	0	2026-01-24 17:42:58.276524+00	0	0
592e4182-ef8a-44af-834f-0e56837343e4	wlx30169d2252f8	474	350	2026-01-24 17:42:58.282067+00	518	383
2e36a098-d19d-4868-b695-ea720b1c3d07	enp0s31f6	0	0	2026-01-24 19:53:30.839203+00	0	0
10228397-0dda-4b5a-8574-280f065082aa	wlx30169d2252f8	5589	13488	2026-01-24 19:53:30.846426+00	1436	3467
e94c731d-0e73-49de-8630-ee505b27b497	enp0s31f6	0	0	2026-01-24 22:49:04.400324+00	0	0
94b6597e-9ef6-42fc-b965-222b2312e862	wlx30169d2252f8	16205	7624	2026-01-24 22:49:04.403889+00	6127	2882
9101cd56-d122-49fd-aa9a-6eb6bf732bc1	enp0s31f6	0	0	2026-01-24 14:47:54.980586+00	0	0
0c0ed0bb-0273-4a18-9fb3-ac42fd4897de	wlx30169d2252f8	224	224	2026-01-24 14:47:54.984584+00	1316	1316
ebda7192-c706-494c-9d83-6b6ea75d13ee	enp0s31f6	0	0	2026-01-24 17:43:28.329116+00	0	0
f0acc68c-4031-4297-9675-c9bfeea48cc6	wlx30169d2252f8	2672	8419	2026-01-24 17:43:28.336624+00	1918	6045
26435530-0326-481e-9355-1c64d88013f8	enp0s31f6	0	0	2026-01-24 19:54:00.80801+00	0	0
1b5374c0-b00e-4021-8553-40c4b12733f4	wlx30169d2252f8	1227	1044	2026-01-24 19:54:00.811748+00	810	689
a00c89a5-41e1-4092-8f62-a141d55dcf38	enp0s31f6	0	0	2026-01-24 22:49:34.469168+00	0	0
8354f64f-94d4-44df-b10d-c972ea639fa2	wlx30169d2252f8	19730	14926	2026-01-24 22:49:34.476503+00	2628	1988
84f8ae81-3f19-4808-b832-da4341fb28e6	enp0s31f6	0	0	2026-01-24 14:48:24.998553+00	0	0
db866408-7737-469f-bf59-ea6a36144d09	wlx30169d2252f8	101391	55509	2026-01-24 14:48:25.001309+00	3378	1849
18c8f8b9-dab0-4cdf-a869-5c91ad87b529	enp0s31f6	0	0	2026-01-24 17:43:58.297177+00	0	0
eba829c1-9ee7-4ccc-be65-400d7f886c63	wlx30169d2252f8	472	208	2026-01-24 17:43:58.300927+00	525	231
ea3489b1-2c9f-4163-969a-3a51aa50f66f	enp0s31f6	0	0	2026-01-24 19:54:30.850446+00	0	0
1aa67092-34b5-4146-bffb-fe99ddb8731e	wlx30169d2252f8	5453	11252	2026-01-24 19:54:30.853912+00	1402	2893
6093f9b0-f5b8-4fd8-9f03-468f40047d88	enp0s31f6	0	0	2026-01-24 22:50:04.436318+00	0	0
dde071bf-b8c0-4b0b-b03b-37667cbb1eb4	wlx30169d2252f8	16103	7628	2026-01-24 22:50:04.440523+00	6045	2863
48baa43a-2f69-40dd-b0f4-b52b4a646d74	enp0s31f6	0	0	2026-01-24 14:48:54.997527+00	0	0
4bc0a207-9e81-4199-bbd9-2f8b24be0f89	wlx30169d2252f8	164	224	2026-01-24 14:48:55.00168+00	966	1319
06fce539-3d80-497e-8c30-1400f4f87bdb	enp0s31f6	0	0	2026-01-24 17:44:28.349764+00	0	0
f436d1bd-f1ac-4ad3-abf1-60960104ff10	wlx30169d2252f8	3948	10688	2026-01-24 17:44:28.356852+00	2710	7338
0d5e6efb-3eff-46eb-b530-3f60a658b8c5	enp0s31f6	0	0	2026-01-24 19:55:00.810308+00	0	0
3eb1804b-58d9-4a20-a34b-a42f85139ad5	wlx30169d2252f8	3243	1135	2026-01-24 19:55:00.811678+00	2161	756
a95b84a8-bd6b-428f-9e36-d17120cf9044	enp0s31f6	0	0	2026-01-24 22:50:34.459066+00	0	0
6589c50e-0ee2-45cc-b7ec-1d787757263e	wlx30169d2252f8	23339	14589	2026-01-24 22:50:34.46161+00	3110	1944
692edcb0-ab1c-42bb-9821-80c402dbc35e	enp0s31f6	0	0	2026-01-24 14:49:25.048627+00	0	0
56c313aa-2589-44aa-ae66-f81de45093ca	wlx30169d2252f8	87156	51512	2026-01-24 14:49:25.057792+00	2903	1715
466a2ddd-cadf-4035-96ea-fb9eacdab5fc	enp0s31f6	0	0	2026-01-24 17:44:58.318454+00	0	0
134db3d2-6dcc-4834-8945-afe7c708a617	wlx30169d2252f8	532	126	2026-01-24 17:44:58.322577+00	569	134
63b9ce25-fe17-4f2e-ae11-c559c80463a4	enp0s31f6	0	0	2026-01-24 19:55:30.847401+00	0	0
9c9c26b4-e6ed-4f57-874c-85e1d612a4be	wlx30169d2252f8	7677	14990	2026-01-24 19:55:30.851803+00	1995	3896
ca104ab2-ca18-48b2-8d01-e625290134e7	enp0s31f6	0	0	2026-01-24 22:51:04.4602+00	0	0
4b9bad25-e954-4c59-8f31-43e45c2c33c3	wlx30169d2252f8	17761	7550	2026-01-24 22:51:04.465355+00	6621	2814
b1dfc588-a2e0-4a09-8632-2b425c8421d6	enp0s31f6	0	0	2026-01-24 14:49:55.017061+00	0	0
b35fd9ba-712c-44ce-8962-f0cbaf12fc81	wlx30169d2252f8	648	680	2026-01-24 14:49:55.020945+00	3571	3747
8a88f33b-fc8a-4fc3-8241-f7fd358a346f	enp0s31f6	0	0	2026-01-24 17:45:28.355826+00	0	0
16626781-3bba-4b69-8f30-bde9763dfbab	wlx30169d2252f8	3588	11733	2026-01-24 17:45:28.363562+00	2477	8100
e55499f6-ab7c-4000-b385-ce9678b2b6e2	enp0s31f6	0	0	2026-01-24 19:56:00.846555+00	0	0
a2f1881e-e6f7-4a2b-a3e2-5df903b435ce	wlx30169d2252f8	1449	1068	2026-01-24 19:56:00.851685+00	955	704
81cc2e13-c880-4a84-b22e-9a47ff6306b8	enp0s31f6	0	0	2026-01-24 22:51:34.508298+00	0	0
2866d90f-0a84-4afc-bce0-1d7c16f2aef3	wlx30169d2252f8	14310	13001	2026-01-24 22:51:34.515532+00	1892	1719
29ca4789-f246-44a6-b304-dbc3cb5a4cc0	enp0s31f6	0	0	2026-01-24 14:50:25.068702+00	0	0
81d9b29a-a7d1-43da-a03d-8a11e17b1e97	wlx30169d2252f8	101085	58522	2026-01-24 14:50:25.076143+00	3367	1949
a2d684e0-aa0b-45e8-98fb-3b8ab6ada97e	enp0s31f6	0	0	2026-01-24 17:45:58.324169+00	0	0
c6be01f4-2585-4428-b1f1-f6ad3fb8cded	wlx30169d2252f8	412	126	2026-01-24 17:45:58.327819+00	460	140
3d028943-fc6b-4a7e-9805-c6e0bbc419bd	enp0s31f6	0	0	2026-01-24 19:56:30.894615+00	0	0
7fe52700-2250-49db-9d63-56b26b982be3	wlx30169d2252f8	5551	11478	2026-01-24 19:56:30.901916+00	1424	2945
ddbd6db2-7dab-412d-a75c-a1da9db9be81	enp0s31f6	0	0	2026-01-24 22:52:04.477883+00	0	0
1a85852d-79f6-4653-99bd-c7d5f34fe608	wlx30169d2252f8	15893	7850	2026-01-24 22:52:04.481421+00	5878	2903
a41dbcd3-9971-4903-b4a6-7e607596165e	enp0s31f6	0	0	2026-01-24 14:50:55.037917+00	0	0
f4450663-1bb2-494c-bbb0-b413c942da49	wlx30169d2252f8	284	224	2026-01-24 14:50:55.041791+00	1677	1322
37fb7741-8d72-4a09-990c-79a357a4815c	enp0s31f6	0	0	2026-01-24 17:46:28.375018+00	0	0
8cb7926b-932c-426f-a012-402fe9750c85	wlx30169d2252f8	3210	10602	2026-01-24 17:46:28.381954+00	2289	7560
92f6ccb9-6698-4761-8e18-6f117cab42f9	enp0s31f6	0	0	2026-01-24 19:57:00.863997+00	0	0
a3aac8a7-e3c0-43ca-a073-440ba3a715a7	wlx30169d2252f8	1141	723	2026-01-24 19:57:00.867591+00	743	471
b69a41dd-118e-481a-8b35-c64a0652c82d	enp0s31f6	0	0	2026-01-24 22:52:34.531903+00	0	0
1c5405ed-6d3b-443e-9ff9-f081c82f75ca	wlx30169d2252f8	16880	13860	2026-01-24 22:52:34.538929+00	2239	1839
5087557a-d29a-40ee-b970-131339a775b6	enp0s31f6	0	0	2026-01-24 14:51:25.050237+00	0	0
1bfe8ec2-99b1-4106-ba94-c12692508429	wlx30169d2252f8	81710	51542	2026-01-24 14:51:25.055198+00	2723	1717
69db2733-c005-481b-8cff-58425c8c39cc	enp0s31f6	0	0	2026-01-24 17:46:58.329451+00	0	0
2b6f3ac3-be67-4a32-bb1a-2d3ed5512f99	wlx30169d2252f8	678	350	2026-01-24 17:46:58.330905+00	732	378
123a9390-82c5-48e4-9cfc-f1bbe819f11d	enp0s31f6	0	0	2026-01-24 19:57:30.91667+00	0	0
e24b404f-1626-4b7d-8491-e82f0b63c2a8	wlx30169d2252f8	5943	12622	2026-01-24 19:57:30.92542+00	1471	3126
4b4edefb-1461-4317-929f-439c3e53fd6c	enp0s31f6	0	0	2026-01-24 22:53:04.498697+00	0	0
6f4d90da-fffd-4d5d-9a8d-dc6d9b44b4e4	wlx30169d2252f8	16221	7596	2026-01-24 22:53:04.504325+00	5995	2807
e42d330e-66fa-4f07-ba3f-92be499edbce	enp0s31f6	0	0	2026-01-24 14:51:55.05839+00	0	0
4d8ec421-7770-4c30-89f8-6e2b16974780	wlx30169d2252f8	42	142	2026-01-24 14:51:55.062345+00	222	752
942e3c3c-8f6d-407c-b56b-721f964ad7cd	enp0s31f6	0	0	2026-01-24 17:47:28.357004+00	0	0
90f0a4fc-37cc-4564-9d50-c6a8b82b22cc	wlx30169d2252f8	2592	9247	2026-01-24 17:47:28.359755+00	1842	6573
da4819a4-890e-413b-9fec-65f7a58381c5	enp0s31f6	0	0	2026-01-24 19:58:00.885923+00	0	0
fcab32b0-3570-46a6-b03e-b6f12b1db704	wlx30169d2252f8	981	939	2026-01-24 19:58:00.889786+00	637	610
26c3dcfc-21db-4260-8619-3b334c15ef5f	enp0s31f6	0	0	2026-01-24 22:53:34.532473+00	0	0
ea8f0c6f-513e-4fca-a6b6-0f1a16f8ccef	wlx30169d2252f8	15762	12581	2026-01-24 22:53:34.539432+00	2091	1669
6d8e91a7-66fd-4182-98b3-19260f74b17a	enp0s31f6	0	0	2026-01-24 14:52:25.11072+00	0	0
f2a477b2-6264-4a25-92d8-34f0813ff865	wlx30169d2252f8	81440	51082	2026-01-24 14:52:25.1182+00	2712	1701
1a724558-6de8-4a52-bc3e-24594d97f2d2	enp0s31f6	0	0	2026-01-24 17:47:58.351285+00	0	0
00bf849e-e1e1-41e7-a261-8d533e2d9732	wlx30169d2252f8	660	350	2026-01-24 17:47:58.355761+00	729	387
4341d186-6db9-4dd1-b91b-3bacb5ca5fef	enp0s31f6	0	0	2026-01-24 19:58:30.93738+00	0	0
51514a57-0ccc-47a4-b2af-24de991976ff	wlx30169d2252f8	6393	16342	2026-01-24 19:58:30.944743+00	1570	4014
36511efb-860d-48cc-a52c-6678509e4cd2	enp0s31f6	0	0	2026-01-24 22:54:04.504582+00	0	0
c5d92ae0-7e14-4761-b870-c67c6fd36bff	wlx30169d2252f8	19001	7976	2026-01-24 22:54:04.510175+00	7103	2981
08316d19-ec4c-41de-b124-323756ce7f30	enp0s31f6	0	0	2026-01-24 14:52:55.080629+00	0	0
3a4a3cdd-ee26-4dd7-bc49-0067dee1689a	wlx30169d2252f8	162	0	2026-01-24 14:52:55.084793+00	850	0
f7daa4f8-df3a-402a-90c7-7f63565c36b1	enp0s31f6	0	0	2026-01-24 17:48:28.378509+00	0	0
f4860462-f566-4d15-a0d6-89c94396ecb4	wlx30169d2252f8	3336	10698	2026-01-24 17:48:28.380893+00	2292	7350
e62d8f70-7be0-45e6-bf33-8223297044cd	enp0s31f6	0	0	2026-01-24 19:59:00.909214+00	0	0
0a575fdd-7d47-41c8-b7d0-53b4141b439c	wlx30169d2252f8	1119	566	2026-01-24 19:59:00.914868+00	726	367
1352fc52-182d-442f-bf31-cb286b96550d	enp0s31f6	0	0	2026-01-24 22:54:34.557524+00	0	0
a7d55ad0-92e3-44ee-b0f4-b495c22aa7fd	wlx30169d2252f8	15180	11212	2026-01-24 22:54:34.566008+00	1995	1474
2b410434-6e68-4b94-b8db-0af9401bcc04	enp0s31f6	0	0	2026-01-24 14:53:25.093122+00	0	0
793dbcdb-ed36-4472-9391-87fa6470be21	wlx30169d2252f8	89523	53124	2026-01-24 14:53:25.096174+00	2983	1770
586c1cda-13f5-48de-b760-82c3fdb78e58	enp0s31f6	0	0	2026-01-24 17:48:58.385846+00	0	0
05714d9d-9864-443e-8318-320e27ea2f16	wlx30169d2252f8	832	444	2026-01-24 17:48:58.38999+00	897	478
72cb7b57-a363-4da2-9857-bfe79c81050e	enp0s31f6	0	0	2026-01-24 19:59:30.922342+00	0	0
9c584ab2-36df-4418-a7f4-f2140a0ef159	wlx30169d2252f8	11987	11467	2026-01-24 19:59:30.926123+00	3015	2885
545dae48-6ab8-43a0-a335-2acbc0723983	enp0s31f6	0	0	2026-01-24 22:55:04.514313+00	0	0
8310f271-a5da-4a03-ace0-3f0720294854	wlx30169d2252f8	16151	7862	2026-01-24 22:55:04.516511+00	6021	2930
f332d27c-aa5b-455a-841d-2512d7bc8299	enp0s31f6	0	0	2026-01-24 14:53:55.088141+00	0	0
33bcdd0e-f25a-4971-84f7-b0b419ac575e	wlx30169d2252f8	330	0	2026-01-24 14:53:55.091866+00	1591	0
f6184b0c-f947-4626-98fe-8f1770b59ae0	enp0s31f6	0	0	2026-01-24 17:49:28.437388+00	0	0
18c5eb65-4551-4779-8e73-3463d86280a8	wlx30169d2252f8	6046	10999	2026-01-24 17:49:28.444619+00	4178	7601
9c6c2e78-b4da-41f7-ad26-5efaae0890c1	enp0s31f6	0	0	2026-01-24 20:00:00.930067+00	0	0
040602d8-dc5a-4b85-beee-f4a56d66d34d	wlx30169d2252f8	1017	566	2026-01-24 20:00:00.933818+00	657	365
8b2c3e36-232c-4fb4-8efa-fed6bc2c9640	enp0s31f6	0	0	2026-01-24 22:55:34.578318+00	0	0
c13152e4-dcea-4b8b-b0e4-84514e8cb9ea	wlx30169d2252f8	17074	16383	2026-01-24 22:55:34.58376+00	2224	2134
7585b7d3-b87c-4c20-bffa-ce585e1f7bca	enp0s31f6	0	0	2026-01-24 14:54:25.152763+00	0	0
6b3d46e6-d69e-4e4e-8d17-81afbde4c035	wlx30169d2252f8	103902	51988	2026-01-24 14:54:25.161838+00	3459	1731
7e9a938f-8d65-40de-9a40-f141f8f7343f	enp0s31f6	0	0	2026-01-24 17:49:58.406113+00	0	0
77adef41-9cd0-4da6-9900-cf26d6a0efc5	wlx30169d2252f8	654	350	2026-01-24 17:49:58.411823+00	693	371
2c59e9b7-a215-4b19-ab79-66fe639ed9f3	enp0s31f6	0	0	2026-01-24 20:00:30.943522+00	0	0
70879414-5552-41ba-a57e-4c7aa12fa0e4	wlx30169d2252f8	5499	12612	2026-01-24 20:00:30.945923+00	1351	3099
01781aca-5729-4c2b-968f-184dc9788f46	enp0s31f6	0	0	2026-01-24 22:56:04.548711+00	0	0
808b1d5d-0397-4468-9ae5-984a3bcd6292	wlx30169d2252f8	22496	8214	2026-01-24 22:56:04.552382+00	8302	3031
46f38e80-8882-4649-b5ec-c85703242f16	enp0s31f6	0	0	2026-01-24 14:54:55.120826+00	0	0
de151a0e-05ca-4b34-9a85-b94bc736a986	wlx30169d2252f8	102	0	2026-01-24 14:54:55.12469+00	515	0
be57b193-d0dd-4202-8978-0c04a12d52cd	enp0s31f6	0	0	2026-01-24 17:50:28.419916+00	0	0
86f7ddea-ce2f-4d96-b76d-c1d632875f42	wlx30169d2252f8	4702	13978	2026-01-24 17:50:28.422164+00	3228	9598
bdc3e6d3-f403-49e3-9308-e2b1e350db51	enp0s31f6	0	0	2026-01-24 20:01:00.950525+00	0	0
12e35fbb-f76a-4c85-972a-c731733e55e4	wlx30169d2252f8	1119	566	2026-01-24 20:01:00.954356+00	722	365
eaa0b703-88a1-48d2-a846-545a96d4a3b4	enp0s31f6	0	0	2026-01-24 22:56:34.562086+00	0	0
59fec5ba-9b7b-4d3e-b6fd-2cf9e74f8a17	wlx30169d2252f8	23477	12752	2026-01-24 22:56:34.565787+00	3059	1661
a53d8cce-e429-4849-a73b-512cb8ade685	enp0s31f6	0	0	2026-01-24 14:55:25.173539+00	0	0
0ec5d5ed-97a7-4c79-8e9f-4d10695f3f05	wlx30169d2252f8	89449	51714	2026-01-24 14:55:25.181871+00	2979	1722
0f0d9c92-69b6-4a6e-9995-518a97a9d92e	enp0s31f6	0	0	2026-01-24 17:50:58.412231+00	0	0
983d3632-4fc9-4c82-a003-11101c138179	wlx30169d2252f8	354	350	2026-01-24 17:50:58.413626+00	382	377
f75d7d39-a02d-448d-acd3-7ca6c05cd590	enp0s31f6	0	0	2026-01-24 20:01:31.003341+00	0	0
532517e8-959c-486c-b201-a1c7abbbea75	wlx30169d2252f8	5469	12518	2026-01-24 20:01:31.010569+00	1334	3053
4678fed3-6381-46e1-8ff7-493d7f2e8a94	enp0s31f6	0	0	2026-01-24 22:57:04.572638+00	0	0
7958e497-600a-484f-aba1-481b4a069603	wlx30169d2252f8	37313	23665	2026-01-24 22:57:04.579447+00	13780	8740
1a7d5554-8493-4c0e-8112-2a3480636305	enp0s31f6	0	0	2026-01-24 14:55:55.142573+00	0	0
4ebe42f6-bb41-4533-a03f-7ea5b8587708	wlx30169d2252f8	60	0	2026-01-24 14:55:55.146584+00	299	0
90039195-d126-4aa5-886d-516c16f485a3	enp0s31f6	0	0	2026-01-24 17:51:28.482124+00	0	0
3d19e784-e42a-423d-ac32-6835469da08a	wlx30169d2252f8	4018	11661	2026-01-24 17:51:28.49049+00	2614	7588
efa9bd6f-c075-4e54-a35d-3752bdf4c476	enp0s31f6	0	0	2026-01-24 20:02:00.971628+00	0	0
f00ae06e-5af0-4126-9349-1ec1d41f913b	wlx30169d2252f8	999	566	2026-01-24 20:02:00.975335+00	628	356
23df8f49-38f0-48d8-8476-6c879dfcced8	enp0s31f6	0	0	2026-01-24 22:57:34.624384+00	0	0
f078919e-5eab-47d3-94d4-4a216bf97f24	wlx30169d2252f8	29657	13042	2026-01-24 22:57:34.632776+00	3838	1688
3f2c5880-291c-4618-821b-61206fd2cee0	enp0s31f6	0	0	2026-01-24 14:56:25.155056+00	0	0
b943edff-ef01-4d9d-8ce1-ad55ab7b464f	wlx30169d2252f8	89768	51860	2026-01-24 14:56:25.157437+00	2991	1728
bc865a22-c6ae-445c-9e52-6a029d427343	enp0s31f6	0	0	2026-01-24 17:51:58.447724+00	0	0
862d0f5a-3744-4c62-8dde-8551db44fb8c	wlx30169d2252f8	534	350	2026-01-24 17:51:58.451481+00	555	364
7a885fd5-8d7e-40c8-aba7-f9dbfca94c19	enp0s31f6	0	0	2026-01-24 20:02:31.024069+00	0	0
b7233ddd-c9bc-452a-a01f-dca54dc313a9	wlx30169d2252f8	6111	15342	2026-01-24 20:02:31.032373+00	1498	3761
9e78ce1f-bb9e-46e1-b667-82eb343016ba	enp0s31f6	0	0	2026-01-24 22:58:04.594955+00	0	0
13265b25-1d9d-447a-9ef3-a4eca0d1e098	wlx30169d2252f8	37413	23866	2026-01-24 22:58:04.600865+00	13690	8732
5cafd024-1fa5-43a8-b532-0a65b4e2b578	enp0s31f6	0	0	2026-01-24 14:56:55.16279+00	0	0
f48f1f86-9aab-4e90-9113-91633cf3cbd5	wlx30169d2252f8	180	0	2026-01-24 14:56:55.166682+00	849	0
464e01c0-818c-4209-9fd7-198d7bef18a4	enp0s31f6	0	0	2026-01-24 17:52:28.501899+00	0	0
2e1e89e8-a158-4ef8-8a74-1d019e0a0b80	wlx30169d2252f8	3090	10206	2026-01-24 17:52:28.509129+00	2071	6842
02ae3537-cb2c-43d7-9560-34cd6ff311ff	enp0s31f6	0	0	2026-01-24 20:03:00.994517+00	0	0
69153147-c627-4fab-9fa7-17d8ff435feb	wlx30169d2252f8	777	566	2026-01-24 20:03:00.99934+00	495	360
244b2a7f-63bc-4371-a488-84b2f1d1ddc7	enp0s31f6	0	0	2026-01-24 22:58:34.651594+00	0	0
37e13923-655e-419f-b57c-b14f1c1a2b0c	wlx30169d2252f8	28399	13567	2026-01-24 22:58:34.661997+00	3679	1757
10d38469-82b2-40b3-9cd6-3c30ea4f8d82	enp0s31f6	0	0	2026-01-24 14:57:25.216298+00	0	0
99cfc110-cd84-48ce-a78d-d5e275ee5c20	wlx30169d2252f8	81282	52060	2026-01-24 14:57:25.224081+00	2707	1734
9f568f2d-647c-4a77-b04a-08224583f2df	enp0s31f6	0	0	2026-01-24 17:52:58.468806+00	0	0
4f23891a-b8c5-41ee-a74b-37ade5f020e9	wlx30169d2252f8	474	350	2026-01-24 17:52:58.472954+00	504	372
2c6618d9-2f71-40de-b617-102f723acf64	enp0s31f6	0	0	2026-01-24 20:03:31.045898+00	0	0
27153273-919c-454f-a492-a65ed3e21cf6	wlx30169d2252f8	6012	12344	2026-01-24 20:03:31.053754+00	1456	2991
b4fdb40b-4710-4bff-885b-edcb0ea21d49	enp0s31f6	0	0	2026-01-24 22:59:04.617647+00	0	0
ce1d5a09-5627-41cf-a12b-a870600c423c	wlx30169d2252f8	37126	23363	2026-01-24 22:59:04.623497+00	13550	8527
adbc9fea-f11f-41bb-bcd6-d007a496d786	enp0s31f6	0	0	2026-01-24 14:57:55.182818+00	0	0
70b6344b-1459-4ef9-98eb-931511f7ea4c	wlx30169d2252f8	500	341	2026-01-24 14:57:55.186796+00	2203	1502
45cfb257-e61e-477b-910c-9dc4b44927b4	enp0s31f6	0	0	2026-01-24 17:53:28.52149+00	0	0
9a309847-dcc7-4b14-a1ce-15998346a4ee	wlx30169d2252f8	3520	10695	2026-01-24 17:53:28.528656+00	2308	7015
797508bf-466a-4434-9e43-4314e3c8f62d	enp0s31f6	0	0	2026-01-24 20:04:01.015879+00	0	0
d8ffd42c-2977-406d-8870-c0f630e4bba2	wlx30169d2252f8	1557	566	2026-01-24 20:04:01.01999+00	989	359
b001d8ae-7103-40d8-aae1-8a2d04ae6f5a	enp0s31f6	0	0	2026-01-24 22:59:34.631941+00	0	0
19828d6f-79ac-430f-942e-bf7b33f7a9d3	wlx30169d2252f8	21624	12858	2026-01-24 22:59:34.636219+00	2785	1656
8c7ed686-8c41-46ae-b696-7cdf34cbb377	enp0s31f6	0	0	2026-01-24 14:58:25.222676+00	0	0
b1f0140f-5e4e-48fa-a739-ad101e00ebab	wlx30169d2252f8	86428	55133	2026-01-24 14:58:25.230946+00	2880	1837
5c0bbfae-c0fd-4ae3-9ea8-4f80928ee024	enp0s31f6	0	0	2026-01-24 17:53:58.48571+00	0	0
82943557-ff87-4102-a02a-86f2fb8b09dc	wlx30169d2252f8	696	350	2026-01-24 17:53:58.487998+00	740	372
45bd6d0e-ac1c-44ee-a535-01a6d9663e35	enp0s31f6	0	0	2026-01-24 20:04:31.071688+00	0	0
e2a9f071-5934-4cc4-b7d6-b78161a4fb1b	wlx30169d2252f8	5236	10178	2026-01-24 20:04:31.078815+00	1264	2457
d529f7be-ec0b-4aa0-8d42-39fcca8436de	enp0s31f6	0	0	2026-01-24 23:00:04.641792+00	0	0
affeebfd-4a55-4cff-a7b4-9de347d99172	wlx30169d2252f8	37049	23711	2026-01-24 23:00:04.648708+00	13487	8631
a1aadec5-14b9-4576-be90-b4a8cb16bb5d	enp0s31f6	0	0	2026-01-24 14:58:55.187836+00	0	0
41420592-3f7b-49c5-9a72-6448a630f3f0	wlx30169d2252f8	180	818	2026-01-24 14:58:55.192756+00	807	3667
00acc284-d82c-45fa-9693-8c2b671ec1e9	enp0s31f6	0	0	2026-01-24 17:54:28.543525+00	0	0
7582951e-3fd6-4bf2-92e5-f787c058aada	wlx30169d2252f8	2970	9670	2026-01-24 17:54:28.551059+00	1901	6190
c590ce74-590a-4c68-84f3-51ad0063460d	enp0s31f6	0	0	2026-01-24 20:05:01.037639+00	0	0
58ab7070-532c-45f8-8f59-50a3ac75a10e	wlx30169d2252f8	1119	566	2026-01-24 20:05:01.041741+00	699	353
1a1c3d56-3ef6-4b1e-8592-b963a60d55a3	enp0s31f6	0	0	2026-01-24 23:00:34.688761+00	0	0
95d6df39-1777-4b58-9a43-4ec3cea4c841	wlx30169d2252f8	20772	13552	2026-01-24 23:00:34.69704+00	2675	1745
37b1f16e-2ddd-4cb3-846d-73328b5f5e0f	enp0s31f6	0	0	2026-01-24 14:59:25.239534+00	0	0
693d2204-4959-441d-89c0-5d42297cfa34	wlx30169d2252f8	94775	52325	2026-01-24 14:59:25.248573+00	3157	1742
841852b6-7e87-4c91-84ad-c3528cecb11f	enp0s31f6	0	0	2026-01-24 17:54:58.511731+00	0	0
a415c476-4764-4c9d-b141-1a87d64630a2	wlx30169d2252f8	654	350	2026-01-24 17:54:58.515447+00	685	366
9ba18e0f-2e57-4e09-b2a8-22de4daef73b	enp0s31f6	0	0	2026-01-24 20:05:31.088861+00	0	0
66a81775-3396-473e-866a-32aa64284239	wlx30169d2252f8	5662	11400	2026-01-24 20:05:31.09557+00	1354	2727
e0da4568-2259-44f5-b3cf-a48789d20cc1	enp0s31f6	0	0	2026-01-24 23:01:04.643093+00	0	0
3b4de7ba-6c04-434e-9ebf-e03dbe52d996	wlx30169d2252f8	41940	23793	2026-01-24 23:01:04.647895+00	15348	8707
31d4083d-412d-48d7-ac18-42f70d30ead2	enp0s31f6	0	0	2026-01-24 14:59:55.200092+00	0	0
fc915605-056a-4f5f-a21f-b968fae815d4	wlx30169d2252f8	120	0	2026-01-24 14:59:55.202602+00	603	0
8d963073-b928-4d05-9353-99965c05aca6	enp0s31f6	0	0	2026-01-24 17:55:28.563744+00	0	0
a6221eb8-940d-49b9-a2c2-12c97277e9bf	wlx30169d2252f8	3228	10604	2026-01-24 17:55:28.571155+00	1949	6404
755ae4ba-d9ff-4d97-962f-64984bdda775	enp0s31f6	0	0	2026-01-24 20:06:01.043207+00	0	0
f06cdaf6-8471-47cb-b6e7-485dbc595641	wlx30169d2252f8	1893	566	2026-01-24 20:06:01.046273+00	1195	357
a936d574-247e-4824-8549-8549c2071500	enp0s31f6	0	0	2026-01-24 23:01:34.712323+00	0	0
04d35855-5b77-4b2b-b422-6ff800898d6f	wlx30169d2252f8	20204	14085	2026-01-24 23:01:34.719978+00	2582	1800
a25f9459-888d-4742-a20f-b81b95eb2295	enp0s31f6	0	0	2026-01-24 15:00:25.259342+00	0	0
702cceed-2dcd-4357-8354-c40959cb83f1	wlx30169d2252f8	87997	53878	2026-01-24 15:00:25.268202+00	2930	1794
ca0f5b7b-06ea-4cfc-94cc-31c252bb38b4	enp0s31f6	0	0	2026-01-24 17:55:58.532614+00	0	0
de202058-a99a-4acc-bb02-5ce13b1124f6	wlx30169d2252f8	594	350	2026-01-24 17:55:58.536318+00	618	364
08183e03-9ffc-4f8c-b6c9-4498bcc9c47d	enp0s31f6	0	0	2026-01-24 20:06:31.108724+00	0	0
fa919b74-be9c-4a40-9968-ae2fff8878da	wlx30169d2252f8	5490	12454	2026-01-24 20:06:31.112838+00	1347	3057
fb796ed7-e37a-4a94-af49-a5229d416faa	enp0s31f6	0	0	2026-01-24 23:02:04.680873+00	0	0
f9b29005-6e5b-40fe-8f8f-859f19cd72fc	wlx30169d2252f8	37187	23759	2026-01-24 23:02:04.686042+00	13467	8604
4ec6dfac-7d8b-4740-88d2-03c276760f68	enp0s31f6	0	0	2026-01-24 15:00:55.227581+00	0	0
c46a5a24-4b59-4152-9162-86f135042c62	wlx30169d2252f8	0	0	2026-01-24 15:00:55.233513+00	0	0
4334935d-6731-4d34-a4ca-deb5b609db49	enp0s31f6	0	0	2026-01-24 17:56:28.564202+00	0	0
edbe8527-b4f9-471f-a856-538065f1c826	wlx30169d2252f8	5224	10524	2026-01-24 17:56:28.569065+00	3087	6220
fa9209fb-f31e-4cdc-96ab-9a40334714f9	enp0s31f6	0	0	2026-01-24 20:07:01.064398+00	0	0
7df9d7b6-ecac-4048-8438-48e34fc78e57	wlx30169d2252f8	939	566	2026-01-24 20:07:01.065932+00	593	357
1020516e-6731-46b4-9231-e3dae8e1a675	enp0s31f6	0	0	2026-01-24 23:02:34.695905+00	0	0
ad03e141-0202-4034-810c-2eefd774a34e	wlx30169d2252f8	21248	12282	2026-01-24 23:02:34.699775+00	2731	1578
6e5c70a1-d2a4-4d56-ad54-873ca6b679f5	enp0s31f6	0	0	2026-01-24 15:01:25.241376+00	0	0
20076484-62c2-42f6-b30c-78396df6f0a3	wlx30169d2252f8	96506	52978	2026-01-24 15:01:25.245639+00	3215	1765
dce0fa4d-ab25-4cc2-8c0c-907fa31af54b	enp0s31f6	0	0	2026-01-24 17:56:58.533797+00	0	0
473cf308-86d8-400a-9fb5-c7189edcc35f	wlx30169d2252f8	738	350	2026-01-24 17:56:58.537359+00	775	367
f693bc32-3dd0-4b85-8d4d-088d5388d493	enp0s31f6	0	0	2026-01-24 20:07:31.101398+00	0	0
22ab5601-1c96-4eb7-9621-1dc6d239a867	wlx30169d2252f8	6526	12909	2026-01-24 20:07:31.10402+00	1541	3049
8e1fdd12-108f-473c-98d8-851623e64aca	enp0s31f6	0	0	2026-01-24 23:03:04.689167+00	0	0
fb34535e-6170-451a-a807-d711d37e26ee	wlx30169d2252f8	37508	23747	2026-01-24 23:03:04.692102+00	13612	8618
2caf1a4c-fabb-4cac-9b61-dc1f02c4430a	enp0s31f6	0	0	2026-01-24 15:01:55.24831+00	0	0
ea1ebea5-b0ce-4152-ade0-75c28f2c08c5	wlx30169d2252f8	412	0	2026-01-24 15:01:55.252348+00	1683	0
fbb905f9-2381-445b-bd09-01ba4ddb80d9	enp0s31f6	0	0	2026-01-24 17:57:28.546738+00	0	0
714191cf-a6f9-4b72-a54b-094d53a52eb8	wlx30169d2252f8	5373	13766	2026-01-24 17:57:28.550465+00	3296	8445
edd83ac0-500f-485d-acac-c9a05081c909	enp0s31f6	0	0	2026-01-24 20:08:01.101226+00	0	0
2e231549-9570-4874-b548-3d0df337c8a6	wlx30169d2252f8	879	566	2026-01-24 20:08:01.106878+00	542	349
2c2bfeac-5c98-43cd-abd8-72c2cccf6339	enp0s31f6	0	0	2026-01-24 23:03:34.746001+00	0	0
e181adef-db22-467f-b3b3-c7cc1410e3a7	wlx30169d2252f8	20506	12181	2026-01-24 23:03:34.750846+00	2623	1558
0cb8dd55-5eb3-4a51-9a71-7bbaeb4e64a8	enp0s31f6	0	0	2026-01-24 15:02:25.300361+00	0	0
2911efdc-9431-42bc-b897-89a594c8ba8d	wlx30169d2252f8	90465	52608	2026-01-24 15:02:25.30822+00	3013	1752
e58d5ade-d68c-4b6d-99ba-78a3ef2df9ae	enp0s31f6	0	0	2026-01-24 17:57:58.556355+00	0	0
2af427a6-d048-4849-a554-98ddebc5dd1c	wlx30169d2252f8	594	350	2026-01-24 17:57:58.562089+00	616	363
c3900249-36f6-4325-89cb-84b1998621ac	enp0s31f6	0	0	2026-01-24 20:08:31.153076+00	0	0
c872f7a1-cb7e-493d-b3fa-fec57f820e9f	wlx30169d2252f8	5404	10527	2026-01-24 20:08:31.160374+00	1291	2516
96e843d5-0bc0-42af-8c34-0811d9841a5d	enp0s31f6	0	0	2026-01-24 23:04:04.726753+00	0	0
a968fe37-41ab-4095-80ef-72bf66b76341	wlx30169d2252f8	36545	23405	2026-01-24 23:04:04.732583+00	13182	8442
086d8503-8443-4805-8e24-0bb67eef28e5	enp0s31f6	0	0	2026-01-24 15:02:55.26824+00	0	0
45d04e6d-7338-4940-8021-03d2c82baec4	wlx30169d2252f8	1690	0	2026-01-24 15:02:55.272237+00	7498	0
2448c231-1e22-45ba-bbe7-31d17e6fdfa9	enp0s31f6	0	0	2026-01-24 17:58:28.603099+00	0	0
c5e1b6c8-a3dc-4f57-876b-73605460ba5d	wlx30169d2252f8	3216	9735	2026-01-24 17:58:28.611844+00	1967	5956
ab373a04-9be0-4e4b-805d-4e8d05cf6303	enp0s31f6	0	0	2026-01-24 20:09:01.108407+00	0	0
096ca1a3-33fc-4af7-946e-03e0b7fdd2b2	wlx30169d2252f8	939	566	2026-01-24 20:09:01.109918+00	586	353
7ebbe84f-c6c9-43fd-a256-4a193597d548	enp0s31f6	0	0	2026-01-24 23:04:34.776827+00	0	0
ee47913b-346f-4f1b-8448-2885bdc68bfb	wlx30169d2252f8	23016	13634	2026-01-24 23:04:34.783403+00	2952	1748
1b82cbbe-63ed-4d10-bc70-63f50f139676	enp0s31f6	0	0	2026-01-24 15:03:25.28108+00	0	0
cb40e516-df1d-4420-a421-3be4d69582dd	wlx30169d2252f8	87044	52199	2026-01-24 15:03:25.283491+00	2900	1739
e853ff71-7d53-4869-9597-f053a3a83aff	enp0s31f6	0	0	2026-01-24 17:58:58.569136+00	0	0
1b9056ed-56b8-46a9-87bf-5a77b8bbfb17	wlx30169d2252f8	642	444	2026-01-24 17:58:58.572705+00	661	457
f94ecd39-1239-457e-80c9-0db6929ece95	enp0s31f6	0	0	2026-01-24 20:09:31.143415+00	0	0
0d52d74f-09b3-481c-bff8-5156f0ad2392	wlx30169d2252f8	6270	14626	2026-01-24 20:09:31.147536+00	1487	3469
a84d86c7-43b9-41a8-9d84-7fae0ff96247	enp0s31f6	0	0	2026-01-24 23:05:04.74864+00	0	0
ac5e5437-6c3a-4ad7-a7ab-f7d926b9d505	wlx30169d2252f8	37233	23645	2026-01-24 23:05:04.754347+00	13401	8510
95253f39-abae-4ca8-bb49-2cf7ba331350	enp0s31f6	0	0	2026-01-24 15:03:55.295521+00	0	0
9e3ab62e-7183-46b8-9b13-caace0bd49c9	wlx30169d2252f8	102	0	2026-01-24 15:03:55.300119+00	428	0
2c4e9c7c-9386-474d-bc1a-132e972463c5	enp0s31f6	0	0	2026-01-24 17:59:28.589124+00	0	0
38278d37-c81e-48b9-9b19-9d13d08106a4	wlx30169d2252f8	5712	16455	2026-01-24 17:59:28.594178+00	3329	9590
78720af1-d833-4771-86f4-0cd707e0e571	enp0s31f6	0	0	2026-01-24 20:10:01.13028+00	0	0
db74ba7a-dc72-4939-b723-35458d878d3f	wlx30169d2252f8	1343	566	2026-01-24 20:10:01.131725+00	840	354
6cf9a4e8-e1e3-41d2-840a-3ed1055b1963	enp0s31f6	0	0	2026-01-24 23:05:34.797796+00	0	0
c03da5bb-4057-46c3-80a7-450f39d7b4df	wlx30169d2252f8	29647	13553	2026-01-24 23:05:34.806998+00	3788	1731
ae59127f-ef47-4567-a22b-83f385e8b6b9	enp0s31f6	0	0	2026-01-24 15:04:25.303246+00	0	0
eeaa4f98-2354-4a44-91db-aae3a6621f09	wlx30169d2252f8	81595	53633	2026-01-24 15:04:25.306002+00	2719	1787
3f890216-17f9-4e71-b5ac-fa1909682ba3	enp0s31f6	0	0	2026-01-24 17:59:58.58876+00	0	0
65ee3c09-495b-40bb-b82d-653b8a77eec7	wlx30169d2252f8	774	350	2026-01-24 17:59:58.593911+00	805	364
f745341f-eff2-49d5-a282-35ab8b7420c6	enp0s31f6	0	0	2026-01-24 20:10:31.158285+00	0	0
5147c1c6-848d-4648-b608-7b87d805aa17	wlx30169d2252f8	6446	11403	2026-01-24 20:10:31.162057+00	1526	2700
972b5463-fec8-43b8-90c9-d0bc8de65f5d	enp0s31f6	0	0	2026-01-24 23:06:04.770089+00	0	0
b1962068-c376-4ea2-8064-abcc352e5681	wlx30169d2252f8	37670	24025	2026-01-24 23:06:04.775278+00	13544	8638
f2574ae8-c093-4c2f-ac23-0c67df0024ef	enp0s31f6	0	0	2026-01-24 15:04:55.310009+00	0	0
40b6909b-a9cf-4511-82ff-5b214a45ff3a	wlx30169d2252f8	60	0	2026-01-24 15:04:55.313253+00	254	0
55d7d0a8-373c-4638-a2b7-0bbb50820497	enp0s31f6	0	0	2026-01-24 18:00:28.630179+00	0	0
6f278fd7-b9d2-428a-ac7f-9cf5b236fb2a	wlx30169d2252f8	5280	11794	2026-01-24 18:00:28.638884+00	3167	7076
d5c94089-de27-4478-854d-7819433700c3	enp0s31f6	0	0	2026-01-24 20:11:01.159025+00	0	0
67daa556-8008-415a-ba07-d9da64db91b1	wlx30169d2252f8	1017	566	2026-01-24 20:11:01.16059+00	629	350
91183042-7b60-467f-8342-e6ca303bf197	enp0s31f6	0	0	2026-01-24 23:06:34.820342+00	0	0
5923bced-60be-4ab1-b87b-0503ef90652f	wlx30169d2252f8	23016	16619	2026-01-24 23:06:34.829056+00	2933	2117
24eeea59-a50d-4ee0-b1d9-aca45e87a649	enp0s31f6	0	0	2026-01-24 15:05:25.356852+00	0	0
ea55addc-1c4d-4fe6-a617-8dc1218e3b0a	wlx30169d2252f8	81883	55472	2026-01-24 15:05:25.362838+00	2727	1847
232311ac-1bcc-40cf-9518-d6a07d16f0ab	enp0s31f6	0	0	2026-01-24 18:00:58.598682+00	0	0
62ee46e9-1709-402a-854d-6d45a8382785	wlx30169d2252f8	534	350	2026-01-24 18:00:58.602309+00	561	367
15319bb5-fb9e-4279-902b-e7c15833ec73	enp0s31f6	0	0	2026-01-24 20:11:31.202003+00	0	0
0e7126b2-c570-45c6-8c02-678296a7c82e	wlx30169d2252f8	6412	13553	2026-01-24 20:11:31.205236+00	1492	3155
9aeaac30-788b-45fe-9246-7782a01ec818	enp0s31f6	0	0	2026-01-24 23:07:04.776132+00	0	0
372d4451-59b0-40cd-b760-2d86adbbe529	wlx30169d2252f8	43730	41607	2026-01-24 23:07:04.779366+00	15705	14943
9a788c3f-6867-4bca-b3cc-5e59b574a29c	enp0s31f6	0	0	2026-01-24 15:05:55.329567+00	0	0
2f35c33f-670d-4f0f-b642-8ceb57f11c83	wlx30169d2252f8	360	0	2026-01-24 15:05:55.333705+00	1520	0
77c38b3b-3136-4262-b007-42062a4d9c81	enp0s31f6	0	0	2026-01-24 18:01:28.644182+00	0	0
4fa4d257-800c-433a-bb39-b439f0f1586e	wlx30169d2252f8	3894	11654	2026-01-24 18:01:28.650026+00	2304	6896
792cfe3b-594e-453f-bdc9-1850cea2dcb5	enp0s31f6	0	0	2026-01-24 20:12:01.182459+00	0	0
3fa334bd-89a7-4b3e-9cec-3bb859dcbb81	wlx30169d2252f8	1257	566	2026-01-24 20:12:01.186053+00	772	347
42ff3ab6-5ff2-4100-af0b-843ad2b9a414	enp0s31f6	0	0	2026-01-24 23:07:34.845588+00	0	0
706cf12d-7797-4eab-8cd2-1473edea0662	wlx30169d2252f8	21908	15915	2026-01-24 23:07:34.852852+00	2794	2029
1cd3d566-c9ff-40fb-9013-a4f8c52c43e0	enp0s31f6	0	0	2026-01-24 15:06:25.381601+00	0	0
77ea19be-ea2b-494f-8a53-84a7ee62fe06	wlx30169d2252f8	79268	52816	2026-01-24 15:06:25.391078+00	2640	1759
cb33f94d-7df5-4cf1-ad8e-08d45848e514	enp0s31f6	0	0	2026-01-24 18:01:58.61116+00	0	0
0a73bb0b-5189-43d5-a4bc-777055920241	wlx30169d2252f8	594	350	2026-01-24 18:01:58.613917+00	619	365
e029e4b8-85db-4f91-86b5-0f2380489afa	enp0s31f6	0	0	2026-01-24 20:12:31.234462+00	0	0
02dae266-4c6f-4a3e-834a-89c355f344af	wlx30169d2252f8	6914	13505	2026-01-24 20:12:31.241062+00	1622	3168
908bc36c-e4c1-495e-b63a-ddb321a5ba24	enp0s31f6	0	0	2026-01-24 23:08:04.799275+00	0	0
05fdbe7d-3883-45a2-a545-3006b8620cd8	wlx30169d2252f8	44381	23689	2026-01-24 23:08:04.802837+00	15895	8484
7c6b06c9-aa68-402a-ac14-8949a44ebde8	enp0s31f6	0	0	2026-01-24 15:06:55.349577+00	0	0
24039caf-10d4-4836-97f4-33a642dc2c63	wlx30169d2252f8	300	0	2026-01-24 15:06:55.353346+00	1176	0
9ec69c90-e4c3-444b-a8f0-fa7c447a601f	enp0s31f6	0	0	2026-01-24 18:02:28.656396+00	0	0
2d2379d0-5a91-4eef-b9e1-55f69f4bf99b	wlx30169d2252f8	4148	13322	2026-01-24 18:02:28.660019+00	2445	7852
c3d655b8-e8c2-4598-9ba8-2feb27615a77	enp0s31f6	0	0	2026-01-24 20:13:01.20324+00	0	0
652d9075-0938-4789-a202-7247579b1c11	wlx30169d2252f8	1339	656	2026-01-24 20:13:01.209446+00	820	402
e620566d-15b9-477f-81dc-19238ee1869c	enp0s31f6	0	0	2026-01-24 23:08:34.827711+00	0	0
df2758be-1414-43f3-8ae4-4122ba4de442	wlx30169d2252f8	16177	13874	2026-01-24 23:08:34.829895+00	2062	1768
0939a509-7014-4ea8-954f-2bd3f5309753	enp0s31f6	0	0	2026-01-24 15:07:25.401321+00	0	0
d56284dc-7c29-464c-b449-b2e78ab005ac	wlx30169d2252f8	82150	52593	2026-01-24 15:07:25.408431+00	2736	1751
b38fa312-49ad-47a2-974c-9ee51b3543bb	enp0s31f6	0	0	2026-01-24 18:02:58.641274+00	0	0
14abb198-07df-4090-be4e-762373f0decc	wlx30169d2252f8	594	350	2026-01-24 18:02:58.645631+00	611	360
de3a123c-12ef-4e34-aaaf-d2b0724a709c	enp0s31f6	0	0	2026-01-24 20:13:31.254689+00	0	0
403a0e06-266f-40a4-9846-d004b6b2d004	wlx30169d2252f8	15720	10660	2026-01-24 20:13:31.262092+00	3641	2469
dbef9d26-9608-4399-a827-e5feb8a6813d	enp0s31f6	0	0	2026-01-24 23:09:04.839259+00	0	0
ce6cace7-26fc-4edf-9d34-f3b3289cd871	wlx30169d2252f8	39961	23041	2026-01-24 23:09:04.843046+00	14209	8192
831c4b76-db55-4e34-bdb0-10ce8a0dcf48	enp0s31f6	0	0	2026-01-24 15:07:55.356405+00	0	0
a477c530-8bdc-49b6-8c8b-405c0963e030	wlx30169d2252f8	360	0	2026-01-24 15:07:55.358349+00	1444	0
4e16e5fd-b498-46ea-aa6f-2a5333c548dc	enp0s31f6	0	0	2026-01-24 18:03:28.655034+00	0	0
48792c82-0ccd-403e-aa80-705c5fcca738	wlx30169d2252f8	3614	11573	2026-01-24 18:03:28.657595+00	2156	6906
b29fba7f-e04c-43b8-89fc-5c0f10660d15	enp0s31f6	0	0	2026-01-24 20:14:01.227264+00	0	0
f8c4a761-a1cb-403c-9ddc-67384e4b5f5c	wlx30169d2252f8	1163	566	2026-01-24 20:14:01.230975+00	711	346
6d846f4e-2b5e-4b85-9607-c2d64573785e	enp0s31f6	0	0	2026-01-24 23:09:34.873997+00	0	0
4a3d90c9-7373-4b43-8c0f-69d11608bb86	wlx30169d2252f8	17367	17105	2026-01-24 23:09:34.882314+00	2164	2131
8c60e2f9-3e24-4323-b24e-c98074094600	enp0s31f6	0	0	2026-01-24 15:08:25.420691+00	0	0
89bb4305-cd86-436e-a245-caea794b90ab	wlx30169d2252f8	95252	55642	2026-01-24 15:08:25.429257+00	3171	1852
ab04dfa4-af73-480f-8f2b-b5a2b1458e27	enp0s31f6	0	0	2026-01-24 18:03:58.649182+00	0	0
83f0140b-1b5f-43bc-bb70-afc2f5baef80	wlx30169d2252f8	576	350	2026-01-24 18:03:58.650861+00	597	363
d36eb32e-0ee3-45d8-97b5-174a8df7f4d4	enp0s31f6	0	0	2026-01-24 20:14:31.266555+00	0	0
77b76872-9be3-44bb-8f6a-9a89c01c02e6	wlx30169d2252f8	15108	16784	2026-01-24 20:14:31.270231+00	3442	3823
0cb857b8-9cb3-4562-bcc8-4b2671b4072a	enp0s31f6	0	0	2026-01-24 23:10:04.844506+00	0	0
845ebb6a-0f50-4920-b7f4-fb7399dfdcb8	wlx30169d2252f8	32357	23527	2026-01-24 23:10:04.848364+00	11558	8404
c5380aab-06ec-497d-ae2d-90594576d983	enp0s31f6	0	0	2026-01-24 15:08:55.389456+00	0	0
39b10e73-03d7-4bcb-95f3-d61191ae4300	wlx30169d2252f8	0	0	2026-01-24 15:08:55.393443+00	0	0
cfba41b3-c7e7-4e07-9ab2-28bcd333996b	enp0s31f6	0	0	2026-01-24 18:04:28.701762+00	0	0
f22b5b7e-f8bc-4f8c-bb13-cb30228c99c8	wlx30169d2252f8	4574	9560	2026-01-24 18:04:28.705486+00	2786	5823
65fc68e3-87f3-44a1-9e35-7a3b4808b518	enp0s31f6	0	0	2026-01-24 20:15:01.239785+00	0	0
d0a34e56-94d9-49eb-bcbf-c74990fdef47	wlx30169d2252f8	2929	566	2026-01-24 20:15:01.243562+00	1784	344
a9ab4a33-7918-4cc7-9b7f-8717a823a5c9	enp0s31f6	0	0	2026-01-24 23:10:34.894077+00	0	0
37f77f94-445a-4960-9d4f-16593a5a32c6	wlx30169d2252f8	17019	16707	2026-01-24 23:10:34.903305+00	2116	2078
ff4c4207-1811-4d67-9e60-0a30d17cebb8	enp0s31f6	0	0	2026-01-24 15:09:25.437242+00	0	0
678e3070-c432-47a6-a67c-c98f932bc1f6	wlx30169d2252f8	87691	52157	2026-01-24 15:09:25.44608+00	2921	1737
8e1b4301-5bef-4105-b3b1-960ceae103da	enp0s31f6	0	0	2026-01-24 18:04:58.661277+00	0	0
1c11814b-11cd-4404-a998-d3982512c09f	wlx30169d2252f8	654	350	2026-01-24 18:04:58.664599+00	677	362
2b227669-726b-47be-8b02-9af56bc417c6	enp0s31f6	0	0	2026-01-24 20:15:31.296336+00	0	0
bf93fd61-d636-4c0e-a9ec-eda027b52da3	wlx30169d2252f8	6150	10896	2026-01-24 20:15:31.30376+00	1411	2501
0182570e-418d-4aae-8c4d-81082166cfed	enp0s31f6	0	0	2026-01-24 23:11:04.853221+00	0	0
3007f9c0-390a-4f22-8533-4edaf3f24221	wlx30169d2252f8	32734	24152	2026-01-24 23:11:04.85465+00	11718	8645
4d757770-1f38-4f8c-ba77-cba0a5b773fc	enp0s31f6	0	0	2026-01-24 15:09:55.399981+00	0	0
20725c25-df48-4b0d-b9dc-a4d95d5216ad	wlx30169d2252f8	60	0	2026-01-24 15:09:55.402135+00	222	0
796cf061-803e-406c-87fa-f3a4a9e565d9	enp0s31f6	0	0	2026-01-24 18:05:28.710414+00	0	0
20cba7b8-a30b-4d75-acfb-f951fe818c87	wlx30169d2252f8	3458	8644	2026-01-24 18:05:28.729238+00	2023	5057
9934faec-14c7-402a-b1cc-0157bced3d1d	enp0s31f6	0	0	2026-01-24 20:16:01.261812+00	0	0
77f11f9a-006c-4014-9747-a5c90c48f5f6	wlx30169d2252f8	1019	656	2026-01-24 20:16:01.265722+00	620	399
3ec645eb-017b-4ad2-ad1f-a46abb25eb1f	enp0s31f6	0	0	2026-01-24 23:11:34.886208+00	0	0
567e8285-a95d-4752-be36-a35f61ccbe04	wlx30169d2252f8	19007	13915	2026-01-24 23:11:34.890397+00	2381	1743
0010ef50-e1ff-4b9f-a958-5893020c81ad	enp0s31f6	0	0	2026-01-24 15:10:25.423441+00	0	0
7167c62c-81a9-4b72-b92e-2ab0c62f9e65	wlx30169d2252f8	97583	52253	2026-01-24 15:10:25.426337+00	3251	1741
1e8b0540-10f4-44c5-93df-e7c7d64277fc	enp0s31f6	0	0	2026-01-24 18:05:58.678467+00	0	0
b2eb51f5-d6b4-49e8-9772-ecf0daee9e65	wlx30169d2252f8	594	350	2026-01-24 18:05:58.684093+00	604	356
7019c7b0-767f-4712-a2bf-f4f4545e1e89	enp0s31f6	0	0	2026-01-24 20:16:31.315028+00	0	0
f427126c-5868-4641-8839-b7a33a9b8513	wlx30169d2252f8	8254	13497	2026-01-24 20:16:31.322016+00	1869	3057
36aa61df-f99a-4d76-8021-af9eb8d531f3	enp0s31f6	0	0	2026-01-24 23:12:04.888102+00	0	0
e25840dd-ad27-400e-8920-7ed72a0dc80b	wlx30169d2252f8	32885	24403	2026-01-24 23:12:04.890842+00	11655	8649
fee2bd5c-85dd-4708-a053-661db70fe261	enp0s31f6	0	0	2026-01-24 15:10:55.427512+00	0	0
ae16f643-1505-429d-bbea-521817939779	wlx30169d2252f8	262	0	2026-01-24 15:10:55.433364+00	1014	0
f688261b-0bf6-4961-b327-a1203d84c3ff	enp0s31f6	0	0	2026-01-24 18:06:28.715729+00	0	0
0ab88eb6-dd8a-4382-9b85-23ae8144bdd7	wlx30169d2252f8	4452	11425	2026-01-24 18:06:28.718788+00	2457	6307
9e752dae-bf5a-42a1-b516-7e4238988521	enp0s31f6	0	0	2026-01-24 20:17:01.28754+00	0	0
3d841001-162d-40ec-9543-99315cbad5d2	wlx30169d2252f8	2887	566	2026-01-24 20:17:01.293261+00	1733	339
6c7ba8a5-3612-49ee-a40e-731ed5c88cac	enp0s31f6	0	0	2026-01-24 23:12:34.907703+00	0	0
b2b39f0c-9ab7-4708-a5e3-7d15887ba412	wlx30169d2252f8	23730	13919	2026-01-24 23:12:34.911551+00	2953	1732
4cce88ef-5efa-41dd-9d16-17d1acbe6012	enp0s31f6	0	0	2026-01-24 15:11:25.446428+00	0	0
538695b4-f264-46fa-9491-eb7c986093c9	wlx30169d2252f8	90702	53167	2026-01-24 15:11:25.45407+00	3022	1771
57fa51a4-afd5-46de-aa43-746dac2c89b5	enp0s31f6	0	0	2026-01-24 18:06:58.684397+00	0	0
9f763aee-7c83-4ca9-bc49-10612a7bfa2b	wlx30169d2252f8	534	350	2026-01-24 18:06:58.686166+00	539	353
bb858dc6-0e8b-4585-9a54-8c80f14cc286	enp0s31f6	0	0	2026-01-24 20:17:31.337194+00	0	0
0a62ba03-50ae-4973-af48-f1a15ca0a2a7	wlx30169d2252f8	5294	7851	2026-01-24 20:17:31.344399+00	1207	1791
d9e8bec8-6cb3-4e1b-8c0e-b0e483340381	enp0s31f6	0	0	2026-01-24 23:13:04.911581+00	0	0
3bd601dc-9373-49f9-9cee-dfcc257fe61a	wlx30169d2252f8	33499	25466	2026-01-24 23:13:04.917547+00	11843	9003
3faf823b-8e68-4fbb-86b5-19eb1dce290c	enp0s31f6	0	0	2026-01-24 15:11:55.433408+00	0	0
0b5bb3b2-cd5c-4804-a83a-bba689eae9fc	wlx30169d2252f8	442	0	2026-01-24 15:11:55.436451+00	1546	0
a585ecf7-102d-4465-9b87-e9e6bd65ffc8	enp0s31f6	0	0	2026-01-24 18:07:28.741329+00	0	0
88c11ee5-e3f7-4791-bf7a-5e6c0f985dcd	wlx30169d2252f8	3638	10933	2026-01-24 18:07:28.744487+00	2124	6386
e7d58b42-1778-4364-ad89-157f98276594	enp0s31f6	0	0	2026-01-24 20:18:01.301158+00	0	0
d64492ff-5459-4e36-8e75-6d1f76c7dff2	wlx30169d2252f8	1393	566	2026-01-24 20:18:01.304983+00	837	340
1c45e624-e399-450c-92fe-6449a6135db4	enp0s31f6	0	0	2026-01-24 23:13:34.946872+00	0	0
3abe433a-eecc-4708-9972-17dc2045b8a5	wlx30169d2252f8	24698	14788	2026-01-24 23:13:34.956071+00	3066	1836
4cab4430-3065-4403-9d71-fd6528098cb3	enp0s31f6	0	0	2026-01-24 15:12:25.49989+00	0	0
5e8764c4-e478-4978-86df-a368737f066b	wlx30169d2252f8	78627	52246	2026-01-24 15:12:25.507575+00	2618	1739
f71accd5-b278-47fa-8978-e39b84e7b4d2	enp0s31f6	0	0	2026-01-24 18:07:58.719476+00	0	0
ff25f9d8-fdac-4b01-b2c1-069982695e06	wlx30169d2252f8	516	350	2026-01-24 18:07:58.723498+00	518	351
486c56ca-ca4b-44d4-8113-ea9b1fd39572	enp0s31f6	0	0	2026-01-24 20:18:31.318793+00	0	0
3bcb8d26-6f95-4cb4-aa25-87bb5488cbcd	wlx30169d2252f8	6452	11001	2026-01-24 20:18:31.322462+00	1474	2514
4d4d2592-a7da-4a98-abbc-c08f5eb50520	enp0s31f6	0	0	2026-01-24 23:14:04.917503+00	0	0
90b13d1d-da2f-4a12-9df6-327f4544c0bb	wlx30169d2252f8	33342	24589	2026-01-24 23:14:04.921289+00	11832	8726
f03e9993-7db0-469f-a433-20b66406c505	enp0s31f6	0	0	2026-01-24 15:12:55.470666+00	0	0
0c4f11c9-3fe6-49a1-a6bb-6e4e039f3699	wlx30169d2252f8	262	0	2026-01-24 15:12:55.47735+00	935	0
558b78fc-95cd-4e8d-9b24-6e90fd6f85a3	enp0s31f6	0	0	2026-01-24 18:08:28.771458+00	0	0
e87cd3bd-0046-4966-9492-aa1089ae9544	wlx30169d2252f8	3866	11015	2026-01-24 18:08:28.776652+00	2071	5901
eecd46b9-b19e-40b5-a768-aebc30f39310	enp0s31f6	0	0	2026-01-24 20:19:01.32734+00	0	0
0c3e8de0-efbc-46a1-b83f-548d9c4c4c49	wlx30169d2252f8	1459	738	2026-01-24 20:19:01.331063+00	874	442
d494af94-c193-4435-ac81-a7705692b840	enp0s31f6	0	0	2026-01-24 23:14:34.968914+00	0	0
39bf4518-82a3-4b38-8232-15a475be1313	wlx30169d2252f8	16429	13823	2026-01-24 23:14:34.977695+00	2043	1719
10a9d566-7ff9-412c-956a-54131d5b07f7	enp0s31f6	0	0	2026-01-24 15:13:25.518786+00	0	0
ce0b7450-f2c9-4a32-8877-a5536b91ae3e	wlx30169d2252f8	85621	56924	2026-01-24 15:13:25.525758+00	2852	1896
ffd31fd1-8240-4424-b184-953a59df45af	enp0s31f6	0	0	2026-01-24 18:08:58.738416+00	0	0
5aaddc56-e006-46a8-8611-b767b212b608	wlx30169d2252f8	600	350	2026-01-24 18:08:58.743295+00	587	342
0bdf230c-aa37-4db9-98da-932270bf10fe	enp0s31f6	0	0	2026-01-24 20:19:31.37942+00	0	0
f8e06ef3-c876-461a-93e0-192d65c1a22c	wlx30169d2252f8	5866	12007	2026-01-24 20:19:31.386511+00	1331	2725
b6a041e1-a972-4461-ab19-ce58e34521d4	enp0s31f6	0	0	2026-01-24 23:15:04.938642+00	0	0
e90e4b37-1aec-4f6f-a8bc-b26b0e6ff586	wlx30169d2252f8	33020	24355	2026-01-24 23:15:04.942336+00	11705	8633
ec2c53a2-2fd4-4bed-8716-e9f2dc8e2bfa	enp0s31f6	0	0	2026-01-24 15:13:55.490443+00	0	0
a06ef505-806b-4f85-a176-3c30894b7b42	wlx30169d2252f8	484	0	2026-01-24 15:13:55.494415+00	1725	0
ac0e9a63-996e-4437-bf5b-26d0caf5a44f	enp0s31f6	0	0	2026-01-24 18:09:28.778956+00	0	0
01bce04c-c85b-4088-b861-b2c9b06ea57d	wlx30169d2252f8	4324	9771	2026-01-24 18:09:28.787611+00	2318	5239
73562c5c-680a-48d4-a365-f20ad9a2686c	enp0s31f6	0	0	2026-01-24 20:20:01.348623+00	0	0
a2f3de37-b812-440c-9370-3eed832e7cbf	wlx30169d2252f8	1525	432	2026-01-24 20:20:01.352448+00	906	256
c0d12279-f110-4a89-b701-c1c4afd89738	enp0s31f6	0	0	2026-01-24 23:15:34.962177+00	0	0
94cb1337-fc7c-45f3-a93b-9ac17f37e339	wlx30169d2252f8	18495	13822	2026-01-24 23:15:34.965766+00	2297	1717
267f1ce1-2570-4931-b99a-14adfc8244b8	enp0s31f6	0	0	2026-01-24 15:14:25.543286+00	0	0
b79bbf74-0524-4104-ad77-6979aaca64bd	wlx30169d2252f8	82705	52182	2026-01-24 15:14:25.550883+00	2754	1738
61519dbb-37c0-4205-ad5f-084cd7a6309f	enp0s31f6	0	0	2026-01-24 18:09:58.735738+00	0	0
a6b68ecf-33fe-4fdb-b515-fed2f6a39706	wlx30169d2252f8	594	350	2026-01-24 18:09:58.737714+00	608	358
b7220d93-62d9-43a4-8a12-1b10db684bb7	enp0s31f6	0	0	2026-01-24 20:20:31.363685+00	0	0
88c4d5c7-f9d5-40a8-9b0e-25a11ac813d4	wlx30169d2252f8	6536	11493	2026-01-24 20:20:31.367683+00	1480	2602
ed885fb4-0d40-4f45-904d-ccb1c27944d8	enp0s31f6	0	0	2026-01-24 23:16:04.961406+00	0	0
b685c9b0-2c13-4974-9eb3-d49e80e32972	wlx30169d2252f8	22958	8196	2026-01-24 23:16:04.966554+00	8124	2900
e02aaf10-4e1f-4870-a462-d8754d755707	enp0s31f6	0	0	2026-01-24 15:14:55.511895+00	0	0
ee696894-3f28-4643-8750-85d6f5a8c56f	wlx30169d2252f8	442	0	2026-01-24 15:14:55.51593+00	1579	0
b57a7626-a8d3-4a48-952f-4dd836f465b4	enp0s31f6	0	0	2026-01-24 18:10:28.791123+00	0	0
0c64ba7a-8aca-432d-b75d-0ee7f6e8b203	wlx30169d2252f8	3858	9788	2026-01-24 18:10:28.798261+00	2085	5289
9f51de8b-7c28-4751-bcc0-e6b289baadb8	enp0s31f6	0	0	2026-01-24 20:21:01.370703+00	0	0
1285c437-6e8e-43a6-a156-4ce965eeff0e	wlx30169d2252f8	1197	432	2026-01-24 20:21:01.374394+00	714	257
0d4f6c64-0d58-41d3-8f88-8aa9ca52846f	enp0s31f6	0	0	2026-01-24 23:16:34.9755+00	0	0
09821029-c173-4dc1-bec5-77bc9fcaab7e	wlx30169d2252f8	10145	12594	2026-01-24 23:16:34.978246+00	1257	1560
01d1c215-b702-4d12-a763-5545af845b3d	enp0s31f6	0	0	2026-01-24 15:15:25.563664+00	0	0
e4933cbe-f419-4dea-9d5f-c10983f395e9	wlx30169d2252f8	102351	51104	2026-01-24 15:15:25.572784+00	3409	1702
7419d42a-825a-4c38-b5b8-c1d63e0f4480	enp0s31f6	0	0	2026-01-24 18:10:58.75825+00	0	0
a0a190c5-2615-4d6d-aa8f-5b1527d705f2	wlx30169d2252f8	636	350	2026-01-24 18:10:58.762175+00	648	357
833aa51d-121c-4ab2-a92b-d6ae705ed0f2	enp0s31f6	0	0	2026-01-24 20:21:31.42295+00	0	0
bd83cb15-fe6e-4301-89c8-e15d4d75610d	wlx30169d2252f8	6780	11577	2026-01-24 20:21:31.430418+00	1509	2578
2568140a-40ea-41da-9efe-81cbe8778ccd	enp0s31f6	0	0	2026-01-24 23:17:04.983741+00	0	0
cd42e7a9-230e-4fa8-b55d-9c9682ff00a7	wlx30169d2252f8	28992	24830	2026-01-24 23:17:04.985808+00	10204	8739
19870fa6-6db4-49ee-9cb5-56ceb4e186f3	enp0s31f6	0	0	2026-01-24 15:15:55.543479+00	0	0
fc33b7cf-2b6a-4387-a502-d3e3cdbc5722	wlx30169d2252f8	262	0	2026-01-24 15:15:55.550386+00	897	0
c3f97e20-2d1b-4ef8-bbc3-17e2d8a9d7ba	enp0s31f6	0	0	2026-01-24 18:11:28.806373+00	0	0
937ddea7-f457-4cee-b818-8c6dfba051cb	wlx30169d2252f8	5222	9871	2026-01-24 18:11:28.811015+00	2791	5275
9e9c8102-c95e-4d52-8845-666488f954b7	enp0s31f6	0	0	2026-01-24 20:22:01.391839+00	0	0
436a2bac-946e-492c-90fb-dd94381b4051	wlx30169d2252f8	2325	1170	2026-01-24 20:22:01.395406+00	1375	692
386a7d4c-70c0-452b-adc6-855f7f7bf8b4	enp0s31f6	0	0	2026-01-24 23:17:34.997263+00	0	0
8943c13c-20d6-42e9-81ce-c798fa0d6c93	wlx30169d2252f8	11107	13872	2026-01-24 23:17:35.001627+00	1376	1719
b3c17c18-4a65-47dd-8bfd-83090579a6ff	enp0s31f6	0	0	2026-01-24 15:16:25.582674+00	0	0
809a1096-850f-4358-ba2f-dcebfa64f0f1	wlx30169d2252f8	90254	51906	2026-01-24 15:16:25.5885+00	3007	1729
7942b3e3-f478-43dd-87e2-dd66859ef012	enp0s31f6	0	0	2026-01-24 18:11:58.779036+00	0	0
e9284bb1-0b57-4b3b-9a53-939d7301f728	wlx30169d2252f8	696	350	2026-01-24 18:11:58.784164+00	682	343
b08eac09-11dc-4115-9429-2928325bd847	enp0s31f6	0	0	2026-01-24 20:22:31.438409+00	0	0
9421236c-59f4-4ae6-93ea-3012b8d50e39	wlx30169d2252f8	6750	12539	2026-01-24 20:22:31.447094+00	1500	2786
3b6924ad-8a5e-4ed0-992c-28f401be958b	enp0s31f6	0	0	2026-01-24 23:18:05.006311+00	0	0
b8bd7db6-92e6-4191-8e1a-1a4a134161a5	wlx30169d2252f8	11454	8369	2026-01-24 23:18:05.01188+00	4024	2940
7cdee018-8ad6-42f6-a144-afec4dd045e2	enp0s31f6	0	0	2026-01-24 15:16:55.540374+00	0	0
4a5ec5fa-9696-45f4-b71d-a80ec07ee4dc	wlx30169d2252f8	0	0	2026-01-24 15:16:55.558202+00	0	0
d8b7e783-62a2-4d54-b50f-2a65f22b0b0e	enp0s31f6	0	0	2026-01-24 18:12:28.830947+00	0	0
293c736b-9ab0-42d5-981a-d51d1cb68239	wlx30169d2252f8	5087	10839	2026-01-24 18:12:28.837898+00	2703	5760
9ba6b0d8-0533-4338-8e81-0c4d33fd0554	enp0s31f6	0	0	2026-01-24 20:23:01.41068+00	0	0
f101ce6a-fc4e-4401-a1a5-95114af10d13	wlx30169d2252f8	993	424	2026-01-24 20:23:01.415886+00	586	250
a48822af-de54-4cb4-8b74-4dce2b38f458	enp0s31f6	0	0	2026-01-24 23:18:35.058201+00	0	0
3a91cb25-d122-4fbc-a6e0-ff1b41a99939	wlx30169d2252f8	20529	14927	2026-01-24 23:18:35.065467+00	2537	1845
1f562a9b-52a0-4913-8999-802d4caca951	enp0s31f6	0	0	2026-01-24 15:17:25.603552+00	0	0
5a2abbf8-1b3a-4361-909c-331c585dca95	wlx30169d2252f8	88032	52167	2026-01-24 15:17:25.61191+00	2931	1737
c7ed36a9-68a8-4cd8-be4a-0e1d011eb5af	enp0s31f6	0	0	2026-01-24 18:12:58.792007+00	0	0
7f13f781-7506-4b95-91df-863f0e324075	wlx30169d2252f8	464	350	2026-01-24 18:12:58.79513+00	456	344
7434eb43-6703-4f29-8561-f80aa2280629	enp0s31f6	0	0	2026-01-24 20:23:31.460165+00	0	0
2dcccc6d-ff8a-42d9-8df8-ec460ea664a7	wlx30169d2252f8	6906	14319	2026-01-24 20:23:31.46694+00	1512	3136
26e78a57-ef86-4520-90ec-cd8f48e858c9	enp0s31f6	0	0	2026-01-24 23:19:05.028934+00	0	0
1b83c1f6-14a5-47b2-8446-985bfead16fe	wlx30169d2252f8	22259	21333	2026-01-24 23:19:05.034379+00	7800	7476
2bcbd2da-e233-4184-b126-58ae999b3268	enp0s31f6	0	0	2026-01-24 15:17:55.572985+00	0	0
fb1ce353-016d-48ce-9e08-db9788ea59c7	wlx30169d2252f8	164	224	2026-01-24 15:17:55.577001+00	523	714
cbe3087e-7920-4eb0-9a37-f148c7c3ee5f	enp0s31f6	0	0	2026-01-24 18:13:28.854089+00	0	0
baa1fbeb-8d89-43d3-878c-3dd2b48d8598	wlx30169d2252f8	4782	12705	2026-01-24 18:13:28.86135+00	2543	6758
5c76e5f0-5765-4310-9081-d21cfd847b95	enp0s31f6	0	0	2026-01-24 20:24:01.4296+00	0	0
fbba8976-8486-4939-8e7e-b20c84371825	wlx30169d2252f8	7859	424	2026-01-24 20:24:01.433427+00	4632	249
b76ce247-c2d1-41b0-be37-aea608bd6e7b	enp0s31f6	0	0	2026-01-24 23:19:35.044272+00	0	0
416d3bd8-0f8e-4ae8-9fd9-52557dcf218f	wlx30169d2252f8	14373	18148	2026-01-24 23:19:35.048319+00	1753	2214
b364d8d2-e68a-417d-a956-aac9f8ec9c04	enp0s31f6	0	0	2026-01-24 15:18:25.589267+00	0	0
377c4312-6e4f-4fb6-b536-ca84e966b8eb	wlx30169d2252f8	98453	56963	2026-01-24 15:18:25.593729+00	3280	1898
a57e0721-2769-4137-adb9-567abda8ada7	enp0s31f6	0	0	2026-01-24 18:13:58.8074+00	0	0
f1f1fe9e-c99e-4275-9217-475cc82020b0	wlx30169d2252f8	650	514	2026-01-24 18:13:58.808926+00	656	519
415a8843-d999-45bf-9a2d-f2949e5e78ab	enp0s31f6	0	0	2026-01-24 20:24:31.443269+00	0	0
4556986c-ff9e-4fa5-8e3c-26b5188b7817	wlx30169d2252f8	8030	13659	2026-01-24 20:24:31.445461+00	1774	3018
2dffa799-c136-4644-8ee9-5cd875d9b484	enp0s31f6	0	0	2026-01-24 23:20:05.051703+00	0	0
7ebbe16d-b2c9-4d26-9123-96e8929302a2	wlx30169d2252f8	21939	20760	2026-01-24 23:20:05.056977+00	7674	7262
dd167ba9-7957-4779-b7c4-2968f6ce6b62	enp0s31f6	0	0	2026-01-24 15:18:55.59408+00	0	0
b7b67e50-7091-4c8a-9506-3a6edefae537	wlx30169d2252f8	294	224	2026-01-24 15:18:55.598046+00	856	652
cfca520c-e7bd-4c5d-8388-ad75b1d0d0b0	enp0s31f6	0	0	2026-01-24 18:14:28.836224+00	0	0
cbb6db13-026b-4116-9425-955d69515267	wlx30169d2252f8	4666	10836	2026-01-24 18:14:28.841951+00	2410	5598
53cb5040-dff3-4d45-8853-2eceaa061810	enp0s31f6	0	0	2026-01-24 20:25:01.443875+00	0	0
62642719-77fc-453e-af39-da6daf5762a0	wlx30169d2252f8	1293	424	2026-01-24 20:25:01.445378+00	757	248
286d7955-d004-4085-b127-1a0e63aeefa5	enp0s31f6	0	0	2026-01-24 23:20:35.065679+00	0	0
50e056a5-784d-40ff-96fd-ce40742591c2	wlx30169d2252f8	19544	17618	2026-01-24 23:20:35.069834+00	2393	2157
ee460801-3db0-4535-87b0-a843d7885239	enp0s31f6	0	0	2026-01-24 15:19:25.646639+00	0	0
2df0ab99-6963-408c-b0ca-df93cfec77cc	wlx30169d2252f8	82556	53257	2026-01-24 15:19:25.656087+00	2749	1773
56de4bfa-5823-4b99-bbf7-a33b338b7f87	enp0s31f6	0	0	2026-01-24 18:14:58.842357+00	0	0
f0274854-3798-4df5-b1f6-0052a896aa57	wlx30169d2252f8	542	350	2026-01-24 18:14:58.84629+00	527	340
8225af76-b57f-471b-ab32-cc583c71b4bb	enp0s31f6	0	0	2026-01-24 20:25:31.504392+00	0	0
f7b2c010-8939-4c9c-8273-0e0f75122b1a	wlx30169d2252f8	11347	10518	2026-01-24 20:25:31.511566+00	2473	2292
b2110ba1-df30-4fb4-859c-16172fcb0a5c	enp0s31f6	0	0	2026-01-24 23:21:05.074755+00	0	0
98b25f2c-5774-40d2-84d6-e1028e7208c2	wlx30169d2252f8	21248	20785	2026-01-24 23:21:05.080325+00	7420	7259
1d0909e7-6532-4b3c-9867-82fc15a8ec22	enp0s31f6	0	0	2026-01-24 15:19:55.614211+00	0	0
84faeec9-65de-44ab-9b31-22b73e700b33	wlx30169d2252f8	474	224	2026-01-24 15:19:55.618148+00	1358	641
ec204242-8712-4d18-94a5-688fc1f11b47	enp0s31f6	0	0	2026-01-24 18:15:28.895195+00	0	0
3da7249d-487a-459d-9a4c-f350a3e105c5	wlx30169d2252f8	4178	9868	2026-01-24 18:15:28.902498+00	2168	5120
815632bd-1a42-4a06-8e4b-4e0b437a5865	enp0s31f6	0	0	2026-01-24 20:26:01.474213+00	0	0
58bb889e-0b6a-4bf9-843e-40154b67ae3b	wlx30169d2252f8	1465	506	2026-01-24 20:26:01.478321+00	853	294
6e3e2be0-3022-466f-98be-3e2b5ef0cac5	enp0s31f6	0	0	2026-01-24 23:21:35.127504+00	0	0
684987b5-1216-4da7-bf31-f92551850e5a	wlx30169d2252f8	13078	15559	2026-01-24 23:21:35.13454+00	1574	1873
078a438e-4f42-4e09-89a2-0c9839537be0	enp0s31f6	0	0	2026-01-24 15:20:25.665549+00	0	0
174149ff-a523-497b-84e7-9a48257f94ba	wlx30169d2252f8	78659	51463	2026-01-24 15:20:25.672565+00	2620	1714
b1e2d50b-8bc6-4dee-b409-eea12bbf73a3	enp0s31f6	0	0	2026-01-24 18:15:58.864263+00	0	0
4ceb74d4-1b0f-42dd-a393-5fce120f839c	wlx30169d2252f8	542	350	2026-01-24 18:15:58.869792+00	525	339
3a984ab8-793c-4841-82a2-fd81d808611e	enp0s31f6	0	0	2026-01-24 20:26:31.52899+00	0	0
87f73986-cdf3-4e7b-b297-bbe3c51254d5	wlx30169d2252f8	12783	15023	2026-01-24 20:26:31.536201+00	2782	3269
48012565-8558-4a78-9320-603d1016dd03	enp0s31f6	0	0	2026-01-24 23:22:05.096635+00	0	0
98fea416-a030-4067-96a7-3585010bc8a0	wlx30169d2252f8	21474	20302	2026-01-24 23:22:05.100418+00	7460	7053
9e5c2d4c-33a7-425c-a0c6-48963711275e	enp0s31f6	0	0	2026-01-24 15:20:55.621444+00	0	0
c5cc8c2e-c419-4233-ae49-1f9832f559b4	wlx30169d2252f8	294	224	2026-01-24 15:20:55.625711+00	870	663
de532018-d53f-4e90-bfdc-5a8b8a14246e	enp0s31f6	0	0	2026-01-24 18:16:28.901608+00	0	0
89b58b05-184a-4cec-9278-34190acaabe0	wlx30169d2252f8	5597	10869	2026-01-24 18:16:28.908019+00	2958	5744
e9e81207-38f2-4d34-935d-d27e7f0b4a9c	enp0s31f6	0	0	2026-01-24 20:27:01.494763+00	0	0
44472f97-a0b4-414f-8a50-bffcce418a23	wlx30169d2252f8	1521	506	2026-01-24 20:27:01.498015+00	868	288
a69b341a-f8e2-47ff-93c6-b9571bceedec	enp0s31f6	0	0	2026-01-24 23:22:35.142553+00	0	0
40ae00a0-c295-4e7b-bc3e-78e66a4d675a	wlx30169d2252f8	11247	13066	2026-01-24 23:22:35.151511+00	1360	1580
56f0c9cb-bfa7-48b5-917f-02bbcfad3d2a	enp0s31f6	0	0	2026-01-24 15:21:25.686717+00	0	0
5832c7fe-a21e-481c-a339-08e279fa46cd	wlx30169d2252f8	79509	51958	2026-01-24 15:21:25.694423+00	2647	1730
67586d79-277c-408d-8dc8-e59060b92954	enp0s31f6	0	0	2026-01-24 18:16:58.855657+00	0	0
89326bc5-b075-4074-96e6-59e73a1773b4	wlx30169d2252f8	842	444	2026-01-24 18:16:58.856868+00	845	445
30d9f522-ee92-4208-abdf-3b02a6f30a60	enp0s31f6	0	0	2026-01-24 20:27:31.514349+00	0	0
cdd30963-470d-4488-910c-579f0b760e46	wlx30169d2252f8	11493	11651	2026-01-24 20:27:31.516681+00	2491	2526
9578da20-a8ea-4c22-8bd7-404324a29380	enp0s31f6	0	0	2026-01-24 23:23:05.09898+00	0	0
44c6d1b2-06ed-4f1a-ae93-b8132ddffe9c	wlx30169d2252f8	21296	20557	2026-01-24 23:23:05.100573+00	7464	7205
2c0f24bb-a344-4f86-a2de-64dee8b01aee	enp0s31f6	0	0	2026-01-24 15:21:55.643057+00	0	0
0b77d8ba-cd13-4b9a-a35b-c4f31253517c	wlx30169d2252f8	174	224	2026-01-24 15:21:55.644633+00	523	673
64ecf511-3cde-403f-a4c4-7b468b06df42	enp0s31f6	0	0	2026-01-24 18:17:28.922524+00	0	0
bae2c7df-14cb-4adf-ae55-d8499782b4a3	wlx30169d2252f8	3581	10091	2026-01-24 18:17:28.931086+00	1824	5142
5b7bddc2-582e-4d4c-bf4b-ae348e218818	enp0s31f6	0	0	2026-01-24 20:28:01.499989+00	0	0
ee109049-7747-4783-b3d8-de152befe3cf	wlx30169d2252f8	1183	506	2026-01-24 20:28:01.503075+00	687	294
d64a2022-eefe-4b50-8f2b-e257efb139ff	enp0s31f6	0	0	2026-01-24 23:23:35.165553+00	0	0
6e0a014c-be96-4823-bbdc-cd75afc7209f	wlx30169d2252f8	12304	14190	2026-01-24 23:23:35.174474+00	1485	1713
e491cce7-ee2c-4e2a-85b0-b988f0851c8b	enp0s31f6	0	0	2026-01-24 15:22:25.707678+00	0	0
480abc46-4cae-48e3-8193-817143d7dc7c	wlx30169d2252f8	87828	51912	2026-01-24 15:22:25.715136+00	2924	1728
fb348625-1abe-4128-87a6-c13cd934d5e1	enp0s31f6	0	0	2026-01-24 18:17:58.87827+00	0	0
9ed265ef-dea5-4972-bc5d-080eb858c613	wlx30169d2252f8	1090	695	2026-01-24 18:17:58.880326+00	1075	685
a78a5ec2-4a4d-4fb8-931e-46988ce78958	enp0s31f6	0	0	2026-01-24 20:28:31.565844+00	0	0
61390494-0aeb-402e-a734-c45c74e23859	wlx30169d2252f8	12887	10291	2026-01-24 20:28:31.573214+00	2759	2203
0e5843ca-8474-4d9f-bc3b-107e9c5fabfd	enp0s31f6	0	0	2026-01-24 23:24:05.135761+00	0	0
e8b77621-6b26-43c9-aac0-4ea09491105f	wlx30169d2252f8	26915	20159	2026-01-24 23:24:05.141073+00	9305	6969
4d0fbd93-da72-4841-b12b-607297c68bcf	enp0s31f6	0	0	2026-01-24 15:22:55.677252+00	0	0
1b2073de-9776-43dc-8d02-84fd1e4abd0c	wlx30169d2252f8	414	224	2026-01-24 15:22:55.681304+00	1155	625
e42dcdcc-0ca0-4e2a-9a39-5cbcbf1aa175	enp0s31f6	0	0	2026-01-24 18:18:28.944058+00	0	0
180f0a63-688e-4b34-b010-417312f2295f	wlx30169d2252f8	4925	12924	2026-01-24 18:18:28.951371+00	2428	6373
d8c60bfd-6c85-45d5-bbcf-c0e5c1c58791	enp0s31f6	0	0	2026-01-24 20:29:01.535879+00	0	0
5188ef16-ee42-40d2-9211-ed4a9cdebb3a	wlx30169d2252f8	1381	502	2026-01-24 20:29:01.53967+00	783	284
b7107d3f-b65b-4415-82ac-451443fd0ff8	enp0s31f6	0	0	2026-01-24 23:24:35.150309+00	0	0
fe2eefae-ca2a-4bbc-b347-31fd2233ece0	wlx30169d2252f8	10544	15536	2026-01-24 23:24:35.152818+00	1272	1874
e58f4d9e-a5ff-409c-a8e4-72e2b0319a8a	enp0s31f6	0	0	2026-01-24 15:23:25.720542+00	0	0
b4b238a7-e79c-411c-8425-709bcb52135f	wlx30169d2252f8	88242	53328	2026-01-24 15:23:25.72399+00	2939	1776
71b21f37-adee-4464-8198-b41a3783fcda	enp0s31f6	0	0	2026-01-24 18:18:58.897212+00	0	0
97ab664d-7819-44b6-9fbc-6da27a45547a	wlx30169d2252f8	1114	1513	2026-01-24 18:18:58.898867+00	1112	1511
c0568cfd-ded8-4382-a1df-21b324cf6f60	enp0s31f6	0	0	2026-01-24 20:29:31.590164+00	0	0
0654b234-1d1f-40bd-b332-591641cc125d	wlx30169d2252f8	16764	12698	2026-01-24 20:29:31.596279+00	3568	2703
e3cbb8dd-a68b-4ec4-939b-81b52233da3d	enp0s31f6	0	0	2026-01-24 23:25:05.144153+00	0	0
899cd65e-3ce7-4bc8-949f-86f98ef39810	wlx30169d2252f8	21733	20453	2026-01-24 23:25:05.147202+00	7589	7142
41dddb59-363b-48db-ad49-998439d7e485	enp0s31f6	0	0	2026-01-24 15:23:55.697852+00	0	0
3e225261-ded0-4bef-a988-44710f945e41	wlx30169d2252f8	354	224	2026-01-24 15:23:55.701998+00	983	622
17f63277-e27d-4391-9428-425c710ae08b	enp0s31f6	0	0	2026-01-24 18:19:28.937945+00	0	0
c0978f79-dd43-4540-8c6f-feba8bec729b	wlx30169d2252f8	13054	11840	2026-01-24 18:19:28.940457+00	6422	5825
cd7272e0-e007-4d2f-9e97-a4c96131e1e0	enp0s31f6	0	0	2026-01-24 20:30:01.557615+00	0	0
5c193bfa-1544-4b23-8f6f-c303f2835124	wlx30169d2252f8	1445	548	2026-01-24 20:30:01.561469+00	826	313
6182fb51-d008-4ebb-9a9d-3d55ccc0d7c7	enp0s31f6	0	0	2026-01-24 23:25:35.211921+00	0	0
3d8b6407-909f-43ab-976f-b0c1718e7489	wlx30169d2252f8	11248	15075	2026-01-24 23:25:35.217611+00	1352	1812
9a80ef1a-f985-4bc9-acd4-3853e3fe30c4	enp0s31f6	0	0	2026-01-24 15:24:25.749451+00	0	0
24bc2169-062e-4613-87dd-55e398882f8b	wlx30169d2252f8	94173	53542	2026-01-24 15:24:25.774648+00	3137	1783
e4e0f413-a0d6-44ff-bf88-4b7623db6955	enp0s31f6	0	0	2026-01-24 18:19:58.933918+00	0	0
4c60e7af-8208-4916-b338-cf97a5e65f24	wlx30169d2252f8	2828	1607	2026-01-24 18:19:58.938706+00	2751	1563
f1585a25-57ee-4e6a-ae62-d919ac8f2009	enp0s31f6	0	0	2026-01-24 20:30:31.572264+00	0	0
d623e6e2-be0a-4074-955e-fc77729b2b1d	wlx30169d2252f8	17732	11652	2026-01-24 20:30:31.576177+00	3799	2496
b2a91af3-3c1b-4156-b060-4acf74dca3e1	enp0s31f6	0	0	2026-01-24 23:26:05.181427+00	0	0
39cc8908-52ab-4f8b-a10a-9daa4771f629	wlx30169d2252f8	21709	20093	2026-01-24 23:26:05.18726+00	7537	6976
d9790161-60c0-4b94-95eb-d7065fd962f4	enp0s31f6	0	0	2026-01-24 15:24:55.703758+00	0	0
be6736f9-e1b3-4a40-8fcb-816aafe73112	wlx30169d2252f8	234	224	2026-01-24 15:24:55.707442+00	660	632
10cb31dd-f57b-41f8-81a1-03d890826f43	enp0s31f6	0	0	2026-01-24 18:20:28.948505+00	0	0
d471231f-74ef-482b-b083-12a2ed815567	wlx30169d2252f8	4385	11449	2026-01-24 18:20:28.95107+00	2168	5660
a258b58c-91ff-48f2-99ce-106e8efac5f4	enp0s31f6	0	0	2026-01-24 20:31:01.579294+00	0	0
ee8b2841-8b11-4912-a580-0300dbe8c399	wlx30169d2252f8	1663	506	2026-01-24 20:31:01.583188+00	941	286
ac766afb-bd06-4239-8a6f-41894b1c1148	enp0s31f6	0	0	2026-01-24 23:26:35.234351+00	0	0
6ed5317e-9174-4c06-a3af-5774ded8109d	wlx30169d2252f8	12713	12527	2026-01-24 23:26:35.241455+00	1522	1499
716c83cf-9ce5-4811-a2e2-af9f07929128	enp0s31f6	0	0	2026-01-24 15:25:25.729765+00	0	0
08b8b384-eec8-4619-bd25-a172b51cc51f	wlx30169d2252f8	88812	54200	2026-01-24 15:25:25.73424+00	2958	1805
a0898c2f-537e-4914-a7fa-943c55756b27	enp0s31f6	0	0	2026-01-24 18:20:58.95929+00	0	0
5652f55e-eafa-4065-a9a6-f5126091d278	wlx30169d2252f8	874	1419	2026-01-24 18:20:58.962162+00	841	1367
b7910595-5ca0-4a9e-ae38-abdcb09515e4	enp0s31f6	0	0	2026-01-24 20:31:31.592807+00	0	0
b8f68205-d7f0-434b-bcd8-48acd7b102f6	wlx30169d2252f8	18240	13806	2026-01-24 20:31:31.595453+00	3843	2909
2e49f87a-ba8e-4484-8c06-ce54a915bc38	enp0s31f6	0	0	2026-01-24 23:27:05.189103+00	0	0
6d70ebe8-01b0-4340-8c25-5d8a56407666	wlx30169d2252f8	21170	21270	2026-01-24 23:27:05.192132+00	7280	7314
965cb10b-fec1-4f1c-9e5b-dbbe73d9d2a5	enp0s31f6	0	0	2026-01-24 15:25:55.72385+00	0	0
17b37c36-4e29-4be8-90f8-d319803bc911	wlx30169d2252f8	294	224	2026-01-24 15:25:55.727388+00	849	647
6b28983e-6fcd-4abe-8cb0-1474624dbcef	enp0s31f6	0	0	2026-01-24 18:21:28.995286+00	0	0
f9386685-9b07-4158-a647-dd4344faf73c	wlx30169d2252f8	4919	11446	2026-01-24 18:21:28.998478+00	2398	5580
f0fc8ed5-4107-4543-b2f6-ff9fca9da7c4	enp0s31f6	0	0	2026-01-24 20:32:01.600848+00	0	0
c7b48c1c-3f91-427f-a701-e89356744463	wlx30169d2252f8	3419	730	2026-01-24 20:32:01.604396+00	1934	412
13f5d285-aa99-4c90-9402-1351fae082f4	enp0s31f6	0	0	2026-01-24 23:27:35.249739+00	0	0
dd8c570d-f9a1-4f31-8d1a-44d567e237da	wlx30169d2252f8	18703	11566	2026-01-24 23:27:35.258107+00	2239	1384
8f6db17d-b338-4df2-b0c9-c6a6641b4dba	enp0s31f6	0	0	2026-01-24 15:26:25.761156+00	0	0
97c1d7b9-f0ba-46ac-ace7-60ece441b341	wlx30169d2252f8	90072	53119	2026-01-24 15:26:25.765417+00	3000	1769
d768dfe0-a703-4d1c-baf6-a35641d7de55	enp0s31f6	0	0	2026-01-24 18:21:58.975422+00	0	0
88430f96-66d8-41ed-b75a-d1e42532f5db	wlx30169d2252f8	602	1168	2026-01-24 18:21:58.978989+00	584	1133
1ddfb441-9282-430b-8816-12224c21891f	enp0s31f6	0	0	2026-01-24 20:32:31.655896+00	0	0
9eb918c6-fe5c-4565-b76d-ab737026a7a9	wlx30169d2252f8	16410	10522	2026-01-24 20:32:31.663209+00	3496	2242
64f69b1c-d99a-4a92-bd14-3cdaac3042eb	enp0s31f6	0	0	2026-01-24 23:28:05.219525+00	0	0
baba778e-f76d-49d2-8bf8-a56f1b3300d4	wlx30169d2252f8	27458	24138	2026-01-24 23:28:05.223239+00	9413	8275
03a34f27-29a2-4f6d-aa5b-76d4537fded3	enp0s31f6	0	0	2026-01-24 15:26:55.744042+00	0	0
5a019171-124c-4139-bbe5-22b4706f4c49	wlx30169d2252f8	234	224	2026-01-24 15:26:55.747321+00	622	596
29ff7037-949f-47d0-9c66-8f5bef2642c3	enp0s31f6	0	0	2026-01-24 18:22:29.02498+00	0	0
67c33b86-3852-4d4e-b447-a40ce7513bbe	wlx30169d2252f8	5359	14962	2026-01-24 18:22:29.029245+00	2543	7101
7bdd8511-9e0f-447c-a5cc-97edce92a0a4	enp0s31f6	0	0	2026-01-24 20:33:01.622465+00	0	0
e49fa3dc-5ace-4f8c-9660-eac56104bfc7	wlx30169d2252f8	3172	730	2026-01-24 20:33:01.62785+00	1773	408
b30b7565-198b-47df-8bf9-625be9ca6acf	enp0s31f6	0	0	2026-01-24 23:28:35.275397+00	0	0
3fd86dec-aba4-4f41-95f4-cfa92b203494	wlx30169d2252f8	12524	15235	2026-01-24 23:28:35.283342+00	1495	1819
9011ae31-61a5-488f-9efe-a0a7f1c20052	enp0s31f6	0	0	2026-01-24 15:27:25.776026+00	0	0
74632a85-9274-4092-9d49-a1728a840000	wlx30169d2252f8	80142	51696	2026-01-24 15:27:25.78059+00	2669	1721
924c6a31-9bef-4c08-89a6-1628028d9868	enp0s31f6	0	0	2026-01-24 18:22:58.979422+00	0	0
7e3a6413-a34a-4056-bec0-ac8e4bd597b9	wlx30169d2252f8	542	350	2026-01-24 18:22:58.981013+00	528	341
1e0c1f9c-54d9-41fc-b909-9ee5be97147f	enp0s31f6	0	0	2026-01-24 20:33:31.673459+00	0	0
f9558529-5d08-4e9d-8950-755a4f308d01	wlx30169d2252f8	17024	11734	2026-01-24 20:33:31.680608+00	3612	2489
6e1cf224-52a7-439c-be9a-6767258482a8	enp0s31f6	0	0	2026-01-24 23:29:05.243212+00	0	0
5d51994a-5dca-42b9-b95a-1b56a208e70d	wlx30169d2252f8	27719	24156	2026-01-24 23:29:05.247018+00	9487	8268
7009aa74-1917-4d24-b91f-ddc886046d7a	enp0s31f6	0	0	2026-01-24 15:27:55.763362+00	0	0
9c375ac5-f607-4926-8f9f-140593569abf	wlx30169d2252f8	234	224	2026-01-24 15:27:55.765162+00	616	590
35444b6f-0798-408b-873c-73600b890c73	enp0s31f6	0	0	2026-01-24 18:23:29.009648+00	0	0
f27bd563-0a64-4d7a-b40d-c0a890224e67	wlx30169d2252f8	4644	11187	2026-01-24 18:23:29.011914+00	2209	5322
aa30e2e8-da6f-465e-9711-2a518714e80f	enp0s31f6	0	0	2026-01-24 20:34:01.643582+00	0	0
315e5a5b-fd8d-455f-bca9-d9cb8249054d	wlx30169d2252f8	1645	730	2026-01-24 20:34:01.647716+00	925	410
9c6970b4-e42d-45eb-a25d-d9afb1815c39	enp0s31f6	0	0	2026-01-24 23:29:35.261343+00	0	0
e95f94d8-9653-47ce-8fca-f1df90791209	wlx30169d2252f8	11525	14841	2026-01-24 23:29:35.265415+00	1373	1768
a4b21152-7e42-4ff7-a301-6f93fd95d521	enp0s31f6	0	0	2026-01-24 15:28:25.829733+00	0	0
8cecaa8c-38d4-4182-9f63-f81f108541cc	wlx30169d2252f8	88164	57220	2026-01-24 15:28:25.83914+00	2935	1905
523fe209-b674-4e09-ab8b-0cc3a0bd7124	enp0s31f6	0	0	2026-01-24 18:23:59.01579+00	0	0
1115ebf5-2131-4ff3-97cd-2b3864c33965	wlx30169d2252f8	482	350	2026-01-24 18:23:59.021698+00	454	329
e8408a2f-f7b5-4eda-ba40-370043cf859a	enp0s31f6	0	0	2026-01-24 20:34:31.689338+00	0	0
ee8cdf30-b865-4209-9c05-00270633cd1d	wlx30169d2252f8	18856	15756	2026-01-24 20:34:31.696548+00	3977	3323
1ca0dddf-b460-450b-b749-1d0a2f3c65fa	enp0s31f6	0	0	2026-01-24 23:30:05.266091+00	0	0
f9d84c4e-9473-45d7-9446-251247233cdd	wlx30169d2252f8	27315	23779	2026-01-24 23:30:05.271889+00	9339	8130
30cb1c86-e4b8-483d-9010-eee22a3807e3	enp0s31f6	0	0	2026-01-24 15:28:55.79979+00	0	0
f0e5a841-c89b-401d-92a7-1851c6090180	wlx30169d2252f8	576	224	2026-01-24 15:28:55.805996+00	1568	609
13bb9d12-58db-4dbf-be8e-ffa4780e01ae	enp0s31f6	0	0	2026-01-24 18:24:29.067733+00	0	0
4d1990a0-2ff6-4f55-830d-a82ba20fc9a9	wlx30169d2252f8	4146	12623	2026-01-24 18:24:29.074678+00	1951	5941
5304e744-dc13-4368-9982-d98cfcb6b4b6	enp0s31f6	0	0	2026-01-24 20:35:01.656846+00	0	0
b8e2a029-ef09-43de-b577-71dc087e51d0	wlx30169d2252f8	1603	730	2026-01-24 20:35:01.660652+00	904	411
087481a5-4820-40f9-8ae1-201ec4e7b811	enp0s31f6	0	0	2026-01-24 23:30:35.316143+00	0	0
bf0b0f91-23c2-4814-9aea-7e1b336d10ee	wlx30169d2252f8	12104	15678	2026-01-24 23:30:35.323025+00	1439	1864
0f081a6c-bf35-4094-90df-8befe0addbc4	enp0s31f6	0	0	2026-01-24 15:29:25.820632+00	0	0
6fd78b02-86e3-4ae9-a13b-541f89e7d87e	wlx30169d2252f8	79881	52067	2026-01-24 15:29:25.823325+00	2661	1734
099f453b-b2b1-443a-9f91-534d95dfdee3	enp0s31f6	0	0	2026-01-24 18:24:59.021954+00	0	0
011374a8-4353-4fa6-860b-21921a09482d	wlx30169d2252f8	482	350	2026-01-24 18:24:59.024412+00	467	339
a081914c-4bf7-47dc-a108-c38e8d21a232	enp0s31f6	0	0	2026-01-24 20:35:31.712604+00	0	0
d39b964f-cc3d-4003-8eec-6ad95dde8591	wlx30169d2252f8	16598	11875	2026-01-24 20:35:31.719895+00	3502	2506
f7906f6e-b4c8-4d50-a77e-7b41e47f5df3	enp0s31f6	0	0	2026-01-24 23:31:05.289493+00	0	0
155ec5bf-a7f5-4e8b-9005-ddd6c02a6300	wlx30169d2252f8	27649	24186	2026-01-24 23:31:05.29458+00	9415	8236
50bdc639-c74d-4549-bfa3-2a8ba022f9a6	enp0s31f6	0	0	2026-01-24 15:29:55.803007+00	0	0
5de7053a-e2b7-4815-8f4c-b21e8d465359	wlx30169d2252f8	234	224	2026-01-24 15:29:55.804595+00	655	627
7e2e400b-fcbf-49c6-8b7d-9fe97dc01126	enp0s31f6	0	0	2026-01-24 18:25:29.05406+00	0	0
67a25536-e8dd-46d3-87db-275991ac1d0b	wlx30169d2252f8	4800	10915	2026-01-24 18:25:29.056637+00	2261	5143
00b7b303-3945-47e1-a92c-b8a3fde58ad5	enp0s31f6	0	0	2026-01-24 20:36:01.679636+00	0	0
5c9a354d-11a9-4be0-b05b-879f96a3c579	wlx30169d2252f8	1731	730	2026-01-24 20:36:01.683398+00	974	411
a8a450a9-a81f-45b2-815c-884ac60fb1de	enp0s31f6	0	0	2026-01-24 23:31:35.321283+00	0	0
8ce53bee-cde3-4d65-8b61-2288d48d5348	wlx30169d2252f8	10312	11755	2026-01-24 23:31:35.323973+00	1223	1394
741af0ae-0975-4eda-9626-48da7beb6f56	enp0s31f6	0	0	2026-01-24 15:30:25.853691+00	0	0
7b2c0c85-799f-4002-9b9f-532e059e6536	wlx30169d2252f8	90503	51695	2026-01-24 15:30:25.86136+00	3015	1722
776eb47c-bbfe-4f1e-98eb-4ea9fbd78289	enp0s31f6	0	0	2026-01-24 18:25:59.057483+00	0	0
80979fbf-29c7-4bf9-8d8e-026ae20b43eb	wlx30169d2252f8	644	224	2026-01-24 18:25:59.061172+00	618	215
2701c20e-d8c8-48ac-bee3-d144d41e23c8	enp0s31f6	0	0	2026-01-24 20:36:31.73247+00	0	0
d8232b88-5f7a-4fbe-a786-f6149af3586b	wlx30169d2252f8	21402	17121	2026-01-24 20:36:31.739751+00	4438	3550
b1695e03-fc98-4a65-b424-095820213c61	enp0s31f6	0	0	2026-01-24 23:32:05.313038+00	0	0
e0497494-5c74-459e-83bd-143210e30428	wlx30169d2252f8	27240	24261	2026-01-24 23:32:05.318176+00	9217	8209
2932720d-405c-479a-bad6-a4694ee4ecbc	enp0s31f6	0	0	2026-01-24 15:30:55.82528+00	0	0
61cbacdf-ab4d-4d70-8ea4-9e64a13dec4f	wlx30169d2252f8	396	224	2026-01-24 15:30:55.828373+00	1114	630
8d9d45f3-3e57-4b08-9b3c-c9eecef05aad	enp0s31f6	0	0	2026-01-24 18:26:29.109403+00	0	0
bf5ddee1-fd41-4439-b427-89800058f85e	wlx30169d2252f8	5617	14705	2026-01-24 18:26:29.116577+00	2563	6711
6870078d-0159-42ad-9f09-9466fe52b7df	enp0s31f6	0	0	2026-01-24 20:37:01.702291+00	0	0
72649a5c-ddf7-4c3c-9938-6be17cffac35	wlx30169d2252f8	1551	730	2026-01-24 20:37:01.707398+00	866	407
b605d82e-9ee1-4fed-9856-04b47abafb48	enp0s31f6	0	0	2026-01-24 23:32:35.350571+00	0	0
a9ba283b-e1b9-437d-9efa-ed291a41c6e6	wlx30169d2252f8	12719	15998	2026-01-24 23:32:35.357432+00	1503	1891
9cb6f5e5-17b2-4bc6-9a45-312574c9a34c	enp0s31f6	0	0	2026-01-24 15:31:25.864212+00	0	0
49c15272-67b2-4b43-8aa1-09baef1b4e74	wlx30169d2252f8	102844	52203	2026-01-24 15:31:25.871009+00	3427	1739
564abb4e-2007-4446-88ba-e629289b4199	enp0s31f6	0	0	2026-01-24 18:26:59.078241+00	0	0
7de35d52-462f-42d2-a07e-6f18823b690e	wlx30169d2252f8	663	224	2026-01-24 18:26:59.081782+00	626	211
2cafdd5e-12a9-45be-a0e1-5dfb57398d61	enp0s31f6	0	0	2026-01-24 20:37:31.715903+00	0	0
d8f8751e-619c-40f8-99d1-ba37ccb5a763	wlx30169d2252f8	17616	15442	2026-01-24 20:37:31.720108+00	3651	3200
1992fa50-7dff-4018-b68b-e77bca15a89d	enp0s31f6	0	0	2026-01-24 23:33:05.312441+00	0	0
ef526673-d535-429e-b243-b1d479e011af	wlx30169d2252f8	27117	23061	2026-01-24 23:33:05.313951+00	9292	7902
2414206a-a418-4a73-a4f6-60bbb55c0258	enp0s31f6	0	0	2026-01-24 15:31:55.832592+00	0	0
26f849d6-a372-4fd9-8c35-e231546b8ca7	wlx30169d2252f8	292	0	2026-01-24 15:31:55.836491+00	807	0
7716ef4a-3634-4293-8603-fd276e48f634	enp0s31f6	0	0	2026-01-24 18:27:29.128747+00	0	0
4f4764d8-eee8-4179-9347-68131954e2b4	wlx30169d2252f8	12042	10836	2026-01-24 18:27:29.135887+00	5592	5032
897511af-b566-43f6-93c5-b563cb72dea2	enp0s31f6	0	0	2026-01-24 20:38:01.710589+00	0	0
12ad621e-2042-49b7-8306-9894c370fb0a	wlx30169d2252f8	1739	730	2026-01-24 20:38:01.714803+00	963	404
02e573fd-e9b8-44c6-a8cc-f08913c64c7e	enp0s31f6	0	0	2026-01-24 23:33:35.347493+00	0	0
e89d9ffb-261d-4541-89dd-6002ca1c6393	wlx30169d2252f8	11243	13755	2026-01-24 23:33:35.350881+00	1324	1620
15549c7a-da07-475b-827e-14e02bdf328f	enp0s31f6	0	0	2026-01-24 15:32:25.888251+00	0	0
ed68152f-0721-43ef-a383-de1e6ae31e0d	wlx30169d2252f8	91098	52079	2026-01-24 15:32:25.895842+00	3034	1734
bacab5d7-3683-4f1d-94fb-beeacdb8f7cd	enp0s31f6	0	0	2026-01-24 18:27:59.097034+00	0	0
2f245fb9-0b28-4cda-856d-2201469385a4	wlx30169d2252f8	907	224	2026-01-24 18:27:59.101384+00	834	206
7f6c204b-c2ad-403c-855b-8f774e5be34e	enp0s31f6	0	0	2026-01-24 20:38:31.769157+00	0	0
7f07f82e-1006-4734-8df1-16695294406b	wlx30169d2252f8	19316	15996	2026-01-24 20:38:31.786003+00	3933	3257
c1144b5a-7f9b-4d01-b5ad-ade2b8271782	enp0s31f6	0	0	2026-01-24 23:34:05.328396+00	0	0
5809df63-6fcf-4de5-a775-e3452db376d4	wlx30169d2252f8	26410	23509	2026-01-24 23:34:05.330288+00	9057	8062
4155426f-f791-47a7-a54b-8655768736cb	enp0s31f6	0	0	2026-01-24 15:32:55.847709+00	0	0
b2ebba12-cb29-41b3-bc2f-87610648a5e6	wlx30169d2252f8	232	0	2026-01-24 15:32:55.851394+00	644	0
2b0d36a6-4fdd-41f9-93f0-e8513e2dddf7	enp0s31f6	0	0	2026-01-24 18:28:29.151588+00	0	0
2133dde6-ded0-4aa4-8d34-006ea67ca2d4	wlx30169d2252f8	5569	13243	2026-01-24 18:28:29.160245+00	2588	6156
15028bc3-e31d-4ac7-9ff6-bf7f6ac723e7	enp0s31f6	0	0	2026-01-24 20:39:01.746033+00	0	0
1ce24fba-a38b-48bf-8ec9-d13f23e3ed8b	wlx30169d2252f8	1311	730	2026-01-24 20:39:01.75141+00	728	405
ab00863a-bbb3-4978-9943-3854447567eb	enp0s31f6	0	0	2026-01-24 23:34:35.392371+00	0	0
e5194ec7-1b78-4139-9d0e-53ffb1733846	wlx30169d2252f8	28310	13914	2026-01-24 23:34:35.40011+00	3349	1646
ecb8f659-d7f3-4409-a75d-323e76166ca1	enp0s31f6	0	0	2026-01-24 15:33:25.902032+00	0	0
6d569851-2474-4962-bb92-015c6d4ead66	wlx30169d2252f8	87700	52063	2026-01-24 15:33:25.909631+00	2921	1734
f91a138f-2b5b-4dea-82f0-a357fc74ed00	enp0s31f6	0	0	2026-01-24 18:28:59.117576+00	0	0
2f8c3c5c-3bda-4490-aaf3-d8cb236697e4	wlx30169d2252f8	1105	224	2026-01-24 18:28:59.121543+00	1033	209
5758fb71-ea7f-4a4a-968c-349dde7c693a	enp0s31f6	0	0	2026-01-24 20:39:31.79072+00	0	0
7980d13e-7568-4bd1-8b82-3c74a1d46088	wlx30169d2252f8	20208	13149	2026-01-24 20:39:31.794302+00	4079	2654
a13e5ef8-0372-41d7-b969-9859cc6b632c	enp0s31f6	0	0	2026-01-24 23:35:05.361285+00	0	0
baec23f9-684c-4891-aa82-455929db6187	wlx30169d2252f8	27183	24007	2026-01-24 23:35:05.365014+00	9249	8168
ff474179-9320-408e-8f70-150c84f9af73	enp0s31f6	0	0	2026-01-24 15:33:55.870742+00	0	0
b742514e-4848-411e-8e82-14296fb683ce	wlx30169d2252f8	112	0	2026-01-24 15:33:55.874803+00	309	0
cefd8594-9992-4561-abb0-c20cdc6e8e20	enp0s31f6	0	0	2026-01-24 18:29:29.165937+00	0	0
7d81d015-c691-4aa5-8520-023e58da7b9b	wlx30169d2252f8	4813	9776	2026-01-24 18:29:29.171291+00	2209	4487
d1c62930-9d76-4f73-9be7-81560d6067c1	enp0s31f6	0	0	2026-01-24 20:40:01.771161+00	0	0
1d6f7927-d085-481e-b35d-cd996701178d	wlx30169d2252f8	1673	772	2026-01-24 20:40:01.777251+00	913	421
d552ddc3-09ef-4110-a868-dbd9b69f48c3	enp0s31f6	0	0	2026-01-24 23:35:35.413403+00	0	0
37925c5b-2111-418d-ab74-86a2db26266a	wlx30169d2252f8	18337	11742	2026-01-24 23:35:35.422075+00	2165	1386
fca064b2-a3dd-4ce2-908c-c53f70cd84fb	enp0s31f6	0	0	2026-01-24 15:34:25.883617+00	0	0
19f1d901-b92f-408f-b54a-a91c901011e6	wlx30169d2252f8	79216	52198	2026-01-24 15:34:25.886623+00	2639	1739
c4e4bba5-1c8a-44a7-9329-9a24f1cab885	enp0s31f6	0	0	2026-01-24 18:29:59.132837+00	0	0
dad212a3-7799-45fc-82b1-74e3da9f2440	wlx30169d2252f8	925	224	2026-01-24 18:29:59.136544+00	870	210
d31db0ed-eb5d-4224-8825-aadb4d3d14f6	enp0s31f6	0	0	2026-01-24 20:40:31.785025+00	0	0
671ba06f-cbf3-4ded-80e8-31e651fc2c68	wlx30169d2252f8	17644	11793	2026-01-24 20:40:31.788659+00	3581	2393
f41e6f0c-99f8-43f8-9c8a-383e2c3289e1	enp0s31f6	0	0	2026-01-24 23:36:05.373128+00	0	0
70dd69bc-cfe2-4834-adce-d99aff135b1d	wlx30169d2252f8	27122	23803	2026-01-24 23:36:05.374667+00	9145	8026
ea701b5b-8965-4305-a43d-1b9053bcdd98	enp0s31f6	0	0	2026-01-24 15:34:55.890447+00	0	0
4f9108fc-798b-4b1f-ac31-10ff63541897	wlx30169d2252f8	112	0	2026-01-24 15:34:55.894355+00	307	0
bb427909-be7c-4f05-b9c1-16a2c3b400fe	enp0s31f6	0	0	2026-01-24 18:30:29.157968+00	0	0
4e96214d-aea7-4818-8416-b478c62badfb	wlx30169d2252f8	3899	10833	2026-01-24 18:30:29.173166+00	1788	4969
b51a88a5-d31f-4400-a507-658520b0ada2	enp0s31f6	0	0	2026-01-24 20:41:01.76139+00	0	0
8871762e-eb4c-4337-8ce6-1f60f1ceabd4	wlx30169d2252f8	4294	730	2026-01-24 20:41:01.764592+00	2406	409
9291a98b-59be-4901-82bf-53a3e91f2550	enp0s31f6	0	0	2026-01-24 23:36:35.437253+00	0	0
f3e74c41-a55b-4337-b5aa-56eb5f876755	wlx30169d2252f8	10763	12787	2026-01-24 23:36:35.446157+00	1268	1506
463ea768-0de8-4403-88c8-9b070b38c213	enp0s31f6	0	0	2026-01-24 15:35:25.9192+00	0	0
ca50bf09-0394-4c2b-af5f-6f9714db8523	wlx30169d2252f8	72707	48947	2026-01-24 15:35:25.922059+00	2422	1630
09954c11-c09e-4084-ab38-0a153f318adb	enp0s31f6	0	0	2026-01-24 18:30:59.145404+00	0	0
56257389-16e3-4824-a090-cd496cf0e5a9	wlx30169d2252f8	985	224	2026-01-24 18:30:59.147769+00	929	211
40a93bfe-a4d1-4845-a209-324365f46318	enp0s31f6	0	0	2026-01-24 20:41:31.827575+00	0	0
d6aeb6ee-f655-4c9a-823d-9a7eef311298	wlx30169d2252f8	16824	10827	2026-01-24 20:41:31.833924+00	3421	2201
bc476a4f-577e-45e2-ad6b-85a1fbf7a4c9	enp0s31f6	0	0	2026-01-24 23:37:05.408184+00	0	0
ef27aa4e-d615-4295-bfa2-c2c769bac498	wlx30169d2252f8	27431	24443	2026-01-24 23:37:05.412834+00	9247	8240
b7cd8994-97fe-483b-b3e4-b592a9f0817d	enp0s31f6	0	0	2026-01-24 15:35:55.911162+00	0	0
34cdadf0-cae8-456c-98ab-3f147b1a397d	wlx30169d2252f8	412	0	2026-01-24 15:35:55.91517+00	1140	0
f1e4ffba-2680-4537-864a-4758f1d785ae	enp0s31f6	0	0	2026-01-24 18:31:29.208795+00	0	0
56a374bc-7b64-43d8-ac3f-1e459b9d61d1	wlx30169d2252f8	3955	9573	2026-01-24 18:31:29.217435+00	1765	4273
d71e937f-d07a-413c-816d-e1f33b047f55	enp0s31f6	0	0	2026-01-24 20:42:01.798388+00	0	0
e0ab4780-6ced-4af1-9efd-600b325cee22	wlx30169d2252f8	1753	730	2026-01-24 20:42:01.802357+00	957	398
48395c74-a4a0-42fb-b13f-a3b9768bd2d7	enp0s31f6	0	0	2026-01-24 23:37:35.463064+00	0	0
b8ba0ef8-399b-4a93-96e6-ef379027b3a0	wlx30169d2252f8	11586	16306	2026-01-24 23:37:35.472093+00	1345	1893
e3147436-8608-4e21-b4d4-a01c632ab2ea	enp0s31f6	0	0	2026-01-24 15:36:25.944904+00	0	0
c1a474d0-7639-4c7d-abec-22d515775d45	wlx30169d2252f8	89872	48983	2026-01-24 15:36:25.952788+00	2995	1632
4c8d9d48-d57b-45dd-95ee-fbb0b0959956	enp0s31f6	0	0	2026-01-24 18:31:59.17641+00	0	0
512d7a67-79e4-42c0-9c64-4c6aaff8e3a2	wlx30169d2252f8	985	224	2026-01-24 18:31:59.180047+00	910	207
55710a30-02a7-411c-8d9d-c3f3236ff6e2	enp0s31f6	0	0	2026-01-24 20:42:31.825362+00	0	0
ffd58e12-ac43-4139-95b4-8d62413a9d6b	wlx30169d2252f8	18348	15128	2026-01-24 20:42:31.829456+00	3711	3060
58cb51a9-ccc9-48e1-b053-157e1488b77c	enp0s31f6	0	0	2026-01-24 23:38:05.419482+00	0	0
5dd81b12-4744-48ea-a7c2-fedebc57db72	wlx30169d2252f8	27984	23812	2026-01-24 23:38:05.421305+00	9438	8031
afb6c08b-d430-4b24-90d8-035b59a86c33	enp0s31f6	0	0	2026-01-24 15:36:55.914053+00	0	0
a150164a-1443-4e33-a60d-4cff73862a2d	wlx30169d2252f8	112	0	2026-01-24 15:36:55.918179+00	298	0
c1c45e7b-e3fd-42e2-bd3e-58cb4bdc060a	enp0s31f6	0	0	2026-01-24 18:32:29.190901+00	0	0
b7d0a9a7-a62e-4939-b725-0968f5ed6de5	wlx30169d2252f8	4321	10834	2026-01-24 18:32:29.195115+00	1960	4916
90701e43-5ba1-4f08-b644-7bf1026f7a03	enp0s31f6	0	0	2026-01-24 20:43:01.820587+00	0	0
f5f1f965-7595-496c-9c5c-c827fa0a0917	wlx30169d2252f8	1779	870	2026-01-24 20:43:01.826257+00	979	478
3fa29936-2098-484b-b135-72c78f769162	enp0s31f6	0	0	2026-01-24 23:38:35.450632+00	0	0
87cf269d-68ab-4bdb-8180-3bf2fef0bba5	wlx30169d2252f8	13384	15717	2026-01-24 23:38:35.454865+00	1542	1811
5c5249dd-f0b6-44bc-b922-cc50a165275b	enp0s31f6	0	0	2026-01-24 15:37:25.965432+00	0	0
7bbac6e4-1e34-4af5-a229-333b0f8b126e	wlx30169d2252f8	84290	49735	2026-01-24 15:37:25.972995+00	2807	1656
c93fe843-2761-4c7a-80fd-dc214a642088	enp0s31f6	0	0	2026-01-24 18:32:59.196873+00	0	0
75ea43b5-aa01-456e-af2e-a6920b25189e	wlx30169d2252f8	925	224	2026-01-24 18:32:59.200919+00	846	204
895d8a24-2454-48be-8133-378b3511476a	enp0s31f6	0	0	2026-01-24 20:43:31.843331+00	0	0
786db2f7-dc70-47b3-aef9-3721a6155bca	wlx30169d2252f8	19148	13574	2026-01-24 20:43:31.846082+00	3842	2723
1765f30e-afbc-47a0-8ea5-37bcce0b0fb5	enp0s31f6	0	0	2026-01-24 23:39:05.459148+00	0	0
b9c4ba18-dfa7-4a7d-9917-4b46715aa864	wlx30169d2252f8	27022	23993	2026-01-24 23:39:05.467204+00	8990	7982
5543dda0-b17b-4927-baee-aa56dad720f5	enp0s31f6	0	0	2026-01-24 15:37:55.933781+00	0	0
96f6852c-b7c2-4f03-9f9c-54bdca285a27	wlx30169d2252f8	292	0	2026-01-24 15:37:55.938048+00	779	0
c8b5a4a1-2e02-49cb-a1fd-f18125c8a92c	enp0s31f6	0	0	2026-01-24 18:33:29.249769+00	0	0
9369624c-7771-4a70-9cde-51147d9fbfa1	wlx30169d2252f8	4423	10834	2026-01-24 18:33:29.258485+00	1948	4773
a91c1f19-2d78-4ef9-b063-2447bb712aa7	enp0s31f6	0	0	2026-01-24 20:44:01.831079+00	0	0
eec5403d-e115-497b-9d23-9532d109856c	wlx30169d2252f8	1773	726	2026-01-24 20:44:01.832785+00	966	395
4f4a8e03-2358-41f3-81a1-b800fe1dc2b3	enp0s31f6	0	0	2026-01-24 23:39:35.505443+00	0	0
82d892a9-038f-43c4-8dea-377339aea964	wlx30169d2252f8	10842	12104	2026-01-24 23:39:35.512763+00	1257	1403
09c09778-85a0-4708-8622-d7c3e3f43679	enp0s31f6	0	0	2026-01-24 15:38:25.952738+00	0	0
ef473640-33fb-4098-8075-6b9d0ca8c466	wlx30169d2252f8	88843	52034	2026-01-24 15:38:25.956153+00	2960	1733
1beca400-de5d-4cc2-9984-6d6cd7fff8eb	enp0s31f6	0	0	2026-01-24 18:33:59.218355+00	0	0
c123fb5b-9927-4783-a7ec-afeaa4d683a3	wlx30169d2252f8	925	224	2026-01-24 18:33:59.223812+00	838	203
f2fe623e-2041-40cf-9fa1-177f0df78fc8	enp0s31f6	0	0	2026-01-24 20:44:31.856209+00	0	0
141991c9-3699-4beb-9527-c2fd837ab48c	wlx30169d2252f8	18585	10425	2026-01-24 20:44:31.858464+00	3755	2106
05217243-ce9c-4a54-9965-1457df62b2be	enp0s31f6	0	0	2026-01-24 23:40:05.46149+00	0	0
95d95bbe-a4c8-465d-a34f-b440cba7f626	wlx30169d2252f8	26495	23480	2026-01-24 23:40:05.464171+00	8909	7896
4e900a3f-778d-49de-9878-829ee41bedb4	enp0s31f6	0	0	2026-01-24 15:38:55.953555+00	0	0
d5f638eb-b117-4351-9b5d-7e02c3c1a46b	wlx30169d2252f8	292	0	2026-01-24 15:38:55.957571+00	738	0
9f74b789-9d69-4f9d-a6bf-1d9aa9044735	enp0s31f6	0	0	2026-01-24 18:34:29.231557+00	0	0
63e195b8-522e-4a0b-872b-47c76c50454f	wlx30169d2252f8	11109	10831	2026-01-24 18:34:29.234838+00	4985	4861
2570bf62-3c52-406d-a9e1-65c7e57f6387	enp0s31f6	0	0	2026-01-24 20:45:01.850929+00	0	0
d0e72837-35c6-407e-8631-dead0601d708	wlx30169d2252f8	1345	726	2026-01-24 20:45:01.852604+00	732	395
2cedf4ca-9c36-4897-95e3-8068ca2504c6	enp0s31f6	0	0	2026-01-24 23:40:35.526361+00	0	0
bfb3cf7c-3dcb-4a99-8ca9-4e704dc5851b	wlx30169d2252f8	11400	12893	2026-01-24 23:40:35.533594+00	1316	1488
59b08031-89e8-4ff0-8842-208993c96bb8	enp0s31f6	0	0	2026-01-24 15:39:26.004542+00	0	0
96181197-d600-40b0-b24b-d256229a644a	wlx30169d2252f8	83831	48002	2026-01-24 15:39:26.012176+00	2792	1599
a2ba199a-4e3d-481f-938b-f76ddcd14927	enp0s31f6	0	0	2026-01-24 18:34:59.239356+00	0	0
0b78bb23-6422-4c0a-82f8-83f757f5446a	wlx30169d2252f8	847	224	2026-01-24 18:34:59.24304+00	766	202
30e1c7b7-ca67-4d5f-9054-02668028b185	enp0s31f6	0	0	2026-01-24 20:45:31.877485+00	0	0
91322545-e49a-4860-a953-c5a162d063b8	wlx30169d2252f8	17148	10515	2026-01-24 20:45:31.879639+00	3450	2115
e4ebc2ed-2055-45cb-b356-9c52afe12ba7	enp0s31f6	0	0	2026-01-24 23:41:05.496799+00	0	0
c2ab72fd-88c6-497d-b03a-69038bef7d34	wlx30169d2252f8	27069	24169	2026-01-24 23:41:05.5007+00	9013	8048
d0b0cec5-7d3b-49af-8100-4287e779a2af	enp0s31f6	0	0	2026-01-24 15:39:55.961577+00	0	0
e6f0ee1b-dee2-4bc0-ad6b-223b40f02971	wlx30169d2252f8	232	0	2026-01-24 15:39:55.963672+00	630	0
64a679a2-fb91-43ec-be24-51b43595fff2	enp0s31f6	0	0	2026-01-24 18:35:29.255172+00	0	0
b3d1e33d-bab2-4cce-b995-6ed61f903f4e	wlx30169d2252f8	4241	9876	2026-01-24 18:35:29.257648+00	1787	4163
00744980-c3b4-4588-b6c2-7311f86be4d3	enp0s31f6	0	0	2026-01-24 20:46:01.870403+00	0	0
0d60b186-dfc3-484a-b082-4fd96cc898ef	wlx30169d2252f8	1423	730	2026-01-24 20:46:01.873764+00	774	397
b9557ff3-6518-4559-a0df-75d50db53876	enp0s31f6	0	0	2026-01-24 23:41:35.539097+00	0	0
710e9c12-4ae4-4bad-87da-a170817e8f09	wlx30169d2252f8	14208	13528	2026-01-24 23:41:35.543221+00	1635	1557
acfae4a8-140b-4369-bab8-7e5f04ed6b57	enp0s31f6	0	0	2026-01-24 15:40:25.996972+00	0	0
98c483ba-18e4-4c14-bc58-c4894457ff46	wlx30169d2252f8	84168	50678	2026-01-24 15:40:26.001745+00	2803	1687
794b11a3-a3ca-447b-817d-ec65056fc1df	enp0s31f6	0	0	2026-01-24 18:35:59.248329+00	0	0
678e3ce5-7a82-4c31-9ce1-0503d8b23b75	wlx30169d2252f8	1051	436	2026-01-24 18:35:59.250173+00	949	393
ccc420ab-eabf-4036-b6b1-729585721de3	enp0s31f6	0	0	2026-01-24 20:46:31.901572+00	0	0
594cecd5-2e9c-46cb-8487-edd1d3941fc1	wlx30169d2252f8	17834	13579	2026-01-24 20:46:31.905681+00	3564	2713
58e4ff20-03d1-4b08-8bb3-3826ea7e9b94	enp0s31f6	0	0	2026-01-24 23:42:05.506258+00	0	0
fb621343-4b3b-4e97-9393-8541a4becaff	wlx30169d2252f8	26583	23803	2026-01-24 23:42:05.509505+00	8788	7869
2cde67ed-7d49-42ab-90c3-a5fb6c83fae9	enp0s31f6	0	0	2026-01-24 15:40:55.995025+00	0	0
9a9ff493-0c1f-4b67-9b99-d4cb26230d2c	wlx30169d2252f8	112	0	2026-01-24 15:40:55.999407+00	292	0
dbc78409-2332-421c-b0fa-e6f04979d8d9	enp0s31f6	0	0	2026-01-24 18:36:29.286229+00	0	0
e05e445c-7ac0-4138-82e9-39074dc4f91a	wlx30169d2252f8	4243	10839	2026-01-24 18:36:29.289559+00	1799	4597
b4869233-3cfa-4d9b-a56f-1507b77d97de	enp0s31f6	0	0	2026-01-24 20:47:01.894132+00	0	0
85f4ec2d-2da0-4d69-90e6-845f329cda19	wlx30169d2252f8	1645	730	2026-01-24 20:47:01.897731+00	887	394
76d227d9-a72e-4f4f-ac1a-760caa522ba5	enp0s31f6	0	0	2026-01-24 23:42:35.574153+00	0	0
df2e8120-9150-4417-8551-709c717db544	wlx30169d2252f8	19499	12707	2026-01-24 23:42:35.580789+00	2241	1460
9ac51d6c-373f-4c56-8dfd-7b7a44207709	enp0s31f6	0	0	2026-01-24 15:41:26.047891+00	0	0
6aec6ec8-1840-435b-a708-ce8eb683f025	wlx30169d2252f8	78662	52684	2026-01-24 15:41:26.055176+00	2620	1754
55bffc27-328c-4193-83cf-7a83355d90aa	enp0s31f6	0	0	2026-01-24 18:36:59.26819+00	0	0
b6332c1e-cb44-4345-b02c-3e4e31e402f7	wlx30169d2252f8	967	224	2026-01-24 18:36:59.271522+00	872	202
19151eb3-5188-4b70-be57-ad600198f446	enp0s31f6	0	0	2026-01-24 20:47:31.91941+00	0	0
278c5aed-cef2-4996-87de-366f2d7c105e	wlx30169d2252f8	17078	13657	2026-01-24 20:47:31.924291+00	3413	2729
af39a28e-14df-4c2b-be00-8edeec543e0c	enp0s31f6	0	0	2026-01-24 23:43:05.543912+00	0	0
4669dd89-b931-44ab-accb-01f404d127d0	wlx30169d2252f8	26939	24213	2026-01-24 23:43:05.547667+00	8894	7994
fb9578e8-f679-4beb-89fe-46924aed9028	enp0s31f6	0	0	2026-01-24 15:41:56.001331+00	0	0
a9b60893-37a9-4b3e-b383-b7f11525abbc	wlx30169d2252f8	112	0	2026-01-24 15:41:56.00487+00	271	0
22488236-c3be-4861-973a-ea6eb9061dc8	enp0s31f6	0	0	2026-01-24 18:37:29.319436+00	0	0
0fe65979-cc1e-46b5-a58f-933fe2a77d62	wlx30169d2252f8	3763	9469	2026-01-24 18:37:29.326633+00	1568	3947
03cc372f-d365-4c56-b15b-a5e3d89ff959	enp0s31f6	0	0	2026-01-24 20:48:01.91432+00	0	0
be7db893-6463-49ad-9c3a-56463e3b4f48	wlx30169d2252f8	9420	730	2026-01-24 20:48:01.917771+00	5142	398
6e77935c-eff8-4212-a855-5710885bbeb2	enp0s31f6	0	0	2026-01-24 23:43:35.577799+00	0	0
ab61887c-59f2-4e1e-b6f4-f15b6e29dbae	wlx30169d2252f8	12122	12985	2026-01-24 23:43:35.581911+00	1388	1486
ecad44fc-a71c-4e85-a69e-53917cd57f57	enp0s31f6	0	0	2026-01-24 15:42:26.065013+00	0	0
48e8a156-87ba-4bab-9c20-281cf7f3af58	wlx30169d2252f8	86788	69437	2026-01-24 15:42:26.070412+00	2889	2312
45f83997-5e8f-44dc-bc16-96c76b3d1c66	enp0s31f6	0	0	2026-01-24 18:37:59.288024+00	0	0
159dd0f4-8105-4946-b01d-b87ec351a59a	wlx30169d2252f8	1105	224	2026-01-24 18:37:59.292259+00	995	201
5769c7e5-2f30-42bf-99eb-7e93ec7f24ee	enp0s31f6	0	0	2026-01-24 20:48:31.941236+00	0	0
43673081-1c29-41a8-a7e2-b1df4a3ac6f2	wlx30169d2252f8	17808	12051	2026-01-24 20:48:31.943622+00	3558	2408
4108527d-0df6-4a40-b8b0-71d7cb523724	enp0s31f6	0	0	2026-01-24 23:44:05.566566+00	0	0
3371fb16-8ceb-4edb-a6e0-c0acbbae03c8	wlx30169d2252f8	27072	24231	2026-01-24 23:44:05.570336+00	8882	7949
db428006-27a8-4b1d-8757-f7cb37b13d6a	enp0s31f6	0	0	2026-01-24 15:42:56.030735+00	0	0
395eec1b-eb49-4d1d-af94-e6fc57858bb4	wlx30169d2252f8	412	0	2026-01-24 15:42:56.034103+00	1031	0
1eb33843-cbc1-4cb9-8085-e65f0f4882fa	enp0s31f6	0	0	2026-01-24 18:38:29.339941+00	0	0
bf49b8ab-3bb9-4f42-96b0-bdd876f0bd15	wlx30169d2252f8	4863	13919	2026-01-24 18:38:29.347181+00	2062	5904
523f1001-9bab-47ff-959a-9ec5b03827d1	enp0s31f6	0	0	2026-01-24 20:49:01.936001+00	0	0
9e7a8b3a-a9e2-400f-94db-6c09b04a14b1	wlx30169d2252f8	1785	730	2026-01-24 20:49:01.939025+00	971	397
b4bf12b0-6fe4-43bb-9623-99dbdb52fed9	enp0s31f6	0	0	2026-01-24 23:44:35.582421+00	0	0
80ceb1be-a9bc-400d-a32b-c40b67ca0141	wlx30169d2252f8	12624	12709	2026-01-24 23:44:35.586626+00	1449	1459
2fe9d4f4-5f81-4b37-8473-61d622c3ffe5	enp0s31f6	0	0	2026-01-24 15:43:26.049016+00	0	0
79f86dab-7e96-4e59-88e0-69d0d5ede6b6	wlx30169d2252f8	81462	53660	2026-01-24 15:43:26.051552+00	2714	1787
44726614-aca6-4007-8cb3-c903d9183f06	enp0s31f6	0	0	2026-01-24 18:38:59.30431+00	0	0
8609308a-17f6-4abb-bf2c-1359b238ff71	wlx30169d2252f8	985	224	2026-01-24 18:38:59.30841+00	887	201
5a5c6e0b-af9e-42f8-9723-fdbe149f785a	enp0s31f6	0	0	2026-01-24 20:49:31.963793+00	0	0
57f8d6df-62e2-411e-9cf9-109da97c5d5f	wlx30169d2252f8	18026	14110	2026-01-24 20:49:31.968222+00	3573	2797
8921003d-a2b3-4b12-af32-8dbfe5b3ddcb	enp0s31f6	0	0	2026-01-24 23:45:05.590438+00	0	0
3b3a5a4b-a436-46e5-bc65-9e4823f97330	wlx30169d2252f8	34007	23818	2026-01-24 23:45:05.594429+00	11042	7734
853837bb-67cf-4331-a270-6de34b9914da	enp0s31f6	0	0	2026-01-24 15:43:56.046334+00	0	0
aa2a2c1f-c1c7-48d0-b717-257f1fb9aa49	wlx30169d2252f8	112	0	2026-01-24 15:43:56.050581+00	267	0
198321d5-e887-4d4a-85ac-fd9d2b665281	enp0s31f6	0	0	2026-01-24 18:39:29.36155+00	0	0
5f2a4c05-b0c0-48b0-8319-59cd2dd4bb01	wlx30169d2252f8	5513	11140	2026-01-24 18:39:29.368804+00	2274	4595
1bccb50f-46a3-48a9-8451-b7a48e3ff059	enp0s31f6	0	0	2026-01-24 20:50:01.958162+00	0	0
47c6b26f-3df4-40f2-852c-df66df151286	wlx30169d2252f8	1603	730	2026-01-24 20:50:01.965108+00	870	396
1aeea430-2363-4ec9-9763-15bd182302e7	enp0s31f6	0	0	2026-01-24 23:45:35.644719+00	0	0
0c1405e6-bf92-4a87-9160-f2e2d9eaad74	wlx30169d2252f8	12056	13095	2026-01-24 23:45:35.653329+00	1377	1496
b15ff144-5533-4af3-8c22-f2917162252e	enp0s31f6	0	0	2026-01-24 15:44:26.109185+00	0	0
f95c6b02-7f4b-4165-9336-4543a2295646	wlx30169d2252f8	82359	52099	2026-01-24 15:44:26.118386+00	2742	1735
34efa2e4-7841-4f82-82f3-0bec06c537cf	enp0s31f6	0	0	2026-01-24 18:39:59.330618+00	0	0
d7f7120b-07c2-4d7b-91af-664b0ec33c5f	wlx30169d2252f8	1189	224	2026-01-24 18:39:59.334327+00	1058	199
0687e055-edf4-46db-8922-934220141b64	enp0s31f6	0	0	2026-01-24 20:50:31.989816+00	0	0
189a9070-25d7-455a-b6be-a02c7cc82fc3	wlx30169d2252f8	25025	11789	2026-01-24 20:50:31.994048+00	4961	2337
9187cdd9-065d-4232-aab5-02e46ad9e370	enp0s31f6	0	0	2026-01-24 23:46:05.61395+00	0	0
b2592739-47b8-4c89-abc1-5e0a95aaaee6	wlx30169d2252f8	33701	23867	2026-01-24 23:46:05.617581+00	11000	7790
e4c2fe42-ec14-41f3-a364-d2d1cd09a269	enp0s31f6	0	0	2026-01-24 15:44:56.075883+00	0	0
0c3cef78-3277-491f-be13-17031b53257e	wlx30169d2252f8	1121	302	2026-01-24 15:44:56.080277+00	2634	709
d40689f1-0ec8-489d-a46b-199fdc21f499	enp0s31f6	0	0	2026-01-24 18:40:29.384498+00	0	0
716e0418-fc0a-4996-8dd4-fc0e1b146cd7	wlx30169d2252f8	5541	13580	2026-01-24 18:40:29.391784+00	2296	5628
b63f4299-abf3-499d-b170-8f045fd4ec4b	enp0s31f6	0	0	2026-01-24 20:51:01.97966+00	0	0
0fd44b16-f7c3-4e2e-8ba3-3e026941e37f	wlx30169d2252f8	1970	648	2026-01-24 20:51:01.981099+00	1067	351
20dc9569-d5a2-4e57-9e8f-9a4bee7cb6a9	enp0s31f6	0	0	2026-01-24 23:46:35.662952+00	0	0
f975a383-6155-46fe-8b4c-db7216c89d25	wlx30169d2252f8	12454	12932	2026-01-24 23:46:35.668319+00	1414	1468
8e5b04c2-88d8-4f21-9d0c-3709424ba747	enp0s31f6	0	0	2026-01-24 15:45:26.089707+00	0	0
5ac4aa21-9073-439d-ac17-690a11597d01	wlx30169d2252f8	86813	51949	2026-01-24 15:45:26.092178+00	2892	1731
c2756575-0cf2-4f38-9f18-11129601a855	enp0s31f6	0	0	2026-01-24 18:40:59.337124+00	0	0
89fe2c4d-b343-4b74-8f75-2c1fc02d8336	wlx30169d2252f8	865	224	2026-01-24 18:40:59.34029+00	776	201
5a88e012-a68c-4ba9-aa74-bc3778e15e88	enp0s31f6	0	0	2026-01-24 20:51:32.007871+00	0	0
1a315bfe-53db-4a00-8d7b-0cb89a0cd885	wlx30169d2252f8	19094	11869	2026-01-24 20:51:32.011777+00	3746	2329
078d7070-0429-4b10-bad5-d34253646252	enp0s31f6	0	0	2026-01-24 23:47:05.635837+00	0	0
9b85e030-1b26-4166-954f-c536b868f1d0	wlx30169d2252f8	27024	23729	2026-01-24 23:47:05.63965+00	8784	7713
ffdd70f9-ffdc-4560-8177-5a7de02b4d0c	enp0s31f6	0	0	2026-01-24 15:45:56.097057+00	0	0
5dddded4-9b8f-4b85-b724-daaa2b9e3ae6	wlx30169d2252f8	112	0	2026-01-24 15:45:56.100948+00	277	0
49fddc65-8049-40a2-b325-f7d9de7b7804	enp0s31f6	0	0	2026-01-24 18:41:29.401901+00	0	0
543b138f-3575-4d4a-bdcc-8c96f8aec3fc	wlx30169d2252f8	10812	12788	2026-01-24 18:41:29.410575+00	4456	5271
647b948f-7791-44ba-9633-d95786bda4c7	enp0s31f6	0	0	2026-01-24 20:52:02.000983+00	0	0
72e38ef6-cfca-4d2d-8588-5377d06a66da	wlx30169d2252f8	1848	730	2026-01-24 20:52:02.002381+00	991	391
c8a7256d-aa2d-4ba3-ad5b-540fcac1a508	enp0s31f6	0	0	2026-01-24 23:47:35.687793+00	0	0
4e611186-86f3-4d30-8958-7383e27409bd	wlx30169d2252f8	12012	13893	2026-01-24 23:47:35.694954+00	1361	1574
d78ff240-0ead-427c-b89a-cec05225ae82	enp0s31f6	0	0	2026-01-24 15:46:26.141979+00	0	0
ac0762bb-c50e-4d03-8b23-ec311cd46c5a	wlx30169d2252f8	88452	51692	2026-01-24 15:46:26.14673+00	2946	1721
98f34905-d93f-4896-8179-4c517bd4fe0e	enp0s31f6	0	0	2026-01-24 18:41:59.356711+00	0	0
28a33c80-4ed6-4011-9275-dc5d5388f7ff	wlx30169d2252f8	865	224	2026-01-24 18:41:59.360164+00	757	196
cd638116-7ec3-4de4-8806-e117d3cc59cb	enp0s31f6	0	0	2026-01-24 20:52:32.029279+00	0	0
8547a7b6-891b-4de1-9d01-1e3b0890e3a1	wlx30169d2252f8	19411	13934	2026-01-24 20:52:32.033155+00	3819	2741
80059e5a-4f3f-48e1-be99-a4c28ca39670	enp0s31f6	0	0	2026-01-24 23:48:05.658524+00	0	0
28c3c003-eeb7-45fe-87b9-fb5562e75e4e	wlx30169d2252f8	26574	23675	2026-01-24 23:48:05.66384+00	8573	7638
e6fa698f-4b89-41cc-afee-cea29f389096	enp0s31f6	0	0	2026-01-24 15:46:56.104044+00	0	0
9c0a3641-6dab-4153-9cb7-e885285e0452	wlx30169d2252f8	242	0	2026-01-24 15:46:56.105596+00	581	0
e298688a-38fa-4615-8eed-13880400f187	enp0s31f6	0	0	2026-01-24 18:42:29.423076+00	0	0
d08d0e6e-4f0b-4b54-903f-140dd335ad33	wlx30169d2252f8	5700	11135	2026-01-24 18:42:29.430691+00	2309	4511
d4c51d85-4f09-4e6d-bfa6-b517d0ac0814	enp0s31f6	0	0	2026-01-24 20:53:02.024361+00	0	0
8cde1487-5823-4cee-91a6-79d1d7dd94e9	wlx30169d2252f8	1422	730	2026-01-24 20:53:02.025939+00	759	389
666beaff-eaea-4ce4-878a-6534924d9529	enp0s31f6	0	0	2026-01-24 23:48:35.711029+00	0	0
24104d97-a6bf-4a2a-ae34-e949b76888b0	wlx30169d2252f8	14236	13202	2026-01-24 23:48:35.716275+00	1618	1500
cdc11188-a834-43d6-8b2d-ec8cbc31d0da	enp0s31f6	0	0	2026-01-24 15:47:26.149482+00	0	0
ee596953-cbf4-4303-8a9a-e8e01e830940	wlx30169d2252f8	103940	51872	2026-01-24 15:47:26.155718+00	3461	1727
77125e3a-d219-4372-97c7-21a8e5512922	enp0s31f6	0	0	2026-01-24 18:42:59.392523+00	0	0
d57d0463-245a-402e-8a47-d604087ae125	wlx30169d2252f8	907	224	2026-01-24 18:42:59.398767+00	790	195
720e5e83-5501-4790-8c82-d5850d79fe45	enp0s31f6	0	0	2026-01-24 20:53:32.053077+00	0	0
195b4f91-b143-4189-988c-cd8a818b5dd6	wlx30169d2252f8	18144	13141	2026-01-24 20:53:32.055442+00	3458	2504
b83f0257-e0d2-4ee8-a626-97e012e8b854	enp0s31f6	0	0	2026-01-24 23:49:05.680875+00	0	0
18188e50-3e9f-4c97-b15f-61d454865542	wlx30169d2252f8	27256	24257	2026-01-24 23:49:05.684637+00	8754	7791
c1db23ae-32ef-4d79-a965-2fc74279958e	enp0s31f6	0	0	2026-01-24 15:47:56.137649+00	0	0
ad7dd84e-4979-4733-bd9f-e531ef1109e0	wlx30169d2252f8	0	0	2026-01-24 15:47:56.142337+00	0	0
4c762510-7366-49cd-882d-0200260c8a95	enp0s31f6	0	0	2026-01-24 18:43:29.422511+00	0	0
815d197c-2c41-4332-999e-e162cc1bbd13	wlx30169d2252f8	5763	12110	2026-01-24 18:43:29.427249+00	2300	4833
42c542d9-9d01-45b7-ba8e-05a1ac0fe330	enp0s31f6	0	0	2026-01-24 20:54:02.045986+00	0	0
55d54bb0-661f-4d77-8ded-3cd760367dab	wlx30169d2252f8	1422	730	2026-01-24 20:54:02.049303+00	759	390
c0a66483-6661-4346-808d-76d060e23151	enp0s31f6	0	0	2026-01-24 23:49:35.697059+00	0	0
7f4416a2-d2d2-4a3a-8784-b8c76984a878	wlx30169d2252f8	20369	12331	2026-01-24 23:49:35.701264+00	2314	1401
1745e9ee-df60-4903-9e4d-0953d0f2cee5	enp0s31f6	0	0	2026-01-24 15:48:26.188675+00	0	0
42050f91-8727-4a10-90e0-1ce3103896c0	wlx30169d2252f8	95461	56455	2026-01-24 15:48:26.196346+00	3179	1880
362f66c6-92e7-4670-abc7-74ce0ee6203a	enp0s31f6	0	0	2026-01-24 18:43:59.398319+00	0	0
343d6636-aad6-4635-89c7-d4b97e7ed937	wlx30169d2252f8	913	388	2026-01-24 18:43:59.399752+00	801	340
b9a0d005-c86d-42bc-8287-943c6f016b85	enp0s31f6	0	0	2026-01-24 20:54:32.073004+00	0	0
395a2dc9-82ee-47bb-a395-d20c463e2621	wlx30169d2252f8	18696	15805	2026-01-24 20:54:32.078408+00	3556	3006
a083a004-48d8-4557-97af-77090fd3890a	enp0s31f6	0	0	2026-01-24 23:50:05.704612+00	0	0
fe63ba12-3028-4ce3-bf49-cc7cddbb366f	wlx30169d2252f8	27166	24109	2026-01-24 23:50:05.709863+00	8712	7731
dacb2cf1-1c3b-4e63-98bd-2ed6ea94714b	enp0s31f6	0	0	2026-01-24 15:48:56.157833+00	0	0
b89ba0d2-4d14-47d4-8485-0b5b863772ba	wlx30169d2252f8	0	0	2026-01-24 15:48:56.161729+00	0	0
821da7a3-b1c7-43f8-96d5-0527477f9517	enp0s31f6	0	0	2026-01-24 18:44:29.455468+00	0	0
ef66e525-dcc3-4b7b-b301-57b91e22d466	wlx30169d2252f8	6193	13177	2026-01-24 18:44:29.460537+00	2508	5337
7026678d-210a-4e6e-bbad-5fd818b723c5	enp0s31f6	0	0	2026-01-24 20:55:02.066491+00	0	0
9e46b1ec-b260-4931-a017-a213a54f59e8	wlx30169d2252f8	1584	730	2026-01-24 20:55:02.069967+00	843	388
f0ca14e9-e9c3-40fe-a449-1ccd5d0b1809	enp0s31f6	0	0	2026-01-24 23:50:35.757278+00	0	0
9297cb11-eece-43fc-811a-a17c96d8579b	wlx30169d2252f8	21569	18170	2026-01-24 23:50:35.764929+00	2411	2031
961c81f9-f5e2-4a53-af9e-94844d4eda1c	enp0s31f6	0	0	2026-01-24 15:49:26.208556+00	0	0
4b647bfb-c4c0-4104-a3b6-3a097dda65b9	wlx30169d2252f8	78397	52839	2026-01-24 15:49:26.216854+00	2611	1760
de7b6e34-33d0-4775-bdf9-570335686d50	enp0s31f6	0	0	2026-01-24 18:44:59.425886+00	0	0
f8e3fa52-e352-4239-8737-1fbdc137a363	wlx30169d2252f8	1047	224	2026-01-24 18:44:59.429534+00	915	195
20476d09-f6b4-432e-bad5-39a2ac414350	enp0s31f6	0	0	2026-01-24 20:55:32.095228+00	0	0
ce9437df-26bc-42ed-b2bd-e6fe47738534	wlx30169d2252f8	16250	10646	2026-01-24 20:55:32.099614+00	3119	2043
45763699-e796-4a6f-aac2-70ba64b6495b	enp0s31f6	0	0	2026-01-24 23:51:05.727324+00	0	0
ec27764e-12cc-4976-bcbd-17c1eabded62	wlx30169d2252f8	27089	23583	2026-01-24 23:51:05.732456+00	8600	7487
6c84e7e0-1cf9-4688-8610-2184c4050407	enp0s31f6	0	0	2026-01-24 15:49:56.169914+00	0	0
24c0b902-26af-455c-b606-c1f357919e61	wlx30169d2252f8	542	224	2026-01-24 15:49:56.172143+00	1279	528
bffbf32c-1bdc-45ec-9e88-8ac7e88f06dd	enp0s31f6	0	0	2026-01-24 18:45:29.477634+00	0	0
b4e0a2cf-f56a-4d94-90f7-d294dcb0235a	wlx30169d2252f8	5553	10301	2026-01-24 18:45:29.484669+00	2247	4168
710d0b88-2650-4e4a-83d8-74962f1a8584	enp0s31f6	0	0	2026-01-24 20:56:02.088259+00	0	0
fda54f76-1980-4cf8-933c-ebf94ad41a02	wlx30169d2252f8	9239	730	2026-01-24 20:56:02.089716+00	4898	387
710f534f-4744-40e7-8fee-fe2707087a74	enp0s31f6	0	0	2026-01-24 23:51:35.772051+00	0	0
92486385-a410-488b-a2fa-ba56f5c49c3e	wlx30169d2252f8	12396	13262	2026-01-24 23:51:35.780505+00	1387	1484
15fdcd63-3d0b-46fa-833e-5c5b40453b29	enp0s31f6	0	0	2026-01-24 15:50:26.222822+00	0	0
2cd89fba-38f5-43f7-8352-ec0a48d6b821	wlx30169d2252f8	81049	53458	2026-01-24 15:50:26.228955+00	2699	1780
726eeb9b-9e42-41bc-ace6-7cb0607e0d82	enp0s31f6	0	0	2026-01-24 18:45:59.44694+00	0	0
f4773508-af53-4535-9f4f-ea6b61bfd193	wlx30169d2252f8	3506	224	2026-01-24 18:45:59.450588+00	3033	193
0eb0a59c-1ae7-4b5e-8dd8-16f0533e8115	enp0s31f6	0	0	2026-01-24 20:56:32.117682+00	0	0
c937451d-d77e-4a8c-ad2d-d527d528c36a	wlx30169d2252f8	18368	15812	2026-01-24 20:56:32.120108+00	3485	3000
d7ed2412-2ca1-453f-9b66-672f00feaadb	enp0s31f6	0	0	2026-01-24 23:52:05.742348+00	0	0
da70af04-360f-4f00-b1c2-9038c92515c9	wlx30169d2252f8	27298	25531	2026-01-24 23:52:05.747737+00	8647	8087
66fb31b5-e28c-4bb7-b279-93d5119fdd13	enp0s31f6	0	0	2026-01-24 15:50:56.197446+00	0	0
16168610-681b-424f-8453-30a593dc7cb8	wlx30169d2252f8	224	224	2026-01-24 15:50:56.21154+00	501	501
c573d7d6-32d3-4b18-b515-058a8305d471	enp0s31f6	0	0	2026-01-24 18:46:29.46146+00	0	0
1afc8d9b-c92c-44b3-8690-521f31d71419	wlx30169d2252f8	6591	12109	2026-01-24 18:46:29.463674+00	2629	4831
58386780-0f93-4b23-a584-9d8e051e0a8d	enp0s31f6	0	0	2026-01-24 20:57:02.111207+00	0	0
69c2b65e-50d6-4e7d-95d1-f1173a089c70	wlx30169d2252f8	1626	730	2026-01-24 20:57:02.114092+00	843	378
1fbffb21-9d03-423c-ac7b-fceb3335ffdd	enp0s31f6	0	0	2026-01-24 23:52:35.75508+00	0	0
7f6ea8b9-8a59-4715-a71e-ca81f27e6057	wlx30169d2252f8	11034	12060	2026-01-24 23:52:35.759751+00	1235	1350
b2b5c7fb-b7e3-4181-8335-839133ef0aab	enp0s31f6	0	0	2026-01-24 15:51:26.221442+00	0	0
29518506-319e-4329-a06f-c957c8e1e85b	wlx30169d2252f8	80760	52342	2026-01-24 15:51:26.226044+00	2690	1743
bf1a547d-c899-4354-8812-04b26bc74276	enp0s31f6	0	0	2026-01-24 18:46:59.468056+00	0	0
f0eb4214-8d4e-499c-8626-0bfed5de9470	wlx30169d2252f8	1225	224	2026-01-24 18:46:59.472854+00	1022	186
8552ed8b-4263-475f-9d00-1330629b55ed	enp0s31f6	0	0	2026-01-24 20:57:32.138595+00	0	0
f7652186-22d8-4104-94c4-07c80fd8e7ce	wlx30169d2252f8	17596	12111	2026-01-24 20:57:32.141118+00	3355	2309
07581116-d738-4bae-87a7-65f49ffce3d2	enp0s31f6	0	0	2026-01-24 23:53:05.764337+00	0	0
d0c9992c-4e36-471f-bda4-3061fd07f91f	wlx30169d2252f8	34979	24077	2026-01-24 23:53:05.769926+00	11148	7674
70c9cfcd-60b6-43d7-b395-0094626dfce0	enp0s31f6	0	0	2026-01-24 15:51:56.217182+00	0	0
a968008c-5c8c-41c7-9f6f-3e28cab7b105	wlx30169d2252f8	242	224	2026-01-24 15:51:56.219525+00	494	457
3e50f651-d1fc-47d6-8230-4d00620a78ba	enp0s31f6	0	0	2026-01-24 18:47:29.486763+00	0	0
7177385b-a852-4f14-9a80-e4396df8eb36	wlx30169d2252f8	5365	11138	2026-01-24 18:47:29.491702+00	2161	4488
165d682d-e1ee-4805-96af-b80e2c3d2b0b	enp0s31f6	0	0	2026-01-24 20:58:02.131343+00	0	0
42ef7637-608c-4a5e-9f76-c4d1ff4d4128	wlx30169d2252f8	1884	730	2026-01-24 20:58:02.134589+00	985	381
2fae9683-12c6-405e-bbcd-d4c7e4922d07	enp0s31f6	0	0	2026-01-24 23:53:35.817547+00	0	0
f2918fa3-336b-4f86-b6e6-226eb68f0faf	wlx30169d2252f8	11548	11644	2026-01-24 23:53:35.825337+00	1288	1298
f5774b04-394c-4d5b-8a1a-b7d1acd7df8c	enp0s31f6	0	0	2026-01-24 15:52:26.270343+00	0	0
f66e3ba8-8841-4b0b-9f83-4bf9149e10ff	wlx30169d2252f8	94223	51731	2026-01-24 15:52:26.277653+00	3138	1723
7e964508-64dc-4e34-8dff-696e24a0f245	enp0s31f6	0	0	2026-01-24 18:47:59.483027+00	0	0
11ba754e-62d2-4570-bbd7-773f37cf4f8c	wlx30169d2252f8	865	224	2026-01-24 18:47:59.48879+00	740	191
73c257d7-e844-49d6-b47a-695477dbdc26	enp0s31f6	0	0	2026-01-24 20:58:32.1596+00	0	0
7ff2e2eb-b0bf-4dd2-b2da-fd1bb2292d44	wlx30169d2252f8	20010	12107	2026-01-24 20:58:32.163255+00	3805	2302
3787eb91-926b-4214-b702-0e63a9502010	enp0s31f6	0	0	2026-01-24 23:54:05.788021+00	0	0
6ae044ea-9ec2-4e9e-9b44-b0d859f79cd3	wlx30169d2252f8	26985	23920	2026-01-24 23:54:05.79172+00	8560	7588
decf8f9f-5fbc-4b0f-846a-f46a173e85e3	enp0s31f6	0	0	2026-01-24 15:52:56.223763+00	0	0
c01c304f-d189-467b-9330-6484edfea9a6	wlx30169d2252f8	224	224	2026-01-24 15:52:56.225569+00	485	485
81214b6b-e93b-41c7-9e8a-d84d0902c091	enp0s31f6	0	0	2026-01-24 18:48:29.535485+00	0	0
dccd7930-4526-4b97-a566-cc25d270bc7c	wlx30169d2252f8	5733	13901	2026-01-24 18:48:29.541816+00	2190	5312
f0efcf2c-c036-4f12-ac7c-eaf2ee6afaef	enp0s31f6	0	0	2026-01-24 20:59:02.153585+00	0	0
ed5aea73-98ed-4190-bcb5-128ec034c686	wlx30169d2252f8	1764	730	2026-01-24 20:59:02.15512+00	919	380
47f6fab7-076a-4114-8ea7-8d62419f6789	enp0s31f6	0	0	2026-01-24 23:54:35.802583+00	0	0
c7554838-a935-436d-aace-16b06e4703b2	wlx30169d2252f8	11728	13015	2026-01-24 23:54:35.806336+00	1305	1449
a2031128-858c-48a0-a722-64247d160a44	enp0s31f6	0	0	2026-01-24 15:53:26.261083+00	0	0
7e601958-c530-49b2-a92e-be9f27014c79	wlx30169d2252f8	89486	52250	2026-01-24 15:53:26.265452+00	2980	1740
8ae00e49-083d-481f-bdc3-b160b74c2270	enp0s31f6	0	0	2026-01-24 18:48:59.494261+00	0	0
929434cb-dfe5-4c09-999c-4904e72bf642	wlx30169d2252f8	857	224	2026-01-24 18:48:59.496473+00	735	192
283ba455-b199-49f3-b993-071fd255abe0	enp0s31f6	0	0	2026-01-24 20:59:32.219059+00	0	0
f4dc4355-eba5-4831-8714-893556562152	wlx30169d2252f8	18459	10951	2026-01-24 20:59:32.223656+00	3473	2060
b43f9476-79d7-466c-9cc9-cccde4dde011	enp0s31f6	0	0	2026-01-24 23:55:05.807766+00	0	0
22a1fba8-b80f-4e1f-8195-3f8e420ad2b2	wlx30169d2252f8	27491	24168	2026-01-24 23:55:05.813419+00	8655	7609
31b52e41-c1a5-4df2-8260-e7d8336c9aee	enp0s31f6	0	0	2026-01-24 15:53:56.257338+00	0	0
5f5a4d59-b4e5-42f7-af4c-2e74f3a9f9d1	wlx30169d2252f8	422	224	2026-01-24 15:53:56.262996+00	885	469
9cf808fc-2d1a-43f6-b03c-b37ce5379fc2	enp0s31f6	0	0	2026-01-24 18:49:29.516977+00	0	0
b6acae44-d5e6-405c-b69c-e8f77b530707	wlx30169d2252f8	5575	11368	2026-01-24 18:49:29.520303+00	2095	4272
67bf8964-8472-468a-8221-4efaabd0d61e	enp0s31f6	0	0	2026-01-24 21:00:02.175388+00	0	0
e57c905a-b95c-463a-bd8b-cf0218bde553	wlx30169d2252f8	1590	730	2026-01-24 21:00:02.177206+00	827	379
c28ad1e2-33b4-40f5-ae2b-dd992f4805a1	enp0s31f6	0	0	2026-01-24 23:55:35.860608+00	0	0
109b3662-801d-4cbe-b3c6-17f33416c9ee	wlx30169d2252f8	21597	14350	2026-01-24 23:55:35.869638+00	2402	1596
99096c23-92a9-4da7-b621-d0a9a7745976	enp0s31f6	0	0	2026-01-24 15:54:26.272338+00	0	0
0110a436-4e40-444a-9396-a54a2b579d8e	wlx30169d2252f8	66516	52321	2026-01-24 15:54:26.274948+00	2216	1743
4ddc2e1a-83e4-4568-9c95-95702a127d4d	enp0s31f6	0	0	2026-01-24 18:49:59.517759+00	0	0
15ffced0-83f8-4c32-9ce2-095a8651ac35	wlx30169d2252f8	865	224	2026-01-24 18:49:59.531191+00	740	191
2e14e95f-cdc0-4bf6-badc-cf370e4943c3	enp0s31f6	0	0	2026-01-24 21:00:32.242546+00	0	0
36f5485f-d2a5-4a67-87c5-d7b1a685cf52	wlx30169d2252f8	19174	13150	2026-01-24 21:00:32.249769+00	3597	2467
1897c8b3-5f6f-4710-8e3e-379aeb3ab3fc	enp0s31f6	0	0	2026-01-24 23:56:05.816152+00	0	0
25df07d4-1f6a-44fe-91a6-7c8fa62e645f	wlx30169d2252f8	27001	23865	2026-01-24 23:56:05.818038+00	8575	7579
686cf054-6140-417b-b744-b0fddd51e03d	enp0s31f6	0	0	2026-01-24 15:54:56.264168+00	0	0
bcb193a4-0c4a-4b7d-acda-a7e7adc0ecc6	wlx30169d2252f8	122	224	2026-01-24 15:54:56.265914+00	254	468
673277d8-c079-41c6-a282-590b3c4604da	enp0s31f6	0	0	2026-01-24 18:50:29.569942+00	0	0
de9ac08b-6fb9-4c16-8ed7-c1235c4aa753	wlx30169d2252f8	5239	11799	2026-01-24 18:50:29.573923+00	1983	4467
30a14671-3813-4b6a-850e-2d7b598018a7	enp0s31f6	0	0	2026-01-24 21:01:02.198135+00	0	0
06df5c9e-fda3-4deb-81b5-61549e62fbda	wlx30169d2252f8	1674	848	2026-01-24 21:01:02.201586+00	868	439
3c224612-a5ea-44db-8b32-ec386aab52fe	enp0s31f6	0	0	2026-01-24 23:56:35.844382+00	0	0
d9f26f25-ffd3-4f95-a51a-2e8c8d127d03	wlx30169d2252f8	14188	17633	2026-01-24 23:56:35.846574+00	1574	1957
4dc19290-e1d9-4222-ae28-789e69e3ad1c	enp0s31f6	0	0	2026-01-24 15:55:26.291253+00	0	0
378cd6dc-7956-4722-8036-ccae0b9e9b16	wlx30169d2252f8	87744	53345	2026-01-24 15:55:26.293761+00	2922	1777
0069f863-0a11-483c-a023-9cfa01a4c840	enp0s31f6	0	0	2026-01-24 18:50:59.54461+00	0	0
c9835219-4713-4e6b-bfac-6ca00324e69c	wlx30169d2252f8	1153	224	2026-01-24 18:50:59.549153+00	961	186
a35c7a94-585e-4bb4-a6bd-306b73bba70b	enp0s31f6	0	0	2026-01-24 21:01:32.225919+00	0	0
c4f65739-393e-4044-8a04-236c9e114ae7	wlx30169d2252f8	17394	12020	2026-01-24 21:01:32.229739+00	3254	2248
67e5fd6a-4364-4aa1-91b0-6e2dbd564c53	enp0s31f6	0	0	2026-01-24 23:57:05.853944+00	0	0
b9289666-f0cd-4e9e-8add-851913b045b5	wlx30169d2252f8	27109	23759	2026-01-24 23:57:05.859049+00	8540	7484
df51c802-ddce-4859-bc6d-26567355b094	enp0s31f6	0	0	2026-01-24 15:55:56.29847+00	0	0
eec6d647-a8ca-41ca-a987-0eee098beff0	wlx30169d2252f8	242	224	2026-01-24 15:55:56.302451+00	517	479
719d89f7-7442-48b9-8556-c488aa193b54	enp0s31f6	0	0	2026-01-24 18:51:29.55828+00	0	0
7a6887b7-d220-4baf-8290-a5079dd83a7d	wlx30169d2252f8	4735	13350	2026-01-24 18:51:29.562219+00	1796	5066
326fa034-6adb-4adc-a1eb-119e633a6893	enp0s31f6	0	0	2026-01-24 21:02:02.235352+00	0	0
6d45d934-0b0e-48b2-b577-0a2cf2a9fdf9	wlx30169d2252f8	1878	730	2026-01-24 21:02:02.240411+00	958	372
ff9cf304-7ef2-42ed-b006-9034c700b528	enp0s31f6	0	0	2026-01-24 23:57:35.906381+00	0	0
95d7c16a-44b5-4e9e-a1ab-0a2d8fafa40c	wlx30169d2252f8	19045	13175	2026-01-24 23:57:35.91363+00	2111	1460
521bc10c-f80e-40bd-adf5-9e6f45de0fc5	enp0s31f6	0	0	2026-01-24 15:56:26.348805+00	0	0
c9e23405-8d42-4838-955c-f7b6bce0cf0a	wlx30169d2252f8	80723	51924	2026-01-24 15:56:26.353051+00	2688	1729
70db14b8-f379-4479-bc78-27a7852d221d	enp0s31f6	0	0	2026-01-24 18:51:59.551396+00	0	0
17caed01-e35b-4960-8cc8-4c333edc6e62	wlx30169d2252f8	1395	306	2026-01-24 18:51:59.552774+00	1182	259
30b7162b-902c-4bfb-9231-ac69a18762de	enp0s31f6	0	0	2026-01-24 21:02:32.278133+00	0	0
9f86e0a0-b440-4ada-89ea-f2360ba2ba41	wlx30169d2252f8	18332	14171	2026-01-24 21:02:32.281297+00	3392	2622
eddd1039-8239-4857-90fb-19f2ed460e8d	enp0s31f6	0	0	2026-01-24 23:58:05.876987+00	0	0
890705c2-3802-4822-828d-0cf16a8c3242	wlx30169d2252f8	27362	24095	2026-01-24 23:58:05.88108+00	8616	7587
764196ba-2d9e-47cf-a0ed-0e291479c76c	enp0s31f6	0	0	2026-01-24 15:56:56.307123+00	0	0
482345a2-f8c2-418d-877f-e44f6cd1924b	wlx30169d2252f8	302	224	2026-01-24 15:56:56.309226+00	632	469
00dd1104-1d81-4c28-b109-db5dd348b95b	enp0s31f6	0	0	2026-01-24 18:52:29.602686+00	0	0
644030f0-2796-4257-8703-8f540680ca74	wlx30169d2252f8	6201	14060	2026-01-24 18:52:29.605664+00	2302	5221
0ea16e4d-4fb9-44fc-93e9-393521a43a85	enp0s31f6	0	0	2026-01-24 21:03:02.243813+00	0	0
43f6f776-0e31-48f5-a454-e4e82d5143cd	wlx30169d2252f8	9323	730	2026-01-24 21:03:02.247395+00	4710	368
b723ee3a-a1f0-47fc-a176-1abd9625ae87	enp0s31f6	0	0	2026-01-24 23:58:35.927838+00	0	0
b902fdf0-9d1b-4125-a046-10b4ce5fa5da	wlx30169d2252f8	11014	12143	2026-01-24 23:58:35.935126+00	1218	1343
286d4a10-93d9-4fe0-b36f-60b75116e11d	enp0s31f6	0	0	2026-01-24 15:57:26.360433+00	0	0
13c81823-b6ed-4db2-a721-e919fcca070e	wlx30169d2252f8	77632	52511	2026-01-24 15:57:26.367909+00	2585	1749
1e4ee788-5380-4bbe-9d97-d1cbb1fb0f08	enp0s31f6	0	0	2026-01-24 18:52:59.587154+00	0	0
446e083d-ab9c-4af2-8e58-1187bc2318bf	wlx30169d2252f8	1173	448	2026-01-24 18:52:59.591229+00	972	371
7f31442e-62f9-4128-ac6e-3c3c77a11a2e	enp0s31f6	0	0	2026-01-24 21:03:32.273692+00	0	0
20926e26-74b2-48e1-abd4-abeac4b0c83b	wlx30169d2252f8	17730	12104	2026-01-24 21:03:32.276763+00	3297	2251
7186651b-ee21-4854-83cf-97d7a79addc8	enp0s31f6	0	0	2026-01-24 23:59:05.902261+00	0	0
379912b6-e7a3-40d6-b5fd-214b2e9a3160	wlx30169d2252f8	27322	23929	2026-01-24 23:59:05.906016+00	8515	7457
c0805560-d697-4697-9886-04b12f0a9cd1	enp0s31f6	0	0	2026-01-24 15:57:56.329763+00	0	0
c021acb7-db38-4fa0-8017-7b159f862ddf	wlx30169d2252f8	302	224	2026-01-24 15:57:56.333977+00	621	460
e7f9e00f-ef5a-418d-b8df-ae0bc367cda2	enp0s31f6	0	0	2026-01-24 18:53:29.639245+00	0	0
9b328df7-7f89-42d2-9314-39affeccea11	wlx30169d2252f8	6941	14855	2026-01-24 18:53:29.646497+00	2541	5439
1e365099-3f70-413b-9898-62706f616d11	enp0s31f6	0	0	2026-01-24 21:04:02.271246+00	0	0
5410a78f-0c24-4c94-9a60-dfb010e70802	wlx30169d2252f8	1506	730	2026-01-24 21:04:02.276611+00	757	367
cbc541b6-ec07-4a96-b9ad-db3a2e0b633a	enp0s31f6	0	0	2026-01-24 23:59:35.95212+00	0	0
49da82cb-cadf-4f96-bb13-cef1e0523461	wlx30169d2252f8	13092	15981	2026-01-24 23:59:35.959358+00	1441	1759
2c54ae2e-8e7a-41a5-a1fa-1c13758679aa	enp0s31f6	0	0	2026-01-24 15:58:26.361915+00	0	0
a0d9112f-7f29-46c5-a4f5-4d160ee7eb49	wlx30169d2252f8	84543	55197	2026-01-24 15:58:26.373136+00	2817	1839
5f339c8f-9454-4e67-93e2-4225934bd840	enp0s31f6	0	0	2026-01-24 18:53:59.608928+00	0	0
20befaaa-ed1a-4ee8-9b2f-c1fcb205af70	wlx30169d2252f8	1253	448	2026-01-24 18:53:59.612713+00	1020	364
b14e418a-16e3-425d-b93c-0cb6e66f041a	enp0s31f6	0	0	2026-01-24 21:04:32.302761+00	0	0
edd095c6-e1b7-4867-82ef-a8cf77e7f260	wlx30169d2252f8	17452	12020	2026-01-24 21:04:32.306974+00	3268	2251
513cfe53-daee-4e7e-8f99-116c1014e0ab	enp0s31f6	0	0	2026-01-24 15:58:56.333264+00	0	0
786c31ea-ca51-4744-9779-2da360cd83fb	wlx30169d2252f8	182	224	2026-01-24 15:58:56.338924+00	384	473
9c59806e-ea56-4635-9f72-815d90ec6a98	enp0s31f6	0	0	2026-01-24 18:54:29.651087+00	0	0
078cb253-dd54-4bd3-9737-8db252f90bcf	wlx30169d2252f8	5081	12019	2026-01-24 18:54:29.654516+00	1858	4396
73e3417b-bbed-4d08-a83c-d4955654dffa	enp0s31f6	0	0	2026-01-24 21:05:02.301935+00	0	0
1c68a920-d7e2-4f61-809c-e0baea24ac8c	wlx30169d2252f8	1806	730	2026-01-24 21:05:02.307069+00	913	369
4f24b231-cd87-4b86-8de3-e11b82af927c	enp0s31f6	0	0	2026-01-24 15:59:26.365935+00	0	0
29ef1629-2037-4429-a41f-e67c90faf823	wlx30169d2252f8	87368	52005	2026-01-24 15:59:26.372566+00	2912	1733
0dc3572c-0334-4cfb-a248-72e522ae866f	enp0s31f6	0	0	2026-01-24 18:54:59.610443+00	0	0
7f45aeba-7924-4722-bdaa-41c2efaa34ea	wlx30169d2252f8	1557	448	2026-01-24 18:54:59.613442+00	1286	370
a651b876-1ea7-456e-b2f9-ef791048824c	enp0s31f6	0	0	2026-01-24 21:05:32.35431+00	0	0
a2bf2dc1-91a3-4282-8d66-0cdbd345266c	wlx30169d2252f8	21080	11048	2026-01-24 21:05:32.361651+00	3910	2049
08ec7f01-f402-4006-9726-20845c443d47	enp0s31f6	0	0	2026-01-24 15:59:56.33511+00	0	0
69abf64c-31d2-4449-aaeb-7cdfabbbbfa3	wlx30169d2252f8	182	224	2026-01-24 15:59:56.338928+00	385	474
c2944e7d-de9c-4ff1-8a28-0ad3d9d0eba6	enp0s31f6	0	0	2026-01-24 18:55:29.668521+00	0	0
0736519b-c115-46fd-a82a-2101e38c2eca	wlx30169d2252f8	5533	11143	2026-01-24 18:55:29.675594+00	2043	4115
653d3e83-2312-437c-bbb3-0ea16f3762e3	enp0s31f6	0	0	2026-01-24 21:06:02.309835+00	0	0
4991ece8-b04d-4efc-8cb8-5474d8ee6e7c	wlx30169d2252f8	1968	730	2026-01-24 21:06:02.311209+00	1000	371
7eb0fc99-c86d-4c32-912a-98d4e0cfdc46	enp0s31f6	0	0	2026-01-24 16:00:26.358817+00	0	0
b12bff57-8bff-49c1-9091-a7c39e4139ab	wlx30169d2252f8	88518	52119	2026-01-24 16:00:26.362561+00	2949	1736
16ae82bd-02bf-4bd5-b64c-7dcb65e510fe	enp0s31f6	0	0	2026-01-24 18:55:59.64702+00	0	0
379793a4-e7ac-4d40-92ad-9a06dd1525f1	wlx30169d2252f8	1031	448	2026-01-24 18:55:59.650672+00	827	359
587c41ab-e9b4-4777-8619-bef63fbf741a	enp0s31f6	0	0	2026-01-24 21:06:32.376296+00	0	0
9c99b487-689c-475f-ac9a-aa07c9d285a7	wlx30169d2252f8	21610	11705	2026-01-24 21:06:32.385165+00	3907	2116
57837e25-94e2-4acb-8b78-be4f8a76df39	enp0s31f6	0	0	2026-01-24 16:00:56.355856+00	0	0
86e90c86-00a2-4283-8b31-d3ce08d62b12	wlx30169d2252f8	520	306	2026-01-24 16:00:56.359923+00	1090	641
0abd51fa-8cae-4173-b4d1-45b034577fe3	enp0s31f6	0	0	2026-01-24 18:56:29.659853+00	0	0
21cbf5d3-36dd-4bcd-8808-95b99283678f	wlx30169d2252f8	4381	10012	2026-01-24 18:56:29.663635+00	1628	3721
9b6917af-4577-498c-820d-d1c070e1fb55	enp0s31f6	0	0	2026-01-24 21:07:02.350491+00	0	0
f76590af-3e9a-4d58-9d9f-01016f381a48	wlx30169d2252f8	3274	730	2026-01-24 21:07:02.355933+00	1634	364
c0a7c918-e768-4651-809f-cfaeee223889	enp0s31f6	0	0	2026-01-24 16:01:26.406648+00	0	0
e51075d8-8b3d-4178-8d0c-8ac7ac05acb1	wlx30169d2252f8	87760	52820	2026-01-24 16:01:26.414084+00	2923	1759
c5c8ae38-7537-4c37-8bc9-7f5f4fd99f34	enp0s31f6	0	0	2026-01-24 18:56:59.667858+00	0	0
58472b62-91a5-4418-b75f-71a75ef18874	wlx30169d2252f8	1159	448	2026-01-24 18:56:59.670799+00	927	358
7249033a-ff8a-4672-a147-433349b134f3	enp0s31f6	0	0	2026-01-24 21:07:32.399119+00	0	0
66134606-11bc-4121-b3b5-3e8b479142c7	wlx30169d2252f8	20623	16957	2026-01-24 21:07:32.409576+00	3738	3073
463e6469-6f4f-4487-92f3-4242c0ce75e6	enp0s31f6	0	0	2026-01-24 16:01:56.361729+00	0	0
9e95ecf2-a0f6-4e3f-8256-48a9463557ca	wlx30169d2252f8	2390	306	2026-01-24 16:01:56.363324+00	5187	664
ccefc375-e7b7-492f-8a4b-92193884a4c4	enp0s31f6	0	0	2026-01-24 18:57:29.721648+00	0	0
9eb97ec1-2c3c-47dc-8954-a939351df1c9	wlx30169d2252f8	4349	9696	2026-01-24 18:57:29.727413+00	1583	3530
71c01c0e-232c-4e54-bf21-d57d055a5faa	enp0s31f6	0	0	2026-01-24 21:08:02.368653+00	0	0
1eec3874-5e6c-4d32-a483-e7f952571629	wlx30169d2252f8	1632	730	2026-01-24 21:08:02.374343+00	815	364
979bb484-08d5-48d6-9e37-8a89604b53cf	enp0s31f6	0	0	2026-01-24 16:02:26.428495+00	0	0
89500390-90ee-42f7-8a94-82e9ef8caca1	wlx30169d2252f8	88716	52260	2026-01-24 16:02:26.435831+00	2953	1740
cdc41896-dae2-463a-a143-2de28d0b1b42	enp0s31f6	0	0	2026-01-24 18:57:59.675251+00	0	0
f6e49917-f37c-4fa5-917a-70c23a47f9d8	wlx30169d2252f8	1091	448	2026-01-24 18:57:59.676998+00	867	356
7c73aac6-0ffa-4f61-b5fe-d2d7764e8ba5	enp0s31f6	0	0	2026-01-24 21:08:32.420344+00	0	0
adcef14c-71ba-4c02-b0f8-22a7e5c38d57	wlx30169d2252f8	19624	12924	2026-01-24 21:08:32.4293+00	3508	2310
89bd6609-846e-4659-916f-2197382657b0	enp0s31f6	0	0	2026-01-24 16:02:56.397712+00	0	0
74e54ea0-b47d-485d-9dd9-984f3ec6c6eb	wlx30169d2252f8	278	82	2026-01-24 16:02:56.401886+00	581	171
184ce36f-77ba-48e4-9de2-1a9055f69ca0	enp0s31f6	0	0	2026-01-24 18:58:29.703498+00	0	0
98bafff7-20c2-4081-8bcd-57e0456c9b79	wlx30169d2252f8	4549	9791	2026-01-24 18:58:29.709576+00	1653	3559
88c88cc3-6f4e-4886-b84a-1b08b0e54971	enp0s31f6	0	0	2026-01-24 21:09:02.390064+00	0	0
b41cfc1c-53f4-4408-a92f-e13c4e02f068	wlx30169d2252f8	1710	730	2026-01-24 21:09:02.393759+00	853	364
fd9a79c0-8db7-4ab9-adb6-a505741c9533	enp0s31f6	0	0	2026-01-24 16:03:26.430535+00	0	0
08227ace-f6d9-4ed3-9708-69c86ea01348	wlx30169d2252f8	84937	51720	2026-01-24 16:03:26.437698+00	2830	1723
35c5a5c1-02b8-4848-bda7-451cf8bc3c21	enp0s31f6	0	0	2026-01-24 18:58:59.711589+00	0	0
2fd27bd7-f568-4546-b539-b1535daf10cc	wlx30169d2252f8	1235	448	2026-01-24 18:58:59.715382+00	987	358
245d0fb5-23d2-4ca2-962e-6e26e9ba95b9	enp0s31f6	0	0	2026-01-24 21:09:32.403609+00	0	0
86b52431-81e9-4a93-9bc8-64e4c1ef3659	wlx30169d2252f8	17596	14025	2026-01-24 21:09:32.405872+00	3177	2532
53eaacba-383e-4375-bfba-e113bb7d8a54	enp0s31f6	0	0	2026-01-24 16:03:56.4149+00	0	0
26ee9669-f683-4f9e-b0c4-a4c72fa27f4b	wlx30169d2252f8	158	82	2026-01-24 16:03:56.419015+00	333	173
286f56ff-6531-418b-aa1c-e306c2017ca1	enp0s31f6	0	0	2026-01-24 18:59:29.764237+00	0	0
3ce97119-949b-448a-a70b-26a911768301	wlx30169d2252f8	5965	12325	2026-01-24 18:59:29.771417+00	2134	4409
a07ce316-a90a-45ae-a384-0f3597fa9ce4	enp0s31f6	0	0	2026-01-24 21:10:02.411544+00	0	0
5ba61e9c-36c8-4298-adaa-cf66388ddf74	wlx30169d2252f8	1428	730	2026-01-24 21:10:02.416714+00	704	360
9e0c779a-6e31-44fa-8c36-71cca7294413	enp0s31f6	0	0	2026-01-24 16:04:26.428369+00	0	0
28ccce8f-70b5-499d-a433-db69903e53f7	wlx30169d2252f8	78211	52028	2026-01-24 16:04:26.430844+00	2606	1733
6295c063-307b-4806-bece-446abc3c7d13	enp0s31f6	0	0	2026-01-24 18:59:59.732598+00	0	0
63e26735-6125-4d36-8f3f-5ed45415e002	wlx30169d2252f8	1211	448	2026-01-24 18:59:59.736278+00	965	357
6305edc1-09f7-422e-a0fd-58fbd52d0836	enp0s31f6	0	0	2026-01-24 21:10:32.414693+00	0	0
f51994aa-e3b2-4209-8a9d-d8f4e8e55a1b	wlx30169d2252f8	19042	15249	2026-01-24 21:10:32.418326+00	3401	2723
68476330-bb3a-43b2-9112-67da02d2067c	enp0s31f6	0	0	2026-01-24 16:04:56.436105+00	0	0
bb8d5ce0-d86f-438f-b19f-0768236fc58c	wlx30169d2252f8	320	82	2026-01-24 16:04:56.440021+00	670	171
91a12949-d3b6-444e-a1bb-adc77fd0cc13	enp0s31f6	0	0	2026-01-24 19:00:29.785487+00	0	0
0c337315-a2d3-4164-8321-178c599542d4	wlx30169d2252f8	3789	8422	2026-01-24 19:00:29.793013+00	1307	2906
179c45c2-10be-4279-9327-58747b0b89ca	enp0s31f6	0	0	2026-01-24 21:11:02.422748+00	0	0
b3e024ae-3402-45e7-80fc-adc76408d5aa	wlx30169d2252f8	1626	730	2026-01-24 21:11:02.427975+00	810	363
efcd6dc9-b1af-4641-a9e4-2248ab3f4f30	enp0s31f6	0	0	2026-01-24 16:05:26.487194+00	0	0
43d39349-21f5-4282-9f36-cc6ad291a6ab	wlx30169d2252f8	82791	52797	2026-01-24 16:05:26.49478+00	2757	1758
e3a5a51a-75dd-4cea-8054-abaccc59ce65	enp0s31f6	0	0	2026-01-24 19:00:59.753923+00	0	0
1f091561-2f8c-491a-8d11-62465a0ab200	wlx30169d2252f8	1207	224	2026-01-24 19:00:59.758016+00	955	177
3e616a52-0aa1-4a65-a795-129cac0bfe95	enp0s31f6	0	0	2026-01-24 21:11:32.473846+00	0	0
0cf3e2ee-1c20-424a-8fc8-233b7aa2eeec	wlx30169d2252f8	17850	9373	2026-01-24 21:11:32.479872+00	3214	1687
7d85ba07-0c34-495a-ade7-d7085042ba53	enp0s31f6	0	0	2026-01-24 16:05:56.457258+00	0	0
ba91ed30-ebb0-48d5-98a9-81ea4e692722	wlx30169d2252f8	459	82	2026-01-24 16:05:56.461279+00	946	169
afd69972-8c5b-4b27-bd70-e090986bfee0	enp0s31f6	0	0	2026-01-24 19:01:29.783249+00	0	0
a01d5603-5c55-4f69-b3d2-5afea0342e99	wlx30169d2252f8	5411	10838	2026-01-24 19:01:29.789639+00	1882	3769
37ee75d3-a842-48e0-bff3-c85ea81641d9	enp0s31f6	0	0	2026-01-24 21:12:02.44413+00	0	0
ee865c73-68c9-4202-8ff7-d19e6e71ffe7	wlx30169d2252f8	1848	870	2026-01-24 21:12:02.447871+00	914	430
0f761d52-05af-44f5-a2d1-dd6e4aad7de2	enp0s31f6	0	0	2026-01-24 16:06:26.502257+00	0	0
9b6dddb5-d728-43ce-9765-7879d4e370af	wlx30169d2252f8	86531	52103	2026-01-24 16:06:26.50981+00	2883	1735
8d0d7223-df1a-4729-be79-294230fa6531	enp0s31f6	0	0	2026-01-24 19:01:59.769499+00	0	0
eb1eaaab-88d4-4fc8-87ba-6ac06ab326b5	wlx30169d2252f8	789	224	2026-01-24 19:01:59.774988+00	619	175
c73bc0ed-f3c7-48e9-ab7f-b44a752a08aa	enp0s31f6	0	0	2026-01-24 21:12:32.457759+00	0	0
71eb9673-4e4e-46a5-8fdb-4f1b56e8b99d	wlx30169d2252f8	18624	11868	2026-01-24 21:12:32.460564+00	3348	2133
cbd68bda-79f8-4a15-a9af-310e7d05c680	enp0s31f6	0	0	2026-01-24 16:06:56.471854+00	0	0
dc64483e-36c7-4d70-9934-7ac55c7fa8c8	wlx30169d2252f8	464	82	2026-01-24 16:06:56.475649+00	932	164
f54a3f55-66cb-4ba9-aeb8-208d0544c3ec	enp0s31f6	0	0	2026-01-24 19:02:29.824261+00	0	0
72c21390-507d-47a2-b55e-0abb1112e49c	wlx30169d2252f8	4483	10834	2026-01-24 19:02:29.82837+00	1542	3726
7aeaa15b-5877-42bd-b8ad-5d90030c3710	enp0s31f6	0	0	2026-01-24 21:13:02.465577+00	0	0
864d2247-3d49-44f5-9577-ddcadc91d8a3	wlx30169d2252f8	1752	730	2026-01-24 21:13:02.47127+00	864	360
461ff567-e95d-4ca6-b336-2e34a2fe3b6b	enp0s31f6	0	0	2026-01-24 16:07:26.489033+00	0	0
f8e8b8f6-baec-4f41-bcea-813c03c43e4f	wlx30169d2252f8	88124	53776	2026-01-24 16:07:26.491565+00	2936	1791
b7cae5c1-e150-4258-b93f-c17870087513	enp0s31f6	0	0	2026-01-24 19:02:59.783043+00	0	0
4630a1dd-f7dd-45a5-a9cd-a464fbae9982	wlx30169d2252f8	1089	224	2026-01-24 19:02:59.785454+00	855	176
39801a09-8ac8-4087-a32a-d8a4d7018e92	enp0s31f6	0	0	2026-01-24 21:13:32.516352+00	0	0
3f7c0298-6b94-48de-ae05-a087da0ea18d	wlx30169d2252f8	19928	13576	2026-01-24 21:13:32.525235+00	3532	2406
3f67a8da-97e3-4b13-a2a4-5a752f796252	enp0s31f6	0	0	2026-01-24 16:07:56.495288+00	0	0
0c9af296-d516-49f6-9dd0-9faa6a190221	wlx30169d2252f8	298	302	2026-01-24 16:07:56.499632+00	591	599
9ae33acb-5b6c-4266-b3fc-30cfdad77a10	enp0s31f6	0	0	2026-01-24 19:03:29.843383+00	0	0
628bfc85-9bbb-46f0-9ef5-a740e62d78ef	wlx30169d2252f8	6669	10839	2026-01-24 19:03:29.850835+00	2279	3704
d4234f37-c9eb-42ab-8b3b-dacc47251dea	enp0s31f6	0	0	2026-01-24 21:14:02.486292+00	0	0
d6651da3-1ee0-4511-970e-e5dda99ee09b	wlx30169d2252f8	1906	730	2026-01-24 21:14:02.491187+00	938	359
57647e68-3afd-4ef8-8c2b-313fb7fb5bd1	enp0s31f6	0	0	2026-01-24 16:08:26.545589+00	0	0
e9c2926f-696c-4f5b-a65f-0a11f2ac22ef	wlx30169d2252f8	109519	55462	2026-01-24 16:08:26.552806+00	3648	1847
f7cc721e-ecbf-4dc9-b8e7-b6108a97b9b7	enp0s31f6	0	0	2026-01-24 19:03:59.811737+00	0	0
30947c16-b41f-4c8f-b68d-7acc427ab894	wlx30169d2252f8	943	224	2026-01-24 19:03:59.815532+00	726	172
a230aa4a-f5c1-410e-a181-e453a68b521e	enp0s31f6	0	0	2026-01-24 21:14:32.529054+00	0	0
48f3b15a-5b36-41d6-b421-6afbef275e92	wlx30169d2252f8	25947	12837	2026-01-24 21:14:32.537762+00	4590	2271
6eb08a67-26a5-45a0-a364-7fa81f827fea	enp0s31f6	0	0	2026-01-24 16:08:56.507242+00	0	0
b0bbbbf9-836b-429b-a69f-ab86931c805b	wlx30169d2252f8	444	164	2026-01-24 16:08:56.510421+00	891	329
84513e56-ff11-4f88-87e9-8ac3e92fa52d	enp0s31f6	0	0	2026-01-24 19:04:29.827491+00	0	0
ba514b42-0964-478c-a12f-00880f2d8f12	wlx30169d2252f8	12664	11149	2026-01-24 19:04:29.829859+00	4339	3820
a847e9ce-3664-4359-bbe6-deef01ce9b0f	enp0s31f6	0	0	2026-01-24 21:15:02.484593+00	0	0
83608b66-d776-4a65-999e-d44adb5b8fd0	wlx30169d2252f8	1506	730	2026-01-24 21:15:02.48616+00	749	363
4c6a1660-3105-4ff2-bc12-bf2d78ec6cd7	enp0s31f6	0	0	2026-01-24 16:09:26.564498+00	0	0
46fddb6b-9c7d-4cf4-a790-d341a5f2d19c	wlx30169d2252f8	91120	52634	2026-01-24 16:09:26.572003+00	3034	1752
c63c0c99-116f-46ac-921b-a77bfe3c0284	enp0s31f6	0	0	2026-01-24 19:04:59.83301+00	0	0
402a5e80-6175-40e9-b8f1-143ce946ba3f	wlx30169d2252f8	833	224	2026-01-24 19:04:59.836684+00	649	174
ce4234b1-cf7a-4b58-b27c-c4b4b49a2a90	enp0s31f6	0	0	2026-01-24 21:15:32.550014+00	0	0
7fb4d026-1434-4c85-a837-250a83409393	wlx30169d2252f8	18316	11868	2026-01-24 21:15:32.558288+00	3254	2108
89a29bf7-59c7-4e03-a5dd-62fe0cc298e0	enp0s31f6	0	0	2026-01-24 16:09:56.533903+00	0	0
2c928bab-4153-4c28-abc9-c06270954f20	wlx30169d2252f8	445	164	2026-01-24 16:09:56.538062+00	859	316
68153de3-b958-4df1-a4bf-6b106494481b	enp0s31f6	0	0	2026-01-24 19:05:29.884258+00	0	0
59aab8a2-5ea3-453d-aa71-f7240e1293a2	wlx30169d2252f8	4635	11199	2026-01-24 19:05:29.893523+00	1577	3810
f8c16487-f1a5-4ab7-a05b-6fb1fd4fbc81	enp0s31f6	0	0	2026-01-24 21:16:02.522239+00	0	0
8ba0dc3e-e23e-43dd-a06b-a389f1a79035	wlx30169d2252f8	1954	730	2026-01-24 21:16:02.527519+00	961	359
410626f8-d626-4ccb-8da7-267148648304	enp0s31f6	0	0	2026-01-24 16:10:26.551395+00	0	0
f7d8994a-1ecc-4ece-ab2f-8cf0884a1b92	wlx30169d2252f8	88538	51363	2026-01-24 16:10:26.554721+00	2950	1711
7ed49338-dda6-4890-8d2c-e3b38142b366	enp0s31f6	0	0	2026-01-24 19:05:59.851505+00	0	0
6a3bd2ba-18e1-49f9-a99b-9350d3ecbde8	wlx30169d2252f8	943	224	2026-01-24 19:05:59.85532+00	733	174
3b163350-8daf-4ab8-ab94-a14e730e365c	enp0s31f6	0	0	2026-01-24 21:16:32.572341+00	0	0
ae5c08fd-8554-466a-8b4f-1465b67588d1	wlx30169d2252f8	19672	14713	2026-01-24 21:16:32.580209+00	3490	2610
1143ea51-2548-4074-a6cb-56f1691c1cb8	enp0s31f6	0	0	2026-01-24 16:10:56.557608+00	0	0
107867ca-d315-464b-a70e-c3e70e7c903b	wlx30169d2252f8	324	160	2026-01-24 16:10:56.563491+00	589	291
7a2d8f59-10a7-4f89-b262-8ba9c24f21db	enp0s31f6	0	0	2026-01-24 19:06:29.870939+00	0	0
6473e091-1db5-4fda-9aaa-647f277a33c5	wlx30169d2252f8	4861	11058	2026-01-24 19:06:29.874649+00	1626	3701
0dce2ced-2936-4352-9341-6a26195edb8b	enp0s31f6	0	0	2026-01-24 21:17:02.542302+00	0	0
0535d6c1-af57-4e4b-b31d-f437a9abbe3e	wlx30169d2252f8	4016	730	2026-01-24 21:17:02.545428+00	1940	352
4a9b0e1a-cc5e-46de-9bd7-b7dad2a2af97	enp0s31f6	0	0	2026-01-24 16:11:26.605913+00	0	0
26bf2235-413d-4826-b546-7b2c6837c9df	wlx30169d2252f8	78490	51904	2026-01-24 16:11:26.613403+00	2614	1729
ea57cf96-020b-41cd-b86e-04bc2fe4353c	enp0s31f6	0	0	2026-01-24 19:06:59.872891+00	0	0
7324b457-c18c-406a-944a-aa0cc8e9e866	wlx30169d2252f8	1021	224	2026-01-24 19:06:59.876742+00	769	168
b140e12a-eab8-4d15-bdb1-0215392743dd	enp0s31f6	0	0	2026-01-24 21:17:32.593875+00	0	0
09704c90-3686-49ef-87ee-9ff71ffe0b0a	wlx30169d2252f8	19938	15984	2026-01-24 21:17:32.601072+00	3509	2813
f0620d49-2fd3-405a-8f59-0c2fda4e86d9	enp0s31f6	0	0	2026-01-24 16:11:56.573285+00	0	0
d7dd1f44-4d6e-41cd-88d8-8fa367f9f236	wlx30169d2252f8	384	164	2026-01-24 16:11:56.575785+00	3619	1545
16a4850e-99cb-40e4-b98f-76446c3907f0	enp0s31f6	0	0	2026-01-24 19:07:29.886651+00	0	0
c217da3e-37be-4534-9074-709f5c48cdbc	wlx30169d2252f8	5813	13021	2026-01-24 19:07:29.88883+00	1968	4409
a440fa1b-c2fe-45d4-a3e8-63619256347e	enp0s31f6	0	0	2026-01-24 21:18:02.546189+00	0	0
c88d011b-a1fa-423f-8f4b-28164926eb93	wlx30169d2252f8	9849	730	2026-01-24 21:18:02.549493+00	4844	359
e7a2160d-1012-4e60-9cb9-8c6d58270c26	enp0s31f6	0	0	2026-01-24 16:12:26.627344+00	0	0
8701a9b9-7407-4af8-be7f-f129a261cc1d	wlx30169d2252f8	79652	51973	2026-01-24 16:12:26.631827+00	2653	1731
901ee878-3f84-4289-bbd9-0e36a9138440	enp0s31f6	0	0	2026-01-24 19:07:59.89262+00	0	0
258e39c2-f83f-408b-87a9-7b4d85f04e26	wlx30169d2252f8	1559	224	2026-01-24 19:07:59.895501+00	1193	171
35992d7f-e2aa-4bb0-ad62-1b6628a20b26	enp0s31f6	0	0	2026-01-24 21:18:32.613686+00	0	0
947cae83-684f-48fc-8f42-823ff6e2c200	wlx30169d2252f8	19433	14153	2026-01-24 21:18:32.621071+00	3432	2499
3bf87015-5304-4d15-b366-0f0535101c4b	enp0s31f6	0	0	2026-01-24 16:12:56.580057+00	0	0
dd093091-1439-486b-af30-2cc8a6242798	wlx30169d2252f8	264	164	2026-01-24 16:12:56.581826+00	498	309
ff8ee324-d72c-4267-be50-12c15f643ba8	enp0s31f6	0	0	2026-01-24 19:08:29.931129+00	0	0
df7d4ccb-9c1f-4106-83c9-fa7e8e596d85	wlx30169d2252f8	7637	18178	2026-01-24 19:08:29.934627+00	2549	6067
35d53e50-29b1-4b05-bc84-a2084c95386c	enp0s31f6	0	0	2026-01-24 21:19:02.583002+00	0	0
47b84653-e181-4f29-ac97-a840a55eb558	wlx30169d2252f8	1924	648	2026-01-24 21:19:02.586724+00	938	316
0e94e31d-9747-43e6-acd7-cbb573e627e1	enp0s31f6	0	0	2026-01-24 16:13:26.613352+00	0	0
b38a64e1-ad27-4ffe-8a69-f3499195834e	wlx30169d2252f8	98582	53558	2026-01-24 16:13:26.616268+00	3283	1783
2822d194-8dff-4256-8e77-9f1ead622408	enp0s31f6	0	0	2026-01-24 19:08:59.917592+00	0	0
9e1ab28e-467e-4063-a2a0-dea25a5eb9d4	wlx30169d2252f8	1087	224	2026-01-24 19:08:59.922746+00	816	168
4d83f958-cb83-4234-9573-8f3bfeec2c77	enp0s31f6	0	0	2026-01-24 21:19:32.636083+00	0	0
d746a9f7-0973-4466-9fbf-690c5d590671	wlx30169d2252f8	18749	14810	2026-01-24 21:19:32.643211+00	3251	2568
1859009c-3bb1-4223-a388-24fd8dab0e0d	enp0s31f6	0	0	2026-01-24 16:13:56.611824+00	0	0
00b9b665-c7fb-48db-9ef8-73e3fc277eb0	wlx30169d2252f8	648	164	2026-01-24 16:13:56.615711+00	1156	292
0ec6b1be-d162-4efa-8778-fd8b261ce02d	enp0s31f6	0	0	2026-01-24 19:09:29.96953+00	0	0
5ed9f258-5329-4054-a2cf-7f3241d43387	wlx30169d2252f8	5949	11371	2026-01-24 19:09:29.978547+00	1953	3734
b589715e-1220-4610-b804-aaa464635a9a	enp0s31f6	0	0	2026-01-24 21:20:02.603821+00	0	0
5cc51004-4aef-4b34-806c-a22bbba4030f	wlx30169d2252f8	1746	730	2026-01-24 21:20:02.60962+00	846	354
cfb87947-e262-40d2-b699-563da3480d6d	enp0s31f6	0	0	2026-01-24 16:14:26.65759+00	0	0
8b832fd6-43a2-48d7-ab24-f6a93874e0b3	wlx30169d2252f8	87943	52470	2026-01-24 16:14:26.664897+00	2929	1748
29a1d6f3-0f8b-429e-912b-d5862364e56d	enp0s31f6	0	0	2026-01-24 19:09:59.938284+00	0	0
6960edc7-8349-4a5d-90ad-7b4e7fe21898	wlx30169d2252f8	1373	224	2026-01-24 19:09:59.94189+00	1032	168
07497372-b1b2-4ced-ae5f-7ab1b884f702	enp0s31f6	0	0	2026-01-24 21:20:32.65615+00	0	0
339472e7-9bd6-41c1-9896-523b65f37dbd	wlx30169d2252f8	20539	15532	2026-01-24 21:20:32.664447+00	3525	2666
b6250245-dbdc-40de-b874-1df5bf5d9193	enp0s31f6	0	0	2026-01-24 16:14:56.612886+00	0	0
c258b8a6-dedc-4bf7-a1ed-650751c91dc3	wlx30169d2252f8	204	164	2026-01-24 16:14:56.614749+00	389	313
9ed05b92-8c41-458a-b4d8-d1700a23540c	enp0s31f6	0	0	2026-01-24 19:10:29.951737+00	0	0
07e35838-ea50-4176-ba43-6d0482396b1c	wlx30169d2252f8	4815	15029	2026-01-24 19:10:29.954288+00	1573	4912
a8ce2ef3-a125-4e72-804b-2275cfd2e788	enp0s31f6	0	0	2026-01-24 21:21:02.626619+00	0	0
49233737-3b85-4a2b-b801-818d425424f2	wlx30169d2252f8	1814	730	2026-01-24 21:21:02.6307+00	868	349
7ae07da2-984c-4cd5-870d-4bcec1f9db9f	enp0s31f6	0	0	2026-01-24 16:15:26.675325+00	0	0
d3a87075-0bb8-4808-abf3-e4473c81a4b2	wlx30169d2252f8	93355	52975	2026-01-24 16:15:26.680911+00	3108	1763
4ceb73ad-7c8a-4da1-9718-4ef502fcf041	enp0s31f6	0	0	2026-01-24 19:10:59.945195+00	0	0
5fae94e9-3b7b-46a7-b0c7-4ddf43038c38	wlx30169d2252f8	1163	224	2026-01-24 19:10:59.948399+00	890	171
f13ac594-889a-40e2-bd00-6c5f804685ee	enp0s31f6	0	0	2026-01-24 21:21:32.671447+00	0	0
42f1f896-ab7a-42ed-b543-d71ff8c3d398	wlx30169d2252f8	26438	12764	2026-01-24 21:21:32.678671+00	4551	2197
30c33dd4-da2f-4110-84f6-780764a7af05	enp0s31f6	0	0	2026-01-24 16:15:56.646801+00	0	0
e7115d00-7b7a-4cb1-81e8-180a40bf4ab2	wlx30169d2252f8	444	164	2026-01-24 16:15:56.652411+00	830	306
9f7f7c59-3d41-4344-a117-e13be54e2c18	enp0s31f6	0	0	2026-01-24 19:11:30.002718+00	0	0
9934ae26-4d58-473e-9108-536c8ee910df	wlx30169d2252f8	4675	9702	2026-01-24 19:11:30.008027+00	1521	3157
14b62b3c-2427-462e-a80b-5528bfb801bd	enp0s31f6	0	0	2026-01-24 21:22:02.641608+00	0	0
2bd6ddd5-3177-4b34-b583-02605c27a732	wlx30169d2252f8	1362	730	2026-01-24 21:22:02.646592+00	649	348
5a52cd08-a07b-4062-ad9a-eb055e4997a6	enp0s31f6	0	0	2026-01-24 16:16:26.662749+00	0	0
9c28c931-3185-4bdd-9b1a-57cd2491287b	wlx30169d2252f8	89341	51844	2026-01-24 16:16:26.665416+00	2977	1727
fae4d0b0-3af3-4833-a93e-9959abf2352c	enp0s31f6	0	0	2026-01-24 19:11:59.960385+00	0	0
2c38a545-22df-43f3-82a4-6f132b20614e	wlx30169d2252f8	1247	364	2026-01-24 19:11:59.961771+00	950	277
770b16e7-0de7-48c3-9f18-192c4e906757	enp0s31f6	0	0	2026-01-24 21:22:32.678704+00	0	0
0e1464fd-7bb3-4cc5-b007-d4326cad6cdb	wlx30169d2252f8	18874	12637	2026-01-24 21:22:32.686521+00	3255	2179
59439707-2301-4fee-861e-6ce0f7770a88	enp0s31f6	0	0	2026-01-24 16:16:56.663075+00	0	0
46e9fd8c-2114-4718-8c21-b404164ba423	wlx30169d2252f8	384	164	2026-01-24 16:16:56.665396+00	698	298
d3c3b980-3378-483c-9855-c502256901d7	enp0s31f6	0	0	2026-01-24 19:12:30.024906+00	0	0
1526f2cf-3e13-4b08-8ba6-1e10ec162497	wlx30169d2252f8	4553	10016	2026-01-24 19:12:30.030585+00	1505	3311
68eeee43-bb19-4e23-94eb-654168b11ee0	enp0s31f6	0	0	2026-01-24 21:23:02.633821+00	0	0
266dab32-765a-44c2-8829-cf0616f7800c	wlx30169d2252f8	1686	730	2026-01-24 21:23:02.636851+00	819	354
55401ca4-bf18-44d7-8fff-8c508d538809	enp0s31f6	0	0	2026-01-24 16:17:26.715211+00	0	0
fb661f80-dfbc-42c7-83ac-11c80bd01e31	wlx30169d2252f8	89095	52915	2026-01-24 16:17:26.721436+00	2967	1762
e50b634a-960c-4fd6-ad55-d0863a451e78	enp0s31f6	0	0	2026-01-24 19:12:59.982289+00	0	0
a4af7f69-9cf4-415f-83af-9c37617d83db	wlx30169d2252f8	1343	224	2026-01-24 19:12:59.984931+00	1015	169
6253a52e-fa4d-4c9b-a624-70ed4e078b97	enp0s31f6	0	0	2026-01-24 21:23:32.70149+00	0	0
32348929-066b-475d-ad06-65bbc34b13ae	wlx30169d2252f8	18211	13079	2026-01-24 21:23:32.707243+00	3130	2248
f8dfe46b-ec54-414c-b0e3-9791abb5ffd9	enp0s31f6	0	0	2026-01-24 16:17:56.684462+00	0	0
03f1ec80-2b25-4a51-9da9-4b732d76f0c0	wlx30169d2252f8	454	486	2026-01-24 16:17:56.688686+00	819	876
0c8ed91f-4541-47e9-bbc6-cacb7db328c3	enp0s31f6	0	0	2026-01-24 19:13:30.049437+00	0	0
3ad9a75b-c8f0-4f7e-bc1d-0eded59b042c	wlx30169d2252f8	5517	11149	2026-01-24 19:13:30.057489+00	1794	3625
e77945ac-2d3e-46c7-94d8-e7d326354c69	enp0s31f6	0	0	2026-01-24 21:24:02.660373+00	0	0
3ed463c1-d5f6-4926-b895-5e2976f8f64d	wlx30169d2252f8	1734	730	2026-01-24 21:24:02.662676+00	839	353
95f0a9f1-1d4f-4b49-a0d3-4078ba1f82e2	enp0s31f6	0	0	2026-01-24 16:18:26.698058+00	0	0
19bcca9e-bb77-4c49-b7ea-8aae6dd7451d	wlx30169d2252f8	84611	55191	2026-01-24 16:18:26.700432+00	2819	1839
ae82a301-c3b1-4d0b-83ef-6917f3fd5798	enp0s31f6	0	0	2026-01-24 19:14:00.016117+00	0	0
f3d90bdb-b767-4292-a8eb-d01fac481e94	wlx30169d2252f8	1205	224	2026-01-24 19:14:00.019776+00	901	167
21c9ebe9-d93f-4e1d-909b-4eeb33c4d1f5	enp0s31f6	0	0	2026-01-24 21:24:32.68318+00	0	0
7a51e483-ad4a-4420-a2af-03be44cf1f01	wlx30169d2252f8	20674	13940	2026-01-24 21:24:32.686946+00	3536	2384
ba8ea246-5e3c-4b3c-a99a-51dac411e791	enp0s31f6	0	0	2026-01-24 16:18:56.690253+00	0	0
4ec83144-5317-4de3-89dd-037cca7478dd	wlx30169d2252f8	626	246	2026-01-24 16:18:56.693066+00	1101	433
65e9b66e-c392-4a1a-8785-d827806ec76c	enp0s31f6	0	0	2026-01-24 19:14:30.061975+00	0	0
a2df42f1-d2bc-4794-921d-96275774d504	wlx30169d2252f8	4675	10216	2026-01-24 19:14:30.065758+00	1534	3353
b4c42139-9562-4df2-9777-1c534f3f4091	enp0s31f6	0	0	2026-01-24 21:25:02.692631+00	0	0
6fd3356a-a0d1-4a0f-97f7-4d08dd567455	wlx30169d2252f8	8462	730	2026-01-24 21:25:02.696396+00	4039	348
ec2ee44d-6a01-45cd-823b-4e5a37a69516	enp0s31f6	0	0	2026-01-24 16:19:26.736576+00	0	0
538f206f-ddf9-47b3-ade3-072b96ffd1c3	wlx30169d2252f8	80931	53081	2026-01-24 16:19:26.745442+00	2696	1768
7679af39-3506-4f79-a71c-5dd5ed305b31	enp0s31f6	0	0	2026-01-24 19:15:00.038247+00	0	0
a512a4bd-d3a5-4490-8a24-d4e5dab2fb42	wlx30169d2252f8	1145	350	2026-01-24 19:15:00.041874+00	855	261
172feb81-feac-4e35-a5e8-9c606b07256e	enp0s31f6	0	0	2026-01-24 21:25:32.714728+00	0	0
a6b068cf-d726-4b6e-a03a-2bd0f098b3b9	wlx30169d2252f8	19973	17930	2026-01-24 21:25:32.718164+00	3429	3078
2e968c04-9a2f-4bf3-97a9-fabfd50c8cf3	enp0s31f6	0	0	2026-01-24 16:19:56.692706+00	0	0
76795467-f2f7-42a7-b58f-dbec95852b19	wlx30169d2252f8	632	388	2026-01-24 16:19:56.694736+00	1179	724
9f9d71ee-a6ac-4f08-b81c-52241b02bffc	enp0s31f6	0	0	2026-01-24 19:15:30.077624+00	0	0
49d95cf6-58d8-4e4a-9770-22356cc44cba	wlx30169d2252f8	11093	11186	2026-01-24 19:15:30.08076+00	3476	3506
3ea6f1e3-486d-4ac0-aa62-388cbc93033e	enp0s31f6	0	0	2026-01-24 21:26:02.713787+00	0	0
7d547c69-03ec-4cc7-9668-a716d7914bba	wlx30169d2252f8	2094	730	2026-01-24 21:26:02.717489+00	994	346
d2d58de0-1e94-4d8a-9db3-9cda72b71cca	enp0s31f6	0	0	2026-01-24 16:20:26.723872+00	0	0
b75125e2-d3dd-458d-a904-57c2afc4d900	wlx30169d2252f8	77626	52608	2026-01-24 16:20:26.72697+00	2585	1752
3a38342b-4017-4e8b-8c5b-b651dbdab89a	enp0s31f6	0	0	2026-01-24 19:16:00.044927+00	0	0
76f2347e-edb3-4e42-9ee2-5e474191c785	wlx30169d2252f8	1103	350	2026-01-24 19:16:00.046427+00	815	258
4bf3d978-6022-42a9-a8f1-9bbfc0a56765	enp0s31f6	0	0	2026-01-24 21:26:32.753267+00	0	0
5da4f309-3dc3-4f1f-a931-db8cf47f3e99	wlx30169d2252f8	19873	13658	2026-01-24 21:26:32.756864+00	3388	2328
e13a2cbe-740e-448e-a1f2-33ec18cf1bad	enp0s31f6	0	0	2026-01-24 16:20:56.7169+00	0	0
3326ecd6-83a2-446e-9f79-237e72bfa95c	wlx30169d2252f8	632	388	2026-01-24 16:20:56.721144+00	1169	718
514622bc-aa6c-412f-8422-61fe5cf335ff	enp0s31f6	0	0	2026-01-24 19:16:30.111195+00	0	0
d25624d8-6fc6-4d75-8642-84db870c7364	wlx30169d2252f8	5007	13062	2026-01-24 19:16:30.117728+00	1630	4253
66992a08-cd34-4953-a9bd-6ce8d1d1167b	enp0s31f6	0	0	2026-01-24 21:27:02.736199+00	0	0
a68a7915-9dc3-41f4-b05a-9d0f67bacef7	wlx30169d2252f8	2298	730	2026-01-24 21:27:02.739754+00	1082	343
e4dbd92d-efd9-4e95-b51e-33fab2f204ac	enp0s31f6	0	0	2026-01-24 16:21:26.734808+00	0	0
93324702-ac1e-446c-b230-42e6a2a64e77	wlx30169d2252f8	89285	53083	2026-01-24 16:21:26.738902+00	2975	1768
39cb5454-a7b7-4446-842b-502d815aae0d	enp0s31f6	0	0	2026-01-24 19:17:00.081386+00	0	0
4fccf969-586e-4d07-93eb-04ece8ed6b3f	wlx30169d2252f8	1283	350	2026-01-24 19:17:00.083658+00	945	257
ca943b7e-8d84-48e2-83b6-f783f151fc9b	enp0s31f6	0	0	2026-01-24 21:27:32.789019+00	0	0
3f4f9cd2-9a94-455e-bdb9-5d64092c20f7	wlx30169d2252f8	24917	14584	2026-01-24 21:27:32.796135+00	4253	2489
c57cf05b-686c-43fa-ae3a-9777e45c041e	enp0s31f6	0	0	2026-01-24 16:21:56.741888+00	0	0
32911698-3311-46bc-a6db-72a27480beaf	wlx30169d2252f8	812	388	2026-01-24 16:21:56.745791+00	1439	687
2ed0fa6a-3e21-475f-9460-bd5936541a2d	enp0s31f6	0	0	2026-01-24 19:17:30.133282+00	0	0
d934deb4-aa59-46e0-a2f9-5252dd8cd844	wlx30169d2252f8	4999	11924	2026-01-24 19:17:30.140712+00	1567	3737
f5ab890c-3294-4fa6-9945-709bed820196	enp0s31f6	0	0	2026-01-24 21:28:02.756776+00	0	0
e63541ed-7f9a-4cee-b101-cc532b772adc	wlx30169d2252f8	2034	730	2026-01-24 21:28:02.764849+00	956	343
c2dd3cab-ed95-46e4-9066-1ae85e64a389	enp0s31f6	0	0	2026-01-24 16:22:26.774706+00	0	0
d1e6ed31-ce31-4903-91e8-98df70b8ed65	wlx30169d2252f8	89393	52003	2026-01-24 16:22:26.782134+00	2979	1733
0d193520-69b7-43de-bca1-00a874e201d8	enp0s31f6	0	0	2026-01-24 19:18:00.102764+00	0	0
bb248338-29e5-4d0e-81cb-f365cbbb3144	wlx30169d2252f8	1463	350	2026-01-24 19:18:00.108081+00	1073	256
578d88a7-9f0a-4392-b077-a50007b177f6	enp0s31f6	0	0	2026-01-24 21:28:32.77376+00	0	0
f2a9d65e-3650-41e4-98fe-f59e99f44c21	wlx30169d2252f8	19317	12774	2026-01-24 21:28:32.77848+00	3294	2178
1c811578-8575-4920-a68c-4fb06c1bfff0	enp0s31f6	0	0	2026-01-24 16:22:56.743804+00	0	0
f3eb37a2-32df-4786-b7cc-4ae9fd9c2dcd	wlx30169d2252f8	572	388	2026-01-24 16:22:56.748316+00	1043	707
736a6634-a5da-4532-af4e-c574adc4a531	enp0s31f6	0	0	2026-01-24 19:18:30.147829+00	0	0
a2b1d6d4-b3b5-4180-ab93-d23f0fcd5b78	wlx30169d2252f8	4989	11283	2026-01-24 19:18:30.155542+00	1531	3464
9da5f239-3532-4902-9737-1034c9740491	enp0s31f6	0	0	2026-01-24 21:29:02.77513+00	0	0
fb5ba164-36f6-4eae-923d-4b6b2c4b4423	wlx30169d2252f8	1728	730	2026-01-24 21:29:02.780945+00	806	340
2764029c-111a-4989-b9a8-f2cdcc8d9f25	enp0s31f6	0	0	2026-01-24 16:23:26.794259+00	0	0
95ce6448-7ba1-4a51-b38d-83ff0fd17f12	wlx30169d2252f8	87532	52336	2026-01-24 16:23:26.801745+00	2915	1743
961e42d4-f718-4562-bc97-324f6495a12c	enp0s31f6	0	0	2026-01-24 19:19:00.116062+00	0	0
b79ad786-9d51-403d-a827-5b4b33461c56	wlx30169d2252f8	1367	350	2026-01-24 19:19:00.119715+00	1017	260
3f5c2fff-6b0c-4be9-891b-30baf5dde15b	enp0s31f6	0	0	2026-01-24 21:29:32.798075+00	0	0
c217695c-bb56-4c9d-b8dd-ea6abd93a37f	wlx30169d2252f8	25872	14990	2026-01-24 21:29:32.800684+00	4402	2550
642c42ea-ca13-4536-88bc-83ad49020080	enp0s31f6	0	0	2026-01-24 16:23:56.763992+00	0	0
2ff80085-3645-47c8-b439-84a1cff0b58a	wlx30169d2252f8	2383	388	2026-01-24 16:23:56.768101+00	4247	691
4442f90e-4ce7-44e2-adeb-88d24881249d	enp0s31f6	0	0	2026-01-24 19:19:30.168453+00	0	0
f8ca62d2-fde1-40da-b0cc-94cbf5c3d43b	wlx30169d2252f8	4929	10528	2026-01-24 19:19:30.174545+00	1535	3279
576127f5-8c76-4912-b5b5-ea698394e8e4	enp0s31f6	0	0	2026-01-24 21:30:02.798204+00	0	0
283c3ecd-3ce5-497e-b399-8472608f146f	wlx30169d2252f8	1848	730	2026-01-24 21:30:02.802034+00	862	340
0aa8c0de-e302-481c-85b2-78d0115b3349	enp0s31f6	0	0	2026-01-24 16:24:26.817353+00	0	0
c219e07b-2980-471d-a2ad-3480bcac15d9	wlx30169d2252f8	99000	52408	2026-01-24 16:24:26.824825+00	3297	1745
1e5b625b-aa31-4e94-aa26-bb6f852d9b11	enp0s31f6	0	0	2026-01-24 19:20:00.136783+00	0	0
3f57ff3b-881b-4395-a4b4-39be63b9bdbd	wlx30169d2252f8	1385	350	2026-01-24 19:20:00.140471+00	1021	258
0f7f9245-15bc-42b1-b966-8e3aba2f3a48	enp0s31f6	0	0	2026-01-24 21:30:32.811994+00	0	0
0162eed9-9137-44d1-aa5b-1b22d333ba6c	wlx30169d2252f8	18189	12605	2026-01-24 21:30:32.815654+00	3072	2129
54754be0-f081-41f2-9ae5-f508d5a50e43	enp0s31f6	0	0	2026-01-24 16:24:56.784266+00	0	0
96d3eeaa-e525-4854-ba07-a6288d3cd1a3	wlx30169d2252f8	932	388	2026-01-24 16:24:56.788733+00	1624	676
4f59883d-ed73-4edf-be64-caa0eb57a2d9	enp0s31f6	0	0	2026-01-24 19:20:30.155296+00	0	0
0ace4985-5e04-424a-ae56-3cf6bf48119c	wlx30169d2252f8	5275	11194	2026-01-24 19:20:30.160232+00	1636	3472
09ce1332-d7a0-42a0-b95d-fd285d251760	enp0s31f6	0	0	2026-01-24 21:31:02.819484+00	0	0
ce37742a-4466-4093-b06b-8c29c8d2f25a	wlx30169d2252f8	1680	824	2026-01-24 21:31:02.824743+00	781	383
1d88b18f-a0a0-41fe-a1df-8df21afba254	enp0s31f6	0	0	2026-01-24 16:25:26.834754+00	0	0
a000cb32-1872-420a-8db8-761820aaecf9	wlx30169d2252f8	90806	54314	2026-01-24 16:25:26.842466+00	3024	1809
d6bdd07f-5ec7-4c22-8a27-9bfa5d57d3f2	enp0s31f6	0	0	2026-01-24 19:21:00.159023+00	0	0
8d98753d-8b83-43f6-8d52-30efbf0b7dc1	wlx30169d2252f8	1163	350	2026-01-24 19:21:00.164345+00	838	252
57dfe755-a151-43c5-bcd0-3d2f4a30e0aa	enp0s31f6	0	0	2026-01-24 21:31:32.873323+00	0	0
e8e6b338-4e8c-4dfa-8b39-7e378f5965f0	wlx30169d2252f8	20981	16572	2026-01-24 21:31:32.880165+00	3543	2798
d227197e-a74b-4e15-9ba5-fe96e54778c9	enp0s31f6	0	0	2026-01-24 16:25:56.804045+00	0	0
8ce18e9f-e759-4bc5-be9c-07974c36fd5c	wlx30169d2252f8	632	388	2026-01-24 16:25:56.808073+00	1130	693
e5a7b518-138c-480b-8d08-7db4bf04e89a	enp0s31f6	0	0	2026-01-24 19:21:30.177517+00	0	0
2085b582-b3ef-4214-a5c3-ece675830ee2	wlx30169d2252f8	6789	14843	2026-01-24 19:21:30.182191+00	2090	4570
a9b61d86-7eb1-4a12-aee7-58f0defa24b6	enp0s31f6	0	0	2026-01-24 21:32:02.844541+00	0	0
9c9a901b-8629-49c8-9d20-701a8a6ae416	wlx30169d2252f8	2402	1075	2026-01-24 21:32:02.849138+00	1107	495
c328083f-5b55-49ff-b54b-1977e8527ba8	enp0s31f6	0	0	2026-01-24 16:26:26.855855+00	0	0
f0bfedea-0b5e-4546-9f15-a019f52ae3e3	wlx30169d2252f8	81806	52532	2026-01-24 16:26:26.864717+00	2725	1749
7eae8817-1313-4ff8-8e03-258392442b4c	enp0s31f6	0	0	2026-01-24 19:22:00.166448+00	0	0
f9480c93-23ab-44ad-b073-708a6155f773	wlx30169d2252f8	1103	350	2026-01-24 19:22:00.17003+00	808	256
efcd8d30-687c-4fac-ac64-e07efa9633cb	enp0s31f6	0	0	2026-01-24 21:32:32.856884+00	0	0
4f782558-5e35-494f-be67-51a49c121dbd	wlx30169d2252f8	18569	12767	2026-01-24 21:32:32.860602+00	3136	2156
05fe3133-caf9-4be3-8438-d819e7265678	enp0s31f6	0	0	2026-01-24 16:26:56.816027+00	0	0
e5bf3672-4cf2-4269-9818-5084ccd5790c	wlx30169d2252f8	1158	528	2026-01-24 16:26:56.819534+00	2031	926
8d647fe3-7d55-42f6-a5eb-4012a0ad7d74	enp0s31f6	0	0	2026-01-24 19:22:30.196441+00	0	0
2a7aab29-576d-4254-9e3c-e23dcfff94b2	wlx30169d2252f8	4735	8769	2026-01-24 19:22:30.200658+00	1444	2674
4aa06468-ff56-48df-895b-a534e22c14de	enp0s31f6	0	0	2026-01-24 21:33:02.867016+00	0	0
1f7aaf21-937f-4044-9467-ec7c67c11942	wlx30169d2252f8	11330	1975	2026-01-24 21:33:02.872597+00	5194	905
57f30f64-b0b3-4d46-b35a-1b7a7e230b8f	enp0s31f6	0	0	2026-01-24 16:27:26.840801+00	0	0
139779fe-5d2e-460e-8e05-9ab32ad2ce57	wlx30169d2252f8	74581	40701	2026-01-24 16:27:26.844017+00	2484	1356
57f126c3-b7a6-40b0-bba7-f53a8802d7f9	enp0s31f6	0	0	2026-01-24 19:23:00.201804+00	0	0
b3e8bd6c-a2a7-44c2-8d7b-7308b01268ad	wlx30169d2252f8	2895	350	2026-01-24 19:23:00.206046+00	2100	253
4b5e9d46-2597-47f0-94fd-515fa1215a88	enp0s31f6	0	0	2026-01-24 21:33:32.910065+00	0	0
87b1c996-f7e9-4561-b31b-1b5d004cda6d	wlx30169d2252f8	19643	17896	2026-01-24 21:33:32.913428+00	3227	2940
4914bbc5-add2-476d-a400-98e43f19f991	enp0s31f6	0	0	2026-01-24 16:27:56.831571+00	0	0
3e0f2b50-7c07-47f4-9f78-3ee1025b2dbb	wlx30169d2252f8	1560	2487	2026-01-24 16:27:56.835246+00	2627	4189
2d767730-e5f5-46b3-a78d-660c16771003	enp0s31f6	0	0	2026-01-24 19:23:30.215082+00	0	0
65b8bc2c-a9ac-4645-9431-6bd25c481c5f	wlx30169d2252f8	7104	13935	2026-01-24 19:23:30.217388+00	2173	4264
62d9605e-0d19-4d24-b6e1-7d48ab14c17e	enp0s31f6	0	0	2026-01-24 21:34:02.888675+00	0	0
36373a14-f5ea-42f0-b95a-a0d58958e3bd	wlx30169d2252f8	2416	2117	2026-01-24 21:34:02.892427+00	1103	967
1196fac6-f068-49ef-8716-2b51431accef	enp0s31f6	0	0	2026-01-24 16:28:26.91012+00	0	0
5ad15abd-8aff-4a0d-b4e4-ff414d769119	wlx30169d2252f8	97374	53274	2026-01-24 16:28:26.916168+00	3242	1773
359b21a8-d752-4d0c-b090-1344fc1c3dac	enp0s31f6	0	0	2026-01-24 21:34:32.941301+00	0	0
0414d709-87fb-4922-bed1-09aaf1b8b998	wlx30169d2252f8	20565	19872	2026-01-24 21:34:32.94874+00	3369	3255
ef7189b4-f6cc-495a-91be-041daa1413ac	enp0s31f6	0	0	2026-01-24 16:28:56.850721+00	0	0
2816bd32-62ff-45ec-a96a-0d6ff6896dcb	wlx30169d2252f8	1007	388	2026-01-24 16:28:56.853913+00	1724	664
e8ba22c6-337b-4683-8b5c-82c310bce227	enp0s31f6	0	0	2026-01-24 21:35:02.911093+00	0	0
938fa97e-7e98-43a6-a102-1f5f32a44be5	wlx30169d2252f8	2698	2117	2026-01-24 21:35:02.916761+00	1229	964
9be5519f-84ae-4798-a8ca-f4155f210ecf	enp0s31f6	0	0	2026-01-24 16:29:26.88204+00	0	0
6ec38858-013b-48d3-b1ea-9549a4850c1a	wlx30169d2252f8	1105	6786	2026-01-24 16:29:26.887834+00	90539	556017
02a0425a-ae23-4cd2-9609-6a7eb9247988	enp0s31f6	0	0	2026-01-24 21:35:32.962723+00	0	0
f9460cb0-f251-4986-a575-e084dc0b6258	wlx30169d2252f8	20245	12892	2026-01-24 21:35:32.970427+00	3322	2115
029d1f39-7918-4656-9bdc-35e12cc1a668	enp0s31f6	0	0	2026-01-24 16:29:56.886456+00	0	0
47c5ebf6-0ef9-48b8-8c9c-1ac84c81d758	wlx30169d2252f8	1158	388	2026-01-24 16:29:56.890213+00	1986	665
d4166ec4-21ca-4996-84c4-c815e1fc14c8	enp0s31f6	0	0	2026-01-24 21:36:02.933487+00	0	0
796c0c85-0b47-414f-9b63-396b92dd0837	wlx30169d2252f8	2518	2093	2026-01-24 21:36:02.937476+00	1133	941
a0e3f696-c832-41c6-954c-9c3ab0fa1044	enp0s31f6	0	0	2026-01-24 16:30:26.950788+00	0	0
96f40f95-e613-41bf-b7e7-6f634daf941b	wlx30169d2252f8	3649	9303	2026-01-24 16:30:26.953693+00	101401	258519
35004bc2-329a-472e-8e34-556509946ef5	enp0s31f6	0	0	2026-01-24 21:36:32.947255+00	0	0
4b71e7c0-be98-4662-96c7-403830039d6f	wlx30169d2252f8	25916	11488	2026-01-24 21:36:32.950129+00	4267	1891
1baab137-1563-4557-b205-534ea7c8629f	enp0s31f6	0	0	2026-01-24 16:30:56.906509+00	0	0
ca272958-3eb9-48b0-a72a-845283a846e9	wlx30169d2252f8	1177	388	2026-01-24 16:30:56.91048+00	2022	666
92df86de-b08a-40fe-b639-36c76f897c88	enp0s31f6	0	0	2026-01-24 21:37:02.958836+00	0	0
7725f47b-2658-4086-9e6b-2a89136cf131	wlx30169d2252f8	2536	2109	2026-01-24 21:37:02.963949+00	1141	949
f427f9e2-9a5c-4b50-8bf8-456c917c3a88	enp0s31f6	0	0	2026-01-24 16:31:26.949384+00	0	0
6c79123a-9f98-4472-ac4c-2a7b3865e23f	wlx30169d2252f8	5151	10492	2026-01-24 16:31:26.952567+00	142619	290499
291190d2-959a-489f-a03a-addf7c120f9a	enp0s31f6	0	0	2026-01-24 21:37:33.004406+00	0	0
ee60456f-f9e9-40e2-9d3e-3888ccae51de	wlx30169d2252f8	17328	11317	2026-01-24 21:37:33.013483+00	2859	1867
dd7b07e8-2a89-4c05-b73a-3fdd0326d330	enp0s31f6	0	0	2026-01-24 16:31:56.927082+00	0	0
bda8b347-f9a6-4a5d-80a8-01054346af6f	wlx30169d2252f8	1195	388	2026-01-24 16:31:56.930856+00	1907	619
64604c70-7b54-4631-9ef2-68445ccccc67	enp0s31f6	0	0	2026-01-24 21:38:02.961474+00	0	0
15b33333-2be2-4d4f-9475-fc822ea68fdd	wlx30169d2252f8	2168	1772	2026-01-24 21:38:02.965169+00	982	802
47f5ccbb-50ac-4ee2-8054-14d510ca672d	enp0s31f6	0	0	2026-01-24 16:32:26.951539+00	0	0
92f0f59a-4845-494a-b14d-2c95faf87f3f	wlx30169d2252f8	1224	8165	2026-01-24 16:32:26.954154+00	29051	193793
39368b8a-2675-4c6a-91a4-449dba94a145	enp0s31f6	0	0	2026-01-24 21:38:33.002175+00	0	0
e4852b11-37a9-4914-8130-779d7a9b2c1e	wlx30169d2252f8	17876	12260	2026-01-24 21:38:33.006749+00	2930	2009
d75f7fcf-03d2-45cb-88ac-66be789a33d3	enp0s31f6	0	0	2026-01-24 16:32:56.934224+00	0	0
f9d82be2-f902-4e84-9734-748ab4339a6b	wlx30169d2252f8	1135	388	2026-01-24 16:32:56.93814+00	1912	653
db2702b5-a467-41eb-b456-26dceb0b3c2e	enp0s31f6	0	0	2026-01-24 21:39:02.996461+00	0	0
d7460902-31a7-417e-82a0-479063e804f5	wlx30169d2252f8	2612	1114	2026-01-24 21:39:03.001947+00	1163	496
ac9a09c7-bb05-478a-8878-6a066518b0b2	enp0s31f6	0	0	2026-01-24 16:33:26.961713+00	0	0
261ca9ca-08e8-4305-af17-04c77ae49ce5	wlx30169d2252f8	2590	12272	2026-01-24 16:33:26.96417+00	40956	194060
600b1499-a589-4147-aba8-487e6e326939	enp0s31f6	0	0	2026-01-24 21:39:33.049835+00	0	0
f4d82cb3-c9fb-4ba9-b840-4e7d0a6ab5e3	wlx30169d2252f8	20534	19554	2026-01-24 21:39:33.057036+00	3341	3181
d141a895-fbd6-4a5d-8bf8-32a9537076e2	enp0s31f6	0	0	2026-01-24 16:33:56.9548+00	0	0
2149315e-d430-47bc-a684-b2402027b18e	wlx30169d2252f8	1195	388	2026-01-24 16:33:56.958139+00	1942	630
6559c970-842e-4868-ac11-e870012e36cf	enp0s31f6	0	0	2026-01-24 21:40:03.004325+00	0	0
d47ac2f3-1859-4169-babc-5b964fb4bc32	wlx30169d2252f8	9769	954	2026-01-24 21:40:03.007533+00	4382	427
b0a3f03f-fbfc-4a9b-80ed-e472fbbdef9c	enp0s31f6	0	0	2026-01-24 16:34:26.982539+00	0	0
5c8a72d0-e92e-4c23-939e-999e1073aa61	wlx30169d2252f8	2214	10271	2026-01-24 16:34:26.986435+00	23481	108931
e58456d2-23b7-4d16-af60-429abbdcf16f	enp0s31f6	0	0	2026-01-24 21:40:33.069036+00	0	0
e7f166e5-11e1-469d-b099-5850e0f76679	wlx30169d2252f8	17586	10873	2026-01-24 21:40:33.072548+00	2841	1756
709d3423-630b-44ac-9c7e-c79d5a6256ce	enp0s31f6	0	0	2026-01-24 16:34:56.987288+00	0	0
a3f01036-1d6e-4af7-ab64-a5d91d4bb3ca	wlx30169d2252f8	1375	388	2026-01-24 16:34:56.992337+00	2192	618
52102208-6551-480e-a38b-c30272f489c4	enp0s31f6	0	0	2026-01-24 21:41:03.026079+00	0	0
dbeddeb0-e028-4651-8dce-ff6a9f2a1147	wlx30169d2252f8	2244	954	2026-01-24 21:41:03.027518+00	1011	429
dc2d0256-0a43-4f8d-a150-2cd6c303c75d	enp0s31f6	0	0	2026-01-24 16:35:27.043304+00	0	0
abc97f07-db9a-4ee5-aeb2-f3a0a3c35656	wlx30169d2252f8	2331	12190	2026-01-24 16:35:27.050712+00	21347	111636
fa9eccab-4e48-4686-8f47-4cb3ecb5fdb1	enp0s31f6	0	0	2026-01-24 21:41:33.092939+00	0	0
796d8b99-7cd4-494a-a3a4-f23dce0e8230	wlx30169d2252f8	17322	10784	2026-01-24 21:41:33.101982+00	2814	1752
82f82f58-dc58-477a-b701-639b5d92dc74	enp0s31f6	0	0	2026-01-24 16:35:56.996611+00	0	0
f60fc525-2134-46b9-8efa-9b95e1455a8f	wlx30169d2252f8	917	306	2026-01-24 16:35:56.998287+00	1474	491
312fb56c-ab40-49ff-ab40-ff5ad97b0943	enp0s31f6	0	0	2026-01-24 21:42:03.063645+00	0	0
3809a8a6-7d26-409b-9ba4-06020b60d783	wlx30169d2252f8	2030	820	2026-01-24 21:42:03.0687+00	895	361
2e4988b5-7a37-4afd-ad6c-f0674d4facf1	enp0s31f6	0	0	2026-01-24 16:36:27.025948+00	0	0
5ec1e115-6f2f-4fd6-9afe-322fc96e37e9	wlx30169d2252f8	3636	12350	2026-01-24 16:36:27.028443+00	28753	97665
e52f43cc-cc25-43ec-af92-59adcd9ddb8a	enp0s31f6	0	0	2026-01-24 21:42:33.114337+00	0	0
8ce187a7-1678-4e46-825d-3a3cdb41fd57	wlx30169d2252f8	19904	12006	2026-01-24 21:42:33.121744+00	3224	1945
d9ac92d5-a872-43a6-bed1-4e0113fdd13b	enp0s31f6	0	0	2026-01-24 16:36:57.032283+00	0	0
627f6cba-ef15-460d-a8cd-07c600d8e602	wlx30169d2252f8	869	0	2026-01-24 16:36:57.036137+00	1389	0
15634f9f-f945-4812-bc70-0234a6a76e38	enp0s31f6	0	0	2026-01-24 21:43:03.08586+00	0	0
e0e97a45-63e8-45de-a711-cd29577ec98f	wlx30169d2252f8	1992	730	2026-01-24 21:43:03.090699+00	883	323
bd54babf-0c28-4152-945d-0c790c58ff07	enp0s31f6	0	0	2026-01-24 16:37:27.053177+00	0	0
61c762cf-2873-4a48-b2ad-89ce91d0d854	wlx30169d2252f8	3016	13091	2026-01-24 16:37:27.05919+00	25933	112564
657a18d9-a0a5-4e4e-96b7-6f2771adfb75	enp0s31f6	0	0	2026-01-24 21:43:33.141416+00	0	0
73aa4784-b11a-4448-9941-a1bb98f17b18	wlx30169d2252f8	20594	13955	2026-01-24 21:43:33.150597+00	3332	2258
0f9219f1-d885-461e-b463-6fa1280d39a3	enp0s31f6	0	0	2026-01-24 16:37:57.05284+00	0	0
8f297184-c575-4ef4-9cf9-046ba6f23222	wlx30169d2252f8	5056	2765	2026-01-24 16:37:57.059191+00	7999	4374
2c1f7084-ae5a-4ff3-88a8-b924af675833	enp0s31f6	0	0	2026-01-24 21:44:03.107497+00	0	0
91901dc8-54a8-432d-828b-14045e0be8fe	wlx30169d2252f8	1968	730	2026-01-24 21:44:03.112784+00	869	322
7fd8d58c-9471-48f2-b5b6-71dfd29aaa1a	enp0s31f6	0	0	2026-01-24 16:38:27.104347+00	0	0
298c14d5-a3d9-4668-bde8-84bfd53f334d	wlx30169d2252f8	3330	11403	2026-01-24 16:38:27.111789+00	21311	72976
d827a250-8f3c-4150-86d2-2ed1e49079f9	enp0s31f6	0	0	2026-01-24 21:44:33.124559+00	0	0
d2086f3a-c42c-418d-9d49-2d554a28703d	wlx30169d2252f8	19535	11099	2026-01-24 21:44:33.128502+00	3161	1796
93e9e871-8eb2-409b-bec5-734f5b1d21dc	enp0s31f6	0	0	2026-01-24 16:38:57.07466+00	0	0
4f62cad6-7496-4f1d-8393-cbb58683b975	wlx30169d2252f8	971	0	2026-01-24 16:38:57.078545+00	1532	0
2f5683ec-78d4-45b9-ad23-b2770198ac4a	enp0s31f6	0	0	2026-01-24 21:45:03.13049+00	0	0
fedd8abf-b574-46a3-9b71-910ab1143fe6	wlx30169d2252f8	7201	820	2026-01-24 21:45:03.135579+00	3171	361
73348c86-84d9-4c4d-9698-b1f8e29b925a	enp0s31f6	0	0	2026-01-24 16:39:27.12508+00	0	0
4729a186-f308-4c6b-8e3f-3f9afda77ac9	wlx30169d2252f8	4113	13643	2026-01-24 16:39:27.134058+00	17604	58394
43fc4e08-9296-4d3f-af19-7a3998ce54b3	enp0s31f6	0	0	2026-01-24 21:45:33.182412+00	0	0
07327e0f-e71a-4770-89bb-d1ceb676a0db	wlx30169d2252f8	18206	12008	2026-01-24 21:45:33.190152+00	2932	1933
0ac798ae-4169-404a-b42e-3598ff19f6b5	enp0s31f6	0	0	2026-01-24 16:39:57.090835+00	0	0
74b7b997-f006-426e-b91c-ea80d04fb152	wlx30169d2252f8	503	0	2026-01-24 16:39:57.093378+00	797	0
7747c8d9-93b3-4008-bd44-2cf84ec9b857	enp0s31f6	0	0	2026-01-24 21:46:03.151663+00	0	0
e1dbe550-655c-4bf5-be24-b2ff4fce8b8a	wlx30169d2252f8	7193	730	2026-01-24 21:46:03.157419+00	3163	321
01a8e919-f733-4925-a231-aae3ea390e7c	enp0s31f6	0	0	2026-01-24 16:40:27.104992+00	0	0
48b93659-0fba-4e79-b21a-566d747f0b1e	wlx30169d2252f8	2716	11114	2026-01-24 16:40:27.107207+00	12325	50436
6a5b8ee4-ceae-4b2d-970d-c8ad04a1d7ca	enp0s31f6	0	0	2026-01-24 21:46:33.207934+00	0	0
320a62f9-6f0f-46d7-8f08-97c7cef045eb	wlx30169d2252f8	19674	12962	2026-01-24 21:46:33.216562+00	3150	2075
6d902b70-0aa9-4e2a-8cdc-fd23384f5585	enp0s31f6	0	0	2026-01-24 16:40:57.112919+00	0	0
e0a0861a-8ffc-4433-af24-7f2534c8d4e1	wlx30169d2252f8	665	0	2026-01-24 16:40:57.115971+00	1055	0
b439c358-ffe0-451d-a221-c9e010babdff	enp0s31f6	0	0	2026-01-24 21:47:03.175875+00	0	0
737a2ed0-bbe5-4897-bd9f-e8cc5e491a88	wlx30169d2252f8	14181	730	2026-01-24 21:47:03.180864+00	6192	318
9bcbb604-6ef8-4c9c-a982-a79d3de8cde4	enp0s31f6	0	0	2026-01-24 16:41:27.129372+00	0	0
1956fe14-3415-4dca-a9bf-1c79147009fa	wlx30169d2252f8	2960	10256	2026-01-24 16:41:27.132231+00	15293	52990
7cb7e446-936a-4132-9e3d-be8398dda57f	enp0s31f6	0	0	2026-01-24 21:47:33.194281+00	0	0
f6595227-a7d3-4eca-bfa8-8a119853dde8	wlx30169d2252f8	18552	14110	2026-01-24 21:47:33.196556+00	2948	2242
6e806247-dbde-480a-b921-023e0fcbc997	enp0s31f6	0	0	2026-01-24 16:41:57.132001+00	0	0
982be52b-2898-4b63-9d9a-c378db2bd193	wlx30169d2252f8	803	0	2026-01-24 16:41:57.134382+00	1233	0
5c88d6a9-d598-4609-8a7b-45ad1658ef43	enp0s31f6	0	0	2026-01-24 21:48:03.199415+00	0	0
6e6763e3-d85a-4703-b90d-bf87e2a0e79c	wlx30169d2252f8	7455	890	2026-01-24 21:48:03.204138+00	3238	386
1699d26d-7166-42fe-a3cc-5098c00ee8a9	enp0s31f6	0	0	2026-01-24 16:42:27.148346+00	0	0
a0086591-8634-4631-baca-cdff88bde752	wlx30169d2252f8	5924	11220	2026-01-24 16:42:27.152774+00	23015	43591
a9c204f0-6f9e-4f8c-b588-0471acf452f7	enp0s31f6	0	0	2026-01-24 21:48:33.25133+00	0	0
7b54ac2f-8223-4995-890c-0329d1c0fa34	wlx30169d2252f8	18620	12118	2026-01-24 21:48:33.258399+00	2976	1937
01eb2127-a9d3-4dea-8d16-507b233c41ff	enp0s31f6	0	0	2026-01-24 16:42:57.143131+00	0	0
167db830-824c-47e5-ac47-e32a29ac0c20	wlx30169d2252f8	955	345	2026-01-24 16:42:57.146823+00	1481	535
29b57e2b-9b29-4c05-9505-665dbdc318c9	enp0s31f6	0	0	2026-01-24 21:49:03.221273+00	0	0
f35efd85-e204-48d5-ad1a-ececfec31dab	wlx30169d2252f8	7243	648	2026-01-24 21:49:03.226792+00	3129	279
243f4124-e8b5-4758-b5ea-646f678bab17	enp0s31f6	0	0	2026-01-24 16:43:27.173059+00	0	0
685f73a6-b53c-4e34-995e-6dcbea27289f	wlx30169d2252f8	3649	13089	2026-01-24 16:43:27.176069+00	13013	46680
3a2cd6bb-d0b3-4b45-925f-ac2568a406f0	enp0s31f6	0	0	2026-01-24 21:49:33.240705+00	0	0
531d8a6d-860c-4290-b0d6-dc017edc5fd6	wlx30169d2252f8	18978	14324	2026-01-24 21:49:33.24324+00	2954	2229
405da8ac-b2f5-4880-87b1-5d62230003a7	enp0s31f6	0	0	2026-01-24 16:43:57.162276+00	0	0
32fe9086-e68d-47b1-81cd-9ae54520070f	wlx30169d2252f8	1159	717	2026-01-24 16:43:57.164053+00	1803	1115
24843ec1-06de-4fdb-a014-99dee321a8bf	enp0s31f6	0	0	2026-01-24 21:50:03.244797+00	0	0
3960ff29-4996-45fe-9413-c68522dcd977	wlx30169d2252f8	12676	648	2026-01-24 21:50:03.249015+00	5413	276
b8a8a03e-cebc-43c1-a66c-8f1cdc49ed91	enp0s31f6	0	0	2026-01-24 16:44:27.192713+00	0	0
255c65fd-8cc6-4464-a778-4f9abb1f88bf	wlx30169d2252f8	2716	8898	2026-01-24 16:44:27.195607+00	8045	26356
f2adb403-f866-4665-827f-15f6092b5d15	enp0s31f6	0	0	2026-01-24 21:50:33.286903+00	0	0
a0b84925-f7bd-45e4-b80e-2f3bdfb3d770	wlx30169d2252f8	21562	14046	2026-01-24 21:50:33.294276+00	3372	2196
b92e94f7-53d8-49dd-9e54-6939dba79a62	enp0s31f6	0	0	2026-01-24 16:44:57.185013+00	0	0
7817945a-b714-4332-b7a8-64e3e8531bc7	wlx30169d2252f8	448	372	2026-01-24 16:44:57.187491+00	688	571
6a6c795b-2b63-4412-8b3b-b82d844f3b23	enp0s31f6	0	0	2026-01-24 21:51:03.266791+00	0	0
b4c6ca24-2c4e-4da4-82ea-f8df76d53137	wlx30169d2252f8	13056	820	2026-01-24 21:51:03.272059+00	5586	350
eb26aff9-8496-4a32-be38-de6204c0a5ca	enp0s31f6	0	0	2026-01-24 16:45:27.240847+00	0	0
0c96be27-c20c-45cd-bd71-552bab470125	wlx30169d2252f8	2892	11392	2026-01-24 16:45:27.2468+00	8146	32092
a127bdfc-15b6-4129-b3fa-ea9cba7edf00	enp0s31f6	0	0	2026-01-24 21:51:33.278792+00	0	0
71032920-fe10-4894-9aa1-568aabeed9d4	wlx30169d2252f8	27449	15896	2026-01-24 21:51:33.282929+00	4288	2483
f1528f2d-0fac-4181-9619-0b78f4b71278	enp0s31f6	0	0	2026-01-24 16:45:57.201382+00	0	0
142d24e4-8970-4d0b-9679-3e5ff0f75351	wlx30169d2252f8	422	82	2026-01-24 16:45:57.204868+00	662	128
5a925334-0f4d-4fb8-840b-c1d3bb097f40	enp0s31f6	0	0	2026-01-24 21:52:03.288845+00	0	0
8ccf963e-b1b5-4479-8cb5-0007e0010632	wlx30169d2252f8	12598	730	2026-01-24 21:52:03.293786+00	5386	312
31359627-0f11-450b-a51e-46a75f18ff45	enp0s31f6	0	0	2026-01-24 16:46:27.258051+00	0	0
81395148-e811-4ae3-b248-756d4fc52b60	wlx30169d2252f8	2634	10257	2026-01-24 16:46:27.265494+00	8108	31576
be824fd4-84ff-4de3-827e-ba32d592ad9f	enp0s31f6	0	0	2026-01-24 21:52:33.329445+00	0	0
87586973-22e5-4dac-86b2-0cc598c3f2f6	wlx30169d2252f8	17682	11699	2026-01-24 21:52:33.335132+00	2737	1811
84f5eb6a-1b42-40af-9c38-3c8b7fb8f956	enp0s31f6	0	0	2026-01-24 16:46:57.212161+00	0	0
0a61016a-fdf4-479f-9ae7-83090d6a302f	wlx30169d2252f8	242	224	2026-01-24 16:46:57.215382+00	369	342
b6919c94-b62b-4439-842d-499bbbf39183	enp0s31f6	0	0	2026-01-24 21:53:03.284198+00	0	0
90dc6703-2482-4043-a60b-608e4c3f8770	wlx30169d2252f8	12274	730	2026-01-24 21:53:03.287302+00	5247	312
51308f65-58ae-4481-9974-73b476072e8b	enp0s31f6	0	0	2026-01-24 16:47:27.278515+00	0	0
193357b6-5ed4-4bcc-bc38-685714456ab9	wlx30169d2252f8	3450	11226	2026-01-24 16:47:27.286001+00	11120	36183
1f7d23d3-7287-46ad-8eac-5bfbaed207b2	enp0s31f6	0	0	2026-01-24 21:53:33.350136+00	0	0
2cb1c033-e51b-4019-a6f0-93dcd7e363dc	wlx30169d2252f8	18962	10827	2026-01-24 21:53:33.381547+00	2956	1688
c9e2bdf8-6544-4793-a0d7-8c3a30cf2559	enp0s31f6	0	0	2026-01-24 16:47:57.249851+00	0	0
74b2fe6a-58a2-4fe8-b4dd-036cb7dfe430	wlx30169d2252f8	6017	3127	2026-01-24 16:47:57.254011+00	8966	4659
e0f4f182-aced-4ba9-8631-542e7347f649	enp0s31f6	0	0	2026-01-24 21:54:03.321235+00	0	0
c2fda1c7-c6d2-4bb6-b7a6-2e19ba12feb0	wlx30169d2252f8	19777	820	2026-01-24 21:54:03.326759+00	8435	349
fa3871e9-193b-4da4-8660-713693896e03	enp0s31f6	0	0	2026-01-24 16:48:27.29948+00	0	0
fc5aa9fe-f3d9-4dd0-a300-a171e449f223	wlx30169d2252f8	2694	12136	2026-01-24 16:48:27.306899+00	6787	30578
aa22c384-8f62-4242-82ea-b5a428234b6a	enp0s31f6	0	0	2026-01-24 21:54:33.366844+00	0	0
80e19baf-bf4a-4dfa-9606-69f8a17abd3a	wlx30169d2252f8	19366	13883	2026-01-24 21:54:33.373374+00	2987	2141
6d834633-1d4a-4bb1-a08a-feaacfec5ed3	enp0s31f6	0	0	2026-01-24 16:48:57.260172+00	0	0
c17f88d0-14d8-4f31-9ace-f544b5cf8d6c	wlx30169d2252f8	422	224	2026-01-24 16:48:57.263826+00	634	336
34de6c8c-4257-4991-9c03-648774cd552c	enp0s31f6	0	0	2026-01-24 21:55:03.340529+00	0	0
cab87083-56ef-4898-acf5-d838b9c76d27	wlx30169d2252f8	19412	730	2026-01-24 21:55:03.345064+00	8234	309
e7359883-1b1c-426b-b0d5-5f7e470d6f66	enp0s31f6	0	0	2026-01-24 16:49:27.302738+00	0	0
50287fbe-1ebf-4d37-9869-c4c8f271e56f	wlx30169d2252f8	2952	10468	2026-01-24 16:49:27.310111+00	6722	23839
5a4e04ed-9fb8-4527-a08d-9f8f2973455d	enp0s31f6	0	0	2026-01-24 21:55:33.384946+00	0	0
dcb5aeaa-8a14-4951-96f3-6b0b3621710e	wlx30169d2252f8	17976	12014	2026-01-24 21:55:33.389195+00	2764	1847
1985d09b-de78-405f-acbd-1f268f903fc4	enp0s31f6	0	0	2026-01-24 16:49:57.269997+00	0	0
3ac300dd-da46-451b-90ed-8c2de9b3ea5f	wlx30169d2252f8	302	224	2026-01-24 16:49:57.274183+00	459	340
aea68ff5-5269-4573-bd46-b16026f790f3	enp0s31f6	0	0	2026-01-24 21:56:03.361648+00	0	0
8e6be326-48e9-4f1d-b265-1f5da073d7db	wlx30169d2252f8	12856	730	2026-01-24 21:56:03.365893+00	5397	306
b090610b-094c-4c49-963b-2accde8b4822	enp0s31f6	0	0	2026-01-24 16:50:27.32243+00	0	0
a4b99103-3226-4c57-9b20-55ace075231c	wlx30169d2252f8	4056	12270	2026-01-24 16:50:27.329774+00	9583	28991
747b473a-e1c7-4ffe-8d97-8f56efe3da3a	enp0s31f6	0	0	2026-01-24 21:56:33.381277+00	0	0
257e0280-9812-45e5-96df-e5a5e2e77a5d	wlx30169d2252f8	19346	14935	2026-01-24 21:56:33.385186+00	2959	2284
3735f2a9-2629-4bb2-a14b-d3f87a26b84a	enp0s31f6	0	0	2026-01-24 16:50:57.290555+00	0	0
3f212f50-2101-4989-a13b-7a727b74d0f6	wlx30169d2252f8	422	224	2026-01-24 16:50:57.294493+00	628	333
d95271f7-230a-4229-bba9-adba492fe7a5	enp0s31f6	0	0	2026-01-24 21:57:03.388364+00	0	0
48848ca6-1cc0-465b-9e4c-a2efed284f03	wlx30169d2252f8	12900	820	2026-01-24 21:57:03.394163+00	5368	341
e9ee6c59-e706-43d9-b4a0-393c4aeaf6f0	enp0s31f6	0	0	2026-01-24 16:51:27.345141+00	0	0
1ea0aeb2-b3de-49ef-8b11-5b8d4b79c606	wlx30169d2252f8	4572	14368	2026-01-24 16:51:27.352603+00	10659	33497
23edab43-95ae-4d15-b40d-5afa767057a3	enp0s31f6	0	0	2026-01-24 21:57:33.405258+00	0	0
eb73c039-4055-47d1-aa2d-563ca653f6d7	wlx30169d2252f8	21836	12012	2026-01-24 21:57:33.4076+00	3365	1851
09914b67-1168-4b5d-b683-70be5b3d8d98	enp0s31f6	0	0	2026-01-24 16:51:57.311641+00	0	0
82cfdff2-8578-4bdb-a052-4b1962fabae3	wlx30169d2252f8	302	224	2026-01-24 16:51:57.317015+00	428	318
1c809fe6-0adf-4d6b-a1b7-7c5ad3264551	enp0s31f6	0	0	2026-01-24 21:58:03.408091+00	0	0
57b02bb1-ba6b-485e-b4fd-49b23c657543	wlx30169d2252f8	13078	1088	2026-01-24 21:58:03.412512+00	5433	452
8e9cbaa7-8b44-4c61-8635-fb795819478b	enp0s31f6	0	0	2026-01-24 16:52:27.363537+00	0	0
746ef126-fe25-4a64-8433-eaa13c4f7702	wlx30169d2252f8	2454	10268	2026-01-24 16:52:27.370937+00	5890	24648
7d3c961a-7530-4f02-bc3d-e1d31b31e42f	enp0s31f6	0	0	2026-01-24 21:58:33.423462+00	0	0
eff91288-c5e2-4303-8cbe-0ef531e7dc5a	wlx30169d2252f8	26585	10744	2026-01-24 21:58:33.426206+00	4102	1658
b2ca0c68-236c-4cb7-81cd-5368cfa4de22	enp0s31f6	0	0	2026-01-24 16:52:57.317401+00	0	0
2b84153c-c819-4188-abff-2a39692b3839	wlx30169d2252f8	522	224	2026-01-24 16:52:57.31911+00	743	319
0e1123d6-ed42-48fb-b89f-89f465dee398	enp0s31f6	0	0	2026-01-24 21:59:03.417089+00	0	0
e11fa9f3-9199-4e93-a9ae-2b301aaaf5c6	wlx30169d2252f8	12777	1190	2026-01-24 21:59:03.420651+00	5375	500
e67773be-b6fa-4b4b-b755-ec963105e9d6	enp0s31f6	0	0	2026-01-24 16:53:27.403726+00	0	0
e83f2f00-8257-4ce8-bcea-21bf8d218cd1	wlx30169d2252f8	3252	9299	2026-01-24 16:53:27.416294+00	7147	20437
ab8b8aaf-5fbe-4ec3-9908-40f307bdba53	enp0s31f6	0	0	2026-01-24 21:59:33.445781+00	0	0
36f3e339-e087-4201-90d0-75c1b8773dd8	wlx30169d2252f8	20912	11131	2026-01-24 21:59:33.448106+00	3226	1717
22e77dfd-fa45-4ada-a17a-21fe5c5999cc	enp0s31f6	0	0	2026-01-24 16:53:57.353816+00	0	0
eecc4a9d-61e0-4ab1-a88f-2d9bef74c574	wlx30169d2252f8	6592	224	2026-01-24 16:53:57.357705+00	9499	322
a2098b4e-f789-4bf8-96aa-7530a8e9fe21	enp0s31f6	0	0	2026-01-24 22:00:03.44019+00	0	0
356a4907-f092-4a50-8506-e43e3268e558	wlx30169d2252f8	12625	1280	2026-01-24 22:00:03.441855+00	5298	537
6db6fcb5-43b2-48d9-880d-40de204220aa	enp0s31f6	0	0	2026-01-24 16:54:27.375721+00	0	0
c37fbc5c-9154-4eb1-bde6-088c1f975223	wlx30169d2252f8	3514	12129	2026-01-24 16:54:27.379195+00	7924	27352
eed34c32-8790-43de-8e81-cd6d75b7285f	enp0s31f6	0	0	2026-01-24 22:00:33.468217+00	0	0
55877aa4-fa7a-4d43-9b8f-39240b5c9560	wlx30169d2252f8	20808	12310	2026-01-24 22:00:33.470507+00	3139	1857
710df75f-91c7-4b9d-9913-4a0fb4f5bc30	enp0s31f6	0	0	2026-01-24 16:54:57.374028+00	0	0
1b92520e-a137-40ca-91f9-2e1f9a5fce5c	wlx30169d2252f8	422	224	2026-01-24 16:54:57.377816+00	607	322
f2604cee-267e-4e5f-94d9-ca0f148ceade	enp0s31f6	0	0	2026-01-24 22:01:03.474155+00	0	0
64551295-3c0b-4304-9bd6-b8d3df605753	wlx30169d2252f8	13111	1190	2026-01-24 22:01:03.477467+00	5474	496
5126f267-9a1b-4736-9feb-e1988e255558	enp0s31f6	0	0	2026-01-24 16:55:27.427316+00	0	0
3364cc80-83dc-4f21-af31-8d736aa1185f	wlx30169d2252f8	2816	10083	2026-01-24 16:55:27.434753+00	5808	20796
628f925b-bcef-4fc0-9fb5-cd5f84666c55	enp0s31f6	0	0	2026-01-24 22:01:33.530365+00	0	0
58defe86-a62d-45ae-915b-7f21e9d0b827	wlx30169d2252f8	18408	15944	2026-01-24 22:01:33.53754+00	2767	2397
3589deb1-8e38-461c-a2f5-c06ba45d82b1	enp0s31f6	0	0	2026-01-24 16:55:57.395903+00	0	0
9dea05ff-d1c6-4477-b5e1-2622cf0ddf79	wlx30169d2252f8	482	224	2026-01-24 16:55:57.399883+00	669	311
8e8d8805-7f7e-4c36-89c6-90c7ccab472e	enp0s31f6	0	0	2026-01-24 22:02:03.495745+00	0	0
f6b11580-8ec6-421e-bd9a-1b267b9686d0	wlx30169d2252f8	19827	1302	2026-01-24 22:02:03.499583+00	8178	537
d67768a9-8edd-4b33-9c61-6bf0bff5cacc	enp0s31f6	0	0	2026-01-24 16:56:27.417572+00	0	0
3e00cd40-be5f-4e55-9cba-7ff0f8c0d0b6	wlx30169d2252f8	4592	12495	2026-01-24 16:56:27.420768+00	9409	25604
f94d2dc6-9823-44eb-b40b-6feff5687eba	enp0s31f6	0	0	2026-01-24 22:02:33.540661+00	0	0
0b371385-097a-4f78-936d-a1e0ae555cfa	wlx30169d2252f8	18790	12328	2026-01-24 22:02:33.547814+00	2830	1856
ab8fc475-db3a-4989-8259-350c324c763c	enp0s31f6	0	0	2026-01-24 16:56:57.403697+00	0	0
6a7500fe-7fe2-4c15-86fe-53783a5e2377	wlx30169d2252f8	542	224	2026-01-24 16:56:57.405559+00	770	318
5ad31a52-0975-4945-b2fe-572349aecbc3	enp0s31f6	0	0	2026-01-24 22:03:03.511786+00	0	0
b3b936b0-ff10-478b-a613-e1afe56900ab	wlx30169d2252f8	13253	1280	2026-01-24 22:03:03.517367+00	5498	531
752992f3-e5bb-4e43-8ded-07bdeca7f3fd	enp0s31f6	0	0	2026-01-24 16:57:27.47141+00	0	0
a71a0343-9d09-45f1-831d-43624ff5cd93	wlx30169d2252f8	2876	9119	2026-01-24 16:57:27.478765+00	5176	16413
dfe780bc-7cd4-4ecd-9b14-8d5af54facc5	enp0s31f6	0	0	2026-01-24 22:03:33.56242+00	0	0
f6c07206-bd63-42e4-a8f8-81162d5ef208	wlx30169d2252f8	18740	13589	2026-01-24 22:03:33.568932+00	2801	2031
21177cfd-fd7f-467c-8a44-2abd86ebccc9	enp0s31f6	0	0	2026-01-24 16:57:57.436732+00	0	0
323f96f6-15df-4283-98f9-671352567dd9	wlx30169d2252f8	5504	2899	2026-01-24 16:57:57.441121+00	7378	3886
af9fd1f8-22e7-4a74-9a41-84dbb67e30d1	enp0s31f6	0	0	2026-01-24 22:04:03.533028+00	0	0
5ea115ab-c78c-4370-ad00-a5f96b1583e6	wlx30169d2252f8	12795	1190	2026-01-24 22:04:03.536698+00	5296	492
9d7a63ea-12f6-417c-a88a-17384bd92408	enp0s31f6	0	0	2026-01-24 16:58:27.483008+00	0	0
31bb8122-6a8b-4b8d-a1c2-9ccde24577a8	wlx30169d2252f8	3818	10581	2026-01-24 16:58:27.4888+00	6594	18275
55fdd6eb-7d04-44f4-8ef1-3c34a022a540	enp0s31f6	0	0	2026-01-24 22:04:33.550988+00	0	0
b75e19c3-d4f8-4a70-89af-bc6e25089b7f	wlx30169d2252f8	26655	15061	2026-01-24 22:04:33.553629+00	3991	2255
5c3cf09f-c8e5-458f-bc37-165e5fd68906	enp0s31f6	0	0	2026-01-24 16:58:57.442976+00	0	0
3e599a91-8e87-4387-a952-0182c137be82	wlx30169d2252f8	344	224	2026-01-24 16:58:57.444526+00	473	308
2be11e80-df04-45c5-b2bb-ec9c132f0a3e	enp0s31f6	0	0	2026-01-24 22:05:03.55564+00	0	0
0c8d2b42-6a96-4a49-82e7-a69ba870c4d0	wlx30169d2252f8	13413	1410	2026-01-24 22:05:03.559437+00	5545	582
b8f06fe0-43db-4d4c-9acf-475ad10dd54e	enp0s31f6	0	0	2026-01-24 16:59:27.510204+00	0	0
74737f68-d6d6-417a-a2d0-84bf1a420093	wlx30169d2252f8	4820	14584	2026-01-24 16:59:27.517795+00	7273	22006
8cf85c3c-694c-49ae-a211-4c5fa40080c8	enp0s31f6	0	0	2026-01-24 22:05:33.6082+00	0	0
a740683f-f485-4a01-b406-bf851b43c595	wlx30169d2252f8	20738	12316	2026-01-24 22:05:33.615753+00	3085	1832
10df18f8-0983-47e6-b001-ce1b705cc220	enp0s31f6	0	0	2026-01-24 16:59:57.479146+00	0	0
f4cebaec-8cbc-4272-afb6-078fb58abde2	wlx30169d2252f8	482	224	2026-01-24 16:59:57.484162+00	663	308
917ce2e7-0ee8-41ac-9312-59af81aa71df	enp0s31f6	0	0	2026-01-24 22:06:03.578478+00	0	0
9c441b3e-8f5a-4992-b7f6-3f579eae8877	wlx30169d2252f8	13381	1504	2026-01-24 22:06:03.583042+00	5510	619
a687e867-05c9-4cec-8048-cbeaab56e48f	enp0s31f6	0	0	2026-01-24 17:00:27.503872+00	0	0
223603c6-c470-4861-a8fd-95c466fbda49	wlx30169d2252f8	2936	10480	2026-01-24 17:00:27.508545+00	4607	16446
15fc78ce-0627-43d2-a0cf-3b8587215a64	enp0s31f6	0	0	2026-01-24 22:06:33.633681+00	0	0
45266ae0-a7be-454e-b756-bf55aee4a90f	wlx30169d2252f8	26833	12231	2026-01-24 22:06:33.641327+00	3977	1813
b1b33e90-0a6e-438a-974d-1dcbe82e90fa	enp0s31f6	0	0	2026-01-24 17:00:57.496689+00	0	0
ea8b100f-4903-491d-a126-026c826ae974	wlx30169d2252f8	362	224	2026-01-24 17:00:57.499345+00	483	299
01b2f68f-4ffc-4ff3-b66a-e4bc24aa886b	enp0s31f6	0	0	2026-01-24 22:07:03.587249+00	0	0
899bd08c-caa2-4081-a139-c5964c719f42	wlx30169d2252f8	13267	1508	2026-01-24 22:07:03.58866+00	5459	620
2657fc1a-6a26-4cbf-90d3-2e3ab65bb1e9	enp0s31f6	0	0	2026-01-24 17:01:27.551589+00	0	0
0c43da3c-fbc7-47e0-a0d4-e47832d47944	wlx30169d2252f8	2700	10475	2026-01-24 17:01:27.55879+00	4098	15899
2a031614-ead2-4f7c-a32b-5f478616d424	enp0s31f6	0	0	2026-01-24 22:07:33.61565+00	0	0
5be52cf9-7f82-4f5f-8f29-81e66712e15a	wlx30169d2252f8	18998	12296	2026-01-24 22:07:33.620356+00	2813	1820
5ffa1201-a798-433a-b05a-c135ba3d9192	enp0s31f6	0	0	2026-01-24 17:01:57.505212+00	0	0
d1c542da-481b-49eb-a8e2-a33023d56f04	wlx30169d2252f8	8634	224	2026-01-24 17:01:57.506753+00	11582	300
2d3948b8-defb-4924-9df3-5b05494affcd	enp0s31f6	0	0	2026-01-24 22:08:03.624888+00	0	0
e2ecbfb7-a8a8-41a8-a2fc-ef607e3cb902	wlx30169d2252f8	12907	1414	2026-01-24 22:08:03.629936+00	5273	577
c2665fb1-cc99-47a9-a345-9476578c47bc	enp0s31f6	0	0	2026-01-24 17:02:27.571554+00	0	0
bed66bfc-d08c-4105-9853-2bca28957270	wlx30169d2252f8	2816	10568	2026-01-24 17:02:27.577875+00	3888	14592
943d2e81-fa3f-4358-84d1-979984382b4d	enp0s31f6	0	0	2026-01-24 22:08:33.677273+00	0	0
088a41e0-59e6-47d8-94af-964c973683f1	wlx30169d2252f8	20080	12484	2026-01-24 22:08:33.687867+00	2976	1850
daf6b063-33f2-4b56-b027-fc26f9f30f8a	enp0s31f6	0	0	2026-01-24 17:02:57.539781+00	0	0
48cc6245-5fb0-47c4-89df-5b0d23062d19	wlx30169d2252f8	422	224	2026-01-24 17:02:57.545781+00	548	291
8ff3979c-1557-48f1-b630-a2770518efcc	enp0s31f6	0	0	2026-01-24 22:09:03.647045+00	0	0
f3f665ae-de40-44e7-9565-61dd2071777f	wlx30169d2252f8	20337	1332	2026-01-24 22:09:03.651751+00	8282	542
e4b5836a-76fe-4cfc-a0cd-00a4c22f101e	enp0s31f6	0	0	2026-01-24 17:03:27.554327+00	0	0
139f1e66-b50c-4a0a-b054-82bb9488f700	wlx30169d2252f8	4532	13851	2026-01-24 17:03:27.556749+00	6229	19038
51a65f02-5da1-47bf-bbaa-f70c7ad19e6b	enp0s31f6	0	0	2026-01-24 22:09:33.68949+00	0	0
4191d3cb-a24e-497d-9c33-fed8204e4f39	wlx30169d2252f8	18926	16270	2026-01-24 22:09:33.712088+00	2801	2408
5e248476-1b2a-4d37-a942-eabc03f59da8	enp0s31f6	0	0	2026-01-24 17:03:57.546361+00	0	0
86128501-f72a-4982-b12c-906388d66895	wlx30169d2252f8	618	224	2026-01-24 17:03:57.547997+00	837	303
24638808-b5f1-4f47-abf4-9b54155e616c	enp0s31f6	0	0	2026-01-24 22:10:03.669537+00	0	0
14a8020f-10fc-48e6-a8b2-b7cf94aefa7a	wlx30169d2252f8	12884	3144	2026-01-24 22:10:03.673272+00	5237	1278
ee0c4021-6834-49fc-b5f2-95a79ff521d4	enp0s31f6	0	0	2026-01-24 17:04:27.60935+00	0	0
fbc9726e-75ca-4e11-a31f-5821840ea026	wlx30169d2252f8	5614	10616	2026-01-24 17:04:27.618347+00	8021	15168
e585b5d5-3018-4598-9c86-d8d6f8c1bc18	enp0s31f6	0	0	2026-01-24 22:10:33.718738+00	0	0
cee66239-6a27-4b2d-86be-caba7d15f909	wlx30169d2252f8	20512	14380	2026-01-24 22:10:33.725901+00	3014	2113
b44b1312-39eb-480a-bced-e6002e330db8	enp0s31f6	0	0	2026-01-24 17:04:57.574853+00	0	0
49dc07fa-32e2-4978-b12a-cf16765f5f02	wlx30169d2252f8	534	350	2026-01-24 17:04:57.57882+00	719	471
dbe32585-84bd-47e8-8e83-1b5158e02bd9	enp0s31f6	0	0	2026-01-24 22:11:03.689008+00	0	0
15a4173f-da67-4831-bffb-44b24883c3e7	wlx30169d2252f8	12863	3226	2026-01-24 22:11:03.69323+00	5225	1310
559a2ad2-c16b-4013-b7e0-4422d54293d6	enp0s31f6	0	0	2026-01-24 17:05:27.611887+00	0	0
7f68f503-e002-494e-bf95-6279fc73f4ca	wlx30169d2252f8	3692	11575	2026-01-24 17:05:27.615752+00	4924	15440
e8242704-bf6f-4df6-974b-7d592d67552c	enp0s31f6	0	0	2026-01-24 22:11:33.702829+00	0	0
77d6a825-fddb-4972-834a-0475e8a213d5	wlx30169d2252f8	18242	12323	2026-01-24 22:11:33.705229+00	2696	1821
5c61ca35-fae7-4f6d-bd70-600b642e081d	enp0s31f6	0	0	2026-01-24 17:05:57.570797+00	0	0
96bdd140-de74-4d3f-a9b3-b500fa405d2e	wlx30169d2252f8	242	350	2026-01-24 17:05:57.572449+00	335	485
999d5c5a-fa2f-4062-a913-93293895dd17	enp0s31f6	0	0	2026-01-24 22:12:03.697118+00	0	0
0a0ab7bb-4faf-430c-9466-d92ef4e5df8b	wlx30169d2252f8	13844	5592	2026-01-24 22:12:03.699118+00	5618	2269
d1f8d9c1-acbe-4c10-9ac4-de2fe496af10	enp0s31f6	0	0	2026-01-24 17:06:27.627885+00	0	0
d90a8789-ebb5-4b04-ba60-71c4a5430257	wlx30169d2252f8	2198	9247	2026-01-24 17:06:27.635742+00	3195	13444
dd58ea5c-93be-44a4-8351-8e1c740ca6de	enp0s31f6	0	0	2026-01-24 22:12:33.751347+00	0	0
1ef11a7b-0500-48a1-92a1-f7e1b3311ec0	wlx30169d2252f8	22008	16187	2026-01-24 22:12:33.774725+00	3248	2389
00a9b5aa-c570-4e8f-b387-ea42d0416d73	enp0s31f6	0	0	2026-01-24 17:06:57.588955+00	0	0
f638e5ca-c11b-4279-b213-a911507fc4ee	wlx30169d2252f8	422	350	2026-01-24 17:06:57.5927+00	577	479
62d71881-2031-4c6c-93cf-5b3169510e9c	enp0s31f6	0	0	2026-01-24 22:13:03.709705+00	0	0
e9db18fd-06dd-454f-ac27-2d103154e8dc	wlx30169d2252f8	12914	3234	2026-01-24 22:13:03.7132+00	5247	1314
2b259446-10fd-45d6-9392-999904b02ab7	enp0s31f6	0	0	2026-01-24 17:07:27.627055+00	0	0
164b8069-27cf-474c-adae-772e6de6397e	wlx30169d2252f8	2798	10694	2026-01-24 17:07:27.634394+00	3929	15017
18a18d74-61bc-45a7-9b28-0ede53ef243f	enp0s31f6	0	0	2026-01-24 22:13:33.758919+00	0	0
2843e8b2-f783-4804-8a08-b4af013e252b	wlx30169d2252f8	26029	12246	2026-01-24 22:13:33.768165+00	3835	1804
a1a9ceab-fcda-495d-be38-17f61cb41e59	enp0s31f6	0	0	2026-01-24 17:07:57.594734+00	0	0
f65a0879-c70b-49c0-9551-9428685aa61c	wlx30169d2252f8	5501	1248	2026-01-24 17:07:57.599474+00	7388	1676
c9e57bab-8bca-4947-9d87-a3604b4a4c09	enp0s31f6	0	0	2026-01-24 22:14:03.728792+00	0	0
87762b59-7ce7-4818-8efc-d68e824bea18	wlx30169d2252f8	13010	3226	2026-01-24 22:14:03.734178+00	5239	1299
4fe46baa-7cd7-4a0f-aaa8-8467a22012cc	enp0s31f6	0	0	2026-01-24 17:08:27.647141+00	0	0
616fe13d-a413-4d38-8f7e-c7e7bd230e8b	wlx30169d2252f8	3878	11661	2026-01-24 17:08:27.652392+00	5560	16720
47491cd6-0511-43e0-9cf6-25e5867b53d1	enp0s31f6	0	0	2026-01-24 22:14:33.774565+00	0	0
7c5c16a3-4887-419d-b0da-1933459807dc	wlx30169d2252f8	17976	11052	2026-01-24 22:14:33.781793+00	2613	1606
314abe2a-e81a-4052-9a9d-d52f6630c641	enp0s31f6	0	0	2026-01-24 17:08:57.616627+00	0	0
cf263b90-5739-40d9-8f16-9eaf7eedd9f2	wlx30169d2252f8	300	126	2026-01-24 17:08:57.620574+00	413	173
01952dc2-a6b3-43fe-b245-cd9710633b3d	enp0s31f6	0	0	2026-01-24 22:15:03.732035+00	0	0
8137c5bd-9521-4cc7-ad28-e3a2ba82c8be	wlx30169d2252f8	13148	3226	2026-01-24 22:15:03.735521+00	5370	1317
f55575f1-cc21-4819-b7fd-8d6f219723f5	enp0s31f6	0	0	2026-01-24 17:09:27.668693+00	0	0
fac10a71-7003-490f-83b5-297b8964ca3a	wlx30169d2252f8	3642	10697	2026-01-24 17:09:27.676105+00	4800	14098
efdd92da-e6e4-4eca-97ca-8004c8759995	enp0s31f6	0	0	2026-01-24 22:15:33.761911+00	0	0
bbbdc4bb-d646-488c-bd61-25f200c8f589	wlx30169d2252f8	18040	10966	2026-01-24 22:15:33.765988+00	2613	1588
4cb8ef9d-8cf7-441b-b175-616c515c80f1	enp0s31f6	0	0	2026-01-24 17:09:57.636704+00	0	0
8ed1c971-993b-430d-8754-01e0e3a2be0b	wlx30169d2252f8	562	126	2026-01-24 17:09:57.642231+00	771	172
26694bc1-e712-470c-a972-4ca927d0da31	enp0s31f6	0	0	2026-01-24 22:16:03.769073+00	0	0
21d2ed6e-16e8-4674-a93d-97cffd6635fd	wlx30169d2252f8	14718	3226	2026-01-24 22:16:03.774015+00	5967	1308
445a671b-4758-477c-8aec-3603fbabd5bb	enp0s31f6	0	0	2026-01-24 17:10:27.677467+00	0	0
0d99faa0-d88a-4a06-83b1-149d32eaae9e	wlx30169d2252f8	4650	17255	2026-01-24 17:10:27.684876+00	5545	20578
4120ee88-4375-435b-b6e8-0895186c9a37	enp0s31f6	0	0	2026-01-24 22:16:33.811899+00	0	0
94c3b3a5-14d9-4d1f-837f-5bfc7b34ff52	wlx30169d2252f8	19342	13205	2026-01-24 22:16:33.820853+00	2797	1910
bd099498-56db-4c22-b52c-ee86733b6ec5	enp0s31f6	0	0	2026-01-24 17:10:57.629217+00	0	0
3c5497d0-8641-4720-be70-10deb2d93258	wlx30169d2252f8	622	126	2026-01-24 17:10:57.631064+00	882	178
a7472a93-f716-46f4-8fb2-d4a144113101	enp0s31f6	0	0	2026-01-24 22:17:03.784088+00	0	0
1d35e051-8599-40cb-b522-7dc1f27cff5e	wlx30169d2252f8	21271	3226	2026-01-24 22:17:03.786136+00	8527	1293
606ef9ba-7eb9-4a57-9e6c-2a8b4a93af98	enp0s31f6	0	0	2026-01-24 17:11:27.657266+00	0	0
45ee4e00-282d-400e-801c-759fa638e882	wlx30169d2252f8	10624	11087	2026-01-24 17:11:27.661427+00	13198	13773
e95a5b8c-cd01-4e43-a6f7-f000a396c267	enp0s31f6	0	0	2026-01-24 22:17:33.830293+00	0	0
be99aa94-19af-4512-815e-98b1c65c061d	wlx30169d2252f8	17980	11782	2026-01-24 22:17:33.838699+00	2610	1710
c6df8f66-bc8c-4896-8466-57b1b969d219	enp0s31f6	0	0	2026-01-24 17:11:57.665411+00	0	0
882124cd-ce00-4a65-8074-961f0d5c776c	wlx30169d2252f8	622	126	2026-01-24 17:11:57.669286+00	848	171
18dcfe80-88f5-4743-9ad2-075417b23238	enp0s31f6	0	0	2026-01-24 22:18:03.799347+00	0	0
b29b03ae-5877-4420-a7c1-b49da390e749	wlx30169d2252f8	18184	4579	2026-01-24 22:18:03.805501+00	7278	1832
65617b22-4dc9-480e-80c6-abc5c1df6db8	enp0s31f6	0	0	2026-01-24 17:12:27.718611+00	0	0
f7c3c0bd-5f8c-47ed-bcbd-29f41687206c	wlx30169d2252f8	2888	11347	2026-01-24 17:12:27.727544+00	3997	15704
fad7a9b5-29b5-4910-9237-6e95fd8adfc0	enp0s31f6	0	0	2026-01-24 22:18:33.825275+00	0	0
65db5ddb-45e6-4de0-86fe-0f2c32018058	wlx30169d2252f8	18406	12332	2026-01-24 22:18:33.830546+00	2662	1784
d90d20c4-58c3-448d-a40d-d4f7def2170d	enp0s31f6	0	0	2026-01-24 17:12:57.685512+00	0	0
6d2a016a-35a3-4f73-b891-b6949b6d89c0	wlx30169d2252f8	434	126	2026-01-24 17:12:57.689573+00	570	165
0c5ce5eb-a63d-4df4-8410-087f2bbdb5f7	enp0s31f6	0	0	2026-01-24 22:19:03.814686+00	0	0
1e103393-554e-4f93-a076-078e9f22f32f	wlx30169d2252f8	17744	4283	2026-01-24 22:19:03.818457+00	7122	1719
34c58755-bf1c-4de1-a597-d420b5f774ef	enp0s31f6	0	0	2026-01-24 14:15:58.214479+00	0	0
a91a8254-704d-4a9c-85ce-13caa29c7f6d	wlx30169d2252f8	144900	1880613	2026-01-24 14:15:58.226515+00	4805	62369
a8c358fb-0c49-439a-ad0d-05310c0c2eb4	enp0s31f6	0	0	2026-01-24 14:16:28.187098+00	0	0
78695cd8-75ff-4f5f-8f45-46c74c6bb6f3	wlx30169d2252f8	183655	2505933	2026-01-24 14:16:28.191211+00	6123	83551
d404f1cd-0110-4c0a-9002-f7ba37dfdaec	enp0s31f6	0	0	2026-01-24 14:17:24.410703+00	0	0
6413c38a-c401-4030-ac78-736dcd3b8649	wlx30169d2252f8	184693	2065176	2026-01-24 14:17:24.418081+00	6118	68410
\.


--
-- Data for Name: security_settings; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.security_settings (id, ufw_status, fail2ban_status, ssh_port, last_check_at, created_at, updated_at) FROM stdin;
7a5d650f-f22e-41e0-95e0-84ffcb7c40d7	active	active	22	\N	2026-01-06 13:41:44.386089+00	2026-01-06 13:41:44.386089+00
\.


--
-- Data for Name: service_uptime; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.service_uptime (id, service_id, status, response_time_ms, checked_at) FROM stdin;
\.


--
-- Data for Name: services; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.services (id, name, description, category, port, url, icon, is_active, status, last_check_at, response_time_ms, created_at, updated_at) FROM stdin;
55dcfbfc-fcd6-4af9-baea-c6f79486f3c2	Portainer	Docker management	admin	9000	\N	container	t	unknown	\N	\N	2026-01-08 05:24:42.914104+00	2026-01-08 05:24:42.914104+00
7955995d-2d9b-4d35-83b6-af74868dafd8	Glances	System monitor	admin	61208	\N	activity	t	unknown	\N	\N	2026-01-08 05:24:42.914104+00	2026-01-08 05:24:42.914104+00
9338d3a0-bd14-4ea2-a89d-3109fbf8d4cc	Adminer	Database management	admin	8083	/adminer/	database	t	unknown	\N	\N	2026-01-08 05:24:42.914104+00	2026-01-08 05:24:42.914104+00
5a28dceb-1191-4fd8-a544-1282f6f3af72	Dozzle	Log viewer	admin	8888	\N	terminal	t	unknown	\N	\N	2026-01-08 05:24:42.914104+00	2026-01-08 05:24:42.914104+00
a6d29ae0-05c3-42d3-aa4c-022939b9c5bb	AI Translate	LibreTranslate API	ai	5000	/ai-hub	languages	t	unknown	\N	\N	2026-01-08 05:24:42.914104+00	2026-01-08 05:24:42.914104+00
188199de-69c3-44e4-8fc1-7139b834b4e0	IOPaint	AI Inpainting	ai	8585	\N	eraser	t	unknown	\N	\N	2026-01-08 05:24:42.914104+00	2026-01-08 05:24:42.914104+00
540755d6-d456-49de-b6c1-2366dee5b4d2	SAM 2	Segment Anything	ai	8787	\N	scan	t	unknown	\N	\N	2026-01-08 05:24:42.914104+00	2026-01-08 05:24:42.914104+00
f52c24f5-9db4-4ad1-8259-048882897345	Video Processor	FFmpeg Pipeline	ai	8686	\N	video	t	unknown	\N	\N	2026-01-08 05:24:42.914104+00	2026-01-08 05:24:42.914104+00
0b423bb9-4717-4e4c-be7f-5a54d52e5b51	AI Chat	Ollama Llama3	ai	11434	/ai-hub	message-square	t	unknown	\N	\N	2026-01-08 05:24:42.914104+00	2026-01-08 05:24:42.914104+00
4e1ea6b3-088e-4ea3-9716-756418bb4d8b	AI Transcribe	Whisper GPU	ai	8000	/ai-hub	mic	t	unknown	\N	\N	2026-01-08 05:24:42.914104+00	2026-01-08 05:24:42.914104+00
ff7d4513-00b9-49a9-9806-62780da06f16	PostgreSQL	Main database	core	5432	\N	database	t	unknown	\N	\N	2026-01-08 05:24:42.914104+00	2026-01-08 05:24:42.914104+00
2a2aa2ce-fc4b-4ee9-bb9b-a34689ccd748	Redis	Cache & queue	core	6379	\N	zap	t	unknown	\N	\N	2026-01-08 05:24:42.914104+00	2026-01-08 05:24:42.914104+00
346f4e19-947a-46f3-9b76-f5b14e384efa	n8n	Workflow automation	work	5678	\N	workflow	t	unknown	\N	\N	2026-01-08 05:24:42.914104+00	2026-01-08 09:24:26.626397+00
3dd71766-da18-4c0e-a35e-868190cf0818	Browserless	Headless browser	work	3002	\N	globe	t	unknown	\N	\N	2026-01-08 05:24:42.914104+00	2026-01-08 09:24:26.626397+00
9d808b16-0043-4da0-ab32-24158e7f875e	Healthchecks	Monitor cron jobs	work	8001	\N	heart-pulse	t	unknown	\N	\N	2026-01-08 05:24:42.914104+00	2026-01-08 09:24:26.626397+00
1bf99467-cf89-4095-a7dd-0c4e6a6fade8	Nginx Proxy Manager	Reverse proxy	data	81	\N	shield	t	unknown	\N	\N	2026-01-08 05:24:42.914104+00	2026-01-08 09:24:26.626397+00
684d9238-93a9-4084-8eb6-da893e7389be	WireGuard UI	VPN Management	data	5003	\N	lock	t	unknown	\N	\N	2026-01-08 05:24:42.914104+00	2026-01-08 09:24:26.626397+00
adb596c8-1ea4-496d-80eb-dd93e7dce884	RSSHub	RSS aggregator	data	1200	\N	rss	t	unknown	\N	\N	2026-01-08 05:24:42.914104+00	2026-01-08 09:24:26.626397+00
a345b27f-a877-4a3c-a3a4-e34736556c9d	Nextcloud	Cloud storage	data	8081	\N	cloud	t	unknown	\N	\N	2026-01-08 05:24:42.914104+00	2026-01-08 09:24:26.626397+00
7d94d3b4-f5d3-41a9-b96d-f752146dfd5b	File Browser	Web file manager	data	8082	\N	folder-open	t	unknown	\N	\N	2026-01-08 05:24:42.914104+00	2026-01-08 09:24:26.626397+00
\.


--
-- Data for Name: system_metrics; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.system_metrics (id, "timestamp", cpu_percent, ram_percent, net_rx_total, net_tx_total) FROM stdin;
24cb0c53-d3cf-4d76-b961-c970c1bd0480	2026-01-24 14:17:54.419111+00	29.8	43.2	0	0
bcb311a2-eeae-4eeb-9e31-29a3d2d38901	2026-01-24 17:11:56.931415+00	17	27.6	3347	1522
0cf42ab1-66e0-4f97-8401-e83688f27160	2026-01-24 20:02:59.45653+00	17.3	27.8	2770	1259
da60a335-bc8b-42df-ae32-0a741a908bfc	2026-01-24 22:54:01.841975+00	14.5	27.2	3678	1954
4bd750e6-8d37-41d7-9d85-d999a9446aa6	2026-01-24 14:18:54.457107+00	30	43.1	1959	1300
27b18e8e-4608-41d0-8b2c-629f8aa75ecc	2026-01-24 17:12:27.00503+00	16.4	27.6	156662	156662
e88cebdd-5c26-42b0-935c-97cd78c2e016	2026-01-24 20:03:26.973718+00	17.4	27.8	183081	183081
dfeb6200-1980-46d3-a153-35ee76b923fd	2026-01-24 22:54:26.935681+00	13.4	27	219858	219858
468d0b1b-3535-4200-84e9-0927c4df18cf	2026-01-24 14:19:54.422861+00	33.6	40.2	2381	1290
7bfa066d-66f9-4425-b743-bd350b4e7f96	2026-01-24 17:12:56.930198+00	16.5	27.9	2597	1316
1713267c-a410-4cee-bf29-e35fd7d1b473	2026-01-24 20:03:59.474051+00	17.1	27.6	3865	1857
e0dff780-ebc4-4d13-91a7-e0d514403ec1	2026-01-24 22:55:01.848591+00	14.9	27.3	2461	1331
775eafac-9e3c-487b-bf20-87ce46cafa34	2026-01-24 14:20:54.524568+00	37	39.9	2228	1275
271dfcf4-45d9-4d0d-ad33-2cf96ce90196	2026-01-24 17:13:26.906578+00	16	27.9	239289	239289
a0a8c511-3849-4536-ae76-46f53365d5a6	2026-01-24 20:04:26.919076+00	15.9	27.9	225602	225602
2201741e-ddf4-4fb8-a5a8-c812cb8fdea3	2026-01-24 22:55:26.933405+00	11.8	27.4	247157	247157
e4ca0fb8-de3f-4540-b65f-e97e655f9579	2026-01-24 14:21:51.849868+00	51.3	41.3	153234	153234
eeb1f735-e932-47ca-8389-84c89786570e	2026-01-24 17:13:57.002609+00	16.5	27.9	2166	1324
34162a9e-c8b2-49de-ba18-ad33ef35e018	2026-01-24 20:04:59.44373+00	17	27.8	2418	1317
891619b5-180d-46e1-97a4-9f0c40713ad5	2026-01-24 22:56:01.84491+00	13.8	27.2	2523	1332
e4ce0d25-e747-4561-aa82-53e1e1b388aa	2026-01-24 14:21:54.429267+00	28.8	41.5	1453	6095
bad9ef2d-0b90-49e2-b9b2-c7ca926a8c1f	2026-01-24 17:14:26.914628+00	17.5	27.8	165880	165880
df5c32c1-da97-4c0a-87cb-5b8a62dbbea3	2026-01-24 20:05:26.894307+00	16.7	27.9	306488	306488
731ecdf7-28ec-463b-828a-15b0d9a8f57f	2026-01-24 22:56:26.91514+00	12.2	27.4	203654	203654
2f7502bd-5b35-4101-abd2-8f74f33334c9	2026-01-24 14:22:51.948557+00	54.4	41.6	152940	152940
f923fe5f-e9d7-4743-9f62-d0890e9c1691	2026-01-24 17:14:57.019558+00	16.5	28	1948	1203
50c3fdf2-6a18-4ec8-ab6e-1526e6df18f2	2026-01-24 20:05:59.471041+00	16.9	27.9	2487	1311
d6c161da-852a-4564-9bfe-c47322c801fe	2026-01-24 22:57:01.864821+00	14	27	2201	1343
f1719cd9-f806-437f-8ba4-06b9a3c09b07	2026-01-24 14:22:54.507275+00	33.6	41.6	1232	6352
0c8bf058-ccbe-482e-9d51-35cd3459c647	2026-01-24 17:15:26.88605+00	16.5	27.7	275152	275152
71d460b5-7917-4b39-bcf0-e97fd2f58989	2026-01-24 20:06:27.046383+00	16.2	28.1	171659	171659
05b4efe7-1425-408c-8c37-4c23bc7101b8	2026-01-24 22:57:26.890527+00	14	27.3	211056	211056
443a4252-43f3-4c9e-9920-290dca75f38e	2026-01-24 14:23:54.620732+00	52.8	30	7083	126646
7a73deb1-695d-4eb0-bd9f-a48f0850caed	2026-01-24 17:15:57.035144+00	16.5	27.9	1986	1177
7519f0bf-6bc5-4c51-8674-6524d8c9e41e	2026-01-24 20:06:59.487492+00	17.2	27.9	2375	1310
0f4ff6f5-b750-4951-850c-48f39068c522	2026-01-24 22:58:01.868054+00	13.8	27.3	2455	1471
1b0632e2-98f2-473f-b675-fe2613e5e596	2026-01-24 14:24:51.652885+00	48	27.6	133178	133178
741c351f-12c9-430f-9d1b-1f47c12a7da0	2026-01-24 14:24:55.172782+00	21.2	27.8	292887	292887
08c95c6c-c3b5-4800-a455-8431f2eb164f	2026-01-24 17:16:26.894806+00	17	27.8	112927	112927
892a3c18-37a8-49bd-b580-844a9c741df8	2026-01-24 20:07:26.917691+00	16.4	28.1	195593	195593
dba64fc2-71d6-471e-9a61-4d29ec66e3fe	2026-01-24 22:58:26.941352+00	13.8	26.9	267818	267818
66893cbe-6033-4f15-9417-a7dbe4139463	2026-01-24 14:24:54.511653+00	21.2	27.8	6760	252922
04f07181-f955-4d2e-9f21-2099f5658836	2026-01-24 17:16:57.011224+00	16.7	27.8	2860	1277
ff9310a5-1b42-4d4d-b198-89ee4cec0109	2026-01-24 20:07:59.486252+00	16.6	28.2	2288	1421
ac268a48-9cd7-4c9a-bb5f-65a008908224	2026-01-24 22:59:01.885531+00	14.4	26.9	2010	1341
cc3d3860-ac8e-44c3-bb1f-ab57ee59e868	2026-01-24 14:25:54.518061+00	27.9	29.9	2482	1659
0a5620e8-fc38-49d8-84fb-9a016af9efe5	2026-01-24 17:17:26.938278+00	50	27.6	170526	170526
3f2c85cf-43e6-44c5-821b-889048d11f9a	2026-01-24 20:08:26.95348+00	16.7	28.1	183863	183863
23d5989f-7ace-4814-bbd7-c5d16995ea73	2026-01-24 22:59:26.923398+00	14.1	27.1	260068	260068
6e87e0d7-61ee-466c-ae75-7df6d5f22623	2026-01-24 14:26:54.510747+00	27	32.2	4224	42101
8b8154a0-d3c1-41de-b85e-aa0669074c21	2026-01-24 17:17:57.00833+00	16.6	27.7	3409	1730
6ab64992-2922-4fd2-84ba-38e959dc968a	2026-01-24 20:08:59.544011+00	16.7	27.9	2117	1299
03846715-e02a-4122-8ade-8c90fae2ed88	2026-01-24 23:00:01.902165+00	14	26.9	3617	1956
ec05c766-dcce-4fd8-a055-1b9b971d6d41	2026-01-24 14:27:21.979894+00	22.7	33.6	135883	135883
1c59b37d-1f77-47ef-b393-fbc91cbad3e3	2026-01-24 17:18:26.889166+00	17.1	27.7	148168	148168
ef92cc30-ff11-49c8-b715-e816bc735f30	2026-01-24 20:09:26.997623+00	17.6	28.2	213865	213865
ca55b349-6574-48fb-9078-00fd2c61768b	2026-01-24 23:00:26.946185+00	13.5	27.3	199873	199873
32778369-2a42-4341-b5c3-48709c6a4880	2026-01-24 14:27:54.565824+00	34.9	30.8	2370	9210
e4088bcf-561f-440f-8efd-f4cb8cdfc030	2026-01-24 17:18:57.074334+00	16.6	27.7	2985	1523
c674b76e-70ab-4582-a74a-95cc402c0fa1	2026-01-24 20:09:59.554081+00	16.5	28.2	3581	1910
72fa9b33-ee6a-4785-a718-a784e3aa41c3	2026-01-24 23:01:01.91871+00	14.2	28	2726	1377
6acecf98-0f26-4cc0-aebc-11eee7123719	2026-01-24 14:28:22.854929+00	38.7	36.3	361666	361666
702c13f6-4b27-4389-b1d0-e5be8eeff3d3	2026-01-24 17:19:26.959134+00	16.7	27.6	171346	171346
176ad878-ab4f-41a8-83a0-e338075c675e	2026-01-24 20:10:26.950026+00	16.5	28.2	193651	193651
aadd4a71-c99c-411f-8889-2d41a89939bf	2026-01-24 23:01:26.877523+00	12.5	27.5	270578	270578
da1ec087-c970-4a3f-8dc6-b9753eea8e9e	2026-01-24 14:28:54.527103+00	26.2	33	6549	78185
da6ee18a-335a-4b9b-a210-ea831e056580	2026-01-24 17:19:57.049946+00	16.6	28	2397	1297
439c0b73-9090-4e0e-9c35-786c79f4e78a	2026-01-24 20:10:59.57978+00	16.6	28.1	2424	1323
20023b95-848a-407e-acf7-7fa996e19786	2026-01-24 23:02:01.918226+00	13.9	28.1	2412	1360
0122b29e-0976-45a9-ba50-b025ab86f097	2026-01-24 14:29:22.858595+00	21.6	33	36645	36645
8e46e175-dcfc-44de-8dee-001b52892665	2026-01-24 17:20:26.918849+00	16.6	27.7	198810	198810
4c39c2b1-9c08-4f2f-b31f-682a00de1115	2026-01-24 20:11:26.904057+00	14.1	28.1	172907	172907
ca290d48-0f72-44bc-8197-08875d09d177	2026-01-24 23:02:26.922892+00	12.4	27.6	223260	223260
71c17606-7da9-4966-b2e4-a37dbe1b6f8a	2026-01-24 14:29:54.545951+00	21.9	34.8	6698	111601
b6bb32e7-bc29-4a5d-8054-b8bcaf127a16	2026-01-24 17:20:57.110884+00	17	27.8	2090	1284
b47b835f-bafb-4f78-abb0-0ce51daa93fa	2026-01-24 20:11:59.555524+00	14.8	28.1	2544	1313
2500d754-c0af-461e-977c-0a8f5f76c48a	2026-01-24 23:03:01.942258+00	13.5	27.3	2866	1365
87d4088d-4715-434c-af50-d29401281992	2026-01-24 14:30:22.924204+00	16.6	34.7	2563	2563
732fb004-6761-4b97-9e9d-b36a07a13338	2026-01-24 17:21:26.95948+00	16.4	27.4	183686	183686
3721d55c-ef77-4a0f-85f8-71c9a0a0188f	2026-01-24 20:12:26.964304+00	14.6	28	173194	173194
de007d99-7254-42e7-af92-8c7c34bf3837	2026-01-24 23:03:26.922441+00	12.3	27.5	153987	153987
d5410c75-12af-404a-ae34-fcda94364edb	2026-01-24 14:30:54.578882+00	18.1	34.8	2313	1866
dcbf0fee-ea75-4012-b014-5a2602a2ec62	2026-01-24 17:21:57.063723+00	16.6	27.8	2201	1308
d8e03d8f-1306-4b3e-9637-c9a172646e65	2026-01-24 20:12:59.605721+00	13.9	27.7	2454	1305
2f4a3766-64b5-4012-b362-4e0074a59f48	2026-01-24 23:04:01.960317+00	13.2	27.3	2356	1383
cf9e7595-3ecb-4efc-a605-3919bd854625	2026-01-24 14:31:22.831908+00	16.4	34.9	2574	2574
3914a40d-1b21-4b7d-9e21-4a38d16d50b6	2026-01-24 17:22:26.89867+00	16.5	27.8	483789	483789
cce3c8d6-1a19-4827-9d76-59eb1dce768d	2026-01-24 20:13:26.94891+00	15.1	27.7	189295	189295
912c1ac2-1ef2-4742-a536-986972663a67	2026-01-24 23:04:26.98969+00	13.5	27.6	183113	183113
7fa993f8-265b-4cb1-a572-bac433de29fe	2026-01-24 14:31:54.579107+00	16.7	30.3	2391	1900
9a6cd722-b434-4d6b-9a3c-2eeedfb7c993	2026-01-24 17:22:57.123857+00	16.6	27.6	2135	1304
8ed44389-8677-4bea-a42a-f74a7f4c6db0	2026-01-24 20:13:59.611367+00	13.5	27.7	2737	1458
77c47a7a-9810-41ce-a2e1-a35055c5b033	2026-01-24 23:05:01.977611+00	13.6	27.5	2265	1325
b4477ed3-c29c-4de4-8370-90b82c5f043e	2026-01-24 14:32:22.863061+00	16.9	30.7	2602	2602
08a2981e-a9e1-4b1f-b270-30661fe11d24	2026-01-24 17:23:27.114905+00	16.6	27.8	223873	223873
4c8c7e50-4520-47fc-8ae3-bd39db5413cf	2026-01-24 20:14:26.884842+00	14.1	27.5	178509	178509
db7e311f-fd6f-481d-a320-6d60b60425b4	2026-01-24 23:05:26.994875+00	13.3	27.4	213364	213364
c91d8197-5240-43cd-a75a-53e6de4aa8d9	2026-01-24 14:32:54.634678+00	16.7	30.6	2285	1849
ee8e9ba1-9b99-4c98-b19d-b816742a686b	2026-01-24 17:23:57.125692+00	17	27.4	3061	1651
30655dc1-aca5-454e-86fa-dcd55967b0b6	2026-01-24 20:14:59.632031+00	16.4	27.2	2090	1323
15923c7c-10b2-4d61-81bd-a19853c107e5	2026-01-24 23:06:01.998878+00	13.4	27.7	3448	1966
c79d3a00-59ce-4c39-8d07-cc786637aa11	2026-01-24 14:33:22.875408+00	16.5	30.7	2733	2733
e24a2351-2a52-4469-b4ff-845ca315ed9b	2026-01-24 17:24:26.988271+00	18.4	27.5	141693	141693
55a59cde-2887-4aba-8738-052c83fc6162	2026-01-24 20:15:26.928063+00	14.3	27.1	223758	223758
eeafad74-c5a6-47dd-bf35-6b68099b5267	2026-01-24 23:06:26.982345+00	13.4	27.4	219979	219979
28e0b59e-7c49-4e80-944d-2722260a9739	2026-01-24 14:33:54.651526+00	16.8	25.6	4152	2507
351a940f-0e58-44c8-bcb3-b2b1c9c4c965	2026-01-24 17:24:57.131348+00	22.2	27.3	2828	1444
0d8bca8f-3e74-48c0-902f-432f315c5b34	2026-01-24 20:15:59.652715+00	15.3	27.2	3536	1898
6a06e662-8bd5-417b-bd14-b589fb34fe9a	2026-01-24 23:07:01.993109+00	13.3	27.2	2942	2343
78314778-2a2f-41e4-8936-49428c994db1	2026-01-24 14:34:26.984765+00	17.3	25.7	189235	189235
ff572299-5c05-4367-a1e7-cb93f18a18e7	2026-01-24 17:25:26.903634+00	15.7	27.5	108944	108944
097542bc-581b-496c-9ec3-02633688d387	2026-01-24 20:16:26.943147+00	15	26.8	221984	221984
cf10e69d-a42b-4baf-9b06-fe7824bcf754	2026-01-24 23:07:26.998521+00	14.9	27.7	144424	144424
49c02692-4ea8-4989-af68-de2953d49894	2026-01-24 14:34:54.667737+00	17.5	24.4	2615	1760
63a72099-e5f8-4b39-a18b-8c90b3f137a3	2026-01-24 17:25:57.128781+00	19.3	27.5	2371	1276
8305d125-5655-4be7-bd7e-329118cde488	2026-01-24 20:16:59.625233+00	13.8	27.3	2340	1451
b19cedf8-6d41-46a1-b72b-cd0608354486	2026-01-24 23:08:02.01581+00	13.4	27.8	2509	1449
abb57367-bd1c-4b06-91be-9848346dabc7	2026-01-24 14:35:27.023535+00	15.5	24.4	278481	278481
6ef3a7ab-61ea-41a9-bedc-45dccfecb576	2026-01-24 17:26:27.026289+00	16.2	27.6	124388	124388
1bace831-d948-4707-a97e-a2d813d4d477	2026-01-24 20:17:26.933578+00	13.5	27	263833	263833
18fd5a33-ec0e-4428-b01a-07fead914a4e	2026-01-24 23:08:27.022444+00	14.3	27.4	238365	238365
ea258d3a-33aa-4238-9785-aa29d394ad8d	2026-01-24 14:35:54.688711+00	17.4	24.1	2570	1668
b611f405-9432-4ad6-83dd-8b32bb4dbf22	2026-01-24 17:26:57.134283+00	18.2	27.4	2481	1302
d93dfa95-2330-4b0a-8170-d36008603176	2026-01-24 20:17:59.666154+00	13.8	27.3	2834	1550
2991f5e9-4c59-4811-aa2a-5e69a06cb6c0	2026-01-24 23:09:02.032898+00	12.9	27.4	2240	1389
631ad35b-65a2-4093-a1e8-8de932dd2fcb	2026-01-24 14:36:27.095741+00	15.7	24.5	187254	187254
5608a4e3-857b-4a3e-b16c-65170480f1ed	2026-01-24 17:27:26.888435+00	17.7	27.5	211126	211126
be4071eb-d3f3-4a6a-b803-a24dd42bf890	2026-01-24 20:18:26.975872+00	13.2	27.1	217597	217597
cbc006f7-54ab-43f2-ac10-bb2fac198321	2026-01-24 23:09:26.851608+00	14.6	27.1	240145	240145
affe299f-7b13-4b70-97f9-1cb58241263a	2026-01-24 14:36:54.634473+00	22.3	24.2	2602	1710
26010553-e4cf-4ec8-ae68-a4f3555d4bfa	2026-01-24 17:27:57.150027+00	17.1	27.4	2490	1406
c236dea9-ea18-4f4a-8d45-816166cab5d2	2026-01-24 20:18:59.691559+00	14	27.3	2950	1317
3661877c-42f5-4bb5-9ccf-336bd7bbacbc	2026-01-24 23:10:02.050567+00	14.7	27.4	2482	1348
28b00240-b395-401d-886a-5a6f68f9fb9c	2026-01-24 14:37:27.048632+00	16	24.5	204930	204930
ad7fb995-2f43-4aff-9e23-8b927b523c5f	2026-01-24 17:28:26.931672+00	15.3	27.6	326499	326499
187f7004-cb30-41af-bfba-45b65701b863	2026-01-24 20:19:26.981702+00	13.5	27.1	170384	170384
e86b78bc-c4e0-49bb-82ba-8d934494bcfe	2026-01-24 23:10:26.840035+00	16.8	27.2	249600	249600
b917f0c1-c882-47ac-8562-bcf9a6186e3b	2026-01-24 14:37:54.687255+00	17.1	24.7	2348	1715
34ef2a63-ee23-4ed0-8664-998f5f2c6661	2026-01-24 17:28:57.170138+00	17.3	27.8	2135	1289
50863bf3-8fe5-422b-9fe9-7fc9bd58c25a	2026-01-24 20:19:59.676357+00	13.8	27.2	2472	1326
1904300e-c844-4af8-af5a-f757a19dc7ac	2026-01-24 23:11:02.068178+00	12.1	27.5	2540	1345
130bd706-3b18-4e15-834f-94a257a4b3bc	2026-01-24 14:38:27.042739+00	16.9	24.6	127615	127615
f9f460ea-d274-4aa4-8d12-72e68a359f91	2026-01-24 17:29:26.949507+00	16.3	27.4	110697	110697
94af9623-0dd1-4b19-a043-5706292cfb8f	2026-01-24 20:20:26.992265+00	12.8	27.3	209855	209855
de98bc09-f552-4e1b-9b57-1075e2be9ba5	2026-01-24 23:11:26.933989+00	14.9	27.2	183792	183792
3d6e6463-e5a4-40de-bd0c-d1869328beae	2026-01-24 14:38:54.674305+00	17	24.5	2351	1849
18b563b3-25e0-415b-aa80-901367e2426a	2026-01-24 17:29:57.241379+00	16.8	27.4	3023	1654
39d1c8d0-a3fa-4122-bfb7-93f7f7fc7203	2026-01-24 20:20:59.727342+00	14.4	27.4	2460	1318
cfcfca01-26d7-45b0-b667-6f60751ec126	2026-01-24 23:12:02.065722+00	13.3	27.5	2397	1277
f0acd417-e96d-4587-ab6a-79d9b4b9efe9	2026-01-24 14:39:26.94545+00	19.4	24.6	143069	143069
ccf1506e-0d22-4475-851f-5317b3130578	2026-01-24 17:30:26.961509+00	15.7	27.6	182021	182021
1908a371-f334-4f01-b6f1-6a1985c46cf7	2026-01-24 20:21:26.962757+00	12.4	27.1	189936	189936
877b3216-33bc-498f-8c6f-56776f77cdcd	2026-01-24 23:12:26.890346+00	14.1	27.3	173273	173273
366ddc70-b4e5-4713-8d82-964166b6559f	2026-01-24 14:39:54.749836+00	16.4	24.1	3757	2323
ea7b1628-ba9f-4cc2-9cbd-e2c4121a6b66	2026-01-24 17:30:57.205507+00	17.3	27.5	2500	1440
50e296be-dc6f-4fa0-9cb5-85089cad5039	2026-01-24 20:21:59.703796+00	13.8	27.3	4678	2902
a077045a-7155-4205-bedb-efe873cbed7c	2026-01-24 23:13:02.089487+00	12.7	27.4	4117	1944
58aa9c5c-1d27-4041-a256-f1b4b7f2cfe9	2026-01-24 14:40:27.034359+00	17.5	24.1	240808	240808
04ad28eb-0e11-454c-971b-ac11775f29ea	2026-01-24 17:31:26.917623+00	16.7	27.5	197360	197360
a8033cba-737e-428a-8932-af7476f25a48	2026-01-24 20:22:26.95935+00	12	27.1	166358	166358
240644f5-07d5-4dad-9834-9cbf05a34eab	2026-01-24 23:13:26.880375+00	12.8	27.4	168491	168491
b72f1411-3402-459e-ac40-5a462c1a8cbc	2026-01-24 14:40:54.757454+00	16.2	24.3	2333	1840
61211de4-8629-43da-beeb-fdca938e0be1	2026-01-24 17:31:57.226644+00	16.6	27.6	3772	2416
c58abea1-f32e-4cc3-8420-f737959b4378	2026-01-24 20:22:59.749451+00	13.9	27	2177	1326
ce8f3928-1a47-4d49-aec2-42319ac0b4e3	2026-01-24 23:14:02.106448+00	13.5	27.5	2492	1485
e43a4af8-07c4-4596-a910-67a0f7ba7596	2026-01-24 14:41:26.985549+00	20.1	24.3	272162	272162
ad9eb1ef-0920-4969-9d4a-28fdac8fcc8c	2026-01-24 17:32:26.954743+00	16.6	27.5	219236	219236
a1684f5a-1ec4-46f9-9d14-693774ab800e	2026-01-24 20:23:26.940711+00	13.2	27	245073	245073
99b9409f-ca81-41ba-84b9-98c21f1f2701	2026-01-24 23:14:26.925009+00	12.6	27.5	230777	230777
37f32f1e-a334-401e-8f1e-139698503cf5	2026-01-24 14:41:54.725255+00	17.1	24.3	2625	1801
ecb17fca-a4f0-4ebf-91a7-0adfa7c8cf98	2026-01-24 17:32:57.279626+00	16.6	27.5	2974	1289
5d68dd60-3d2e-4992-bd43-d7a6ed0d9e2c	2026-01-24 20:23:59.766912+00	13.9	27.1	2130	1341
9ddc7cb7-b93e-4b0c-95df-8683c878935b	2026-01-24 23:15:02.123714+00	13.2	27.4	2129	1327
a003a829-c386-4d0a-bf76-5d1f12ecb42a	2026-01-24 14:42:26.946144+00	17.9	24.7	192413	192413
b5f66b58-9eb6-43b0-92e8-eaf70ebd8d52	2026-01-24 17:33:26.904632+00	16.8	27.8	126044	126044
e3b941fd-a491-40e5-905b-2bb75e9f9922	2026-01-24 20:24:26.973385+00	12.1	27.2	277772	277772
b2871282-50b6-45dc-8dd3-bf84d0f6193e	2026-01-24 23:15:26.924499+00	11.8	27.5	218972	218972
76951718-f9a7-4bca-9499-f1be6bd2cf80	2026-01-24 14:42:54.771725+00	16.8	24.6	2570	1721
f2d8a247-7f25-4cbb-b6a8-6b1e02d77b15	2026-01-24 17:33:57.290002+00	16.5	27.9	2410	1294
202e40fd-a1e4-40ce-8b4c-b0469d4130f9	2026-01-24 20:24:59.771889+00	14.5	27.2	2128	1309
ea80cc60-8962-40fc-a0b1-bb7b6867cd94	2026-01-24 23:16:02.142249+00	13.4	27.4	2192	1323
d7297efb-b834-40b6-a38b-ecdcf79c1f19	2026-01-24 14:43:26.955434+00	17.4	24.6	209749	209749
467239c6-e9f1-4110-8742-d52ae94cfdd5	2026-01-24 17:34:26.942367+00	17.3	27.9	120849	120849
078398db-24c0-42d0-912b-a2f146fb539a	2026-01-24 20:25:26.935134+00	11.4	27.3	196771	196771
510842e0-b892-4d21-8b3b-e25613994f1b	2026-01-24 23:16:26.914761+00	12	27.5	198135	198135
1cf691d5-5858-4ed5-9e4b-a3349e324cb9	2026-01-24 14:43:54.738016+00	16.9	24.6	3477	1941
d8e7d009-cb08-4772-8c61-18da021ed4f9	2026-01-24 17:34:57.310439+00	16.8	27.6	2339	1293
65004740-cc21-4249-8aa6-14cfdd6cfab2	2026-01-24 20:25:59.789078+00	15.6	26.9	2551	1333
1f26e622-aa51-4d3d-b957-f9b8d96a7f1d	2026-01-24 23:17:02.141087+00	13.6	27.5	2698	1348
3b4f9ce0-b14a-4710-9db3-0f2be9e3de8b	2026-01-24 14:44:26.935079+00	16.4	24.6	303012	303012
1f7856d2-bf4e-4c29-a1a5-f5aec940ec7a	2026-01-24 17:35:26.930763+00	16.5	27.4	150349	150349
16c3ae31-bdb3-4c98-ad9b-9b7d750465bd	2026-01-24 20:26:26.950699+00	13.6	27.2	134787	134787
8ff67462-4fe9-4d3c-bfb2-871da3228bc5	2026-01-24 23:17:26.960084+00	12.1	27.5	256469	256469
23d2f2c9-80e1-4baf-aacf-30b1326886cf	2026-01-24 14:44:54.756567+00	16.7	24.7	2548	1685
c7418e79-7b76-45ee-aa11-7dd3e4611781	2026-01-24 17:35:57.324274+00	17	27.4	2121	1291
da5884b3-57e2-48ff-b6fa-ecbec5d6aebc	2026-01-24 20:26:59.744162+00	14.9	27.4	2454	1312
eaabf326-c0c7-4b6e-b5ac-ec22535a2775	2026-01-24 23:18:02.165645+00	14.3	27.4	2854	1409
16ad8d8a-a762-480f-bf19-db65f5a4de6d	2026-01-24 14:45:26.916582+00	19.9	24.2	226257	226257
95583daf-1f14-4ac0-b040-bb0f338b20e7	2026-01-24 17:36:26.978597+00	16.3	27.5	160124	160124
3dc6af37-1569-4b02-a2dc-daae80c75cef	2026-01-24 20:27:26.94317+00	12.4	27.1	211745	211745
aac14dba-f910-44b8-8e03-f0a40adc374b	2026-01-24 23:18:26.972008+00	13.4	27.6	164936	164936
d73147f9-150e-4add-b3ba-e6bd7c8eeb20	2026-01-24 14:45:54.822909+00	17.9	24.6	3859	2350
35e76e9d-fb2d-4737-8645-474e31253670	2026-01-24 17:36:57.265951+00	16.4	27.4	2583	1542
c03977f3-544e-48e7-a94e-c514d4eee0d7	2026-01-24 20:27:59.812784+00	14.3	27.4	4188	1990
8dd921e3-956a-410b-bec0-53250f597b24	2026-01-24 23:19:02.181027+00	14	27.1	4455	1947
d120d062-7fec-4584-9f6c-ab0418d48eb9	2026-01-24 14:46:26.90912+00	16.6	24.6	294862	294862
4dd45497-8edc-453b-9d62-094683af5e08	2026-01-24 17:37:26.978602+00	16.6	27.4	160147	160147
657e5801-3025-46cd-bdaa-2aa3eb3654d2	2026-01-24 20:28:26.902294+00	13.1	27.4	146834	146834
42199143-e36e-4e53-979c-2e0186d00d25	2026-01-24 23:19:26.903429+00	15.8	27.2	181941	181941
e9da55d1-f3d7-4180-924e-37b98e254a4f	2026-01-24 14:46:54.792301+00	16.8	24.8	3333	2721
7d503681-b86f-457b-975e-929db217cb16	2026-01-24 17:37:57.290502+00	16.5	27.5	3503	1676
a67abe77-364b-4911-923c-33f8b77ca1dd	2026-01-24 20:28:59.784286+00	13.6	27.4	2478	1356
f880cf7a-36fc-47df-b5ed-d129d4641629	2026-01-24 23:20:02.199433+00	15.8	27.3	2641	1338
921f2348-55a5-4e6b-8bfb-0e7b1c193e34	2026-01-24 14:47:26.963503+00	16.7	24.7	195773	195773
e953f051-17bf-41e1-b73b-d528a368ebc4	2026-01-24 17:38:26.954744+00	16.5	27.8	150301	150301
67694572-9080-4aed-8488-f59c2b09eb9d	2026-01-24 20:29:26.889383+00	13.1	27.3	265772	265772
3538a22d-94da-49e5-b8e9-fc6745e28f9a	2026-01-24 23:20:26.930314+00	12.8	27.4	141824	141824
073bb1fc-85a2-41a4-8d7e-51b09163454d	2026-01-24 14:47:54.83706+00	16.8	24.6	2206	1644
a6ba25cc-7188-4a68-9702-2ce17990d38e	2026-01-24 17:38:57.3633+00	16.4	27.7	1714	1318
b7f79571-46b5-4e36-be62-64c076afe460	2026-01-24 20:29:59.840076+00	13.5	27.4	2406	1334
9de81804-01b9-42e4-aa99-26665fa7a570	2026-01-24 23:21:02.217113+00	14	27.3	2336	1335
74620320-e4cf-46cb-90fb-9b4304a68e2c	2026-01-24 14:48:27.003356+00	16.9	24.3	225469	225469
96cccc4f-a84d-4fb6-8488-603342856a08	2026-01-24 17:39:26.913634+00	17.3	27.5	178202	178202
2a511f2d-24ef-43b6-8371-914b7d60bde5	2026-01-24 20:30:26.93983+00	13.4	27.3	150278	150278
3ef6840a-1ab2-4511-8534-24ee089819da	2026-01-24 23:21:26.813802+00	13.6	27.4	213881	213881
c8f04ad2-13ee-4113-a436-bae28eb3f0bf	2026-01-24 14:48:54.861642+00	16.9	24.9	2973	1773
13985558-ac4a-495f-8c2a-cffa34ae4f98	2026-01-24 17:39:57.348181+00	16.8	27.7	2403	1291
9fdf9235-2566-401b-bceb-409a2521821d	2026-01-24 20:30:59.824062+00	13.7	27.4	2122	1323
7c5b53cf-27b5-4fba-882f-2a1f503190c8	2026-01-24 23:22:02.216563+00	13.2	27.5	2405	1327
38a432f5-3a2b-43d9-87b3-d68ba5931ec4	2026-01-24 14:49:27.038453+00	17.1	24.5	131163	131163
3a5b6935-51bf-4c4c-a4b0-cd828a23cfb6	2026-01-24 17:40:26.919267+00	18.8	27.4	218542	218542
96eb1598-d0ec-40b3-a5c7-d27e3fc0e5c7	2026-01-24 20:31:26.864254+00	13.4	27.2	332920	332920
2e553217-9271-4ce0-bdc9-63db0578ef5b	2026-01-24 23:22:26.862227+00	12.7	27.5	291691	291691
d07a9f65-f318-4f5b-a8c4-79d1cdc00e42	2026-01-24 14:49:54.843455+00	16.7	24.8	2596	1738
c1868c2a-f15a-4679-8270-af5a5b8f44a9	2026-01-24 17:40:57.388545+00	18.8	27.8	2410	1311
909651d2-9df7-4359-b3ce-c45b2a17fce8	2026-01-24 20:31:59.836186+00	13	27.2	2139	1340
724ba5e4-c0d1-4d56-9a1f-dfd43ecebf9d	2026-01-24 23:23:02.281465+00	14.5	27.1	2417	1333
c9b036bc-a200-46c2-ae2b-66d119e765b7	2026-01-24 14:50:27.129435+00	16.7	24.6	216049	216049
929ea445-c3da-420a-bbfc-2189e363fad0	2026-01-24 17:41:27.013379+00	16.9	27.8	136425	136425
c7ac7c83-ba89-499e-a032-942b65d86c96	2026-01-24 20:32:26.964209+00	13.3	27.2	137497	137497
dc8d1a70-b2b1-42ab-be49-d96f6f36bdf4	2026-01-24 23:23:26.877472+00	13.2	27.1	186864	186864
3f6100c2-c371-49ec-8bce-2785b53fdfeb	2026-01-24 14:50:54.901037+00	16.6	24.8	2602	1732
8c934602-2e04-4eff-8727-19172cf42a9e	2026-01-24 17:41:57.373547+00	17.1	27.6	2413	1296
7b96f91b-61f8-4060-9861-a5ae8cf6895c	2026-01-24 20:32:59.850388+00	13.5	27.1	2420	1294
64537d19-2a50-4e0e-a96a-03b5f008217b	2026-01-24 23:24:02.249282+00	13.5	27.1	2260	1301
b24980fc-8648-438e-a7d6-c0ee35b29e4d	2026-01-24 14:51:27.000907+00	16.4	24.7	211641	211641
34ad73e9-565f-4b37-9dc2-143e9b916dc0	2026-01-24 17:42:26.974492+00	15.5	27.8	229667	229667
bb0de801-c25c-46c3-8e1c-17c8b1394a6c	2026-01-24 20:33:27.005437+00	13	27.2	180313	180313
b546c642-d5d8-46eb-97a3-a1312ee5f0e3	2026-01-24 23:24:26.900721+00	13.1	27.1	245848	245848
7bb1d808-1394-4a48-9491-b1aef80c189a	2026-01-24 14:51:54.871888+00	16.6	24.7	3515	2070
406df36f-98f4-40dc-aaed-488c68cd2d1a	2026-01-24 17:42:57.368863+00	16.6	27.5	2619	1537
d2f70fe7-7e55-40ee-8f28-500f1b9b2036	2026-01-24 20:33:59.883568+00	14.7	27.2	3867	2110
6bd35343-889e-4886-bea9-95c08fd8772b	2026-01-24 23:25:02.318552+00	13.3	27.2	4782	1939
5201d5cd-c16a-46ab-9b0d-aa894771f950	2026-01-24 14:52:27.01313+00	17	24.7	178131	178131
70ecf841-9822-48b4-bf90-6fe5a9debc20	2026-01-24 17:43:26.924366+00	15.1	27.5	153396	153396
de7a04c8-620a-4dbc-a078-2f9001f1cb3c	2026-01-24 20:34:26.951172+00	13.1	27.1	244951	244951
dce3e0d1-33ed-4a3b-b1fd-3253c0a34e12	2026-01-24 23:25:26.881155+00	13.1	27.1	159590	159590
f014ca22-cebf-401d-80cf-ffaa7d0cf133	2026-01-24 14:52:54.916188+00	16.7	24.8	2898	1924
68d07247-5b3b-4071-9238-fda43f715702	2026-01-24 17:43:57.434465+00	17.2	27.3	3151	1691
a16e28b4-c8c3-4d23-839b-34ca53eda4e7	2026-01-24 20:34:59.916924+00	13.5	27.3	3013	1341
1bd4bcab-0bc1-416e-bd4f-a7498da7aa1c	2026-01-24 23:26:02.331916+00	11.9	27.3	2703	1379
a4874896-3b62-485a-8409-af6c17586d07	2026-01-24 14:53:26.991931+00	17.3	25	182079	182079
69a749cb-1674-4320-9a90-5ddd9102f083	2026-01-24 17:44:26.926177+00	16.2	27.6	261722	261722
dc49dcf0-ef88-40e8-b0a8-1500e0c6f225	2026-01-24 20:35:26.965506+00	13.4	27.2	157362	157362
dfdac180-aab9-45b8-8f4f-d6a052f07945	2026-01-24 23:26:26.899459+00	13.2	27.3	183006	183006
fc3160e4-058f-4996-84d6-ca0f87177c2b	2026-01-24 14:53:54.890424+00	16.7	24.7	2306	1696
b6b0ff06-a245-41ca-996a-57abf2b04656	2026-01-24 17:44:57.390422+00	16.8	27.3	2124	1299
468c1ca5-24d0-4787-b43d-103d74994f36	2026-01-24 20:35:59.936881+00	13.8	27	2466	1357
29a90a3c-50b5-42ff-825b-596bb24bd2ca	2026-01-24 23:27:02.282914+00	13.2	27.3	2851	1461
e0de8f1f-460e-4a68-b1ec-423f609ebf15	2026-01-24 14:54:27.027306+00	19.8	24.8	163259	163259
19878166-b5dc-4c16-b8f8-49d7e08163ca	2026-01-24 17:45:26.892787+00	16.1	27.7	134430	134430
d81a7669-3c7e-48f7-a05c-691258bc6d4e	2026-01-24 20:36:26.953935+00	12	27.3	119998	119998
6295a77f-4a95-403d-b49a-04de9992cbe1	2026-01-24 23:27:26.906955+00	13.7	27.2	249877	249877
1a19bf33-19d8-4f8a-8598-3cab66fa29c8	2026-01-24 14:54:54.955211+00	15.5	25	2238	1780
1bd107a3-acd5-445f-af2d-bf7750dab6e4	2026-01-24 17:45:57.442782+00	16.6	27.8	2091	1280
7f567382-50f0-4392-bd8b-0894f1d81173	2026-01-24 20:36:59.914665+00	16.4	27	2370	1312
225646b9-6fb8-43c4-8152-6fd7d1ed3d5e	2026-01-24 23:28:02.311549+00	14.9	27.1	2596	1487
8c9886e6-124c-47e1-a944-5c8dbddc43c6	2026-01-24 14:55:26.84847+00	17.2	24.9	238782	238782
929a66de-0155-48ec-b3d1-bdc84d20a5c2	2026-01-24 17:46:26.983369+00	16.7	27.9	140189	140189
93b7395f-194e-4394-b106-76265e92585f	2026-01-24 20:37:26.915448+00	16.1	27.1	168446	168446
8225b148-ea07-4670-89e8-e4730c0a5f5a	2026-01-24 23:28:26.942462+00	23.5	26.9	142300	142300
154d6065-57fc-43c7-a1c4-72b45f09bda5	2026-01-24 14:55:54.97505+00	16.7	25.1	2434	1817
38e0b00e-1363-42c2-8e05-b704b5f848af	2026-01-24 17:46:57.404625+00	16.7	27.7	2372	1296
c3763b74-fedc-47dd-a254-3fcfc372b9c1	2026-01-24 20:37:59.917051+00	14.8	26.9	2385	1437
84e03897-bfb5-4a45-983d-f7b47daccff5	2026-01-24 23:29:02.332447+00	16.3	27	2361	1379
acefa698-3ef7-413d-a547-f60e3db72234	2026-01-24 14:56:26.923036+00	16.6	24.5	244258	244258
5017337b-3ca1-43fd-9659-8b42c416dba2	2026-01-24 17:47:26.957413+00	16.4	27.9	194856	194856
27da30cf-1090-4bad-8197-77280cf432ee	2026-01-24 20:38:26.899613+00	16.4	27	151682	151682
85c6debb-01ff-4076-9c0a-798132626b68	2026-01-24 23:29:26.882335+00	15.4	27.2	77941	77941
a788fcd3-b1b7-4de9-b5ef-bcf1296f0aea	2026-01-24 14:56:54.953571+00	16.6	24.7	2606	1578
adf1c525-f1a1-4ed0-95bc-2bd0eadf30f9	2026-01-24 17:47:57.480574+00	17.4	27.8	2634	1389
a774aab1-7c3d-4103-8822-37de8d148df1	2026-01-24 20:38:59.97736+00	15.2	27.1	2089	1308
b4fc98c6-d4b1-46b2-b08a-8da13d0b5656	2026-01-24 23:30:02.35975+00	16.4	27.3	2336	1351
3c1c2fcc-5ab1-4a70-bf1d-b415eb6b6b43	2026-01-24 14:57:26.977871+00	17.2	24.5	140790	140790
e0cc8dd2-1160-4cc2-9494-e27166882c5b	2026-01-24 17:48:26.959626+00	15.9	27.9	154989	154989
17519f37-cd8c-446a-8d75-1afdde2f5080	2026-01-24 20:39:26.83011+00	15.4	27.3	211796	211796
b0d25274-1e86-46d5-a80a-79ca6437a457	2026-01-24 23:30:26.92475+00	12.4	27.3	184597	184597
8b473fe7-4e10-45ee-8ab2-7c8a0e351937	2026-01-24 14:57:54.967198+00	15.4	24.7	3525	2099
da1e6926-ef23-42d4-a866-f6c4a81daa69	2026-01-24 17:48:57.468442+00	16.5	27.7	3371	1494
c0f5755c-90f1-4f0d-97e4-8073485e7d33	2026-01-24 20:39:59.944442+00	15	27	4055	1910
27275db8-8673-4142-9af7-64153d6e747c	2026-01-24 23:31:02.359612+00	13.8	27	3981	2000
586036a3-043b-42f2-b90b-bd0abd41d7bb	2026-01-24 14:58:26.88862+00	16.3	24.6	275773	275773
2f632e00-6714-4848-bd71-cbbcb8d55e51	2026-01-24 17:49:26.986251+00	16.7	27.7	154478	154478
f0a040a7-5259-4f67-b528-236fd42bb76c	2026-01-24 20:40:26.87608+00	13.8	27.2	290181	290181
ee0dadb9-ad5a-465d-8589-918ec68b5a69	2026-01-24 23:31:26.89655+00	14.3	27.1	222162	222162
5c4b1eaf-537a-4ce8-a025-7587a7ff95ed	2026-01-24 14:58:54.974726+00	16.4	24.6	2962	1815
d70f9ff0-c256-435b-9371-3b1bc11fa14c	2026-01-24 17:49:57.469757+00	16.2	27.6	3107	1565
7e1251b7-e21a-44c4-8724-39c0e7bd1388	2026-01-24 20:41:00.012664+00	16	27	2441	1329
8a0a648d-67f2-44b0-91b4-72f486e12f30	2026-01-24 23:32:02.356369+00	16	27	2741	1376
3ae8830b-bb8b-46ac-997c-1a20e3e857d5	2026-01-24 14:59:26.969675+00	17.1	24.6	141896	141896
17e648a6-7e7d-4740-8873-172a39bb1e82	2026-01-24 17:50:26.99407+00	16.7	27.8	168845	168845
443e2634-f83a-466a-8189-16153c2697be	2026-01-24 20:41:26.894679+00	13.7	27.1	186485	186485
a7331da6-ccf5-4b5a-ace6-c2de8e4d2b10	2026-01-24 23:32:26.908766+00	15.9	27	97531	97531
640a6179-8b5f-4da9-91af-d7b4598505d9	2026-01-24 14:59:55.037039+00	16.2	25	2637	1789
e8ba3fed-6d51-449d-84e0-bc31c599622f	2026-01-24 17:50:57.500268+00	16.3	27.9	2152	1292
bab6501a-4089-4562-9cf5-a9812015d003	2026-01-24 20:41:59.969683+00	14.5	27	2448	1324
39a00722-ddd9-41a7-aadf-ce70b5c5ac2b	2026-01-24 23:33:02.42292+00	16.1	27.2	2703	1367
55c0ee47-55a4-4e50-8d88-f6b67eec024c	2026-01-24 15:00:26.964574+00	16.9	24.7	236712	236712
e9800dd6-a7cb-4f29-a5f2-5a74b876c94b	2026-01-24 17:51:26.944416+00	17.5	27.4	353141	353141
7fa0adeb-9aa4-42db-9816-ec1420dacbab	2026-01-24 20:42:26.949215+00	12.2	27.2	195770	195770
341829c2-64f2-426a-902d-f23198a51506	2026-01-24 23:33:26.916796+00	12.6	27.2	166013	166013
a8d62246-7879-4e41-a669-149279e23358	2026-01-24 15:00:55.054741+00	16.5	24.9	2246	1650
e694d551-68f5-4041-b962-9c44e6f9fe15	2026-01-24 17:51:57.484874+00	16.6	27.6	2071	1289
bccaa9cc-8169-442c-acb2-d39a87b942f5	2026-01-24 20:43:00.035366+00	14.6	27.2	2489	1328
6612f4f1-ae87-421d-8154-73b5ad148fb8	2026-01-24 23:34:02.448449+00	13.4	27.4	2786	1392
55cb88ed-7d85-4746-9173-bb734c66c3cb	2026-01-24 15:01:26.967077+00	17.8	24.7	283279	283279
280f06c3-907e-4f32-af78-55eec9c6292e	2026-01-24 17:52:26.995463+00	18.8	27.6	187292	187292
6eb96835-a691-4c97-80df-58d570e40066	2026-01-24 20:43:26.867021+00	14.8	27.4	157020	157020
d44f47f1-3637-452f-81e1-bdf1a653abcf	2026-01-24 23:34:26.930779+00	13.7	27.3	166615	166615
01ea0696-590d-45a6-93f2-867d52bb3818	2026-01-24 15:01:55.002451+00	16.5	25	2485	1624
7b12ad00-be0d-422b-99e4-556e0a5d8af1	2026-01-24 17:52:57.559284+00	17.1	27.8	2133	1302
081de82a-c3e0-4589-8e5b-a8ccad6e9c0e	2026-01-24 20:44:00.003741+00	14.2	27.2	2676	1466
3e2a2cdb-57ea-4769-9095-291a771802d4	2026-01-24 23:35:02.453933+00	14.4	27.3	2646	1398
b67415f2-7747-419f-a5ba-0035c24e9c58	2026-01-24 15:02:26.961761+00	16.7	24.6	254368	254368
1ae2db6c-a592-47ac-bb58-b51488777bee	2026-01-24 17:53:26.98752+00	16.7	27.7	209353	209353
29b839eb-ac5b-48fb-95e8-a24193520862	2026-01-24 20:44:26.914913+00	12	27.6	227251	227251
3cc2299f-e4d7-4c7a-9b03-373083679a14	2026-01-24 23:35:26.934522+00	14.3	27.3	172273	172273
162de959-2d59-472a-9bae-c15e94ab197d	2026-01-24 15:02:55.077255+00	16.7	24.8	2320	1707
cebe2006-b841-4ee3-b1f9-2ea466ce525a	2026-01-24 17:53:57.56762+00	16.7	27.7	2630	1283
debc634e-5c4f-429c-b43f-d8e4131e7a20	2026-01-24 20:45:00.022391+00	14.5	26.9	2139	1306
71625aa1-bbfb-4416-b6fd-b5741ff6a648	2026-01-24 23:36:02.416258+00	13.6	27.3	2375	1356
22434d41-87c3-490f-87b3-96f671403c7f	2026-01-24 15:03:26.946015+00	16.6	25.2	252684	252684
8ddcab6f-863a-457f-93c0-f14397b0ad30	2026-01-24 17:54:26.959399+00	17.9	27.6	154488	154488
54cb98c1-f786-43da-9e2d-8dcd7ddb58ae	2026-01-24 20:45:26.919875+00	13.6	27.3	198758	198758
acd03e15-5a06-4b24-84c5-560a06df6fd4	2026-01-24 23:36:26.937637+00	11.9	27.4	190474	190474
d48dabab-37fa-41a2-8ed2-b4486066295e	2026-01-24 15:03:55.092237+00	16.6	25	3544	2100
2c5b608d-fda3-42a9-8615-d0e4ff51a1c0	2026-01-24 17:54:57.589783+00	16.6	27.8	2843	1510
145b9860-807c-4a73-b506-fb0326aa1c03	2026-01-24 20:46:00.040631+00	13.2	27.3	3580	1934
a24b6763-4321-4859-9eea-bf8c18cd95d6	2026-01-24 23:37:02.444502+00	13.2	27.6	4441	1966
5dbf1ad8-e9ad-4250-8174-a4fe804e11a3	2026-01-24 15:04:26.970023+00	17.2	25	205061	205061
ea9e5a13-c3c9-4e7d-becf-2e6f216a6f58	2026-01-24 17:55:26.896175+00	17.4	27.6	166339	166339
9ce60c72-0862-4d0c-bb7d-e68681ceedae	2026-01-24 20:46:26.947742+00	14.1	27.2	284593	284593
2f3ee569-503c-4e18-94e8-e6497d1d92ea	2026-01-24 23:37:26.852419+00	13.3	27.2	161903	161903
35fe1534-a355-4f5b-86cb-ee3ffeb260b0	2026-01-24 15:04:55.107725+00	16.3	25.1	3418	1811
1a9dca5e-dd5c-45d7-978c-9d5a3739888f	2026-01-24 17:55:57.604389+00	16.6	27.5	3289	1582
07981a46-2711-4a54-8085-b5accf66b056	2026-01-24 20:47:00.040414+00	12.8	27.2	2081	1326
76df89ea-cbde-4c35-806f-e5dff5679a72	2026-01-24 23:38:02.490092+00	14.4	27.3	2581	1476
38e5125c-c057-456a-a1a5-83a472daf044	2026-01-24 15:05:26.939792+00	15.3	25	139434	139434
6b6a4940-0590-414e-8d17-56767adf584d	2026-01-24 17:56:26.904041+00	16.7	27.7	273585	273585
1863749d-417d-4c12-8969-bb0bd3ebc814	2026-01-24 20:47:26.959912+00	15	27.3	143572	143572
64ed61e8-2070-4c8f-ae69-7601bfaefbe6	2026-01-24 23:38:26.789869+00	11.8	27.3	209815	209815
f94446f2-e52a-4ce7-b57a-944012b9c1cf	2026-01-24 15:05:55.126387+00	16.5	25.1	2605	1601
5cc5afc6-049e-44f2-9372-959ff65661a7	2026-01-24 17:56:57.592316+00	16.4	27.8	2404	1316
c913c2ed-07b1-49f5-8bdf-a2b488c6ae73	2026-01-24 20:48:00.117448+00	12.2	27.2	2363	1421
66925b87-c28b-4a51-b854-eae3c485f1bd	2026-01-24 23:39:02.455967+00	13.6	27.3	2707	1392
211583b3-de45-45ec-ba2f-a2695dab0848	2026-01-24 15:06:26.974398+00	16	25.2	208247	208247
ccd93dee-cb86-4d79-a750-82c04b022131	2026-01-24 17:57:26.960814+00	16.6	27.5	155466	155466
e8d9ae2d-91b5-4eb8-bd82-3c91c333ae43	2026-01-24 20:48:26.949272+00	15.9	27.3	167634	167634
91b688fd-69ff-497a-b64c-3194c25f466a	2026-01-24 23:39:26.875416+00	14	27.3	168467	168467
3546fc62-6718-457c-82b2-c4e8a009a256	2026-01-24 15:06:55.098317+00	16.4	25.2	2624	1655
eb78564f-3e6e-4b48-aa3a-c4dddb29e54c	2026-01-24 17:57:57.626112+00	16	27.7	2315	1410
2a6238b7-7bd5-46d3-8ae8-cc2461e3b51e	2026-01-24 20:49:00.131186+00	13.5	27	2504	1325
12d359cf-5885-4f00-8a58-576202b8a059	2026-01-24 23:40:02.523753+00	12.9	27.5	3335	1349
e2f3a6af-94b1-41c7-9a3b-8d8d7d297a53	2026-01-24 15:07:26.885952+00	16.4	25.1	121635	121635
e6613f25-35dc-4cf1-99d5-499e72c31dd4	2026-01-24 17:58:26.969162+00	16.7	27.7	188587	188587
239781af-daca-4f69-8d6f-f2aba317e7e9	2026-01-24 20:49:26.961623+00	19.4	26.8	187095	187095
54521f2f-17a9-4b8b-ac7a-05e8a5df3d1f	2026-01-24 23:40:26.873712+00	13.2	27.4	198614	198614
3ebdda27-ad96-4ef3-a8b9-f708848e9d28	2026-01-24 15:07:55.143326+00	16.4	25.2	2039	1585
fdb61fce-0dc7-4bfc-9444-09e722788894	2026-01-24 17:58:57.608372+00	16.5	27.7	2109	1301
cb44e008-5962-4697-b443-1d042c9e83f1	2026-01-24 20:50:00.150683+00	13.8	26.9	2479	1342
c03210b3-e9cb-40e6-8770-86c6b5efdd08	2026-01-24 23:41:02.528071+00	13.3	27.6	2702	1382
d74822a8-25ac-400e-8a78-671961778611	2026-01-24 15:08:26.910103+00	16.5	24.9	256475	256475
bcbc4c25-2de2-48bb-8112-2beb5c453fac	2026-01-24 17:59:26.927294+00	15.9	27.8	94459	94459
6ec84187-3651-44d1-971e-fd050979a852	2026-01-24 20:50:26.951533+00	14.7	26.9	148991	148991
422ce550-009c-49f2-8e2d-49af292db10f	2026-01-24 23:41:26.870894+00	14	27.5	174266	174266
8097ca4a-e772-4923-9bc5-d02d0dbfe85a	2026-01-24 15:08:55.160141+00	16.6	25.1	2228	1680
9852fb0a-44a8-45dc-aa51-a12701b2d478	2026-01-24 17:59:57.663074+00	16.5	27.7	2137	1313
d4e5d52a-34d3-4b40-ad73-8c1f5bda782d	2026-01-24 20:51:00.169129+00	14.4	27	2704	1320
95181ddf-ab85-462c-8db8-0cc80ba40684	2026-01-24 23:42:02.482129+00	13.4	27.6	2653	1343
cf88221b-3d2f-4571-a478-8463ddb2c8d4	2026-01-24 15:09:26.891102+00	15.5	25	182784	182784
e2b90144-193d-41a3-8521-6bab0d767603	2026-01-24 18:00:26.962362+00	16.9	27.7	152774	152774
160914bc-a15d-4ca5-ab06-9682c18e544e	2026-01-24 20:51:26.929284+00	15	27.2	189164	189164
8449e9da-da93-49e2-bb2b-9f42985e8a64	2026-01-24 23:42:26.888289+00	13.4	27.5	199742	199742
e2d7bede-1668-4354-b2c6-7600cdc39365	2026-01-24 15:09:55.158347+00	16.4	24.9	3386	2021
a113b678-788b-4a58-84bd-a01aecc7da20	2026-01-24 18:00:57.674213+00	17	27.8	2581	1537
6cc5276e-8791-4226-981f-ab20f3e707bb	2026-01-24 20:52:00.140601+00	13.9	27.4	3909	1934
3b3f6980-b438-408c-be48-4bcce4b719a8	2026-01-24 23:43:02.548827+00	13.1	27.4	4094	1996
fa654c07-3d37-4eaa-ad92-d4884a2afdd3	2026-01-24 15:10:26.90135+00	16.4	25.1	181215	181215
9f4f68c4-a1d2-40bf-bd83-4d8bd670f148	2026-01-24 18:01:26.980597+00	16.1	27.7	151914	151914
5f73ce17-4344-4b0a-b672-1b6b9854431b	2026-01-24 20:52:27.0119+00	14.7	27.2	301967	301967
f1b92cef-0bbe-4f48-a0af-231f651303e7	2026-01-24 23:43:26.871121+00	13.6	27.3	200761	200761
11de848c-f08f-4165-aeab-3a909a06fca3	2026-01-24 15:10:55.203382+00	17.2	24.5	2619	1814
1cf5be80-0ff1-487f-a251-1c7b95893f1c	2026-01-24 18:01:57.653474+00	17	27.8	3258	1567
79729b78-46ba-4eda-8604-b47ee9629206	2026-01-24 20:53:00.186621+00	12.6	27.4	2148	1325
1057263c-cfe6-40aa-baef-d43a0e977717	2026-01-24 23:44:02.552691+00	12.9	27.5	2709	1519
4f3f8324-5cf3-4cf0-8ef9-9d6590efc446	2026-01-24 15:11:26.913575+00	18.4	24.9	209315	209315
d33c46bf-42e7-4225-93f7-8dc2ac3d9cf2	2026-01-24 18:02:26.98059+00	16.7	27.9	224648	224648
02ab660f-c8d4-4ad1-ae63-2f3c836ff130	2026-01-24 20:53:26.830103+00	14	27.4	217368	217368
f9e25ac9-b8c1-47d3-8298-08cc45632feb	2026-01-24 23:44:26.905029+00	13.3	27.7	155792	155792
6d5d6ec7-15e0-4fe6-a7eb-aedae718ad07	2026-01-24 15:11:55.148954+00	18.8	25	2572	1710
e602ba9b-9317-422f-8348-b6e674dcdfbe	2026-01-24 18:02:57.703939+00	17.2	27.8	2413	1310
ce9f53d1-897a-4f9b-8da5-2d8d128bbffd	2026-01-24 20:54:00.209799+00	13.7	27.4	2128	1325
b8de7070-4012-411a-9347-0561bbd56361	2026-01-24 23:45:02.517547+00	13.2	27.5	2774	1399
79b1eca2-442e-4aed-8892-3b22a78699ff	2026-01-24 15:12:26.873195+00	16	25	268082	268082
03c1410a-4e0c-4821-956a-1e8f50885e24	2026-01-24 18:03:27.005532+00	15.6	27.8	184978	184978
56cf3a3a-d11c-4c03-9aba-b4853bfd8f7a	2026-01-24 20:54:26.827754+00	13.3	27.3	104190	104190
66f33a62-155d-4aa6-9510-1842574ba8c2	2026-01-24 23:45:26.920737+00	13.9	27.5	237932	237932
68540246-da33-4d8f-a699-0a3202f8e9d4	2026-01-24 15:12:55.22733+00	18.8	24.8	2592	1684
c06662ba-bcbe-477f-b432-d1bd96040bde	2026-01-24 18:03:57.720932+00	16.9	28	2450	1302
f6d9003b-756f-497d-aca4-a9a49fac9a66	2026-01-24 20:55:00.22391+00	13.8	27.1	2270	1317
2fe02e00-b06e-426f-9529-5ec8d2d1e66c	2026-01-24 23:46:02.583164+00	12.5	27.6	2415	1374
924e8c84-6436-4aee-99ca-de576c53301a	2026-01-24 15:13:26.871358+00	20.1	24.9	212359	212359
d02b8cf4-5859-464c-8c7e-8b4c3318852b	2026-01-24 18:04:27.048766+00	16.1	27.9	234036	234036
9cca7804-e05a-4cf1-9047-a2223600c5d5	2026-01-24 20:55:26.914521+00	13.3	27.3	136364	136364
8fb70dcb-2a1c-4be5-9974-6544e2702645	2026-01-24 23:46:26.865298+00	14	27.5	152410	152410
209c7c46-7e5c-447f-9143-b469c7550b9a	2026-01-24 15:13:55.243548+00	17.9	25	3049	1757
afaf9d9d-bc6d-45de-ac9c-85a03b77cf4e	2026-01-24 18:04:57.73166+00	16.9	27.6	2406	1294
4e82d270-e69f-434c-9fe0-9b8e216eb5c4	2026-01-24 20:56:00.237371+00	14.1	27.1	2754	1354
19e6fd51-d012-405c-b8cf-71afb5ffdfb6	2026-01-24 23:47:02.55957+00	13.2	27.2	2738	1391
b12bd632-037a-4c5e-a7c5-274f07b424cb	2026-01-24 15:14:26.89684+00	16.3	24.9	264541	264541
fc66fd08-f2fd-4da9-a567-ed0deceeee25	2026-01-24 18:05:26.985033+00	18.7	27.5	239600	239600
fa1d6fe7-5ef4-479b-aade-abfea638e0dd	2026-01-24 20:56:26.910904+00	12.4	27.4	216126	216126
bc6623f8-84cd-44ed-8d52-1eff3e9f6ca2	2026-01-24 23:47:26.889935+00	12.6	27.3	207934	207934
185b8515-53c7-4577-acd0-b50a1c6a875a	2026-01-24 15:14:55.261156+00	18	25.3	2408	1672
65b2d417-85b9-41d9-8238-07adc321ded7	2026-01-24 18:05:57.706943+00	24.8	27.2	2100	1286
7556f2bd-3b8f-4fae-8821-ecb8cb481a91	2026-01-24 20:57:00.183983+00	14.2	27.2	2451	1298
8b442da6-fed0-4c6a-8b7d-00fa64ccafbf	2026-01-24 23:48:02.592762+00	13.9	27	3022	1481
0ada84c3-2b2f-4bd9-af4c-58e4309094b4	2026-01-24 15:15:26.939485+00	15.9	25.3	220415	220415
91dca3fc-2966-4dfb-8962-687884114bce	2026-01-24 18:06:26.914464+00	16.9	27.7	232373	232373
03e0f0f2-663e-4bf9-8955-9e2f1b1c700b	2026-01-24 20:57:26.93132+00	13.4	27.3	174320	174320
cdeeabbf-40c0-48a4-aec1-1ffd5ac822bc	2026-01-24 23:48:26.936086+00	11.1	27.1	203948	203948
4f68966d-7aa6-4ecb-a8dd-0754d9c6c3ef	2026-01-24 15:15:55.283328+00	19.3	24.7	3245	2064
aaf2c0a1-9a30-4fa6-b2e8-7b4701afb5b8	2026-01-24 18:06:57.695948+00	19.4	27.7	2554	1505
920fa67b-b443-4983-b8ba-2ea990999a9e	2026-01-24 20:58:00.25432+00	13.2	27.3	4157	2018
990201d2-fe3b-4886-9c12-94510dab0d3f	2026-01-24 23:49:02.600403+00	15.2	27.2	4747	2001
f082015d-4f84-45b2-982f-605fea1f19d0	2026-01-24 15:16:26.952261+00	21.7	24.8	181060	181060
dab3bd28-43cf-4aaf-8461-f2f2b56eae93	2026-01-24 18:07:27.063771+00	17.1	27.6	102142	102142
42ae1162-bb83-4b15-91b3-9d9bde4ac11f	2026-01-24 20:58:26.930516+00	12.8	27.3	164928	164928
775c9ba7-cf98-47ff-969d-62c303a1d9ff	2026-01-24 23:49:26.906165+00	11.3	27.4	272319	272319
3af03c73-b1ab-4796-be81-355f7032d743	2026-01-24 15:16:55.253421+00	19	25	2638	1850
421e6f87-9f0e-4de2-80ed-06752252580f	2026-01-24 18:07:57.755758+00	16.1	27.8	3196	1694
ce75cd88-ee5e-4d09-8629-3a921657f5c8	2026-01-24 20:59:00.270093+00	13.5	27.2	2433	1333
e886d6ad-ab49-4a94-8ae5-0febefd8f538	2026-01-24 23:50:02.61981+00	14.4	27.3	2441	1371
63c6c3c7-f3d6-49eb-b12a-58b0bcb735fc	2026-01-24 15:17:26.969184+00	16.2	24.9	213741	213741
73c3b7ce-eaeb-4a15-92da-f4ccc3a047ae	2026-01-24 18:08:26.894417+00	19.5	27.5	227441	227441
695cbc7e-64dd-404e-9b1d-5a7c886cdc0b	2026-01-24 20:59:26.931305+00	13.2	27.2	259416	259416
2aa3554f-035f-4f34-8eea-75f65a0897b6	2026-01-24 23:50:26.869074+00	11	27.4	290905	290905
691d4bec-70d6-42cb-9748-c592fdb9a81d	2026-01-24 15:17:55.293626+00	17	25.6	2232	1667
ad2bcba7-d62b-40af-9e9c-023a7620f260	2026-01-24 18:08:57.725595+00	18.1	27.8	2393	1305
3379ff1b-31a9-4781-9c24-f8abbcf012e9	2026-01-24 21:00:00.288382+00	13.5	27	2180	1341
eb75bce3-da5b-4072-a4e9-94f221f266e4	2026-01-24 23:51:02.584591+00	15.2	27.2	2472	1383
275b902c-1a91-4c98-9b57-d547cc4e33ff	2026-01-24 15:18:26.940419+00	17.1	25.6	140635	140635
0942a5cf-fa94-406a-92a9-11075a112117	2026-01-24 18:09:26.905099+00	17.1	28	251953	251953
5ef601d2-7030-4fad-a9ef-f65f9b6225a0	2026-01-24 21:00:26.941534+00	16.3	27.6	223226	223226
d354d969-3523-4809-b101-4bba952ba852	2026-01-24 23:51:26.849481+00	12.4	27.2	228585	228585
85935bd7-cc8b-451f-8fbd-2e005941ce1e	2026-01-24 15:18:55.262828+00	17.8	25.5	2523	1697
272ea489-f707-448e-874a-aef4551a827e	2026-01-24 18:09:57.790868+00	17.3	27.9	2893	1280
d1ad4cdd-9aca-492b-b81b-d5e30b0bd5e5	2026-01-24 21:01:00.305999+00	14.2	27.3	2256	1353
ced71e70-7e51-4617-978f-85f3daa663c8	2026-01-24 23:52:02.583811+00	14	27.1	2425	1373
fc96e9b0-0c3e-428c-85d6-5ed4d824cfc6	2026-01-24 15:19:26.943829+00	17.3	25.2	218475	218475
f108fe45-14d5-40f9-bad2-2edf2b9ba4e2	2026-01-24 18:10:26.961841+00	17.3	27.9	189492	189492
0fb80be6-653b-4fe7-8640-803bad8272d1	2026-01-24 21:01:26.903176+00	13	27.5	202163	202163
79edacf0-d2d7-4409-abf4-8d1d04d49ecb	2026-01-24 23:52:26.864452+00	19	27.1	161436	161436
37b223b8-8f51-46b9-81ff-7478f50bd5bf	2026-01-24 15:19:55.2717+00	17.2	25.2	2644	1715
669ae521-2b02-4008-aa11-1d5352e30ac6	2026-01-24 18:10:57.812048+00	17.5	27.9	2527	1322
8de22391-a9d5-41d7-9c57-5526238f2ef3	2026-01-24 21:02:00.278619+00	13.6	27.4	2151	1347
361c25f8-a092-4ac6-abb1-beb6b81ff284	2026-01-24 23:53:02.660408+00	13.9	27.1	2458	1376
b6a1a26f-43ad-49c8-a6cb-5cc9f4bae251	2026-01-24 15:20:26.981845+00	15	25.5	220988	220988
bf2fa391-5ef6-4dfb-a509-29904c3614c6	2026-01-24 18:11:26.946837+00	17	27.9	198652	198652
4ab769b4-ee41-4ec1-9f80-95f1904a323c	2026-01-24 21:02:26.916609+00	13.3	27.6	204467	204467
6a3e5f81-5cd8-4aaa-8c28-6fb52ef6f098	2026-01-24 23:53:26.836838+00	14.2	27.3	207819	207819
62df4961-de55-4743-a967-9f8357cca5f7	2026-01-24 15:20:55.292096+00	16.9	25.7	3145	1692
441ed2c9-145f-4b8b-95a4-0d9b02582a0e	2026-01-24 18:11:57.757596+00	16.8	27.6	2345	1293
28e10680-ebc0-4cae-ab22-588419528736	2026-01-24 21:03:00.272255+00	15.2	26.8	2221	1302
17500cf6-19dc-4905-8af0-4036fb102530	2026-01-24 23:54:02.670006+00	14.3	27.3	2776	1383
25783e67-4c4c-4837-8653-92d69b78c149	2026-01-24 15:21:26.861369+00	15.6	25.3	95957	95957
c38a2ab5-0e55-4ee9-b943-8fdd65c4e8ee	2026-01-24 18:12:26.96688+00	19.3	27.5	139252	139252
dbbfc5f1-2693-4c77-9630-679d4563c44e	2026-01-24 21:03:26.919772+00	15.8	27.2	154810	154810
fdf135be-df02-4c95-9475-a1d3c543fa9f	2026-01-24 23:54:26.84869+00	13.8	27.3	259043	259043
61688db5-2ddf-40a8-b2f8-57c7a0361dba	2026-01-24 15:21:55.315144+00	17.2	25.4	3495	2173
548a4f5b-ed73-4077-9deb-975ccf211989	2026-01-24 18:12:57.783766+00	19.3	27.5	2539	1508
2a5a8033-af4d-47b6-b520-b6bfa33d3f98	2026-01-24 21:04:00.293554+00	13.1	27.2	4001	1915
6e6d55c6-b3ac-4c94-90d7-4a438269a967	2026-01-24 23:55:02.638845+00	16.5	26.9	4265	2002
482fa392-3790-4c59-93f4-d190e134159e	2026-01-24 15:22:27.004321+00	15.7	25.2	174340	174340
55adb75e-cdda-4c23-8c3e-8c6bede48407	2026-01-24 18:13:26.95995+00	19.1	27.4	212446	212446
34a50057-6048-4cc0-a72a-5cc57d4a1158	2026-01-24 21:04:26.998131+00	23.1	27.1	181910	181910
f6f62679-8ec5-451f-97b1-80e41c26598e	2026-01-24 23:55:26.861453+00	15.7	27.3	133565	133565
f7da2939-3c0f-49ac-b774-73edc54223b1	2026-01-24 15:22:55.326317+00	16.5	25.4	2593	1806
6334de9b-7484-44b0-80d9-ce59851fea71	2026-01-24 18:13:57.853117+00	17.5	27.6	3203	1682
96906b81-49be-4408-a895-ec90a559c9d6	2026-01-24 21:05:00.355987+00	14.1	27.1	2489	1327
e3ff4e70-66dd-4eae-8f20-bcdba0dfc744	2026-01-24 23:56:02.703525+00	14.2	27.3	2994	1368
903c86b5-a643-4aea-b83e-c1ebd8be0706	2026-01-24 15:23:26.901856+00	16.3	25.6	174391	174391
4c91fe50-cd8b-410f-ba1c-f19e4c18fab6	2026-01-24 18:14:26.945618+00	17.1	27.5	220867	220867
88e7a101-1a91-47c3-9b5c-29526e249625	2026-01-24 21:05:26.943317+00	15	27.3	195004	195004
2ea6a92d-5601-4944-9cec-239f2bb8d98f	2026-01-24 23:56:26.862315+00	14.1	27.2	120789	120789
b60bca88-6865-451a-b406-3e09ecb22020	2026-01-24 15:23:55.346834+00	17.1	25.3	2190	1652
ed7506de-adc7-446b-985f-23ccc26cdfb8	2026-01-24 18:14:57.822317+00	18.7	27.6	2356	1312
c25e63bc-f641-4314-ad54-747cf0596898	2026-01-24 21:06:00.378712+00	12.2	27.3	2437	1297
7d05bfbe-3835-41fb-8b40-7038955ff169	2026-01-24 23:57:02.68211+00	14	27.4	2713	1393
86045662-cf89-4066-a47a-319ab829220f	2026-01-24 15:24:26.938615+00	17.5	25.3	239077	239077
b000fdad-dc88-4d68-8d98-f2398b10ea01	2026-01-24 18:15:26.95848+00	18.2	27.5	280551	280551
9fd434a2-ec86-4774-b22c-6ff12492482b	2026-01-24 21:06:26.848035+00	14.6	27.3	300237	300237
4d11a679-84d1-4205-961d-68fa999ff870	2026-01-24 23:57:26.87429+00	14.5	27.3	135760	135760
b58b369a-90c1-4b18-9e00-8f0ed6e89f92	2026-01-24 15:24:55.362582+00	19.7	25.1	2213	1563
563b413f-6e1f-4c56-bc0e-f01bb681daf9	2026-01-24 18:15:57.839467+00	17.1	27.6	2169	1307
39765aa3-dc7e-4d46-82c9-09a9a80790c6	2026-01-24 21:07:00.347584+00	12.8	27.4	2502	1328
69bcfe77-8c88-4f79-a185-d060ec19f53d	2026-01-24 23:58:02.714952+00	13.4	27.3	2609	1498
ab7beb9e-5317-4745-99b4-9adac86f350b	2026-01-24 15:25:26.935769+00	21.1	25.2	142169	142169
4cf50b38-33e2-4dde-bad6-01a8bf43c1fb	2026-01-24 18:16:27.004573+00	16.4	27.4	132463	132463
264d8b76-018c-49c6-a739-fd6a52f59f23	2026-01-24 21:07:26.897037+00	15.3	27.3	102994	102994
e5218904-d8c2-45a9-89fb-6614d887c93e	2026-01-24 23:58:26.880485+00	13.9	27.2	150642	150642
ee30c6a1-e6ff-4a62-ba62-986a404c6d55	2026-01-24 15:25:55.390034+00	17.6	25.1	2915	1681
ef22a7c9-a5cd-4fe1-bf5a-c0e2337a783e	2026-01-24 18:16:57.864609+00	17.4	27.6	2446	1312
66362989-e366-4ba8-a204-b72a734966eb	2026-01-24 21:08:00.398372+00	14.2	27.3	2365	1438
30869651-5cfe-4e21-804b-113ff43aaf3c	2026-01-24 23:59:02.709643+00	13.2	27.3	2397	1396
4d2ceae1-ec04-4598-b302-854069a1578f	2026-01-24 15:26:26.92558+00	20	25.2	195358	195358
c478965e-bdb8-4765-8f22-40070e0513d7	2026-01-24 18:17:26.946776+00	16.3	27.6	221893	221893
b7bc3e4f-0dce-4c79-9cb8-9a69594e439b	2026-01-24 21:08:26.835129+00	13.2	27.5	212605	212605
cdb2ccda-a63f-4923-9f3c-f4d2d8224069	2026-01-24 23:59:26.866997+00	13.5	27.2	112357	112357
b853efc4-4bf5-46ca-a408-59f84de80344	2026-01-24 15:26:55.370108+00	17.2	25.3	2525	1688
51594fca-2e76-4f5e-8806-d9e2a49a328a	2026-01-24 18:17:57.876777+00	16.7	27.8	2624	1405
9efcf476-e43c-4d0a-a21b-251911449e29	2026-01-24 21:09:00.419857+00	14.2	26.8	2204	1305
17ed8cdc-4cbe-40d1-b3d7-39fce9374422	2026-01-24 15:27:26.95427+00	20.5	25.1	194658	194658
83dcc53b-435d-4715-acdf-2f1e158fffed	2026-01-24 18:18:26.90227+00	16.8	27.6	260114	260114
0685eb5b-4818-4d74-9d5b-0602159d693d	2026-01-24 21:09:26.909803+00	14.8	27.2	154544	154544
d62d9ebe-6619-444c-96b8-6fb74c1350c1	2026-01-24 15:27:55.393731+00	19.5	25.4	3431	2052
277b9ca3-939a-4faa-bd48-995299d9f7b4	2026-01-24 18:18:57.931072+00	17.4	27.8	2894	1479
fd176c70-4e25-402c-b563-4ec2eb1748d9	2026-01-24 21:10:00.401661+00	12.3	27.1	3651	1912
159acf0e-69b6-4173-94a8-948557e3825a	2026-01-24 15:28:26.983729+00	19.7	24.9	234510	234510
0f9be5af-ce10-4712-8574-08e14bf3c78a	2026-01-24 18:19:26.926415+00	16.8	27.6	260128	260128
6f05cd27-aef3-470e-bf51-5cd64fc6b309	2026-01-24 21:10:26.84905+00	14.4	27	241571	241571
b2dfb8b9-1f23-4c0c-ac49-0d2e065f2148	2026-01-24 15:28:55.46318+00	20.3	25.2	2946	1826
e17c9282-a6a7-4c9a-a822-d86693b4de44	2026-01-24 18:19:57.91374+00	17.2	27.6	2838	1526
9cabb997-857c-4b9f-b7e1-54f7c1f4f90b	2026-01-24 21:11:00.445884+00	14	27.1	2503	1348
cf31af12-5ded-4abb-805c-a873a42472c4	2026-01-24 15:29:26.977918+00	17.5	25.3	199401	199401
e0e835ad-321e-4b3c-985e-4612430d55d4	2026-01-24 18:20:26.949435+00	16.4	27.6	277701	277701
d1abf004-2912-4875-b1e8-b39e854a8ced	2026-01-24 21:11:26.934147+00	13.2	27.1	187834	187834
9dd3ecf4-2f05-46ea-8313-df9f53045c2d	2026-01-24 15:29:55.482449+00	18.9	25.4	2264	1817
8240de8e-86e0-4df1-bd07-15621f813601	2026-01-24 18:20:57.929028+00	16.5	27.7	2119	1281
74cdf4e6-fdac-4825-ba8d-a65265e8b408	2026-01-24 21:12:00.426941+00	13.9	27.2	3060	1331
16842a1c-8ba6-4f47-a20f-7b23ec2705d0	2026-01-24 15:30:27.023761+00	18.8	25	223117	223117
6f874b93-3aef-4f6b-b8dd-e723993be17a	2026-01-24 18:21:26.941737+00	16.5	27.9	143598	143598
dc9eb705-6c7d-4ac0-9a6a-daf095b05de4	2026-01-24 21:12:26.904955+00	13.5	27.5	206075	206075
88e39e9d-d1c7-4b55-b9cc-82471f53cece	2026-01-24 15:30:55.481781+00	17.4	25.1	2226	1834
f8d54487-609e-4235-9343-b2849c17e7df	2026-01-24 18:21:57.945916+00	16.5	27.8	2128	1238
ced1505d-6291-4b51-810b-51009be04e1c	2026-01-24 21:13:00.474197+00	13.6	27.4	2498	1330
c0228d4f-1575-44bf-98ba-d49c9ebb261c	2026-01-24 15:31:26.989342+00	16.4	25	166647	166647
df30e021-9a28-4d7a-8901-246550a2458c	2026-01-24 18:22:26.952758+00	16.2	27.7	201477	201477
8df4653f-ee67-4d44-b6ec-e06a07ab670b	2026-01-24 21:13:26.889597+00	13.5	27.3	198069	198069
085f7015-798d-4ad8-9d25-2cbf9df45ee8	2026-01-24 15:31:55.472949+00	18.4	25.2	2285	1581
db4ed459-8275-4169-94c1-7028ad773b6c	2026-01-24 18:22:57.969733+00	16.7	27.6	2108	1263
a719aee5-0ffd-4e52-81e1-796319cb8c55	2026-01-24 21:14:00.489409+00	13.9	27.4	2727	1449
d43e8663-6035-4f62-9d8a-f11b8232aadc	2026-01-24 15:32:27.007211+00	16.6	25	195721	195721
344dd372-6629-4d95-81d3-0a835e8f9d00	2026-01-24 18:23:26.93081+00	15.9	27.9	287649	287649
8559e796-1238-4f62-a630-d8664b4e2223	2026-01-24 21:14:26.868013+00	13.2	27.3	183857	183857
05d05394-1e40-44d5-a3a5-a508287bf63c	2026-01-24 15:32:55.522802+00	16.3	25.1	2303	1773
b3f49214-9f56-4a8b-ba35-3100f05f0656	2026-01-24 18:23:57.961587+00	16.3	28.1	2484	1285
57f6fb00-1840-4e4b-b89c-0b7c62a51216	2026-01-24 21:15:00.498372+00	13.7	27	2213	1320
721ddb83-68e0-457d-9807-1535aab3c2d2	2026-01-24 15:33:27.021648+00	16.9	25.4	219638	219638
df8274c5-2a8f-46dd-9e58-3182f6cff53d	2026-01-24 18:24:26.975443+00	16.3	27.9	305133	305133
a04b05be-379d-4c75-85ee-51b1155157f1	2026-01-24 21:15:26.917805+00	13.5	27.2	321731	321731
6913a6d3-4d9b-49d0-9b1c-28d7c51aad32	2026-01-24 15:33:55.54552+00	15.8	25.3	3452	1975
046bab36-e618-4264-8307-06ba372c194d	2026-01-24 18:24:58.027539+00	16.3	28	2894	1477
d534b80b-9af8-46c1-ab5f-b9609f921310	2026-01-24 21:16:00.524921+00	13.2	27.1	3789	1927
e6fd4395-0656-4e9b-ae6f-bf8f0af7760c	2026-01-24 15:34:27.084034+00	16.7	25.3	110829	110829
a1e97880-ff22-4d41-b325-0e2f1cdf0216	2026-01-24 18:25:26.952193+00	17.4	27.8	159779	159779
351c64ca-13c9-4346-b051-abe7f50c8686	2026-01-24 21:16:26.930695+00	13.2	27.5	178851	178851
a2d43874-984b-478d-9033-3b86a46a29d3	2026-01-24 15:34:55.56089+00	16.2	25.6	2947	1877
aea09397-1050-461b-b9df-844b9e0a98fa	2026-01-24 18:25:58.047054+00	15.6	27.9	3716	1539
f3508427-cabc-41db-970d-d7093de21e72	2026-01-24 21:17:00.471554+00	13.4	27.5	3594	2309
03130196-6c0c-4d02-9b40-ef73e3f7f036	2026-01-24 15:35:26.988058+00	15.9	25.7	206994	206994
03c502ad-3011-4391-96c4-5732fb257784	2026-01-24 18:26:27.004134+00	16.5	27.9	245075	245075
0375ff8c-6e4e-477a-8c96-8da835186abe	2026-01-24 21:17:26.958788+00	13	27.1	194064	194064
dc6c6d80-3e85-4b6c-95c4-5a8fca912812	2026-01-24 15:35:55.583278+00	16.6	25.4	2745	1766
1d2b4f25-ad41-43bb-be5d-02ae04f14b64	2026-01-24 18:26:58.02208+00	16.3	27.8	3359	2245
3557dc18-e6e3-45f3-a882-c6dcfb419c27	2026-01-24 21:18:00.547684+00	13.4	27.1	2455	1438
f0f54197-6868-4f35-ae64-2d72150bc5e9	2026-01-24 15:36:27.099412+00	15.4	25.3	229526	229526
9da221c4-aeb0-4812-9be4-86dd3137478d	2026-01-24 18:27:26.995303+00	16.5	27.6	247437	247437
78f7550e-1c42-4a85-97ef-36e8a7768435	2026-01-24 21:18:26.952919+00	12.8	27.4	159920	159920
0f04a509-157e-4ebd-a256-c72109cb6301	2026-01-24 15:36:55.536496+00	18.4	25.3	2818	1795
ebb89088-743a-4e7d-9194-f310960632f4	2026-01-24 18:27:58.016278+00	16.8	27.9	2350	1391
dd53861b-6b7c-49f4-abbe-5e8277620c7e	2026-01-24 21:19:00.567834+00	14	27.1	2480	1337
48e52466-a952-48b7-aca0-82d49fa22af3	2026-01-24 15:37:26.964512+00	17.5	25.5	327093	327093
603596e7-8321-4c49-a128-f555488148c1	2026-01-24 18:28:27.013132+00	16.9	27.7	209996	209996
021215de-a914-46b3-a0d2-213fbdaa1459	2026-01-24 21:19:26.866572+00	13.2	27.2	215006	215006
e8a8f283-ac14-470f-be18-70b836c827bf	2026-01-24 15:37:55.584337+00	16.3	25.4	2502	1927
630a679e-5e87-479e-b88b-c9164301309a	2026-01-24 18:28:58.08682+00	15.7	27.8	2080	1286
5c8ec96b-96c8-47ae-b861-e28aeee9b371	2026-01-24 21:20:00.573996+00	13.3	27.4	2501	1336
9bad69b7-c8a9-4487-802c-8345f1e6d06b	2026-01-24 15:38:26.973001+00	16.4	25.7	247235	247235
9e155ae8-02d0-4538-8860-d09a119ea899	2026-01-24 18:29:27.002811+00	17.8	27.7	203430	203430
6d88ed09-22fc-4b70-8a96-9198e19ed092	2026-01-24 21:20:26.825613+00	13.2	27.3	179902	179902
17a9858f-3592-439c-9a11-b5af50f549a0	2026-01-24 15:38:55.572506+00	17.3	25.5	2415	1776
dba10128-6fd5-4263-8ebc-1c1d8423889f	2026-01-24 18:29:58.105454+00	16.5	27.9	2142	1274
1eea1510-2b4f-45b3-94c5-73f01ed4a52f	2026-01-24 21:21:00.542946+00	13.4	27	2495	1354
ae0a9654-a9ca-4c9a-8c52-9625117c42c2	2026-01-24 15:39:26.95004+00	15.2	25.7	154447	154447
6d6ace25-ba30-4dbf-a629-e97702cffd5f	2026-01-24 18:30:27.026933+00	18	27.6	129245	129245
9e6cd713-738c-4644-a2fd-82c06fdb49e9	2026-01-24 21:21:26.856477+00	13.3	27.4	336027	336027
788d61cd-74ae-4b54-b6fe-2c471e82234a	2026-01-24 15:39:55.631612+00	18.1	25.3	3337	2091
b2292587-8136-44c8-9ba8-0111af05fdfe	2026-01-24 18:30:58.122025+00	16.7	27.8	2726	1330
f3db809b-5ae8-40c8-a71b-1f7356fcd8a5	2026-01-24 21:22:00.543626+00	13.6	27.1	3146	1691
dc0464ed-99ff-49ee-b57e-5c3b7d3584b4	2026-01-24 15:40:27.005169+00	17.2	25.4	229809	229809
7442a02c-8163-42b4-8971-b7fe3c2ea2c7	2026-01-24 18:31:26.977058+00	16.6	27.6	210536	210536
c92f2284-309f-46ea-b186-f16585813f4e	2026-01-24 21:22:26.899323+00	13.6	27.3	307071	307071
73b3c5d3-7d39-4f3e-9f7f-f6b2b0ce5c96	2026-01-24 15:40:55.646396+00	16.7	25.3	2993	1818
da406f17-aca4-46bb-b0aa-83cdefa81950	2026-01-24 18:31:58.096015+00	16.5	28	5715	1916
307bf798-b9e4-4df8-894f-b546cd1a1387	2026-01-24 21:23:00.611722+00	13.4	27	2555	1484
139ac9d3-e90b-4795-ab8d-d3ea581c74cf	2026-01-24 15:41:26.964582+00	15.6	25.5	229158	229158
a4a233d3-8ffc-4f2b-9c10-023e46a78a2b	2026-01-24 18:32:27.03768+00	16.7	27.7	169527	169527
ca2ee184-c477-45ca-b84a-a7222f137112	2026-01-24 21:23:26.864082+00	13.9	27.1	146099	146099
2bdf4c62-bbf7-40ce-bebd-19ff05268aa6	2026-01-24 15:41:55.589848+00	17.1	25.4	4305	2660
b9324602-767b-4612-a066-a6f5fcf729c2	2026-01-24 18:32:58.115208+00	19.4	27.4	2507	1328
817e657d-55cc-4b09-9a11-810121f17bb0	2026-01-24 21:24:00.625615+00	13.4	27.3	2190	1325
8b2bf767-4d30-42ee-afd9-8e507ee5d1b4	2026-01-24 15:42:26.997114+00	17	25.5	148413	148413
40a3ca3b-619c-452d-ada7-5f6a68ffab28	2026-01-24 18:33:26.986317+00	16.7	27.5	181576	181576
824f501a-d47a-48e6-b1e3-618c22ea7a7f	2026-01-24 21:24:26.901484+00	13.9	27.1	357796	357796
16a9a60c-d115-4f2a-98f8-b2656efc091d	2026-01-24 15:42:55.667713+00	16.6	25.5	2514	1645
50eaf408-bafe-4dd8-b2a8-5eef428c923b	2026-01-24 18:33:58.146177+00	16.9	27.8	2474	1291
b1ce9f26-ba82-4070-be66-d4038aba0f89	2026-01-24 21:25:00.634524+00	12.5	27.3	2256	1380
998ae230-311d-463e-8e47-8f87806d2462	2026-01-24 15:43:27.021875+00	15.9	25.6	151197	151197
fe8f38a9-912b-4650-b3c5-93e35d05c7c7	2026-01-24 18:34:27.03691+00	15.3	27.7	149258	149258
0c8e355f-df06-42c7-b51b-902f4e4df6ac	2026-01-24 21:25:26.915414+00	15.3	27.2	109453	109453
dedb1b3c-e327-44ba-90c5-e68c65054799	2026-01-24 15:43:55.636436+00	17.4	25.7	2878	1800
c62defff-74a5-4757-ba5d-ff2daf3b12b5	2026-01-24 18:34:58.153906+00	16.8	27.6	2127	1298
a3a84e28-731c-47f0-8a14-aaec3c70ae31	2026-01-24 21:26:00.640479+00	13.3	27.3	2463	1335
d066e73b-36b4-4a9d-a4ac-621ebff6fd6c	2026-01-24 15:44:26.991899+00	16.7	25.5	201503	201503
5fc1efab-8e72-47e9-a4d6-b0343613fe57	2026-01-24 18:35:26.930143+00	15.9	28	202319	202319
89fdeb14-b5ca-421f-9fc8-4b2da42fbe19	2026-01-24 21:26:26.903381+00	13.1	27.3	224035	224035
01474b18-b2e4-42c4-ad38-224fa7287e54	2026-01-24 15:44:55.659607+00	21	25.5	2571	1782
4d0d97ed-a2b8-48ad-a580-af7fc0a51c99	2026-01-24 18:35:58.152995+00	16.8	27.8	2106	1272
0f25a4ed-b1fe-4230-a214-210b053f0b4a	2026-01-24 21:27:00.616474+00	13.4	27.6	2547	1343
324e19ec-0bc3-4a2a-b3a6-33be6c4f9772	2026-01-24 15:45:26.998441+00	17.9	25.7	305596	305596
1a69caec-09e8-4284-b427-b20bac4f2777	2026-01-24 18:36:26.943027+00	15.5	27.9	144488	144488
c3c9abd7-fc45-4631-a8dd-ab424f1da46c	2026-01-24 21:27:26.927453+00	14.8	27.3	115326	115326
b81c52b8-d42f-48ef-9ed8-7dff1b387080	2026-01-24 15:45:55.712776+00	16.3	25.5	2235	1651
2e06137e-a21c-4b0c-8410-9a16fe054742	2026-01-24 18:36:58.162932+00	16.5	27.9	2214	1290
d3c80f9f-7aed-4e8d-8daa-233256dd8252	2026-01-24 21:28:00.663097+00	12.5	27.4	3890	1805
c74e95e4-5aa6-4da4-9ed8-e455bc2489bd	2026-01-24 15:46:27.002459+00	19.4	25.2	170773	170773
f3ec050f-cdb0-4497-ac22-8b2d107416e6	2026-01-24 18:37:26.90314+00	16.6	27.9	243337	243337
3926f6ba-0644-49f0-be34-82354ac7ed48	2026-01-24 21:28:26.93893+00	14.6	27.3	177664	177664
5ceb1ddf-e59a-4e21-b005-943dc63bc2c8	2026-01-24 15:46:55.689405+00	17.5	25.2	2412	1713
37b24fb8-5d21-488b-bb1c-7c40e4faa8e3	2026-01-24 18:37:58.208878+00	17	27.8	3483	1873
814fed13-132a-4434-b533-68fccdd4a8f8	2026-01-24 21:29:00.66606+00	12.8	27.5	2827	1488
1b772871-4db0-4c1a-a0d5-fb0f6c82a0a7	2026-01-24 15:47:27.0531+00	21.6	25.1	189090	189090
95ae59ba-43ba-413b-a5a5-3b0203c94867	2026-01-24 18:38:26.994015+00	16.7	28	82204	82204
4d8f26d8-7671-4aef-8ecf-f81d7c784d4b	2026-01-24 21:29:26.931767+00	14.7	27	202422	202422
f6c43add-532d-4ab2-8765-7c074ca8b4b9	2026-01-24 15:47:55.721331+00	17.4	25.1	3395	2080
345de1ff-bb10-483a-a437-329b94cb8217	2026-01-24 18:38:58.207711+00	17.3	27.6	2584	1369
fcce38fd-b606-4ea4-92f7-4af80193ea9f	2026-01-24 21:30:00.687378+00	13.8	27.2	2219	1360
8615e7ad-0f0d-434a-9437-7f96a17ff7be	2026-01-24 15:48:27.018304+00	17	25.3	282546	282546
765c8587-8df7-4ebc-9b6f-89cc6fea85d5	2026-01-24 18:39:26.930097+00	15.9	27.8	235386	235386
6c8e62ab-b8ff-4ee5-8b3c-68d8bb649253	2026-01-24 21:30:26.924096+00	14.9	27	159137	159137
cb967539-ebfd-4e15-8fd6-c37c4de12961	2026-01-24 15:48:55.76569+00	15.4	25.5	2555	1652
af1982f1-e063-4ac4-88f9-b0b39955a95c	2026-01-24 18:39:58.241764+00	17.5	27.9	2492	1295
8157ae81-0fdb-45d9-b9e5-565c8c1bb9ab	2026-01-24 21:31:00.70335+00	13.5	27.6	2180	1319
b3a15a1a-2d43-4b51-a8fd-a1170fd0817b	2026-01-24 15:49:26.940892+00	17.2	25.5	138825	138825
7f781fac-e8e6-41c6-8705-6be7d54d8782	2026-01-24 18:40:26.953052+00	15.9	28	174740	174740
39ea35a7-0a5e-4612-a370-82f9577b6a3b	2026-01-24 21:31:26.997941+00	12.5	27.5	117907	117907
ea89258c-49f3-4140-81ad-ec14f896c74d	2026-01-24 15:49:55.782087+00	15.6	25.4	2477	1614
46fbb708-ba31-429f-9a13-e131f61600fb	2026-01-24 18:40:58.255765+00	18.7	27.4	2402	1293
4fd4b65a-3d76-46df-b746-431dded99c3f	2026-01-24 21:32:00.675478+00	14.2	27.6	2155	1319
0a14a33a-aaaa-4c8e-bdb8-349ecf60c46e	2026-01-24 15:50:26.866897+00	19	25	213604	213604
f1590071-22c7-46db-9268-bdf6c56f6b0b	2026-01-24 18:41:26.997793+00	17.4	27.6	166483	166483
e9153992-fbf2-42e4-9e04-b724ff4b9aee	2026-01-24 21:32:26.975427+00	13	27.2	183336	183336
02e43193-7529-4e3d-a630-3d99d37252ff	2026-01-24 15:50:55.784697+00	17.5	25.2	2601	1822
df39d2d1-cfbd-4618-8fab-862adfdbf996	2026-01-24 18:41:58.216158+00	18.3	27.4	2565	1321
7707bbc1-a1c2-4b57-b93a-ef2d340f4ed7	2026-01-24 21:33:00.718757+00	15.7	27.5	2712	1295
8d528361-c95e-4b01-939a-376afe71c0f7	2026-01-24 15:51:26.880927+00	16.5	25.1	252768	252768
52b01b85-5891-48a4-8ae2-4e8e5bb449e3	2026-01-24 18:42:26.947198+00	16.9	27.7	227587	227587
cc858e19-90ef-4bdd-971c-9df4f8694483	2026-01-24 21:33:26.870995+00	12	27.2	166156	166156
0e1da291-5765-4480-9b23-d3b074dfb4b6	2026-01-24 15:51:55.726143+00	17	25.6	2609	1649
2203a5d7-c69e-41c1-8ad5-bcc4765407ad	2026-01-24 18:42:58.264145+00	17.2	27.9	2470	1295
8439dead-f1ea-4fb3-b6dc-eeeb76afa940	2026-01-24 21:34:00.73334+00	13.7	27.3	2586	1650
8452f78f-94ba-464a-bef2-845a7585db09	2026-01-24 15:52:26.977762+00	16.4	25.5	184524	184524
a48649f8-f8bf-4e70-a29c-32749b522c9e	2026-01-24 18:43:26.960759+00	17.3	27.8	197178	197178
0465a6fb-18bd-42a1-afb5-d58e44dedfae	2026-01-24 21:34:26.85462+00	13.4	27.1	192780	192780
05633158-23bc-4c0e-938d-51f5bd494cdb	2026-01-24 15:52:55.77537+00	16.2	25.5	2419	1744
d59b60ab-0d29-4a23-8f23-f99931935aa1	2026-01-24 18:43:58.29337+00	17.6	27.7	3639	1877
398861be-8768-4297-838e-c82219867950	2026-01-24 21:35:00.749713+00	13.8	27.3	2921	1438
b37fbd8f-4695-43ce-a87a-738f50270540	2026-01-24 15:53:26.95923+00	16.5	25.5	175869	175869
eff08a1a-597e-4b00-bc64-faab1f12b03d	2026-01-24 18:44:26.990615+00	17.3	27.8	275469	275469
c8c4c1ef-bbc8-45b7-9fa3-8fc2370b0f2e	2026-01-24 21:35:26.862755+00	13.5	27.3	152514	152514
5ccf528d-28b4-47b1-a417-6e97c67c3ee0	2026-01-24 15:53:55.798103+00	17.2	25.4	3211	2025
d81bfbe5-7c03-4f15-ab2c-342fcedebcd4	2026-01-24 18:44:58.313199+00	16	27.9	2204	1348
0697cbee-df79-443f-9c18-d0e3aaebf052	2026-01-24 21:36:00.717259+00	14.5	27.1	2365	1288
39123df5-d5a9-4bf6-b49b-d453c7cf4a39	2026-01-24 15:54:26.961862+00	16.8	25.2	306666	306666
3b28f7f9-a7e5-4d35-9767-183a66fac8a7	2026-01-24 18:45:27.027087+00	16.8	27.6	262781	262781
8be606fb-30fc-4784-b140-159f1c697f16	2026-01-24 21:36:26.909439+00	13.6	27.1	180317	180317
8bb3798f-476b-4b9f-b7d9-080bae59ea2f	2026-01-24 15:54:55.794279+00	15.8	25.4	2336	1624
155cddd8-21aa-49d4-9a05-e66b36364897	2026-01-24 18:45:58.323281+00	16.3	27.5	2612	1393
8eaf31b4-3cf9-4f06-b7b9-7ffd44eaa453	2026-01-24 21:37:00.737472+00	16.8	27	2126	1300
65402459-3b8d-48ed-9c1d-30bb54c0f8c3	2026-01-24 15:55:26.939788+00	16.8	25.6	161559	161559
87cdaf9f-5b81-45ae-9af5-2b33bd62391e	2026-01-24 18:46:26.979717+00	16.5	27.7	289504	289504
e397a2a7-023f-435c-8778-471ed5327ae2	2026-01-24 21:37:26.939266+00	13.9	27	105304	105304
8300d0de-8c40-4f69-a1e7-c956d1c1414e	2026-01-24 15:55:55.86611+00	17.2	25.6	2486	1680
25f1f660-4c13-4081-8c62-ca7bd6f7fa97	2026-01-24 18:46:58.268692+00	17.2	28	2903	1289
34f92ab0-a6b5-4a4a-9ec3-7ea99325eaed	2026-01-24 21:38:00.789379+00	15.2	26.7	2398	1432
86e8a8fd-6934-4ff4-9fbd-e01fbcf4a2f9	2026-01-24 15:56:27.01033+00	16.5	25.6	135566	135566
e214550e-bfb0-4e71-818d-ba018b6a28b2	2026-01-24 18:47:27.013894+00	16.8	27.7	201163	201163
8aa2c760-f681-4332-860d-bc35486bf4ed	2026-01-24 21:38:26.912801+00	13.8	27	151009	151009
ea90d8cb-dda8-40e7-8430-25d0c6a54800	2026-01-24 15:56:55.834318+00	17.1	25.6	2518	1781
3b5a13f1-1feb-4c7c-9eaa-2a3c5b149de5	2026-01-24 18:47:58.348473+00	16.5	28.1	2668	1397
716c78fb-935b-4b8d-8085-b44d7587eccc	2026-01-24 21:39:00.759227+00	14.3	26.9	2155	1307
08ccded3-6947-4463-ab53-4f775c383d3c	2026-01-24 15:57:26.975987+00	16.2	25.5	147047	147047
c18c5388-30ce-41dd-b5db-451973870ce7	2026-01-24 18:48:26.935634+00	17.3	28	213680	213680
71dc83a4-422f-4678-8a7d-7c37d742bd74	2026-01-24 21:39:26.942026+00	14.2	27.2	185802	185802
ada8a798-96b1-4a64-adaa-75edf86ad06d	2026-01-24 15:57:55.876785+00	16.6	25.7	3114	1693
2db215a8-4a60-4d7d-94ed-a6108d3a651e	2026-01-24 18:48:58.363314+00	16.3	28	2415	1284
07792993-2998-4ae0-bfd4-36afa212530e	2026-01-24 21:40:00.809542+00	14.1	27.3	3154	1673
34f99dbe-cf5b-4527-bc8f-e60388ee01b4	2026-01-24 15:58:26.954628+00	16.5	25.4	138645	138645
9cf54dc1-3b1a-47ba-9598-a67d0fe195a7	2026-01-24 18:49:26.875242+00	20.3	27.5	227067	227067
9c2afc4c-dd77-4941-8112-a392aa224789	2026-01-24 21:40:26.867457+00	13.4	27.2	298439	298439
ce635bd2-3f68-4749-ac94-98b28bd97560	2026-01-24 15:58:55.893557+00	16.7	25.5	2740	1679
91af4dc5-3519-4826-8c0a-05d99aa7bf04	2026-01-24 18:49:58.379904+00	18.9	28	4050	1976
83728e3e-e75e-4329-afb0-7754fb6a1c4a	2026-01-24 21:41:00.841321+00	14.2	27.3	2915	1467
bb7a0534-e3bb-4571-8748-6685f46debff	2026-01-24 15:59:26.992517+00	16.8	25.7	217087	217087
ec261bc5-93a1-47ba-86dc-51f0ec92b573	2026-01-24 18:50:26.980086+00	17.2	28	202231	202231
1c50fe80-54b0-482b-a1b2-90ae4ddd49ff	2026-01-24 21:41:26.921319+00	13.1	27.5	249798	249798
eb33e6d7-c7a7-422d-9ffc-7c2a6f37b406	2026-01-24 15:59:55.872089+00	16.8	25.3	3247	2031
85a5657d-a1c9-4583-8285-8fcc01e90709	2026-01-24 18:50:58.357919+00	17.3	27.8	2244	1321
6e2ce502-290f-46ca-95fd-f5ed1d260f97	2026-01-24 21:42:00.795923+00	13.8	27.3	2470	1339
510ecf11-d88c-4aee-ae20-0c65c3b4973b	2026-01-24 16:00:27.029239+00	16.5	25.5	168324	168324
e0945cdc-89e9-431b-b7b5-f8272d2be3da	2026-01-24 18:51:26.939474+00	18.3	27.8	171429	171429
135f7be3-2715-4852-9923-488ed3ea64c7	2026-01-24 21:42:26.96268+00	13.1	27.3	294028	294028
28fa2423-433a-4b37-bba9-de7d4597e64e	2026-01-24 16:00:55.887456+00	16.1	25.6	2330	1727
28db1be6-9f28-4d3a-bad7-36c3256354c4	2026-01-24 18:51:58.377062+00	18.1	27.9	2131	1304
31f4fdb2-c49d-42f9-8c61-f8fda139f4eb	2026-01-24 21:43:00.864389+00	14.1	27.2	2456	1324
4b1a7050-74d5-4d4c-959f-e34ed60b120d	2026-01-24 16:01:27.027108+00	16.7	25.8	185853	185853
dc7972d6-1074-4eda-bb33-638be8aec803	2026-01-24 18:52:26.936392+00	19	27.8	334673	334673
cb4230c7-3037-421a-b594-393bed556589	2026-01-24 21:43:26.946158+00	12.7	27.3	148384	148384
4cf98a3e-6365-4397-a3a8-015ce9971f35	2026-01-24 16:01:55.907449+00	16.4	25.6	2160	1686
9404c53e-a54b-44e9-9303-0e87d84d118e	2026-01-24 18:52:58.412618+00	19.3	27.7	2124	1275
ff857429-a147-413e-8e6f-62fe0a614e88	2026-01-24 21:44:00.876993+00	14.3	27.3	2792	1484
c9de2a1e-645a-410e-ac29-ca41ae3e03aa	2026-01-24 16:02:27.051044+00	16.9	25.3	148237	148237
3d7a68dc-d4ae-4826-9bae-e622c2992364	2026-01-24 18:53:26.909838+00	18.8	27.9	99959	99959
bc89e0b7-40d8-45e7-9017-eeb2df8f1e0a	2026-01-24 21:44:26.960404+00	13	27.4	200726	200726
36f1bdd1-5f14-48f7-bfb3-0b4a4f61e9b1	2026-01-24 16:02:55.953264+00	16.6	25.3	2755	1626
151bb28d-9781-42fa-86d6-dee2a9a6044c	2026-01-24 18:53:58.392894+00	18.3	27.9	2497	1290
05829be8-0800-4f43-a06c-0ce55c7c16c3	2026-01-24 21:45:00.896287+00	14	27.5	2008	1316
a51d4893-160a-4b96-af13-51f85e87b4fa	2026-01-24 16:03:27.069083+00	18	25.4	183683	183683
07fe1ac6-6519-4b84-a0a2-846d9425a42d	2026-01-24 18:54:26.970158+00	15.2	28	237249	237249
3bfcb989-5396-4158-982e-4cf04933f9bf	2026-01-24 21:45:26.990127+00	13.7	27.2	286781	286781
b0aa8bec-4022-4f02-8d5c-50f8684e4f00	2026-01-24 16:03:55.973377+00	17.1	25.4	2610	1746
d76cc431-4860-4198-94fc-fc389ee1aaa5	2026-01-24 18:54:58.435336+00	17.7	27.7	2395	1264
13c75f66-027c-4517-9a40-057e8e938075	2026-01-24 21:46:00.911717+00	13.7	27.2	2945	1696
bb4e4811-a034-4dad-bc79-bf3b4c838eb6	2026-01-24 16:04:26.888144+00	17.4	25.5	220306	220306
26fd1a14-2bf4-424d-8a54-00e92471c111	2026-01-24 18:55:26.987204+00	15.9	27.9	217588	217588
1f6cbfc3-9d6b-4324-96a8-670d9869d73d	2026-01-24 21:46:26.960539+00	12.6	27.2	271711	271711
3d06a2ba-85cb-4f81-8a69-dbe65b42e003	2026-01-24 16:04:55.987139+00	16.8	25.9	2598	1669
13ddd42b-3a7c-4d9a-8743-ec618d9ade11	2026-01-24 18:55:58.407705+00	17.5	27.8	3641	1748
f795abf7-79fc-423d-963b-115d053a6e4e	2026-01-24 21:47:00.888288+00	13.8	27.2	2450	1499
69678095-22aa-4e1f-b1f2-5c3585657d09	2026-01-24 16:05:26.931031+00	17.4	25.5	234549	234549
5c70dbc2-4716-466a-8aab-c715c46951c5	2026-01-24 18:56:26.998053+00	17.4	28	190613	190613
10701ded-0253-4e7e-9043-56ea97730656	2026-01-24 21:47:26.917011+00	13	27.2	269431	269431
473ad4d4-b123-46b4-80c2-75b6a936b66e	2026-01-24 16:05:56.006087+00	16.1	25.5	3625	1932
a72e864a-f922-4b5e-8157-34b4df13c404	2026-01-24 18:56:58.420248+00	17	28.4	2547	1340
ce8ecc64-c211-4acb-b4a6-525d30311d44	2026-01-24 21:48:00.933334+00	13.5	27.1	2469	1426
d73efa10-3df7-41da-83a6-c14e9957d88d	2026-01-24 16:06:26.973236+00	16.7	25.4	147584	147584
10c87e9f-2a7e-46c3-a287-ef71471e177f	2026-01-24 18:57:26.963355+00	15.8	27.9	306777	306777
6f8a6954-907a-4faf-ba47-589ee9f064d1	2026-01-24 21:48:27.007757+00	11.1	27.2	144515	144515
003f2d89-a506-4f83-943e-eb8ff6a08f78	2026-01-24 16:06:55.975739+00	16.2	25.6	2325	1715
4aaf1980-2c9f-4110-b378-64cbc664336b	2026-01-24 18:57:58.424892+00	16.2	27.9	2584	1417
52c2c89a-73b5-4624-97cf-1c77552de082	2026-01-24 21:49:00.938187+00	15.3	27.1	2824	1332
f1a3a60e-5969-4ba0-bb81-86642ed01b0a	2026-01-24 16:07:26.948565+00	16.9	25.4	321606	321606
eb9cd87c-56c6-4bc4-808c-dce33838742d	2026-01-24 18:58:27.008522+00	16.6	28	186036	186036
6a6dc7d6-5d23-401e-ac9c-4cef305abbd9	2026-01-24 21:49:26.836945+00	11	26.9	245947	245947
51240af2-025f-4a9b-8cda-244e3688259a	2026-01-24 16:07:56.027506+00	16.6	25.6	2251	1648
69ef489e-e68a-47d3-8d49-b91e7a42c215	2026-01-24 18:58:58.491125+00	17.2	27.9	2090	1272
c4d86c31-3169-4f7d-85cd-a713b269b450	2026-01-24 21:50:00.909132+00	13.5	27.1	1952	1192
e68ab118-e10f-4a51-9d2a-09675183e964	2026-01-24 16:08:26.931314+00	19.1	27.2	281123	281123
e1319d8f-7ef4-44cd-b0c4-913b772ea9f7	2026-01-24 18:59:26.975388+00	16.7	27.9	294369	294369
1cc106aa-1ef1-4a18-bf5d-8026b0011811	2026-01-24 21:50:26.936494+00	12.9	27.5	294449	294449
ac5029bd-a3b2-45bf-a5e5-1347db9058c1	2026-01-24 16:08:56.046061+00	16.8	27.4	2241	1634
909679eb-615f-40f1-8e3c-4d5d49baa5f5	2026-01-24 18:59:58.513122+00	16.5	27.8	2218	1288
df5a54f4-8f9b-4b77-b617-aa8493763f90	2026-01-24 21:51:00.958813+00	13.7	27.4	2035	1325
00479522-2df6-4c8d-9a90-24703e9de554	2026-01-24 16:09:26.986599+00	19.1	27	134867	134867
96fb29ba-8d78-4d27-ab06-24dbdf50d2e0	2026-01-24 19:00:26.869074+00	17.9	28.4	229318	229318
07fdc792-37d9-491d-9d8f-bb3f1f8c1d99	2026-01-24 21:51:26.911594+00	11.4	27.3	177912	177912
30815666-2ad6-4b7a-a68d-110405e78cb9	2026-01-24 16:09:56.049922+00	17.3	27.3	2254	1711
5f06b7be-fa91-488b-8ad0-bccf6c2e01aa	2026-01-24 19:00:58.523019+00	16.5	28.4	2390	1299
2f460291-a096-421c-8f3b-88ef0040e929	2026-01-24 21:52:00.953862+00	13.3	27	2703	1723
744c0821-51da-4d60-a576-bbbbc4b317f5	2026-01-24 16:10:26.92986+00	18.7	27.1	258768	258768
bac628a8-e48b-416d-b410-c40f9dcd5b4a	2026-01-24 19:01:26.911992+00	17.1	28.5	271008	271008
19e1ca88-16cb-48bd-8027-30bbe07d71e8	2026-01-24 21:52:26.865439+00	12.4	27.3	239550	239550
3704705d-ecb1-4015-9f01-7ac266bd48b6	2026-01-24 16:10:56.014008+00	17.1	27.2	2745	1776
679ee9d3-79df-4bdb-9e5b-b2ce88b2e3f6	2026-01-24 19:01:58.497415+00	17	28.3	3594	1763
56e68e66-b16e-4843-abae-2297f05cb51e	2026-01-24 21:53:00.961015+00	13.3	27	2251	1493
de046b87-f952-44fb-be5c-ec7328c62633	2026-01-24 16:11:26.914629+00	16.7	27.3	241734	241734
378a41b6-6691-4975-b0f2-32640dcd1192	2026-01-24 19:02:26.940685+00	16.8	27.9	185960	185960
70343ec4-a5cd-406d-bce6-7246a5912dc7	2026-01-24 21:53:26.958131+00	15.6	27	253096	253096
8d6f4196-55cc-4bd2-8331-2d7b9067ea59	2026-01-24 16:11:56.466641+00	17.3	27.4	3647	2030
70f8e5c0-3fd3-4e77-b538-92224fbe78e1	2026-01-24 19:02:58.547445+00	16.7	28	3104	1328
08d96109-968b-444c-b171-6cb36bfec4d1	2026-01-24 21:54:01.012937+00	17.8	26.9	2067	1319
148506fe-2dc9-4c2b-827f-a85c14767722	2026-01-24 16:12:26.962977+00	16.2	27.6	249476	249476
e465ac44-d8cd-443c-8767-125874cc1a03	2026-01-24 19:03:26.957073+00	17.3	28.1	166038	166038
2d4d869b-1839-472b-87a8-d1b449e68b08	2026-01-24 21:54:26.898186+00	15.9	27.1	249851	249851
fe007c4a-0abb-4df7-bdf6-a06118ebb7b9	2026-01-24 16:12:56.077811+00	17.9	27.7	2618	1652
aa61c269-f51d-4913-8da0-8e6c5770f96d	2026-01-24 19:03:58.5247+00	16.3	27.9	2413	1321
dd0a51de-f38f-4dbf-8dcb-ef1b845d6097	2026-01-24 21:55:01.01894+00	13.8	27.1	1850	1326
af88ee2b-71cb-4b67-a53f-d10305064dc5	2026-01-24 16:13:26.960389+00	15.7	27.6	174657	174657
71cd3bd3-afa3-4573-bcd9-b91ec95445fc	2026-01-24 19:04:26.956285+00	17.6	27.9	189285	189285
dda03c99-5c88-4134-9e74-4d1b79518925	2026-01-24 21:55:26.884048+00	12.5	27.4	232467	232467
97af36d0-040c-40f4-8088-56e1e6459984	2026-01-24 16:13:56.058948+00	17.6	27.7	2764	1754
8b29e94d-fa16-4c3e-aa04-3f3cbb769636	2026-01-24 19:04:58.583162+00	16.9	28.2	2055	1298
287f4f21-1690-4d08-a5cf-3e8d473317c2	2026-01-24 21:56:00.986187+00	13.8	27.3	2163	1341
e95f2d2d-e681-48b4-ba2b-2abf46b635d0	2026-01-24 16:14:27.012548+00	17.8	27.6	181294	181294
fc1289ea-69e2-439d-a7ec-682a345a1fe8	2026-01-24 19:05:26.925964+00	17.4	27.7	195755	195755
417a3543-2ac1-4e39-9228-c1d82a9d14e3	2026-01-24 21:56:26.890874+00	11.3	27.5	184606	184606
7d2634fa-68c7-4043-868a-b6537c12894d	2026-01-24 16:14:56.12495+00	16.8	27.5	2068	1645
c26886a8-0591-4e7e-ac66-04245ed70bca	2026-01-24 19:05:58.602876+00	16.6	28	2225	1325
f0d20bdf-6fb1-4500-ae06-f199c47c9585	2026-01-24 21:57:00.984163+00	13.1	27.3	2143	1346
938c169d-698e-4f86-bd02-a17f8dc37b2b	2026-01-24 16:15:27.028908+00	15	27.3	185639	185639
d29223a3-fed5-47f7-9261-6f8faf55a6ca	2026-01-24 19:06:26.921638+00	16	27.8	220570	220570
1afb6f9a-ff0c-4d19-830f-f4633c755cbd	2026-01-24 21:57:26.930533+00	14.2	27.2	163297	163297
64be6d43-05e2-4e24-91ca-bc1efdae2915	2026-01-24 16:15:56.145822+00	17.1	27.5	2186	1639
5ed4daba-dbc6-4a47-b3f7-c2c1ae6ff395	2026-01-24 19:06:58.544146+00	16.7	27.8	2175	1310
d200d335-f8b2-461b-97b3-3b720698552d	2026-01-24 21:58:01.007713+00	14.2	27	3242	1808
d74b78dc-d83c-4196-97e9-b4a4c8286a78	2026-01-24 16:16:27.068001+00	17.6	27.7	141471	141471
71974e63-9834-4c83-9190-da34ffa2d5ce	2026-01-24 19:07:26.971838+00	15.8	27.9	236938	236938
4a0f1f47-8e7c-4656-8c3b-04eb83edc1fb	2026-01-24 21:58:26.960037+00	14.5	27.4	280718	280718
509efed1-a62a-48bb-ba75-d96b5e8e7dc6	2026-01-24 16:16:56.116098+00	16.8	27.6	2539	1837
a1c4802b-dcee-4ec7-bb16-31ae1a55a6b6	2026-01-24 19:07:58.618614+00	16.3	27.9	4027	1890
ad9388d0-80b5-41b9-b44e-9136ca67381c	2026-01-24 21:59:01.075587+00	13.8	27.4	2282	1495
6b352edd-b3f6-49b9-827b-ef3707da53ad	2026-01-24 16:17:26.913305+00	15.7	27.6	209235	209235
20746017-ee9d-49f6-8d16-c04cd1c36427	2026-01-24 19:08:26.968191+00	16.6	27.7	194131	194131
51a05855-3ddb-4318-860f-91614f1542aa	2026-01-24 21:59:26.974906+00	14.3	27.4	207844	207844
de198f0d-a67f-4cc0-993e-e4e56102931f	2026-01-24 16:17:56.153337+00	17.6	27.3	3596	2024
3909521e-d7d7-48b1-9ad4-13a5ead19ea5	2026-01-24 19:08:58.597157+00	16.8	27.9	2571	1341
2323e919-8ad5-4862-9696-6336a29d1f41	2026-01-24 22:00:01.093335+00	13.2	27.5	1783	1348
8fb41915-fbe4-47f9-a14c-5bd1722391e3	2026-01-24 16:18:26.87501+00	15.7	27.3	221595	221595
36208af0-fc84-49ef-88ce-169c31aa37e9	2026-01-24 19:09:26.947967+00	17.8	27.8	190054	190054
9b06d40c-c742-4081-82f8-1288e8c9e380	2026-01-24 22:00:26.868646+00	14.3	27.3	278190	278190
0ee24988-2e07-4e0a-a362-a84a10b09c96	2026-01-24 16:18:56.130343+00	17	27.4	3021	1688
dea922c5-7e64-4180-9fb1-c099e0858475	2026-01-24 19:09:58.625097+00	17.4	28	2473	1315
e27b7f82-58de-4b19-b027-99dff656cf7f	2026-01-24 22:01:01.112196+00	13.2	27.3	1793	1345
8771fb75-c035-44b0-971c-7243c60e0acc	2026-01-24 16:19:26.957367+00	16.4	27.5	169661	169661
b2475cc6-5345-4372-8e50-4a4bae0d2d8c	2026-01-24 19:10:26.931928+00	15.5	27.9	247326	247326
3fef21d2-3b2d-49a1-8279-5c4a2485e5b0	2026-01-24 22:01:26.883811+00	13.2	27.2	169902	169902
db3bc06f-858a-4c9f-b493-4f1d1cd886e0	2026-01-24 16:19:56.19499+00	16.7	27.5	2467	1628
697886d5-c0da-498d-a48c-2884a9e82ce1	2026-01-24 19:10:58.675484+00	17.1	27.9	2176	1298
0df924af-ba70-4b82-9fc7-3e036521f003	2026-01-24 22:02:01.073315+00	12.5	27.3	1846	1346
b508da95-6545-42bb-8c54-62a520f120f6	2026-01-24 16:20:26.943147+00	17.2	27.5	178857	178857
d1fbdbb2-7515-4105-a2cb-ae210b8a4752	2026-01-24 19:11:26.917769+00	15.4	28.1	281883	281883
d40ac46f-0f5b-4732-baba-cc9c642e2bcc	2026-01-24 22:02:26.924302+00	14.6	27.2	186462	186462
2f1929c8-fa65-45b7-bbba-b4effd4ec248	2026-01-24 16:20:56.212015+00	16.5	27.5	2577	1642
e1d4c12c-00ae-44c7-a91c-64ea4137914e	2026-01-24 19:11:58.652835+00	16.9	27.9	2441	1302
64a064b7-ba27-45e9-9ad2-4a135c7f84a6	2026-01-24 22:03:01.134505+00	12	27.3	2155	1337
216f521b-f931-486b-a00a-2198158efabf	2026-01-24 16:21:26.910693+00	16.4	27.2	198215	198215
95102f0d-7591-4ee1-93df-d9496549eb7c	2026-01-24 19:12:26.993781+00	17.1	28	168788	168788
2a2f6cbc-c4a0-4096-a354-28c3385844ed	2026-01-24 22:03:26.867321+00	14.6	27.2	137109	137109
f7fdca2b-9527-4666-bc75-178678d514fd	2026-01-24 16:21:56.180007+00	17.2	27.6	2209	1600
9957d148-5b75-438e-b339-624026904df6	2026-01-24 19:12:58.694757+00	17	27.8	2392	1309
c98158ee-3efe-435a-a7fc-112f97d23d6b	2026-01-24 22:04:01.15046+00	11.8	27.3	3087	1702
4ad51100-73fe-4e99-8bb5-27b65fe867fd	2026-01-24 16:22:26.956063+00	16.7	27.5	273396	273396
0393f00b-aaa2-44d0-b0b9-0fd49ac4d91a	2026-01-24 19:13:26.986836+00	15.7	27.8	185837	185837
0b04ee9f-4f04-4ca3-83c8-f0dccb05a551	2026-01-24 22:04:26.913418+00	14.7	27.2	214987	214987
885e0a67-11c4-4095-ac30-7fbd4e9f9ead	2026-01-24 16:22:56.233738+00	0	27.3	2589	1860
df3862d3-c70b-41b2-81b1-f485c484b555	2026-01-24 19:13:58.71304+00	16.9	28	3974	1913
90e5590f-98f4-4aa6-947c-dff74e0ded21	2026-01-24 22:05:01.16679+00	13.6	27.2	2722	1497
33879ab5-c46c-4db7-8a9d-fa40f298e103	2026-01-24 16:23:26.991975+00	16.3	27.5	142930	142930
5329c0a5-e5de-4a8c-82a5-17b76351a5cf	2026-01-24 19:14:27.028738+00	16.2	27.9	144323	144323
dce7f3c1-a79a-4eae-a2ba-932f47674f08	2026-01-24 22:05:26.896719+00	13.2	27.2	249825	249825
6206d9dd-ed72-490a-ac44-72043c5426d1	2026-01-24 16:23:56.211629+00	16.7	27.4	3531	2025
97d80b29-6996-4a1b-a07d-8a32bd271fc6	2026-01-24 19:14:58.721183+00	17.3	27.7	2490	1351
6ea4351c-167c-4795-95cd-1f2d61f25b96	2026-01-24 22:06:01.184189+00	13.1	27.2	2004	1335
f3ce4063-ba6c-4a8d-8e0e-8acd29bea636	2026-01-24 16:24:26.963924+00	16.2	27.7	143728	143728
c3e53a22-83dd-4b38-9423-46afca64679f	2026-01-24 19:15:26.922183+00	16.7	27.9	191612	191612
052a8afe-bf8e-4c2f-89eb-4e701aad830b	2026-01-24 22:06:26.929079+00	12.9	27.1	142735	142735
706bc754-eb3d-40e2-8d3d-fab616e436b3	2026-01-24 16:24:56.218372+00	0	27.5	2287	1777
5883a4af-7061-4e1a-b48c-ff7080e286f9	2026-01-24 19:15:58.700174+00	16.7	28	2159	1299
9c7189a9-9024-4731-803e-c00066c76a8c	2026-01-24 22:07:01.161837+00	13.6	27.3	1833	1330
2ae5f8fe-28da-4326-8a79-de97023269fe	2026-01-24 16:25:26.994586+00	16.3	27.6	117430	117430
00605932-2a5f-4c3a-a4df-23080f9721ea	2026-01-24 19:16:27.065383+00	16.3	27.8	137063	137063
15749838-a63e-41ff-a4a2-6c8dce0e1cd0	2026-01-24 22:07:26.909344+00	12.2	27.1	197986	197986
2a40597b-4cf4-4d66-b90e-8ad81a056da4	2026-01-24 16:25:56.281278+00	16.5	27.7	2592	1887
3b4812e6-1789-4601-86be-748245123a2e	2026-01-24 19:16:58.725738+00	16.6	27.8	2132	1282
a5aaab5e-e134-41d6-a558-f491cd8b6459	2026-01-24 22:08:01.189129+00	14	27.2	1945	1438
b4a72d68-85f0-4010-96c2-a5f115fba133	2026-01-24 16:26:27.007673+00	16	27.6	184420	184420
255ec9c8-ab7a-4da6-b5da-30b1ff41a265	2026-01-24 19:17:26.92569+00	16.3	27.8	150069	150069
a8785e5b-5737-4518-b001-3c01a5c538bb	2026-01-24 22:08:26.932147+00	13.2	27.5	422425	422425
cf23402f-291e-4609-bf08-3fa7901b1b57	2026-01-24 16:26:56.249867+00	16.6	27.4	2570	1570
2a06163f-def9-4082-81be-41ddedcd3e88	2026-01-24 19:17:58.77571+00	16.9	27.7	2324	1386
9ef7bd92-6cf8-48fb-95ac-bce54a11818f	2026-01-24 22:09:01.224879+00	14.6	27.4	1857	1331
6c47117e-0e7d-42f8-a84a-16cac91e50e9	2026-01-24 16:27:27.0166+00	15.8	27.5	171658	171658
1b638577-6d82-4175-ab3d-052065285d35	2026-01-24 19:18:26.888022+00	16.7	27.6	206749	206749
f072fde0-6d42-42f8-abd7-d5fe33b7eb08	2026-01-24 22:09:26.945044+00	13.7	27.5	124841	124841
2d4fb72d-ed41-408c-8d2a-abdb40e1e008	2026-01-24 16:27:56.246421+00	16.3	27.6	2503	1588
98cee9ef-73b7-4a17-9459-b9f068db5332	2026-01-24 19:18:58.783125+00	16.6	27.8	2404	1286
e5939b47-a0af-47b2-82ae-5f3bddd3aeb7	2026-01-24 22:10:01.243009+00	13.3	27.3	3642	1700
15027e3e-04fb-4b9d-9b53-1975ed239ef2	2026-01-24 16:28:27.02858+00	16.4	27.4	168327	168327
c66aab48-6286-4aa8-803d-73bd6ef5bb2d	2026-01-24 19:19:26.946188+00	16.5	27.9	181282	181282
39223be9-6be7-4ee3-b6fa-7fa3d231446e	2026-01-24 22:10:26.94166+00	12	27.6	365519	365519
902504ce-f65d-4a40-aead-21490572e212	2026-01-24 16:28:56.276298+00	17.2	27.6	2459	1723
02cb70a2-ee61-4a67-b4f4-cbe51489eb35	2026-01-24 19:19:58.813946+00	16.6	27.7	3783	1749
2c89300c-5ae1-4108-9c26-e3c7072884c1	2026-01-24 22:11:01.263296+00	13.4	27.5	2530	1474
db40d3fd-dd99-4b53-abc8-03ba45231cf8	2026-01-24 16:29:26.978012+00	16.7	27.5	443504	443504
4e9cb9ef-d991-4169-a346-735cdef79982	2026-01-24 19:20:26.963972+00	19.2	27.8	166592	166592
8778341a-033f-462e-ba0e-41b066da2bfb	2026-01-24 22:11:26.962077+00	11.7	27.3	202812	202812
0ed5e470-bf82-48df-9676-39234a6462b0	2026-01-24 16:29:56.33662+00	16.1	27.6	3290	2052
4150eb62-1a14-4546-95f7-08efc4419123	2026-01-24 19:20:58.778639+00	18.7	27.7	3024	1333
dbdcee46-86a9-45f6-b02a-29486c906e13	2026-01-24 22:12:01.237665+00	18.2	27	3478	2463
94f46128-66b5-4acc-a9b8-dfa87cfcdf7b	2026-01-24 16:30:27.047005+00	16.6	27.7	150758	150758
9fcf57f1-fecb-46ad-9c8b-f88bd5dc9178	2026-01-24 19:21:26.952992+00	22.8	27.5	198476	198476
a1e2734e-dda5-4aa9-a589-7bb522adb180	2026-01-24 22:12:26.977214+00	15.1	27.1	153892	153892
000de57c-1b44-4f41-96b7-b07ffe2164ed	2026-01-24 16:30:56.359035+00	17.4	27.6	2171	1633
14da431c-40ab-41b4-93f0-e7e7375b7e03	2026-01-24 19:21:58.804583+00	21.1	27.6	3793	2408
75910d6b-90c9-40f4-b7a5-ef0acd7f7c2e	2026-01-24 22:13:01.282002+00	15.4	26.8	2125	1333
6b522492-c1a5-4e7b-bd59-d798951b21ae	2026-01-24 16:31:27.011196+00	15.2	27.4	338500	338500
cfc950a1-0e8c-42fd-a1fc-e82f2e338f22	2026-01-24 19:22:26.948379+00	18.2	27.4	172246	172246
f4aee070-2c2e-4f7c-9478-2998c32610f8	2026-01-24 22:13:27.023741+00	13.6	27	224647	224647
6f995d6f-f71c-457a-a215-8dce82b12f2d	2026-01-24 16:31:56.298809+00	17.7	27.5	2248	1689
36a00e3c-7a32-4e75-800e-a93ab7d3e09f	2026-01-24 19:22:58.845883+00	19.2	27.6	2323	1294
960ae255-c33c-4822-8239-b9f64e65e812	2026-01-24 22:14:01.253268+00	15	26.8	2089	1467
7d8688da-840e-45f7-9dff-03d04c1fde7b	2026-01-24 16:32:26.938631+00	16	27.7	225313	225313
de92546b-f7b1-4af0-86da-ff2c6d4f2742	2026-01-24 19:23:26.975132+00	16.7	27.8	164318	164318
5de07af9-045b-402a-9418-aee49f85d30a	2026-01-24 22:14:26.880185+00	14.6	27.2	231792	231792
7cafb742-343e-4db1-822a-320b5064780c	2026-01-24 16:32:56.366155+00	16.8	27.1	2496	1415
f5cc796a-a2a7-4a6d-94b0-007e4f66a484	2026-01-24 19:23:58.870753+00	18.1	27.7	2123	1303
afc7b657-7048-477b-af9d-65cfcc4359b1	2026-01-24 22:15:01.319396+00	13.8	27.2	1803	1325
e28c37eb-cbca-48b5-8353-58b5b7a41bda	2026-01-24 16:33:26.941248+00	17	27.2	245341	245341
3e496472-844a-40af-8b8b-0332a4db31b9	2026-01-24 19:24:26.964035+00	17.1	27.8	220351	220351
b97ab351-bc80-4c53-87d6-9a6f315f3b53	2026-01-24 22:15:26.909198+00	18.2	27.1	232864	232864
c8b32784-cd57-49ae-9200-4e2cd3063046	2026-01-24 16:33:56.348907+00	22.3	27.1	2433	1284
03b98aee-5120-4833-a196-3a50c5472dca	2026-01-24 19:24:58.889672+00	17.4	27.7	2109	1317
48025877-d7c6-44a5-8ba4-8b5d64bbad27	2026-01-24 22:16:01.332702+00	13.9	27.1	1847	1339
3c4d1f7d-e9ce-4987-8362-1449362b0837	2026-01-24 16:34:26.904652+00	19.8	27.3	241789	241789
4669e3fa-0f40-4912-9b18-aecc087ee96f	2026-01-24 19:25:26.898596+00	15	28.2	247236	247236
755c0dbc-e69f-418e-9044-24659a5f3e84	2026-01-24 22:16:26.920751+00	17.3	27.3	190876	190876
c7747ed3-c2ca-45eb-a2be-3fd8d81fc8af	2026-01-24 16:34:56.366263+00	18.9	27.3	3118	1377
27bc9d9a-63b5-433f-a7bf-b428a184ef88	2026-01-24 19:25:58.875071+00	17.3	27.8	2692	1311
638a0d5f-1de1-436a-93bc-9bfa23956f45	2026-01-24 22:17:01.289219+00	14.9	27.5	1821	1312
ad1ded2d-7619-4e30-a88a-99bcc756a55d	2026-01-24 16:35:26.91653+00	0	27.6	161298	161298
272caa69-93ef-4f3f-a470-ef73c7adb269	2026-01-24 19:26:26.951341+00	16.7	28.2	152945	152945
1e0e290e-438d-48cc-98dd-c848c5c6ad88	2026-01-24 22:17:26.919696+00	15	27.3	152663	152663
0b1a4299-1130-4595-9e2e-cd664d87b566	2026-01-24 16:35:56.383088+00	20.1	27.8	3492	1699
dd8d93e0-05c0-4a15-a316-d008dc6b1ac2	2026-01-24 19:26:58.85805+00	17	27.8	2375	1293
3c3a293c-b4e3-4d0b-b77d-8d0eab48c9c6	2026-01-24 22:18:01.306931+00	15	27.4	3921	2141
1a704ffe-e0c6-4d76-b13f-0d8aeac0f0f4	2026-01-24 16:36:26.942056+00	17.3	27.9	204506	204506
57c4c54b-1744-4677-b7ef-bd7ffd65f253	2026-01-24 19:27:27.025253+00	17.5	28.1	94126	94126
ca976c1d-0404-4080-a9a8-734efa1b1c40	2026-01-24 22:18:26.926587+00	15.8	27	163798	163798
748f4394-018b-470a-ab59-c7592e862816	2026-01-24 16:36:56.40718+00	17.7	27.9	3061	2216
517c528f-6cbb-413f-be1a-f8cb0e5c81a4	2026-01-24 19:27:58.895187+00	16.2	28	4149	1999
f1b53e30-e111-44be-9629-d072c60445dc	2026-01-24 22:19:01.334935+00	16	27.3	2230	1333
270513d1-daec-4253-86cc-9bbb8b361b71	2026-01-24 16:37:26.953182+00	18	27.5	161632	161632
22118b59-6ab2-46ae-83d1-5c80dc1ee971	2026-01-24 19:28:27.007947+00	16.9	28	125969	125969
a1fe8e5e-2342-4ff5-81d6-a54d131d8243	2026-01-24 22:19:26.898501+00	17.3	27.2	181646	181646
ddd56ac2-bf0b-4455-ab26-74557d8e33fa	2026-01-24 16:37:56.432168+00	19.3	27.7	2136	1279
32db9088-6c8a-488b-b585-483d174febf1	2026-01-24 19:28:58.952466+00	18	27.8	2375	1310
0847f755-dc80-4ab6-a141-bd3f53f41501	2026-01-24 22:20:01.386203+00	16.9	27.2	2070	1346
6354994b-de6b-4883-bada-21608b302334	2026-01-24 16:38:26.940379+00	17.5	27.6	184527	184527
72a7abc6-4900-413e-9188-8a6d6a547bcc	2026-01-24 19:29:26.847572+00	19.3	28.1	264138	264138
dd3d0d2a-c270-43a4-841d-f7eab16bd22b	2026-01-24 22:20:26.865413+00	12.3	27.3	237712	237712
2d19e2d3-cd02-4b8e-b45b-7eb1d25aa685	2026-01-24 16:38:56.474576+00	17	27.5	2152	1285
b1020636-28a5-4bd1-adbf-0d94069c922c	2026-01-24 19:29:58.934078+00	19.3	27.9	2379	1313
1daeaa9b-76bc-4d69-b25d-12e49a56e2ef	2026-01-24 22:21:01.388951+00	14	27.1	1846	1322
2a98e6b4-ddc5-43ef-8645-37e5268d145f	2026-01-24 16:39:26.891999+00	17.3	27.3	245954	245954
21686a69-d8f0-4a85-ab76-969f2912ec01	2026-01-24 19:30:26.898403+00	17.2	27.9	200940	200940
082dedb7-2d94-4e5d-a361-7c1fa1e5fbc8	2026-01-24 22:21:26.882493+00	12.5	27.1	273779	273779
8ef62cad-1424-45c5-a762-076bb1d51c51	2026-01-24 16:39:56.495427+00	17.2	27.4	2687	1307
bdd49727-406c-432a-a56f-a52a814b9a3c	2026-01-24 19:30:58.934679+00	17.4	28.1	2123	1290
04f6ee68-2310-4fb2-ac6b-d329a232e266	2026-01-24 22:22:01.372743+00	13.9	27.1	1837	1348
cb1632e3-a328-4e02-8e69-951c177980f9	2026-01-24 16:40:26.912503+00	16.4	27.2	244659	244659
a5e861d0-fa36-4458-abfd-ecc914f5040b	2026-01-24 19:31:26.942919+00	15.8	28.1	246198	246198
0281b3a7-b8be-4c68-b3f6-0651c70a2ae5	2026-01-24 22:22:26.853142+00	14.7	27.3	239109	239109
5c3c49eb-674b-4dc6-a1c1-820958ecab33	2026-01-24 16:40:56.498192+00	17.2	27.4	2495	1310
08e14ae0-87e8-4a26-8568-2859a55523b3	2026-01-24 19:31:58.931434+00	15.8	27.9	2067	1276
ac8a5175-7379-4cb8-b708-c99b37439bd3	2026-01-24 22:23:01.3892+00	13.7	27.1	1793	1338
d0d4c9bf-3f29-4243-bcc4-c76427b3d338	2026-01-24 16:41:26.973883+00	17	27.2	151447	151447
b5be6482-3e9e-4919-9eff-c14907507860	2026-01-24 19:32:26.962656+00	17.9	27.9	155909	155909
b119c193-c33f-42b7-8bef-541511054917	2026-01-24 22:23:26.9144+00	13	27.1	176514	176514
49df401b-7b2b-431a-9702-e144d41d478f	2026-01-24 16:41:56.484755+00	17.6	27.5	3401	1676
bc99db62-600e-4176-90ec-6cf988149520	2026-01-24 19:32:58.974944+00	17.8	28	2043	1282
a2cae46a-68e5-430a-bc13-38d901ae6390	2026-01-24 22:24:01.445839+00	12.9	27	3287	1951
0574cd64-9c13-4473-b722-35ac6dff842f	2026-01-24 16:42:26.922766+00	18.7	27.2	259626	259626
36693ed7-48ec-4edf-b5d6-7fecef09297b	2026-01-24 19:33:26.941188+00	17.3	28.1	170633	170633
3d0306d3-bdc2-4fe0-a47b-61822d1c41ca	2026-01-24 22:24:26.848935+00	12.3	27.3	198431	198431
b13264de-e1f5-46f0-9b99-3792ab1fb4b9	2026-01-24 16:42:56.534576+00	18.7	27.7	2719	1452
5e7a1d20-68c4-480e-bd7a-cb9932ebdac5	2026-01-24 19:33:59.02659+00	16.7	28.1	3885	1877
b6a5101f-ef75-4fbf-9783-f12650b4fdfe	2026-01-24 22:25:01.470226+00	13.2	27	2140	1336
107b37b7-3637-41fb-b6bf-4258300561f2	2026-01-24 16:43:26.920226+00	0	27.7	275293	275293
0083275e-c23f-4415-b879-cdd92bf47136	2026-01-24 19:34:26.953985+00	17.8	27.8	173947	173947
9ee3264d-1fdd-4616-b879-c13d429206d9	2026-01-24 22:25:26.930942+00	11.6	27.4	168232	168232
d098c1d5-f178-4d43-addb-7c51798afebf	2026-01-24 16:43:56.554658+00	17.2	27.6	2418	1437
a61aef8e-0853-45e2-aeec-688f1105fd7e	2026-01-24 19:34:59.022741+00	16.8	28.1	2412	1306
8993eb15-23d2-4e8f-ac61-241ad55f8f9d	2026-01-24 22:26:01.439297+00	14	27.2	2671	1341
bc8a8974-0786-40f2-9345-128c9c2cab80	2026-01-24 16:44:26.864102+00	16.4	27.6	236598	236598
19958bd8-4260-4ae6-9dcd-6c7b7f33d381	2026-01-24 19:35:26.928787+00	17.9	28.2	155961	155961
a7f52cd9-f29e-4a7c-9537-198f6e5f8eaf	2026-01-24 22:26:26.985126+00	13	27.4	284559	284559
39c78b06-15ed-4f56-94a2-1604a59c364b	2026-01-24 16:44:56.569676+00	17	27.4	2130	1296
7cd3bab5-5eea-46c3-88ff-1b9c27d68100	2026-01-24 19:35:59.020739+00	16.2	28.1	2452	1298
92a5e126-8184-4259-86e1-c4637ddd91dc	2026-01-24 22:27:01.448436+00	14	27.4	2150	1316
10e5b1c2-e5e3-469d-aba6-075282459dc0	2026-01-24 16:45:26.870266+00	15.2	27.5	277016	277016
8e9c26f5-7f0b-4b29-996c-034f9761587f	2026-01-24 19:36:26.989874+00	19.2	28	198182	198182
704a4b69-e3f6-4a06-a296-c3bcc3ce5bf4	2026-01-24 22:27:26.89907+00	13.1	27.3	183736	183736
859c5349-3bd9-4157-92d6-e0dd22f2ad9d	2026-01-24 16:45:56.600234+00	16.5	27.5	2081	1288
59d1200b-adf6-43fd-88ae-cb1fc91aaaca	2026-01-24 19:36:59.028932+00	15.5	28.1	2571	1292
87b03bb1-ef23-4644-9ccf-6c994800589e	2026-01-24 22:28:01.506348+00	14.4	26.9	2311	1462
3b6167b9-4253-416d-b153-0b44568c76e2	2026-01-24 16:46:26.953404+00	16.8	27.5	242890	242890
2880f19c-b238-459f-9cb5-ffadf3381268	2026-01-24 19:37:27.001999+00	18	28	160593	160593
c96d29e6-b875-4d09-90f9-1554a6f1ae38	2026-01-24 22:28:26.932534+00	13.8	26.9	150521	150521
a403f9a8-6295-4bdd-a48d-773024febc15	2026-01-24 16:46:56.565035+00	17	27.5	2199	1296
b27e7881-add9-4b18-8582-18c5e72ccc35	2026-01-24 19:37:59.078315+00	17	27.9	2555	1391
e7e998b6-0c05-457d-a438-00c5ec57d38b	2026-01-24 22:29:01.521079+00	16.3	26.8	1797	1340
8b1cde65-eb94-41ed-9a2e-be0fc2a23705	2026-01-24 16:47:26.973461+00	16.5	27.5	224124	224124
91e5137e-db61-4ec5-8cf9-997d26457a41	2026-01-24 19:38:26.96422+00	16.6	27.8	150827	150827
a170e9b5-3f67-4521-b983-f55dd86f3eb9	2026-01-24 22:29:26.909976+00	19.1	26.9	280931	280931
1400c422-ac27-44d1-b488-0cafcd16dae2	2026-01-24 16:47:56.610066+00	17.8	27.6	3282	1631
87f4f067-9208-4f44-8fb4-dd13cfb91fc7	2026-01-24 19:38:59.061873+00	16.9	27.9	2063	1283
db67d0c8-fcd4-4356-98d4-7e999b14b640	2026-01-24 22:30:01.486759+00	18.7	27.1	3317	1931
a332cb89-dba2-43f8-bb13-99678362a924	2026-01-24 16:48:26.899553+00	15.8	27.5	170421	170421
d21735cf-f89d-4d82-878b-e492944047f5	2026-01-24 19:39:27.005172+00	18	27.7	143232	143232
4c135642-5d07-486c-aa80-89857cb9a0a8	2026-01-24 22:30:26.936318+00	19.5	27.2	162470	162470
4ec47108-1d67-4713-ab42-ce9f3a44f761	2026-01-24 16:48:56.609616+00	16.5	27.5	2792	1444
d8e06285-4888-48c5-a597-13cc9786228d	2026-01-24 19:39:59.112873+00	16	28.4	3605	1888
aab84351-8ad9-431b-b321-7c5649f2b4a0	2026-01-24 22:31:01.556331+00	14.4	27.3	2316	1364
8a91bae1-7b8c-4499-9d03-5543e65f64f5	2026-01-24 16:49:26.860268+00	16.5	27.8	268709	268709
67cd1ca6-04a1-4095-ace3-93d42ddd5532	2026-01-24 19:40:27.000289+00	18.8	28.3	246679	246679
a1cb2a5e-2399-45a1-828c-c8475b0442ed	2026-01-24 22:31:26.955171+00	13.9	27.2	243137	243137
f0b35a0e-e85e-4889-9cb4-18873d6d8f4a	2026-01-24 16:49:56.648431+00	17	27.8	2452	1293
691c563f-78fc-4e8d-94e9-a7ce25b2dde4	2026-01-24 19:40:59.134344+00	17	27.9	2429	1300
594dd861-f117-406f-848f-9bea5ca31580	2026-01-24 22:32:01.500863+00	0	27.3	1840	1339
be7eafba-989a-4793-afa6-e81e185e951a	2026-01-24 16:50:26.926919+00	15.6	27.7	261874	261874
e7d0723d-2003-4aba-a3be-049ed75cfe20	2026-01-24 19:41:26.985375+00	17.4	28.1	265620	265620
d3ddf866-0511-4813-ba6f-7d10a8b9b073	2026-01-24 22:32:26.903998+00	18.4	27	197586	197586
c080043e-5171-4dae-ba07-21022591f7f8	2026-01-24 16:50:56.652512+00	17.1	27.5	2360	1290
875d4d4f-ab41-4715-a52c-ba57c76febf0	2026-01-24 19:41:59.108586+00	16.5	28	2957	1300
eb9935aa-eb3f-4456-8d28-c9b5e7fff843	2026-01-24 22:33:01.575519+00	15.7	27.1	2200	1353
9879b182-d17a-4cdf-8c7c-68e1e3e8a360	2026-01-24 16:51:26.918371+00	15.3	27.4	163689	163689
9afcab53-dbd2-498f-8a2b-b70bae79eccc	2026-01-24 19:42:27.060684+00	17	27.8	191055	191055
68dd61c7-5f5a-4974-a368-d659f68793fe	2026-01-24 22:33:26.956647+00	16.4	27.2	175447	175447
128102c7-18a4-418e-a0f8-403444db85de	2026-01-24 16:51:56.606516+00	16.5	27.4	2069	1301
301c1ceb-7748-4445-bfe4-db489c6e6944	2026-01-24 19:42:59.155829+00	20.2	27.6	2484	1293
4a592f75-4b52-4813-996e-25a818fd426f	2026-01-24 22:34:01.594542+00	14.9	27.2	2134	1354
a0ed4ae1-e1d5-4db6-99c3-aacc205b1bf8	2026-01-24 16:52:26.962542+00	15.5	27.4	195640	195640
6bb3018e-0f8f-41eb-b4d9-9156e0149a51	2026-01-24 19:43:26.858382+00	16.6	27.8	334836	334836
b5a5df8d-cc9c-4abf-bfa9-e2d7dff6b39e	2026-01-24 22:34:26.981745+00	14.7	27.1	168199	168199
2cdd594f-a32a-4545-bde0-a88ca89df87d	2026-01-24 16:52:56.623886+00	16.9	27.4	2161	1293
70588494-0d9d-4e78-9d47-d13291800722	2026-01-24 19:43:59.17639+00	17	27.8	2783	1453
d72a8a91-0ba0-46df-b3d2-241112caa10d	2026-01-24 22:35:01.593946+00	12.9	27.2	2038	1305
85256188-4a4d-481e-bf6f-8db91968a002	2026-01-24 16:53:26.937139+00	16.6	27.6	272608	272608
acf86fd5-cb3e-4d21-93b3-7a7641b2bb99	2026-01-24 19:44:26.883125+00	16.4	27.8	157295	157295
6c29d97c-d8c5-480c-96c7-8c60c63a2e16	2026-01-24 22:35:26.92352+00	14.9	26.9	189292	189292
8a3a753a-7dca-4570-b0ce-989a2e367818	2026-01-24 16:53:56.693102+00	16.9	27.6	3038	1630
c612800c-c61e-40a7-b0f6-dac07f2433ab	2026-01-24 19:44:59.192085+00	17.2	27.8	2389	1299
12cef9a2-377d-4e5a-a46a-cc424ee7097f	2026-01-24 22:36:01.625078+00	14.3	27.2	3308	1952
2764e7e2-0be0-45b6-9de7-40574e2a5e87	2026-01-24 16:54:26.953254+00	16.3	27.7	141489	141489
8cac6565-5f4c-4512-88e5-efb7ca34bc5b	2026-01-24 19:45:26.940626+00	15.8	28	171596	171596
38a07d8c-dbfe-4d7a-a3fb-01cded90fe2a	2026-01-24 22:36:26.997722+00	13.2	27.1	205798	205798
f3eecfd1-b173-4196-a5bd-9cea8eca0e62	2026-01-24 16:54:56.689318+00	16.5	27.5	2780	1427
1e842fe0-b139-4c9b-b5e1-1b3158eec7af	2026-01-24 19:45:59.210421+00	16.8	27.8	3624	1876
f8b3e6fa-99f8-4821-a7b1-99c21741235a	2026-01-24 22:37:01.600867+00	13.6	27.4	3273	1355
108388f6-d01a-417a-af7f-89d8a3c7bee7	2026-01-24 16:55:26.927528+00	16.5	27.6	216064	216064
4e4ed50c-cb4e-4cee-9624-9cca9ba56d46	2026-01-24 19:46:26.919583+00	16.4	28	205692	205692
4ef7a4c9-b5d8-4f59-ac9b-f6dbe0df0391	2026-01-24 22:37:26.970275+00	13.2	26.9	276086	276086
52cfab14-c489-4a71-b186-f17a4972d9c1	2026-01-24 16:55:56.683709+00	16.3	27.6	2951	1284
186cd236-d13e-403f-9682-5d52f60fea64	2026-01-24 19:46:59.189186+00	16.5	27.8	2089	1303
09b40fee-739e-4763-a689-300dc734487f	2026-01-24 22:38:01.645504+00	14.1	27.3	2178	1457
8253132d-759c-4c16-981d-b52b9df33df9	2026-01-24 16:56:26.947098+00	16.3	27.8	192274	192274
37e8f900-ad52-4d8f-ba3b-74b2dc95e61a	2026-01-24 19:47:26.962713+00	16.6	27.6	107985	107985
b854887c-7e66-424c-a074-472cc6d00891	2026-01-24 22:38:26.989267+00	13.4	27.1	193211	193211
2d7ec33a-2bd4-46a9-86c0-050a489bb0bd	2026-01-24 16:56:56.701149+00	16.4	27.7	2475	1317
b31b894c-610e-49e1-8187-42d9c49d124b	2026-01-24 19:47:59.231088+00	17.5	27.5	2322	1400
98d23f85-8953-4797-a989-5df5f6bed4be	2026-01-24 22:39:01.664683+00	13.9	27.1	2063	1329
b0d0abb8-921b-41d8-be98-b55eeb805c45	2026-01-24 16:57:26.899948+00	16.4	27.7	261259	261259
fdd7cab0-fa40-4678-8491-9201ae11ab4c	2026-01-24 19:48:26.950685+00	16.9	27.3	171144	171144
97ad268d-92df-463a-9b7a-5b6d0631176c	2026-01-24 22:39:26.940202+00	12.5	27.3	262485	262485
61b2e934-147a-4a1f-aeaa-5962b05daa7c	2026-01-24 16:57:56.696587+00	16.3	27.6	2422	1351
27af73e6-84eb-4216-9e53-af224731ed8f	2026-01-24 19:48:59.243944+00	16.9	27.6	2451	1325
8ace5a6b-e02f-4325-ba16-edbcdd14b858	2026-01-24 22:40:01.676952+00	0	27	2300	1349
58b8a8b6-f0bc-4ccc-a167-3656caa09eec	2026-01-24 16:58:26.970273+00	16.3	27.8	229099	229099
e4d74e86-7c06-4ffc-9923-f52f42b182d4	2026-01-24 19:49:26.894941+00	16.7	27.6	388785	388785
bbf6d3b9-20d5-4f03-ba5e-6e770b4c2094	2026-01-24 22:40:26.896915+00	12.1	27	184422	184422
7eb8bc6b-0c61-46e5-9f48-b08988f097aa	2026-01-24 16:58:56.728626+00	17	27.5	2169	1280
3e580691-081f-4973-8ba2-a9510d52b3cd	2026-01-24 19:49:59.223044+00	16.7	27.4	2485	1416
b23edaee-4d4f-4b50-9df2-5cbab2095793	2026-01-24 22:41:01.643294+00	14.6	27	2270	1325
9c2c2bd4-b164-4258-93f5-1202c77a1779	2026-01-24 16:59:26.840328+00	16.1	27.7	216805	216805
040c7631-809d-45dc-9052-bf013e162465	2026-01-24 19:50:26.949547+00	16.3	27.7	228537	228537
fc2efa14-0e68-4154-9b08-dcb73b7d0b8c	2026-01-24 22:41:26.939891+00	12.1	27.2	231361	231361
789692d0-2606-4027-8c91-de24ff3445da	2026-01-24 14:09:04.862343+00	36.2	40.2	9872159	9872159
34e43567-32b8-4956-a573-d43874a027ce	2026-01-24 14:10:04.819683+00	27.1	41.4	3902484	3902484
158195fe-39ea-49b8-b83f-e8781ae9a436	2026-01-24 14:10:12.034663+00	27	42.5	7333258	7333258
2965f73b-43cc-47fe-9e83-d42621c9cd23	2026-01-24 16:59:56.785866+00	16.1	27.3	2982	1639
eb979b02-5e83-43c8-b1d3-c0d375c660c2	2026-01-24 19:50:59.2497+00	16.4	27.7	2468	1301
1e2dc313-bd61-49b6-91b2-4dc799a7f55a	2026-01-24 22:42:01.668192+00	14.5	27.1	3897	1939
d66cccc0-448c-4857-98cb-d174d4127493	2026-01-24 17:00:26.875628+00	17.2	27.8	144512	144512
ad1bd6ec-2c04-4fb4-bc74-5fe936bea492	2026-01-24 19:51:26.996118+00	16.6	27.7	171815	171815
bd0b4536-99f9-4fc9-9767-6f29370d0ae7	2026-01-24 22:42:26.946599+00	14.4	27.3	185807	185807
91509838-8f36-4aac-9e08-0563a06157ba	2026-01-24 14:15:28.023313+00	55.7	40.4	8186	71033
88493ad6-75ec-4630-968f-3c2089b51164	2026-01-24 17:00:56.757547+00	16.3	27.8	2978	1441
2afb187e-eaad-428b-adbf-6fd612384874	2026-01-24 19:51:59.263009+00	16.1	27.8	3817	1908
8e621fa5-ad72-4706-9a01-f8f168044c2e	2026-01-24 22:43:01.713441+00	13.4	27.1	2203	1356
0a84fafe-d9cb-451a-a80c-c04880fe332b	2026-01-24 17:01:26.883716+00	17	27.3	158531	158531
d9858563-7aca-44da-a859-b3350e8c92da	2026-01-24 19:52:27.027823+00	18	27.6	89550	89550
6c829ce4-d005-41b2-bfe1-b5f64b372ee0	2026-01-24 22:43:26.929655+00	12.4	27.4	148617	148617
7b7840b2-37c2-4abc-87dc-18e2065a226b	2026-01-24 14:16:28.187879+00	27	41.3	0	0
46fedb22-e7e9-47e9-b4f4-6163a10233f5	2026-01-24 17:01:56.760736+00	16.4	27.8	2130	1306
bbbc1bb6-784b-445e-bd06-6f20acf72a9f	2026-01-24 19:52:59.257722+00	16.7	28	2152	1315
e75cc394-534c-44a0-8142-07f4bc04fe44	2026-01-24 22:44:01.727717+00	13.5	27.1	2275	1470
a6d0a88d-a583-4aab-9cef-1e44b8ad9ac5	2026-01-24 17:02:26.860921+00	17.5	27.5	217924	217924
f1049bbf-943d-4180-bb50-e7a3559a80bd	2026-01-24 19:53:26.9487+00	17.5	27.7	214372	214372
33203306-6d62-43ea-a809-d240e0e3e570	2026-01-24 22:44:26.914183+00	11.9	27.3	173764	173764
0bcbcec6-96b7-4821-a2c3-70a8e9acd644	2026-01-24 14:16:54.181657+00	47.9	40.7	3742	53367
2f895540-e45b-42af-830d-a75e7ad1bcb8	2026-01-24 17:02:56.777998+00	16.6	27.7	2418	1287
1dacaec9-b794-4f2c-855e-a6af75ab013b	2026-01-24 19:53:59.322673+00	15.3	27.9	2206	1302
5e6459f2-34a2-4149-a92b-af0d6774e4d0	2026-01-24 22:45:01.74946+00	13.6	27.2	2020	1342
fa92e801-a22e-49b2-82db-427863fd8d3e	2026-01-24 17:03:26.8551+00	16.5	27.8	220901	220901
94687669-5d5a-44e4-bf12-cf286bd113b9	2026-01-24 19:54:26.957212+00	16.8	27.7	204355	204355
3f6452d0-4ac0-4c0f-a1ff-460f61bb7517	2026-01-24 22:45:26.93306+00	11.6	27.3	152738	152738
3b0f343d-29d2-400e-a25a-a4926ff7e53b	2026-01-24 17:03:56.823757+00	16.4	27.9	2448	1291
b82f0e0e-2e47-43c8-aeed-7aa9edc6a7c9	2026-01-24 19:54:59.346133+00	16	27.8	2095	1279
7066a006-b1c7-4f4b-8669-1dd49bc307c5	2026-01-24 22:46:01.754545+00	13.5	27.3	2018	1355
06522d45-0b92-4082-b8aa-560e3c878d49	2026-01-24 17:04:26.906059+00	16.1	27.8	252849	252849
f9d69579-cb27-4a0a-8bbd-94eb6f732faa	2026-01-24 19:55:27.027416+00	16.9	27.6	141981	141981
1ed54317-811d-4698-a701-887a514c36c3	2026-01-24 22:46:26.962524+00	12.3	27.3	201691	201691
0aabbce4-278d-49e9-a078-d92e82f29ce6	2026-01-24 17:04:56.864091+00	16.4	28	2351	1290
40c8ce3a-45e2-41a9-91a5-0c0b11b80487	2026-01-24 19:55:59.361913+00	16.9	27.7	2434	1273
bcaba6a4-cd92-4867-85c0-022ad71ece87	2026-01-24 22:47:01.712515+00	13.2	27.2	2742	1304
e5b39b8d-5009-4e5c-82ec-d1ed95e3af0d	2026-01-24 17:05:26.872995+00	15.5	27.9	339850	339850
16601c4c-27d1-4273-a6ac-a67f95222577	2026-01-24 19:56:27.016815+00	17	27.8	218685	218685
ca1b824b-6f88-4083-ac20-67ee733e9641	2026-01-24 22:47:26.966709+00	13.1	27.5	240838	240838
703676f9-b386-462c-8c52-7cc54528e235	2026-01-24 17:05:56.887624+00	16.4	27.8	2975	1629
0725cd0e-97f4-4131-a928-4498be923e13	2026-01-24 19:56:59.335923+00	15.9	27.8	2445	1254
5d581fe8-321f-4b58-aa5b-5e9ca78962cf	2026-01-24 22:48:01.783429+00	12.7	27.2	4117	2063
6081c6ae-5380-4482-8845-c19c7c996fee	2026-01-24 17:06:26.93531+00	16.2	27.9	205977	205977
d78a9f7b-0198-4e8f-aa3b-6c8b06f70f34	2026-01-24 19:57:26.899134+00	17.5	27.9	263500	263500
687bf0b4-dac6-470a-9cfa-2c56f8568c37	2026-01-24 22:48:26.954419+00	14	27.4	153170	153170
df5955a0-0d53-45ea-918b-671f9601f471	2026-01-24 17:06:56.858455+00	16.8	27.6	2536	1452
c7f0a1e7-0c3e-44ff-9e15-1631f66c0420	2026-01-24 19:57:59.381374+00	16.7	27.8	4575	1958
0fb67c70-4b1e-411b-a246-3c14c88bc91b	2026-01-24 22:49:01.792116+00	13.1	27.2	3064	1349
e0e32634-4cbb-43ca-9289-d7c8e3904e0e	2026-01-24 17:07:26.902558+00	16.3	27.6	229142	229142
1594a0ac-70ce-420b-bcff-7e6f93a8fcc1	2026-01-24 19:58:26.85439+00	16.6	27.8	292575	292575
aba85723-ce59-4bfa-a85c-ebee4dd44a53	2026-01-24 22:49:26.96921+00	13.4	27.2	177211	177211
d6d9585b-f41e-4811-97ad-375dd91dcda6	2026-01-24 17:07:56.856425+00	16.5	27.9	2152	1366
a2b6c049-7fa4-4cc6-942e-8042c8058559	2026-01-24 19:58:59.401032+00	17.3	27.8	2453	1286
e1762288-fa32-41a4-938c-5a2383a41b39	2026-01-24 22:50:01.804457+00	13.4	27.2	2996	1602
0e4396ef-1076-46af-a055-7594d6a957eb	2026-01-24 17:08:27.09649+00	16.5	27.8	188361	188361
72374b61-eef8-4757-819c-821e145aa3ff	2026-01-24 19:59:26.973818+00	16.8	27.8	176158	176158
708e9cb5-854c-41b0-b23f-62736973f19e	2026-01-24 22:50:26.975135+00	13.5	27.2	142867	142867
70d26bef-3005-442b-9da0-68f2e12a191a	2026-01-24 17:08:56.925015+00	16.4	27.9	2151	1287
378ec1f2-b10d-4538-b0e4-c857bcc3c7f7	2026-01-24 19:59:59.416352+00	16.9	27.8	2209	1277
fa82eacd-7224-40fb-8d86-67c298f1a381	2026-01-24 22:51:01.787981+00	13.6	27.2	2153	1322
1033bfee-f970-47bc-bac4-80e0585ef538	2026-01-24 17:09:26.929759+00	16	28	301675	301675
46824285-1477-4d94-9f2c-2cc17feea7c3	2026-01-24 20:00:26.900511+00	16.1	27.8	225301	225301
9bccf596-f3d7-4aa5-b8a8-055a38e701e8	2026-01-24 22:51:26.957793+00	13.6	27.2	178209	178209
10acaa0c-c88b-4eff-9de7-27917a117d32	2026-01-24 17:09:56.940709+00	16.4	27.8	2445	1293
d2559008-d14b-43a5-b8a5-a149076cc691	2026-01-24 20:00:59.434405+00	16.6	27.7	2114	1268
4c8f5710-9111-42f0-9189-aa8fce07b370	2026-01-24 22:52:01.773953+00	13.3	27.3	2193	1355
02e9f7fb-b6c2-42af-93b3-976848848630	2026-01-24 17:10:26.839901+00	16.1	27.9	180429	180429
28e227b1-ad0b-48e0-b208-158b73f7b279	2026-01-24 20:01:26.933447+00	15.5	27.8	168355	168355
bb2b113e-7bdd-46f1-8b65-6fc82586796a	2026-01-24 22:52:27.007803+00	13.6	27.3	220634	220634
e579b090-f1da-4a11-86e8-760940725db1	2026-01-24 17:10:56.959538+00	16.4	27.4	2402	1264
7ae67c2b-a4a9-4037-ba51-5d7c7735cb26	2026-01-24 20:01:59.381462+00	16.9	27.8	2139	1252
21c44650-377b-4927-b03b-06f419e892d4	2026-01-24 22:53:01.802506+00	13.6	27.2	2149	1321
7ff8e90b-104d-4c65-a9be-e29368e64b63	2026-01-24 17:11:26.867512+00	17.1	27.4	327321	327321
c6ddf2cf-b2bb-4250-8c13-6fcbdfd6cec8	2026-01-24 20:02:26.945233+00	17.4	27.6	194614	194614
2eba3b9d-a2d2-4cf2-83fc-37494dfa1c3d	2026-01-24 22:53:27.002838+00	13.8	27.1	210895	210895
\.


--
-- Data for Name: telegram_bots; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.telegram_bots (id, name, token, username, description, is_active, created_at, updated_at) FROM stdin;
\.


--
-- Data for Name: vpn_profiles; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.vpn_profiles (id, name, config, is_active, created_at, updated_at) FROM stdin;
\.


--
-- Name: activity_logs activity_logs_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.activity_logs
    ADD CONSTRAINT activity_logs_pkey PRIMARY KEY (id);


--
-- Name: admins admins_email_key; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.admins
    ADD CONSTRAINT admins_email_key UNIQUE (email);


--
-- Name: admins admins_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.admins
    ADD CONSTRAINT admins_pkey PRIMARY KEY (id);


--
-- Name: ai_requests ai_requests_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.ai_requests
    ADD CONSTRAINT ai_requests_pkey PRIMARY KEY (id);


--
-- Name: app_settings app_settings_key_key; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.app_settings
    ADD CONSTRAINT app_settings_key_key UNIQUE (key);


--
-- Name: app_settings app_settings_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.app_settings
    ADD CONSTRAINT app_settings_pkey PRIMARY KEY (id);


--
-- Name: backups backups_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.backups
    ADD CONSTRAINT backups_pkey PRIMARY KEY (id);


--
-- Name: disk_snapshots disk_snapshots_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.disk_snapshots
    ADD CONSTRAINT disk_snapshots_pkey PRIMARY KEY (id);


--
-- Name: dns_configs dns_configs_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.dns_configs
    ADD CONSTRAINT dns_configs_pkey PRIMARY KEY (id);


--
-- Name: firewall_rules firewall_rules_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.firewall_rules
    ADD CONSTRAINT firewall_rules_pkey PRIMARY KEY (id);


--
-- Name: media_channels media_channels_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.media_channels
    ADD CONSTRAINT media_channels_pkey PRIMARY KEY (id);


--
-- Name: monitored_hosts monitored_hosts_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.monitored_hosts
    ADD CONSTRAINT monitored_hosts_pkey PRIMARY KEY (id);


--
-- Name: network_traffic network_traffic_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.network_traffic
    ADD CONSTRAINT network_traffic_pkey PRIMARY KEY (id);


--
-- Name: security_settings security_settings_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.security_settings
    ADD CONSTRAINT security_settings_pkey PRIMARY KEY (id);


--
-- Name: service_uptime service_uptime_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.service_uptime
    ADD CONSTRAINT service_uptime_pkey PRIMARY KEY (id);


--
-- Name: services services_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.services
    ADD CONSTRAINT services_pkey PRIMARY KEY (id);


--
-- Name: system_metrics system_metrics_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.system_metrics
    ADD CONSTRAINT system_metrics_pkey PRIMARY KEY (id);


--
-- Name: telegram_bots telegram_bots_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.telegram_bots
    ADD CONSTRAINT telegram_bots_pkey PRIMARY KEY (id);


--
-- Name: vpn_profiles vpn_profiles_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.vpn_profiles
    ADD CONSTRAINT vpn_profiles_pkey PRIMARY KEY (id);


--
-- Name: idx_admins_last_seen; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX idx_admins_last_seen ON public.admins USING btree (last_seen_at);


--
-- Name: idx_admins_online_status; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX idx_admins_online_status ON public.admins USING btree (online_status);


--
-- Name: idx_disk_snapshots_name_timestamp; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX idx_disk_snapshots_name_timestamp ON public.disk_snapshots USING btree (name, "timestamp" DESC);


--
-- Name: idx_disk_snapshots_timestamp; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX idx_disk_snapshots_timestamp ON public.disk_snapshots USING btree ("timestamp" DESC);


--
-- Name: idx_network_traffic_recorded_at; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX idx_network_traffic_recorded_at ON public.network_traffic USING btree (recorded_at DESC);


--
-- Name: idx_service_uptime_checked_at; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX idx_service_uptime_checked_at ON public.service_uptime USING btree (checked_at DESC);


--
-- Name: idx_service_uptime_service_id; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX idx_service_uptime_service_id ON public.service_uptime USING btree (service_id);


--
-- Name: idx_system_metrics_timestamp; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX idx_system_metrics_timestamp ON public.system_metrics USING btree ("timestamp" DESC);


--
-- Name: admins update_admins_updated_at; Type: TRIGGER; Schema: public; Owner: postgres
--

CREATE TRIGGER update_admins_updated_at BEFORE UPDATE ON public.admins FOR EACH ROW EXECUTE FUNCTION public.update_updated_at_column();


--
-- Name: app_settings update_app_settings_updated_at; Type: TRIGGER; Schema: public; Owner: postgres
--

CREATE TRIGGER update_app_settings_updated_at BEFORE UPDATE ON public.app_settings FOR EACH ROW EXECUTE FUNCTION public.update_updated_at_column();


--
-- Name: dns_configs update_dns_configs_updated_at; Type: TRIGGER; Schema: public; Owner: postgres
--

CREATE TRIGGER update_dns_configs_updated_at BEFORE UPDATE ON public.dns_configs FOR EACH ROW EXECUTE FUNCTION public.update_updated_at_column();


--
-- Name: firewall_rules update_firewall_rules_updated_at; Type: TRIGGER; Schema: public; Owner: postgres
--

CREATE TRIGGER update_firewall_rules_updated_at BEFORE UPDATE ON public.firewall_rules FOR EACH ROW EXECUTE FUNCTION public.update_updated_at_column();


--
-- Name: media_channels update_media_channels_updated_at; Type: TRIGGER; Schema: public; Owner: postgres
--

CREATE TRIGGER update_media_channels_updated_at BEFORE UPDATE ON public.media_channels FOR EACH ROW EXECUTE FUNCTION public.update_updated_at_column();


--
-- Name: security_settings update_security_settings_updated_at; Type: TRIGGER; Schema: public; Owner: postgres
--

CREATE TRIGGER update_security_settings_updated_at BEFORE UPDATE ON public.security_settings FOR EACH ROW EXECUTE FUNCTION public.update_updated_at_column();


--
-- Name: services update_services_updated_at; Type: TRIGGER; Schema: public; Owner: postgres
--

CREATE TRIGGER update_services_updated_at BEFORE UPDATE ON public.services FOR EACH ROW EXECUTE FUNCTION public.update_updated_at_column();


--
-- Name: telegram_bots update_telegram_bots_updated_at; Type: TRIGGER; Schema: public; Owner: postgres
--

CREATE TRIGGER update_telegram_bots_updated_at BEFORE UPDATE ON public.telegram_bots FOR EACH ROW EXECUTE FUNCTION public.update_updated_at_column();


--
-- Name: vpn_profiles update_vpn_profiles_updated_at; Type: TRIGGER; Schema: public; Owner: postgres
--

CREATE TRIGGER update_vpn_profiles_updated_at BEFORE UPDATE ON public.vpn_profiles FOR EACH ROW EXECUTE FUNCTION public.update_updated_at_column();


--
-- Name: service_uptime service_uptime_service_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.service_uptime
    ADD CONSTRAINT service_uptime_service_id_fkey FOREIGN KEY (service_id) REFERENCES public.services(id) ON DELETE CASCADE;


--
-- Name: admins Admin access; Type: POLICY; Schema: public; Owner: postgres
--

CREATE POLICY "Admin access" ON public.admins TO authenticated USING (true);


--
-- Name: monitored_hosts Allow anon to view hosts; Type: POLICY; Schema: public; Owner: postgres
--

CREATE POLICY "Allow anon to view hosts" ON public.monitored_hosts FOR SELECT TO anon USING (true);


--
-- Name: monitored_hosts Allow authenticated full access; Type: POLICY; Schema: public; Owner: postgres
--

CREATE POLICY "Allow authenticated full access" ON public.monitored_hosts TO authenticated USING (true);


--
-- Name: ai_requests Authenticated ai logs; Type: POLICY; Schema: public; Owner: postgres
--

CREATE POLICY "Authenticated ai logs" ON public.ai_requests TO authenticated USING (true);


--
-- Name: backups Authenticated backups; Type: POLICY; Schema: public; Owner: postgres
--

CREATE POLICY "Authenticated backups" ON public.backups TO authenticated USING (true);


--
-- Name: telegram_bots Authenticated bot access; Type: POLICY; Schema: public; Owner: postgres
--

CREATE POLICY "Authenticated bot access" ON public.telegram_bots TO authenticated USING (true);


--
-- Name: media_channels Authenticated channels; Type: POLICY; Schema: public; Owner: postgres
--

CREATE POLICY "Authenticated channels" ON public.media_channels TO authenticated USING (true);


--
-- Name: disk_snapshots Authenticated disks; Type: POLICY; Schema: public; Owner: postgres
--

CREATE POLICY "Authenticated disks" ON public.disk_snapshots TO authenticated USING (true);


--
-- Name: dns_configs Authenticated dns; Type: POLICY; Schema: public; Owner: postgres
--

CREATE POLICY "Authenticated dns" ON public.dns_configs TO authenticated USING (true);


--
-- Name: firewall_rules Authenticated firewall; Type: POLICY; Schema: public; Owner: postgres
--

CREATE POLICY "Authenticated firewall" ON public.firewall_rules TO authenticated USING (true);


--
-- Name: activity_logs Authenticated logs; Type: POLICY; Schema: public; Owner: postgres
--

CREATE POLICY "Authenticated logs" ON public.activity_logs TO authenticated USING (true);


--
-- Name: system_metrics Authenticated metrics; Type: POLICY; Schema: public; Owner: postgres
--

CREATE POLICY "Authenticated metrics" ON public.system_metrics TO authenticated USING (true);


--
-- Name: security_settings Authenticated security; Type: POLICY; Schema: public; Owner: postgres
--

CREATE POLICY "Authenticated security" ON public.security_settings TO authenticated USING (true);


--
-- Name: services Authenticated services; Type: POLICY; Schema: public; Owner: postgres
--

CREATE POLICY "Authenticated services" ON public.services TO authenticated USING (true);


--
-- Name: app_settings Authenticated settings; Type: POLICY; Schema: public; Owner: postgres
--

CREATE POLICY "Authenticated settings" ON public.app_settings TO authenticated USING (true);


--
-- Name: network_traffic Authenticated traffic; Type: POLICY; Schema: public; Owner: postgres
--

CREATE POLICY "Authenticated traffic" ON public.network_traffic TO authenticated USING (true);


--
-- Name: vpn_profiles Authenticated vpn; Type: POLICY; Schema: public; Owner: postgres
--

CREATE POLICY "Authenticated vpn" ON public.vpn_profiles TO authenticated USING (true);


--
-- Name: media_channels Public read channels; Type: POLICY; Schema: public; Owner: postgres
--

CREATE POLICY "Public read channels" ON public.media_channels FOR SELECT TO web_anon USING (true);


--
-- Name: disk_snapshots Public read disks; Type: POLICY; Schema: public; Owner: postgres
--

CREATE POLICY "Public read disks" ON public.disk_snapshots FOR SELECT TO web_anon USING (true);


--
-- Name: system_metrics Public read metrics; Type: POLICY; Schema: public; Owner: postgres
--

CREATE POLICY "Public read metrics" ON public.system_metrics FOR SELECT TO web_anon USING (true);


--
-- Name: services Public read services; Type: POLICY; Schema: public; Owner: postgres
--

CREATE POLICY "Public read services" ON public.services FOR SELECT TO web_anon USING (true);


--
-- Name: network_traffic Public read traffic; Type: POLICY; Schema: public; Owner: postgres
--

CREATE POLICY "Public read traffic" ON public.network_traffic FOR SELECT TO web_anon USING (true);


--
-- Name: activity_logs; Type: ROW SECURITY; Schema: public; Owner: postgres
--

ALTER TABLE public.activity_logs ENABLE ROW LEVEL SECURITY;

--
-- Name: admins; Type: ROW SECURITY; Schema: public; Owner: postgres
--

ALTER TABLE public.admins ENABLE ROW LEVEL SECURITY;

--
-- Name: ai_requests; Type: ROW SECURITY; Schema: public; Owner: postgres
--

ALTER TABLE public.ai_requests ENABLE ROW LEVEL SECURITY;

--
-- Name: activity_logs anon_select_logs; Type: POLICY; Schema: public; Owner: postgres
--

CREATE POLICY anon_select_logs ON public.activity_logs FOR SELECT TO anon USING (true);


--
-- Name: app_settings; Type: ROW SECURITY; Schema: public; Owner: postgres
--

ALTER TABLE public.app_settings ENABLE ROW LEVEL SECURITY;

--
-- Name: backups; Type: ROW SECURITY; Schema: public; Owner: postgres
--

ALTER TABLE public.backups ENABLE ROW LEVEL SECURITY;

--
-- Name: disk_snapshots; Type: ROW SECURITY; Schema: public; Owner: postgres
--

ALTER TABLE public.disk_snapshots ENABLE ROW LEVEL SECURITY;

--
-- Name: dns_configs; Type: ROW SECURITY; Schema: public; Owner: postgres
--

ALTER TABLE public.dns_configs ENABLE ROW LEVEL SECURITY;

--
-- Name: firewall_rules; Type: ROW SECURITY; Schema: public; Owner: postgres
--

ALTER TABLE public.firewall_rules ENABLE ROW LEVEL SECURITY;

--
-- Name: media_channels; Type: ROW SECURITY; Schema: public; Owner: postgres
--

ALTER TABLE public.media_channels ENABLE ROW LEVEL SECURITY;

--
-- Name: monitored_hosts; Type: ROW SECURITY; Schema: public; Owner: postgres
--

ALTER TABLE public.monitored_hosts ENABLE ROW LEVEL SECURITY;

--
-- Name: network_traffic; Type: ROW SECURITY; Schema: public; Owner: postgres
--

ALTER TABLE public.network_traffic ENABLE ROW LEVEL SECURITY;

--
-- Name: security_settings; Type: ROW SECURITY; Schema: public; Owner: postgres
--

ALTER TABLE public.security_settings ENABLE ROW LEVEL SECURITY;

--
-- Name: service_uptime; Type: ROW SECURITY; Schema: public; Owner: postgres
--

ALTER TABLE public.service_uptime ENABLE ROW LEVEL SECURITY;

--
-- Name: services; Type: ROW SECURITY; Schema: public; Owner: postgres
--

ALTER TABLE public.services ENABLE ROW LEVEL SECURITY;

--
-- Name: system_metrics; Type: ROW SECURITY; Schema: public; Owner: postgres
--

ALTER TABLE public.system_metrics ENABLE ROW LEVEL SECURITY;

--
-- Name: telegram_bots; Type: ROW SECURITY; Schema: public; Owner: postgres
--

ALTER TABLE public.telegram_bots ENABLE ROW LEVEL SECURITY;

--
-- Name: vpn_profiles; Type: ROW SECURITY; Schema: public; Owner: postgres
--

ALTER TABLE public.vpn_profiles ENABLE ROW LEVEL SECURITY;

--
-- Name: SCHEMA public; Type: ACL; Schema: -; Owner: pg_database_owner
--

GRANT USAGE ON SCHEMA public TO web_anon;
GRANT USAGE ON SCHEMA public TO authenticated;
GRANT USAGE ON SCHEMA public TO anon;


--
-- Name: TABLE activity_logs; Type: ACL; Schema: public; Owner: postgres
--

GRANT ALL ON TABLE public.activity_logs TO authenticated;
GRANT SELECT ON TABLE public.activity_logs TO web_anon;
GRANT SELECT ON TABLE public.activity_logs TO anon;


--
-- Name: TABLE admins; Type: ACL; Schema: public; Owner: postgres
--

GRANT ALL ON TABLE public.admins TO authenticated;


--
-- Name: TABLE ai_requests; Type: ACL; Schema: public; Owner: postgres
--

GRANT ALL ON TABLE public.ai_requests TO authenticated;


--
-- Name: TABLE app_settings; Type: ACL; Schema: public; Owner: postgres
--

GRANT ALL ON TABLE public.app_settings TO authenticated;


--
-- Name: TABLE backups; Type: ACL; Schema: public; Owner: postgres
--

GRANT ALL ON TABLE public.backups TO authenticated;


--
-- Name: TABLE disk_snapshots; Type: ACL; Schema: public; Owner: postgres
--

GRANT ALL ON TABLE public.disk_snapshots TO authenticated;
GRANT SELECT ON TABLE public.disk_snapshots TO web_anon;


--
-- Name: TABLE dns_configs; Type: ACL; Schema: public; Owner: postgres
--

GRANT ALL ON TABLE public.dns_configs TO authenticated;


--
-- Name: TABLE firewall_rules; Type: ACL; Schema: public; Owner: postgres
--

GRANT ALL ON TABLE public.firewall_rules TO authenticated;


--
-- Name: TABLE media_channels; Type: ACL; Schema: public; Owner: postgres
--

GRANT ALL ON TABLE public.media_channels TO authenticated;
GRANT SELECT ON TABLE public.media_channels TO web_anon;


--
-- Name: TABLE monitored_hosts; Type: ACL; Schema: public; Owner: postgres
--

GRANT SELECT ON TABLE public.monitored_hosts TO anon;
GRANT ALL ON TABLE public.monitored_hosts TO authenticated;


--
-- Name: TABLE network_traffic; Type: ACL; Schema: public; Owner: postgres
--

GRANT ALL ON TABLE public.network_traffic TO authenticated;
GRANT SELECT ON TABLE public.network_traffic TO web_anon;


--
-- Name: TABLE security_settings; Type: ACL; Schema: public; Owner: postgres
--

GRANT ALL ON TABLE public.security_settings TO authenticated;


--
-- Name: TABLE service_uptime; Type: ACL; Schema: public; Owner: postgres
--

GRANT ALL ON TABLE public.service_uptime TO authenticated;


--
-- Name: TABLE services; Type: ACL; Schema: public; Owner: postgres
--

GRANT ALL ON TABLE public.services TO authenticated;
GRANT SELECT ON TABLE public.services TO web_anon;


--
-- Name: TABLE system_metrics; Type: ACL; Schema: public; Owner: postgres
--

GRANT ALL ON TABLE public.system_metrics TO authenticated;
GRANT SELECT ON TABLE public.system_metrics TO web_anon;


--
-- Name: TABLE telegram_bots; Type: ACL; Schema: public; Owner: postgres
--

GRANT ALL ON TABLE public.telegram_bots TO authenticated;


--
-- Name: TABLE vpn_profiles; Type: ACL; Schema: public; Owner: postgres
--

GRANT ALL ON TABLE public.vpn_profiles TO authenticated;


--
-- PostgreSQL database dump complete
--

\unrestrict ooTo6xBfrOOURBEZInhTLftDygIleGdmEnb1HayfUFccuQoBHdH1IaUQg0Rtp6m

