# 🔧 HOTFIX: Services Status Issue Resolution

**Дата:** 2026-01-11 12:25  
**Проблема:** Все сервисы показывались как "неактивные" в дашборде  
**Статус:** ✅ **ИСПРАВЛЕНО**

---

## 🚨 **ПРИЧИНА ПРОБЛЕМЫ**

После перезапуска `system-api` (во время применения Phase 3 fixes), Docker присвоил контейнеру новый IP-адрес:
- **Старый IP:** `172.18.0.11`
- **Новый IP:** (динамически назначен Docker)

**Nginx** кэшировал старый IP-адрес и продолжал пытаться подключиться к нему, получая "Connection refused".

---

## ✅ **РЕШЕНИЕ**

Перезапуск Nginx контейнера для сброса DNS-кэша:

```bash
docker compose restart creationhub
```

Это заставило Nginx заново резолвить имя `system-api` и получить актуальный IP.

---

## 🔍 **ДИАГНОСТИКА**

```bash
# Проверка логов Nginx показала:
[error] connect() failed (111: Connection refused) 
upstream: "http://172.18.0.11:9191/api/services/status-by-port"
                    ^^^^^^^^^ старый IP

# Прямое обращение к System API работало:
curl http://localhost:9191/api/services/status-by-port  # ✅ OK

# Через Nginx не работало:
curl http://localhost:7777/api/services/status-by-port  # ❌ Error
```

---

## 📊 **ТЕКУЩИЙ СТАТУС**

```json
{
  "postgres": "online",
  "redis": "online",
  "api": "online",
  "dashboard": "online",
  "ollama": "online",
  "grafana": "online",
  "prometheus": "online"
}
```

✅ Все сервисы показываются корректно в дашборде.

---

## 🛡️ **ПРОФИЛАКТИКА В БУДУЩЕМ**

### **Опция 1: Использовать статические IP (рекомендуется)**
```yaml
# docker-compose.yml
services:
  system-api:
    networks:
      creationhub-backend:
        ipv4_address: 172.18.0.11
```

### **Опция 2: Настроить Nginx resolver с коротким TTL**
```nginx
resolver 127.0.0.11 valid=10s;  # Docker внутренний DNS
set $upstream system-api:9191;
proxy_pass http://$upstream;
```

### **Опция 3: Использовать docker-compose down/up вместо restart**
При критических изменениях System API использовать:
```bash
docker compose down system-api
docker compose up -d system-api
docker compose restart creationhub  # Всегда перезапускать Nginx после
```

---

## ✅ **ВЕРДИКТ**

Проблема решена. Это была временная проблема DNS-кэширования.  
**Действий не требуется** - система работает корректно.

**Рекомендация:** При будущих перезапусках System API всегда перезапускать Nginx.

---

**Время решения:** < 5 минут  
**Downtime:** ~10 секунд (перезапуск Nginx)
