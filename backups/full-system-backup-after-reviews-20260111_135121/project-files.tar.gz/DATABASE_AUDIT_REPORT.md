# 🗄️ DATABASE AUDIT REPORT

**Дата:** 2026-01-11 12:55  
**Статус:** ⚠️ **НАЙДЕНЫ ПРОБЛЕМЫ**

---

## 📊 **СТАТИСТИКА БАЗЫ ДАННЫХ**

### **Размер и активность таблиц:**

| Таблица | Строк | Dead Rows | Размер | Статус |
|---------|-------|-----------|--------|--------|
| `system_metrics` | 31,760 | 0 | 4.8 MB | ✅ Активная |
| `network_traffic` | 28,031 | 0 | 5.1 MB | ✅ Активная |
| `disk_snapshots` | 4,900 | 0 | 1.2 MB | ✅ Активная |
| `activity_logs` | 21 | 0 | 32 KB | ✅ Используется |
| `services` | 20 | 15 | 32 KB | ⚠️ Dead rows |
| `security_settings` | 1 | 0 | 32 KB | ✅ OK |
| `backups` | 1 | 0 | 32 KB | ✅ OK |
| **17 таблиц** | **0 строк** | - | **~400 KB** | ⚠️ **ПУСТЫЕ** |

---

## 🚨 **КРИТИЧЕСКИЕ ПРОБЛЕМЫ**

### **1. ❌ НЕПРАВИЛЬНЫЕ ЗАПРОСЫ К БД (3 места)**

#### **Проблема A: activity_logs.created_at**
**Файл:** `src/pages/SecurityPage.tsx`  
**Строки:** 71, 79

**Ошибка в логах:**
```
ERROR: column activity_logs.created_at does not exist at character 151
```

**Фактическая структура:**
```sql
activity_logs:
  - timestamp (не created_at!)
```

**Неправильный код:**
```typescript
.order('created_at', { ascending: false })  // ❌
...
time: timeAgo(e.created_at)  // ❌
```

**Должно быть:**
```typescript
.order('timestamp', { ascending: false })  // ✅
...
time: timeAgo(e.timestamp)  // ✅
```

---

#### **Проблема B: security_settings.setting_key**
**Файл:** `src/pages/SecurityPage.tsx`  
**Строки:** 111-112

**Ошибка в логах:**
```
ERROR: column security_settings.setting_key does not exist at character 31
```

**Фактическая структура:**
```sql
security_settings:
  - id, ufw_status, fail2ban_status, ssh_port
  - last_check_at, created_at, updated_at
  (нет setting_key/setting_value!)
```

**Неправильный код:**
```typescript
.select('setting_key, setting_value')
.eq('setting_key', 'realtime')
```

**Решение:** Запрос неправильный. Нужно просто читать последнюю запись:
```typescript
.select('ufw_status, fail2ban_status')
.order('created_at', { ascending: false })
.limit(1)
.single()
```

---

## ⚠️ **ПРЕДУПРЕЖДЕНИЯ**

### **2. ⚠️ ПУСТЫЕ ТАБЛИЦЫ (17 штук)**

Следующие таблицы **полностью пустые** и занимают место:

| Таблица | Назначение (предположительно) | Действие |
|---------|-------------------------------|----------|
| `ai_requests` | AI Hub запросы | Удалить или начать использовать |
| `ad_clicks` | Реклама | Вероятно не используется - удалить |
| `ad_purchases` | Реклама | Вероятно не используется - удалить |
| `ad_sales` | Реклама | Вероятно не используется - удалить |
| `admins` | Админы | ⚠️ 8 dead rows - нужен VACUUM |
| `app_settings` | Настройки | Удалить или использовать |
| `channel_ad_rates` | Реклама | Удалить |
| `dns_configs` | DNS конфиги | Удалить или использовать |
| `firewall_rules` | Firewall | Используется UI, но пуста |
| `media_channels` | Медиа | Удалить или использовать |
| `monitored_hosts` | Мониторинг | Удалить или использовать |
| `service_uptime` | Uptime сервисов | Удалить или использовать |
| `telegram_ads` | Telegram реклама | Удалить |
| `telegram_bots` | Telegram боты | Удалить или использовать |
| `vpn_profiles` | VPN | Удалить или использовать |

**Рекомендация:**  
- Удалить таблицы связанные с рекламой (8 tables ~150 KB)
- Провести VACUUM на `admins` (8 dead rows)
- Проверить нужны ли остальные пустые таблицы

---

### **3. ⚠️ DEAD ROWS в services**

Таблица `services` имеет 15 dead rows при 20 живых.  
**Решение:** Запустить VACUUM.

---

## 🔧 **ПЛАН ИСПРАВЛЕНИЙ**

### **Приоритет 1: КРИТИЧНО (сейчас)**
1. ✅ Исправить `activity_logs.created_at` → `timestamp`
2. ✅ Исправить запрос к `security_settings`

### **Приоритет 2: ВАЖНО (сегодня)**
3. ✅ Удалить неиспользуемые таблицы (реклама)
4. ✅ Провести VACUUM ANALYZE

### **Приоритет 3: ОПЦИОНАЛЬНО (на неделе)**
5. Решить судьбу пустых таблиц (использовать или удалить)

---

## 📝 **SQL ДЛЯ ОЧИСТКИ**

```sql
-- 1. Удаление рекламных таблиц (не используются)
DROP TABLE IF EXISTS ad_clicks CASCADE;
DROP TABLE IF EXISTS ad_purchases CASCADE;
DROP TABLE IF EXISTS ad_sales CASCADE;
DROP TABLE IF EXISTS channel_ad_rates CASCADE;
DROP TABLE IF EXISTS telegram_ads CASCADE;

-- 2. Очистка dead rows
VACUUM ANALYZE admins;
VACUUM ANALYZE services;

-- 3. Полная оптимизация БД
VACUUM ANALYZE;
```

---

## ✅ **ВЕРДИКТ**

**Найдено:**
- ❌ 3 критических бага (неправильные запросы)
- ⚠️ 17 пустых таблиц
- ⚠️ Dead rows в 2 таблицах

**Влияние:**
- Ошибки в логах PostgreSQL
- Неработающие функции фронтенда (Security Page)
- Небольшая трата места (~500 KB)

**Следующий шаг:** Исправить код фронтенда и очистить БД.

---

**Дата отчёта:** 2026-01-11 12:55
