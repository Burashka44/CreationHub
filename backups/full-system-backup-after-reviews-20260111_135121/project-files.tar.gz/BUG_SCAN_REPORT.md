# 🔍 COMPREHENSIVE BUG SCAN REPORT

**Дата сканирования:** 2026-01-11 12:27  
**Статус:** ⚠️ **4 ПРОБЛЕМЫ ОБНАРУЖЕНЫ**

---

## 🚨 **КРИТИЧЕСКИЕ ПРОБЛЕМЫ**

### **1. ❌ Hardcoded IP в nginx.conf**

**Серьезность:** 🔴 **HIGH (7/10)**

**Найдено:**
```nginx
proxy_pass http://192.168.1.220:61208/api/4/;  # Glances
proxy_pass http://192.168.1.220:8686/;         # ???
```

**Проблема:**
- Если IP сервера изменится → routes сломаются
- Невозможно перенести на другую машину без правки конфига

**Решение:**
```nginx
# БЫЛО:
proxy_pass http://192.168.1.220:61208/api/4/;

# ДОЛЖНО БЫТЬ (если Glances в Docker):
proxy_pass http://host.docker.internal:61208/api/4/;

# ИЛИ добавить в docker-compose.yml:
extra_hosts:
  - "glances:192.168.1.220"
```

---

### **2. ❌ Hardcoded IPs в System API**

**Серьезность:** 🟡 **MEDIUM (5/10)**

**Найдено:**
- `system-api/routes/services.js`: `host = '192.168.1.220'`
- `system-api/index.js`: CORS origins содержит `http://192.168.1.220:7777`

**Проблема:**
- Жестко привязано к текущему IP
- При переносе на другой хост сломается

**Решение:**
Использовать переменные окружения:
```javascript
// system-api/routes/services.js
const HOST_IP = process.env.HOST_IP || '192.168.1.220';
const checkPort = (port, host = HOST_IP) => ...

// system-api/index.js
const CORS_ORIGINS = process.env.CORS_ORIGINS
    ? process.env.CORS_ORIGINS.split(',')
    : ['http://localhost:5173', ...];
```

---

## ⚠️ **ВАЖНЫЕ ПРЕДУПРЕЖДЕНИЯ**

### **3. ⚠️ Missing Dependencies в docker-compose.yml**

**Серьезность:** 🟡 **MEDIUM (4/10)**

**Найдено:**
- `grafana` не имеет `depends_on: [prometheus]`
- `system-api` не имеет `depends_on: [postgres, redis]`

**Проблема:**
- Контейнеры могут стартовать в неправильном порядке
- System API может попытаться подключиться к Redis/Postgres до их запуска

**Решение:**
```yaml
grafana:
  depends_on:
    prometheus:
      condition: service_started

system-api:
  depends_on:
    creationhub-postgres:
      condition: service_healthy
    redis:
      condition: service_healthy
```

---

### **4. ⚠️ Отсутствующие ENV переменные**

**Серьезность:** 🟢 **LOW (2/10)**

**Отсутствуют в `.env`:**
- `AI_DATA_PATH`
- `CORS_ORIGINS`
- `GLANCES_URL`
- `PORT`
- `RATE_LIMIT_RPM`
- `WG_CONFIG_DIR`

**Проблема:**
Используются дефолтные значения, которые могут не подходить для продакшена.

**Решение:**
Добавить в `.env`:
```bash
# System
PORT=9191
WG_CONFIG_DIR=/etc/wireguard

# Paths
AI_DATA_PATH=./ai_data
GLANCES_URL=http://192.168.1.220:61208

# Security
CORS_ORIGINS=http://localhost:7777,http://192.168.1.220:7777
RATE_LIMIT_RPM=500
```

---

## 📊 **ДОПОЛНИТЕЛЬНЫЕ НАБЛЮДЕНИЯ**

### **✅ Что работает хорошо:**
- Все критические эндпоинты доступны
- Нет публично открытых портов (кроме dashboard)
- `.env` имеет правильные permissions (600)
- Все healthcheck'и проходят
- Нет CHANGEME значений в production

### **⚠️ Что требует внимания:**
- **Диск заполнен на 74%** - рекомендуется очистить старые логи/бэкапы
- **PostgreSQL errors в логах** - запросы к несуществующим колонкам
- **404 на `/api/services/health`** - endpoint не существует (фронтенд может его использовать)

---

## 🔧 **ПЛАН ИСПРАВЛЕНИЙ**

### **Приоритет 1: Критические (выполнить сейчас)**
1. ✅ Исправить hardcoded IPs в nginx.conf
2. ✅ Добавить зависимости в docker-compose.yml

### **Приоритет 2: Важные (выполнить сегодня)**
3. ✅ Убрать hardcoded IPs из System API
4. ✅ Добавить недостающие ENV переменные

### **Приоритет 3: Профилактика (на неделе)**
5. Очистить старые Docker volumes (диск 74%)
6. Исправить ошибки PostgreSQL (несуществующие колонки)
7. Добавить `/api/services/health` endpoint если используется

---

## 📋 **ЧЕКЛИСТ ИСПРАВЛЕНИЙ**

```bash
- [ ] 1. Исправить nginx.conf (hardcoded IPs)
- [ ] 2. Добавить depends_on в docker-compose.yml
- [ ] 3. Вынести IPs в переменные окружения (System API)
- [ ] 4. Добавить все переменные в .env
- [ ] 5. Перезапустить затронутые сервисы
- [ ] 6. Запустить bug_scanner.sh снова для проверки
```

---

## 🎯 **СЛЕДУЮЩИЕ ШАГИ**

**Хотите, чтобы я:**
1. **Исправил все 4 проблемы автоматически** (рекомендуется)
2. **Исправил только критические** (1-2)
3. **Дал инструкции для ручного исправления**

**Ваше решение?**

---

**Scan Complete**  
**Total Issues:** 4  
**Critical:** 1  
**Medium:** 2  
**Low:** 1
